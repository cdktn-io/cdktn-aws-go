import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfElbConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elb#id DataTfElb#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elb#name DataTfElb#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elb#region DataTfElb#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elb#tags DataTfElb#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elb aws_elb}
*/
export declare class DataTfElb extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_elb";
    /**
    * Generates CDKTN code for importing a DataTfElb resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfElb to import
    * @param importFromId The id of the existing DataTfElb that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elb#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfElb to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elb aws_elb} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfElbConfig
    */
    constructor(scope: Construct, id: string, config: DataTfElbConfig);
    private _accessLogs;
    get accessLogs(): DataTfElb.AccessLogsPropertyList;
    get arn(): string;
    get availabilityZones(): string[];
    get connectionDraining(): cdktn.IResolvable;
    get connectionDrainingTimeout(): number;
    get crossZoneLoadBalancing(): cdktn.IResolvable;
    get desyncMitigationMode(): string;
    get dnsName(): string;
    private _healthCheck;
    get healthCheck(): DataTfElb.HealthCheckPropertyList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get idleTimeout(): number;
    get instances(): string[];
    get internal(): cdktn.IResolvable;
    private _listener;
    get listener(): DataTfElb.ListenerPropertyList;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get securityGroups(): string[];
    get sourceSecurityGroup(): string;
    get sourceSecurityGroupId(): string;
    get subnets(): string[];
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get zoneId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfElbAccessLogsPropertyToTerraform(struct?: DataTfElb.AccessLogsProperty): any;
export declare function dataTfElbAccessLogsPropertyToHclTerraform(struct?: DataTfElb.AccessLogsProperty): any;
export declare function dataTfElbHealthCheckPropertyToTerraform(struct?: DataTfElb.HealthCheckProperty): any;
export declare function dataTfElbHealthCheckPropertyToHclTerraform(struct?: DataTfElb.HealthCheckProperty): any;
export declare function dataTfElbListenerPropertyToTerraform(struct?: DataTfElb.ListenerProperty): any;
export declare function dataTfElbListenerPropertyToHclTerraform(struct?: DataTfElb.ListenerProperty): any;
export declare namespace DataTfElb {
    interface AccessLogsProperty {
    }
    class AccessLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AccessLogsProperty | undefined;
        set internalValue(value: AccessLogsProperty | undefined);
        get bucket(): string;
        get bucketPrefix(): string;
        get enabled(): cdktn.IResolvable;
        get interval(): number;
    }
    class AccessLogsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AccessLogsPropertyOutputReference;
    }
    interface HealthCheckProperty {
    }
    class HealthCheckPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HealthCheckProperty | undefined;
        set internalValue(value: HealthCheckProperty | undefined);
        get healthyThreshold(): number;
        get interval(): number;
        get target(): string;
        get timeout(): number;
        get unhealthyThreshold(): number;
    }
    class HealthCheckPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HealthCheckPropertyOutputReference;
    }
    interface ListenerProperty {
    }
    class ListenerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ListenerProperty | undefined;
        set internalValue(value: ListenerProperty | undefined);
        get instancePort(): number;
        get instanceProtocol(): string;
        get lbPort(): number;
        get lbProtocol(): string;
        get sslCertificateId(): string;
    }
    class ListenerPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ListenerPropertyOutputReference;
    }
}
