import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfCustomKeyStoreConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_custom_key_store#cloud_hsm_cluster_id TfCustomKeyStore#cloud_hsm_cluster_id}
    */
    readonly cloudHsmClusterId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_custom_key_store#custom_key_store_name TfCustomKeyStore#custom_key_store_name}
    */
    readonly customKeyStoreName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_custom_key_store#custom_key_store_type TfCustomKeyStore#custom_key_store_type}
    */
    readonly customKeyStoreType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_custom_key_store#id TfCustomKeyStore#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_custom_key_store#key_store_password TfCustomKeyStore#key_store_password}
    */
    readonly keyStorePassword?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_custom_key_store#region TfCustomKeyStore#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_custom_key_store#trust_anchor_certificate TfCustomKeyStore#trust_anchor_certificate}
    */
    readonly trustAnchorCertificate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_custom_key_store#xks_proxy_connectivity TfCustomKeyStore#xks_proxy_connectivity}
    */
    readonly xksProxyConnectivity?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_custom_key_store#xks_proxy_uri_endpoint TfCustomKeyStore#xks_proxy_uri_endpoint}
    */
    readonly xksProxyUriEndpoint?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_custom_key_store#xks_proxy_uri_path TfCustomKeyStore#xks_proxy_uri_path}
    */
    readonly xksProxyUriPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_custom_key_store#xks_proxy_vpc_endpoint_service_name TfCustomKeyStore#xks_proxy_vpc_endpoint_service_name}
    */
    readonly xksProxyVpcEndpointServiceName?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_custom_key_store#timeouts TfCustomKeyStore#timeouts}
    */
    readonly timeouts?: TfCustomKeyStore.TimeoutsProperty;
    /**
    * xks_proxy_authentication_credential block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_custom_key_store#xks_proxy_authentication_credential TfCustomKeyStore#xks_proxy_authentication_credential}
    */
    readonly xksProxyAuthenticationCredential?: TfCustomKeyStore.XksProxyAuthenticationCredentialProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_custom_key_store aws_kms_custom_key_store}
*/
export declare class TfCustomKeyStore extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_kms_custom_key_store";
    /**
    * Generates CDKTN code for importing a TfCustomKeyStore resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfCustomKeyStore to import
    * @param importFromId The id of the existing TfCustomKeyStore that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_custom_key_store#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfCustomKeyStore to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_custom_key_store aws_kms_custom_key_store} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfCustomKeyStoreConfig
    */
    constructor(scope: Construct, id: string, config: TfCustomKeyStoreConfig);
    private _cloudHsmClusterId?;
    get cloudHsmClusterId(): string;
    set cloudHsmClusterId(value: string);
    resetCloudHsmClusterId(): void;
    get cloudHsmClusterIdInput(): string | undefined;
    private _customKeyStoreName?;
    get customKeyStoreName(): string;
    set customKeyStoreName(value: string);
    get customKeyStoreNameInput(): string | undefined;
    private _customKeyStoreType?;
    get customKeyStoreType(): string;
    set customKeyStoreType(value: string);
    resetCustomKeyStoreType(): void;
    get customKeyStoreTypeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _keyStorePassword?;
    get keyStorePassword(): string;
    set keyStorePassword(value: string);
    resetKeyStorePassword(): void;
    get keyStorePasswordInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _trustAnchorCertificate?;
    get trustAnchorCertificate(): string;
    set trustAnchorCertificate(value: string);
    resetTrustAnchorCertificate(): void;
    get trustAnchorCertificateInput(): string | undefined;
    private _xksProxyConnectivity?;
    get xksProxyConnectivity(): string;
    set xksProxyConnectivity(value: string);
    resetXksProxyConnectivity(): void;
    get xksProxyConnectivityInput(): string | undefined;
    private _xksProxyUriEndpoint?;
    get xksProxyUriEndpoint(): string;
    set xksProxyUriEndpoint(value: string);
    resetXksProxyUriEndpoint(): void;
    get xksProxyUriEndpointInput(): string | undefined;
    private _xksProxyUriPath?;
    get xksProxyUriPath(): string;
    set xksProxyUriPath(value: string);
    resetXksProxyUriPath(): void;
    get xksProxyUriPathInput(): string | undefined;
    private _xksProxyVpcEndpointServiceName?;
    get xksProxyVpcEndpointServiceName(): string;
    set xksProxyVpcEndpointServiceName(value: string);
    resetXksProxyVpcEndpointServiceName(): void;
    get xksProxyVpcEndpointServiceNameInput(): string | undefined;
    private _timeouts;
    get timeouts(): TfCustomKeyStore.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfCustomKeyStore.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): TfCustomKeyStore.TimeoutsProperty | cdktn.IResolvable | undefined;
    private _xksProxyAuthenticationCredential;
    get xksProxyAuthenticationCredential(): TfCustomKeyStore.XksProxyAuthenticationCredentialPropertyOutputReference;
    putXksProxyAuthenticationCredential(value: TfCustomKeyStore.XksProxyAuthenticationCredentialProperty): void;
    resetXksProxyAuthenticationCredential(): void;
    get xksProxyAuthenticationCredentialInput(): TfCustomKeyStore.XksProxyAuthenticationCredentialProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfCustomKeyStoreTimeoutsPropertyToTerraform(struct?: TfCustomKeyStore.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfCustomKeyStoreTimeoutsPropertyToHclTerraform(struct?: TfCustomKeyStore.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfCustomKeyStoreXksProxyAuthenticationCredentialPropertyToTerraform(struct?: TfCustomKeyStore.XksProxyAuthenticationCredentialPropertyOutputReference | TfCustomKeyStore.XksProxyAuthenticationCredentialProperty): any;
export declare function tfCustomKeyStoreXksProxyAuthenticationCredentialPropertyToHclTerraform(struct?: TfCustomKeyStore.XksProxyAuthenticationCredentialPropertyOutputReference | TfCustomKeyStore.XksProxyAuthenticationCredentialProperty): any;
export declare namespace TfCustomKeyStore {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_custom_key_store#create TfCustomKeyStore#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_custom_key_store#delete TfCustomKeyStore#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_custom_key_store#update TfCustomKeyStore#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface XksProxyAuthenticationCredentialProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_custom_key_store#access_key_id TfCustomKeyStore#access_key_id}
        */
        readonly accessKeyId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_custom_key_store#raw_secret_access_key TfCustomKeyStore#raw_secret_access_key}
        */
        readonly rawSecretAccessKey: string;
    }
    class XksProxyAuthenticationCredentialPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): XksProxyAuthenticationCredentialProperty | undefined;
        set internalValue(value: XksProxyAuthenticationCredentialProperty | undefined);
        private _accessKeyId?;
        get accessKeyId(): string;
        set accessKeyId(value: string);
        get accessKeyIdInput(): string | undefined;
        private _rawSecretAccessKey?;
        get rawSecretAccessKey(): string;
        set rawSecretAccessKey(value: string);
        get rawSecretAccessKeyInput(): string | undefined;
    }
}
