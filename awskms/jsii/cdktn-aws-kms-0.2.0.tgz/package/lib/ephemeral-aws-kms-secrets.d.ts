import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface EphemeralTfSecretsConfig extends cdktn.TerraformEphemeralMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/ephemeral-resources/kms_secrets#region EphemeralTfSecrets#region}
    */
    readonly region?: string;
    /**
    * secret block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/ephemeral-resources/kms_secrets#secret EphemeralTfSecrets#secret}
    */
    readonly secret?: EphemeralTfSecrets.SecretProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/ephemeral-resources/kms_secrets aws_kms_secrets}
*/
export declare class EphemeralTfSecrets extends cdktn.TerraformEphemeralResource {
    static readonly tfResourceType = "aws_kms_secrets";
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/ephemeral-resources/kms_secrets aws_kms_secrets} Ephemeral Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EphemeralTfSecretsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: EphemeralTfSecretsConfig);
    private _plaintext;
    get plaintext(): cdktn.StringMap;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _secret;
    get secret(): EphemeralTfSecrets.SecretPropertyList;
    putSecret(value: EphemeralTfSecrets.SecretProperty[] | cdktn.IResolvable): void;
    resetSecret(): void;
    get secretInput(): cdktn.IResolvable | EphemeralTfSecrets.SecretProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function ephemeralTfSecretsSecretPropertyToTerraform(struct?: EphemeralTfSecrets.SecretProperty | cdktn.IResolvable): any;
export declare function ephemeralTfSecretsSecretPropertyToHclTerraform(struct?: EphemeralTfSecrets.SecretProperty | cdktn.IResolvable): any;
export declare namespace EphemeralTfSecrets {
    interface SecretProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/ephemeral-resources/kms_secrets#context EphemeralTfSecrets#context}
        */
        readonly context?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/ephemeral-resources/kms_secrets#encryption_algorithm EphemeralTfSecrets#encryption_algorithm}
        */
        readonly encryptionAlgorithm?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/ephemeral-resources/kms_secrets#grant_tokens EphemeralTfSecrets#grant_tokens}
        */
        readonly grantTokens?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/ephemeral-resources/kms_secrets#key_id EphemeralTfSecrets#key_id}
        */
        readonly keyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/ephemeral-resources/kms_secrets#name EphemeralTfSecrets#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/ephemeral-resources/kms_secrets#payload EphemeralTfSecrets#payload}
        */
        readonly payload: string;
    }
    class SecretPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SecretProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SecretProperty | cdktn.IResolvable | undefined);
        private _context?;
        get context(): {
            [key: string]: string;
        };
        set context(value: {
            [key: string]: string;
        });
        resetContext(): void;
        get contextInput(): {
            [key: string]: string;
        } | undefined;
        private _encryptionAlgorithm?;
        get encryptionAlgorithm(): string;
        set encryptionAlgorithm(value: string);
        resetEncryptionAlgorithm(): void;
        get encryptionAlgorithmInput(): string | undefined;
        private _grantTokens?;
        get grantTokens(): string[];
        set grantTokens(value: string[]);
        resetGrantTokens(): void;
        get grantTokensInput(): string[] | undefined;
        private _keyId?;
        get keyId(): string;
        set keyId(value: string);
        resetKeyId(): void;
        get keyIdInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _payload?;
        get payload(): string;
        set payload(value: string);
        get payloadInput(): string | undefined;
    }
    class SecretPropertyList extends cdktn.ComplexList {
        internalValue?: SecretProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SecretPropertyOutputReference;
    }
}
