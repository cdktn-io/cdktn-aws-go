import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfGrantConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_grant#grant_creation_tokens TfGrant#grant_creation_tokens}
    */
    readonly grantCreationTokens?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_grant#grantee_principal TfGrant#grantee_principal}
    */
    readonly granteePrincipal: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_grant#id TfGrant#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_grant#key_id TfGrant#key_id}
    */
    readonly keyId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_grant#name TfGrant#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_grant#operations TfGrant#operations}
    */
    readonly operations: string[];
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_grant#region TfGrant#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_grant#retire_on_delete TfGrant#retire_on_delete}
    */
    readonly retireOnDelete?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_grant#retiring_principal TfGrant#retiring_principal}
    */
    readonly retiringPrincipal?: string;
    /**
    * constraints block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_grant#constraints TfGrant#constraints}
    */
    readonly constraints?: TfGrant.ConstraintsProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_grant aws_kms_grant}
*/
export declare class TfGrant extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_kms_grant";
    /**
    * Generates CDKTN code for importing a TfGrant resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfGrant to import
    * @param importFromId The id of the existing TfGrant that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_grant#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfGrant to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_grant aws_kms_grant} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfGrantConfig
    */
    constructor(scope: Construct, id: string, config: TfGrantConfig);
    private _grantCreationTokens?;
    get grantCreationTokens(): string[];
    set grantCreationTokens(value: string[]);
    resetGrantCreationTokens(): void;
    get grantCreationTokensInput(): string[] | undefined;
    get grantId(): string;
    get grantToken(): string;
    private _granteePrincipal?;
    get granteePrincipal(): string;
    set granteePrincipal(value: string);
    get granteePrincipalInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _keyId?;
    get keyId(): string;
    set keyId(value: string);
    get keyIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _operations?;
    get operations(): string[];
    set operations(value: string[]);
    get operationsInput(): string[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _retireOnDelete?;
    get retireOnDelete(): boolean | cdktn.IResolvable;
    set retireOnDelete(value: boolean | cdktn.IResolvable);
    resetRetireOnDelete(): void;
    get retireOnDeleteInput(): boolean | cdktn.IResolvable | undefined;
    private _retiringPrincipal?;
    get retiringPrincipal(): string;
    set retiringPrincipal(value: string);
    resetRetiringPrincipal(): void;
    get retiringPrincipalInput(): string | undefined;
    private _constraints;
    get constraints(): TfGrant.ConstraintsPropertyList;
    putConstraints(value: TfGrant.ConstraintsProperty[] | cdktn.IResolvable): void;
    resetConstraints(): void;
    get constraintsInput(): cdktn.IResolvable | TfGrant.ConstraintsProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfGrantConstraintsPropertyToTerraform(struct?: TfGrant.ConstraintsProperty | cdktn.IResolvable): any;
export declare function tfGrantConstraintsPropertyToHclTerraform(struct?: TfGrant.ConstraintsProperty | cdktn.IResolvable): any;
export declare namespace TfGrant {
    interface ConstraintsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_grant#encryption_context_equals TfGrant#encryption_context_equals}
        */
        readonly encryptionContextEquals?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kms_grant#encryption_context_subset TfGrant#encryption_context_subset}
        */
        readonly encryptionContextSubset?: {
            [key: string]: string;
        };
    }
    class ConstraintsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConstraintsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConstraintsProperty | cdktn.IResolvable | undefined);
        private _encryptionContextEquals?;
        get encryptionContextEquals(): {
            [key: string]: string;
        };
        set encryptionContextEquals(value: {
            [key: string]: string;
        });
        resetEncryptionContextEquals(): void;
        get encryptionContextEqualsInput(): {
            [key: string]: string;
        } | undefined;
        private _encryptionContextSubset?;
        get encryptionContextSubset(): {
            [key: string]: string;
        };
        set encryptionContextSubset(value: {
            [key: string]: string;
        });
        resetEncryptionContextSubset(): void;
        get encryptionContextSubsetInput(): {
            [key: string]: string;
        } | undefined;
    }
    class ConstraintsPropertyList extends cdktn.ComplexList {
        internalValue?: ConstraintsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConstraintsPropertyOutputReference;
    }
}
