import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsCognitoIdentityPoolConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_identity_pool#allow_classic_flow AwsCognitoIdentityPool#allow_classic_flow}
    */
    readonly allowClassicFlow?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_identity_pool#allow_unauthenticated_identities AwsCognitoIdentityPool#allow_unauthenticated_identities}
    */
    readonly allowUnauthenticatedIdentities?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_identity_pool#developer_provider_name AwsCognitoIdentityPool#developer_provider_name}
    */
    readonly developerProviderName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_identity_pool#id AwsCognitoIdentityPool#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_identity_pool#identity_pool_name AwsCognitoIdentityPool#identity_pool_name}
    */
    readonly identityPoolName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_identity_pool#openid_connect_provider_arns AwsCognitoIdentityPool#openid_connect_provider_arns}
    */
    readonly openidConnectProviderArns?: string[];
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_identity_pool#region AwsCognitoIdentityPool#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_identity_pool#saml_provider_arns AwsCognitoIdentityPool#saml_provider_arns}
    */
    readonly samlProviderArns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_identity_pool#supported_login_providers AwsCognitoIdentityPool#supported_login_providers}
    */
    readonly supportedLoginProviders?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_identity_pool#tags AwsCognitoIdentityPool#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_identity_pool#tags_all AwsCognitoIdentityPool#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * cognito_identity_providers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_identity_pool#cognito_identity_providers AwsCognitoIdentityPool#cognito_identity_providers}
    */
    readonly cognitoIdentityProviders?: AwsCognitoIdentityPool.CognitoIdentityProvidersProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_identity_pool aws_cognito_identity_pool}
*/
export declare class AwsCognitoIdentityPool extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cognito_identity_pool";
    /**
    * Generates CDKTN code for importing a AwsCognitoIdentityPool resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCognitoIdentityPool to import
    * @param importFromId The id of the existing AwsCognitoIdentityPool that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_identity_pool#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCognitoIdentityPool to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_identity_pool aws_cognito_identity_pool} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsCognitoIdentityPoolConfig
    */
    constructor(scope: Construct, id: string, config: AwsCognitoIdentityPoolConfig);
    private _allowClassicFlow?;
    get allowClassicFlow(): boolean | cdktn.IResolvable;
    set allowClassicFlow(value: boolean | cdktn.IResolvable);
    resetAllowClassicFlow(): void;
    get allowClassicFlowInput(): boolean | cdktn.IResolvable | undefined;
    private _allowUnauthenticatedIdentities?;
    get allowUnauthenticatedIdentities(): boolean | cdktn.IResolvable;
    set allowUnauthenticatedIdentities(value: boolean | cdktn.IResolvable);
    resetAllowUnauthenticatedIdentities(): void;
    get allowUnauthenticatedIdentitiesInput(): boolean | cdktn.IResolvable | undefined;
    get arn(): string;
    private _developerProviderName?;
    get developerProviderName(): string;
    set developerProviderName(value: string);
    resetDeveloperProviderName(): void;
    get developerProviderNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identityPoolName?;
    get identityPoolName(): string;
    set identityPoolName(value: string);
    get identityPoolNameInput(): string | undefined;
    private _openidConnectProviderArns?;
    get openidConnectProviderArns(): string[];
    set openidConnectProviderArns(value: string[]);
    resetOpenidConnectProviderArns(): void;
    get openidConnectProviderArnsInput(): string[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _samlProviderArns?;
    get samlProviderArns(): string[];
    set samlProviderArns(value: string[]);
    resetSamlProviderArns(): void;
    get samlProviderArnsInput(): string[] | undefined;
    private _supportedLoginProviders?;
    get supportedLoginProviders(): {
        [key: string]: string;
    };
    set supportedLoginProviders(value: {
        [key: string]: string;
    });
    resetSupportedLoginProviders(): void;
    get supportedLoginProvidersInput(): {
        [key: string]: string;
    } | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _cognitoIdentityProviders;
    get cognitoIdentityProviders(): AwsCognitoIdentityPool.CognitoIdentityProvidersPropertyList;
    putCognitoIdentityProviders(value: AwsCognitoIdentityPool.CognitoIdentityProvidersProperty[] | cdktn.IResolvable): void;
    resetCognitoIdentityProviders(): void;
    get cognitoIdentityProvidersInput(): cdktn.IResolvable | AwsCognitoIdentityPool.CognitoIdentityProvidersProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsCognitoIdentityPoolCognitoIdentityProvidersPropertyToTerraform(struct?: AwsCognitoIdentityPool.CognitoIdentityProvidersProperty | cdktn.IResolvable): any;
export declare function awsCognitoIdentityPoolCognitoIdentityProvidersPropertyToHclTerraform(struct?: AwsCognitoIdentityPool.CognitoIdentityProvidersProperty | cdktn.IResolvable): any;
export declare namespace AwsCognitoIdentityPool {
    interface CognitoIdentityProvidersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_identity_pool#client_id AwsCognitoIdentityPool#client_id}
        */
        readonly clientId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_identity_pool#provider_name AwsCognitoIdentityPool#provider_name}
        */
        readonly providerName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_identity_pool#server_side_token_check AwsCognitoIdentityPool#server_side_token_check}
        */
        readonly serverSideTokenCheck?: boolean | cdktn.IResolvable;
    }
    class CognitoIdentityProvidersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CognitoIdentityProvidersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CognitoIdentityProvidersProperty | cdktn.IResolvable | undefined);
        private _clientId?;
        get clientId(): string;
        set clientId(value: string);
        resetClientId(): void;
        get clientIdInput(): string | undefined;
        private _providerName?;
        get providerName(): string;
        set providerName(value: string);
        resetProviderName(): void;
        get providerNameInput(): string | undefined;
        private _serverSideTokenCheck?;
        get serverSideTokenCheck(): boolean | cdktn.IResolvable;
        set serverSideTokenCheck(value: boolean | cdktn.IResolvable);
        resetServerSideTokenCheck(): void;
        get serverSideTokenCheckInput(): boolean | cdktn.IResolvable | undefined;
    }
    class CognitoIdentityProvidersPropertyList extends cdktn.ComplexList {
        internalValue?: CognitoIdentityProvidersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CognitoIdentityProvidersPropertyOutputReference;
    }
}
