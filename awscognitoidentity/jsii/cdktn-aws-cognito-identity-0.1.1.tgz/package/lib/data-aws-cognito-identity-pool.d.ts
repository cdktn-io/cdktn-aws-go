import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsCognitoIdentityPoolConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cognito_identity_pool#id DataAwsCognitoIdentityPool#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cognito_identity_pool#identity_pool_name DataAwsCognitoIdentityPool#identity_pool_name}
    */
    readonly identityPoolName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cognito_identity_pool#region DataAwsCognitoIdentityPool#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cognito_identity_pool#tags DataAwsCognitoIdentityPool#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cognito_identity_pool aws_cognito_identity_pool}
*/
export declare class DataAwsCognitoIdentityPool extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_cognito_identity_pool";
    /**
    * Generates CDKTN code for importing a DataAwsCognitoIdentityPool resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsCognitoIdentityPool to import
    * @param importFromId The id of the existing DataAwsCognitoIdentityPool that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cognito_identity_pool#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsCognitoIdentityPool to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cognito_identity_pool aws_cognito_identity_pool} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsCognitoIdentityPoolConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsCognitoIdentityPoolConfig);
    get allowClassicFlow(): cdktn.IResolvable;
    get allowUnauthenticatedIdentities(): cdktn.IResolvable;
    get arn(): string;
    private _cognitoIdentityProviders;
    get cognitoIdentityProviders(): DataAwsCognitoIdentityPool.CognitoIdentityProvidersPropertyList;
    get developerProviderName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identityPoolName?;
    get identityPoolName(): string;
    set identityPoolName(value: string);
    get identityPoolNameInput(): string | undefined;
    get openidConnectProviderArns(): string[];
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get samlProviderArns(): string[];
    private _supportedLoginProviders;
    get supportedLoginProviders(): cdktn.StringMap;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsCognitoIdentityPoolCognitoIdentityProvidersPropertyToTerraform(struct?: DataAwsCognitoIdentityPool.CognitoIdentityProvidersProperty): any;
export declare function dataAwsCognitoIdentityPoolCognitoIdentityProvidersPropertyToHclTerraform(struct?: DataAwsCognitoIdentityPool.CognitoIdentityProvidersProperty): any;
export declare namespace DataAwsCognitoIdentityPool {
    interface CognitoIdentityProvidersProperty {
    }
    class CognitoIdentityProvidersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CognitoIdentityProvidersProperty | undefined;
        set internalValue(value: CognitoIdentityProvidersProperty | undefined);
        get clientId(): string;
        get providerName(): string;
        get serverSideTokenCheck(): cdktn.IResolvable;
    }
    class CognitoIdentityProvidersPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CognitoIdentityProvidersPropertyOutputReference;
    }
}
