import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfPoolProviderPrincipalTagConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_identity_pool_provider_principal_tag#id TfPoolProviderPrincipalTag#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_identity_pool_provider_principal_tag#identity_pool_id TfPoolProviderPrincipalTag#identity_pool_id}
    */
    readonly identityPoolId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_identity_pool_provider_principal_tag#identity_provider_name TfPoolProviderPrincipalTag#identity_provider_name}
    */
    readonly identityProviderName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_identity_pool_provider_principal_tag#principal_tags TfPoolProviderPrincipalTag#principal_tags}
    */
    readonly principalTags?: {
        [key: string]: string;
    };
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_identity_pool_provider_principal_tag#region TfPoolProviderPrincipalTag#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_identity_pool_provider_principal_tag#use_defaults TfPoolProviderPrincipalTag#use_defaults}
    */
    readonly useDefaults?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_identity_pool_provider_principal_tag aws_cognito_identity_pool_provider_principal_tag}
*/
export declare class TfPoolProviderPrincipalTag extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cognito_identity_pool_provider_principal_tag";
    /**
    * Generates CDKTN code for importing a TfPoolProviderPrincipalTag resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfPoolProviderPrincipalTag to import
    * @param importFromId The id of the existing TfPoolProviderPrincipalTag that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_identity_pool_provider_principal_tag#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfPoolProviderPrincipalTag to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_identity_pool_provider_principal_tag aws_cognito_identity_pool_provider_principal_tag} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfPoolProviderPrincipalTagConfig
    */
    constructor(scope: Construct, id: string, config: TfPoolProviderPrincipalTagConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identityPoolId?;
    get identityPoolId(): string;
    set identityPoolId(value: string);
    get identityPoolIdInput(): string | undefined;
    private _identityProviderName?;
    get identityProviderName(): string;
    set identityProviderName(value: string);
    get identityProviderNameInput(): string | undefined;
    private _principalTags?;
    get principalTags(): {
        [key: string]: string;
    };
    set principalTags(value: {
        [key: string]: string;
    });
    resetPrincipalTags(): void;
    get principalTagsInput(): {
        [key: string]: string;
    } | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _useDefaults?;
    get useDefaults(): boolean | cdktn.IResolvable;
    set useDefaults(value: boolean | cdktn.IResolvable);
    resetUseDefaults(): void;
    get useDefaultsInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
