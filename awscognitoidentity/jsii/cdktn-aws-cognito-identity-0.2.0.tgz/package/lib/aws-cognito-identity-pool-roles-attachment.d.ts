import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfPoolRolesAttachmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_identity_pool_roles_attachment#id TfPoolRolesAttachment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_identity_pool_roles_attachment#identity_pool_id TfPoolRolesAttachment#identity_pool_id}
    */
    readonly identityPoolId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_identity_pool_roles_attachment#region TfPoolRolesAttachment#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_identity_pool_roles_attachment#roles TfPoolRolesAttachment#roles}
    */
    readonly roles: {
        [key: string]: string;
    };
    /**
    * role_mapping block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_identity_pool_roles_attachment#role_mapping TfPoolRolesAttachment#role_mapping}
    */
    readonly roleMapping?: TfPoolRolesAttachment.RoleMappingProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_identity_pool_roles_attachment aws_cognito_identity_pool_roles_attachment}
*/
export declare class TfPoolRolesAttachment extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cognito_identity_pool_roles_attachment";
    /**
    * Generates CDKTN code for importing a TfPoolRolesAttachment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfPoolRolesAttachment to import
    * @param importFromId The id of the existing TfPoolRolesAttachment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_identity_pool_roles_attachment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfPoolRolesAttachment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_identity_pool_roles_attachment aws_cognito_identity_pool_roles_attachment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfPoolRolesAttachmentConfig
    */
    constructor(scope: Construct, id: string, config: TfPoolRolesAttachmentConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identityPoolId?;
    get identityPoolId(): string;
    set identityPoolId(value: string);
    get identityPoolIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roles?;
    get roles(): {
        [key: string]: string;
    };
    set roles(value: {
        [key: string]: string;
    });
    get rolesInput(): {
        [key: string]: string;
    } | undefined;
    private _roleMapping;
    get roleMapping(): TfPoolRolesAttachment.RoleMappingPropertyList;
    putRoleMapping(value: TfPoolRolesAttachment.RoleMappingProperty[] | cdktn.IResolvable): void;
    resetRoleMapping(): void;
    get roleMappingInput(): cdktn.IResolvable | TfPoolRolesAttachment.RoleMappingProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfPoolRolesAttachmentMappingRulePropertyToTerraform(struct?: TfPoolRolesAttachment.MappingRuleProperty | cdktn.IResolvable): any;
export declare function tfPoolRolesAttachmentMappingRulePropertyToHclTerraform(struct?: TfPoolRolesAttachment.MappingRuleProperty | cdktn.IResolvable): any;
export declare function tfPoolRolesAttachmentRoleMappingPropertyToTerraform(struct?: TfPoolRolesAttachment.RoleMappingProperty | cdktn.IResolvable): any;
export declare function tfPoolRolesAttachmentRoleMappingPropertyToHclTerraform(struct?: TfPoolRolesAttachment.RoleMappingProperty | cdktn.IResolvable): any;
export declare namespace TfPoolRolesAttachment {
    interface MappingRuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_identity_pool_roles_attachment#claim TfPoolRolesAttachment#claim}
        */
        readonly claim: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_identity_pool_roles_attachment#match_type TfPoolRolesAttachment#match_type}
        */
        readonly matchType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_identity_pool_roles_attachment#role_arn TfPoolRolesAttachment#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_identity_pool_roles_attachment#value TfPoolRolesAttachment#value}
        */
        readonly value: string;
    }
    class MappingRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MappingRuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MappingRuleProperty | cdktn.IResolvable | undefined);
        private _claim?;
        get claim(): string;
        set claim(value: string);
        get claimInput(): string | undefined;
        private _matchType?;
        get matchType(): string;
        set matchType(value: string);
        get matchTypeInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class MappingRulePropertyList extends cdktn.ComplexList {
        internalValue?: MappingRuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MappingRulePropertyOutputReference;
    }
    interface RoleMappingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_identity_pool_roles_attachment#ambiguous_role_resolution TfPoolRolesAttachment#ambiguous_role_resolution}
        */
        readonly ambiguousRoleResolution?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_identity_pool_roles_attachment#identity_provider TfPoolRolesAttachment#identity_provider}
        */
        readonly identityProvider: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_identity_pool_roles_attachment#type TfPoolRolesAttachment#type}
        */
        readonly type: string;
        /**
        * mapping_rule block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_identity_pool_roles_attachment#mapping_rule TfPoolRolesAttachment#mapping_rule}
        */
        readonly mappingRule?: MappingRuleProperty[] | cdktn.IResolvable;
    }
    class RoleMappingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RoleMappingProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RoleMappingProperty | cdktn.IResolvable | undefined);
        private _ambiguousRoleResolution?;
        get ambiguousRoleResolution(): string;
        set ambiguousRoleResolution(value: string);
        resetAmbiguousRoleResolution(): void;
        get ambiguousRoleResolutionInput(): string | undefined;
        private _identityProvider?;
        get identityProvider(): string;
        set identityProvider(value: string);
        get identityProviderInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _mappingRule;
        get mappingRule(): MappingRulePropertyList;
        putMappingRule(value: MappingRuleProperty[] | cdktn.IResolvable): void;
        resetMappingRule(): void;
        get mappingRuleInput(): cdktn.IResolvable | MappingRuleProperty[] | undefined;
    }
    class RoleMappingPropertyList extends cdktn.ComplexList {
        internalValue?: RoleMappingProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RoleMappingPropertyOutputReference;
    }
}
