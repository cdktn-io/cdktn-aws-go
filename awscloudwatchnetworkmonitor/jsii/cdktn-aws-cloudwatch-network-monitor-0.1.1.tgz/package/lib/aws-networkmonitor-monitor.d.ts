import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsNetworkmonitorMonitorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmonitor_monitor#aggregation_period AwsNetworkmonitorMonitor#aggregation_period}
    */
    readonly aggregationPeriod?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmonitor_monitor#monitor_name AwsNetworkmonitorMonitor#monitor_name}
    */
    readonly monitorName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmonitor_monitor#region AwsNetworkmonitorMonitor#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmonitor_monitor#tags AwsNetworkmonitorMonitor#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmonitor_monitor aws_networkmonitor_monitor}
*/
export declare class AwsNetworkmonitorMonitor extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_networkmonitor_monitor";
    /**
    * Generates CDKTN code for importing a AwsNetworkmonitorMonitor resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsNetworkmonitorMonitor to import
    * @param importFromId The id of the existing AwsNetworkmonitorMonitor that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmonitor_monitor#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsNetworkmonitorMonitor to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmonitor_monitor aws_networkmonitor_monitor} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsNetworkmonitorMonitorConfig
    */
    constructor(scope: Construct, id: string, config: AwsNetworkmonitorMonitorConfig);
    private _aggregationPeriod?;
    get aggregationPeriod(): number;
    set aggregationPeriod(value: number);
    resetAggregationPeriod(): void;
    get aggregationPeriodInput(): number | undefined;
    get arn(): string;
    get id(): string;
    private _monitorName?;
    get monitorName(): string;
    set monitorName(value: string);
    get monitorNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
