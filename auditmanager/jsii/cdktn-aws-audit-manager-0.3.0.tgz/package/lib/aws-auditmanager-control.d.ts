import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsControlConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_control#action_plan_instructions AwsControl#action_plan_instructions}
    */
    readonly actionPlanInstructions?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_control#action_plan_title AwsControl#action_plan_title}
    */
    readonly actionPlanTitle?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_control#description AwsControl#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_control#name AwsControl#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_control#region AwsControl#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_control#tags AwsControl#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_control#testing_information AwsControl#testing_information}
    */
    readonly testingInformation?: string;
    /**
    * control_mapping_sources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_control#control_mapping_sources AwsControl#control_mapping_sources}
    */
    readonly controlMappingSources?: AwsControl.ControlMappingSourcesProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_control aws_auditmanager_control}
*/
export declare class AwsControl extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_auditmanager_control";
    /**
    * Generates CDKTN code for importing a AwsControl resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsControl to import
    * @param importFromId The id of the existing AwsControl that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_control#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsControl to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_control aws_auditmanager_control} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsControlConfig
    */
    constructor(scope: Construct, id: string, config: AwsControlConfig);
    private _actionPlanInstructions?;
    get actionPlanInstructions(): string;
    set actionPlanInstructions(value: string);
    resetActionPlanInstructions(): void;
    get actionPlanInstructionsInput(): string | undefined;
    private _actionPlanTitle?;
    get actionPlanTitle(): string;
    set actionPlanTitle(value: string);
    resetActionPlanTitle(): void;
    get actionPlanTitleInput(): string | undefined;
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _testingInformation?;
    get testingInformation(): string;
    set testingInformation(value: string);
    resetTestingInformation(): void;
    get testingInformationInput(): string | undefined;
    get type(): string;
    private _controlMappingSources;
    get controlMappingSources(): AwsControl.ControlMappingSourcesPropertyList;
    putControlMappingSources(value: AwsControl.ControlMappingSourcesProperty[] | cdktn.IResolvable): void;
    resetControlMappingSources(): void;
    get controlMappingSourcesInput(): cdktn.IResolvable | AwsControl.ControlMappingSourcesProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsControlSourceKeywordPropertyToTerraform(struct?: AwsControl.SourceKeywordProperty | cdktn.IResolvable): any;
export declare function awsControlSourceKeywordPropertyToHclTerraform(struct?: AwsControl.SourceKeywordProperty | cdktn.IResolvable): any;
export declare function awsControlControlMappingSourcesPropertyToTerraform(struct?: AwsControl.ControlMappingSourcesProperty | cdktn.IResolvable): any;
export declare function awsControlControlMappingSourcesPropertyToHclTerraform(struct?: AwsControl.ControlMappingSourcesProperty | cdktn.IResolvable): any;
export declare namespace AwsControl {
    interface SourceKeywordProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_control#keyword_input_type AwsControl#keyword_input_type}
        */
        readonly keywordInputType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_control#keyword_value AwsControl#keyword_value}
        */
        readonly keywordValue?: string;
    }
    class SourceKeywordPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SourceKeywordProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SourceKeywordProperty | cdktn.IResolvable | undefined);
        private _keywordInputType?;
        get keywordInputType(): string;
        set keywordInputType(value: string);
        resetKeywordInputType(): void;
        get keywordInputTypeInput(): string | undefined;
        private _keywordValue?;
        get keywordValue(): string;
        set keywordValue(value: string);
        resetKeywordValue(): void;
        get keywordValueInput(): string | undefined;
    }
    class SourceKeywordPropertyList extends cdktn.ComplexList {
        internalValue?: SourceKeywordProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SourceKeywordPropertyOutputReference;
    }
    interface ControlMappingSourcesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_control#source_description AwsControl#source_description}
        */
        readonly sourceDescription?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_control#source_frequency AwsControl#source_frequency}
        */
        readonly sourceFrequency?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_control#source_keyword AwsControl#source_keyword}
        */
        readonly sourceKeyword?: SourceKeywordProperty[] | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_control#source_name AwsControl#source_name}
        */
        readonly sourceName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_control#source_set_up_option AwsControl#source_set_up_option}
        */
        readonly sourceSetUpOption: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_control#source_type AwsControl#source_type}
        */
        readonly sourceType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/auditmanager_control#troubleshooting_text AwsControl#troubleshooting_text}
        */
        readonly troubleshootingText?: string;
    }
    class ControlMappingSourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ControlMappingSourcesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ControlMappingSourcesProperty | cdktn.IResolvable | undefined);
        private _sourceDescription?;
        get sourceDescription(): string;
        set sourceDescription(value: string);
        resetSourceDescription(): void;
        get sourceDescriptionInput(): string | undefined;
        private _sourceFrequency?;
        get sourceFrequency(): string;
        set sourceFrequency(value: string);
        resetSourceFrequency(): void;
        get sourceFrequencyInput(): string | undefined;
        get sourceId(): string;
        private _sourceKeyword;
        get sourceKeyword(): SourceKeywordPropertyList;
        putSourceKeyword(value: SourceKeywordProperty[] | cdktn.IResolvable): void;
        resetSourceKeyword(): void;
        get sourceKeywordInput(): cdktn.IResolvable | SourceKeywordProperty[] | undefined;
        private _sourceName?;
        get sourceName(): string;
        set sourceName(value: string);
        get sourceNameInput(): string | undefined;
        private _sourceSetUpOption?;
        get sourceSetUpOption(): string;
        set sourceSetUpOption(value: string);
        get sourceSetUpOptionInput(): string | undefined;
        private _sourceType?;
        get sourceType(): string;
        set sourceType(value: string);
        get sourceTypeInput(): string | undefined;
        private _troubleshootingText?;
        get troubleshootingText(): string;
        set troubleshootingText(value: string);
        resetTroubleshootingText(): void;
        get troubleshootingTextInput(): string | undefined;
    }
    class ControlMappingSourcesPropertyList extends cdktn.ComplexList {
        internalValue?: ControlMappingSourcesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ControlMappingSourcesPropertyOutputReference;
    }
}
