import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsFrameworkConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/auditmanager_framework#framework_type DataAwsFramework#framework_type}
    */
    readonly frameworkType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/auditmanager_framework#name DataAwsFramework#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/auditmanager_framework#region DataAwsFramework#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/auditmanager_framework aws_auditmanager_framework}
*/
export declare class DataAwsFramework extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_auditmanager_framework";
    /**
    * Generates CDKTN code for importing a DataAwsFramework resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsFramework to import
    * @param importFromId The id of the existing DataAwsFramework that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/auditmanager_framework#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsFramework to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/auditmanager_framework aws_auditmanager_framework} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsFrameworkConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsFrameworkConfig);
    get arn(): string;
    get complianceType(): string;
    private _controlSets;
    get controlSets(): DataAwsFramework.ControlSetsPropertyList;
    get description(): string;
    private _frameworkType?;
    get frameworkType(): string;
    set frameworkType(value: string);
    get frameworkTypeInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags;
    get tags(): cdktn.StringMap;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsFrameworkControlsPropertyToTerraform(struct?: DataAwsFramework.ControlsProperty): any;
export declare function dataAwsFrameworkControlsPropertyToHclTerraform(struct?: DataAwsFramework.ControlsProperty): any;
export declare function dataAwsFrameworkControlSetsPropertyToTerraform(struct?: DataAwsFramework.ControlSetsProperty): any;
export declare function dataAwsFrameworkControlSetsPropertyToHclTerraform(struct?: DataAwsFramework.ControlSetsProperty): any;
export declare namespace DataAwsFramework {
    interface ControlsProperty {
    }
    class ControlsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ControlsProperty | undefined;
        set internalValue(value: ControlsProperty | undefined);
        get id(): string;
    }
    class ControlsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ControlsPropertyOutputReference;
    }
    interface ControlSetsProperty {
    }
    class ControlSetsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ControlSetsProperty | undefined;
        set internalValue(value: ControlSetsProperty | undefined);
        private _controls;
        get controls(): ControlsPropertyList;
        get id(): string;
        get name(): string;
    }
    class ControlSetsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ControlSetsPropertyOutputReference;
    }
}
