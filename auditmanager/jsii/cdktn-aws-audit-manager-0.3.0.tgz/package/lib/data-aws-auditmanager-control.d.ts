import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsControlConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/auditmanager_control#name DataAwsControl#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/auditmanager_control#region DataAwsControl#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/auditmanager_control#type DataAwsControl#type}
    */
    readonly type: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/auditmanager_control aws_auditmanager_control}
*/
export declare class DataAwsControl extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_auditmanager_control";
    /**
    * Generates CDKTN code for importing a DataAwsControl resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsControl to import
    * @param importFromId The id of the existing DataAwsControl that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/auditmanager_control#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsControl to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/auditmanager_control aws_auditmanager_control} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsControlConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsControlConfig);
    get actionPlanInstructions(): string;
    get actionPlanTitle(): string;
    get arn(): string;
    private _controlMappingSources;
    get controlMappingSources(): DataAwsControl.ControlMappingSourcesPropertyList;
    get description(): string;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags;
    get tags(): cdktn.StringMap;
    get testingInformation(): string;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsControlSourceKeywordPropertyToTerraform(struct?: DataAwsControl.SourceKeywordProperty): any;
export declare function dataAwsControlSourceKeywordPropertyToHclTerraform(struct?: DataAwsControl.SourceKeywordProperty): any;
export declare function dataAwsControlControlMappingSourcesPropertyToTerraform(struct?: DataAwsControl.ControlMappingSourcesProperty): any;
export declare function dataAwsControlControlMappingSourcesPropertyToHclTerraform(struct?: DataAwsControl.ControlMappingSourcesProperty): any;
export declare namespace DataAwsControl {
    interface SourceKeywordProperty {
    }
    class SourceKeywordPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SourceKeywordProperty | undefined;
        set internalValue(value: SourceKeywordProperty | undefined);
        get keywordInputType(): string;
        get keywordValue(): string;
    }
    class SourceKeywordPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SourceKeywordPropertyOutputReference;
    }
    interface ControlMappingSourcesProperty {
    }
    class ControlMappingSourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ControlMappingSourcesProperty | undefined;
        set internalValue(value: ControlMappingSourcesProperty | undefined);
        get sourceDescription(): string;
        get sourceFrequency(): string;
        get sourceId(): string;
        private _sourceKeyword;
        get sourceKeyword(): SourceKeywordPropertyList;
        get sourceName(): string;
        get sourceSetUpOption(): string;
        get sourceType(): string;
        get troubleshootingText(): string;
    }
    class ControlMappingSourcesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ControlMappingSourcesPropertyOutputReference;
    }
}
