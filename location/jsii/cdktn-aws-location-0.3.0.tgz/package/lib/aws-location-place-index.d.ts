import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsPlaceIndexConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/location_place_index#data_source AwsPlaceIndex#data_source}
    */
    readonly dataSource: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/location_place_index#description AwsPlaceIndex#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/location_place_index#id AwsPlaceIndex#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/location_place_index#index_name AwsPlaceIndex#index_name}
    */
    readonly indexName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/location_place_index#region AwsPlaceIndex#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/location_place_index#tags AwsPlaceIndex#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/location_place_index#tags_all AwsPlaceIndex#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * data_source_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/location_place_index#data_source_configuration AwsPlaceIndex#data_source_configuration}
    */
    readonly dataSourceConfiguration?: AwsPlaceIndex.DataSourceConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/location_place_index aws_location_place_index}
*/
export declare class AwsPlaceIndex extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_location_place_index";
    /**
    * Generates CDKTN code for importing a AwsPlaceIndex resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsPlaceIndex to import
    * @param importFromId The id of the existing AwsPlaceIndex that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/location_place_index#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsPlaceIndex to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/location_place_index aws_location_place_index} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsPlaceIndexConfig
    */
    constructor(scope: Construct, id: string, config: AwsPlaceIndexConfig);
    get createTime(): string;
    private _dataSource?;
    get dataSource(): string;
    set dataSource(value: string);
    get dataSourceInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get indexArn(): string;
    private _indexName?;
    get indexName(): string;
    set indexName(value: string);
    get indexNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get updateTime(): string;
    private _dataSourceConfiguration;
    get dataSourceConfiguration(): AwsPlaceIndex.DataSourceConfigurationPropertyOutputReference;
    putDataSourceConfiguration(value: AwsPlaceIndex.DataSourceConfigurationProperty): void;
    resetDataSourceConfiguration(): void;
    get dataSourceConfigurationInput(): AwsPlaceIndex.DataSourceConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsPlaceIndexDataSourceConfigurationPropertyToTerraform(struct?: AwsPlaceIndex.DataSourceConfigurationPropertyOutputReference | AwsPlaceIndex.DataSourceConfigurationProperty): any;
export declare function awsPlaceIndexDataSourceConfigurationPropertyToHclTerraform(struct?: AwsPlaceIndex.DataSourceConfigurationPropertyOutputReference | AwsPlaceIndex.DataSourceConfigurationProperty): any;
export declare namespace AwsPlaceIndex {
    interface DataSourceConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/location_place_index#intended_use AwsPlaceIndex#intended_use}
        */
        readonly intendedUse?: string;
    }
    class DataSourceConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DataSourceConfigurationProperty | undefined;
        set internalValue(value: DataSourceConfigurationProperty | undefined);
        private _intendedUse?;
        get intendedUse(): string;
        set intendedUse(value: string);
        resetIntendedUse(): void;
        get intendedUseInput(): string | undefined;
    }
}
