import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsVpcEncryptionControlConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_encryption_control#egress_only_internet_gateway_exclusion AwsVpcEncryptionControl#egress_only_internet_gateway_exclusion}
    */
    readonly egressOnlyInternetGatewayExclusion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_encryption_control#elastic_file_system_exclusion AwsVpcEncryptionControl#elastic_file_system_exclusion}
    */
    readonly elasticFileSystemExclusion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_encryption_control#internet_gateway_exclusion AwsVpcEncryptionControl#internet_gateway_exclusion}
    */
    readonly internetGatewayExclusion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_encryption_control#lambda_exclusion AwsVpcEncryptionControl#lambda_exclusion}
    */
    readonly lambdaExclusion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_encryption_control#mode AwsVpcEncryptionControl#mode}
    */
    readonly mode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_encryption_control#nat_gateway_exclusion AwsVpcEncryptionControl#nat_gateway_exclusion}
    */
    readonly natGatewayExclusion?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_encryption_control#region AwsVpcEncryptionControl#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_encryption_control#tags AwsVpcEncryptionControl#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_encryption_control#virtual_private_gateway_exclusion AwsVpcEncryptionControl#virtual_private_gateway_exclusion}
    */
    readonly virtualPrivateGatewayExclusion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_encryption_control#vpc_id AwsVpcEncryptionControl#vpc_id}
    */
    readonly vpcId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_encryption_control#vpc_lattice_exclusion AwsVpcEncryptionControl#vpc_lattice_exclusion}
    */
    readonly vpcLatticeExclusion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_encryption_control#vpc_peering_exclusion AwsVpcEncryptionControl#vpc_peering_exclusion}
    */
    readonly vpcPeeringExclusion?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_encryption_control#timeouts AwsVpcEncryptionControl#timeouts}
    */
    readonly timeouts?: AwsVpcEncryptionControl.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_encryption_control aws_vpc_encryption_control}
*/
export declare class AwsVpcEncryptionControl extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_vpc_encryption_control";
    /**
    * Generates CDKTN code for importing a AwsVpcEncryptionControl resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsVpcEncryptionControl to import
    * @param importFromId The id of the existing AwsVpcEncryptionControl that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_encryption_control#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsVpcEncryptionControl to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_encryption_control aws_vpc_encryption_control} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsVpcEncryptionControlConfig
    */
    constructor(scope: Construct, id: string, config: AwsVpcEncryptionControlConfig);
    private _egressOnlyInternetGatewayExclusion?;
    get egressOnlyInternetGatewayExclusion(): string;
    set egressOnlyInternetGatewayExclusion(value: string);
    resetEgressOnlyInternetGatewayExclusion(): void;
    get egressOnlyInternetGatewayExclusionInput(): string | undefined;
    private _elasticFileSystemExclusion?;
    get elasticFileSystemExclusion(): string;
    set elasticFileSystemExclusion(value: string);
    resetElasticFileSystemExclusion(): void;
    get elasticFileSystemExclusionInput(): string | undefined;
    get id(): string;
    private _internetGatewayExclusion?;
    get internetGatewayExclusion(): string;
    set internetGatewayExclusion(value: string);
    resetInternetGatewayExclusion(): void;
    get internetGatewayExclusionInput(): string | undefined;
    private _lambdaExclusion?;
    get lambdaExclusion(): string;
    set lambdaExclusion(value: string);
    resetLambdaExclusion(): void;
    get lambdaExclusionInput(): string | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    get modeInput(): string | undefined;
    private _natGatewayExclusion?;
    get natGatewayExclusion(): string;
    set natGatewayExclusion(value: string);
    resetNatGatewayExclusion(): void;
    get natGatewayExclusionInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourceExclusions;
    get resourceExclusions(): AwsVpcEncryptionControl.ResourceExclusionsPropertyOutputReference;
    get state(): string;
    get stateMessage(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _virtualPrivateGatewayExclusion?;
    get virtualPrivateGatewayExclusion(): string;
    set virtualPrivateGatewayExclusion(value: string);
    resetVirtualPrivateGatewayExclusion(): void;
    get virtualPrivateGatewayExclusionInput(): string | undefined;
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    get vpcIdInput(): string | undefined;
    private _vpcLatticeExclusion?;
    get vpcLatticeExclusion(): string;
    set vpcLatticeExclusion(value: string);
    resetVpcLatticeExclusion(): void;
    get vpcLatticeExclusionInput(): string | undefined;
    private _vpcPeeringExclusion?;
    get vpcPeeringExclusion(): string;
    set vpcPeeringExclusion(value: string);
    resetVpcPeeringExclusion(): void;
    get vpcPeeringExclusionInput(): string | undefined;
    private _timeouts;
    get timeouts(): AwsVpcEncryptionControl.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsVpcEncryptionControl.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsVpcEncryptionControl.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsVpcEncryptionControlEgressOnlyInternetGatewayPropertyToTerraform(struct?: AwsVpcEncryptionControl.EgressOnlyInternetGatewayProperty): any;
export declare function awsVpcEncryptionControlEgressOnlyInternetGatewayPropertyToHclTerraform(struct?: AwsVpcEncryptionControl.EgressOnlyInternetGatewayProperty): any;
export declare function awsVpcEncryptionControlElasticFileSystemPropertyToTerraform(struct?: AwsVpcEncryptionControl.ElasticFileSystemProperty): any;
export declare function awsVpcEncryptionControlElasticFileSystemPropertyToHclTerraform(struct?: AwsVpcEncryptionControl.ElasticFileSystemProperty): any;
export declare function awsVpcEncryptionControlInternetGatewayPropertyToTerraform(struct?: AwsVpcEncryptionControl.InternetGatewayProperty): any;
export declare function awsVpcEncryptionControlInternetGatewayPropertyToHclTerraform(struct?: AwsVpcEncryptionControl.InternetGatewayProperty): any;
export declare function awsVpcEncryptionControlLambdaPropertyToTerraform(struct?: AwsVpcEncryptionControl.LambdaProperty): any;
export declare function awsVpcEncryptionControlLambdaPropertyToHclTerraform(struct?: AwsVpcEncryptionControl.LambdaProperty): any;
export declare function awsVpcEncryptionControlNatGatewayPropertyToTerraform(struct?: AwsVpcEncryptionControl.NatGatewayProperty): any;
export declare function awsVpcEncryptionControlNatGatewayPropertyToHclTerraform(struct?: AwsVpcEncryptionControl.NatGatewayProperty): any;
export declare function awsVpcEncryptionControlVirtualPrivateGatewayPropertyToTerraform(struct?: AwsVpcEncryptionControl.VirtualPrivateGatewayProperty): any;
export declare function awsVpcEncryptionControlVirtualPrivateGatewayPropertyToHclTerraform(struct?: AwsVpcEncryptionControl.VirtualPrivateGatewayProperty): any;
export declare function awsVpcEncryptionControlVpcLatticePropertyToTerraform(struct?: AwsVpcEncryptionControl.VpcLatticeProperty): any;
export declare function awsVpcEncryptionControlVpcLatticePropertyToHclTerraform(struct?: AwsVpcEncryptionControl.VpcLatticeProperty): any;
export declare function awsVpcEncryptionControlVpcPeeringPropertyToTerraform(struct?: AwsVpcEncryptionControl.VpcPeeringProperty): any;
export declare function awsVpcEncryptionControlVpcPeeringPropertyToHclTerraform(struct?: AwsVpcEncryptionControl.VpcPeeringProperty): any;
export declare function awsVpcEncryptionControlResourceExclusionsPropertyToTerraform(struct?: AwsVpcEncryptionControl.ResourceExclusionsProperty): any;
export declare function awsVpcEncryptionControlResourceExclusionsPropertyToHclTerraform(struct?: AwsVpcEncryptionControl.ResourceExclusionsProperty): any;
export declare function awsVpcEncryptionControlTimeoutsPropertyToTerraform(struct?: AwsVpcEncryptionControl.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsVpcEncryptionControlTimeoutsPropertyToHclTerraform(struct?: AwsVpcEncryptionControl.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsVpcEncryptionControl {
    interface EgressOnlyInternetGatewayProperty {
    }
    class EgressOnlyInternetGatewayPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EgressOnlyInternetGatewayProperty | undefined;
        set internalValue(value: EgressOnlyInternetGatewayProperty | undefined);
        get state(): string;
        get stateMessage(): string;
    }
    interface ElasticFileSystemProperty {
    }
    class ElasticFileSystemPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ElasticFileSystemProperty | undefined;
        set internalValue(value: ElasticFileSystemProperty | undefined);
        get state(): string;
        get stateMessage(): string;
    }
    interface InternetGatewayProperty {
    }
    class InternetGatewayPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InternetGatewayProperty | undefined;
        set internalValue(value: InternetGatewayProperty | undefined);
        get state(): string;
        get stateMessage(): string;
    }
    interface LambdaProperty {
    }
    class LambdaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LambdaProperty | undefined;
        set internalValue(value: LambdaProperty | undefined);
        get state(): string;
        get stateMessage(): string;
    }
    interface NatGatewayProperty {
    }
    class NatGatewayPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NatGatewayProperty | undefined;
        set internalValue(value: NatGatewayProperty | undefined);
        get state(): string;
        get stateMessage(): string;
    }
    interface VirtualPrivateGatewayProperty {
    }
    class VirtualPrivateGatewayPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VirtualPrivateGatewayProperty | undefined;
        set internalValue(value: VirtualPrivateGatewayProperty | undefined);
        get state(): string;
        get stateMessage(): string;
    }
    interface VpcLatticeProperty {
    }
    class VpcLatticePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcLatticeProperty | undefined;
        set internalValue(value: VpcLatticeProperty | undefined);
        get state(): string;
        get stateMessage(): string;
    }
    interface VpcPeeringProperty {
    }
    class VpcPeeringPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcPeeringProperty | undefined;
        set internalValue(value: VpcPeeringProperty | undefined);
        get state(): string;
        get stateMessage(): string;
    }
    interface ResourceExclusionsProperty {
    }
    class ResourceExclusionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ResourceExclusionsProperty | undefined;
        set internalValue(value: ResourceExclusionsProperty | undefined);
        private _egressOnlyInternetGateway;
        get egressOnlyInternetGateway(): EgressOnlyInternetGatewayPropertyOutputReference;
        private _elasticFileSystem;
        get elasticFileSystem(): ElasticFileSystemPropertyOutputReference;
        private _internetGateway;
        get internetGateway(): InternetGatewayPropertyOutputReference;
        private _lambda;
        get lambda(): LambdaPropertyOutputReference;
        private _natGateway;
        get natGateway(): NatGatewayPropertyOutputReference;
        private _virtualPrivateGateway;
        get virtualPrivateGateway(): VirtualPrivateGatewayPropertyOutputReference;
        private _vpcLattice;
        get vpcLattice(): VpcLatticePropertyOutputReference;
        private _vpcPeering;
        get vpcPeering(): VpcPeeringPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_encryption_control#create AwsVpcEncryptionControl#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_encryption_control#delete AwsVpcEncryptionControl#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_encryption_control#update AwsVpcEncryptionControl#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
