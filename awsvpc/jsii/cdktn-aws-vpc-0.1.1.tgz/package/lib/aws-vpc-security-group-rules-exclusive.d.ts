import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsVpcSecurityGroupRulesExclusiveConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_security_group_rules_exclusive#egress_rule_ids AwsVpcSecurityGroupRulesExclusive#egress_rule_ids}
    */
    readonly egressRuleIds: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_security_group_rules_exclusive#ingress_rule_ids AwsVpcSecurityGroupRulesExclusive#ingress_rule_ids}
    */
    readonly ingressRuleIds: string[];
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_security_group_rules_exclusive#region AwsVpcSecurityGroupRulesExclusive#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_security_group_rules_exclusive#security_group_id AwsVpcSecurityGroupRulesExclusive#security_group_id}
    */
    readonly securityGroupId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_security_group_rules_exclusive aws_vpc_security_group_rules_exclusive}
*/
export declare class AwsVpcSecurityGroupRulesExclusive extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_vpc_security_group_rules_exclusive";
    /**
    * Generates CDKTN code for importing a AwsVpcSecurityGroupRulesExclusive resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsVpcSecurityGroupRulesExclusive to import
    * @param importFromId The id of the existing AwsVpcSecurityGroupRulesExclusive that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_security_group_rules_exclusive#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsVpcSecurityGroupRulesExclusive to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_security_group_rules_exclusive aws_vpc_security_group_rules_exclusive} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsVpcSecurityGroupRulesExclusiveConfig
    */
    constructor(scope: Construct, id: string, config: AwsVpcSecurityGroupRulesExclusiveConfig);
    private _egressRuleIds?;
    get egressRuleIds(): string[];
    set egressRuleIds(value: string[]);
    get egressRuleIdsInput(): string[] | undefined;
    private _ingressRuleIds?;
    get ingressRuleIds(): string[];
    set ingressRuleIds(value: string[]);
    get ingressRuleIdsInput(): string[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _securityGroupId?;
    get securityGroupId(): string;
    set securityGroupId(value: string);
    get securityGroupIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
