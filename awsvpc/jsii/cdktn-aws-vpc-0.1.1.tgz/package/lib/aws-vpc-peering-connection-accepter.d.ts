import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsVpcPeeringConnectionAccepterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection_accepter#auto_accept AwsVpcPeeringConnectionAccepter#auto_accept}
    */
    readonly autoAccept?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection_accepter#id AwsVpcPeeringConnectionAccepter#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection_accepter#region AwsVpcPeeringConnectionAccepter#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection_accepter#tags AwsVpcPeeringConnectionAccepter#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection_accepter#tags_all AwsVpcPeeringConnectionAccepter#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection_accepter#vpc_peering_connection_id AwsVpcPeeringConnectionAccepter#vpc_peering_connection_id}
    */
    readonly vpcPeeringConnectionId: string;
    /**
    * accepter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection_accepter#accepter AwsVpcPeeringConnectionAccepter#accepter}
    */
    readonly accepter?: AwsVpcPeeringConnectionAccepter.AccepterProperty;
    /**
    * requester block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection_accepter#requester AwsVpcPeeringConnectionAccepter#requester}
    */
    readonly requester?: AwsVpcPeeringConnectionAccepter.RequesterProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection_accepter#timeouts AwsVpcPeeringConnectionAccepter#timeouts}
    */
    readonly timeouts?: AwsVpcPeeringConnectionAccepter.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection_accepter aws_vpc_peering_connection_accepter}
*/
export declare class AwsVpcPeeringConnectionAccepter extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_vpc_peering_connection_accepter";
    /**
    * Generates CDKTN code for importing a AwsVpcPeeringConnectionAccepter resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsVpcPeeringConnectionAccepter to import
    * @param importFromId The id of the existing AwsVpcPeeringConnectionAccepter that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection_accepter#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsVpcPeeringConnectionAccepter to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection_accepter aws_vpc_peering_connection_accepter} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsVpcPeeringConnectionAccepterConfig
    */
    constructor(scope: Construct, id: string, config: AwsVpcPeeringConnectionAccepterConfig);
    get acceptStatus(): string;
    private _autoAccept?;
    get autoAccept(): boolean | cdktn.IResolvable;
    set autoAccept(value: boolean | cdktn.IResolvable);
    resetAutoAccept(): void;
    get autoAcceptInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get peerOwnerId(): string;
    get peerRegion(): string;
    get peerVpcId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get vpcId(): string;
    private _vpcPeeringConnectionId?;
    get vpcPeeringConnectionId(): string;
    set vpcPeeringConnectionId(value: string);
    get vpcPeeringConnectionIdInput(): string | undefined;
    private _accepter;
    get accepter(): AwsVpcPeeringConnectionAccepter.AccepterPropertyOutputReference;
    putAccepter(value: AwsVpcPeeringConnectionAccepter.AccepterProperty): void;
    resetAccepter(): void;
    get accepterInput(): AwsVpcPeeringConnectionAccepter.AccepterProperty | undefined;
    private _requester;
    get requester(): AwsVpcPeeringConnectionAccepter.RequesterPropertyOutputReference;
    putRequester(value: AwsVpcPeeringConnectionAccepter.RequesterProperty): void;
    resetRequester(): void;
    get requesterInput(): AwsVpcPeeringConnectionAccepter.RequesterProperty | undefined;
    private _timeouts;
    get timeouts(): AwsVpcPeeringConnectionAccepter.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsVpcPeeringConnectionAccepter.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsVpcPeeringConnectionAccepter.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsVpcPeeringConnectionAccepterAccepterPropertyToTerraform(struct?: AwsVpcPeeringConnectionAccepter.AccepterPropertyOutputReference | AwsVpcPeeringConnectionAccepter.AccepterProperty): any;
export declare function awsVpcPeeringConnectionAccepterAccepterPropertyToHclTerraform(struct?: AwsVpcPeeringConnectionAccepter.AccepterPropertyOutputReference | AwsVpcPeeringConnectionAccepter.AccepterProperty): any;
export declare function awsVpcPeeringConnectionAccepterRequesterPropertyToTerraform(struct?: AwsVpcPeeringConnectionAccepter.RequesterPropertyOutputReference | AwsVpcPeeringConnectionAccepter.RequesterProperty): any;
export declare function awsVpcPeeringConnectionAccepterRequesterPropertyToHclTerraform(struct?: AwsVpcPeeringConnectionAccepter.RequesterPropertyOutputReference | AwsVpcPeeringConnectionAccepter.RequesterProperty): any;
export declare function awsVpcPeeringConnectionAccepterTimeoutsPropertyToTerraform(struct?: AwsVpcPeeringConnectionAccepter.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsVpcPeeringConnectionAccepterTimeoutsPropertyToHclTerraform(struct?: AwsVpcPeeringConnectionAccepter.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsVpcPeeringConnectionAccepter {
    interface AccepterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection_accepter#allow_remote_vpc_dns_resolution AwsVpcPeeringConnectionAccepter#allow_remote_vpc_dns_resolution}
        */
        readonly allowRemoteVpcDnsResolution?: boolean | cdktn.IResolvable;
    }
    class AccepterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AccepterProperty | undefined;
        set internalValue(value: AccepterProperty | undefined);
        private _allowRemoteVpcDnsResolution?;
        get allowRemoteVpcDnsResolution(): boolean | cdktn.IResolvable;
        set allowRemoteVpcDnsResolution(value: boolean | cdktn.IResolvable);
        resetAllowRemoteVpcDnsResolution(): void;
        get allowRemoteVpcDnsResolutionInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface RequesterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection_accepter#allow_remote_vpc_dns_resolution AwsVpcPeeringConnectionAccepter#allow_remote_vpc_dns_resolution}
        */
        readonly allowRemoteVpcDnsResolution?: boolean | cdktn.IResolvable;
    }
    class RequesterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RequesterProperty | undefined;
        set internalValue(value: RequesterProperty | undefined);
        private _allowRemoteVpcDnsResolution?;
        get allowRemoteVpcDnsResolution(): boolean | cdktn.IResolvable;
        set allowRemoteVpcDnsResolution(value: boolean | cdktn.IResolvable);
        resetAllowRemoteVpcDnsResolution(): void;
        get allowRemoteVpcDnsResolutionInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection_accepter#create AwsVpcPeeringConnectionAccepter#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection_accepter#update AwsVpcPeeringConnectionAccepter#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
