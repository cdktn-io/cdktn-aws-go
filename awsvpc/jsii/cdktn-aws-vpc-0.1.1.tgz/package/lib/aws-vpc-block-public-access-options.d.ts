import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsVpcBlockPublicAccessOptionsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_block_public_access_options#internet_gateway_block_mode AwsVpcBlockPublicAccessOptions#internet_gateway_block_mode}
    */
    readonly internetGatewayBlockMode: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_block_public_access_options#region AwsVpcBlockPublicAccessOptions#region}
    */
    readonly region?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_block_public_access_options#timeouts AwsVpcBlockPublicAccessOptions#timeouts}
    */
    readonly timeouts?: AwsVpcBlockPublicAccessOptions.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_block_public_access_options aws_vpc_block_public_access_options}
*/
export declare class AwsVpcBlockPublicAccessOptions extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_vpc_block_public_access_options";
    /**
    * Generates CDKTN code for importing a AwsVpcBlockPublicAccessOptions resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsVpcBlockPublicAccessOptions to import
    * @param importFromId The id of the existing AwsVpcBlockPublicAccessOptions that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_block_public_access_options#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsVpcBlockPublicAccessOptions to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_block_public_access_options aws_vpc_block_public_access_options} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsVpcBlockPublicAccessOptionsConfig
    */
    constructor(scope: Construct, id: string, config: AwsVpcBlockPublicAccessOptionsConfig);
    get awsAccountId(): string;
    get awsRegion(): string;
    get id(): string;
    private _internetGatewayBlockMode?;
    get internetGatewayBlockMode(): string;
    set internetGatewayBlockMode(value: string);
    get internetGatewayBlockModeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _timeouts;
    get timeouts(): AwsVpcBlockPublicAccessOptions.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsVpcBlockPublicAccessOptions.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsVpcBlockPublicAccessOptions.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsVpcBlockPublicAccessOptionsTimeoutsPropertyToTerraform(struct?: AwsVpcBlockPublicAccessOptions.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsVpcBlockPublicAccessOptionsTimeoutsPropertyToHclTerraform(struct?: AwsVpcBlockPublicAccessOptions.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsVpcBlockPublicAccessOptions {
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_block_public_access_options#create AwsVpcBlockPublicAccessOptions#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_block_public_access_options#delete AwsVpcBlockPublicAccessOptions#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_block_public_access_options#update AwsVpcBlockPublicAccessOptions#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
