import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsVpcEndpointConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint#auto_accept AwsVpcEndpoint#auto_accept}
    */
    readonly autoAccept?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint#id AwsVpcEndpoint#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint#ip_address_type AwsVpcEndpoint#ip_address_type}
    */
    readonly ipAddressType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint#policy AwsVpcEndpoint#policy}
    */
    readonly policy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint#private_dns_enabled AwsVpcEndpoint#private_dns_enabled}
    */
    readonly privateDnsEnabled?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint#region AwsVpcEndpoint#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint#resource_configuration_arn AwsVpcEndpoint#resource_configuration_arn}
    */
    readonly resourceConfigurationArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint#route_table_ids AwsVpcEndpoint#route_table_ids}
    */
    readonly routeTableIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint#security_group_ids AwsVpcEndpoint#security_group_ids}
    */
    readonly securityGroupIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint#service_name AwsVpcEndpoint#service_name}
    */
    readonly serviceName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint#service_network_arn AwsVpcEndpoint#service_network_arn}
    */
    readonly serviceNetworkArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint#service_region AwsVpcEndpoint#service_region}
    */
    readonly serviceRegion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint#subnet_ids AwsVpcEndpoint#subnet_ids}
    */
    readonly subnetIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint#tags AwsVpcEndpoint#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint#tags_all AwsVpcEndpoint#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint#vpc_endpoint_type AwsVpcEndpoint#vpc_endpoint_type}
    */
    readonly vpcEndpointType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint#vpc_id AwsVpcEndpoint#vpc_id}
    */
    readonly vpcId: string;
    /**
    * dns_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint#dns_options AwsVpcEndpoint#dns_options}
    */
    readonly dnsOptions?: AwsVpcEndpoint.DnsOptionsProperty;
    /**
    * subnet_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint#subnet_configuration AwsVpcEndpoint#subnet_configuration}
    */
    readonly subnetConfiguration?: AwsVpcEndpoint.SubnetConfigurationProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint#timeouts AwsVpcEndpoint#timeouts}
    */
    readonly timeouts?: AwsVpcEndpoint.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint aws_vpc_endpoint}
*/
export declare class AwsVpcEndpoint extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_vpc_endpoint";
    /**
    * Generates CDKTN code for importing a AwsVpcEndpoint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsVpcEndpoint to import
    * @param importFromId The id of the existing AwsVpcEndpoint that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsVpcEndpoint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint aws_vpc_endpoint} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsVpcEndpointConfig
    */
    constructor(scope: Construct, id: string, config: AwsVpcEndpointConfig);
    get arn(): string;
    private _autoAccept?;
    get autoAccept(): boolean | cdktn.IResolvable;
    set autoAccept(value: boolean | cdktn.IResolvable);
    resetAutoAccept(): void;
    get autoAcceptInput(): boolean | cdktn.IResolvable | undefined;
    get cidrBlocks(): string[];
    private _dnsEntry;
    get dnsEntry(): AwsVpcEndpoint.DnsEntryPropertyList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipAddressType?;
    get ipAddressType(): string;
    set ipAddressType(value: string);
    resetIpAddressType(): void;
    get ipAddressTypeInput(): string | undefined;
    get networkInterfaceIds(): string[];
    get ownerId(): string;
    private _policy?;
    get policy(): string;
    set policy(value: string);
    resetPolicy(): void;
    get policyInput(): string | undefined;
    get prefixListId(): string;
    private _privateDnsEnabled?;
    get privateDnsEnabled(): boolean | cdktn.IResolvable;
    set privateDnsEnabled(value: boolean | cdktn.IResolvable);
    resetPrivateDnsEnabled(): void;
    get privateDnsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get requesterManaged(): cdktn.IResolvable;
    private _resourceConfigurationArn?;
    get resourceConfigurationArn(): string;
    set resourceConfigurationArn(value: string);
    resetResourceConfigurationArn(): void;
    get resourceConfigurationArnInput(): string | undefined;
    private _routeTableIds?;
    get routeTableIds(): string[];
    set routeTableIds(value: string[]);
    resetRouteTableIds(): void;
    get routeTableIdsInput(): string[] | undefined;
    private _securityGroupIds?;
    get securityGroupIds(): string[];
    set securityGroupIds(value: string[]);
    resetSecurityGroupIds(): void;
    get securityGroupIdsInput(): string[] | undefined;
    private _serviceName?;
    get serviceName(): string;
    set serviceName(value: string);
    resetServiceName(): void;
    get serviceNameInput(): string | undefined;
    private _serviceNetworkArn?;
    get serviceNetworkArn(): string;
    set serviceNetworkArn(value: string);
    resetServiceNetworkArn(): void;
    get serviceNetworkArnInput(): string | undefined;
    private _serviceRegion?;
    get serviceRegion(): string;
    set serviceRegion(value: string);
    resetServiceRegion(): void;
    get serviceRegionInput(): string | undefined;
    get state(): string;
    private _subnetIds?;
    get subnetIds(): string[];
    set subnetIds(value: string[]);
    resetSubnetIds(): void;
    get subnetIdsInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _vpcEndpointType?;
    get vpcEndpointType(): string;
    set vpcEndpointType(value: string);
    resetVpcEndpointType(): void;
    get vpcEndpointTypeInput(): string | undefined;
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    get vpcIdInput(): string | undefined;
    private _dnsOptions;
    get dnsOptions(): AwsVpcEndpoint.DnsOptionsPropertyOutputReference;
    putDnsOptions(value: AwsVpcEndpoint.DnsOptionsProperty): void;
    resetDnsOptions(): void;
    get dnsOptionsInput(): AwsVpcEndpoint.DnsOptionsProperty | undefined;
    private _subnetConfiguration;
    get subnetConfiguration(): AwsVpcEndpoint.SubnetConfigurationPropertyList;
    putSubnetConfiguration(value: AwsVpcEndpoint.SubnetConfigurationProperty[] | cdktn.IResolvable): void;
    resetSubnetConfiguration(): void;
    get subnetConfigurationInput(): cdktn.IResolvable | AwsVpcEndpoint.SubnetConfigurationProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsVpcEndpoint.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsVpcEndpoint.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsVpcEndpoint.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsVpcEndpointDnsEntryPropertyToTerraform(struct?: AwsVpcEndpoint.DnsEntryProperty): any;
export declare function awsVpcEndpointDnsEntryPropertyToHclTerraform(struct?: AwsVpcEndpoint.DnsEntryProperty): any;
export declare function awsVpcEndpointDnsOptionsPropertyToTerraform(struct?: AwsVpcEndpoint.DnsOptionsPropertyOutputReference | AwsVpcEndpoint.DnsOptionsProperty): any;
export declare function awsVpcEndpointDnsOptionsPropertyToHclTerraform(struct?: AwsVpcEndpoint.DnsOptionsPropertyOutputReference | AwsVpcEndpoint.DnsOptionsProperty): any;
export declare function awsVpcEndpointSubnetConfigurationPropertyToTerraform(struct?: AwsVpcEndpoint.SubnetConfigurationProperty | cdktn.IResolvable): any;
export declare function awsVpcEndpointSubnetConfigurationPropertyToHclTerraform(struct?: AwsVpcEndpoint.SubnetConfigurationProperty | cdktn.IResolvable): any;
export declare function awsVpcEndpointTimeoutsPropertyToTerraform(struct?: AwsVpcEndpoint.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsVpcEndpointTimeoutsPropertyToHclTerraform(struct?: AwsVpcEndpoint.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsVpcEndpoint {
    interface DnsEntryProperty {
    }
    class DnsEntryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DnsEntryProperty | undefined;
        set internalValue(value: DnsEntryProperty | undefined);
        get dnsName(): string;
        get hostedZoneId(): string;
    }
    class DnsEntryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DnsEntryPropertyOutputReference;
    }
    interface DnsOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint#dns_record_ip_type AwsVpcEndpoint#dns_record_ip_type}
        */
        readonly dnsRecordIpType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint#private_dns_only_for_inbound_resolver_endpoint AwsVpcEndpoint#private_dns_only_for_inbound_resolver_endpoint}
        */
        readonly privateDnsOnlyForInboundResolverEndpoint?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint#private_dns_preference AwsVpcEndpoint#private_dns_preference}
        */
        readonly privateDnsPreference?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint#private_dns_specified_domains AwsVpcEndpoint#private_dns_specified_domains}
        */
        readonly privateDnsSpecifiedDomains?: string[];
    }
    class DnsOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DnsOptionsProperty | undefined;
        set internalValue(value: DnsOptionsProperty | undefined);
        private _dnsRecordIpType?;
        get dnsRecordIpType(): string;
        set dnsRecordIpType(value: string);
        resetDnsRecordIpType(): void;
        get dnsRecordIpTypeInput(): string | undefined;
        private _privateDnsOnlyForInboundResolverEndpoint?;
        get privateDnsOnlyForInboundResolverEndpoint(): boolean | cdktn.IResolvable;
        set privateDnsOnlyForInboundResolverEndpoint(value: boolean | cdktn.IResolvable);
        resetPrivateDnsOnlyForInboundResolverEndpoint(): void;
        get privateDnsOnlyForInboundResolverEndpointInput(): boolean | cdktn.IResolvable | undefined;
        private _privateDnsPreference?;
        get privateDnsPreference(): string;
        set privateDnsPreference(value: string);
        resetPrivateDnsPreference(): void;
        get privateDnsPreferenceInput(): string | undefined;
        private _privateDnsSpecifiedDomains?;
        get privateDnsSpecifiedDomains(): string[];
        set privateDnsSpecifiedDomains(value: string[]);
        resetPrivateDnsSpecifiedDomains(): void;
        get privateDnsSpecifiedDomainsInput(): string[] | undefined;
    }
    interface SubnetConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint#ipv4 AwsVpcEndpoint#ipv4}
        */
        readonly ipv4?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint#ipv6 AwsVpcEndpoint#ipv6}
        */
        readonly ipv6?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint#subnet_id AwsVpcEndpoint#subnet_id}
        */
        readonly subnetId?: string;
    }
    class SubnetConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SubnetConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SubnetConfigurationProperty | cdktn.IResolvable | undefined);
        private _ipv4?;
        get ipv4(): string;
        set ipv4(value: string);
        resetIpv4(): void;
        get ipv4Input(): string | undefined;
        private _ipv6?;
        get ipv6(): string;
        set ipv6(value: string);
        resetIpv6(): void;
        get ipv6Input(): string | undefined;
        private _subnetId?;
        get subnetId(): string;
        set subnetId(value: string);
        resetSubnetId(): void;
        get subnetIdInput(): string | undefined;
    }
    class SubnetConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: SubnetConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SubnetConfigurationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint#create AwsVpcEndpoint#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint#delete AwsVpcEndpoint#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint#update AwsVpcEndpoint#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
