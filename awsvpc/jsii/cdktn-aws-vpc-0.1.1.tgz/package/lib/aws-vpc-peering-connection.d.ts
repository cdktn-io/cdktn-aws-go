import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsVpcPeeringConnectionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection#auto_accept AwsVpcPeeringConnection#auto_accept}
    */
    readonly autoAccept?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection#id AwsVpcPeeringConnection#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection#peer_owner_id AwsVpcPeeringConnection#peer_owner_id}
    */
    readonly peerOwnerId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection#peer_region AwsVpcPeeringConnection#peer_region}
    */
    readonly peerRegion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection#peer_vpc_id AwsVpcPeeringConnection#peer_vpc_id}
    */
    readonly peerVpcId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection#region AwsVpcPeeringConnection#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection#tags AwsVpcPeeringConnection#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection#tags_all AwsVpcPeeringConnection#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection#vpc_id AwsVpcPeeringConnection#vpc_id}
    */
    readonly vpcId: string;
    /**
    * accepter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection#accepter AwsVpcPeeringConnection#accepter}
    */
    readonly accepter?: AwsVpcPeeringConnection.AccepterProperty;
    /**
    * requester block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection#requester AwsVpcPeeringConnection#requester}
    */
    readonly requester?: AwsVpcPeeringConnection.RequesterProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection#timeouts AwsVpcPeeringConnection#timeouts}
    */
    readonly timeouts?: AwsVpcPeeringConnection.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection aws_vpc_peering_connection}
*/
export declare class AwsVpcPeeringConnection extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_vpc_peering_connection";
    /**
    * Generates CDKTN code for importing a AwsVpcPeeringConnection resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsVpcPeeringConnection to import
    * @param importFromId The id of the existing AwsVpcPeeringConnection that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsVpcPeeringConnection to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection aws_vpc_peering_connection} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsVpcPeeringConnectionConfig
    */
    constructor(scope: Construct, id: string, config: AwsVpcPeeringConnectionConfig);
    get acceptStatus(): string;
    private _autoAccept?;
    get autoAccept(): boolean | cdktn.IResolvable;
    set autoAccept(value: boolean | cdktn.IResolvable);
    resetAutoAccept(): void;
    get autoAcceptInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _peerOwnerId?;
    get peerOwnerId(): string;
    set peerOwnerId(value: string);
    resetPeerOwnerId(): void;
    get peerOwnerIdInput(): string | undefined;
    private _peerRegion?;
    get peerRegion(): string;
    set peerRegion(value: string);
    resetPeerRegion(): void;
    get peerRegionInput(): string | undefined;
    private _peerVpcId?;
    get peerVpcId(): string;
    set peerVpcId(value: string);
    get peerVpcIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    get vpcIdInput(): string | undefined;
    private _accepter;
    get accepter(): AwsVpcPeeringConnection.AccepterPropertyOutputReference;
    putAccepter(value: AwsVpcPeeringConnection.AccepterProperty): void;
    resetAccepter(): void;
    get accepterInput(): AwsVpcPeeringConnection.AccepterProperty | undefined;
    private _requester;
    get requester(): AwsVpcPeeringConnection.RequesterPropertyOutputReference;
    putRequester(value: AwsVpcPeeringConnection.RequesterProperty): void;
    resetRequester(): void;
    get requesterInput(): AwsVpcPeeringConnection.RequesterProperty | undefined;
    private _timeouts;
    get timeouts(): AwsVpcPeeringConnection.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsVpcPeeringConnection.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsVpcPeeringConnection.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsVpcPeeringConnectionAccepterPropertyToTerraform(struct?: AwsVpcPeeringConnection.AccepterPropertyOutputReference | AwsVpcPeeringConnection.AccepterProperty): any;
export declare function awsVpcPeeringConnectionAccepterPropertyToHclTerraform(struct?: AwsVpcPeeringConnection.AccepterPropertyOutputReference | AwsVpcPeeringConnection.AccepterProperty): any;
export declare function awsVpcPeeringConnectionRequesterPropertyToTerraform(struct?: AwsVpcPeeringConnection.RequesterPropertyOutputReference | AwsVpcPeeringConnection.RequesterProperty): any;
export declare function awsVpcPeeringConnectionRequesterPropertyToHclTerraform(struct?: AwsVpcPeeringConnection.RequesterPropertyOutputReference | AwsVpcPeeringConnection.RequesterProperty): any;
export declare function awsVpcPeeringConnectionTimeoutsPropertyToTerraform(struct?: AwsVpcPeeringConnection.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsVpcPeeringConnectionTimeoutsPropertyToHclTerraform(struct?: AwsVpcPeeringConnection.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsVpcPeeringConnection {
    interface AccepterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection#allow_remote_vpc_dns_resolution AwsVpcPeeringConnection#allow_remote_vpc_dns_resolution}
        */
        readonly allowRemoteVpcDnsResolution?: boolean | cdktn.IResolvable;
    }
    class AccepterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AccepterProperty | undefined;
        set internalValue(value: AccepterProperty | undefined);
        private _allowRemoteVpcDnsResolution?;
        get allowRemoteVpcDnsResolution(): boolean | cdktn.IResolvable;
        set allowRemoteVpcDnsResolution(value: boolean | cdktn.IResolvable);
        resetAllowRemoteVpcDnsResolution(): void;
        get allowRemoteVpcDnsResolutionInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface RequesterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection#allow_remote_vpc_dns_resolution AwsVpcPeeringConnection#allow_remote_vpc_dns_resolution}
        */
        readonly allowRemoteVpcDnsResolution?: boolean | cdktn.IResolvable;
    }
    class RequesterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RequesterProperty | undefined;
        set internalValue(value: RequesterProperty | undefined);
        private _allowRemoteVpcDnsResolution?;
        get allowRemoteVpcDnsResolution(): boolean | cdktn.IResolvable;
        set allowRemoteVpcDnsResolution(value: boolean | cdktn.IResolvable);
        resetAllowRemoteVpcDnsResolution(): void;
        get allowRemoteVpcDnsResolutionInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection#create AwsVpcPeeringConnection#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection#delete AwsVpcPeeringConnection#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection#update AwsVpcPeeringConnection#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
