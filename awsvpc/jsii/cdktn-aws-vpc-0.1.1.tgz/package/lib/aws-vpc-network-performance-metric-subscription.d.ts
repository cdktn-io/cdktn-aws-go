import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsVpcNetworkPerformanceMetricSubscriptionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_network_performance_metric_subscription#destination AwsVpcNetworkPerformanceMetricSubscription#destination}
    */
    readonly destination: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_network_performance_metric_subscription#id AwsVpcNetworkPerformanceMetricSubscription#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_network_performance_metric_subscription#metric AwsVpcNetworkPerformanceMetricSubscription#metric}
    */
    readonly metric?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_network_performance_metric_subscription#region AwsVpcNetworkPerformanceMetricSubscription#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_network_performance_metric_subscription#source AwsVpcNetworkPerformanceMetricSubscription#source}
    */
    readonly source: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_network_performance_metric_subscription#statistic AwsVpcNetworkPerformanceMetricSubscription#statistic}
    */
    readonly statistic?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_network_performance_metric_subscription aws_vpc_network_performance_metric_subscription}
*/
export declare class AwsVpcNetworkPerformanceMetricSubscription extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_vpc_network_performance_metric_subscription";
    /**
    * Generates CDKTN code for importing a AwsVpcNetworkPerformanceMetricSubscription resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsVpcNetworkPerformanceMetricSubscription to import
    * @param importFromId The id of the existing AwsVpcNetworkPerformanceMetricSubscription that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_network_performance_metric_subscription#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsVpcNetworkPerformanceMetricSubscription to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_network_performance_metric_subscription aws_vpc_network_performance_metric_subscription} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsVpcNetworkPerformanceMetricSubscriptionConfig
    */
    constructor(scope: Construct, id: string, config: AwsVpcNetworkPerformanceMetricSubscriptionConfig);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metric?;
    get metric(): string;
    set metric(value: string);
    resetMetric(): void;
    get metricInput(): string | undefined;
    get period(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
    private _statistic?;
    get statistic(): string;
    set statistic(value: string);
    resetStatistic(): void;
    get statisticInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
