import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsVpcEndpointPrivateDnsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint_private_dns#private_dns_enabled AwsVpcEndpointPrivateDns#private_dns_enabled}
    */
    readonly privateDnsEnabled: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint_private_dns#region AwsVpcEndpointPrivateDns#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint_private_dns#vpc_endpoint_id AwsVpcEndpointPrivateDns#vpc_endpoint_id}
    */
    readonly vpcEndpointId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint_private_dns aws_vpc_endpoint_private_dns}
*/
export declare class AwsVpcEndpointPrivateDns extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_vpc_endpoint_private_dns";
    /**
    * Generates CDKTN code for importing a AwsVpcEndpointPrivateDns resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsVpcEndpointPrivateDns to import
    * @param importFromId The id of the existing AwsVpcEndpointPrivateDns that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint_private_dns#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsVpcEndpointPrivateDns to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint_private_dns aws_vpc_endpoint_private_dns} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsVpcEndpointPrivateDnsConfig
    */
    constructor(scope: Construct, id: string, config: AwsVpcEndpointPrivateDnsConfig);
    private _privateDnsEnabled?;
    get privateDnsEnabled(): boolean | cdktn.IResolvable;
    set privateDnsEnabled(value: boolean | cdktn.IResolvable);
    get privateDnsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _vpcEndpointId?;
    get vpcEndpointId(): string;
    set vpcEndpointId(value: string);
    get vpcEndpointIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
