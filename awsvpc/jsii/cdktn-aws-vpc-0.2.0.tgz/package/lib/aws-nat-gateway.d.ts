import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfNatGatewayConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/nat_gateway#allocation_id TfNatGateway#allocation_id}
    */
    readonly allocationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/nat_gateway#availability_mode TfNatGateway#availability_mode}
    */
    readonly availabilityMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/nat_gateway#connectivity_type TfNatGateway#connectivity_type}
    */
    readonly connectivityType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/nat_gateway#id TfNatGateway#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/nat_gateway#private_ip TfNatGateway#private_ip}
    */
    readonly privateIp?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/nat_gateway#region TfNatGateway#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/nat_gateway#secondary_allocation_ids TfNatGateway#secondary_allocation_ids}
    */
    readonly secondaryAllocationIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/nat_gateway#secondary_private_ip_address_count TfNatGateway#secondary_private_ip_address_count}
    */
    readonly secondaryPrivateIpAddressCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/nat_gateway#secondary_private_ip_addresses TfNatGateway#secondary_private_ip_addresses}
    */
    readonly secondaryPrivateIpAddresses?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/nat_gateway#subnet_id TfNatGateway#subnet_id}
    */
    readonly subnetId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/nat_gateway#tags TfNatGateway#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/nat_gateway#tags_all TfNatGateway#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/nat_gateway#vpc_id TfNatGateway#vpc_id}
    */
    readonly vpcId?: string;
    /**
    * availability_zone_address block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/nat_gateway#availability_zone_address TfNatGateway#availability_zone_address}
    */
    readonly availabilityZoneAddress?: TfNatGateway.AvailabilityZoneAddressProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/nat_gateway#timeouts TfNatGateway#timeouts}
    */
    readonly timeouts?: TfNatGateway.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/nat_gateway aws_nat_gateway}
*/
export declare class TfNatGateway extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_nat_gateway";
    /**
    * Generates CDKTN code for importing a TfNatGateway resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfNatGateway to import
    * @param importFromId The id of the existing TfNatGateway that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/nat_gateway#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfNatGateway to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/nat_gateway aws_nat_gateway} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfNatGatewayConfig = {}
    */
    constructor(scope: Construct, id: string, config?: TfNatGatewayConfig);
    private _allocationId?;
    get allocationId(): string;
    set allocationId(value: string);
    resetAllocationId(): void;
    get allocationIdInput(): string | undefined;
    get associationId(): string;
    get autoProvisionZones(): string;
    get autoScalingIps(): string;
    private _availabilityMode?;
    get availabilityMode(): string;
    set availabilityMode(value: string);
    resetAvailabilityMode(): void;
    get availabilityModeInput(): string | undefined;
    private _connectivityType?;
    get connectivityType(): string;
    set connectivityType(value: string);
    resetConnectivityType(): void;
    get connectivityTypeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get networkInterfaceId(): string;
    private _privateIp?;
    get privateIp(): string;
    set privateIp(value: string);
    resetPrivateIp(): void;
    get privateIpInput(): string | undefined;
    get publicIp(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _regionalNatGatewayAddress;
    get regionalNatGatewayAddress(): TfNatGateway.RegionalNatGatewayAddressPropertyList;
    get regionalNatGatewayAutoMode(): string;
    get routeTableId(): string;
    private _secondaryAllocationIds?;
    get secondaryAllocationIds(): string[];
    set secondaryAllocationIds(value: string[]);
    resetSecondaryAllocationIds(): void;
    get secondaryAllocationIdsInput(): string[] | undefined;
    private _secondaryPrivateIpAddressCount?;
    get secondaryPrivateIpAddressCount(): number;
    set secondaryPrivateIpAddressCount(value: number);
    resetSecondaryPrivateIpAddressCount(): void;
    get secondaryPrivateIpAddressCountInput(): number | undefined;
    private _secondaryPrivateIpAddresses?;
    get secondaryPrivateIpAddresses(): string[];
    set secondaryPrivateIpAddresses(value: string[]);
    resetSecondaryPrivateIpAddresses(): void;
    get secondaryPrivateIpAddressesInput(): string[] | undefined;
    private _subnetId?;
    get subnetId(): string;
    set subnetId(value: string);
    resetSubnetId(): void;
    get subnetIdInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    resetVpcId(): void;
    get vpcIdInput(): string | undefined;
    private _availabilityZoneAddress;
    get availabilityZoneAddress(): TfNatGateway.AvailabilityZoneAddressPropertyList;
    putAvailabilityZoneAddress(value: TfNatGateway.AvailabilityZoneAddressProperty[] | cdktn.IResolvable): void;
    resetAvailabilityZoneAddress(): void;
    get availabilityZoneAddressInput(): cdktn.IResolvable | TfNatGateway.AvailabilityZoneAddressProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfNatGateway.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfNatGateway.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfNatGateway.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfNatGatewayRegionalNatGatewayAddressPropertyToTerraform(struct?: TfNatGateway.RegionalNatGatewayAddressProperty): any;
export declare function tfNatGatewayRegionalNatGatewayAddressPropertyToHclTerraform(struct?: TfNatGateway.RegionalNatGatewayAddressProperty): any;
export declare function tfNatGatewayAvailabilityZoneAddressPropertyToTerraform(struct?: TfNatGateway.AvailabilityZoneAddressProperty | cdktn.IResolvable): any;
export declare function tfNatGatewayAvailabilityZoneAddressPropertyToHclTerraform(struct?: TfNatGateway.AvailabilityZoneAddressProperty | cdktn.IResolvable): any;
export declare function tfNatGatewayTimeoutsPropertyToTerraform(struct?: TfNatGateway.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfNatGatewayTimeoutsPropertyToHclTerraform(struct?: TfNatGateway.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfNatGateway {
    interface RegionalNatGatewayAddressProperty {
    }
    class RegionalNatGatewayAddressPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RegionalNatGatewayAddressProperty | undefined;
        set internalValue(value: RegionalNatGatewayAddressProperty | undefined);
        get allocationId(): string;
        get associationId(): string;
        get availabilityZone(): string;
        get availabilityZoneId(): string;
        get networkInterfaceId(): string;
        get publicIp(): string;
        get status(): string;
    }
    class RegionalNatGatewayAddressPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RegionalNatGatewayAddressPropertyOutputReference;
    }
    interface AvailabilityZoneAddressProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/nat_gateway#allocation_ids TfNatGateway#allocation_ids}
        */
        readonly allocationIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/nat_gateway#availability_zone TfNatGateway#availability_zone}
        */
        readonly availabilityZone?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/nat_gateway#availability_zone_id TfNatGateway#availability_zone_id}
        */
        readonly availabilityZoneId?: string;
    }
    class AvailabilityZoneAddressPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AvailabilityZoneAddressProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AvailabilityZoneAddressProperty | cdktn.IResolvable | undefined);
        private _allocationIds?;
        get allocationIds(): string[];
        set allocationIds(value: string[]);
        resetAllocationIds(): void;
        get allocationIdsInput(): string[] | undefined;
        private _availabilityZone?;
        get availabilityZone(): string;
        set availabilityZone(value: string);
        resetAvailabilityZone(): void;
        get availabilityZoneInput(): string | undefined;
        private _availabilityZoneId?;
        get availabilityZoneId(): string;
        set availabilityZoneId(value: string);
        resetAvailabilityZoneId(): void;
        get availabilityZoneIdInput(): string | undefined;
    }
    class AvailabilityZoneAddressPropertyList extends cdktn.ComplexList {
        internalValue?: AvailabilityZoneAddressProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AvailabilityZoneAddressPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/nat_gateway#create TfNatGateway#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/nat_gateway#delete TfNatGateway#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/nat_gateway#update TfNatGateway#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
