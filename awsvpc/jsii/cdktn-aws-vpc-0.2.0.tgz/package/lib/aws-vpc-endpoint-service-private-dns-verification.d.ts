import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfEndpointServicePrivateDnsVerificationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint_service_private_dns_verification#region TfEndpointServicePrivateDnsVerification#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint_service_private_dns_verification#service_id TfEndpointServicePrivateDnsVerification#service_id}
    */
    readonly serviceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint_service_private_dns_verification#wait_for_verification TfEndpointServicePrivateDnsVerification#wait_for_verification}
    */
    readonly waitForVerification?: boolean | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint_service_private_dns_verification#timeouts TfEndpointServicePrivateDnsVerification#timeouts}
    */
    readonly timeouts?: TfEndpointServicePrivateDnsVerification.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint_service_private_dns_verification aws_vpc_endpoint_service_private_dns_verification}
*/
export declare class TfEndpointServicePrivateDnsVerification extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_vpc_endpoint_service_private_dns_verification";
    /**
    * Generates CDKTN code for importing a TfEndpointServicePrivateDnsVerification resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfEndpointServicePrivateDnsVerification to import
    * @param importFromId The id of the existing TfEndpointServicePrivateDnsVerification that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint_service_private_dns_verification#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfEndpointServicePrivateDnsVerification to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint_service_private_dns_verification aws_vpc_endpoint_service_private_dns_verification} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfEndpointServicePrivateDnsVerificationConfig
    */
    constructor(scope: Construct, id: string, config: TfEndpointServicePrivateDnsVerificationConfig);
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _serviceId?;
    get serviceId(): string;
    set serviceId(value: string);
    get serviceIdInput(): string | undefined;
    private _waitForVerification?;
    get waitForVerification(): boolean | cdktn.IResolvable;
    set waitForVerification(value: boolean | cdktn.IResolvable);
    resetWaitForVerification(): void;
    get waitForVerificationInput(): boolean | cdktn.IResolvable | undefined;
    private _timeouts;
    get timeouts(): TfEndpointServicePrivateDnsVerification.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfEndpointServicePrivateDnsVerification.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfEndpointServicePrivateDnsVerification.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfEndpointServicePrivateDnsVerificationTimeoutsPropertyToTerraform(struct?: TfEndpointServicePrivateDnsVerification.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfEndpointServicePrivateDnsVerificationTimeoutsPropertyToHclTerraform(struct?: TfEndpointServicePrivateDnsVerification.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfEndpointServicePrivateDnsVerification {
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_endpoint_service_private_dns_verification#create TfEndpointServicePrivateDnsVerification#create}
        */
        readonly create?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
    }
}
