import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfEndpointAssociationsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc_endpoint_associations#region DataTfEndpointAssociations#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc_endpoint_associations#vpc_endpoint_id DataTfEndpointAssociations#vpc_endpoint_id}
    */
    readonly vpcEndpointId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc_endpoint_associations aws_vpc_endpoint_associations}
*/
export declare class DataTfEndpointAssociations extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_vpc_endpoint_associations";
    /**
    * Generates CDKTN code for importing a DataTfEndpointAssociations resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfEndpointAssociations to import
    * @param importFromId The id of the existing DataTfEndpointAssociations that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc_endpoint_associations#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfEndpointAssociations to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc_endpoint_associations aws_vpc_endpoint_associations} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfEndpointAssociationsConfig
    */
    constructor(scope: Construct, id: string, config: DataTfEndpointAssociationsConfig);
    private _associations;
    get associations(): DataTfEndpointAssociations.AssociationsPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _vpcEndpointId?;
    get vpcEndpointId(): string;
    set vpcEndpointId(value: string);
    get vpcEndpointIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfEndpointAssociationsDnsEntryPropertyToTerraform(struct?: DataTfEndpointAssociations.DnsEntryProperty): any;
export declare function dataTfEndpointAssociationsDnsEntryPropertyToHclTerraform(struct?: DataTfEndpointAssociations.DnsEntryProperty): any;
export declare function dataTfEndpointAssociationsPrivateDnsEntryPropertyToTerraform(struct?: DataTfEndpointAssociations.PrivateDnsEntryProperty): any;
export declare function dataTfEndpointAssociationsPrivateDnsEntryPropertyToHclTerraform(struct?: DataTfEndpointAssociations.PrivateDnsEntryProperty): any;
export declare function dataTfEndpointAssociationsAssociationsPropertyToTerraform(struct?: DataTfEndpointAssociations.AssociationsProperty): any;
export declare function dataTfEndpointAssociationsAssociationsPropertyToHclTerraform(struct?: DataTfEndpointAssociations.AssociationsProperty): any;
export declare namespace DataTfEndpointAssociations {
    interface DnsEntryProperty {
    }
    class DnsEntryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DnsEntryProperty | undefined;
        set internalValue(value: DnsEntryProperty | undefined);
        get dnsName(): string;
        get hostedZoneId(): string;
    }
    class DnsEntryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DnsEntryPropertyOutputReference;
    }
    interface PrivateDnsEntryProperty {
    }
    class PrivateDnsEntryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PrivateDnsEntryProperty | undefined;
        set internalValue(value: PrivateDnsEntryProperty | undefined);
        get dnsName(): string;
        get hostedZoneId(): string;
    }
    class PrivateDnsEntryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PrivateDnsEntryPropertyOutputReference;
    }
    interface AssociationsProperty {
    }
    class AssociationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AssociationsProperty | undefined;
        set internalValue(value: AssociationsProperty | undefined);
        get associatedResourceAccessibility(): string;
        get associatedResourceArn(): string;
        private _dnsEntry;
        get dnsEntry(): DnsEntryPropertyList;
        get id(): string;
        private _privateDnsEntry;
        get privateDnsEntry(): PrivateDnsEntryPropertyList;
        get resourceConfigurationGroupArn(): string;
        get serviceNetworkArn(): string;
        get serviceNetworkName(): string;
        private _tags;
        get tags(): cdktn.StringMap;
    }
    class AssociationsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AssociationsPropertyOutputReference;
    }
}
