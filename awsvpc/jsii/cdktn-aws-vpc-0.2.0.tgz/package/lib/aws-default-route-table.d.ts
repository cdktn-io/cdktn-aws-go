import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfDefaultRouteTableConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_route_table#default_route_table_id TfDefaultRouteTable#default_route_table_id}
    */
    readonly defaultRouteTableId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_route_table#id TfDefaultRouteTable#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_route_table#propagating_vgws TfDefaultRouteTable#propagating_vgws}
    */
    readonly propagatingVgws?: string[];
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_route_table#region TfDefaultRouteTable#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_route_table#route TfDefaultRouteTable#route}
    */
    readonly route?: TfDefaultRouteTable.RouteProperty[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_route_table#tags TfDefaultRouteTable#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_route_table#tags_all TfDefaultRouteTable#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_route_table#timeouts TfDefaultRouteTable#timeouts}
    */
    readonly timeouts?: TfDefaultRouteTable.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_route_table aws_default_route_table}
*/
export declare class TfDefaultRouteTable extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_default_route_table";
    /**
    * Generates CDKTN code for importing a TfDefaultRouteTable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfDefaultRouteTable to import
    * @param importFromId The id of the existing TfDefaultRouteTable that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_route_table#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfDefaultRouteTable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_route_table aws_default_route_table} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfDefaultRouteTableConfig
    */
    constructor(scope: Construct, id: string, config: TfDefaultRouteTableConfig);
    get arn(): string;
    private _defaultRouteTableId?;
    get defaultRouteTableId(): string;
    set defaultRouteTableId(value: string);
    get defaultRouteTableIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ownerId(): string;
    private _propagatingVgws?;
    get propagatingVgws(): string[];
    set propagatingVgws(value: string[]);
    resetPropagatingVgws(): void;
    get propagatingVgwsInput(): string[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _route;
    get route(): TfDefaultRouteTable.RoutePropertyList;
    putRoute(value: TfDefaultRouteTable.RouteProperty[] | cdktn.IResolvable): void;
    resetRoute(): void;
    get routeInput(): cdktn.IResolvable | TfDefaultRouteTable.RouteProperty[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get vpcId(): string;
    private _timeouts;
    get timeouts(): TfDefaultRouteTable.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfDefaultRouteTable.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfDefaultRouteTable.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfDefaultRouteTableRoutePropertyToTerraform(struct?: TfDefaultRouteTable.RouteProperty | cdktn.IResolvable): any;
export declare function tfDefaultRouteTableRoutePropertyToHclTerraform(struct?: TfDefaultRouteTable.RouteProperty | cdktn.IResolvable): any;
export declare function tfDefaultRouteTableTimeoutsPropertyToTerraform(struct?: TfDefaultRouteTable.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfDefaultRouteTableTimeoutsPropertyToHclTerraform(struct?: TfDefaultRouteTable.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfDefaultRouteTable {
    interface RouteProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_route_table#cidr_block TfDefaultRouteTable#cidr_block}
        */
        readonly cidrBlock?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_route_table#core_network_arn TfDefaultRouteTable#core_network_arn}
        */
        readonly coreNetworkArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_route_table#destination_prefix_list_id TfDefaultRouteTable#destination_prefix_list_id}
        */
        readonly destinationPrefixListId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_route_table#egress_only_gateway_id TfDefaultRouteTable#egress_only_gateway_id}
        */
        readonly egressOnlyGatewayId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_route_table#gateway_id TfDefaultRouteTable#gateway_id}
        */
        readonly gatewayId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_route_table#instance_id TfDefaultRouteTable#instance_id}
        */
        readonly instanceId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_route_table#ipv6_cidr_block TfDefaultRouteTable#ipv6_cidr_block}
        */
        readonly ipv6CidrBlock?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_route_table#nat_gateway_id TfDefaultRouteTable#nat_gateway_id}
        */
        readonly natGatewayId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_route_table#network_interface_id TfDefaultRouteTable#network_interface_id}
        */
        readonly networkInterfaceId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_route_table#transit_gateway_id TfDefaultRouteTable#transit_gateway_id}
        */
        readonly transitGatewayId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_route_table#vpc_endpoint_id TfDefaultRouteTable#vpc_endpoint_id}
        */
        readonly vpcEndpointId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_route_table#vpc_peering_connection_id TfDefaultRouteTable#vpc_peering_connection_id}
        */
        readonly vpcPeeringConnectionId?: string;
    }
    class RoutePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RouteProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RouteProperty | cdktn.IResolvable | undefined);
        private _cidrBlock?;
        get cidrBlock(): string;
        set cidrBlock(value: string);
        resetCidrBlock(): void;
        get cidrBlockInput(): string | undefined;
        private _coreNetworkArn?;
        get coreNetworkArn(): string;
        set coreNetworkArn(value: string);
        resetCoreNetworkArn(): void;
        get coreNetworkArnInput(): string | undefined;
        private _destinationPrefixListId?;
        get destinationPrefixListId(): string;
        set destinationPrefixListId(value: string);
        resetDestinationPrefixListId(): void;
        get destinationPrefixListIdInput(): string | undefined;
        private _egressOnlyGatewayId?;
        get egressOnlyGatewayId(): string;
        set egressOnlyGatewayId(value: string);
        resetEgressOnlyGatewayId(): void;
        get egressOnlyGatewayIdInput(): string | undefined;
        private _gatewayId?;
        get gatewayId(): string;
        set gatewayId(value: string);
        resetGatewayId(): void;
        get gatewayIdInput(): string | undefined;
        private _instanceId?;
        get instanceId(): string;
        set instanceId(value: string);
        resetInstanceId(): void;
        get instanceIdInput(): string | undefined;
        private _ipv6CidrBlock?;
        get ipv6CidrBlock(): string;
        set ipv6CidrBlock(value: string);
        resetIpv6CidrBlock(): void;
        get ipv6CidrBlockInput(): string | undefined;
        private _natGatewayId?;
        get natGatewayId(): string;
        set natGatewayId(value: string);
        resetNatGatewayId(): void;
        get natGatewayIdInput(): string | undefined;
        private _networkInterfaceId?;
        get networkInterfaceId(): string;
        set networkInterfaceId(value: string);
        resetNetworkInterfaceId(): void;
        get networkInterfaceIdInput(): string | undefined;
        private _transitGatewayId?;
        get transitGatewayId(): string;
        set transitGatewayId(value: string);
        resetTransitGatewayId(): void;
        get transitGatewayIdInput(): string | undefined;
        private _vpcEndpointId?;
        get vpcEndpointId(): string;
        set vpcEndpointId(value: string);
        resetVpcEndpointId(): void;
        get vpcEndpointIdInput(): string | undefined;
        private _vpcPeeringConnectionId?;
        get vpcPeeringConnectionId(): string;
        set vpcPeeringConnectionId(value: string);
        resetVpcPeeringConnectionId(): void;
        get vpcPeeringConnectionIdInput(): string | undefined;
    }
    class RoutePropertyList extends cdktn.ComplexList {
        internalValue?: RouteProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RoutePropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_route_table#create TfDefaultRouteTable#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/default_route_table#update TfDefaultRouteTable#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
