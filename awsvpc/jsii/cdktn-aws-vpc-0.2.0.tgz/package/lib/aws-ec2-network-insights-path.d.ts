import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfEc2NetworkInsightsPathConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_path#destination TfEc2NetworkInsightsPath#destination}
    */
    readonly destination?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_path#destination_ip TfEc2NetworkInsightsPath#destination_ip}
    */
    readonly destinationIp?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_path#destination_port TfEc2NetworkInsightsPath#destination_port}
    */
    readonly destinationPort?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_path#id TfEc2NetworkInsightsPath#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_path#protocol TfEc2NetworkInsightsPath#protocol}
    */
    readonly protocol: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_path#region TfEc2NetworkInsightsPath#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_path#source TfEc2NetworkInsightsPath#source}
    */
    readonly source: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_path#source_ip TfEc2NetworkInsightsPath#source_ip}
    */
    readonly sourceIp?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_path#tags TfEc2NetworkInsightsPath#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_path#tags_all TfEc2NetworkInsightsPath#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * filter_at_destination block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_path#filter_at_destination TfEc2NetworkInsightsPath#filter_at_destination}
    */
    readonly filterAtDestination?: TfEc2NetworkInsightsPath.FilterAtDestinationProperty;
    /**
    * filter_at_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_path#filter_at_source TfEc2NetworkInsightsPath#filter_at_source}
    */
    readonly filterAtSource?: TfEc2NetworkInsightsPath.FilterAtSourceProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_path aws_ec2_network_insights_path}
*/
export declare class TfEc2NetworkInsightsPath extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ec2_network_insights_path";
    /**
    * Generates CDKTN code for importing a TfEc2NetworkInsightsPath resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfEc2NetworkInsightsPath to import
    * @param importFromId The id of the existing TfEc2NetworkInsightsPath that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_path#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfEc2NetworkInsightsPath to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_path aws_ec2_network_insights_path} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfEc2NetworkInsightsPathConfig
    */
    constructor(scope: Construct, id: string, config: TfEc2NetworkInsightsPathConfig);
    get arn(): string;
    private _destination?;
    get destination(): string;
    set destination(value: string);
    resetDestination(): void;
    get destinationInput(): string | undefined;
    get destinationArn(): string;
    private _destinationIp?;
    get destinationIp(): string;
    set destinationIp(value: string);
    resetDestinationIp(): void;
    get destinationIpInput(): string | undefined;
    private _destinationPort?;
    get destinationPort(): number;
    set destinationPort(value: number);
    resetDestinationPort(): void;
    get destinationPortInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    get protocolInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    get sourceInput(): string | undefined;
    get sourceArn(): string;
    private _sourceIp?;
    get sourceIp(): string;
    set sourceIp(value: string);
    resetSourceIp(): void;
    get sourceIpInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _filterAtDestination;
    get filterAtDestination(): TfEc2NetworkInsightsPath.FilterAtDestinationPropertyOutputReference;
    putFilterAtDestination(value: TfEc2NetworkInsightsPath.FilterAtDestinationProperty): void;
    resetFilterAtDestination(): void;
    get filterAtDestinationInput(): TfEc2NetworkInsightsPath.FilterAtDestinationProperty | undefined;
    private _filterAtSource;
    get filterAtSource(): TfEc2NetworkInsightsPath.FilterAtSourcePropertyOutputReference;
    putFilterAtSource(value: TfEc2NetworkInsightsPath.FilterAtSourceProperty): void;
    resetFilterAtSource(): void;
    get filterAtSourceInput(): TfEc2NetworkInsightsPath.FilterAtSourceProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfEc2NetworkInsightsPathFilterAtDestinationDestinationPortRangePropertyToTerraform(struct?: TfEc2NetworkInsightsPath.FilterAtDestinationDestinationPortRangePropertyOutputReference | TfEc2NetworkInsightsPath.FilterAtDestinationDestinationPortRangeProperty): any;
export declare function tfEc2NetworkInsightsPathFilterAtDestinationDestinationPortRangePropertyToHclTerraform(struct?: TfEc2NetworkInsightsPath.FilterAtDestinationDestinationPortRangePropertyOutputReference | TfEc2NetworkInsightsPath.FilterAtDestinationDestinationPortRangeProperty): any;
export declare function tfEc2NetworkInsightsPathFilterAtDestinationSourcePortRangePropertyToTerraform(struct?: TfEc2NetworkInsightsPath.FilterAtDestinationSourcePortRangePropertyOutputReference | TfEc2NetworkInsightsPath.FilterAtDestinationSourcePortRangeProperty): any;
export declare function tfEc2NetworkInsightsPathFilterAtDestinationSourcePortRangePropertyToHclTerraform(struct?: TfEc2NetworkInsightsPath.FilterAtDestinationSourcePortRangePropertyOutputReference | TfEc2NetworkInsightsPath.FilterAtDestinationSourcePortRangeProperty): any;
export declare function tfEc2NetworkInsightsPathFilterAtDestinationPropertyToTerraform(struct?: TfEc2NetworkInsightsPath.FilterAtDestinationPropertyOutputReference | TfEc2NetworkInsightsPath.FilterAtDestinationProperty): any;
export declare function tfEc2NetworkInsightsPathFilterAtDestinationPropertyToHclTerraform(struct?: TfEc2NetworkInsightsPath.FilterAtDestinationPropertyOutputReference | TfEc2NetworkInsightsPath.FilterAtDestinationProperty): any;
export declare function tfEc2NetworkInsightsPathFilterAtSourceDestinationPortRangePropertyToTerraform(struct?: TfEc2NetworkInsightsPath.FilterAtSourceDestinationPortRangePropertyOutputReference | TfEc2NetworkInsightsPath.FilterAtSourceDestinationPortRangeProperty): any;
export declare function tfEc2NetworkInsightsPathFilterAtSourceDestinationPortRangePropertyToHclTerraform(struct?: TfEc2NetworkInsightsPath.FilterAtSourceDestinationPortRangePropertyOutputReference | TfEc2NetworkInsightsPath.FilterAtSourceDestinationPortRangeProperty): any;
export declare function tfEc2NetworkInsightsPathFilterAtSourceSourcePortRangePropertyToTerraform(struct?: TfEc2NetworkInsightsPath.FilterAtSourceSourcePortRangePropertyOutputReference | TfEc2NetworkInsightsPath.FilterAtSourceSourcePortRangeProperty): any;
export declare function tfEc2NetworkInsightsPathFilterAtSourceSourcePortRangePropertyToHclTerraform(struct?: TfEc2NetworkInsightsPath.FilterAtSourceSourcePortRangePropertyOutputReference | TfEc2NetworkInsightsPath.FilterAtSourceSourcePortRangeProperty): any;
export declare function tfEc2NetworkInsightsPathFilterAtSourcePropertyToTerraform(struct?: TfEc2NetworkInsightsPath.FilterAtSourcePropertyOutputReference | TfEc2NetworkInsightsPath.FilterAtSourceProperty): any;
export declare function tfEc2NetworkInsightsPathFilterAtSourcePropertyToHclTerraform(struct?: TfEc2NetworkInsightsPath.FilterAtSourcePropertyOutputReference | TfEc2NetworkInsightsPath.FilterAtSourceProperty): any;
export declare namespace TfEc2NetworkInsightsPath {
    interface FilterAtDestinationDestinationPortRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_path#from_port TfEc2NetworkInsightsPath#from_port}
        */
        readonly fromPort?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_path#to_port TfEc2NetworkInsightsPath#to_port}
        */
        readonly toPort?: number;
    }
    class FilterAtDestinationDestinationPortRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterAtDestinationDestinationPortRangeProperty | undefined;
        set internalValue(value: FilterAtDestinationDestinationPortRangeProperty | undefined);
        private _fromPort?;
        get fromPort(): number;
        set fromPort(value: number);
        resetFromPort(): void;
        get fromPortInput(): number | undefined;
        private _toPort?;
        get toPort(): number;
        set toPort(value: number);
        resetToPort(): void;
        get toPortInput(): number | undefined;
    }
    interface FilterAtDestinationSourcePortRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_path#from_port TfEc2NetworkInsightsPath#from_port}
        */
        readonly fromPort?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_path#to_port TfEc2NetworkInsightsPath#to_port}
        */
        readonly toPort?: number;
    }
    class FilterAtDestinationSourcePortRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterAtDestinationSourcePortRangeProperty | undefined;
        set internalValue(value: FilterAtDestinationSourcePortRangeProperty | undefined);
        private _fromPort?;
        get fromPort(): number;
        set fromPort(value: number);
        resetFromPort(): void;
        get fromPortInput(): number | undefined;
        private _toPort?;
        get toPort(): number;
        set toPort(value: number);
        resetToPort(): void;
        get toPortInput(): number | undefined;
    }
    interface FilterAtDestinationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_path#destination_address TfEc2NetworkInsightsPath#destination_address}
        */
        readonly destinationAddress?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_path#source_address TfEc2NetworkInsightsPath#source_address}
        */
        readonly sourceAddress?: string;
        /**
        * destination_port_range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_path#destination_port_range TfEc2NetworkInsightsPath#destination_port_range}
        */
        readonly destinationPortRange?: FilterAtDestinationDestinationPortRangeProperty;
        /**
        * source_port_range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_path#source_port_range TfEc2NetworkInsightsPath#source_port_range}
        */
        readonly sourcePortRange?: FilterAtDestinationSourcePortRangeProperty;
    }
    class FilterAtDestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterAtDestinationProperty | undefined;
        set internalValue(value: FilterAtDestinationProperty | undefined);
        private _destinationAddress?;
        get destinationAddress(): string;
        set destinationAddress(value: string);
        resetDestinationAddress(): void;
        get destinationAddressInput(): string | undefined;
        private _sourceAddress?;
        get sourceAddress(): string;
        set sourceAddress(value: string);
        resetSourceAddress(): void;
        get sourceAddressInput(): string | undefined;
        private _destinationPortRange;
        get destinationPortRange(): FilterAtDestinationDestinationPortRangePropertyOutputReference;
        putDestinationPortRange(value: FilterAtDestinationDestinationPortRangeProperty): void;
        resetDestinationPortRange(): void;
        get destinationPortRangeInput(): FilterAtDestinationDestinationPortRangeProperty | undefined;
        private _sourcePortRange;
        get sourcePortRange(): FilterAtDestinationSourcePortRangePropertyOutputReference;
        putSourcePortRange(value: FilterAtDestinationSourcePortRangeProperty): void;
        resetSourcePortRange(): void;
        get sourcePortRangeInput(): FilterAtDestinationSourcePortRangeProperty | undefined;
    }
    interface FilterAtSourceDestinationPortRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_path#from_port TfEc2NetworkInsightsPath#from_port}
        */
        readonly fromPort?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_path#to_port TfEc2NetworkInsightsPath#to_port}
        */
        readonly toPort?: number;
    }
    class FilterAtSourceDestinationPortRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterAtSourceDestinationPortRangeProperty | undefined;
        set internalValue(value: FilterAtSourceDestinationPortRangeProperty | undefined);
        private _fromPort?;
        get fromPort(): number;
        set fromPort(value: number);
        resetFromPort(): void;
        get fromPortInput(): number | undefined;
        private _toPort?;
        get toPort(): number;
        set toPort(value: number);
        resetToPort(): void;
        get toPortInput(): number | undefined;
    }
    interface FilterAtSourceSourcePortRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_path#from_port TfEc2NetworkInsightsPath#from_port}
        */
        readonly fromPort?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_path#to_port TfEc2NetworkInsightsPath#to_port}
        */
        readonly toPort?: number;
    }
    class FilterAtSourceSourcePortRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterAtSourceSourcePortRangeProperty | undefined;
        set internalValue(value: FilterAtSourceSourcePortRangeProperty | undefined);
        private _fromPort?;
        get fromPort(): number;
        set fromPort(value: number);
        resetFromPort(): void;
        get fromPortInput(): number | undefined;
        private _toPort?;
        get toPort(): number;
        set toPort(value: number);
        resetToPort(): void;
        get toPortInput(): number | undefined;
    }
    interface FilterAtSourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_path#destination_address TfEc2NetworkInsightsPath#destination_address}
        */
        readonly destinationAddress?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_path#source_address TfEc2NetworkInsightsPath#source_address}
        */
        readonly sourceAddress?: string;
        /**
        * destination_port_range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_path#destination_port_range TfEc2NetworkInsightsPath#destination_port_range}
        */
        readonly destinationPortRange?: FilterAtSourceDestinationPortRangeProperty;
        /**
        * source_port_range block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_path#source_port_range TfEc2NetworkInsightsPath#source_port_range}
        */
        readonly sourcePortRange?: FilterAtSourceSourcePortRangeProperty;
    }
    class FilterAtSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterAtSourceProperty | undefined;
        set internalValue(value: FilterAtSourceProperty | undefined);
        private _destinationAddress?;
        get destinationAddress(): string;
        set destinationAddress(value: string);
        resetDestinationAddress(): void;
        get destinationAddressInput(): string | undefined;
        private _sourceAddress?;
        get sourceAddress(): string;
        set sourceAddress(value: string);
        resetSourceAddress(): void;
        get sourceAddressInput(): string | undefined;
        private _destinationPortRange;
        get destinationPortRange(): FilterAtSourceDestinationPortRangePropertyOutputReference;
        putDestinationPortRange(value: FilterAtSourceDestinationPortRangeProperty): void;
        resetDestinationPortRange(): void;
        get destinationPortRangeInput(): FilterAtSourceDestinationPortRangeProperty | undefined;
        private _sourcePortRange;
        get sourcePortRange(): FilterAtSourceSourcePortRangePropertyOutputReference;
        putSourcePortRange(value: FilterAtSourceSourcePortRangeProperty): void;
        resetSourcePortRange(): void;
        get sourcePortRangeInput(): FilterAtSourceSourcePortRangeProperty | undefined;
    }
}
