import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfPeeringConnectionOptionsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection_options#id TfPeeringConnectionOptions#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection_options#region TfPeeringConnectionOptions#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection_options#vpc_peering_connection_id TfPeeringConnectionOptions#vpc_peering_connection_id}
    */
    readonly vpcPeeringConnectionId: string;
    /**
    * accepter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection_options#accepter TfPeeringConnectionOptions#accepter}
    */
    readonly accepter?: TfPeeringConnectionOptions.AccepterProperty;
    /**
    * requester block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection_options#requester TfPeeringConnectionOptions#requester}
    */
    readonly requester?: TfPeeringConnectionOptions.RequesterProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection_options aws_vpc_peering_connection_options}
*/
export declare class TfPeeringConnectionOptions extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_vpc_peering_connection_options";
    /**
    * Generates CDKTN code for importing a TfPeeringConnectionOptions resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfPeeringConnectionOptions to import
    * @param importFromId The id of the existing TfPeeringConnectionOptions that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection_options#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfPeeringConnectionOptions to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection_options aws_vpc_peering_connection_options} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfPeeringConnectionOptionsConfig
    */
    constructor(scope: Construct, id: string, config: TfPeeringConnectionOptionsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _vpcPeeringConnectionId?;
    get vpcPeeringConnectionId(): string;
    set vpcPeeringConnectionId(value: string);
    get vpcPeeringConnectionIdInput(): string | undefined;
    private _accepter;
    get accepter(): TfPeeringConnectionOptions.AccepterPropertyOutputReference;
    putAccepter(value: TfPeeringConnectionOptions.AccepterProperty): void;
    resetAccepter(): void;
    get accepterInput(): TfPeeringConnectionOptions.AccepterProperty | undefined;
    private _requester;
    get requester(): TfPeeringConnectionOptions.RequesterPropertyOutputReference;
    putRequester(value: TfPeeringConnectionOptions.RequesterProperty): void;
    resetRequester(): void;
    get requesterInput(): TfPeeringConnectionOptions.RequesterProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfPeeringConnectionOptionsAccepterPropertyToTerraform(struct?: TfPeeringConnectionOptions.AccepterPropertyOutputReference | TfPeeringConnectionOptions.AccepterProperty): any;
export declare function tfPeeringConnectionOptionsAccepterPropertyToHclTerraform(struct?: TfPeeringConnectionOptions.AccepterPropertyOutputReference | TfPeeringConnectionOptions.AccepterProperty): any;
export declare function tfPeeringConnectionOptionsRequesterPropertyToTerraform(struct?: TfPeeringConnectionOptions.RequesterPropertyOutputReference | TfPeeringConnectionOptions.RequesterProperty): any;
export declare function tfPeeringConnectionOptionsRequesterPropertyToHclTerraform(struct?: TfPeeringConnectionOptions.RequesterPropertyOutputReference | TfPeeringConnectionOptions.RequesterProperty): any;
export declare namespace TfPeeringConnectionOptions {
    interface AccepterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection_options#allow_remote_vpc_dns_resolution TfPeeringConnectionOptions#allow_remote_vpc_dns_resolution}
        */
        readonly allowRemoteVpcDnsResolution?: boolean | cdktn.IResolvable;
    }
    class AccepterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AccepterProperty | undefined;
        set internalValue(value: AccepterProperty | undefined);
        private _allowRemoteVpcDnsResolution?;
        get allowRemoteVpcDnsResolution(): boolean | cdktn.IResolvable;
        set allowRemoteVpcDnsResolution(value: boolean | cdktn.IResolvable);
        resetAllowRemoteVpcDnsResolution(): void;
        get allowRemoteVpcDnsResolutionInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface RequesterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_peering_connection_options#allow_remote_vpc_dns_resolution TfPeeringConnectionOptions#allow_remote_vpc_dns_resolution}
        */
        readonly allowRemoteVpcDnsResolution?: boolean | cdktn.IResolvable;
    }
    class RequesterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RequesterProperty | undefined;
        set internalValue(value: RequesterProperty | undefined);
        private _allowRemoteVpcDnsResolution?;
        get allowRemoteVpcDnsResolution(): boolean | cdktn.IResolvable;
        set allowRemoteVpcDnsResolution(value: boolean | cdktn.IResolvable);
        resetAllowRemoteVpcDnsResolution(): void;
        get allowRemoteVpcDnsResolutionInput(): boolean | cdktn.IResolvable | undefined;
    }
}
