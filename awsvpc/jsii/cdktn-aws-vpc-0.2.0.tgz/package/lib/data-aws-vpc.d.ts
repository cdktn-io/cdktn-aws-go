import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfVpcConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc#cidr_block DataTfVpc#cidr_block}
    */
    readonly cidrBlock?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc#default DataTfVpc#default}
    */
    readonly default?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc#dhcp_options_id DataTfVpc#dhcp_options_id}
    */
    readonly dhcpOptionsId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc#id DataTfVpc#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc#region DataTfVpc#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc#state DataTfVpc#state}
    */
    readonly state?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc#tags DataTfVpc#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc#filter DataTfVpc#filter}
    */
    readonly filter?: DataTfVpc.FilterProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc#timeouts DataTfVpc#timeouts}
    */
    readonly timeouts?: DataTfVpc.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc aws_vpc}
*/
export declare class DataTfVpc extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_vpc";
    /**
    * Generates CDKTN code for importing a DataTfVpc resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfVpc to import
    * @param importFromId The id of the existing DataTfVpc that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfVpc to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc aws_vpc} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfVpcConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataTfVpcConfig);
    get arn(): string;
    private _cidrBlock?;
    get cidrBlock(): string;
    set cidrBlock(value: string);
    resetCidrBlock(): void;
    get cidrBlockInput(): string | undefined;
    private _cidrBlockAssociations;
    get cidrBlockAssociations(): DataTfVpc.CidrBlockAssociationsPropertyList;
    private _default?;
    get default(): boolean | cdktn.IResolvable;
    set default(value: boolean | cdktn.IResolvable);
    resetDefault(): void;
    get defaultInput(): boolean | cdktn.IResolvable | undefined;
    private _dhcpOptionsId?;
    get dhcpOptionsId(): string;
    set dhcpOptionsId(value: string);
    resetDhcpOptionsId(): void;
    get dhcpOptionsIdInput(): string | undefined;
    get enableDnsHostnames(): cdktn.IResolvable;
    get enableDnsSupport(): cdktn.IResolvable;
    get enableNetworkAddressUsageMetrics(): cdktn.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get instanceTenancy(): string;
    get ipv6AssociationId(): string;
    get ipv6CidrBlock(): string;
    private _ipv6CidrBlockAssociations;
    get ipv6CidrBlockAssociations(): DataTfVpc.Ipv6CidrBlockAssociationsPropertyList;
    get mainRouteTableId(): string;
    get ownerId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _filter;
    get filter(): DataTfVpc.FilterPropertyList;
    putFilter(value: DataTfVpc.FilterProperty[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataTfVpc.FilterProperty[] | undefined;
    private _timeouts;
    get timeouts(): DataTfVpc.TimeoutsPropertyOutputReference;
    putTimeouts(value: DataTfVpc.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataTfVpc.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfVpcCidrBlockAssociationsPropertyToTerraform(struct?: DataTfVpc.CidrBlockAssociationsProperty): any;
export declare function dataTfVpcCidrBlockAssociationsPropertyToHclTerraform(struct?: DataTfVpc.CidrBlockAssociationsProperty): any;
export declare function dataTfVpcIpv6CidrBlockAssociationsPropertyToTerraform(struct?: DataTfVpc.Ipv6CidrBlockAssociationsProperty): any;
export declare function dataTfVpcIpv6CidrBlockAssociationsPropertyToHclTerraform(struct?: DataTfVpc.Ipv6CidrBlockAssociationsProperty): any;
export declare function dataTfVpcFilterPropertyToTerraform(struct?: DataTfVpc.FilterProperty | cdktn.IResolvable): any;
export declare function dataTfVpcFilterPropertyToHclTerraform(struct?: DataTfVpc.FilterProperty | cdktn.IResolvable): any;
export declare function dataTfVpcTimeoutsPropertyToTerraform(struct?: DataTfVpc.TimeoutsProperty | cdktn.IResolvable): any;
export declare function dataTfVpcTimeoutsPropertyToHclTerraform(struct?: DataTfVpc.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace DataTfVpc {
    interface CidrBlockAssociationsProperty {
    }
    class CidrBlockAssociationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CidrBlockAssociationsProperty | undefined;
        set internalValue(value: CidrBlockAssociationsProperty | undefined);
        get associationId(): string;
        get cidrBlock(): string;
        get state(): string;
    }
    class CidrBlockAssociationsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CidrBlockAssociationsPropertyOutputReference;
    }
    interface Ipv6CidrBlockAssociationsProperty {
    }
    class Ipv6CidrBlockAssociationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): Ipv6CidrBlockAssociationsProperty | undefined;
        set internalValue(value: Ipv6CidrBlockAssociationsProperty | undefined);
        get associationId(): string;
        get ipSource(): string;
        get ipv6AddressAttribute(): string;
        get ipv6CidrBlock(): string;
        get ipv6Pool(): string;
        get networkBorderGroup(): string;
        get state(): string;
    }
    class Ipv6CidrBlockAssociationsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): Ipv6CidrBlockAssociationsPropertyOutputReference;
    }
    interface FilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc#name DataTfVpc#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc#values DataTfVpc#values}
        */
        readonly values: string[];
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class FilterPropertyList extends cdktn.ComplexList {
        internalValue?: FilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc#read DataTfVpc#read}
        */
        readonly read?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _read?;
        get read(): string;
        set read(value: string);
        resetRead(): void;
        get readInput(): string | undefined;
    }
}
