import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfEc2NetworkInsightsAccessScopeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#region TfEc2NetworkInsightsAccessScope#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#tags TfEc2NetworkInsightsAccessScope#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * exclude_paths block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#exclude_paths TfEc2NetworkInsightsAccessScope#exclude_paths}
    */
    readonly excludePaths?: TfEc2NetworkInsightsAccessScope.ExcludePathsProperty[] | cdktn.IResolvable;
    /**
    * match_paths block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#match_paths TfEc2NetworkInsightsAccessScope#match_paths}
    */
    readonly matchPaths?: TfEc2NetworkInsightsAccessScope.MatchPathsProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope aws_ec2_network_insights_access_scope}
*/
export declare class TfEc2NetworkInsightsAccessScope extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ec2_network_insights_access_scope";
    /**
    * Generates CDKTN code for importing a TfEc2NetworkInsightsAccessScope resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfEc2NetworkInsightsAccessScope to import
    * @param importFromId The id of the existing TfEc2NetworkInsightsAccessScope that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfEc2NetworkInsightsAccessScope to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope aws_ec2_network_insights_access_scope} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfEc2NetworkInsightsAccessScopeConfig = {}
    */
    constructor(scope: Construct, id: string, config?: TfEc2NetworkInsightsAccessScopeConfig);
    get arn(): string;
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _excludePaths;
    get excludePaths(): TfEc2NetworkInsightsAccessScope.ExcludePathsPropertyList;
    putExcludePaths(value: TfEc2NetworkInsightsAccessScope.ExcludePathsProperty[] | cdktn.IResolvable): void;
    resetExcludePaths(): void;
    get excludePathsInput(): cdktn.IResolvable | TfEc2NetworkInsightsAccessScope.ExcludePathsProperty[] | undefined;
    private _matchPaths;
    get matchPaths(): TfEc2NetworkInsightsAccessScope.MatchPathsPropertyList;
    putMatchPaths(value: TfEc2NetworkInsightsAccessScope.MatchPathsProperty[] | cdktn.IResolvable): void;
    resetMatchPaths(): void;
    get matchPathsInput(): cdktn.IResolvable | TfEc2NetworkInsightsAccessScope.MatchPathsProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfEc2NetworkInsightsAccessScopeExcludePathsDestinationPacketHeaderStatementPropertyToTerraform(struct?: TfEc2NetworkInsightsAccessScope.ExcludePathsDestinationPacketHeaderStatementProperty | cdktn.IResolvable): any;
export declare function tfEc2NetworkInsightsAccessScopeExcludePathsDestinationPacketHeaderStatementPropertyToHclTerraform(struct?: TfEc2NetworkInsightsAccessScope.ExcludePathsDestinationPacketHeaderStatementProperty | cdktn.IResolvable): any;
export declare function tfEc2NetworkInsightsAccessScopeExcludePathsDestinationResourceStatementPropertyToTerraform(struct?: TfEc2NetworkInsightsAccessScope.ExcludePathsDestinationResourceStatementProperty | cdktn.IResolvable): any;
export declare function tfEc2NetworkInsightsAccessScopeExcludePathsDestinationResourceStatementPropertyToHclTerraform(struct?: TfEc2NetworkInsightsAccessScope.ExcludePathsDestinationResourceStatementProperty | cdktn.IResolvable): any;
export declare function tfEc2NetworkInsightsAccessScopeExcludePathsDestinationPropertyToTerraform(struct?: TfEc2NetworkInsightsAccessScope.ExcludePathsDestinationProperty | cdktn.IResolvable): any;
export declare function tfEc2NetworkInsightsAccessScopeExcludePathsDestinationPropertyToHclTerraform(struct?: TfEc2NetworkInsightsAccessScope.ExcludePathsDestinationProperty | cdktn.IResolvable): any;
export declare function tfEc2NetworkInsightsAccessScopeExcludePathsSourcePacketHeaderStatementPropertyToTerraform(struct?: TfEc2NetworkInsightsAccessScope.ExcludePathsSourcePacketHeaderStatementProperty | cdktn.IResolvable): any;
export declare function tfEc2NetworkInsightsAccessScopeExcludePathsSourcePacketHeaderStatementPropertyToHclTerraform(struct?: TfEc2NetworkInsightsAccessScope.ExcludePathsSourcePacketHeaderStatementProperty | cdktn.IResolvable): any;
export declare function tfEc2NetworkInsightsAccessScopeExcludePathsSourceResourceStatementPropertyToTerraform(struct?: TfEc2NetworkInsightsAccessScope.ExcludePathsSourceResourceStatementProperty | cdktn.IResolvable): any;
export declare function tfEc2NetworkInsightsAccessScopeExcludePathsSourceResourceStatementPropertyToHclTerraform(struct?: TfEc2NetworkInsightsAccessScope.ExcludePathsSourceResourceStatementProperty | cdktn.IResolvable): any;
export declare function tfEc2NetworkInsightsAccessScopeExcludePathsSourcePropertyToTerraform(struct?: TfEc2NetworkInsightsAccessScope.ExcludePathsSourceProperty | cdktn.IResolvable): any;
export declare function tfEc2NetworkInsightsAccessScopeExcludePathsSourcePropertyToHclTerraform(struct?: TfEc2NetworkInsightsAccessScope.ExcludePathsSourceProperty | cdktn.IResolvable): any;
export declare function tfEc2NetworkInsightsAccessScopeExcludePathsThroughResourcesResourceStatementPropertyToTerraform(struct?: TfEc2NetworkInsightsAccessScope.ExcludePathsThroughResourcesResourceStatementProperty | cdktn.IResolvable): any;
export declare function tfEc2NetworkInsightsAccessScopeExcludePathsThroughResourcesResourceStatementPropertyToHclTerraform(struct?: TfEc2NetworkInsightsAccessScope.ExcludePathsThroughResourcesResourceStatementProperty | cdktn.IResolvable): any;
export declare function tfEc2NetworkInsightsAccessScopeThroughResourcesPropertyToTerraform(struct?: TfEc2NetworkInsightsAccessScope.ThroughResourcesProperty | cdktn.IResolvable): any;
export declare function tfEc2NetworkInsightsAccessScopeThroughResourcesPropertyToHclTerraform(struct?: TfEc2NetworkInsightsAccessScope.ThroughResourcesProperty | cdktn.IResolvable): any;
export declare function tfEc2NetworkInsightsAccessScopeExcludePathsPropertyToTerraform(struct?: TfEc2NetworkInsightsAccessScope.ExcludePathsProperty | cdktn.IResolvable): any;
export declare function tfEc2NetworkInsightsAccessScopeExcludePathsPropertyToHclTerraform(struct?: TfEc2NetworkInsightsAccessScope.ExcludePathsProperty | cdktn.IResolvable): any;
export declare function tfEc2NetworkInsightsAccessScopeMatchPathsDestinationPacketHeaderStatementPropertyToTerraform(struct?: TfEc2NetworkInsightsAccessScope.MatchPathsDestinationPacketHeaderStatementProperty | cdktn.IResolvable): any;
export declare function tfEc2NetworkInsightsAccessScopeMatchPathsDestinationPacketHeaderStatementPropertyToHclTerraform(struct?: TfEc2NetworkInsightsAccessScope.MatchPathsDestinationPacketHeaderStatementProperty | cdktn.IResolvable): any;
export declare function tfEc2NetworkInsightsAccessScopeMatchPathsDestinationResourceStatementPropertyToTerraform(struct?: TfEc2NetworkInsightsAccessScope.MatchPathsDestinationResourceStatementProperty | cdktn.IResolvable): any;
export declare function tfEc2NetworkInsightsAccessScopeMatchPathsDestinationResourceStatementPropertyToHclTerraform(struct?: TfEc2NetworkInsightsAccessScope.MatchPathsDestinationResourceStatementProperty | cdktn.IResolvable): any;
export declare function tfEc2NetworkInsightsAccessScopeMatchPathsDestinationPropertyToTerraform(struct?: TfEc2NetworkInsightsAccessScope.MatchPathsDestinationProperty | cdktn.IResolvable): any;
export declare function tfEc2NetworkInsightsAccessScopeMatchPathsDestinationPropertyToHclTerraform(struct?: TfEc2NetworkInsightsAccessScope.MatchPathsDestinationProperty | cdktn.IResolvable): any;
export declare function tfEc2NetworkInsightsAccessScopeMatchPathsSourcePacketHeaderStatementPropertyToTerraform(struct?: TfEc2NetworkInsightsAccessScope.MatchPathsSourcePacketHeaderStatementProperty | cdktn.IResolvable): any;
export declare function tfEc2NetworkInsightsAccessScopeMatchPathsSourcePacketHeaderStatementPropertyToHclTerraform(struct?: TfEc2NetworkInsightsAccessScope.MatchPathsSourcePacketHeaderStatementProperty | cdktn.IResolvable): any;
export declare function tfEc2NetworkInsightsAccessScopeMatchPathsSourceResourceStatementPropertyToTerraform(struct?: TfEc2NetworkInsightsAccessScope.MatchPathsSourceResourceStatementProperty | cdktn.IResolvable): any;
export declare function tfEc2NetworkInsightsAccessScopeMatchPathsSourceResourceStatementPropertyToHclTerraform(struct?: TfEc2NetworkInsightsAccessScope.MatchPathsSourceResourceStatementProperty | cdktn.IResolvable): any;
export declare function tfEc2NetworkInsightsAccessScopeMatchPathsSourcePropertyToTerraform(struct?: TfEc2NetworkInsightsAccessScope.MatchPathsSourceProperty | cdktn.IResolvable): any;
export declare function tfEc2NetworkInsightsAccessScopeMatchPathsSourcePropertyToHclTerraform(struct?: TfEc2NetworkInsightsAccessScope.MatchPathsSourceProperty | cdktn.IResolvable): any;
export declare function tfEc2NetworkInsightsAccessScopeMatchPathsPropertyToTerraform(struct?: TfEc2NetworkInsightsAccessScope.MatchPathsProperty | cdktn.IResolvable): any;
export declare function tfEc2NetworkInsightsAccessScopeMatchPathsPropertyToHclTerraform(struct?: TfEc2NetworkInsightsAccessScope.MatchPathsProperty | cdktn.IResolvable): any;
export declare namespace TfEc2NetworkInsightsAccessScope {
    interface ExcludePathsDestinationPacketHeaderStatementProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#destination_addresses TfEc2NetworkInsightsAccessScope#destination_addresses}
        */
        readonly destinationAddresses?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#destination_ports TfEc2NetworkInsightsAccessScope#destination_ports}
        */
        readonly destinationPorts?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#destination_prefix_lists TfEc2NetworkInsightsAccessScope#destination_prefix_lists}
        */
        readonly destinationPrefixLists?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#protocols TfEc2NetworkInsightsAccessScope#protocols}
        */
        readonly protocols?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#source_addresses TfEc2NetworkInsightsAccessScope#source_addresses}
        */
        readonly sourceAddresses?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#source_ports TfEc2NetworkInsightsAccessScope#source_ports}
        */
        readonly sourcePorts?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#source_prefix_lists TfEc2NetworkInsightsAccessScope#source_prefix_lists}
        */
        readonly sourcePrefixLists?: string[];
    }
    class ExcludePathsDestinationPacketHeaderStatementPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExcludePathsDestinationPacketHeaderStatementProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ExcludePathsDestinationPacketHeaderStatementProperty | cdktn.IResolvable | undefined);
        private _destinationAddresses?;
        get destinationAddresses(): string[];
        set destinationAddresses(value: string[]);
        resetDestinationAddresses(): void;
        get destinationAddressesInput(): string[] | undefined;
        private _destinationPorts?;
        get destinationPorts(): string[];
        set destinationPorts(value: string[]);
        resetDestinationPorts(): void;
        get destinationPortsInput(): string[] | undefined;
        private _destinationPrefixLists?;
        get destinationPrefixLists(): string[];
        set destinationPrefixLists(value: string[]);
        resetDestinationPrefixLists(): void;
        get destinationPrefixListsInput(): string[] | undefined;
        private _protocols?;
        get protocols(): string[];
        set protocols(value: string[]);
        resetProtocols(): void;
        get protocolsInput(): string[] | undefined;
        private _sourceAddresses?;
        get sourceAddresses(): string[];
        set sourceAddresses(value: string[]);
        resetSourceAddresses(): void;
        get sourceAddressesInput(): string[] | undefined;
        private _sourcePorts?;
        get sourcePorts(): string[];
        set sourcePorts(value: string[]);
        resetSourcePorts(): void;
        get sourcePortsInput(): string[] | undefined;
        private _sourcePrefixLists?;
        get sourcePrefixLists(): string[];
        set sourcePrefixLists(value: string[]);
        resetSourcePrefixLists(): void;
        get sourcePrefixListsInput(): string[] | undefined;
    }
    class ExcludePathsDestinationPacketHeaderStatementPropertyList extends cdktn.ComplexList {
        internalValue?: ExcludePathsDestinationPacketHeaderStatementProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExcludePathsDestinationPacketHeaderStatementPropertyOutputReference;
    }
    interface ExcludePathsDestinationResourceStatementProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#resource_types TfEc2NetworkInsightsAccessScope#resource_types}
        */
        readonly resourceTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#resources TfEc2NetworkInsightsAccessScope#resources}
        */
        readonly resources?: string[];
    }
    class ExcludePathsDestinationResourceStatementPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExcludePathsDestinationResourceStatementProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ExcludePathsDestinationResourceStatementProperty | cdktn.IResolvable | undefined);
        private _resourceTypes?;
        get resourceTypes(): string[];
        set resourceTypes(value: string[]);
        resetResourceTypes(): void;
        get resourceTypesInput(): string[] | undefined;
        private _resources?;
        get resources(): string[];
        set resources(value: string[]);
        resetResources(): void;
        get resourcesInput(): string[] | undefined;
    }
    class ExcludePathsDestinationResourceStatementPropertyList extends cdktn.ComplexList {
        internalValue?: ExcludePathsDestinationResourceStatementProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExcludePathsDestinationResourceStatementPropertyOutputReference;
    }
    interface ExcludePathsDestinationProperty {
        /**
        * packet_header_statement block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#packet_header_statement TfEc2NetworkInsightsAccessScope#packet_header_statement}
        */
        readonly packetHeaderStatement?: ExcludePathsDestinationPacketHeaderStatementProperty[] | cdktn.IResolvable;
        /**
        * resource_statement block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#resource_statement TfEc2NetworkInsightsAccessScope#resource_statement}
        */
        readonly resourceStatement?: ExcludePathsDestinationResourceStatementProperty[] | cdktn.IResolvable;
    }
    class ExcludePathsDestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExcludePathsDestinationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ExcludePathsDestinationProperty | cdktn.IResolvable | undefined);
        private _packetHeaderStatement;
        get packetHeaderStatement(): ExcludePathsDestinationPacketHeaderStatementPropertyList;
        putPacketHeaderStatement(value: ExcludePathsDestinationPacketHeaderStatementProperty[] | cdktn.IResolvable): void;
        resetPacketHeaderStatement(): void;
        get packetHeaderStatementInput(): cdktn.IResolvable | ExcludePathsDestinationPacketHeaderStatementProperty[] | undefined;
        private _resourceStatement;
        get resourceStatement(): ExcludePathsDestinationResourceStatementPropertyList;
        putResourceStatement(value: ExcludePathsDestinationResourceStatementProperty[] | cdktn.IResolvable): void;
        resetResourceStatement(): void;
        get resourceStatementInput(): cdktn.IResolvable | ExcludePathsDestinationResourceStatementProperty[] | undefined;
    }
    class ExcludePathsDestinationPropertyList extends cdktn.ComplexList {
        internalValue?: ExcludePathsDestinationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExcludePathsDestinationPropertyOutputReference;
    }
    interface ExcludePathsSourcePacketHeaderStatementProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#destination_addresses TfEc2NetworkInsightsAccessScope#destination_addresses}
        */
        readonly destinationAddresses?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#destination_ports TfEc2NetworkInsightsAccessScope#destination_ports}
        */
        readonly destinationPorts?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#destination_prefix_lists TfEc2NetworkInsightsAccessScope#destination_prefix_lists}
        */
        readonly destinationPrefixLists?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#protocols TfEc2NetworkInsightsAccessScope#protocols}
        */
        readonly protocols?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#source_addresses TfEc2NetworkInsightsAccessScope#source_addresses}
        */
        readonly sourceAddresses?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#source_ports TfEc2NetworkInsightsAccessScope#source_ports}
        */
        readonly sourcePorts?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#source_prefix_lists TfEc2NetworkInsightsAccessScope#source_prefix_lists}
        */
        readonly sourcePrefixLists?: string[];
    }
    class ExcludePathsSourcePacketHeaderStatementPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExcludePathsSourcePacketHeaderStatementProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ExcludePathsSourcePacketHeaderStatementProperty | cdktn.IResolvable | undefined);
        private _destinationAddresses?;
        get destinationAddresses(): string[];
        set destinationAddresses(value: string[]);
        resetDestinationAddresses(): void;
        get destinationAddressesInput(): string[] | undefined;
        private _destinationPorts?;
        get destinationPorts(): string[];
        set destinationPorts(value: string[]);
        resetDestinationPorts(): void;
        get destinationPortsInput(): string[] | undefined;
        private _destinationPrefixLists?;
        get destinationPrefixLists(): string[];
        set destinationPrefixLists(value: string[]);
        resetDestinationPrefixLists(): void;
        get destinationPrefixListsInput(): string[] | undefined;
        private _protocols?;
        get protocols(): string[];
        set protocols(value: string[]);
        resetProtocols(): void;
        get protocolsInput(): string[] | undefined;
        private _sourceAddresses?;
        get sourceAddresses(): string[];
        set sourceAddresses(value: string[]);
        resetSourceAddresses(): void;
        get sourceAddressesInput(): string[] | undefined;
        private _sourcePorts?;
        get sourcePorts(): string[];
        set sourcePorts(value: string[]);
        resetSourcePorts(): void;
        get sourcePortsInput(): string[] | undefined;
        private _sourcePrefixLists?;
        get sourcePrefixLists(): string[];
        set sourcePrefixLists(value: string[]);
        resetSourcePrefixLists(): void;
        get sourcePrefixListsInput(): string[] | undefined;
    }
    class ExcludePathsSourcePacketHeaderStatementPropertyList extends cdktn.ComplexList {
        internalValue?: ExcludePathsSourcePacketHeaderStatementProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExcludePathsSourcePacketHeaderStatementPropertyOutputReference;
    }
    interface ExcludePathsSourceResourceStatementProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#resource_types TfEc2NetworkInsightsAccessScope#resource_types}
        */
        readonly resourceTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#resources TfEc2NetworkInsightsAccessScope#resources}
        */
        readonly resources?: string[];
    }
    class ExcludePathsSourceResourceStatementPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExcludePathsSourceResourceStatementProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ExcludePathsSourceResourceStatementProperty | cdktn.IResolvable | undefined);
        private _resourceTypes?;
        get resourceTypes(): string[];
        set resourceTypes(value: string[]);
        resetResourceTypes(): void;
        get resourceTypesInput(): string[] | undefined;
        private _resources?;
        get resources(): string[];
        set resources(value: string[]);
        resetResources(): void;
        get resourcesInput(): string[] | undefined;
    }
    class ExcludePathsSourceResourceStatementPropertyList extends cdktn.ComplexList {
        internalValue?: ExcludePathsSourceResourceStatementProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExcludePathsSourceResourceStatementPropertyOutputReference;
    }
    interface ExcludePathsSourceProperty {
        /**
        * packet_header_statement block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#packet_header_statement TfEc2NetworkInsightsAccessScope#packet_header_statement}
        */
        readonly packetHeaderStatement?: ExcludePathsSourcePacketHeaderStatementProperty[] | cdktn.IResolvable;
        /**
        * resource_statement block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#resource_statement TfEc2NetworkInsightsAccessScope#resource_statement}
        */
        readonly resourceStatement?: ExcludePathsSourceResourceStatementProperty[] | cdktn.IResolvable;
    }
    class ExcludePathsSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExcludePathsSourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ExcludePathsSourceProperty | cdktn.IResolvable | undefined);
        private _packetHeaderStatement;
        get packetHeaderStatement(): ExcludePathsSourcePacketHeaderStatementPropertyList;
        putPacketHeaderStatement(value: ExcludePathsSourcePacketHeaderStatementProperty[] | cdktn.IResolvable): void;
        resetPacketHeaderStatement(): void;
        get packetHeaderStatementInput(): cdktn.IResolvable | ExcludePathsSourcePacketHeaderStatementProperty[] | undefined;
        private _resourceStatement;
        get resourceStatement(): ExcludePathsSourceResourceStatementPropertyList;
        putResourceStatement(value: ExcludePathsSourceResourceStatementProperty[] | cdktn.IResolvable): void;
        resetResourceStatement(): void;
        get resourceStatementInput(): cdktn.IResolvable | ExcludePathsSourceResourceStatementProperty[] | undefined;
    }
    class ExcludePathsSourcePropertyList extends cdktn.ComplexList {
        internalValue?: ExcludePathsSourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExcludePathsSourcePropertyOutputReference;
    }
    interface ExcludePathsThroughResourcesResourceStatementProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#resource_types TfEc2NetworkInsightsAccessScope#resource_types}
        */
        readonly resourceTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#resources TfEc2NetworkInsightsAccessScope#resources}
        */
        readonly resources?: string[];
    }
    class ExcludePathsThroughResourcesResourceStatementPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExcludePathsThroughResourcesResourceStatementProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ExcludePathsThroughResourcesResourceStatementProperty | cdktn.IResolvable | undefined);
        private _resourceTypes?;
        get resourceTypes(): string[];
        set resourceTypes(value: string[]);
        resetResourceTypes(): void;
        get resourceTypesInput(): string[] | undefined;
        private _resources?;
        get resources(): string[];
        set resources(value: string[]);
        resetResources(): void;
        get resourcesInput(): string[] | undefined;
    }
    class ExcludePathsThroughResourcesResourceStatementPropertyList extends cdktn.ComplexList {
        internalValue?: ExcludePathsThroughResourcesResourceStatementProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExcludePathsThroughResourcesResourceStatementPropertyOutputReference;
    }
    interface ThroughResourcesProperty {
        /**
        * resource_statement block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#resource_statement TfEc2NetworkInsightsAccessScope#resource_statement}
        */
        readonly resourceStatement?: ExcludePathsThroughResourcesResourceStatementProperty[] | cdktn.IResolvable;
    }
    class ThroughResourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ThroughResourcesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ThroughResourcesProperty | cdktn.IResolvable | undefined);
        private _resourceStatement;
        get resourceStatement(): ExcludePathsThroughResourcesResourceStatementPropertyList;
        putResourceStatement(value: ExcludePathsThroughResourcesResourceStatementProperty[] | cdktn.IResolvable): void;
        resetResourceStatement(): void;
        get resourceStatementInput(): cdktn.IResolvable | ExcludePathsThroughResourcesResourceStatementProperty[] | undefined;
    }
    class ThroughResourcesPropertyList extends cdktn.ComplexList {
        internalValue?: ThroughResourcesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ThroughResourcesPropertyOutputReference;
    }
    interface ExcludePathsProperty {
        /**
        * destination block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#destination TfEc2NetworkInsightsAccessScope#destination}
        */
        readonly destination?: ExcludePathsDestinationProperty[] | cdktn.IResolvable;
        /**
        * source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#source TfEc2NetworkInsightsAccessScope#source}
        */
        readonly source?: ExcludePathsSourceProperty[] | cdktn.IResolvable;
        /**
        * through_resources block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#through_resources TfEc2NetworkInsightsAccessScope#through_resources}
        */
        readonly throughResources?: ThroughResourcesProperty[] | cdktn.IResolvable;
    }
    class ExcludePathsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExcludePathsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ExcludePathsProperty | cdktn.IResolvable | undefined);
        private _destination;
        get destination(): ExcludePathsDestinationPropertyList;
        putDestination(value: ExcludePathsDestinationProperty[] | cdktn.IResolvable): void;
        resetDestination(): void;
        get destinationInput(): cdktn.IResolvable | ExcludePathsDestinationProperty[] | undefined;
        private _source;
        get source(): ExcludePathsSourcePropertyList;
        putSource(value: ExcludePathsSourceProperty[] | cdktn.IResolvable): void;
        resetSource(): void;
        get sourceInput(): cdktn.IResolvable | ExcludePathsSourceProperty[] | undefined;
        private _throughResources;
        get throughResources(): ThroughResourcesPropertyList;
        putThroughResources(value: ThroughResourcesProperty[] | cdktn.IResolvable): void;
        resetThroughResources(): void;
        get throughResourcesInput(): cdktn.IResolvable | ThroughResourcesProperty[] | undefined;
    }
    class ExcludePathsPropertyList extends cdktn.ComplexList {
        internalValue?: ExcludePathsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExcludePathsPropertyOutputReference;
    }
    interface MatchPathsDestinationPacketHeaderStatementProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#destination_addresses TfEc2NetworkInsightsAccessScope#destination_addresses}
        */
        readonly destinationAddresses?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#destination_ports TfEc2NetworkInsightsAccessScope#destination_ports}
        */
        readonly destinationPorts?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#destination_prefix_lists TfEc2NetworkInsightsAccessScope#destination_prefix_lists}
        */
        readonly destinationPrefixLists?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#protocols TfEc2NetworkInsightsAccessScope#protocols}
        */
        readonly protocols?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#source_addresses TfEc2NetworkInsightsAccessScope#source_addresses}
        */
        readonly sourceAddresses?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#source_ports TfEc2NetworkInsightsAccessScope#source_ports}
        */
        readonly sourcePorts?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#source_prefix_lists TfEc2NetworkInsightsAccessScope#source_prefix_lists}
        */
        readonly sourcePrefixLists?: string[];
    }
    class MatchPathsDestinationPacketHeaderStatementPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MatchPathsDestinationPacketHeaderStatementProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MatchPathsDestinationPacketHeaderStatementProperty | cdktn.IResolvable | undefined);
        private _destinationAddresses?;
        get destinationAddresses(): string[];
        set destinationAddresses(value: string[]);
        resetDestinationAddresses(): void;
        get destinationAddressesInput(): string[] | undefined;
        private _destinationPorts?;
        get destinationPorts(): string[];
        set destinationPorts(value: string[]);
        resetDestinationPorts(): void;
        get destinationPortsInput(): string[] | undefined;
        private _destinationPrefixLists?;
        get destinationPrefixLists(): string[];
        set destinationPrefixLists(value: string[]);
        resetDestinationPrefixLists(): void;
        get destinationPrefixListsInput(): string[] | undefined;
        private _protocols?;
        get protocols(): string[];
        set protocols(value: string[]);
        resetProtocols(): void;
        get protocolsInput(): string[] | undefined;
        private _sourceAddresses?;
        get sourceAddresses(): string[];
        set sourceAddresses(value: string[]);
        resetSourceAddresses(): void;
        get sourceAddressesInput(): string[] | undefined;
        private _sourcePorts?;
        get sourcePorts(): string[];
        set sourcePorts(value: string[]);
        resetSourcePorts(): void;
        get sourcePortsInput(): string[] | undefined;
        private _sourcePrefixLists?;
        get sourcePrefixLists(): string[];
        set sourcePrefixLists(value: string[]);
        resetSourcePrefixLists(): void;
        get sourcePrefixListsInput(): string[] | undefined;
    }
    class MatchPathsDestinationPacketHeaderStatementPropertyList extends cdktn.ComplexList {
        internalValue?: MatchPathsDestinationPacketHeaderStatementProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MatchPathsDestinationPacketHeaderStatementPropertyOutputReference;
    }
    interface MatchPathsDestinationResourceStatementProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#resource_types TfEc2NetworkInsightsAccessScope#resource_types}
        */
        readonly resourceTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#resources TfEc2NetworkInsightsAccessScope#resources}
        */
        readonly resources?: string[];
    }
    class MatchPathsDestinationResourceStatementPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MatchPathsDestinationResourceStatementProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MatchPathsDestinationResourceStatementProperty | cdktn.IResolvable | undefined);
        private _resourceTypes?;
        get resourceTypes(): string[];
        set resourceTypes(value: string[]);
        resetResourceTypes(): void;
        get resourceTypesInput(): string[] | undefined;
        private _resources?;
        get resources(): string[];
        set resources(value: string[]);
        resetResources(): void;
        get resourcesInput(): string[] | undefined;
    }
    class MatchPathsDestinationResourceStatementPropertyList extends cdktn.ComplexList {
        internalValue?: MatchPathsDestinationResourceStatementProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MatchPathsDestinationResourceStatementPropertyOutputReference;
    }
    interface MatchPathsDestinationProperty {
        /**
        * packet_header_statement block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#packet_header_statement TfEc2NetworkInsightsAccessScope#packet_header_statement}
        */
        readonly packetHeaderStatement?: MatchPathsDestinationPacketHeaderStatementProperty[] | cdktn.IResolvable;
        /**
        * resource_statement block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#resource_statement TfEc2NetworkInsightsAccessScope#resource_statement}
        */
        readonly resourceStatement?: MatchPathsDestinationResourceStatementProperty[] | cdktn.IResolvable;
    }
    class MatchPathsDestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MatchPathsDestinationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MatchPathsDestinationProperty | cdktn.IResolvable | undefined);
        private _packetHeaderStatement;
        get packetHeaderStatement(): MatchPathsDestinationPacketHeaderStatementPropertyList;
        putPacketHeaderStatement(value: MatchPathsDestinationPacketHeaderStatementProperty[] | cdktn.IResolvable): void;
        resetPacketHeaderStatement(): void;
        get packetHeaderStatementInput(): cdktn.IResolvable | MatchPathsDestinationPacketHeaderStatementProperty[] | undefined;
        private _resourceStatement;
        get resourceStatement(): MatchPathsDestinationResourceStatementPropertyList;
        putResourceStatement(value: MatchPathsDestinationResourceStatementProperty[] | cdktn.IResolvable): void;
        resetResourceStatement(): void;
        get resourceStatementInput(): cdktn.IResolvable | MatchPathsDestinationResourceStatementProperty[] | undefined;
    }
    class MatchPathsDestinationPropertyList extends cdktn.ComplexList {
        internalValue?: MatchPathsDestinationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MatchPathsDestinationPropertyOutputReference;
    }
    interface MatchPathsSourcePacketHeaderStatementProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#destination_addresses TfEc2NetworkInsightsAccessScope#destination_addresses}
        */
        readonly destinationAddresses?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#destination_ports TfEc2NetworkInsightsAccessScope#destination_ports}
        */
        readonly destinationPorts?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#destination_prefix_lists TfEc2NetworkInsightsAccessScope#destination_prefix_lists}
        */
        readonly destinationPrefixLists?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#protocols TfEc2NetworkInsightsAccessScope#protocols}
        */
        readonly protocols?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#source_addresses TfEc2NetworkInsightsAccessScope#source_addresses}
        */
        readonly sourceAddresses?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#source_ports TfEc2NetworkInsightsAccessScope#source_ports}
        */
        readonly sourcePorts?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#source_prefix_lists TfEc2NetworkInsightsAccessScope#source_prefix_lists}
        */
        readonly sourcePrefixLists?: string[];
    }
    class MatchPathsSourcePacketHeaderStatementPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MatchPathsSourcePacketHeaderStatementProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MatchPathsSourcePacketHeaderStatementProperty | cdktn.IResolvable | undefined);
        private _destinationAddresses?;
        get destinationAddresses(): string[];
        set destinationAddresses(value: string[]);
        resetDestinationAddresses(): void;
        get destinationAddressesInput(): string[] | undefined;
        private _destinationPorts?;
        get destinationPorts(): string[];
        set destinationPorts(value: string[]);
        resetDestinationPorts(): void;
        get destinationPortsInput(): string[] | undefined;
        private _destinationPrefixLists?;
        get destinationPrefixLists(): string[];
        set destinationPrefixLists(value: string[]);
        resetDestinationPrefixLists(): void;
        get destinationPrefixListsInput(): string[] | undefined;
        private _protocols?;
        get protocols(): string[];
        set protocols(value: string[]);
        resetProtocols(): void;
        get protocolsInput(): string[] | undefined;
        private _sourceAddresses?;
        get sourceAddresses(): string[];
        set sourceAddresses(value: string[]);
        resetSourceAddresses(): void;
        get sourceAddressesInput(): string[] | undefined;
        private _sourcePorts?;
        get sourcePorts(): string[];
        set sourcePorts(value: string[]);
        resetSourcePorts(): void;
        get sourcePortsInput(): string[] | undefined;
        private _sourcePrefixLists?;
        get sourcePrefixLists(): string[];
        set sourcePrefixLists(value: string[]);
        resetSourcePrefixLists(): void;
        get sourcePrefixListsInput(): string[] | undefined;
    }
    class MatchPathsSourcePacketHeaderStatementPropertyList extends cdktn.ComplexList {
        internalValue?: MatchPathsSourcePacketHeaderStatementProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MatchPathsSourcePacketHeaderStatementPropertyOutputReference;
    }
    interface MatchPathsSourceResourceStatementProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#resource_types TfEc2NetworkInsightsAccessScope#resource_types}
        */
        readonly resourceTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#resources TfEc2NetworkInsightsAccessScope#resources}
        */
        readonly resources?: string[];
    }
    class MatchPathsSourceResourceStatementPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MatchPathsSourceResourceStatementProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MatchPathsSourceResourceStatementProperty | cdktn.IResolvable | undefined);
        private _resourceTypes?;
        get resourceTypes(): string[];
        set resourceTypes(value: string[]);
        resetResourceTypes(): void;
        get resourceTypesInput(): string[] | undefined;
        private _resources?;
        get resources(): string[];
        set resources(value: string[]);
        resetResources(): void;
        get resourcesInput(): string[] | undefined;
    }
    class MatchPathsSourceResourceStatementPropertyList extends cdktn.ComplexList {
        internalValue?: MatchPathsSourceResourceStatementProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MatchPathsSourceResourceStatementPropertyOutputReference;
    }
    interface MatchPathsSourceProperty {
        /**
        * packet_header_statement block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#packet_header_statement TfEc2NetworkInsightsAccessScope#packet_header_statement}
        */
        readonly packetHeaderStatement?: MatchPathsSourcePacketHeaderStatementProperty[] | cdktn.IResolvable;
        /**
        * resource_statement block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#resource_statement TfEc2NetworkInsightsAccessScope#resource_statement}
        */
        readonly resourceStatement?: MatchPathsSourceResourceStatementProperty[] | cdktn.IResolvable;
    }
    class MatchPathsSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MatchPathsSourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MatchPathsSourceProperty | cdktn.IResolvable | undefined);
        private _packetHeaderStatement;
        get packetHeaderStatement(): MatchPathsSourcePacketHeaderStatementPropertyList;
        putPacketHeaderStatement(value: MatchPathsSourcePacketHeaderStatementProperty[] | cdktn.IResolvable): void;
        resetPacketHeaderStatement(): void;
        get packetHeaderStatementInput(): cdktn.IResolvable | MatchPathsSourcePacketHeaderStatementProperty[] | undefined;
        private _resourceStatement;
        get resourceStatement(): MatchPathsSourceResourceStatementPropertyList;
        putResourceStatement(value: MatchPathsSourceResourceStatementProperty[] | cdktn.IResolvable): void;
        resetResourceStatement(): void;
        get resourceStatementInput(): cdktn.IResolvable | MatchPathsSourceResourceStatementProperty[] | undefined;
    }
    class MatchPathsSourcePropertyList extends cdktn.ComplexList {
        internalValue?: MatchPathsSourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MatchPathsSourcePropertyOutputReference;
    }
    interface MatchPathsProperty {
        /**
        * destination block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#destination TfEc2NetworkInsightsAccessScope#destination}
        */
        readonly destination?: MatchPathsDestinationProperty[] | cdktn.IResolvable;
        /**
        * source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_network_insights_access_scope#source TfEc2NetworkInsightsAccessScope#source}
        */
        readonly source?: MatchPathsSourceProperty[] | cdktn.IResolvable;
    }
    class MatchPathsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MatchPathsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MatchPathsProperty | cdktn.IResolvable | undefined);
        private _destination;
        get destination(): MatchPathsDestinationPropertyList;
        putDestination(value: MatchPathsDestinationProperty[] | cdktn.IResolvable): void;
        resetDestination(): void;
        get destinationInput(): cdktn.IResolvable | MatchPathsDestinationProperty[] | undefined;
        private _source;
        get source(): MatchPathsSourcePropertyList;
        putSource(value: MatchPathsSourceProperty[] | cdktn.IResolvable): void;
        resetSource(): void;
        get sourceInput(): cdktn.IResolvable | MatchPathsSourceProperty[] | undefined;
    }
    class MatchPathsPropertyList extends cdktn.ComplexList {
        internalValue?: MatchPathsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MatchPathsPropertyOutputReference;
    }
}
