import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfEc2NetworkInsightsPathConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_network_insights_path#id DataTfEc2NetworkInsightsPath#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_network_insights_path#network_insights_path_id DataTfEc2NetworkInsightsPath#network_insights_path_id}
    */
    readonly networkInsightsPathId?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_network_insights_path#region DataTfEc2NetworkInsightsPath#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_network_insights_path#tags DataTfEc2NetworkInsightsPath#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_network_insights_path#filter DataTfEc2NetworkInsightsPath#filter}
    */
    readonly filter?: DataTfEc2NetworkInsightsPath.FilterProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_network_insights_path aws_ec2_network_insights_path}
*/
export declare class DataTfEc2NetworkInsightsPath extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_ec2_network_insights_path";
    /**
    * Generates CDKTN code for importing a DataTfEc2NetworkInsightsPath resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfEc2NetworkInsightsPath to import
    * @param importFromId The id of the existing DataTfEc2NetworkInsightsPath that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_network_insights_path#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfEc2NetworkInsightsPath to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_network_insights_path aws_ec2_network_insights_path} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfEc2NetworkInsightsPathConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataTfEc2NetworkInsightsPathConfig);
    get arn(): string;
    get destination(): string;
    get destinationArn(): string;
    get destinationIp(): string;
    get destinationPort(): number;
    private _filterAtDestination;
    get filterAtDestination(): DataTfEc2NetworkInsightsPath.FilterAtDestinationPropertyList;
    private _filterAtSource;
    get filterAtSource(): DataTfEc2NetworkInsightsPath.FilterAtSourcePropertyList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _networkInsightsPathId?;
    get networkInsightsPathId(): string;
    set networkInsightsPathId(value: string);
    resetNetworkInsightsPathId(): void;
    get networkInsightsPathIdInput(): string | undefined;
    get protocol(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get source(): string;
    get sourceArn(): string;
    get sourceIp(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _filter;
    get filter(): DataTfEc2NetworkInsightsPath.FilterPropertyList;
    putFilter(value: DataTfEc2NetworkInsightsPath.FilterProperty[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataTfEc2NetworkInsightsPath.FilterProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfEc2NetworkInsightsPathFilterAtDestinationDestinationPortRangePropertyToTerraform(struct?: DataTfEc2NetworkInsightsPath.FilterAtDestinationDestinationPortRangeProperty): any;
export declare function dataTfEc2NetworkInsightsPathFilterAtDestinationDestinationPortRangePropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsPath.FilterAtDestinationDestinationPortRangeProperty): any;
export declare function dataTfEc2NetworkInsightsPathFilterAtDestinationSourcePortRangePropertyToTerraform(struct?: DataTfEc2NetworkInsightsPath.FilterAtDestinationSourcePortRangeProperty): any;
export declare function dataTfEc2NetworkInsightsPathFilterAtDestinationSourcePortRangePropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsPath.FilterAtDestinationSourcePortRangeProperty): any;
export declare function dataTfEc2NetworkInsightsPathFilterAtDestinationPropertyToTerraform(struct?: DataTfEc2NetworkInsightsPath.FilterAtDestinationProperty): any;
export declare function dataTfEc2NetworkInsightsPathFilterAtDestinationPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsPath.FilterAtDestinationProperty): any;
export declare function dataTfEc2NetworkInsightsPathFilterAtSourceDestinationPortRangePropertyToTerraform(struct?: DataTfEc2NetworkInsightsPath.FilterAtSourceDestinationPortRangeProperty): any;
export declare function dataTfEc2NetworkInsightsPathFilterAtSourceDestinationPortRangePropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsPath.FilterAtSourceDestinationPortRangeProperty): any;
export declare function dataTfEc2NetworkInsightsPathFilterAtSourceSourcePortRangePropertyToTerraform(struct?: DataTfEc2NetworkInsightsPath.FilterAtSourceSourcePortRangeProperty): any;
export declare function dataTfEc2NetworkInsightsPathFilterAtSourceSourcePortRangePropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsPath.FilterAtSourceSourcePortRangeProperty): any;
export declare function dataTfEc2NetworkInsightsPathFilterAtSourcePropertyToTerraform(struct?: DataTfEc2NetworkInsightsPath.FilterAtSourceProperty): any;
export declare function dataTfEc2NetworkInsightsPathFilterAtSourcePropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsPath.FilterAtSourceProperty): any;
export declare function dataTfEc2NetworkInsightsPathFilterPropertyToTerraform(struct?: DataTfEc2NetworkInsightsPath.FilterProperty | cdktn.IResolvable): any;
export declare function dataTfEc2NetworkInsightsPathFilterPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsPath.FilterProperty | cdktn.IResolvable): any;
export declare namespace DataTfEc2NetworkInsightsPath {
    interface FilterAtDestinationDestinationPortRangeProperty {
    }
    class FilterAtDestinationDestinationPortRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterAtDestinationDestinationPortRangeProperty | undefined;
        set internalValue(value: FilterAtDestinationDestinationPortRangeProperty | undefined);
        get fromPort(): number;
        get toPort(): number;
    }
    class FilterAtDestinationDestinationPortRangePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterAtDestinationDestinationPortRangePropertyOutputReference;
    }
    interface FilterAtDestinationSourcePortRangeProperty {
    }
    class FilterAtDestinationSourcePortRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterAtDestinationSourcePortRangeProperty | undefined;
        set internalValue(value: FilterAtDestinationSourcePortRangeProperty | undefined);
        get fromPort(): number;
        get toPort(): number;
    }
    class FilterAtDestinationSourcePortRangePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterAtDestinationSourcePortRangePropertyOutputReference;
    }
    interface FilterAtDestinationProperty {
    }
    class FilterAtDestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterAtDestinationProperty | undefined;
        set internalValue(value: FilterAtDestinationProperty | undefined);
        get destinationAddress(): string;
        private _destinationPortRange;
        get destinationPortRange(): FilterAtDestinationDestinationPortRangePropertyList;
        get sourceAddress(): string;
        private _sourcePortRange;
        get sourcePortRange(): FilterAtDestinationSourcePortRangePropertyList;
    }
    class FilterAtDestinationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterAtDestinationPropertyOutputReference;
    }
    interface FilterAtSourceDestinationPortRangeProperty {
    }
    class FilterAtSourceDestinationPortRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterAtSourceDestinationPortRangeProperty | undefined;
        set internalValue(value: FilterAtSourceDestinationPortRangeProperty | undefined);
        get fromPort(): number;
        get toPort(): number;
    }
    class FilterAtSourceDestinationPortRangePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterAtSourceDestinationPortRangePropertyOutputReference;
    }
    interface FilterAtSourceSourcePortRangeProperty {
    }
    class FilterAtSourceSourcePortRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterAtSourceSourcePortRangeProperty | undefined;
        set internalValue(value: FilterAtSourceSourcePortRangeProperty | undefined);
        get fromPort(): number;
        get toPort(): number;
    }
    class FilterAtSourceSourcePortRangePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterAtSourceSourcePortRangePropertyOutputReference;
    }
    interface FilterAtSourceProperty {
    }
    class FilterAtSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterAtSourceProperty | undefined;
        set internalValue(value: FilterAtSourceProperty | undefined);
        get destinationAddress(): string;
        private _destinationPortRange;
        get destinationPortRange(): FilterAtSourceDestinationPortRangePropertyList;
        get sourceAddress(): string;
        private _sourcePortRange;
        get sourcePortRange(): FilterAtSourceSourcePortRangePropertyList;
    }
    class FilterAtSourcePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterAtSourcePropertyOutputReference;
    }
    interface FilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_network_insights_path#name DataTfEc2NetworkInsightsPath#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_network_insights_path#values DataTfEc2NetworkInsightsPath#values}
        */
        readonly values: string[];
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class FilterPropertyList extends cdktn.ComplexList {
        internalValue?: FilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterPropertyOutputReference;
    }
}
