import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfNetworkInterfaceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/network_interface#id DataTfNetworkInterface#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/network_interface#region DataTfNetworkInterface#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/network_interface#tags DataTfNetworkInterface#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/network_interface#filter DataTfNetworkInterface#filter}
    */
    readonly filter?: DataTfNetworkInterface.FilterProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/network_interface#timeouts DataTfNetworkInterface#timeouts}
    */
    readonly timeouts?: DataTfNetworkInterface.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/network_interface aws_network_interface}
*/
export declare class DataTfNetworkInterface extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_network_interface";
    /**
    * Generates CDKTN code for importing a DataTfNetworkInterface resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfNetworkInterface to import
    * @param importFromId The id of the existing DataTfNetworkInterface that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/network_interface#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfNetworkInterface to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/network_interface aws_network_interface} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfNetworkInterfaceConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataTfNetworkInterfaceConfig);
    get arn(): string;
    private _association;
    get association(): DataTfNetworkInterface.AssociationPropertyList;
    private _attachment;
    get attachment(): DataTfNetworkInterface.AttachmentPropertyList;
    get availabilityZone(): string;
    get description(): string;
    private _enaSrdSpecification;
    get enaSrdSpecification(): DataTfNetworkInterface.EnaSrdSpecificationPropertyList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get interfaceType(): string;
    get ipv6Addresses(): string[];
    get macAddress(): string;
    get outpostArn(): string;
    get ownerId(): string;
    get privateDnsName(): string;
    get privateIp(): string;
    get privateIps(): string[];
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get requesterId(): string;
    get securityGroups(): string[];
    get subnetId(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get vpcId(): string;
    private _filter;
    get filter(): DataTfNetworkInterface.FilterPropertyList;
    putFilter(value: DataTfNetworkInterface.FilterProperty[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataTfNetworkInterface.FilterProperty[] | undefined;
    private _timeouts;
    get timeouts(): DataTfNetworkInterface.TimeoutsPropertyOutputReference;
    putTimeouts(value: DataTfNetworkInterface.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataTfNetworkInterface.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfNetworkInterfaceAssociationPropertyToTerraform(struct?: DataTfNetworkInterface.AssociationProperty): any;
export declare function dataTfNetworkInterfaceAssociationPropertyToHclTerraform(struct?: DataTfNetworkInterface.AssociationProperty): any;
export declare function dataTfNetworkInterfaceAttachmentPropertyToTerraform(struct?: DataTfNetworkInterface.AttachmentProperty): any;
export declare function dataTfNetworkInterfaceAttachmentPropertyToHclTerraform(struct?: DataTfNetworkInterface.AttachmentProperty): any;
export declare function dataTfNetworkInterfaceEnaSrdUdpSpecificationPropertyToTerraform(struct?: DataTfNetworkInterface.EnaSrdUdpSpecificationProperty): any;
export declare function dataTfNetworkInterfaceEnaSrdUdpSpecificationPropertyToHclTerraform(struct?: DataTfNetworkInterface.EnaSrdUdpSpecificationProperty): any;
export declare function dataTfNetworkInterfaceEnaSrdSpecificationPropertyToTerraform(struct?: DataTfNetworkInterface.EnaSrdSpecificationProperty): any;
export declare function dataTfNetworkInterfaceEnaSrdSpecificationPropertyToHclTerraform(struct?: DataTfNetworkInterface.EnaSrdSpecificationProperty): any;
export declare function dataTfNetworkInterfaceFilterPropertyToTerraform(struct?: DataTfNetworkInterface.FilterProperty | cdktn.IResolvable): any;
export declare function dataTfNetworkInterfaceFilterPropertyToHclTerraform(struct?: DataTfNetworkInterface.FilterProperty | cdktn.IResolvable): any;
export declare function dataTfNetworkInterfaceTimeoutsPropertyToTerraform(struct?: DataTfNetworkInterface.TimeoutsProperty | cdktn.IResolvable): any;
export declare function dataTfNetworkInterfaceTimeoutsPropertyToHclTerraform(struct?: DataTfNetworkInterface.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace DataTfNetworkInterface {
    interface AssociationProperty {
    }
    class AssociationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AssociationProperty | undefined;
        set internalValue(value: AssociationProperty | undefined);
        get allocationId(): string;
        get associationId(): string;
        get carrierIp(): string;
        get customerOwnedIp(): string;
        get ipOwnerId(): string;
        get publicDnsName(): string;
        get publicIp(): string;
    }
    class AssociationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AssociationPropertyOutputReference;
    }
    interface AttachmentProperty {
    }
    class AttachmentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AttachmentProperty | undefined;
        set internalValue(value: AttachmentProperty | undefined);
        get attachmentId(): string;
        get deviceIndex(): number;
        get instanceId(): string;
        get instanceOwnerId(): string;
        get networkCardIndex(): number;
    }
    class AttachmentPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AttachmentPropertyOutputReference;
    }
    interface EnaSrdUdpSpecificationProperty {
    }
    class EnaSrdUdpSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EnaSrdUdpSpecificationProperty | undefined;
        set internalValue(value: EnaSrdUdpSpecificationProperty | undefined);
        get enaSrdUdpEnabled(): cdktn.IResolvable;
    }
    class EnaSrdUdpSpecificationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EnaSrdUdpSpecificationPropertyOutputReference;
    }
    interface EnaSrdSpecificationProperty {
    }
    class EnaSrdSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EnaSrdSpecificationProperty | undefined;
        set internalValue(value: EnaSrdSpecificationProperty | undefined);
        get enaSrdEnabled(): cdktn.IResolvable;
        private _enaSrdUdpSpecification;
        get enaSrdUdpSpecification(): EnaSrdUdpSpecificationPropertyList;
    }
    class EnaSrdSpecificationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EnaSrdSpecificationPropertyOutputReference;
    }
    interface FilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/network_interface#name DataTfNetworkInterface#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/network_interface#values DataTfNetworkInterface#values}
        */
        readonly values: string[];
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class FilterPropertyList extends cdktn.ComplexList {
        internalValue?: FilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/network_interface#read DataTfNetworkInterface#read}
        */
        readonly read?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _read?;
        get read(): string;
        set read(value: string);
        resetRead(): void;
        get readInput(): string | undefined;
    }
}
