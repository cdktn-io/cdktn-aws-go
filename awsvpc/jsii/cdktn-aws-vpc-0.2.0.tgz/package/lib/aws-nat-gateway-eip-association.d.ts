import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfNatGatewayEipAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/nat_gateway_eip_association#allocation_id TfNatGatewayEipAssociation#allocation_id}
    */
    readonly allocationId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/nat_gateway_eip_association#nat_gateway_id TfNatGatewayEipAssociation#nat_gateway_id}
    */
    readonly natGatewayId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/nat_gateway_eip_association#region TfNatGatewayEipAssociation#region}
    */
    readonly region?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/nat_gateway_eip_association#timeouts TfNatGatewayEipAssociation#timeouts}
    */
    readonly timeouts?: TfNatGatewayEipAssociation.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/nat_gateway_eip_association aws_nat_gateway_eip_association}
*/
export declare class TfNatGatewayEipAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_nat_gateway_eip_association";
    /**
    * Generates CDKTN code for importing a TfNatGatewayEipAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfNatGatewayEipAssociation to import
    * @param importFromId The id of the existing TfNatGatewayEipAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/nat_gateway_eip_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfNatGatewayEipAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/nat_gateway_eip_association aws_nat_gateway_eip_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfNatGatewayEipAssociationConfig
    */
    constructor(scope: Construct, id: string, config: TfNatGatewayEipAssociationConfig);
    private _allocationId?;
    get allocationId(): string;
    set allocationId(value: string);
    get allocationIdInput(): string | undefined;
    get associationId(): string;
    private _natGatewayId?;
    get natGatewayId(): string;
    set natGatewayId(value: string);
    get natGatewayIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _timeouts;
    get timeouts(): TfNatGatewayEipAssociation.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfNatGatewayEipAssociation.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfNatGatewayEipAssociation.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfNatGatewayEipAssociationTimeoutsPropertyToTerraform(struct?: TfNatGatewayEipAssociation.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfNatGatewayEipAssociationTimeoutsPropertyToHclTerraform(struct?: TfNatGatewayEipAssociation.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfNatGatewayEipAssociation {
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/nat_gateway_eip_association#create TfNatGatewayEipAssociation#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/nat_gateway_eip_association#delete TfNatGatewayEipAssociation#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
