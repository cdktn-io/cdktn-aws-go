import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfEc2NetworkInsightsAnalysisConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_network_insights_analysis#id DataTfEc2NetworkInsightsAnalysis#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_network_insights_analysis#network_insights_analysis_id DataTfEc2NetworkInsightsAnalysis#network_insights_analysis_id}
    */
    readonly networkInsightsAnalysisId?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_network_insights_analysis#region DataTfEc2NetworkInsightsAnalysis#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_network_insights_analysis#tags DataTfEc2NetworkInsightsAnalysis#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_network_insights_analysis#filter DataTfEc2NetworkInsightsAnalysis#filter}
    */
    readonly filter?: DataTfEc2NetworkInsightsAnalysis.FilterProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_network_insights_analysis aws_ec2_network_insights_analysis}
*/
export declare class DataTfEc2NetworkInsightsAnalysis extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_ec2_network_insights_analysis";
    /**
    * Generates CDKTN code for importing a DataTfEc2NetworkInsightsAnalysis resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfEc2NetworkInsightsAnalysis to import
    * @param importFromId The id of the existing DataTfEc2NetworkInsightsAnalysis that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_network_insights_analysis#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfEc2NetworkInsightsAnalysis to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_network_insights_analysis aws_ec2_network_insights_analysis} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfEc2NetworkInsightsAnalysisConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataTfEc2NetworkInsightsAnalysisConfig);
    private _alternatePathHints;
    get alternatePathHints(): DataTfEc2NetworkInsightsAnalysis.AlternatePathHintsPropertyList;
    get arn(): string;
    private _explanations;
    get explanations(): DataTfEc2NetworkInsightsAnalysis.ExplanationsPropertyList;
    get filterInArns(): string[];
    private _forwardPathComponents;
    get forwardPathComponents(): DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsPropertyList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _networkInsightsAnalysisId?;
    get networkInsightsAnalysisId(): string;
    set networkInsightsAnalysisId(value: string);
    resetNetworkInsightsAnalysisId(): void;
    get networkInsightsAnalysisIdInput(): string | undefined;
    get networkInsightsPathId(): string;
    get pathFound(): cdktn.IResolvable;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _returnPathComponents;
    get returnPathComponents(): DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsPropertyList;
    get startDate(): string;
    get status(): string;
    get statusMessage(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get warningMessage(): string;
    private _filter;
    get filter(): DataTfEc2NetworkInsightsAnalysis.FilterPropertyList;
    putFilter(value: DataTfEc2NetworkInsightsAnalysis.FilterProperty[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataTfEc2NetworkInsightsAnalysis.FilterProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfEc2NetworkInsightsAnalysisAlternatePathHintsPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.AlternatePathHintsProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisAlternatePathHintsPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.AlternatePathHintsProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisAclPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.AclProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisAclPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.AclProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisExplanationsAclRulePortRangePropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ExplanationsAclRulePortRangeProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisExplanationsAclRulePortRangePropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ExplanationsAclRulePortRangeProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisExplanationsAclRulePropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ExplanationsAclRuleProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisExplanationsAclRulePropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ExplanationsAclRuleProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisExplanationsAttachedToPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ExplanationsAttachedToProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisExplanationsAttachedToPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ExplanationsAttachedToProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisClassicLoadBalancerListenerPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ClassicLoadBalancerListenerProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisClassicLoadBalancerListenerPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ClassicLoadBalancerListenerProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisExplanationsComponentPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ExplanationsComponentProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisExplanationsComponentPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ExplanationsComponentProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisCustomerGatewayPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.CustomerGatewayProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisCustomerGatewayPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.CustomerGatewayProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisDestinationPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.DestinationProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisDestinationPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.DestinationProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisExplanationsDestinationVpcPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ExplanationsDestinationVpcProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisExplanationsDestinationVpcPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ExplanationsDestinationVpcProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisElasticLoadBalancerListenerPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ElasticLoadBalancerListenerProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisElasticLoadBalancerListenerPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ElasticLoadBalancerListenerProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisIngressRouteTablePropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.IngressRouteTableProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisIngressRouteTablePropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.IngressRouteTableProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisInternetGatewayPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.InternetGatewayProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisInternetGatewayPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.InternetGatewayProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisLoadBalancerTargetGroupPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.LoadBalancerTargetGroupProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisLoadBalancerTargetGroupPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.LoadBalancerTargetGroupProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisLoadBalancerTargetGroupsPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.LoadBalancerTargetGroupsProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisLoadBalancerTargetGroupsPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.LoadBalancerTargetGroupsProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisNatGatewayPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.NatGatewayProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisNatGatewayPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.NatGatewayProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisNetworkInterfacePropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.NetworkInterfaceProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisNetworkInterfacePropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.NetworkInterfaceProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisPortRangesPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.PortRangesProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisPortRangesPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.PortRangesProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisPrefixListPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.PrefixListProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisPrefixListPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.PrefixListProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisRouteTablePropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.RouteTableProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisRouteTablePropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.RouteTableProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisExplanationsRouteTableRoutePropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ExplanationsRouteTableRouteProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisExplanationsRouteTableRoutePropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ExplanationsRouteTableRouteProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisSecurityGroupPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.SecurityGroupProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisSecurityGroupPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.SecurityGroupProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisExplanationsSecurityGroupRulePortRangePropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ExplanationsSecurityGroupRulePortRangeProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisExplanationsSecurityGroupRulePortRangePropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ExplanationsSecurityGroupRulePortRangeProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisExplanationsSecurityGroupRulePropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ExplanationsSecurityGroupRuleProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisExplanationsSecurityGroupRulePropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ExplanationsSecurityGroupRuleProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisSecurityGroupsPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.SecurityGroupsProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisSecurityGroupsPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.SecurityGroupsProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisExplanationsSourceVpcPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ExplanationsSourceVpcProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisExplanationsSourceVpcPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ExplanationsSourceVpcProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisExplanationsSubnetPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ExplanationsSubnetProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisExplanationsSubnetPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ExplanationsSubnetProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisSubnetRouteTablePropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.SubnetRouteTableProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisSubnetRouteTablePropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.SubnetRouteTableProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisExplanationsTransitGatewayPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ExplanationsTransitGatewayProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisExplanationsTransitGatewayPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ExplanationsTransitGatewayProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisTransitGatewayAttachmentPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.TransitGatewayAttachmentProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisTransitGatewayAttachmentPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.TransitGatewayAttachmentProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisTransitGatewayRouteTablePropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.TransitGatewayRouteTableProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisTransitGatewayRouteTablePropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.TransitGatewayRouteTableProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisExplanationsTransitGatewayRouteTableRoutePropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ExplanationsTransitGatewayRouteTableRouteProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisExplanationsTransitGatewayRouteTableRoutePropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ExplanationsTransitGatewayRouteTableRouteProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisExplanationsVpcPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ExplanationsVpcProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisExplanationsVpcPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ExplanationsVpcProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisVpcEndpointPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.VpcEndpointProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisVpcEndpointPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.VpcEndpointProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisVpcPeeringConnectionPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.VpcPeeringConnectionProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisVpcPeeringConnectionPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.VpcPeeringConnectionProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisVpnConnectionPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.VpnConnectionProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisVpnConnectionPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.VpnConnectionProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisVpnGatewayPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.VpnGatewayProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisVpnGatewayPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.VpnGatewayProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisExplanationsPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ExplanationsProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisExplanationsPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ExplanationsProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisForwardPathComponentsAclRulePortRangePropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsAclRulePortRangeProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisForwardPathComponentsAclRulePortRangePropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsAclRulePortRangeProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisForwardPathComponentsAclRulePropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsAclRuleProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisForwardPathComponentsAclRulePropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsAclRuleProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisForwardPathComponentsAdditionalDetailsComponentPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsAdditionalDetailsComponentProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisForwardPathComponentsAdditionalDetailsComponentPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsAdditionalDetailsComponentProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisForwardPathComponentsAdditionalDetailsPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsAdditionalDetailsProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisForwardPathComponentsAdditionalDetailsPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsAdditionalDetailsProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisForwardPathComponentsAttachedToPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsAttachedToProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisForwardPathComponentsAttachedToPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsAttachedToProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisForwardPathComponentsComponentPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsComponentProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisForwardPathComponentsComponentPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsComponentProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisForwardPathComponentsDestinationVpcPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsDestinationVpcProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisForwardPathComponentsDestinationVpcPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsDestinationVpcProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisForwardPathComponentsInboundHeaderDestinationPortRangesPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsInboundHeaderDestinationPortRangesProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisForwardPathComponentsInboundHeaderDestinationPortRangesPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsInboundHeaderDestinationPortRangesProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisForwardPathComponentsInboundHeaderSourcePortRangesPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsInboundHeaderSourcePortRangesProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisForwardPathComponentsInboundHeaderSourcePortRangesPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsInboundHeaderSourcePortRangesProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisForwardPathComponentsInboundHeaderPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsInboundHeaderProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisForwardPathComponentsInboundHeaderPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsInboundHeaderProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisForwardPathComponentsOutboundHeaderDestinationPortRangesPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsOutboundHeaderDestinationPortRangesProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisForwardPathComponentsOutboundHeaderDestinationPortRangesPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsOutboundHeaderDestinationPortRangesProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisForwardPathComponentsOutboundHeaderSourcePortRangesPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsOutboundHeaderSourcePortRangesProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisForwardPathComponentsOutboundHeaderSourcePortRangesPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsOutboundHeaderSourcePortRangesProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisForwardPathComponentsOutboundHeaderPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsOutboundHeaderProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisForwardPathComponentsOutboundHeaderPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsOutboundHeaderProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisForwardPathComponentsRouteTableRoutePropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsRouteTableRouteProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisForwardPathComponentsRouteTableRoutePropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsRouteTableRouteProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisForwardPathComponentsSecurityGroupRulePortRangePropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsSecurityGroupRulePortRangeProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisForwardPathComponentsSecurityGroupRulePortRangePropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsSecurityGroupRulePortRangeProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisForwardPathComponentsSecurityGroupRulePropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsSecurityGroupRuleProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisForwardPathComponentsSecurityGroupRulePropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsSecurityGroupRuleProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisForwardPathComponentsSourceVpcPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsSourceVpcProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisForwardPathComponentsSourceVpcPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsSourceVpcProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisForwardPathComponentsSubnetPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsSubnetProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisForwardPathComponentsSubnetPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsSubnetProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisForwardPathComponentsTransitGatewayPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsTransitGatewayProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisForwardPathComponentsTransitGatewayPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsTransitGatewayProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisForwardPathComponentsTransitGatewayRouteTableRoutePropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsTransitGatewayRouteTableRouteProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisForwardPathComponentsTransitGatewayRouteTableRoutePropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsTransitGatewayRouteTableRouteProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisForwardPathComponentsVpcPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsVpcProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisForwardPathComponentsVpcPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsVpcProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisForwardPathComponentsPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisForwardPathComponentsPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ForwardPathComponentsProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisReturnPathComponentsAclRulePortRangePropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsAclRulePortRangeProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisReturnPathComponentsAclRulePortRangePropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsAclRulePortRangeProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisReturnPathComponentsAclRulePropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsAclRuleProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisReturnPathComponentsAclRulePropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsAclRuleProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisReturnPathComponentsAdditionalDetailsComponentPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsAdditionalDetailsComponentProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisReturnPathComponentsAdditionalDetailsComponentPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsAdditionalDetailsComponentProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisReturnPathComponentsAdditionalDetailsPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsAdditionalDetailsProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisReturnPathComponentsAdditionalDetailsPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsAdditionalDetailsProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisReturnPathComponentsAttachedToPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsAttachedToProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisReturnPathComponentsAttachedToPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsAttachedToProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisReturnPathComponentsComponentPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsComponentProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisReturnPathComponentsComponentPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsComponentProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisReturnPathComponentsDestinationVpcPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsDestinationVpcProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisReturnPathComponentsDestinationVpcPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsDestinationVpcProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisReturnPathComponentsInboundHeaderDestinationPortRangesPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsInboundHeaderDestinationPortRangesProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisReturnPathComponentsInboundHeaderDestinationPortRangesPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsInboundHeaderDestinationPortRangesProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisReturnPathComponentsInboundHeaderSourcePortRangesPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsInboundHeaderSourcePortRangesProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisReturnPathComponentsInboundHeaderSourcePortRangesPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsInboundHeaderSourcePortRangesProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisReturnPathComponentsInboundHeaderPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsInboundHeaderProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisReturnPathComponentsInboundHeaderPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsInboundHeaderProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisReturnPathComponentsOutboundHeaderDestinationPortRangesPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsOutboundHeaderDestinationPortRangesProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisReturnPathComponentsOutboundHeaderDestinationPortRangesPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsOutboundHeaderDestinationPortRangesProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisReturnPathComponentsOutboundHeaderSourcePortRangesPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsOutboundHeaderSourcePortRangesProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisReturnPathComponentsOutboundHeaderSourcePortRangesPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsOutboundHeaderSourcePortRangesProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisReturnPathComponentsOutboundHeaderPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsOutboundHeaderProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisReturnPathComponentsOutboundHeaderPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsOutboundHeaderProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisReturnPathComponentsRouteTableRoutePropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsRouteTableRouteProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisReturnPathComponentsRouteTableRoutePropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsRouteTableRouteProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisReturnPathComponentsSecurityGroupRulePortRangePropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsSecurityGroupRulePortRangeProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisReturnPathComponentsSecurityGroupRulePortRangePropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsSecurityGroupRulePortRangeProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisReturnPathComponentsSecurityGroupRulePropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsSecurityGroupRuleProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisReturnPathComponentsSecurityGroupRulePropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsSecurityGroupRuleProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisReturnPathComponentsSourceVpcPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsSourceVpcProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisReturnPathComponentsSourceVpcPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsSourceVpcProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisReturnPathComponentsSubnetPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsSubnetProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisReturnPathComponentsSubnetPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsSubnetProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisReturnPathComponentsTransitGatewayPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsTransitGatewayProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisReturnPathComponentsTransitGatewayPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsTransitGatewayProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisReturnPathComponentsTransitGatewayRouteTableRoutePropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsTransitGatewayRouteTableRouteProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisReturnPathComponentsTransitGatewayRouteTableRoutePropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsTransitGatewayRouteTableRouteProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisReturnPathComponentsVpcPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsVpcProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisReturnPathComponentsVpcPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsVpcProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisReturnPathComponentsPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisReturnPathComponentsPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.ReturnPathComponentsProperty): any;
export declare function dataTfEc2NetworkInsightsAnalysisFilterPropertyToTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.FilterProperty | cdktn.IResolvable): any;
export declare function dataTfEc2NetworkInsightsAnalysisFilterPropertyToHclTerraform(struct?: DataTfEc2NetworkInsightsAnalysis.FilterProperty | cdktn.IResolvable): any;
export declare namespace DataTfEc2NetworkInsightsAnalysis {
    interface AlternatePathHintsProperty {
    }
    class AlternatePathHintsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AlternatePathHintsProperty | undefined;
        set internalValue(value: AlternatePathHintsProperty | undefined);
        get componentArn(): string;
        get componentId(): string;
    }
    class AlternatePathHintsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AlternatePathHintsPropertyOutputReference;
    }
    interface AclProperty {
    }
    class AclPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AclProperty | undefined;
        set internalValue(value: AclProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class AclPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AclPropertyOutputReference;
    }
    interface ExplanationsAclRulePortRangeProperty {
    }
    class ExplanationsAclRulePortRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExplanationsAclRulePortRangeProperty | undefined;
        set internalValue(value: ExplanationsAclRulePortRangeProperty | undefined);
        get from(): number;
        get to(): number;
    }
    class ExplanationsAclRulePortRangePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExplanationsAclRulePortRangePropertyOutputReference;
    }
    interface ExplanationsAclRuleProperty {
    }
    class ExplanationsAclRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExplanationsAclRuleProperty | undefined;
        set internalValue(value: ExplanationsAclRuleProperty | undefined);
        get cidr(): string;
        get egress(): cdktn.IResolvable;
        private _portRange;
        get portRange(): ExplanationsAclRulePortRangePropertyList;
        get protocol(): string;
        get ruleAction(): string;
        get ruleNumber(): number;
    }
    class ExplanationsAclRulePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExplanationsAclRulePropertyOutputReference;
    }
    interface ExplanationsAttachedToProperty {
    }
    class ExplanationsAttachedToPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExplanationsAttachedToProperty | undefined;
        set internalValue(value: ExplanationsAttachedToProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ExplanationsAttachedToPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExplanationsAttachedToPropertyOutputReference;
    }
    interface ClassicLoadBalancerListenerProperty {
    }
    class ClassicLoadBalancerListenerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ClassicLoadBalancerListenerProperty | undefined;
        set internalValue(value: ClassicLoadBalancerListenerProperty | undefined);
        get instancePort(): number;
        get loadBalancerPort(): number;
    }
    class ClassicLoadBalancerListenerPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ClassicLoadBalancerListenerPropertyOutputReference;
    }
    interface ExplanationsComponentProperty {
    }
    class ExplanationsComponentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExplanationsComponentProperty | undefined;
        set internalValue(value: ExplanationsComponentProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ExplanationsComponentPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExplanationsComponentPropertyOutputReference;
    }
    interface CustomerGatewayProperty {
    }
    class CustomerGatewayPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomerGatewayProperty | undefined;
        set internalValue(value: CustomerGatewayProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class CustomerGatewayPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomerGatewayPropertyOutputReference;
    }
    interface DestinationProperty {
    }
    class DestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DestinationProperty | undefined;
        set internalValue(value: DestinationProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class DestinationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DestinationPropertyOutputReference;
    }
    interface ExplanationsDestinationVpcProperty {
    }
    class ExplanationsDestinationVpcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExplanationsDestinationVpcProperty | undefined;
        set internalValue(value: ExplanationsDestinationVpcProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ExplanationsDestinationVpcPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExplanationsDestinationVpcPropertyOutputReference;
    }
    interface ElasticLoadBalancerListenerProperty {
    }
    class ElasticLoadBalancerListenerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ElasticLoadBalancerListenerProperty | undefined;
        set internalValue(value: ElasticLoadBalancerListenerProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ElasticLoadBalancerListenerPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ElasticLoadBalancerListenerPropertyOutputReference;
    }
    interface IngressRouteTableProperty {
    }
    class IngressRouteTablePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IngressRouteTableProperty | undefined;
        set internalValue(value: IngressRouteTableProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class IngressRouteTablePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IngressRouteTablePropertyOutputReference;
    }
    interface InternetGatewayProperty {
    }
    class InternetGatewayPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InternetGatewayProperty | undefined;
        set internalValue(value: InternetGatewayProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class InternetGatewayPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InternetGatewayPropertyOutputReference;
    }
    interface LoadBalancerTargetGroupProperty {
    }
    class LoadBalancerTargetGroupPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LoadBalancerTargetGroupProperty | undefined;
        set internalValue(value: LoadBalancerTargetGroupProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class LoadBalancerTargetGroupPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LoadBalancerTargetGroupPropertyOutputReference;
    }
    interface LoadBalancerTargetGroupsProperty {
    }
    class LoadBalancerTargetGroupsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LoadBalancerTargetGroupsProperty | undefined;
        set internalValue(value: LoadBalancerTargetGroupsProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class LoadBalancerTargetGroupsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LoadBalancerTargetGroupsPropertyOutputReference;
    }
    interface NatGatewayProperty {
    }
    class NatGatewayPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NatGatewayProperty | undefined;
        set internalValue(value: NatGatewayProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class NatGatewayPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NatGatewayPropertyOutputReference;
    }
    interface NetworkInterfaceProperty {
    }
    class NetworkInterfacePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkInterfaceProperty | undefined;
        set internalValue(value: NetworkInterfaceProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class NetworkInterfacePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkInterfacePropertyOutputReference;
    }
    interface PortRangesProperty {
    }
    class PortRangesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PortRangesProperty | undefined;
        set internalValue(value: PortRangesProperty | undefined);
        get from(): number;
        get to(): number;
    }
    class PortRangesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PortRangesPropertyOutputReference;
    }
    interface PrefixListProperty {
    }
    class PrefixListPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PrefixListProperty | undefined;
        set internalValue(value: PrefixListProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class PrefixListPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PrefixListPropertyOutputReference;
    }
    interface RouteTableProperty {
    }
    class RouteTablePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RouteTableProperty | undefined;
        set internalValue(value: RouteTableProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class RouteTablePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RouteTablePropertyOutputReference;
    }
    interface ExplanationsRouteTableRouteProperty {
    }
    class ExplanationsRouteTableRoutePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExplanationsRouteTableRouteProperty | undefined;
        set internalValue(value: ExplanationsRouteTableRouteProperty | undefined);
        get destinationCidr(): string;
        get destinationPrefixListId(): string;
        get egressOnlyInternetGatewayId(): string;
        get gatewayId(): string;
        get instanceId(): string;
        get natGatewayId(): string;
        get networkInterfaceId(): string;
        get origin(): string;
        get transitGatewayId(): string;
        get vpcPeeringConnectionId(): string;
    }
    class ExplanationsRouteTableRoutePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExplanationsRouteTableRoutePropertyOutputReference;
    }
    interface SecurityGroupProperty {
    }
    class SecurityGroupPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SecurityGroupProperty | undefined;
        set internalValue(value: SecurityGroupProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class SecurityGroupPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SecurityGroupPropertyOutputReference;
    }
    interface ExplanationsSecurityGroupRulePortRangeProperty {
    }
    class ExplanationsSecurityGroupRulePortRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExplanationsSecurityGroupRulePortRangeProperty | undefined;
        set internalValue(value: ExplanationsSecurityGroupRulePortRangeProperty | undefined);
        get from(): number;
        get to(): number;
    }
    class ExplanationsSecurityGroupRulePortRangePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExplanationsSecurityGroupRulePortRangePropertyOutputReference;
    }
    interface ExplanationsSecurityGroupRuleProperty {
    }
    class ExplanationsSecurityGroupRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExplanationsSecurityGroupRuleProperty | undefined;
        set internalValue(value: ExplanationsSecurityGroupRuleProperty | undefined);
        get cidr(): string;
        get direction(): string;
        private _portRange;
        get portRange(): ExplanationsSecurityGroupRulePortRangePropertyList;
        get prefixListId(): string;
        get protocol(): string;
        get securityGroupId(): string;
    }
    class ExplanationsSecurityGroupRulePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExplanationsSecurityGroupRulePropertyOutputReference;
    }
    interface SecurityGroupsProperty {
    }
    class SecurityGroupsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SecurityGroupsProperty | undefined;
        set internalValue(value: SecurityGroupsProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class SecurityGroupsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SecurityGroupsPropertyOutputReference;
    }
    interface ExplanationsSourceVpcProperty {
    }
    class ExplanationsSourceVpcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExplanationsSourceVpcProperty | undefined;
        set internalValue(value: ExplanationsSourceVpcProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ExplanationsSourceVpcPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExplanationsSourceVpcPropertyOutputReference;
    }
    interface ExplanationsSubnetProperty {
    }
    class ExplanationsSubnetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExplanationsSubnetProperty | undefined;
        set internalValue(value: ExplanationsSubnetProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ExplanationsSubnetPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExplanationsSubnetPropertyOutputReference;
    }
    interface SubnetRouteTableProperty {
    }
    class SubnetRouteTablePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SubnetRouteTableProperty | undefined;
        set internalValue(value: SubnetRouteTableProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class SubnetRouteTablePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SubnetRouteTablePropertyOutputReference;
    }
    interface ExplanationsTransitGatewayProperty {
    }
    class ExplanationsTransitGatewayPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExplanationsTransitGatewayProperty | undefined;
        set internalValue(value: ExplanationsTransitGatewayProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ExplanationsTransitGatewayPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExplanationsTransitGatewayPropertyOutputReference;
    }
    interface TransitGatewayAttachmentProperty {
    }
    class TransitGatewayAttachmentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TransitGatewayAttachmentProperty | undefined;
        set internalValue(value: TransitGatewayAttachmentProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class TransitGatewayAttachmentPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TransitGatewayAttachmentPropertyOutputReference;
    }
    interface TransitGatewayRouteTableProperty {
    }
    class TransitGatewayRouteTablePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TransitGatewayRouteTableProperty | undefined;
        set internalValue(value: TransitGatewayRouteTableProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class TransitGatewayRouteTablePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TransitGatewayRouteTablePropertyOutputReference;
    }
    interface ExplanationsTransitGatewayRouteTableRouteProperty {
    }
    class ExplanationsTransitGatewayRouteTableRoutePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExplanationsTransitGatewayRouteTableRouteProperty | undefined;
        set internalValue(value: ExplanationsTransitGatewayRouteTableRouteProperty | undefined);
        get attachmentId(): string;
        get destinationCidr(): string;
        get prefixListId(): string;
        get resourceId(): string;
        get resourceType(): string;
        get routeOrigin(): string;
        get state(): string;
    }
    class ExplanationsTransitGatewayRouteTableRoutePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExplanationsTransitGatewayRouteTableRoutePropertyOutputReference;
    }
    interface ExplanationsVpcProperty {
    }
    class ExplanationsVpcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExplanationsVpcProperty | undefined;
        set internalValue(value: ExplanationsVpcProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ExplanationsVpcPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExplanationsVpcPropertyOutputReference;
    }
    interface VpcEndpointProperty {
    }
    class VpcEndpointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpcEndpointProperty | undefined;
        set internalValue(value: VpcEndpointProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class VpcEndpointPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpcEndpointPropertyOutputReference;
    }
    interface VpcPeeringConnectionProperty {
    }
    class VpcPeeringConnectionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpcPeeringConnectionProperty | undefined;
        set internalValue(value: VpcPeeringConnectionProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class VpcPeeringConnectionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpcPeeringConnectionPropertyOutputReference;
    }
    interface VpnConnectionProperty {
    }
    class VpnConnectionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpnConnectionProperty | undefined;
        set internalValue(value: VpnConnectionProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class VpnConnectionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpnConnectionPropertyOutputReference;
    }
    interface VpnGatewayProperty {
    }
    class VpnGatewayPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpnGatewayProperty | undefined;
        set internalValue(value: VpnGatewayProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class VpnGatewayPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpnGatewayPropertyOutputReference;
    }
    interface ExplanationsProperty {
    }
    class ExplanationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExplanationsProperty | undefined;
        set internalValue(value: ExplanationsProperty | undefined);
        private _acl;
        get acl(): AclPropertyList;
        private _aclRule;
        get aclRule(): ExplanationsAclRulePropertyList;
        get address(): string;
        get addresses(): string[];
        private _attachedTo;
        get attachedTo(): ExplanationsAttachedToPropertyList;
        get availabilityZones(): string[];
        get cidrs(): string[];
        private _classicLoadBalancerListener;
        get classicLoadBalancerListener(): ClassicLoadBalancerListenerPropertyList;
        private _component;
        get component(): ExplanationsComponentPropertyList;
        private _customerGateway;
        get customerGateway(): CustomerGatewayPropertyList;
        private _destination;
        get destination(): DestinationPropertyList;
        private _destinationVpc;
        get destinationVpc(): ExplanationsDestinationVpcPropertyList;
        get direction(): string;
        private _elasticLoadBalancerListener;
        get elasticLoadBalancerListener(): ElasticLoadBalancerListenerPropertyList;
        get explanationCode(): string;
        private _ingressRouteTable;
        get ingressRouteTable(): IngressRouteTablePropertyList;
        private _internetGateway;
        get internetGateway(): InternetGatewayPropertyList;
        get loadBalancerArn(): string;
        get loadBalancerListenerPort(): number;
        private _loadBalancerTargetGroup;
        get loadBalancerTargetGroup(): LoadBalancerTargetGroupPropertyList;
        private _loadBalancerTargetGroups;
        get loadBalancerTargetGroups(): LoadBalancerTargetGroupsPropertyList;
        get loadBalancerTargetPort(): number;
        get missingComponent(): string;
        private _natGateway;
        get natGateway(): NatGatewayPropertyList;
        private _networkInterface;
        get networkInterface(): NetworkInterfacePropertyList;
        get packetField(): string;
        get port(): number;
        private _portRanges;
        get portRanges(): PortRangesPropertyList;
        private _prefixList;
        get prefixList(): PrefixListPropertyList;
        get protocols(): string[];
        private _routeTable;
        get routeTable(): RouteTablePropertyList;
        private _routeTableRoute;
        get routeTableRoute(): ExplanationsRouteTableRoutePropertyList;
        private _securityGroup;
        get securityGroup(): SecurityGroupPropertyList;
        private _securityGroupRule;
        get securityGroupRule(): ExplanationsSecurityGroupRulePropertyList;
        private _securityGroups;
        get securityGroups(): SecurityGroupsPropertyList;
        private _sourceVpc;
        get sourceVpc(): ExplanationsSourceVpcPropertyList;
        get state(): string;
        private _subnet;
        get subnet(): ExplanationsSubnetPropertyList;
        private _subnetRouteTable;
        get subnetRouteTable(): SubnetRouteTablePropertyList;
        private _transitGateway;
        get transitGateway(): ExplanationsTransitGatewayPropertyList;
        private _transitGatewayAttachment;
        get transitGatewayAttachment(): TransitGatewayAttachmentPropertyList;
        private _transitGatewayRouteTable;
        get transitGatewayRouteTable(): TransitGatewayRouteTablePropertyList;
        private _transitGatewayRouteTableRoute;
        get transitGatewayRouteTableRoute(): ExplanationsTransitGatewayRouteTableRoutePropertyList;
        private _vpc;
        get vpc(): ExplanationsVpcPropertyList;
        private _vpcEndpoint;
        get vpcEndpoint(): VpcEndpointPropertyList;
        private _vpcPeeringConnection;
        get vpcPeeringConnection(): VpcPeeringConnectionPropertyList;
        private _vpnConnection;
        get vpnConnection(): VpnConnectionPropertyList;
        private _vpnGateway;
        get vpnGateway(): VpnGatewayPropertyList;
    }
    class ExplanationsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExplanationsPropertyOutputReference;
    }
    interface ForwardPathComponentsAclRulePortRangeProperty {
    }
    class ForwardPathComponentsAclRulePortRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardPathComponentsAclRulePortRangeProperty | undefined;
        set internalValue(value: ForwardPathComponentsAclRulePortRangeProperty | undefined);
        get from(): number;
        get to(): number;
    }
    class ForwardPathComponentsAclRulePortRangePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPathComponentsAclRulePortRangePropertyOutputReference;
    }
    interface ForwardPathComponentsAclRuleProperty {
    }
    class ForwardPathComponentsAclRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardPathComponentsAclRuleProperty | undefined;
        set internalValue(value: ForwardPathComponentsAclRuleProperty | undefined);
        get cidr(): string;
        get egress(): cdktn.IResolvable;
        private _portRange;
        get portRange(): ForwardPathComponentsAclRulePortRangePropertyList;
        get protocol(): string;
        get ruleAction(): string;
        get ruleNumber(): number;
    }
    class ForwardPathComponentsAclRulePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPathComponentsAclRulePropertyOutputReference;
    }
    interface ForwardPathComponentsAdditionalDetailsComponentProperty {
    }
    class ForwardPathComponentsAdditionalDetailsComponentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardPathComponentsAdditionalDetailsComponentProperty | undefined;
        set internalValue(value: ForwardPathComponentsAdditionalDetailsComponentProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ForwardPathComponentsAdditionalDetailsComponentPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPathComponentsAdditionalDetailsComponentPropertyOutputReference;
    }
    interface ForwardPathComponentsAdditionalDetailsProperty {
    }
    class ForwardPathComponentsAdditionalDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardPathComponentsAdditionalDetailsProperty | undefined;
        set internalValue(value: ForwardPathComponentsAdditionalDetailsProperty | undefined);
        get additionalDetailType(): string;
        private _component;
        get component(): ForwardPathComponentsAdditionalDetailsComponentPropertyList;
    }
    class ForwardPathComponentsAdditionalDetailsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPathComponentsAdditionalDetailsPropertyOutputReference;
    }
    interface ForwardPathComponentsAttachedToProperty {
    }
    class ForwardPathComponentsAttachedToPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardPathComponentsAttachedToProperty | undefined;
        set internalValue(value: ForwardPathComponentsAttachedToProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ForwardPathComponentsAttachedToPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPathComponentsAttachedToPropertyOutputReference;
    }
    interface ForwardPathComponentsComponentProperty {
    }
    class ForwardPathComponentsComponentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardPathComponentsComponentProperty | undefined;
        set internalValue(value: ForwardPathComponentsComponentProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ForwardPathComponentsComponentPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPathComponentsComponentPropertyOutputReference;
    }
    interface ForwardPathComponentsDestinationVpcProperty {
    }
    class ForwardPathComponentsDestinationVpcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardPathComponentsDestinationVpcProperty | undefined;
        set internalValue(value: ForwardPathComponentsDestinationVpcProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ForwardPathComponentsDestinationVpcPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPathComponentsDestinationVpcPropertyOutputReference;
    }
    interface ForwardPathComponentsInboundHeaderDestinationPortRangesProperty {
    }
    class ForwardPathComponentsInboundHeaderDestinationPortRangesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardPathComponentsInboundHeaderDestinationPortRangesProperty | undefined;
        set internalValue(value: ForwardPathComponentsInboundHeaderDestinationPortRangesProperty | undefined);
        get from(): number;
        get to(): number;
    }
    class ForwardPathComponentsInboundHeaderDestinationPortRangesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPathComponentsInboundHeaderDestinationPortRangesPropertyOutputReference;
    }
    interface ForwardPathComponentsInboundHeaderSourcePortRangesProperty {
    }
    class ForwardPathComponentsInboundHeaderSourcePortRangesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardPathComponentsInboundHeaderSourcePortRangesProperty | undefined;
        set internalValue(value: ForwardPathComponentsInboundHeaderSourcePortRangesProperty | undefined);
        get from(): number;
        get to(): number;
    }
    class ForwardPathComponentsInboundHeaderSourcePortRangesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPathComponentsInboundHeaderSourcePortRangesPropertyOutputReference;
    }
    interface ForwardPathComponentsInboundHeaderProperty {
    }
    class ForwardPathComponentsInboundHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardPathComponentsInboundHeaderProperty | undefined;
        set internalValue(value: ForwardPathComponentsInboundHeaderProperty | undefined);
        get destinationAddresses(): string[];
        private _destinationPortRanges;
        get destinationPortRanges(): ForwardPathComponentsInboundHeaderDestinationPortRangesPropertyList;
        get protocol(): string;
        get sourceAddresses(): string[];
        private _sourcePortRanges;
        get sourcePortRanges(): ForwardPathComponentsInboundHeaderSourcePortRangesPropertyList;
    }
    class ForwardPathComponentsInboundHeaderPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPathComponentsInboundHeaderPropertyOutputReference;
    }
    interface ForwardPathComponentsOutboundHeaderDestinationPortRangesProperty {
    }
    class ForwardPathComponentsOutboundHeaderDestinationPortRangesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardPathComponentsOutboundHeaderDestinationPortRangesProperty | undefined;
        set internalValue(value: ForwardPathComponentsOutboundHeaderDestinationPortRangesProperty | undefined);
        get from(): number;
        get to(): number;
    }
    class ForwardPathComponentsOutboundHeaderDestinationPortRangesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPathComponentsOutboundHeaderDestinationPortRangesPropertyOutputReference;
    }
    interface ForwardPathComponentsOutboundHeaderSourcePortRangesProperty {
    }
    class ForwardPathComponentsOutboundHeaderSourcePortRangesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardPathComponentsOutboundHeaderSourcePortRangesProperty | undefined;
        set internalValue(value: ForwardPathComponentsOutboundHeaderSourcePortRangesProperty | undefined);
        get from(): number;
        get to(): number;
    }
    class ForwardPathComponentsOutboundHeaderSourcePortRangesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPathComponentsOutboundHeaderSourcePortRangesPropertyOutputReference;
    }
    interface ForwardPathComponentsOutboundHeaderProperty {
    }
    class ForwardPathComponentsOutboundHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardPathComponentsOutboundHeaderProperty | undefined;
        set internalValue(value: ForwardPathComponentsOutboundHeaderProperty | undefined);
        get destinationAddresses(): string[];
        private _destinationPortRanges;
        get destinationPortRanges(): ForwardPathComponentsOutboundHeaderDestinationPortRangesPropertyList;
        get protocol(): string;
        get sourceAddresses(): string[];
        private _sourcePortRanges;
        get sourcePortRanges(): ForwardPathComponentsOutboundHeaderSourcePortRangesPropertyList;
    }
    class ForwardPathComponentsOutboundHeaderPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPathComponentsOutboundHeaderPropertyOutputReference;
    }
    interface ForwardPathComponentsRouteTableRouteProperty {
    }
    class ForwardPathComponentsRouteTableRoutePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardPathComponentsRouteTableRouteProperty | undefined;
        set internalValue(value: ForwardPathComponentsRouteTableRouteProperty | undefined);
        get destinationCidr(): string;
        get destinationPrefixListId(): string;
        get egressOnlyInternetGatewayId(): string;
        get gatewayId(): string;
        get instanceId(): string;
        get natGatewayId(): string;
        get networkInterfaceId(): string;
        get origin(): string;
        get transitGatewayId(): string;
        get vpcPeeringConnectionId(): string;
    }
    class ForwardPathComponentsRouteTableRoutePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPathComponentsRouteTableRoutePropertyOutputReference;
    }
    interface ForwardPathComponentsSecurityGroupRulePortRangeProperty {
    }
    class ForwardPathComponentsSecurityGroupRulePortRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardPathComponentsSecurityGroupRulePortRangeProperty | undefined;
        set internalValue(value: ForwardPathComponentsSecurityGroupRulePortRangeProperty | undefined);
        get from(): number;
        get to(): number;
    }
    class ForwardPathComponentsSecurityGroupRulePortRangePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPathComponentsSecurityGroupRulePortRangePropertyOutputReference;
    }
    interface ForwardPathComponentsSecurityGroupRuleProperty {
    }
    class ForwardPathComponentsSecurityGroupRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardPathComponentsSecurityGroupRuleProperty | undefined;
        set internalValue(value: ForwardPathComponentsSecurityGroupRuleProperty | undefined);
        get cidr(): string;
        get direction(): string;
        private _portRange;
        get portRange(): ForwardPathComponentsSecurityGroupRulePortRangePropertyList;
        get prefixListId(): string;
        get protocol(): string;
        get securityGroupId(): string;
    }
    class ForwardPathComponentsSecurityGroupRulePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPathComponentsSecurityGroupRulePropertyOutputReference;
    }
    interface ForwardPathComponentsSourceVpcProperty {
    }
    class ForwardPathComponentsSourceVpcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardPathComponentsSourceVpcProperty | undefined;
        set internalValue(value: ForwardPathComponentsSourceVpcProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ForwardPathComponentsSourceVpcPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPathComponentsSourceVpcPropertyOutputReference;
    }
    interface ForwardPathComponentsSubnetProperty {
    }
    class ForwardPathComponentsSubnetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardPathComponentsSubnetProperty | undefined;
        set internalValue(value: ForwardPathComponentsSubnetProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ForwardPathComponentsSubnetPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPathComponentsSubnetPropertyOutputReference;
    }
    interface ForwardPathComponentsTransitGatewayProperty {
    }
    class ForwardPathComponentsTransitGatewayPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardPathComponentsTransitGatewayProperty | undefined;
        set internalValue(value: ForwardPathComponentsTransitGatewayProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ForwardPathComponentsTransitGatewayPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPathComponentsTransitGatewayPropertyOutputReference;
    }
    interface ForwardPathComponentsTransitGatewayRouteTableRouteProperty {
    }
    class ForwardPathComponentsTransitGatewayRouteTableRoutePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardPathComponentsTransitGatewayRouteTableRouteProperty | undefined;
        set internalValue(value: ForwardPathComponentsTransitGatewayRouteTableRouteProperty | undefined);
        get attachmentId(): string;
        get destinationCidr(): string;
        get prefixListId(): string;
        get resourceId(): string;
        get resourceType(): string;
        get routeOrigin(): string;
        get state(): string;
    }
    class ForwardPathComponentsTransitGatewayRouteTableRoutePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPathComponentsTransitGatewayRouteTableRoutePropertyOutputReference;
    }
    interface ForwardPathComponentsVpcProperty {
    }
    class ForwardPathComponentsVpcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardPathComponentsVpcProperty | undefined;
        set internalValue(value: ForwardPathComponentsVpcProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ForwardPathComponentsVpcPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPathComponentsVpcPropertyOutputReference;
    }
    interface ForwardPathComponentsProperty {
    }
    class ForwardPathComponentsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ForwardPathComponentsProperty | undefined;
        set internalValue(value: ForwardPathComponentsProperty | undefined);
        private _aclRule;
        get aclRule(): ForwardPathComponentsAclRulePropertyList;
        private _additionalDetails;
        get additionalDetails(): ForwardPathComponentsAdditionalDetailsPropertyList;
        private _attachedTo;
        get attachedTo(): ForwardPathComponentsAttachedToPropertyList;
        private _component;
        get component(): ForwardPathComponentsComponentPropertyList;
        private _destinationVpc;
        get destinationVpc(): ForwardPathComponentsDestinationVpcPropertyList;
        private _inboundHeader;
        get inboundHeader(): ForwardPathComponentsInboundHeaderPropertyList;
        private _outboundHeader;
        get outboundHeader(): ForwardPathComponentsOutboundHeaderPropertyList;
        private _routeTableRoute;
        get routeTableRoute(): ForwardPathComponentsRouteTableRoutePropertyList;
        private _securityGroupRule;
        get securityGroupRule(): ForwardPathComponentsSecurityGroupRulePropertyList;
        get sequenceNumber(): number;
        private _sourceVpc;
        get sourceVpc(): ForwardPathComponentsSourceVpcPropertyList;
        private _subnet;
        get subnet(): ForwardPathComponentsSubnetPropertyList;
        private _transitGateway;
        get transitGateway(): ForwardPathComponentsTransitGatewayPropertyList;
        private _transitGatewayRouteTableRoute;
        get transitGatewayRouteTableRoute(): ForwardPathComponentsTransitGatewayRouteTableRoutePropertyList;
        private _vpc;
        get vpc(): ForwardPathComponentsVpcPropertyList;
    }
    class ForwardPathComponentsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ForwardPathComponentsPropertyOutputReference;
    }
    interface ReturnPathComponentsAclRulePortRangeProperty {
    }
    class ReturnPathComponentsAclRulePortRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReturnPathComponentsAclRulePortRangeProperty | undefined;
        set internalValue(value: ReturnPathComponentsAclRulePortRangeProperty | undefined);
        get from(): number;
        get to(): number;
    }
    class ReturnPathComponentsAclRulePortRangePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReturnPathComponentsAclRulePortRangePropertyOutputReference;
    }
    interface ReturnPathComponentsAclRuleProperty {
    }
    class ReturnPathComponentsAclRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReturnPathComponentsAclRuleProperty | undefined;
        set internalValue(value: ReturnPathComponentsAclRuleProperty | undefined);
        get cidr(): string;
        get egress(): cdktn.IResolvable;
        private _portRange;
        get portRange(): ReturnPathComponentsAclRulePortRangePropertyList;
        get protocol(): string;
        get ruleAction(): string;
        get ruleNumber(): number;
    }
    class ReturnPathComponentsAclRulePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReturnPathComponentsAclRulePropertyOutputReference;
    }
    interface ReturnPathComponentsAdditionalDetailsComponentProperty {
    }
    class ReturnPathComponentsAdditionalDetailsComponentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReturnPathComponentsAdditionalDetailsComponentProperty | undefined;
        set internalValue(value: ReturnPathComponentsAdditionalDetailsComponentProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ReturnPathComponentsAdditionalDetailsComponentPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReturnPathComponentsAdditionalDetailsComponentPropertyOutputReference;
    }
    interface ReturnPathComponentsAdditionalDetailsProperty {
    }
    class ReturnPathComponentsAdditionalDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReturnPathComponentsAdditionalDetailsProperty | undefined;
        set internalValue(value: ReturnPathComponentsAdditionalDetailsProperty | undefined);
        get additionalDetailType(): string;
        private _component;
        get component(): ReturnPathComponentsAdditionalDetailsComponentPropertyList;
    }
    class ReturnPathComponentsAdditionalDetailsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReturnPathComponentsAdditionalDetailsPropertyOutputReference;
    }
    interface ReturnPathComponentsAttachedToProperty {
    }
    class ReturnPathComponentsAttachedToPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReturnPathComponentsAttachedToProperty | undefined;
        set internalValue(value: ReturnPathComponentsAttachedToProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ReturnPathComponentsAttachedToPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReturnPathComponentsAttachedToPropertyOutputReference;
    }
    interface ReturnPathComponentsComponentProperty {
    }
    class ReturnPathComponentsComponentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReturnPathComponentsComponentProperty | undefined;
        set internalValue(value: ReturnPathComponentsComponentProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ReturnPathComponentsComponentPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReturnPathComponentsComponentPropertyOutputReference;
    }
    interface ReturnPathComponentsDestinationVpcProperty {
    }
    class ReturnPathComponentsDestinationVpcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReturnPathComponentsDestinationVpcProperty | undefined;
        set internalValue(value: ReturnPathComponentsDestinationVpcProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ReturnPathComponentsDestinationVpcPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReturnPathComponentsDestinationVpcPropertyOutputReference;
    }
    interface ReturnPathComponentsInboundHeaderDestinationPortRangesProperty {
    }
    class ReturnPathComponentsInboundHeaderDestinationPortRangesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReturnPathComponentsInboundHeaderDestinationPortRangesProperty | undefined;
        set internalValue(value: ReturnPathComponentsInboundHeaderDestinationPortRangesProperty | undefined);
        get from(): number;
        get to(): number;
    }
    class ReturnPathComponentsInboundHeaderDestinationPortRangesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReturnPathComponentsInboundHeaderDestinationPortRangesPropertyOutputReference;
    }
    interface ReturnPathComponentsInboundHeaderSourcePortRangesProperty {
    }
    class ReturnPathComponentsInboundHeaderSourcePortRangesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReturnPathComponentsInboundHeaderSourcePortRangesProperty | undefined;
        set internalValue(value: ReturnPathComponentsInboundHeaderSourcePortRangesProperty | undefined);
        get from(): number;
        get to(): number;
    }
    class ReturnPathComponentsInboundHeaderSourcePortRangesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReturnPathComponentsInboundHeaderSourcePortRangesPropertyOutputReference;
    }
    interface ReturnPathComponentsInboundHeaderProperty {
    }
    class ReturnPathComponentsInboundHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReturnPathComponentsInboundHeaderProperty | undefined;
        set internalValue(value: ReturnPathComponentsInboundHeaderProperty | undefined);
        get destinationAddresses(): string[];
        private _destinationPortRanges;
        get destinationPortRanges(): ReturnPathComponentsInboundHeaderDestinationPortRangesPropertyList;
        get protocol(): string;
        get sourceAddresses(): string[];
        private _sourcePortRanges;
        get sourcePortRanges(): ReturnPathComponentsInboundHeaderSourcePortRangesPropertyList;
    }
    class ReturnPathComponentsInboundHeaderPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReturnPathComponentsInboundHeaderPropertyOutputReference;
    }
    interface ReturnPathComponentsOutboundHeaderDestinationPortRangesProperty {
    }
    class ReturnPathComponentsOutboundHeaderDestinationPortRangesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReturnPathComponentsOutboundHeaderDestinationPortRangesProperty | undefined;
        set internalValue(value: ReturnPathComponentsOutboundHeaderDestinationPortRangesProperty | undefined);
        get from(): number;
        get to(): number;
    }
    class ReturnPathComponentsOutboundHeaderDestinationPortRangesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReturnPathComponentsOutboundHeaderDestinationPortRangesPropertyOutputReference;
    }
    interface ReturnPathComponentsOutboundHeaderSourcePortRangesProperty {
    }
    class ReturnPathComponentsOutboundHeaderSourcePortRangesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReturnPathComponentsOutboundHeaderSourcePortRangesProperty | undefined;
        set internalValue(value: ReturnPathComponentsOutboundHeaderSourcePortRangesProperty | undefined);
        get from(): number;
        get to(): number;
    }
    class ReturnPathComponentsOutboundHeaderSourcePortRangesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReturnPathComponentsOutboundHeaderSourcePortRangesPropertyOutputReference;
    }
    interface ReturnPathComponentsOutboundHeaderProperty {
    }
    class ReturnPathComponentsOutboundHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReturnPathComponentsOutboundHeaderProperty | undefined;
        set internalValue(value: ReturnPathComponentsOutboundHeaderProperty | undefined);
        get destinationAddresses(): string[];
        private _destinationPortRanges;
        get destinationPortRanges(): ReturnPathComponentsOutboundHeaderDestinationPortRangesPropertyList;
        get protocol(): string;
        get sourceAddresses(): string[];
        private _sourcePortRanges;
        get sourcePortRanges(): ReturnPathComponentsOutboundHeaderSourcePortRangesPropertyList;
    }
    class ReturnPathComponentsOutboundHeaderPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReturnPathComponentsOutboundHeaderPropertyOutputReference;
    }
    interface ReturnPathComponentsRouteTableRouteProperty {
    }
    class ReturnPathComponentsRouteTableRoutePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReturnPathComponentsRouteTableRouteProperty | undefined;
        set internalValue(value: ReturnPathComponentsRouteTableRouteProperty | undefined);
        get destinationCidr(): string;
        get destinationPrefixListId(): string;
        get egressOnlyInternetGatewayId(): string;
        get gatewayId(): string;
        get instanceId(): string;
        get natGatewayId(): string;
        get networkInterfaceId(): string;
        get origin(): string;
        get transitGatewayId(): string;
        get vpcPeeringConnectionId(): string;
    }
    class ReturnPathComponentsRouteTableRoutePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReturnPathComponentsRouteTableRoutePropertyOutputReference;
    }
    interface ReturnPathComponentsSecurityGroupRulePortRangeProperty {
    }
    class ReturnPathComponentsSecurityGroupRulePortRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReturnPathComponentsSecurityGroupRulePortRangeProperty | undefined;
        set internalValue(value: ReturnPathComponentsSecurityGroupRulePortRangeProperty | undefined);
        get from(): number;
        get to(): number;
    }
    class ReturnPathComponentsSecurityGroupRulePortRangePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReturnPathComponentsSecurityGroupRulePortRangePropertyOutputReference;
    }
    interface ReturnPathComponentsSecurityGroupRuleProperty {
    }
    class ReturnPathComponentsSecurityGroupRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReturnPathComponentsSecurityGroupRuleProperty | undefined;
        set internalValue(value: ReturnPathComponentsSecurityGroupRuleProperty | undefined);
        get cidr(): string;
        get direction(): string;
        private _portRange;
        get portRange(): ReturnPathComponentsSecurityGroupRulePortRangePropertyList;
        get prefixListId(): string;
        get protocol(): string;
        get securityGroupId(): string;
    }
    class ReturnPathComponentsSecurityGroupRulePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReturnPathComponentsSecurityGroupRulePropertyOutputReference;
    }
    interface ReturnPathComponentsSourceVpcProperty {
    }
    class ReturnPathComponentsSourceVpcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReturnPathComponentsSourceVpcProperty | undefined;
        set internalValue(value: ReturnPathComponentsSourceVpcProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ReturnPathComponentsSourceVpcPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReturnPathComponentsSourceVpcPropertyOutputReference;
    }
    interface ReturnPathComponentsSubnetProperty {
    }
    class ReturnPathComponentsSubnetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReturnPathComponentsSubnetProperty | undefined;
        set internalValue(value: ReturnPathComponentsSubnetProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ReturnPathComponentsSubnetPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReturnPathComponentsSubnetPropertyOutputReference;
    }
    interface ReturnPathComponentsTransitGatewayProperty {
    }
    class ReturnPathComponentsTransitGatewayPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReturnPathComponentsTransitGatewayProperty | undefined;
        set internalValue(value: ReturnPathComponentsTransitGatewayProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ReturnPathComponentsTransitGatewayPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReturnPathComponentsTransitGatewayPropertyOutputReference;
    }
    interface ReturnPathComponentsTransitGatewayRouteTableRouteProperty {
    }
    class ReturnPathComponentsTransitGatewayRouteTableRoutePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReturnPathComponentsTransitGatewayRouteTableRouteProperty | undefined;
        set internalValue(value: ReturnPathComponentsTransitGatewayRouteTableRouteProperty | undefined);
        get attachmentId(): string;
        get destinationCidr(): string;
        get prefixListId(): string;
        get resourceId(): string;
        get resourceType(): string;
        get routeOrigin(): string;
        get state(): string;
    }
    class ReturnPathComponentsTransitGatewayRouteTableRoutePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReturnPathComponentsTransitGatewayRouteTableRoutePropertyOutputReference;
    }
    interface ReturnPathComponentsVpcProperty {
    }
    class ReturnPathComponentsVpcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReturnPathComponentsVpcProperty | undefined;
        set internalValue(value: ReturnPathComponentsVpcProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
    }
    class ReturnPathComponentsVpcPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReturnPathComponentsVpcPropertyOutputReference;
    }
    interface ReturnPathComponentsProperty {
    }
    class ReturnPathComponentsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReturnPathComponentsProperty | undefined;
        set internalValue(value: ReturnPathComponentsProperty | undefined);
        private _aclRule;
        get aclRule(): ReturnPathComponentsAclRulePropertyList;
        private _additionalDetails;
        get additionalDetails(): ReturnPathComponentsAdditionalDetailsPropertyList;
        private _attachedTo;
        get attachedTo(): ReturnPathComponentsAttachedToPropertyList;
        private _component;
        get component(): ReturnPathComponentsComponentPropertyList;
        private _destinationVpc;
        get destinationVpc(): ReturnPathComponentsDestinationVpcPropertyList;
        private _inboundHeader;
        get inboundHeader(): ReturnPathComponentsInboundHeaderPropertyList;
        private _outboundHeader;
        get outboundHeader(): ReturnPathComponentsOutboundHeaderPropertyList;
        private _routeTableRoute;
        get routeTableRoute(): ReturnPathComponentsRouteTableRoutePropertyList;
        private _securityGroupRule;
        get securityGroupRule(): ReturnPathComponentsSecurityGroupRulePropertyList;
        get sequenceNumber(): number;
        private _sourceVpc;
        get sourceVpc(): ReturnPathComponentsSourceVpcPropertyList;
        private _subnet;
        get subnet(): ReturnPathComponentsSubnetPropertyList;
        private _transitGateway;
        get transitGateway(): ReturnPathComponentsTransitGatewayPropertyList;
        private _transitGatewayRouteTableRoute;
        get transitGatewayRouteTableRoute(): ReturnPathComponentsTransitGatewayRouteTableRoutePropertyList;
        private _vpc;
        get vpc(): ReturnPathComponentsVpcPropertyList;
    }
    class ReturnPathComponentsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReturnPathComponentsPropertyOutputReference;
    }
    interface FilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_network_insights_analysis#name DataTfEc2NetworkInsightsAnalysis#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_network_insights_analysis#values DataTfEc2NetworkInsightsAnalysis#values}
        */
        readonly values: string[];
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class FilterPropertyList extends cdktn.ComplexList {
        internalValue?: FilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterPropertyOutputReference;
    }
}
