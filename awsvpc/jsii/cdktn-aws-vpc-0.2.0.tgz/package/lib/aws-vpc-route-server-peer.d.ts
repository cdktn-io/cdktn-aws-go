import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfRouteServerPeerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_route_server_peer#peer_address TfRouteServerPeer#peer_address}
    */
    readonly peerAddress: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_route_server_peer#region TfRouteServerPeer#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_route_server_peer#route_server_endpoint_id TfRouteServerPeer#route_server_endpoint_id}
    */
    readonly routeServerEndpointId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_route_server_peer#tags TfRouteServerPeer#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * bgp_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_route_server_peer#bgp_options TfRouteServerPeer#bgp_options}
    */
    readonly bgpOptions?: TfRouteServerPeer.BgpOptionsProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_route_server_peer#timeouts TfRouteServerPeer#timeouts}
    */
    readonly timeouts?: TfRouteServerPeer.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_route_server_peer aws_vpc_route_server_peer}
*/
export declare class TfRouteServerPeer extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_vpc_route_server_peer";
    /**
    * Generates CDKTN code for importing a TfRouteServerPeer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfRouteServerPeer to import
    * @param importFromId The id of the existing TfRouteServerPeer that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_route_server_peer#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfRouteServerPeer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_route_server_peer aws_vpc_route_server_peer} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfRouteServerPeerConfig
    */
    constructor(scope: Construct, id: string, config: TfRouteServerPeerConfig);
    get arn(): string;
    get endpointEniAddress(): string;
    get endpointEniId(): string;
    private _peerAddress?;
    get peerAddress(): string;
    set peerAddress(value: string);
    get peerAddressInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _routeServerEndpointId?;
    get routeServerEndpointId(): string;
    set routeServerEndpointId(value: string);
    get routeServerEndpointIdInput(): string | undefined;
    get routeServerId(): string;
    get routeServerPeerId(): string;
    get subnetId(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    get vpcId(): string;
    private _bgpOptions;
    get bgpOptions(): TfRouteServerPeer.BgpOptionsPropertyList;
    putBgpOptions(value: TfRouteServerPeer.BgpOptionsProperty[] | cdktn.IResolvable): void;
    resetBgpOptions(): void;
    get bgpOptionsInput(): cdktn.IResolvable | TfRouteServerPeer.BgpOptionsProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfRouteServerPeer.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfRouteServerPeer.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfRouteServerPeer.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfRouteServerPeerBgpOptionsPropertyToTerraform(struct?: TfRouteServerPeer.BgpOptionsProperty | cdktn.IResolvable): any;
export declare function tfRouteServerPeerBgpOptionsPropertyToHclTerraform(struct?: TfRouteServerPeer.BgpOptionsProperty | cdktn.IResolvable): any;
export declare function tfRouteServerPeerTimeoutsPropertyToTerraform(struct?: TfRouteServerPeer.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfRouteServerPeerTimeoutsPropertyToHclTerraform(struct?: TfRouteServerPeer.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfRouteServerPeer {
    interface BgpOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_route_server_peer#peer_asn TfRouteServerPeer#peer_asn}
        */
        readonly peerAsn: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_route_server_peer#peer_liveness_detection TfRouteServerPeer#peer_liveness_detection}
        */
        readonly peerLivenessDetection?: string;
    }
    class BgpOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BgpOptionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: BgpOptionsProperty | cdktn.IResolvable | undefined);
        private _peerAsn?;
        get peerAsn(): number;
        set peerAsn(value: number);
        get peerAsnInput(): number | undefined;
        private _peerLivenessDetection?;
        get peerLivenessDetection(): string;
        set peerLivenessDetection(value: string);
        resetPeerLivenessDetection(): void;
        get peerLivenessDetectionInput(): string | undefined;
    }
    class BgpOptionsPropertyList extends cdktn.ComplexList {
        internalValue?: BgpOptionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BgpOptionsPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_route_server_peer#create TfRouteServerPeer#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_route_server_peer#delete TfRouteServerPeer#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
