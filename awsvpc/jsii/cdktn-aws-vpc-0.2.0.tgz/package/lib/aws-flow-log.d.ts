import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfFlowLogConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/flow_log#deliver_cross_account_role TfFlowLog#deliver_cross_account_role}
    */
    readonly deliverCrossAccountRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/flow_log#eni_id TfFlowLog#eni_id}
    */
    readonly eniId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/flow_log#iam_role_arn TfFlowLog#iam_role_arn}
    */
    readonly iamRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/flow_log#id TfFlowLog#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/flow_log#log_destination TfFlowLog#log_destination}
    */
    readonly logDestination?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/flow_log#log_destination_type TfFlowLog#log_destination_type}
    */
    readonly logDestinationType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/flow_log#log_format TfFlowLog#log_format}
    */
    readonly logFormat?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/flow_log#max_aggregation_interval TfFlowLog#max_aggregation_interval}
    */
    readonly maxAggregationInterval?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/flow_log#region TfFlowLog#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/flow_log#regional_nat_gateway_id TfFlowLog#regional_nat_gateway_id}
    */
    readonly regionalNatGatewayId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/flow_log#subnet_id TfFlowLog#subnet_id}
    */
    readonly subnetId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/flow_log#tags TfFlowLog#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/flow_log#tags_all TfFlowLog#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/flow_log#traffic_type TfFlowLog#traffic_type}
    */
    readonly trafficType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/flow_log#transit_gateway_attachment_id TfFlowLog#transit_gateway_attachment_id}
    */
    readonly transitGatewayAttachmentId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/flow_log#transit_gateway_id TfFlowLog#transit_gateway_id}
    */
    readonly transitGatewayId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/flow_log#vpc_id TfFlowLog#vpc_id}
    */
    readonly vpcId?: string;
    /**
    * destination_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/flow_log#destination_options TfFlowLog#destination_options}
    */
    readonly destinationOptions?: TfFlowLog.DestinationOptionsProperty;
    /**
    * tag_field_specification block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/flow_log#tag_field_specification TfFlowLog#tag_field_specification}
    */
    readonly tagFieldSpecification?: TfFlowLog.TagFieldSpecificationProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/flow_log aws_flow_log}
*/
export declare class TfFlowLog extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_flow_log";
    /**
    * Generates CDKTN code for importing a TfFlowLog resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfFlowLog to import
    * @param importFromId The id of the existing TfFlowLog that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/flow_log#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfFlowLog to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/flow_log aws_flow_log} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfFlowLogConfig = {}
    */
    constructor(scope: Construct, id: string, config?: TfFlowLogConfig);
    get arn(): string;
    private _deliverCrossAccountRole?;
    get deliverCrossAccountRole(): string;
    set deliverCrossAccountRole(value: string);
    resetDeliverCrossAccountRole(): void;
    get deliverCrossAccountRoleInput(): string | undefined;
    private _eniId?;
    get eniId(): string;
    set eniId(value: string);
    resetEniId(): void;
    get eniIdInput(): string | undefined;
    private _iamRoleArn?;
    get iamRoleArn(): string;
    set iamRoleArn(value: string);
    resetIamRoleArn(): void;
    get iamRoleArnInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _logDestination?;
    get logDestination(): string;
    set logDestination(value: string);
    resetLogDestination(): void;
    get logDestinationInput(): string | undefined;
    private _logDestinationType?;
    get logDestinationType(): string;
    set logDestinationType(value: string);
    resetLogDestinationType(): void;
    get logDestinationTypeInput(): string | undefined;
    private _logFormat?;
    get logFormat(): string;
    set logFormat(value: string);
    resetLogFormat(): void;
    get logFormatInput(): string | undefined;
    private _maxAggregationInterval?;
    get maxAggregationInterval(): number;
    set maxAggregationInterval(value: number);
    resetMaxAggregationInterval(): void;
    get maxAggregationIntervalInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _regionalNatGatewayId?;
    get regionalNatGatewayId(): string;
    set regionalNatGatewayId(value: string);
    resetRegionalNatGatewayId(): void;
    get regionalNatGatewayIdInput(): string | undefined;
    private _subnetId?;
    get subnetId(): string;
    set subnetId(value: string);
    resetSubnetId(): void;
    get subnetIdInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _trafficType?;
    get trafficType(): string;
    set trafficType(value: string);
    resetTrafficType(): void;
    get trafficTypeInput(): string | undefined;
    private _transitGatewayAttachmentId?;
    get transitGatewayAttachmentId(): string;
    set transitGatewayAttachmentId(value: string);
    resetTransitGatewayAttachmentId(): void;
    get transitGatewayAttachmentIdInput(): string | undefined;
    private _transitGatewayId?;
    get transitGatewayId(): string;
    set transitGatewayId(value: string);
    resetTransitGatewayId(): void;
    get transitGatewayIdInput(): string | undefined;
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    resetVpcId(): void;
    get vpcIdInput(): string | undefined;
    private _destinationOptions;
    get destinationOptions(): TfFlowLog.DestinationOptionsPropertyOutputReference;
    putDestinationOptions(value: TfFlowLog.DestinationOptionsProperty): void;
    resetDestinationOptions(): void;
    get destinationOptionsInput(): TfFlowLog.DestinationOptionsProperty | undefined;
    private _tagFieldSpecification;
    get tagFieldSpecification(): TfFlowLog.TagFieldSpecificationPropertyList;
    putTagFieldSpecification(value: TfFlowLog.TagFieldSpecificationProperty[] | cdktn.IResolvable): void;
    resetTagFieldSpecification(): void;
    get tagFieldSpecificationInput(): cdktn.IResolvable | TfFlowLog.TagFieldSpecificationProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfFlowLogDestinationOptionsPropertyToTerraform(struct?: TfFlowLog.DestinationOptionsPropertyOutputReference | TfFlowLog.DestinationOptionsProperty): any;
export declare function tfFlowLogDestinationOptionsPropertyToHclTerraform(struct?: TfFlowLog.DestinationOptionsPropertyOutputReference | TfFlowLog.DestinationOptionsProperty): any;
export declare function tfFlowLogTagFieldSpecificationPropertyToTerraform(struct?: TfFlowLog.TagFieldSpecificationProperty | cdktn.IResolvable): any;
export declare function tfFlowLogTagFieldSpecificationPropertyToHclTerraform(struct?: TfFlowLog.TagFieldSpecificationProperty | cdktn.IResolvable): any;
export declare namespace TfFlowLog {
    interface DestinationOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/flow_log#file_format TfFlowLog#file_format}
        */
        readonly fileFormat?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/flow_log#hive_compatible_partitions TfFlowLog#hive_compatible_partitions}
        */
        readonly hiveCompatiblePartitions?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/flow_log#per_hour_partition TfFlowLog#per_hour_partition}
        */
        readonly perHourPartition?: boolean | cdktn.IResolvable;
    }
    class DestinationOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationOptionsProperty | undefined;
        set internalValue(value: DestinationOptionsProperty | undefined);
        private _fileFormat?;
        get fileFormat(): string;
        set fileFormat(value: string);
        resetFileFormat(): void;
        get fileFormatInput(): string | undefined;
        private _hiveCompatiblePartitions?;
        get hiveCompatiblePartitions(): boolean | cdktn.IResolvable;
        set hiveCompatiblePartitions(value: boolean | cdktn.IResolvable);
        resetHiveCompatiblePartitions(): void;
        get hiveCompatiblePartitionsInput(): boolean | cdktn.IResolvable | undefined;
        private _perHourPartition?;
        get perHourPartition(): boolean | cdktn.IResolvable;
        set perHourPartition(value: boolean | cdktn.IResolvable);
        resetPerHourPartition(): void;
        get perHourPartitionInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface TagFieldSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/flow_log#resource_type TfFlowLog#resource_type}
        */
        readonly resourceType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/flow_log#tag_keys TfFlowLog#tag_keys}
        */
        readonly tagKeys: string[];
    }
    class TagFieldSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TagFieldSpecificationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TagFieldSpecificationProperty | cdktn.IResolvable | undefined);
        private _resourceType?;
        get resourceType(): string;
        set resourceType(value: string);
        get resourceTypeInput(): string | undefined;
        private _tagKeys?;
        get tagKeys(): string[];
        set tagKeys(value: string[]);
        get tagKeysInput(): string[] | undefined;
    }
    class TagFieldSpecificationPropertyList extends cdktn.ComplexList {
        internalValue?: TagFieldSpecificationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TagFieldSpecificationPropertyOutputReference;
    }
}
