import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAnalyzerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_analyzer#analyzer_name AwsAnalyzer#analyzer_name}
    */
    readonly analyzerName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_analyzer#id AwsAnalyzer#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_analyzer#region AwsAnalyzer#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_analyzer#tags AwsAnalyzer#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_analyzer#tags_all AwsAnalyzer#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_analyzer#type AwsAnalyzer#type}
    */
    readonly type?: string;
    /**
    * configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_analyzer#configuration AwsAnalyzer#configuration}
    */
    readonly configuration?: AwsAnalyzer.ConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_analyzer aws_accessanalyzer_analyzer}
*/
export declare class AwsAnalyzer extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_accessanalyzer_analyzer";
    /**
    * Generates CDKTN code for importing a AwsAnalyzer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAnalyzer to import
    * @param importFromId The id of the existing AwsAnalyzer that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_analyzer#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAnalyzer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_analyzer aws_accessanalyzer_analyzer} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAnalyzerConfig
    */
    constructor(scope: Construct, id: string, config: AwsAnalyzerConfig);
    private _analyzerName?;
    get analyzerName(): string;
    set analyzerName(value: string);
    get analyzerNameInput(): string | undefined;
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _configuration;
    get configuration(): AwsAnalyzer.ConfigurationPropertyOutputReference;
    putConfiguration(value: AwsAnalyzer.ConfigurationProperty): void;
    resetConfiguration(): void;
    get configurationInput(): AwsAnalyzer.ConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsAnalyzerInclusionPropertyToTerraform(struct?: AwsAnalyzer.InclusionProperty | cdktn.IResolvable): any;
export declare function awsAnalyzerInclusionPropertyToHclTerraform(struct?: AwsAnalyzer.InclusionProperty | cdktn.IResolvable): any;
export declare function awsAnalyzerConfigurationInternalAccessAnalysisRulePropertyToTerraform(struct?: AwsAnalyzer.ConfigurationInternalAccessAnalysisRulePropertyOutputReference | AwsAnalyzer.ConfigurationInternalAccessAnalysisRuleProperty): any;
export declare function awsAnalyzerConfigurationInternalAccessAnalysisRulePropertyToHclTerraform(struct?: AwsAnalyzer.ConfigurationInternalAccessAnalysisRulePropertyOutputReference | AwsAnalyzer.ConfigurationInternalAccessAnalysisRuleProperty): any;
export declare function awsAnalyzerInternalAccessPropertyToTerraform(struct?: AwsAnalyzer.InternalAccessPropertyOutputReference | AwsAnalyzer.InternalAccessProperty): any;
export declare function awsAnalyzerInternalAccessPropertyToHclTerraform(struct?: AwsAnalyzer.InternalAccessPropertyOutputReference | AwsAnalyzer.InternalAccessProperty): any;
export declare function awsAnalyzerExclusionPropertyToTerraform(struct?: AwsAnalyzer.ExclusionProperty | cdktn.IResolvable): any;
export declare function awsAnalyzerExclusionPropertyToHclTerraform(struct?: AwsAnalyzer.ExclusionProperty | cdktn.IResolvable): any;
export declare function awsAnalyzerConfigurationUnusedAccessAnalysisRulePropertyToTerraform(struct?: AwsAnalyzer.ConfigurationUnusedAccessAnalysisRulePropertyOutputReference | AwsAnalyzer.ConfigurationUnusedAccessAnalysisRuleProperty): any;
export declare function awsAnalyzerConfigurationUnusedAccessAnalysisRulePropertyToHclTerraform(struct?: AwsAnalyzer.ConfigurationUnusedAccessAnalysisRulePropertyOutputReference | AwsAnalyzer.ConfigurationUnusedAccessAnalysisRuleProperty): any;
export declare function awsAnalyzerUnusedAccessPropertyToTerraform(struct?: AwsAnalyzer.UnusedAccessPropertyOutputReference | AwsAnalyzer.UnusedAccessProperty): any;
export declare function awsAnalyzerUnusedAccessPropertyToHclTerraform(struct?: AwsAnalyzer.UnusedAccessPropertyOutputReference | AwsAnalyzer.UnusedAccessProperty): any;
export declare function awsAnalyzerConfigurationPropertyToTerraform(struct?: AwsAnalyzer.ConfigurationPropertyOutputReference | AwsAnalyzer.ConfigurationProperty): any;
export declare function awsAnalyzerConfigurationPropertyToHclTerraform(struct?: AwsAnalyzer.ConfigurationPropertyOutputReference | AwsAnalyzer.ConfigurationProperty): any;
export declare namespace AwsAnalyzer {
    interface InclusionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_analyzer#account_ids AwsAnalyzer#account_ids}
        */
        readonly accountIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_analyzer#resource_arns AwsAnalyzer#resource_arns}
        */
        readonly resourceArns?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_analyzer#resource_types AwsAnalyzer#resource_types}
        */
        readonly resourceTypes?: string[];
    }
    class InclusionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InclusionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InclusionProperty | cdktn.IResolvable | undefined);
        private _accountIds?;
        get accountIds(): string[];
        set accountIds(value: string[]);
        resetAccountIds(): void;
        get accountIdsInput(): string[] | undefined;
        private _resourceArns?;
        get resourceArns(): string[];
        set resourceArns(value: string[]);
        resetResourceArns(): void;
        get resourceArnsInput(): string[] | undefined;
        private _resourceTypes?;
        get resourceTypes(): string[];
        set resourceTypes(value: string[]);
        resetResourceTypes(): void;
        get resourceTypesInput(): string[] | undefined;
    }
    class InclusionPropertyList extends cdktn.ComplexList {
        internalValue?: InclusionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InclusionPropertyOutputReference;
    }
    interface ConfigurationInternalAccessAnalysisRuleProperty {
        /**
        * inclusion block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_analyzer#inclusion AwsAnalyzer#inclusion}
        */
        readonly inclusion?: InclusionProperty[] | cdktn.IResolvable;
    }
    class ConfigurationInternalAccessAnalysisRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConfigurationInternalAccessAnalysisRuleProperty | undefined;
        set internalValue(value: ConfigurationInternalAccessAnalysisRuleProperty | undefined);
        private _inclusion;
        get inclusion(): InclusionPropertyList;
        putInclusion(value: InclusionProperty[] | cdktn.IResolvable): void;
        resetInclusion(): void;
        get inclusionInput(): cdktn.IResolvable | InclusionProperty[] | undefined;
    }
    interface InternalAccessProperty {
        /**
        * analysis_rule block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_analyzer#analysis_rule AwsAnalyzer#analysis_rule}
        */
        readonly analysisRule?: ConfigurationInternalAccessAnalysisRuleProperty;
    }
    class InternalAccessPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InternalAccessProperty | undefined;
        set internalValue(value: InternalAccessProperty | undefined);
        private _analysisRule;
        get analysisRule(): ConfigurationInternalAccessAnalysisRulePropertyOutputReference;
        putAnalysisRule(value: ConfigurationInternalAccessAnalysisRuleProperty): void;
        resetAnalysisRule(): void;
        get analysisRuleInput(): ConfigurationInternalAccessAnalysisRuleProperty | undefined;
    }
    interface ExclusionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_analyzer#account_ids AwsAnalyzer#account_ids}
        */
        readonly accountIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_analyzer#resource_tags AwsAnalyzer#resource_tags}
        */
        readonly resourceTags?: {
            [key: string]: string;
        }[] | cdktn.IResolvable;
    }
    class ExclusionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExclusionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ExclusionProperty | cdktn.IResolvable | undefined);
        private _accountIds?;
        get accountIds(): string[];
        set accountIds(value: string[]);
        resetAccountIds(): void;
        get accountIdsInput(): string[] | undefined;
        private _resourceTags?;
        get resourceTags(): {
            [key: string]: string;
        }[] | cdktn.IResolvable;
        set resourceTags(value: {
            [key: string]: string;
        }[] | cdktn.IResolvable);
        resetResourceTags(): void;
        get resourceTagsInput(): cdktn.IResolvable | {
            [key: string]: string;
        }[] | undefined;
    }
    class ExclusionPropertyList extends cdktn.ComplexList {
        internalValue?: ExclusionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExclusionPropertyOutputReference;
    }
    interface ConfigurationUnusedAccessAnalysisRuleProperty {
        /**
        * exclusion block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_analyzer#exclusion AwsAnalyzer#exclusion}
        */
        readonly exclusion?: ExclusionProperty[] | cdktn.IResolvable;
    }
    class ConfigurationUnusedAccessAnalysisRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConfigurationUnusedAccessAnalysisRuleProperty | undefined;
        set internalValue(value: ConfigurationUnusedAccessAnalysisRuleProperty | undefined);
        private _exclusion;
        get exclusion(): ExclusionPropertyList;
        putExclusion(value: ExclusionProperty[] | cdktn.IResolvable): void;
        resetExclusion(): void;
        get exclusionInput(): cdktn.IResolvable | ExclusionProperty[] | undefined;
    }
    interface UnusedAccessProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_analyzer#unused_access_age AwsAnalyzer#unused_access_age}
        */
        readonly unusedAccessAge?: number;
        /**
        * analysis_rule block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_analyzer#analysis_rule AwsAnalyzer#analysis_rule}
        */
        readonly analysisRule?: ConfigurationUnusedAccessAnalysisRuleProperty;
    }
    class UnusedAccessPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UnusedAccessProperty | undefined;
        set internalValue(value: UnusedAccessProperty | undefined);
        private _unusedAccessAge?;
        get unusedAccessAge(): number;
        set unusedAccessAge(value: number);
        resetUnusedAccessAge(): void;
        get unusedAccessAgeInput(): number | undefined;
        private _analysisRule;
        get analysisRule(): ConfigurationUnusedAccessAnalysisRulePropertyOutputReference;
        putAnalysisRule(value: ConfigurationUnusedAccessAnalysisRuleProperty): void;
        resetAnalysisRule(): void;
        get analysisRuleInput(): ConfigurationUnusedAccessAnalysisRuleProperty | undefined;
    }
    interface ConfigurationProperty {
        /**
        * internal_access block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_analyzer#internal_access AwsAnalyzer#internal_access}
        */
        readonly internalAccess?: InternalAccessProperty;
        /**
        * unused_access block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/accessanalyzer_analyzer#unused_access AwsAnalyzer#unused_access}
        */
        readonly unusedAccess?: UnusedAccessProperty;
    }
    class ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConfigurationProperty | undefined;
        set internalValue(value: ConfigurationProperty | undefined);
        private _internalAccess;
        get internalAccess(): InternalAccessPropertyOutputReference;
        putInternalAccess(value: InternalAccessProperty): void;
        resetInternalAccess(): void;
        get internalAccessInput(): InternalAccessProperty | undefined;
        private _unusedAccess;
        get unusedAccess(): UnusedAccessPropertyOutputReference;
        putUnusedAccess(value: UnusedAccessProperty): void;
        resetUnusedAccess(): void;
        get unusedAccessInput(): UnusedAccessProperty | undefined;
    }
}
