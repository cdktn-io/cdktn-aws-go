import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsBedrockagentcoreMemoryStrategyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#description AwsBedrockagentcoreMemoryStrategy#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#memory_execution_role_arn AwsBedrockagentcoreMemoryStrategy#memory_execution_role_arn}
    */
    readonly memoryExecutionRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#memory_id AwsBedrockagentcoreMemoryStrategy#memory_id}
    */
    readonly memoryId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#name AwsBedrockagentcoreMemoryStrategy#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#namespace_templates AwsBedrockagentcoreMemoryStrategy#namespace_templates}
    */
    readonly namespaceTemplates?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#namespaces AwsBedrockagentcoreMemoryStrategy#namespaces}
    */
    readonly namespaces?: string[];
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#region AwsBedrockagentcoreMemoryStrategy#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#type AwsBedrockagentcoreMemoryStrategy#type}
    */
    readonly type: string;
    /**
    * configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#configuration AwsBedrockagentcoreMemoryStrategy#configuration}
    */
    readonly configuration?: AwsBedrockagentcoreMemoryStrategy.ConfigurationProperty[] | cdktn.IResolvable;
    /**
    * memory_record_schema block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#memory_record_schema AwsBedrockagentcoreMemoryStrategy#memory_record_schema}
    */
    readonly memoryRecordSchema?: AwsBedrockagentcoreMemoryStrategy.MemoryRecordSchemaProperty[] | cdktn.IResolvable;
    /**
    * reflection_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#reflection_configuration AwsBedrockagentcoreMemoryStrategy#reflection_configuration}
    */
    readonly reflectionConfiguration?: AwsBedrockagentcoreMemoryStrategy.ReflectionConfigurationProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#timeouts AwsBedrockagentcoreMemoryStrategy#timeouts}
    */
    readonly timeouts?: AwsBedrockagentcoreMemoryStrategy.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy aws_bedrockagentcore_memory_strategy}
*/
export declare class AwsBedrockagentcoreMemoryStrategy extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrockagentcore_memory_strategy";
    /**
    * Generates CDKTN code for importing a AwsBedrockagentcoreMemoryStrategy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsBedrockagentcoreMemoryStrategy to import
    * @param importFromId The id of the existing AwsBedrockagentcoreMemoryStrategy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsBedrockagentcoreMemoryStrategy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy aws_bedrockagentcore_memory_strategy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsBedrockagentcoreMemoryStrategyConfig
    */
    constructor(scope: Construct, id: string, config: AwsBedrockagentcoreMemoryStrategyConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _memoryExecutionRoleArn?;
    get memoryExecutionRoleArn(): string;
    set memoryExecutionRoleArn(value: string);
    resetMemoryExecutionRoleArn(): void;
    get memoryExecutionRoleArnInput(): string | undefined;
    private _memoryId?;
    get memoryId(): string;
    set memoryId(value: string);
    get memoryIdInput(): string | undefined;
    get memoryStrategyId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namespaceTemplates?;
    get namespaceTemplates(): string[];
    set namespaceTemplates(value: string[]);
    resetNamespaceTemplates(): void;
    get namespaceTemplatesInput(): string[] | undefined;
    private _namespaces?;
    get namespaces(): string[];
    set namespaces(value: string[]);
    resetNamespaces(): void;
    get namespacesInput(): string[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _configuration;
    get configuration(): AwsBedrockagentcoreMemoryStrategy.ConfigurationPropertyList;
    putConfiguration(value: AwsBedrockagentcoreMemoryStrategy.ConfigurationProperty[] | cdktn.IResolvable): void;
    resetConfiguration(): void;
    get configurationInput(): cdktn.IResolvable | AwsBedrockagentcoreMemoryStrategy.ConfigurationProperty[] | undefined;
    private _memoryRecordSchema;
    get memoryRecordSchema(): AwsBedrockagentcoreMemoryStrategy.MemoryRecordSchemaPropertyList;
    putMemoryRecordSchema(value: AwsBedrockagentcoreMemoryStrategy.MemoryRecordSchemaProperty[] | cdktn.IResolvable): void;
    resetMemoryRecordSchema(): void;
    get memoryRecordSchemaInput(): cdktn.IResolvable | AwsBedrockagentcoreMemoryStrategy.MemoryRecordSchemaProperty[] | undefined;
    private _reflectionConfiguration;
    get reflectionConfiguration(): AwsBedrockagentcoreMemoryStrategy.ReflectionConfigurationPropertyList;
    putReflectionConfiguration(value: AwsBedrockagentcoreMemoryStrategy.ReflectionConfigurationProperty[] | cdktn.IResolvable): void;
    resetReflectionConfiguration(): void;
    get reflectionConfigurationInput(): cdktn.IResolvable | AwsBedrockagentcoreMemoryStrategy.ReflectionConfigurationProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsBedrockagentcoreMemoryStrategy.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsBedrockagentcoreMemoryStrategy.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsBedrockagentcoreMemoryStrategy.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsBedrockagentcoreMemoryStrategyConsolidationPropertyToTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.ConsolidationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryStrategyConsolidationPropertyToHclTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.ConsolidationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryStrategyExtractionPropertyToTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.ExtractionProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryStrategyExtractionPropertyToHclTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.ExtractionProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryStrategyReflectionPropertyToTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.ReflectionProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryStrategyReflectionPropertyToHclTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.ReflectionProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualMessageBasedTriggerPropertyToTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.ConfigurationSelfManagedConfigurationTriggerConditionsActualMessageBasedTriggerProperty): any;
export declare function awsBedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualMessageBasedTriggerPropertyToHclTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.ConfigurationSelfManagedConfigurationTriggerConditionsActualMessageBasedTriggerProperty): any;
export declare function awsBedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualTimeBasedTriggerPropertyToTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.ConfigurationSelfManagedConfigurationTriggerConditionsActualTimeBasedTriggerProperty): any;
export declare function awsBedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualTimeBasedTriggerPropertyToHclTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.ConfigurationSelfManagedConfigurationTriggerConditionsActualTimeBasedTriggerProperty): any;
export declare function awsBedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualTokenBasedTriggerPropertyToTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.ConfigurationSelfManagedConfigurationTriggerConditionsActualTokenBasedTriggerProperty): any;
export declare function awsBedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsActualTokenBasedTriggerPropertyToHclTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.ConfigurationSelfManagedConfigurationTriggerConditionsActualTokenBasedTriggerProperty): any;
export declare function awsBedrockagentcoreMemoryStrategyTriggerConditionsActualPropertyToTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.TriggerConditionsActualProperty): any;
export declare function awsBedrockagentcoreMemoryStrategyTriggerConditionsActualPropertyToHclTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.TriggerConditionsActualProperty): any;
export declare function awsBedrockagentcoreMemoryStrategyInvocationConfigurationPropertyToTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.InvocationConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryStrategyInvocationConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.InvocationConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsMessageBasedTriggerPropertyToTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.ConfigurationSelfManagedConfigurationTriggerConditionsMessageBasedTriggerProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsMessageBasedTriggerPropertyToHclTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.ConfigurationSelfManagedConfigurationTriggerConditionsMessageBasedTriggerProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsTimeBasedTriggerPropertyToTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.ConfigurationSelfManagedConfigurationTriggerConditionsTimeBasedTriggerProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsTimeBasedTriggerPropertyToHclTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.ConfigurationSelfManagedConfigurationTriggerConditionsTimeBasedTriggerProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsTokenBasedTriggerPropertyToTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.ConfigurationSelfManagedConfigurationTriggerConditionsTokenBasedTriggerProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryStrategyConfigurationSelfManagedConfigurationTriggerConditionsTokenBasedTriggerPropertyToHclTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.ConfigurationSelfManagedConfigurationTriggerConditionsTokenBasedTriggerProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryStrategyTriggerConditionsPropertyToTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.TriggerConditionsProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryStrategyTriggerConditionsPropertyToHclTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.TriggerConditionsProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryStrategySelfManagedConfigurationPropertyToTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.SelfManagedConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryStrategySelfManagedConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.SelfManagedConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryStrategyConfigurationPropertyToTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.ConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryStrategyConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.ConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryStrategyNumberValidationPropertyToTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.NumberValidationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryStrategyNumberValidationPropertyToHclTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.NumberValidationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryStrategyStringListValidationPropertyToTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.StringListValidationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryStrategyStringListValidationPropertyToHclTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.StringListValidationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryStrategyStringValidationPropertyToTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.StringValidationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryStrategyStringValidationPropertyToHclTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.StringValidationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryStrategyValidationPropertyToTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.ValidationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryStrategyValidationPropertyToHclTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.ValidationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryStrategyLlmExtractionConfigPropertyToTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.LlmExtractionConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryStrategyLlmExtractionConfigPropertyToHclTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.LlmExtractionConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryStrategyExtractionConfigPropertyToTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.ExtractionConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryStrategyExtractionConfigPropertyToHclTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.ExtractionConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryStrategyMetadataSchemaPropertyToTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.MetadataSchemaProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryStrategyMetadataSchemaPropertyToHclTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.MetadataSchemaProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryStrategyMemoryRecordSchemaPropertyToTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.MemoryRecordSchemaProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryStrategyMemoryRecordSchemaPropertyToHclTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.MemoryRecordSchemaProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryStrategyReflectionConfigurationPropertyToTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.ReflectionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryStrategyReflectionConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.ReflectionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryStrategyTimeoutsPropertyToTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryStrategyTimeoutsPropertyToHclTerraform(struct?: AwsBedrockagentcoreMemoryStrategy.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsBedrockagentcoreMemoryStrategy {
    interface ConsolidationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#append_to_prompt AwsBedrockagentcoreMemoryStrategy#append_to_prompt}
        */
        readonly appendToPrompt: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#model_id AwsBedrockagentcoreMemoryStrategy#model_id}
        */
        readonly modelId: string;
    }
    class ConsolidationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConsolidationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConsolidationProperty | cdktn.IResolvable | undefined);
        private _appendToPrompt?;
        get appendToPrompt(): string;
        set appendToPrompt(value: string);
        get appendToPromptInput(): string | undefined;
        private _modelId?;
        get modelId(): string;
        set modelId(value: string);
        get modelIdInput(): string | undefined;
    }
    class ConsolidationPropertyList extends cdktn.ComplexList {
        internalValue?: ConsolidationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConsolidationPropertyOutputReference;
    }
    interface ExtractionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#append_to_prompt AwsBedrockagentcoreMemoryStrategy#append_to_prompt}
        */
        readonly appendToPrompt: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#model_id AwsBedrockagentcoreMemoryStrategy#model_id}
        */
        readonly modelId: string;
    }
    class ExtractionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExtractionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ExtractionProperty | cdktn.IResolvable | undefined);
        private _appendToPrompt?;
        get appendToPrompt(): string;
        set appendToPrompt(value: string);
        get appendToPromptInput(): string | undefined;
        private _modelId?;
        get modelId(): string;
        set modelId(value: string);
        get modelIdInput(): string | undefined;
    }
    class ExtractionPropertyList extends cdktn.ComplexList {
        internalValue?: ExtractionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExtractionPropertyOutputReference;
    }
    interface ReflectionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#append_to_prompt AwsBedrockagentcoreMemoryStrategy#append_to_prompt}
        */
        readonly appendToPrompt: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#model_id AwsBedrockagentcoreMemoryStrategy#model_id}
        */
        readonly modelId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#namespace_templates AwsBedrockagentcoreMemoryStrategy#namespace_templates}
        */
        readonly namespaceTemplates: string[];
    }
    class ReflectionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReflectionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ReflectionProperty | cdktn.IResolvable | undefined);
        private _appendToPrompt?;
        get appendToPrompt(): string;
        set appendToPrompt(value: string);
        get appendToPromptInput(): string | undefined;
        private _modelId?;
        get modelId(): string;
        set modelId(value: string);
        get modelIdInput(): string | undefined;
        private _namespaceTemplates?;
        get namespaceTemplates(): string[];
        set namespaceTemplates(value: string[]);
        get namespaceTemplatesInput(): string[] | undefined;
    }
    class ReflectionPropertyList extends cdktn.ComplexList {
        internalValue?: ReflectionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReflectionPropertyOutputReference;
    }
    interface ConfigurationSelfManagedConfigurationTriggerConditionsActualMessageBasedTriggerProperty {
    }
    class ConfigurationSelfManagedConfigurationTriggerConditionsActualMessageBasedTriggerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConfigurationSelfManagedConfigurationTriggerConditionsActualMessageBasedTriggerProperty | undefined;
        set internalValue(value: ConfigurationSelfManagedConfigurationTriggerConditionsActualMessageBasedTriggerProperty | undefined);
        get messageCount(): number;
    }
    class ConfigurationSelfManagedConfigurationTriggerConditionsActualMessageBasedTriggerPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConfigurationSelfManagedConfigurationTriggerConditionsActualMessageBasedTriggerPropertyOutputReference;
    }
    interface ConfigurationSelfManagedConfigurationTriggerConditionsActualTimeBasedTriggerProperty {
    }
    class ConfigurationSelfManagedConfigurationTriggerConditionsActualTimeBasedTriggerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConfigurationSelfManagedConfigurationTriggerConditionsActualTimeBasedTriggerProperty | undefined;
        set internalValue(value: ConfigurationSelfManagedConfigurationTriggerConditionsActualTimeBasedTriggerProperty | undefined);
        get idleSessionTimeout(): number;
    }
    class ConfigurationSelfManagedConfigurationTriggerConditionsActualTimeBasedTriggerPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConfigurationSelfManagedConfigurationTriggerConditionsActualTimeBasedTriggerPropertyOutputReference;
    }
    interface ConfigurationSelfManagedConfigurationTriggerConditionsActualTokenBasedTriggerProperty {
    }
    class ConfigurationSelfManagedConfigurationTriggerConditionsActualTokenBasedTriggerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConfigurationSelfManagedConfigurationTriggerConditionsActualTokenBasedTriggerProperty | undefined;
        set internalValue(value: ConfigurationSelfManagedConfigurationTriggerConditionsActualTokenBasedTriggerProperty | undefined);
        get tokenCount(): number;
    }
    class ConfigurationSelfManagedConfigurationTriggerConditionsActualTokenBasedTriggerPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConfigurationSelfManagedConfigurationTriggerConditionsActualTokenBasedTriggerPropertyOutputReference;
    }
    interface TriggerConditionsActualProperty {
    }
    class TriggerConditionsActualPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TriggerConditionsActualProperty | undefined;
        set internalValue(value: TriggerConditionsActualProperty | undefined);
        private _messageBasedTrigger;
        get messageBasedTrigger(): ConfigurationSelfManagedConfigurationTriggerConditionsActualMessageBasedTriggerPropertyList;
        private _timeBasedTrigger;
        get timeBasedTrigger(): ConfigurationSelfManagedConfigurationTriggerConditionsActualTimeBasedTriggerPropertyList;
        private _tokenBasedTrigger;
        get tokenBasedTrigger(): ConfigurationSelfManagedConfigurationTriggerConditionsActualTokenBasedTriggerPropertyList;
    }
    class TriggerConditionsActualPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TriggerConditionsActualPropertyOutputReference;
    }
    interface InvocationConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#payload_delivery_bucket_name AwsBedrockagentcoreMemoryStrategy#payload_delivery_bucket_name}
        */
        readonly payloadDeliveryBucketName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#topic_arn AwsBedrockagentcoreMemoryStrategy#topic_arn}
        */
        readonly topicArn: string;
    }
    class InvocationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InvocationConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InvocationConfigurationProperty | cdktn.IResolvable | undefined);
        private _payloadDeliveryBucketName?;
        get payloadDeliveryBucketName(): string;
        set payloadDeliveryBucketName(value: string);
        get payloadDeliveryBucketNameInput(): string | undefined;
        private _topicArn?;
        get topicArn(): string;
        set topicArn(value: string);
        get topicArnInput(): string | undefined;
    }
    class InvocationConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: InvocationConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InvocationConfigurationPropertyOutputReference;
    }
    interface ConfigurationSelfManagedConfigurationTriggerConditionsMessageBasedTriggerProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#message_count AwsBedrockagentcoreMemoryStrategy#message_count}
        */
        readonly messageCount: number;
    }
    class ConfigurationSelfManagedConfigurationTriggerConditionsMessageBasedTriggerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConfigurationSelfManagedConfigurationTriggerConditionsMessageBasedTriggerProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConfigurationSelfManagedConfigurationTriggerConditionsMessageBasedTriggerProperty | cdktn.IResolvable | undefined);
        private _messageCount?;
        get messageCount(): number;
        set messageCount(value: number);
        get messageCountInput(): number | undefined;
    }
    class ConfigurationSelfManagedConfigurationTriggerConditionsMessageBasedTriggerPropertyList extends cdktn.ComplexList {
        internalValue?: ConfigurationSelfManagedConfigurationTriggerConditionsMessageBasedTriggerProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConfigurationSelfManagedConfigurationTriggerConditionsMessageBasedTriggerPropertyOutputReference;
    }
    interface ConfigurationSelfManagedConfigurationTriggerConditionsTimeBasedTriggerProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#idle_session_timeout AwsBedrockagentcoreMemoryStrategy#idle_session_timeout}
        */
        readonly idleSessionTimeout: number;
    }
    class ConfigurationSelfManagedConfigurationTriggerConditionsTimeBasedTriggerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConfigurationSelfManagedConfigurationTriggerConditionsTimeBasedTriggerProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConfigurationSelfManagedConfigurationTriggerConditionsTimeBasedTriggerProperty | cdktn.IResolvable | undefined);
        private _idleSessionTimeout?;
        get idleSessionTimeout(): number;
        set idleSessionTimeout(value: number);
        get idleSessionTimeoutInput(): number | undefined;
    }
    class ConfigurationSelfManagedConfigurationTriggerConditionsTimeBasedTriggerPropertyList extends cdktn.ComplexList {
        internalValue?: ConfigurationSelfManagedConfigurationTriggerConditionsTimeBasedTriggerProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConfigurationSelfManagedConfigurationTriggerConditionsTimeBasedTriggerPropertyOutputReference;
    }
    interface ConfigurationSelfManagedConfigurationTriggerConditionsTokenBasedTriggerProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#token_count AwsBedrockagentcoreMemoryStrategy#token_count}
        */
        readonly tokenCount: number;
    }
    class ConfigurationSelfManagedConfigurationTriggerConditionsTokenBasedTriggerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConfigurationSelfManagedConfigurationTriggerConditionsTokenBasedTriggerProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConfigurationSelfManagedConfigurationTriggerConditionsTokenBasedTriggerProperty | cdktn.IResolvable | undefined);
        private _tokenCount?;
        get tokenCount(): number;
        set tokenCount(value: number);
        get tokenCountInput(): number | undefined;
    }
    class ConfigurationSelfManagedConfigurationTriggerConditionsTokenBasedTriggerPropertyList extends cdktn.ComplexList {
        internalValue?: ConfigurationSelfManagedConfigurationTriggerConditionsTokenBasedTriggerProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConfigurationSelfManagedConfigurationTriggerConditionsTokenBasedTriggerPropertyOutputReference;
    }
    interface TriggerConditionsProperty {
        /**
        * message_based_trigger block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#message_based_trigger AwsBedrockagentcoreMemoryStrategy#message_based_trigger}
        */
        readonly messageBasedTrigger?: ConfigurationSelfManagedConfigurationTriggerConditionsMessageBasedTriggerProperty[] | cdktn.IResolvable;
        /**
        * time_based_trigger block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#time_based_trigger AwsBedrockagentcoreMemoryStrategy#time_based_trigger}
        */
        readonly timeBasedTrigger?: ConfigurationSelfManagedConfigurationTriggerConditionsTimeBasedTriggerProperty[] | cdktn.IResolvable;
        /**
        * token_based_trigger block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#token_based_trigger AwsBedrockagentcoreMemoryStrategy#token_based_trigger}
        */
        readonly tokenBasedTrigger?: ConfigurationSelfManagedConfigurationTriggerConditionsTokenBasedTriggerProperty[] | cdktn.IResolvable;
    }
    class TriggerConditionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TriggerConditionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TriggerConditionsProperty | cdktn.IResolvable | undefined);
        private _messageBasedTrigger;
        get messageBasedTrigger(): ConfigurationSelfManagedConfigurationTriggerConditionsMessageBasedTriggerPropertyList;
        putMessageBasedTrigger(value: ConfigurationSelfManagedConfigurationTriggerConditionsMessageBasedTriggerProperty[] | cdktn.IResolvable): void;
        resetMessageBasedTrigger(): void;
        get messageBasedTriggerInput(): cdktn.IResolvable | ConfigurationSelfManagedConfigurationTriggerConditionsMessageBasedTriggerProperty[] | undefined;
        private _timeBasedTrigger;
        get timeBasedTrigger(): ConfigurationSelfManagedConfigurationTriggerConditionsTimeBasedTriggerPropertyList;
        putTimeBasedTrigger(value: ConfigurationSelfManagedConfigurationTriggerConditionsTimeBasedTriggerProperty[] | cdktn.IResolvable): void;
        resetTimeBasedTrigger(): void;
        get timeBasedTriggerInput(): cdktn.IResolvable | ConfigurationSelfManagedConfigurationTriggerConditionsTimeBasedTriggerProperty[] | undefined;
        private _tokenBasedTrigger;
        get tokenBasedTrigger(): ConfigurationSelfManagedConfigurationTriggerConditionsTokenBasedTriggerPropertyList;
        putTokenBasedTrigger(value: ConfigurationSelfManagedConfigurationTriggerConditionsTokenBasedTriggerProperty[] | cdktn.IResolvable): void;
        resetTokenBasedTrigger(): void;
        get tokenBasedTriggerInput(): cdktn.IResolvable | ConfigurationSelfManagedConfigurationTriggerConditionsTokenBasedTriggerProperty[] | undefined;
    }
    class TriggerConditionsPropertyList extends cdktn.ComplexList {
        internalValue?: TriggerConditionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TriggerConditionsPropertyOutputReference;
    }
    interface SelfManagedConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#historical_context_window_size AwsBedrockagentcoreMemoryStrategy#historical_context_window_size}
        */
        readonly historicalContextWindowSize?: number;
        /**
        * invocation_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#invocation_configuration AwsBedrockagentcoreMemoryStrategy#invocation_configuration}
        */
        readonly invocationConfiguration?: InvocationConfigurationProperty[] | cdktn.IResolvable;
        /**
        * trigger_conditions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#trigger_conditions AwsBedrockagentcoreMemoryStrategy#trigger_conditions}
        */
        readonly triggerConditions?: TriggerConditionsProperty[] | cdktn.IResolvable;
    }
    class SelfManagedConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SelfManagedConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SelfManagedConfigurationProperty | cdktn.IResolvable | undefined);
        private _historicalContextWindowSize?;
        get historicalContextWindowSize(): number;
        set historicalContextWindowSize(value: number);
        resetHistoricalContextWindowSize(): void;
        get historicalContextWindowSizeInput(): number | undefined;
        private _triggerConditionsActual;
        get triggerConditionsActual(): TriggerConditionsActualPropertyList;
        private _invocationConfiguration;
        get invocationConfiguration(): InvocationConfigurationPropertyList;
        putInvocationConfiguration(value: InvocationConfigurationProperty[] | cdktn.IResolvable): void;
        resetInvocationConfiguration(): void;
        get invocationConfigurationInput(): cdktn.IResolvable | InvocationConfigurationProperty[] | undefined;
        private _triggerConditions;
        get triggerConditions(): TriggerConditionsPropertyList;
        putTriggerConditions(value: TriggerConditionsProperty[] | cdktn.IResolvable): void;
        resetTriggerConditions(): void;
        get triggerConditionsInput(): cdktn.IResolvable | TriggerConditionsProperty[] | undefined;
    }
    class SelfManagedConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: SelfManagedConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SelfManagedConfigurationPropertyOutputReference;
    }
    interface ConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#type AwsBedrockagentcoreMemoryStrategy#type}
        */
        readonly type: string;
        /**
        * consolidation block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#consolidation AwsBedrockagentcoreMemoryStrategy#consolidation}
        */
        readonly consolidation?: ConsolidationProperty[] | cdktn.IResolvable;
        /**
        * extraction block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#extraction AwsBedrockagentcoreMemoryStrategy#extraction}
        */
        readonly extraction?: ExtractionProperty[] | cdktn.IResolvable;
        /**
        * reflection block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#reflection AwsBedrockagentcoreMemoryStrategy#reflection}
        */
        readonly reflection?: ReflectionProperty[] | cdktn.IResolvable;
        /**
        * self_managed_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#self_managed_configuration AwsBedrockagentcoreMemoryStrategy#self_managed_configuration}
        */
        readonly selfManagedConfiguration?: SelfManagedConfigurationProperty[] | cdktn.IResolvable;
    }
    class ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConfigurationProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _consolidation;
        get consolidation(): ConsolidationPropertyList;
        putConsolidation(value: ConsolidationProperty[] | cdktn.IResolvable): void;
        resetConsolidation(): void;
        get consolidationInput(): cdktn.IResolvable | ConsolidationProperty[] | undefined;
        private _extraction;
        get extraction(): ExtractionPropertyList;
        putExtraction(value: ExtractionProperty[] | cdktn.IResolvable): void;
        resetExtraction(): void;
        get extractionInput(): cdktn.IResolvable | ExtractionProperty[] | undefined;
        private _reflection;
        get reflection(): ReflectionPropertyList;
        putReflection(value: ReflectionProperty[] | cdktn.IResolvable): void;
        resetReflection(): void;
        get reflectionInput(): cdktn.IResolvable | ReflectionProperty[] | undefined;
        private _selfManagedConfiguration;
        get selfManagedConfiguration(): SelfManagedConfigurationPropertyList;
        putSelfManagedConfiguration(value: SelfManagedConfigurationProperty[] | cdktn.IResolvable): void;
        resetSelfManagedConfiguration(): void;
        get selfManagedConfigurationInput(): cdktn.IResolvable | SelfManagedConfigurationProperty[] | undefined;
    }
    class ConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConfigurationPropertyOutputReference;
    }
    interface NumberValidationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#max_value AwsBedrockagentcoreMemoryStrategy#max_value}
        */
        readonly maxValue?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#min_value AwsBedrockagentcoreMemoryStrategy#min_value}
        */
        readonly minValue?: number;
    }
    class NumberValidationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NumberValidationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NumberValidationProperty | cdktn.IResolvable | undefined);
        private _maxValue?;
        get maxValue(): number;
        set maxValue(value: number);
        resetMaxValue(): void;
        get maxValueInput(): number | undefined;
        private _minValue?;
        get minValue(): number;
        set minValue(value: number);
        resetMinValue(): void;
        get minValueInput(): number | undefined;
    }
    class NumberValidationPropertyList extends cdktn.ComplexList {
        internalValue?: NumberValidationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NumberValidationPropertyOutputReference;
    }
    interface StringListValidationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#allowed_values AwsBedrockagentcoreMemoryStrategy#allowed_values}
        */
        readonly allowedValues?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#max_items AwsBedrockagentcoreMemoryStrategy#max_items}
        */
        readonly maxItems?: number;
    }
    class StringListValidationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StringListValidationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StringListValidationProperty | cdktn.IResolvable | undefined);
        private _allowedValues?;
        get allowedValues(): string[];
        set allowedValues(value: string[]);
        resetAllowedValues(): void;
        get allowedValuesInput(): string[] | undefined;
        private _maxItems?;
        get maxItems(): number;
        set maxItems(value: number);
        resetMaxItems(): void;
        get maxItemsInput(): number | undefined;
    }
    class StringListValidationPropertyList extends cdktn.ComplexList {
        internalValue?: StringListValidationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StringListValidationPropertyOutputReference;
    }
    interface StringValidationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#allowed_values AwsBedrockagentcoreMemoryStrategy#allowed_values}
        */
        readonly allowedValues: string[];
    }
    class StringValidationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StringValidationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StringValidationProperty | cdktn.IResolvable | undefined);
        private _allowedValues?;
        get allowedValues(): string[];
        set allowedValues(value: string[]);
        get allowedValuesInput(): string[] | undefined;
    }
    class StringValidationPropertyList extends cdktn.ComplexList {
        internalValue?: StringValidationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StringValidationPropertyOutputReference;
    }
    interface ValidationProperty {
        /**
        * number_validation block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#number_validation AwsBedrockagentcoreMemoryStrategy#number_validation}
        */
        readonly numberValidation?: NumberValidationProperty[] | cdktn.IResolvable;
        /**
        * string_list_validation block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#string_list_validation AwsBedrockagentcoreMemoryStrategy#string_list_validation}
        */
        readonly stringListValidation?: StringListValidationProperty[] | cdktn.IResolvable;
        /**
        * string_validation block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#string_validation AwsBedrockagentcoreMemoryStrategy#string_validation}
        */
        readonly stringValidation?: StringValidationProperty[] | cdktn.IResolvable;
    }
    class ValidationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ValidationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ValidationProperty | cdktn.IResolvable | undefined);
        private _numberValidation;
        get numberValidation(): NumberValidationPropertyList;
        putNumberValidation(value: NumberValidationProperty[] | cdktn.IResolvable): void;
        resetNumberValidation(): void;
        get numberValidationInput(): cdktn.IResolvable | NumberValidationProperty[] | undefined;
        private _stringListValidation;
        get stringListValidation(): StringListValidationPropertyList;
        putStringListValidation(value: StringListValidationProperty[] | cdktn.IResolvable): void;
        resetStringListValidation(): void;
        get stringListValidationInput(): cdktn.IResolvable | StringListValidationProperty[] | undefined;
        private _stringValidation;
        get stringValidation(): StringValidationPropertyList;
        putStringValidation(value: StringValidationProperty[] | cdktn.IResolvable): void;
        resetStringValidation(): void;
        get stringValidationInput(): cdktn.IResolvable | StringValidationProperty[] | undefined;
    }
    class ValidationPropertyList extends cdktn.ComplexList {
        internalValue?: ValidationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ValidationPropertyOutputReference;
    }
    interface LlmExtractionConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#definition AwsBedrockagentcoreMemoryStrategy#definition}
        */
        readonly definition: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#llm_extraction_instruction AwsBedrockagentcoreMemoryStrategy#llm_extraction_instruction}
        */
        readonly llmExtractionInstruction?: string;
        /**
        * validation block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#validation AwsBedrockagentcoreMemoryStrategy#validation}
        */
        readonly validation?: ValidationProperty[] | cdktn.IResolvable;
    }
    class LlmExtractionConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LlmExtractionConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LlmExtractionConfigProperty | cdktn.IResolvable | undefined);
        private _definition?;
        get definition(): string;
        set definition(value: string);
        get definitionInput(): string | undefined;
        private _llmExtractionInstruction?;
        get llmExtractionInstruction(): string;
        set llmExtractionInstruction(value: string);
        resetLlmExtractionInstruction(): void;
        get llmExtractionInstructionInput(): string | undefined;
        private _validation;
        get validation(): ValidationPropertyList;
        putValidation(value: ValidationProperty[] | cdktn.IResolvable): void;
        resetValidation(): void;
        get validationInput(): cdktn.IResolvable | ValidationProperty[] | undefined;
    }
    class LlmExtractionConfigPropertyList extends cdktn.ComplexList {
        internalValue?: LlmExtractionConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LlmExtractionConfigPropertyOutputReference;
    }
    interface ExtractionConfigProperty {
        /**
        * llm_extraction_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#llm_extraction_config AwsBedrockagentcoreMemoryStrategy#llm_extraction_config}
        */
        readonly llmExtractionConfig?: LlmExtractionConfigProperty[] | cdktn.IResolvable;
    }
    class ExtractionConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExtractionConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ExtractionConfigProperty | cdktn.IResolvable | undefined);
        private _llmExtractionConfig;
        get llmExtractionConfig(): LlmExtractionConfigPropertyList;
        putLlmExtractionConfig(value: LlmExtractionConfigProperty[] | cdktn.IResolvable): void;
        resetLlmExtractionConfig(): void;
        get llmExtractionConfigInput(): cdktn.IResolvable | LlmExtractionConfigProperty[] | undefined;
    }
    class ExtractionConfigPropertyList extends cdktn.ComplexList {
        internalValue?: ExtractionConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExtractionConfigPropertyOutputReference;
    }
    interface MetadataSchemaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#extraction_type AwsBedrockagentcoreMemoryStrategy#extraction_type}
        */
        readonly extractionType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#key AwsBedrockagentcoreMemoryStrategy#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#type AwsBedrockagentcoreMemoryStrategy#type}
        */
        readonly type?: string;
        /**
        * extraction_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#extraction_config AwsBedrockagentcoreMemoryStrategy#extraction_config}
        */
        readonly extractionConfig?: ExtractionConfigProperty[] | cdktn.IResolvable;
    }
    class MetadataSchemaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MetadataSchemaProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MetadataSchemaProperty | cdktn.IResolvable | undefined);
        private _extractionType?;
        get extractionType(): string;
        set extractionType(value: string);
        resetExtractionType(): void;
        get extractionTypeInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
        private _extractionConfig;
        get extractionConfig(): ExtractionConfigPropertyList;
        putExtractionConfig(value: ExtractionConfigProperty[] | cdktn.IResolvable): void;
        resetExtractionConfig(): void;
        get extractionConfigInput(): cdktn.IResolvable | ExtractionConfigProperty[] | undefined;
    }
    class MetadataSchemaPropertyList extends cdktn.ComplexList {
        internalValue?: MetadataSchemaProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MetadataSchemaPropertyOutputReference;
    }
    interface MemoryRecordSchemaProperty {
        /**
        * metadata_schema block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#metadata_schema AwsBedrockagentcoreMemoryStrategy#metadata_schema}
        */
        readonly metadataSchema?: MetadataSchemaProperty[] | cdktn.IResolvable;
    }
    class MemoryRecordSchemaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MemoryRecordSchemaProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MemoryRecordSchemaProperty | cdktn.IResolvable | undefined);
        private _metadataSchema;
        get metadataSchema(): MetadataSchemaPropertyList;
        putMetadataSchema(value: MetadataSchemaProperty[] | cdktn.IResolvable): void;
        resetMetadataSchema(): void;
        get metadataSchemaInput(): cdktn.IResolvable | MetadataSchemaProperty[] | undefined;
    }
    class MemoryRecordSchemaPropertyList extends cdktn.ComplexList {
        internalValue?: MemoryRecordSchemaProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MemoryRecordSchemaPropertyOutputReference;
    }
    interface ReflectionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#namespace_templates AwsBedrockagentcoreMemoryStrategy#namespace_templates}
        */
        readonly namespaceTemplates: string[];
    }
    class ReflectionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReflectionConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ReflectionConfigurationProperty | cdktn.IResolvable | undefined);
        private _namespaceTemplates?;
        get namespaceTemplates(): string[];
        set namespaceTemplates(value: string[]);
        get namespaceTemplatesInput(): string[] | undefined;
    }
    class ReflectionConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ReflectionConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReflectionConfigurationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#create AwsBedrockagentcoreMemoryStrategy#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#delete AwsBedrockagentcoreMemoryStrategy#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory_strategy#update AwsBedrockagentcoreMemoryStrategy#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
