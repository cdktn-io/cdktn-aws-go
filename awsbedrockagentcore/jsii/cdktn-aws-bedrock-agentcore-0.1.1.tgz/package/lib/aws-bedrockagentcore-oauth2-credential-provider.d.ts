import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsBedrockagentcoreOauth2CredentialProviderConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#credential_provider_vendor AwsBedrockagentcoreOauth2CredentialProvider#credential_provider_vendor}
    */
    readonly credentialProviderVendor: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#name AwsBedrockagentcoreOauth2CredentialProvider#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#region AwsBedrockagentcoreOauth2CredentialProvider#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#tags AwsBedrockagentcoreOauth2CredentialProvider#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * oauth2_provider_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#oauth2_provider_config AwsBedrockagentcoreOauth2CredentialProvider#oauth2_provider_config}
    */
    readonly oauth2ProviderConfig?: AwsBedrockagentcoreOauth2CredentialProvider.Oauth2ProviderConfigProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider aws_bedrockagentcore_oauth2_credential_provider}
*/
export declare class AwsBedrockagentcoreOauth2CredentialProvider extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrockagentcore_oauth2_credential_provider";
    /**
    * Generates CDKTN code for importing a AwsBedrockagentcoreOauth2CredentialProvider resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsBedrockagentcoreOauth2CredentialProvider to import
    * @param importFromId The id of the existing AwsBedrockagentcoreOauth2CredentialProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsBedrockagentcoreOauth2CredentialProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider aws_bedrockagentcore_oauth2_credential_provider} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsBedrockagentcoreOauth2CredentialProviderConfig
    */
    constructor(scope: Construct, id: string, config: AwsBedrockagentcoreOauth2CredentialProviderConfig);
    private _clientSecretArn;
    get clientSecretArn(): AwsBedrockagentcoreOauth2CredentialProvider.ClientSecretArnPropertyList;
    get credentialProviderArn(): string;
    private _credentialProviderVendor?;
    get credentialProviderVendor(): string;
    set credentialProviderVendor(value: string);
    get credentialProviderVendorInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _oauth2ProviderConfig;
    get oauth2ProviderConfig(): AwsBedrockagentcoreOauth2CredentialProvider.Oauth2ProviderConfigPropertyList;
    putOauth2ProviderConfig(value: AwsBedrockagentcoreOauth2CredentialProvider.Oauth2ProviderConfigProperty[] | cdktn.IResolvable): void;
    resetOauth2ProviderConfig(): void;
    get oauth2ProviderConfigInput(): cdktn.IResolvable | AwsBedrockagentcoreOauth2CredentialProvider.Oauth2ProviderConfigProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsBedrockagentcoreOauth2CredentialProviderClientSecretArnPropertyToTerraform(struct?: AwsBedrockagentcoreOauth2CredentialProvider.ClientSecretArnProperty): any;
export declare function awsBedrockagentcoreOauth2CredentialProviderClientSecretArnPropertyToHclTerraform(struct?: AwsBedrockagentcoreOauth2CredentialProvider.ClientSecretArnProperty): any;
export declare function awsBedrockagentcoreOauth2CredentialProviderOauth2ProviderConfigCustomOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataPropertyToTerraform(struct?: AwsBedrockagentcoreOauth2CredentialProvider.Oauth2ProviderConfigCustomOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreOauth2CredentialProviderOauth2ProviderConfigCustomOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataPropertyToHclTerraform(struct?: AwsBedrockagentcoreOauth2CredentialProvider.Oauth2ProviderConfigCustomOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreOauth2CredentialProviderOauth2ProviderConfigCustomOauth2ProviderConfigOauthDiscoveryPropertyToTerraform(struct?: AwsBedrockagentcoreOauth2CredentialProvider.Oauth2ProviderConfigCustomOauth2ProviderConfigOauthDiscoveryProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreOauth2CredentialProviderOauth2ProviderConfigCustomOauth2ProviderConfigOauthDiscoveryPropertyToHclTerraform(struct?: AwsBedrockagentcoreOauth2CredentialProvider.Oauth2ProviderConfigCustomOauth2ProviderConfigOauthDiscoveryProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreOauth2CredentialProviderCustomOauth2ProviderConfigPropertyToTerraform(struct?: AwsBedrockagentcoreOauth2CredentialProvider.CustomOauth2ProviderConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreOauth2CredentialProviderCustomOauth2ProviderConfigPropertyToHclTerraform(struct?: AwsBedrockagentcoreOauth2CredentialProvider.CustomOauth2ProviderConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreOauth2CredentialProviderOauth2ProviderConfigGithubOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataPropertyToTerraform(struct?: AwsBedrockagentcoreOauth2CredentialProvider.Oauth2ProviderConfigGithubOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataProperty): any;
export declare function awsBedrockagentcoreOauth2CredentialProviderOauth2ProviderConfigGithubOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataPropertyToHclTerraform(struct?: AwsBedrockagentcoreOauth2CredentialProvider.Oauth2ProviderConfigGithubOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataProperty): any;
export declare function awsBedrockagentcoreOauth2CredentialProviderOauth2ProviderConfigGithubOauth2ProviderConfigOauthDiscoveryPropertyToTerraform(struct?: AwsBedrockagentcoreOauth2CredentialProvider.Oauth2ProviderConfigGithubOauth2ProviderConfigOauthDiscoveryProperty): any;
export declare function awsBedrockagentcoreOauth2CredentialProviderOauth2ProviderConfigGithubOauth2ProviderConfigOauthDiscoveryPropertyToHclTerraform(struct?: AwsBedrockagentcoreOauth2CredentialProvider.Oauth2ProviderConfigGithubOauth2ProviderConfigOauthDiscoveryProperty): any;
export declare function awsBedrockagentcoreOauth2CredentialProviderGithubOauth2ProviderConfigPropertyToTerraform(struct?: AwsBedrockagentcoreOauth2CredentialProvider.GithubOauth2ProviderConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreOauth2CredentialProviderGithubOauth2ProviderConfigPropertyToHclTerraform(struct?: AwsBedrockagentcoreOauth2CredentialProvider.GithubOauth2ProviderConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreOauth2CredentialProviderOauth2ProviderConfigGoogleOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataPropertyToTerraform(struct?: AwsBedrockagentcoreOauth2CredentialProvider.Oauth2ProviderConfigGoogleOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataProperty): any;
export declare function awsBedrockagentcoreOauth2CredentialProviderOauth2ProviderConfigGoogleOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataPropertyToHclTerraform(struct?: AwsBedrockagentcoreOauth2CredentialProvider.Oauth2ProviderConfigGoogleOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataProperty): any;
export declare function awsBedrockagentcoreOauth2CredentialProviderOauth2ProviderConfigGoogleOauth2ProviderConfigOauthDiscoveryPropertyToTerraform(struct?: AwsBedrockagentcoreOauth2CredentialProvider.Oauth2ProviderConfigGoogleOauth2ProviderConfigOauthDiscoveryProperty): any;
export declare function awsBedrockagentcoreOauth2CredentialProviderOauth2ProviderConfigGoogleOauth2ProviderConfigOauthDiscoveryPropertyToHclTerraform(struct?: AwsBedrockagentcoreOauth2CredentialProvider.Oauth2ProviderConfigGoogleOauth2ProviderConfigOauthDiscoveryProperty): any;
export declare function awsBedrockagentcoreOauth2CredentialProviderGoogleOauth2ProviderConfigPropertyToTerraform(struct?: AwsBedrockagentcoreOauth2CredentialProvider.GoogleOauth2ProviderConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreOauth2CredentialProviderGoogleOauth2ProviderConfigPropertyToHclTerraform(struct?: AwsBedrockagentcoreOauth2CredentialProvider.GoogleOauth2ProviderConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreOauth2CredentialProviderOauth2ProviderConfigMicrosoftOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataPropertyToTerraform(struct?: AwsBedrockagentcoreOauth2CredentialProvider.Oauth2ProviderConfigMicrosoftOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataProperty): any;
export declare function awsBedrockagentcoreOauth2CredentialProviderOauth2ProviderConfigMicrosoftOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataPropertyToHclTerraform(struct?: AwsBedrockagentcoreOauth2CredentialProvider.Oauth2ProviderConfigMicrosoftOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataProperty): any;
export declare function awsBedrockagentcoreOauth2CredentialProviderOauth2ProviderConfigMicrosoftOauth2ProviderConfigOauthDiscoveryPropertyToTerraform(struct?: AwsBedrockagentcoreOauth2CredentialProvider.Oauth2ProviderConfigMicrosoftOauth2ProviderConfigOauthDiscoveryProperty): any;
export declare function awsBedrockagentcoreOauth2CredentialProviderOauth2ProviderConfigMicrosoftOauth2ProviderConfigOauthDiscoveryPropertyToHclTerraform(struct?: AwsBedrockagentcoreOauth2CredentialProvider.Oauth2ProviderConfigMicrosoftOauth2ProviderConfigOauthDiscoveryProperty): any;
export declare function awsBedrockagentcoreOauth2CredentialProviderMicrosoftOauth2ProviderConfigPropertyToTerraform(struct?: AwsBedrockagentcoreOauth2CredentialProvider.MicrosoftOauth2ProviderConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreOauth2CredentialProviderMicrosoftOauth2ProviderConfigPropertyToHclTerraform(struct?: AwsBedrockagentcoreOauth2CredentialProvider.MicrosoftOauth2ProviderConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreOauth2CredentialProviderOauth2ProviderConfigSalesforceOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataPropertyToTerraform(struct?: AwsBedrockagentcoreOauth2CredentialProvider.Oauth2ProviderConfigSalesforceOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataProperty): any;
export declare function awsBedrockagentcoreOauth2CredentialProviderOauth2ProviderConfigSalesforceOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataPropertyToHclTerraform(struct?: AwsBedrockagentcoreOauth2CredentialProvider.Oauth2ProviderConfigSalesforceOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataProperty): any;
export declare function awsBedrockagentcoreOauth2CredentialProviderOauth2ProviderConfigSalesforceOauth2ProviderConfigOauthDiscoveryPropertyToTerraform(struct?: AwsBedrockagentcoreOauth2CredentialProvider.Oauth2ProviderConfigSalesforceOauth2ProviderConfigOauthDiscoveryProperty): any;
export declare function awsBedrockagentcoreOauth2CredentialProviderOauth2ProviderConfigSalesforceOauth2ProviderConfigOauthDiscoveryPropertyToHclTerraform(struct?: AwsBedrockagentcoreOauth2CredentialProvider.Oauth2ProviderConfigSalesforceOauth2ProviderConfigOauthDiscoveryProperty): any;
export declare function awsBedrockagentcoreOauth2CredentialProviderSalesforceOauth2ProviderConfigPropertyToTerraform(struct?: AwsBedrockagentcoreOauth2CredentialProvider.SalesforceOauth2ProviderConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreOauth2CredentialProviderSalesforceOauth2ProviderConfigPropertyToHclTerraform(struct?: AwsBedrockagentcoreOauth2CredentialProvider.SalesforceOauth2ProviderConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreOauth2CredentialProviderOauth2ProviderConfigSlackOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataPropertyToTerraform(struct?: AwsBedrockagentcoreOauth2CredentialProvider.Oauth2ProviderConfigSlackOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataProperty): any;
export declare function awsBedrockagentcoreOauth2CredentialProviderOauth2ProviderConfigSlackOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataPropertyToHclTerraform(struct?: AwsBedrockagentcoreOauth2CredentialProvider.Oauth2ProviderConfigSlackOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataProperty): any;
export declare function awsBedrockagentcoreOauth2CredentialProviderOauth2ProviderConfigSlackOauth2ProviderConfigOauthDiscoveryPropertyToTerraform(struct?: AwsBedrockagentcoreOauth2CredentialProvider.Oauth2ProviderConfigSlackOauth2ProviderConfigOauthDiscoveryProperty): any;
export declare function awsBedrockagentcoreOauth2CredentialProviderOauth2ProviderConfigSlackOauth2ProviderConfigOauthDiscoveryPropertyToHclTerraform(struct?: AwsBedrockagentcoreOauth2CredentialProvider.Oauth2ProviderConfigSlackOauth2ProviderConfigOauthDiscoveryProperty): any;
export declare function awsBedrockagentcoreOauth2CredentialProviderSlackOauth2ProviderConfigPropertyToTerraform(struct?: AwsBedrockagentcoreOauth2CredentialProvider.SlackOauth2ProviderConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreOauth2CredentialProviderSlackOauth2ProviderConfigPropertyToHclTerraform(struct?: AwsBedrockagentcoreOauth2CredentialProvider.SlackOauth2ProviderConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreOauth2CredentialProviderOauth2ProviderConfigPropertyToTerraform(struct?: AwsBedrockagentcoreOauth2CredentialProvider.Oauth2ProviderConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreOauth2CredentialProviderOauth2ProviderConfigPropertyToHclTerraform(struct?: AwsBedrockagentcoreOauth2CredentialProvider.Oauth2ProviderConfigProperty | cdktn.IResolvable): any;
export declare namespace AwsBedrockagentcoreOauth2CredentialProvider {
    interface ClientSecretArnProperty {
    }
    class ClientSecretArnPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ClientSecretArnProperty | undefined;
        set internalValue(value: ClientSecretArnProperty | undefined);
        get secretArn(): string;
    }
    class ClientSecretArnPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ClientSecretArnPropertyOutputReference;
    }
    interface Oauth2ProviderConfigCustomOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#authorization_endpoint AwsBedrockagentcoreOauth2CredentialProvider#authorization_endpoint}
        */
        readonly authorizationEndpoint: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#issuer AwsBedrockagentcoreOauth2CredentialProvider#issuer}
        */
        readonly issuer: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#response_types AwsBedrockagentcoreOauth2CredentialProvider#response_types}
        */
        readonly responseTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#token_endpoint AwsBedrockagentcoreOauth2CredentialProvider#token_endpoint}
        */
        readonly tokenEndpoint: string;
    }
    class Oauth2ProviderConfigCustomOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): Oauth2ProviderConfigCustomOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataProperty | cdktn.IResolvable | undefined;
        set internalValue(value: Oauth2ProviderConfigCustomOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataProperty | cdktn.IResolvable | undefined);
        private _authorizationEndpoint?;
        get authorizationEndpoint(): string;
        set authorizationEndpoint(value: string);
        get authorizationEndpointInput(): string | undefined;
        private _issuer?;
        get issuer(): string;
        set issuer(value: string);
        get issuerInput(): string | undefined;
        private _responseTypes?;
        get responseTypes(): string[];
        set responseTypes(value: string[]);
        resetResponseTypes(): void;
        get responseTypesInput(): string[] | undefined;
        private _tokenEndpoint?;
        get tokenEndpoint(): string;
        set tokenEndpoint(value: string);
        get tokenEndpointInput(): string | undefined;
    }
    class Oauth2ProviderConfigCustomOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataPropertyList extends cdktn.ComplexList {
        internalValue?: Oauth2ProviderConfigCustomOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): Oauth2ProviderConfigCustomOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataPropertyOutputReference;
    }
    interface Oauth2ProviderConfigCustomOauth2ProviderConfigOauthDiscoveryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#discovery_url AwsBedrockagentcoreOauth2CredentialProvider#discovery_url}
        */
        readonly discoveryUrl?: string;
        /**
        * authorization_server_metadata block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#authorization_server_metadata AwsBedrockagentcoreOauth2CredentialProvider#authorization_server_metadata}
        */
        readonly authorizationServerMetadata?: Oauth2ProviderConfigCustomOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataProperty[] | cdktn.IResolvable;
    }
    class Oauth2ProviderConfigCustomOauth2ProviderConfigOauthDiscoveryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): Oauth2ProviderConfigCustomOauth2ProviderConfigOauthDiscoveryProperty | cdktn.IResolvable | undefined;
        set internalValue(value: Oauth2ProviderConfigCustomOauth2ProviderConfigOauthDiscoveryProperty | cdktn.IResolvable | undefined);
        private _discoveryUrl?;
        get discoveryUrl(): string;
        set discoveryUrl(value: string);
        resetDiscoveryUrl(): void;
        get discoveryUrlInput(): string | undefined;
        private _authorizationServerMetadata;
        get authorizationServerMetadata(): Oauth2ProviderConfigCustomOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataPropertyList;
        putAuthorizationServerMetadata(value: Oauth2ProviderConfigCustomOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataProperty[] | cdktn.IResolvable): void;
        resetAuthorizationServerMetadata(): void;
        get authorizationServerMetadataInput(): cdktn.IResolvable | Oauth2ProviderConfigCustomOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataProperty[] | undefined;
    }
    class Oauth2ProviderConfigCustomOauth2ProviderConfigOauthDiscoveryPropertyList extends cdktn.ComplexList {
        internalValue?: Oauth2ProviderConfigCustomOauth2ProviderConfigOauthDiscoveryProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): Oauth2ProviderConfigCustomOauth2ProviderConfigOauthDiscoveryPropertyOutputReference;
    }
    interface CustomOauth2ProviderConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#client_credentials_wo_version AwsBedrockagentcoreOauth2CredentialProvider#client_credentials_wo_version}
        */
        readonly clientCredentialsWoVersion?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#client_id AwsBedrockagentcoreOauth2CredentialProvider#client_id}
        */
        readonly clientId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#client_id_wo AwsBedrockagentcoreOauth2CredentialProvider#client_id_wo}
        */
        readonly clientIdWo?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#client_secret AwsBedrockagentcoreOauth2CredentialProvider#client_secret}
        */
        readonly clientSecret?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#client_secret_wo AwsBedrockagentcoreOauth2CredentialProvider#client_secret_wo}
        */
        readonly clientSecretWo?: string;
        /**
        * oauth_discovery block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#oauth_discovery AwsBedrockagentcoreOauth2CredentialProvider#oauth_discovery}
        */
        readonly oauthDiscovery?: Oauth2ProviderConfigCustomOauth2ProviderConfigOauthDiscoveryProperty[] | cdktn.IResolvable;
    }
    class CustomOauth2ProviderConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomOauth2ProviderConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CustomOauth2ProviderConfigProperty | cdktn.IResolvable | undefined);
        private _clientCredentialsWoVersion?;
        get clientCredentialsWoVersion(): number;
        set clientCredentialsWoVersion(value: number);
        resetClientCredentialsWoVersion(): void;
        get clientCredentialsWoVersionInput(): number | undefined;
        private _clientId?;
        get clientId(): string;
        set clientId(value: string);
        resetClientId(): void;
        get clientIdInput(): string | undefined;
        private _clientIdWo?;
        /**
        * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
        */
        get clientIdWo(): string;
        set clientIdWo(value: string);
        resetClientIdWo(): void;
        get clientIdWoInput(): string | undefined;
        private _clientSecret?;
        get clientSecret(): string;
        set clientSecret(value: string);
        resetClientSecret(): void;
        get clientSecretInput(): string | undefined;
        private _clientSecretWo?;
        /**
        * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
        */
        get clientSecretWo(): string;
        set clientSecretWo(value: string);
        resetClientSecretWo(): void;
        get clientSecretWoInput(): string | undefined;
        private _oauthDiscovery;
        get oauthDiscovery(): Oauth2ProviderConfigCustomOauth2ProviderConfigOauthDiscoveryPropertyList;
        putOauthDiscovery(value: Oauth2ProviderConfigCustomOauth2ProviderConfigOauthDiscoveryProperty[] | cdktn.IResolvable): void;
        resetOauthDiscovery(): void;
        get oauthDiscoveryInput(): cdktn.IResolvable | Oauth2ProviderConfigCustomOauth2ProviderConfigOauthDiscoveryProperty[] | undefined;
    }
    class CustomOauth2ProviderConfigPropertyList extends cdktn.ComplexList {
        internalValue?: CustomOauth2ProviderConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomOauth2ProviderConfigPropertyOutputReference;
    }
    interface Oauth2ProviderConfigGithubOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataProperty {
    }
    class Oauth2ProviderConfigGithubOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): Oauth2ProviderConfigGithubOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataProperty | undefined;
        set internalValue(value: Oauth2ProviderConfigGithubOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataProperty | undefined);
        get authorizationEndpoint(): string;
        get issuer(): string;
        get responseTypes(): string[];
        get tokenEndpoint(): string;
    }
    class Oauth2ProviderConfigGithubOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): Oauth2ProviderConfigGithubOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataPropertyOutputReference;
    }
    interface Oauth2ProviderConfigGithubOauth2ProviderConfigOauthDiscoveryProperty {
    }
    class Oauth2ProviderConfigGithubOauth2ProviderConfigOauthDiscoveryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): Oauth2ProviderConfigGithubOauth2ProviderConfigOauthDiscoveryProperty | undefined;
        set internalValue(value: Oauth2ProviderConfigGithubOauth2ProviderConfigOauthDiscoveryProperty | undefined);
        private _authorizationServerMetadata;
        get authorizationServerMetadata(): Oauth2ProviderConfigGithubOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataPropertyList;
        get discoveryUrl(): string;
    }
    class Oauth2ProviderConfigGithubOauth2ProviderConfigOauthDiscoveryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): Oauth2ProviderConfigGithubOauth2ProviderConfigOauthDiscoveryPropertyOutputReference;
    }
    interface GithubOauth2ProviderConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#client_credentials_wo_version AwsBedrockagentcoreOauth2CredentialProvider#client_credentials_wo_version}
        */
        readonly clientCredentialsWoVersion?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#client_id AwsBedrockagentcoreOauth2CredentialProvider#client_id}
        */
        readonly clientId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#client_id_wo AwsBedrockagentcoreOauth2CredentialProvider#client_id_wo}
        */
        readonly clientIdWo?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#client_secret AwsBedrockagentcoreOauth2CredentialProvider#client_secret}
        */
        readonly clientSecret?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#client_secret_wo AwsBedrockagentcoreOauth2CredentialProvider#client_secret_wo}
        */
        readonly clientSecretWo?: string;
    }
    class GithubOauth2ProviderConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GithubOauth2ProviderConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: GithubOauth2ProviderConfigProperty | cdktn.IResolvable | undefined);
        private _clientCredentialsWoVersion?;
        get clientCredentialsWoVersion(): number;
        set clientCredentialsWoVersion(value: number);
        resetClientCredentialsWoVersion(): void;
        get clientCredentialsWoVersionInput(): number | undefined;
        private _clientId?;
        get clientId(): string;
        set clientId(value: string);
        resetClientId(): void;
        get clientIdInput(): string | undefined;
        private _clientIdWo?;
        /**
        * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
        */
        get clientIdWo(): string;
        set clientIdWo(value: string);
        resetClientIdWo(): void;
        get clientIdWoInput(): string | undefined;
        private _clientSecret?;
        get clientSecret(): string;
        set clientSecret(value: string);
        resetClientSecret(): void;
        get clientSecretInput(): string | undefined;
        private _clientSecretWo?;
        /**
        * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
        */
        get clientSecretWo(): string;
        set clientSecretWo(value: string);
        resetClientSecretWo(): void;
        get clientSecretWoInput(): string | undefined;
        private _oauthDiscovery;
        get oauthDiscovery(): Oauth2ProviderConfigGithubOauth2ProviderConfigOauthDiscoveryPropertyList;
    }
    class GithubOauth2ProviderConfigPropertyList extends cdktn.ComplexList {
        internalValue?: GithubOauth2ProviderConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GithubOauth2ProviderConfigPropertyOutputReference;
    }
    interface Oauth2ProviderConfigGoogleOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataProperty {
    }
    class Oauth2ProviderConfigGoogleOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): Oauth2ProviderConfigGoogleOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataProperty | undefined;
        set internalValue(value: Oauth2ProviderConfigGoogleOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataProperty | undefined);
        get authorizationEndpoint(): string;
        get issuer(): string;
        get responseTypes(): string[];
        get tokenEndpoint(): string;
    }
    class Oauth2ProviderConfigGoogleOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): Oauth2ProviderConfigGoogleOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataPropertyOutputReference;
    }
    interface Oauth2ProviderConfigGoogleOauth2ProviderConfigOauthDiscoveryProperty {
    }
    class Oauth2ProviderConfigGoogleOauth2ProviderConfigOauthDiscoveryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): Oauth2ProviderConfigGoogleOauth2ProviderConfigOauthDiscoveryProperty | undefined;
        set internalValue(value: Oauth2ProviderConfigGoogleOauth2ProviderConfigOauthDiscoveryProperty | undefined);
        private _authorizationServerMetadata;
        get authorizationServerMetadata(): Oauth2ProviderConfigGoogleOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataPropertyList;
        get discoveryUrl(): string;
    }
    class Oauth2ProviderConfigGoogleOauth2ProviderConfigOauthDiscoveryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): Oauth2ProviderConfigGoogleOauth2ProviderConfigOauthDiscoveryPropertyOutputReference;
    }
    interface GoogleOauth2ProviderConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#client_credentials_wo_version AwsBedrockagentcoreOauth2CredentialProvider#client_credentials_wo_version}
        */
        readonly clientCredentialsWoVersion?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#client_id AwsBedrockagentcoreOauth2CredentialProvider#client_id}
        */
        readonly clientId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#client_id_wo AwsBedrockagentcoreOauth2CredentialProvider#client_id_wo}
        */
        readonly clientIdWo?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#client_secret AwsBedrockagentcoreOauth2CredentialProvider#client_secret}
        */
        readonly clientSecret?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#client_secret_wo AwsBedrockagentcoreOauth2CredentialProvider#client_secret_wo}
        */
        readonly clientSecretWo?: string;
    }
    class GoogleOauth2ProviderConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GoogleOauth2ProviderConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: GoogleOauth2ProviderConfigProperty | cdktn.IResolvable | undefined);
        private _clientCredentialsWoVersion?;
        get clientCredentialsWoVersion(): number;
        set clientCredentialsWoVersion(value: number);
        resetClientCredentialsWoVersion(): void;
        get clientCredentialsWoVersionInput(): number | undefined;
        private _clientId?;
        get clientId(): string;
        set clientId(value: string);
        resetClientId(): void;
        get clientIdInput(): string | undefined;
        private _clientIdWo?;
        /**
        * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
        */
        get clientIdWo(): string;
        set clientIdWo(value: string);
        resetClientIdWo(): void;
        get clientIdWoInput(): string | undefined;
        private _clientSecret?;
        get clientSecret(): string;
        set clientSecret(value: string);
        resetClientSecret(): void;
        get clientSecretInput(): string | undefined;
        private _clientSecretWo?;
        /**
        * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
        */
        get clientSecretWo(): string;
        set clientSecretWo(value: string);
        resetClientSecretWo(): void;
        get clientSecretWoInput(): string | undefined;
        private _oauthDiscovery;
        get oauthDiscovery(): Oauth2ProviderConfigGoogleOauth2ProviderConfigOauthDiscoveryPropertyList;
    }
    class GoogleOauth2ProviderConfigPropertyList extends cdktn.ComplexList {
        internalValue?: GoogleOauth2ProviderConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GoogleOauth2ProviderConfigPropertyOutputReference;
    }
    interface Oauth2ProviderConfigMicrosoftOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataProperty {
    }
    class Oauth2ProviderConfigMicrosoftOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): Oauth2ProviderConfigMicrosoftOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataProperty | undefined;
        set internalValue(value: Oauth2ProviderConfigMicrosoftOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataProperty | undefined);
        get authorizationEndpoint(): string;
        get issuer(): string;
        get responseTypes(): string[];
        get tokenEndpoint(): string;
    }
    class Oauth2ProviderConfigMicrosoftOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): Oauth2ProviderConfigMicrosoftOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataPropertyOutputReference;
    }
    interface Oauth2ProviderConfigMicrosoftOauth2ProviderConfigOauthDiscoveryProperty {
    }
    class Oauth2ProviderConfigMicrosoftOauth2ProviderConfigOauthDiscoveryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): Oauth2ProviderConfigMicrosoftOauth2ProviderConfigOauthDiscoveryProperty | undefined;
        set internalValue(value: Oauth2ProviderConfigMicrosoftOauth2ProviderConfigOauthDiscoveryProperty | undefined);
        private _authorizationServerMetadata;
        get authorizationServerMetadata(): Oauth2ProviderConfigMicrosoftOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataPropertyList;
        get discoveryUrl(): string;
    }
    class Oauth2ProviderConfigMicrosoftOauth2ProviderConfigOauthDiscoveryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): Oauth2ProviderConfigMicrosoftOauth2ProviderConfigOauthDiscoveryPropertyOutputReference;
    }
    interface MicrosoftOauth2ProviderConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#client_credentials_wo_version AwsBedrockagentcoreOauth2CredentialProvider#client_credentials_wo_version}
        */
        readonly clientCredentialsWoVersion?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#client_id AwsBedrockagentcoreOauth2CredentialProvider#client_id}
        */
        readonly clientId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#client_id_wo AwsBedrockagentcoreOauth2CredentialProvider#client_id_wo}
        */
        readonly clientIdWo?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#client_secret AwsBedrockagentcoreOauth2CredentialProvider#client_secret}
        */
        readonly clientSecret?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#client_secret_wo AwsBedrockagentcoreOauth2CredentialProvider#client_secret_wo}
        */
        readonly clientSecretWo?: string;
    }
    class MicrosoftOauth2ProviderConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MicrosoftOauth2ProviderConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MicrosoftOauth2ProviderConfigProperty | cdktn.IResolvable | undefined);
        private _clientCredentialsWoVersion?;
        get clientCredentialsWoVersion(): number;
        set clientCredentialsWoVersion(value: number);
        resetClientCredentialsWoVersion(): void;
        get clientCredentialsWoVersionInput(): number | undefined;
        private _clientId?;
        get clientId(): string;
        set clientId(value: string);
        resetClientId(): void;
        get clientIdInput(): string | undefined;
        private _clientIdWo?;
        /**
        * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
        */
        get clientIdWo(): string;
        set clientIdWo(value: string);
        resetClientIdWo(): void;
        get clientIdWoInput(): string | undefined;
        private _clientSecret?;
        get clientSecret(): string;
        set clientSecret(value: string);
        resetClientSecret(): void;
        get clientSecretInput(): string | undefined;
        private _clientSecretWo?;
        /**
        * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
        */
        get clientSecretWo(): string;
        set clientSecretWo(value: string);
        resetClientSecretWo(): void;
        get clientSecretWoInput(): string | undefined;
        private _oauthDiscovery;
        get oauthDiscovery(): Oauth2ProviderConfigMicrosoftOauth2ProviderConfigOauthDiscoveryPropertyList;
    }
    class MicrosoftOauth2ProviderConfigPropertyList extends cdktn.ComplexList {
        internalValue?: MicrosoftOauth2ProviderConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MicrosoftOauth2ProviderConfigPropertyOutputReference;
    }
    interface Oauth2ProviderConfigSalesforceOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataProperty {
    }
    class Oauth2ProviderConfigSalesforceOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): Oauth2ProviderConfigSalesforceOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataProperty | undefined;
        set internalValue(value: Oauth2ProviderConfigSalesforceOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataProperty | undefined);
        get authorizationEndpoint(): string;
        get issuer(): string;
        get responseTypes(): string[];
        get tokenEndpoint(): string;
    }
    class Oauth2ProviderConfigSalesforceOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): Oauth2ProviderConfigSalesforceOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataPropertyOutputReference;
    }
    interface Oauth2ProviderConfigSalesforceOauth2ProviderConfigOauthDiscoveryProperty {
    }
    class Oauth2ProviderConfigSalesforceOauth2ProviderConfigOauthDiscoveryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): Oauth2ProviderConfigSalesforceOauth2ProviderConfigOauthDiscoveryProperty | undefined;
        set internalValue(value: Oauth2ProviderConfigSalesforceOauth2ProviderConfigOauthDiscoveryProperty | undefined);
        private _authorizationServerMetadata;
        get authorizationServerMetadata(): Oauth2ProviderConfigSalesforceOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataPropertyList;
        get discoveryUrl(): string;
    }
    class Oauth2ProviderConfigSalesforceOauth2ProviderConfigOauthDiscoveryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): Oauth2ProviderConfigSalesforceOauth2ProviderConfigOauthDiscoveryPropertyOutputReference;
    }
    interface SalesforceOauth2ProviderConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#client_credentials_wo_version AwsBedrockagentcoreOauth2CredentialProvider#client_credentials_wo_version}
        */
        readonly clientCredentialsWoVersion?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#client_id AwsBedrockagentcoreOauth2CredentialProvider#client_id}
        */
        readonly clientId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#client_id_wo AwsBedrockagentcoreOauth2CredentialProvider#client_id_wo}
        */
        readonly clientIdWo?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#client_secret AwsBedrockagentcoreOauth2CredentialProvider#client_secret}
        */
        readonly clientSecret?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#client_secret_wo AwsBedrockagentcoreOauth2CredentialProvider#client_secret_wo}
        */
        readonly clientSecretWo?: string;
    }
    class SalesforceOauth2ProviderConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SalesforceOauth2ProviderConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SalesforceOauth2ProviderConfigProperty | cdktn.IResolvable | undefined);
        private _clientCredentialsWoVersion?;
        get clientCredentialsWoVersion(): number;
        set clientCredentialsWoVersion(value: number);
        resetClientCredentialsWoVersion(): void;
        get clientCredentialsWoVersionInput(): number | undefined;
        private _clientId?;
        get clientId(): string;
        set clientId(value: string);
        resetClientId(): void;
        get clientIdInput(): string | undefined;
        private _clientIdWo?;
        /**
        * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
        */
        get clientIdWo(): string;
        set clientIdWo(value: string);
        resetClientIdWo(): void;
        get clientIdWoInput(): string | undefined;
        private _clientSecret?;
        get clientSecret(): string;
        set clientSecret(value: string);
        resetClientSecret(): void;
        get clientSecretInput(): string | undefined;
        private _clientSecretWo?;
        /**
        * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
        */
        get clientSecretWo(): string;
        set clientSecretWo(value: string);
        resetClientSecretWo(): void;
        get clientSecretWoInput(): string | undefined;
        private _oauthDiscovery;
        get oauthDiscovery(): Oauth2ProviderConfigSalesforceOauth2ProviderConfigOauthDiscoveryPropertyList;
    }
    class SalesforceOauth2ProviderConfigPropertyList extends cdktn.ComplexList {
        internalValue?: SalesforceOauth2ProviderConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SalesforceOauth2ProviderConfigPropertyOutputReference;
    }
    interface Oauth2ProviderConfigSlackOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataProperty {
    }
    class Oauth2ProviderConfigSlackOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): Oauth2ProviderConfigSlackOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataProperty | undefined;
        set internalValue(value: Oauth2ProviderConfigSlackOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataProperty | undefined);
        get authorizationEndpoint(): string;
        get issuer(): string;
        get responseTypes(): string[];
        get tokenEndpoint(): string;
    }
    class Oauth2ProviderConfigSlackOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): Oauth2ProviderConfigSlackOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataPropertyOutputReference;
    }
    interface Oauth2ProviderConfigSlackOauth2ProviderConfigOauthDiscoveryProperty {
    }
    class Oauth2ProviderConfigSlackOauth2ProviderConfigOauthDiscoveryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): Oauth2ProviderConfigSlackOauth2ProviderConfigOauthDiscoveryProperty | undefined;
        set internalValue(value: Oauth2ProviderConfigSlackOauth2ProviderConfigOauthDiscoveryProperty | undefined);
        private _authorizationServerMetadata;
        get authorizationServerMetadata(): Oauth2ProviderConfigSlackOauth2ProviderConfigOauthDiscoveryAuthorizationServerMetadataPropertyList;
        get discoveryUrl(): string;
    }
    class Oauth2ProviderConfigSlackOauth2ProviderConfigOauthDiscoveryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): Oauth2ProviderConfigSlackOauth2ProviderConfigOauthDiscoveryPropertyOutputReference;
    }
    interface SlackOauth2ProviderConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#client_credentials_wo_version AwsBedrockagentcoreOauth2CredentialProvider#client_credentials_wo_version}
        */
        readonly clientCredentialsWoVersion?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#client_id AwsBedrockagentcoreOauth2CredentialProvider#client_id}
        */
        readonly clientId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#client_id_wo AwsBedrockagentcoreOauth2CredentialProvider#client_id_wo}
        */
        readonly clientIdWo?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#client_secret AwsBedrockagentcoreOauth2CredentialProvider#client_secret}
        */
        readonly clientSecret?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#client_secret_wo AwsBedrockagentcoreOauth2CredentialProvider#client_secret_wo}
        */
        readonly clientSecretWo?: string;
    }
    class SlackOauth2ProviderConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SlackOauth2ProviderConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SlackOauth2ProviderConfigProperty | cdktn.IResolvable | undefined);
        private _clientCredentialsWoVersion?;
        get clientCredentialsWoVersion(): number;
        set clientCredentialsWoVersion(value: number);
        resetClientCredentialsWoVersion(): void;
        get clientCredentialsWoVersionInput(): number | undefined;
        private _clientId?;
        get clientId(): string;
        set clientId(value: string);
        resetClientId(): void;
        get clientIdInput(): string | undefined;
        private _clientIdWo?;
        /**
        * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
        */
        get clientIdWo(): string;
        set clientIdWo(value: string);
        resetClientIdWo(): void;
        get clientIdWoInput(): string | undefined;
        private _clientSecret?;
        get clientSecret(): string;
        set clientSecret(value: string);
        resetClientSecret(): void;
        get clientSecretInput(): string | undefined;
        private _clientSecretWo?;
        /**
        * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
        */
        get clientSecretWo(): string;
        set clientSecretWo(value: string);
        resetClientSecretWo(): void;
        get clientSecretWoInput(): string | undefined;
        private _oauthDiscovery;
        get oauthDiscovery(): Oauth2ProviderConfigSlackOauth2ProviderConfigOauthDiscoveryPropertyList;
    }
    class SlackOauth2ProviderConfigPropertyList extends cdktn.ComplexList {
        internalValue?: SlackOauth2ProviderConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SlackOauth2ProviderConfigPropertyOutputReference;
    }
    interface Oauth2ProviderConfigProperty {
        /**
        * custom_oauth2_provider_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#custom_oauth2_provider_config AwsBedrockagentcoreOauth2CredentialProvider#custom_oauth2_provider_config}
        */
        readonly customOauth2ProviderConfig?: CustomOauth2ProviderConfigProperty[] | cdktn.IResolvable;
        /**
        * github_oauth2_provider_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#github_oauth2_provider_config AwsBedrockagentcoreOauth2CredentialProvider#github_oauth2_provider_config}
        */
        readonly githubOauth2ProviderConfig?: GithubOauth2ProviderConfigProperty[] | cdktn.IResolvable;
        /**
        * google_oauth2_provider_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#google_oauth2_provider_config AwsBedrockagentcoreOauth2CredentialProvider#google_oauth2_provider_config}
        */
        readonly googleOauth2ProviderConfig?: GoogleOauth2ProviderConfigProperty[] | cdktn.IResolvable;
        /**
        * microsoft_oauth2_provider_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#microsoft_oauth2_provider_config AwsBedrockagentcoreOauth2CredentialProvider#microsoft_oauth2_provider_config}
        */
        readonly microsoftOauth2ProviderConfig?: MicrosoftOauth2ProviderConfigProperty[] | cdktn.IResolvable;
        /**
        * salesforce_oauth2_provider_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#salesforce_oauth2_provider_config AwsBedrockagentcoreOauth2CredentialProvider#salesforce_oauth2_provider_config}
        */
        readonly salesforceOauth2ProviderConfig?: SalesforceOauth2ProviderConfigProperty[] | cdktn.IResolvable;
        /**
        * slack_oauth2_provider_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_oauth2_credential_provider#slack_oauth2_provider_config AwsBedrockagentcoreOauth2CredentialProvider#slack_oauth2_provider_config}
        */
        readonly slackOauth2ProviderConfig?: SlackOauth2ProviderConfigProperty[] | cdktn.IResolvable;
    }
    class Oauth2ProviderConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): Oauth2ProviderConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: Oauth2ProviderConfigProperty | cdktn.IResolvable | undefined);
        private _customOauth2ProviderConfig;
        get customOauth2ProviderConfig(): CustomOauth2ProviderConfigPropertyList;
        putCustomOauth2ProviderConfig(value: CustomOauth2ProviderConfigProperty[] | cdktn.IResolvable): void;
        resetCustomOauth2ProviderConfig(): void;
        get customOauth2ProviderConfigInput(): cdktn.IResolvable | CustomOauth2ProviderConfigProperty[] | undefined;
        private _githubOauth2ProviderConfig;
        get githubOauth2ProviderConfig(): GithubOauth2ProviderConfigPropertyList;
        putGithubOauth2ProviderConfig(value: GithubOauth2ProviderConfigProperty[] | cdktn.IResolvable): void;
        resetGithubOauth2ProviderConfig(): void;
        get githubOauth2ProviderConfigInput(): cdktn.IResolvable | GithubOauth2ProviderConfigProperty[] | undefined;
        private _googleOauth2ProviderConfig;
        get googleOauth2ProviderConfig(): GoogleOauth2ProviderConfigPropertyList;
        putGoogleOauth2ProviderConfig(value: GoogleOauth2ProviderConfigProperty[] | cdktn.IResolvable): void;
        resetGoogleOauth2ProviderConfig(): void;
        get googleOauth2ProviderConfigInput(): cdktn.IResolvable | GoogleOauth2ProviderConfigProperty[] | undefined;
        private _microsoftOauth2ProviderConfig;
        get microsoftOauth2ProviderConfig(): MicrosoftOauth2ProviderConfigPropertyList;
        putMicrosoftOauth2ProviderConfig(value: MicrosoftOauth2ProviderConfigProperty[] | cdktn.IResolvable): void;
        resetMicrosoftOauth2ProviderConfig(): void;
        get microsoftOauth2ProviderConfigInput(): cdktn.IResolvable | MicrosoftOauth2ProviderConfigProperty[] | undefined;
        private _salesforceOauth2ProviderConfig;
        get salesforceOauth2ProviderConfig(): SalesforceOauth2ProviderConfigPropertyList;
        putSalesforceOauth2ProviderConfig(value: SalesforceOauth2ProviderConfigProperty[] | cdktn.IResolvable): void;
        resetSalesforceOauth2ProviderConfig(): void;
        get salesforceOauth2ProviderConfigInput(): cdktn.IResolvable | SalesforceOauth2ProviderConfigProperty[] | undefined;
        private _slackOauth2ProviderConfig;
        get slackOauth2ProviderConfig(): SlackOauth2ProviderConfigPropertyList;
        putSlackOauth2ProviderConfig(value: SlackOauth2ProviderConfigProperty[] | cdktn.IResolvable): void;
        resetSlackOauth2ProviderConfig(): void;
        get slackOauth2ProviderConfigInput(): cdktn.IResolvable | SlackOauth2ProviderConfigProperty[] | undefined;
    }
    class Oauth2ProviderConfigPropertyList extends cdktn.ComplexList {
        internalValue?: Oauth2ProviderConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): Oauth2ProviderConfigPropertyOutputReference;
    }
}
