import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsBedrockagentcoreBrowserConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#description AwsBedrockagentcoreBrowser#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#execution_role_arn AwsBedrockagentcoreBrowser#execution_role_arn}
    */
    readonly executionRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#name AwsBedrockagentcoreBrowser#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#region AwsBedrockagentcoreBrowser#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#tags AwsBedrockagentcoreBrowser#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * browser_signing block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#browser_signing AwsBedrockagentcoreBrowser#browser_signing}
    */
    readonly browserSigning?: AwsBedrockagentcoreBrowser.BrowserSigningProperty[] | cdktn.IResolvable;
    /**
    * certificate block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#certificate AwsBedrockagentcoreBrowser#certificate}
    */
    readonly certificate?: AwsBedrockagentcoreBrowser.CertificateProperty[] | cdktn.IResolvable;
    /**
    * enterprise_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#enterprise_policy AwsBedrockagentcoreBrowser#enterprise_policy}
    */
    readonly enterprisePolicy?: AwsBedrockagentcoreBrowser.EnterprisePolicyProperty[] | cdktn.IResolvable;
    /**
    * network_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#network_configuration AwsBedrockagentcoreBrowser#network_configuration}
    */
    readonly networkConfiguration?: AwsBedrockagentcoreBrowser.NetworkConfigurationProperty[] | cdktn.IResolvable;
    /**
    * recording block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#recording AwsBedrockagentcoreBrowser#recording}
    */
    readonly recording?: AwsBedrockagentcoreBrowser.RecordingProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#timeouts AwsBedrockagentcoreBrowser#timeouts}
    */
    readonly timeouts?: AwsBedrockagentcoreBrowser.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser aws_bedrockagentcore_browser}
*/
export declare class AwsBedrockagentcoreBrowser extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrockagentcore_browser";
    /**
    * Generates CDKTN code for importing a AwsBedrockagentcoreBrowser resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsBedrockagentcoreBrowser to import
    * @param importFromId The id of the existing AwsBedrockagentcoreBrowser that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsBedrockagentcoreBrowser to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser aws_bedrockagentcore_browser} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsBedrockagentcoreBrowserConfig
    */
    constructor(scope: Construct, id: string, config: AwsBedrockagentcoreBrowserConfig);
    get browserArn(): string;
    get browserId(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _executionRoleArn?;
    get executionRoleArn(): string;
    set executionRoleArn(value: string);
    resetExecutionRoleArn(): void;
    get executionRoleArnInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _browserSigning;
    get browserSigning(): AwsBedrockagentcoreBrowser.BrowserSigningPropertyList;
    putBrowserSigning(value: AwsBedrockagentcoreBrowser.BrowserSigningProperty[] | cdktn.IResolvable): void;
    resetBrowserSigning(): void;
    get browserSigningInput(): cdktn.IResolvable | AwsBedrockagentcoreBrowser.BrowserSigningProperty[] | undefined;
    private _certificate;
    get certificate(): AwsBedrockagentcoreBrowser.CertificatePropertyList;
    putCertificate(value: AwsBedrockagentcoreBrowser.CertificateProperty[] | cdktn.IResolvable): void;
    resetCertificate(): void;
    get certificateInput(): cdktn.IResolvable | AwsBedrockagentcoreBrowser.CertificateProperty[] | undefined;
    private _enterprisePolicy;
    get enterprisePolicy(): AwsBedrockagentcoreBrowser.EnterprisePolicyPropertyList;
    putEnterprisePolicy(value: AwsBedrockagentcoreBrowser.EnterprisePolicyProperty[] | cdktn.IResolvable): void;
    resetEnterprisePolicy(): void;
    get enterprisePolicyInput(): cdktn.IResolvable | AwsBedrockagentcoreBrowser.EnterprisePolicyProperty[] | undefined;
    private _networkConfiguration;
    get networkConfiguration(): AwsBedrockagentcoreBrowser.NetworkConfigurationPropertyList;
    putNetworkConfiguration(value: AwsBedrockagentcoreBrowser.NetworkConfigurationProperty[] | cdktn.IResolvable): void;
    resetNetworkConfiguration(): void;
    get networkConfigurationInput(): cdktn.IResolvable | AwsBedrockagentcoreBrowser.NetworkConfigurationProperty[] | undefined;
    private _recording;
    get recording(): AwsBedrockagentcoreBrowser.RecordingPropertyList;
    putRecording(value: AwsBedrockagentcoreBrowser.RecordingProperty[] | cdktn.IResolvable): void;
    resetRecording(): void;
    get recordingInput(): cdktn.IResolvable | AwsBedrockagentcoreBrowser.RecordingProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsBedrockagentcoreBrowser.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsBedrockagentcoreBrowser.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsBedrockagentcoreBrowser.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsBedrockagentcoreBrowserBrowserSigningPropertyToTerraform(struct?: AwsBedrockagentcoreBrowser.BrowserSigningProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreBrowserBrowserSigningPropertyToHclTerraform(struct?: AwsBedrockagentcoreBrowser.BrowserSigningProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreBrowserSecretsManagerPropertyToTerraform(struct?: AwsBedrockagentcoreBrowser.SecretsManagerProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreBrowserSecretsManagerPropertyToHclTerraform(struct?: AwsBedrockagentcoreBrowser.SecretsManagerProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreBrowserCertificateLocationPropertyToTerraform(struct?: AwsBedrockagentcoreBrowser.CertificateLocationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreBrowserCertificateLocationPropertyToHclTerraform(struct?: AwsBedrockagentcoreBrowser.CertificateLocationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreBrowserCertificatePropertyToTerraform(struct?: AwsBedrockagentcoreBrowser.CertificateProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreBrowserCertificatePropertyToHclTerraform(struct?: AwsBedrockagentcoreBrowser.CertificateProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreBrowserS3PropertyToTerraform(struct?: AwsBedrockagentcoreBrowser.S3Property | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreBrowserS3PropertyToHclTerraform(struct?: AwsBedrockagentcoreBrowser.S3Property | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreBrowserEnterprisePolicyLocationPropertyToTerraform(struct?: AwsBedrockagentcoreBrowser.EnterprisePolicyLocationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreBrowserEnterprisePolicyLocationPropertyToHclTerraform(struct?: AwsBedrockagentcoreBrowser.EnterprisePolicyLocationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreBrowserEnterprisePolicyPropertyToTerraform(struct?: AwsBedrockagentcoreBrowser.EnterprisePolicyProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreBrowserEnterprisePolicyPropertyToHclTerraform(struct?: AwsBedrockagentcoreBrowser.EnterprisePolicyProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreBrowserVpcConfigPropertyToTerraform(struct?: AwsBedrockagentcoreBrowser.VpcConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreBrowserVpcConfigPropertyToHclTerraform(struct?: AwsBedrockagentcoreBrowser.VpcConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreBrowserNetworkConfigurationPropertyToTerraform(struct?: AwsBedrockagentcoreBrowser.NetworkConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreBrowserNetworkConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentcoreBrowser.NetworkConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreBrowserS3LocationPropertyToTerraform(struct?: AwsBedrockagentcoreBrowser.S3LocationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreBrowserS3LocationPropertyToHclTerraform(struct?: AwsBedrockagentcoreBrowser.S3LocationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreBrowserRecordingPropertyToTerraform(struct?: AwsBedrockagentcoreBrowser.RecordingProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreBrowserRecordingPropertyToHclTerraform(struct?: AwsBedrockagentcoreBrowser.RecordingProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreBrowserTimeoutsPropertyToTerraform(struct?: AwsBedrockagentcoreBrowser.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreBrowserTimeoutsPropertyToHclTerraform(struct?: AwsBedrockagentcoreBrowser.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsBedrockagentcoreBrowser {
    interface BrowserSigningProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#enabled AwsBedrockagentcoreBrowser#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
    }
    class BrowserSigningPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BrowserSigningProperty | cdktn.IResolvable | undefined;
        set internalValue(value: BrowserSigningProperty | cdktn.IResolvable | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    class BrowserSigningPropertyList extends cdktn.ComplexList {
        internalValue?: BrowserSigningProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BrowserSigningPropertyOutputReference;
    }
    interface SecretsManagerProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#secret_arn AwsBedrockagentcoreBrowser#secret_arn}
        */
        readonly secretArn: string;
    }
    class SecretsManagerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SecretsManagerProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SecretsManagerProperty | cdktn.IResolvable | undefined);
        private _secretArn?;
        get secretArn(): string;
        set secretArn(value: string);
        get secretArnInput(): string | undefined;
    }
    class SecretsManagerPropertyList extends cdktn.ComplexList {
        internalValue?: SecretsManagerProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SecretsManagerPropertyOutputReference;
    }
    interface CertificateLocationProperty {
        /**
        * secrets_manager block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#secrets_manager AwsBedrockagentcoreBrowser#secrets_manager}
        */
        readonly secretsManager?: SecretsManagerProperty[] | cdktn.IResolvable;
    }
    class CertificateLocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CertificateLocationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CertificateLocationProperty | cdktn.IResolvable | undefined);
        private _secretsManager;
        get secretsManager(): SecretsManagerPropertyList;
        putSecretsManager(value: SecretsManagerProperty[] | cdktn.IResolvable): void;
        resetSecretsManager(): void;
        get secretsManagerInput(): cdktn.IResolvable | SecretsManagerProperty[] | undefined;
    }
    class CertificateLocationPropertyList extends cdktn.ComplexList {
        internalValue?: CertificateLocationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CertificateLocationPropertyOutputReference;
    }
    interface CertificateProperty {
        /**
        * location block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#location AwsBedrockagentcoreBrowser#location}
        */
        readonly location?: CertificateLocationProperty[] | cdktn.IResolvable;
    }
    class CertificatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CertificateProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CertificateProperty | cdktn.IResolvable | undefined);
        private _location;
        get location(): CertificateLocationPropertyList;
        putLocation(value: CertificateLocationProperty[] | cdktn.IResolvable): void;
        resetLocation(): void;
        get locationInput(): cdktn.IResolvable | CertificateLocationProperty[] | undefined;
    }
    class CertificatePropertyList extends cdktn.ComplexList {
        internalValue?: CertificateProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CertificatePropertyOutputReference;
    }
    interface S3Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#bucket AwsBedrockagentcoreBrowser#bucket}
        */
        readonly bucket: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#prefix AwsBedrockagentcoreBrowser#prefix}
        */
        readonly prefix: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#version_id AwsBedrockagentcoreBrowser#version_id}
        */
        readonly versionId?: string;
    }
    class S3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3Property | cdktn.IResolvable | undefined;
        set internalValue(value: S3Property | cdktn.IResolvable | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        get bucketInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        get prefixInput(): string | undefined;
        private _versionId?;
        get versionId(): string;
        set versionId(value: string);
        resetVersionId(): void;
        get versionIdInput(): string | undefined;
    }
    class S3PropertyList extends cdktn.ComplexList {
        internalValue?: S3Property[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3PropertyOutputReference;
    }
    interface EnterprisePolicyLocationProperty {
        /**
        * s3 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#s3 AwsBedrockagentcoreBrowser#s3}
        */
        readonly s3?: S3Property[] | cdktn.IResolvable;
    }
    class EnterprisePolicyLocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EnterprisePolicyLocationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EnterprisePolicyLocationProperty | cdktn.IResolvable | undefined);
        private _s3;
        get s3(): S3PropertyList;
        putS3(value: S3Property[] | cdktn.IResolvable): void;
        resetS3(): void;
        get s3Input(): cdktn.IResolvable | S3Property[] | undefined;
    }
    class EnterprisePolicyLocationPropertyList extends cdktn.ComplexList {
        internalValue?: EnterprisePolicyLocationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EnterprisePolicyLocationPropertyOutputReference;
    }
    interface EnterprisePolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#type AwsBedrockagentcoreBrowser#type}
        */
        readonly type?: string;
        /**
        * location block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#location AwsBedrockagentcoreBrowser#location}
        */
        readonly location?: EnterprisePolicyLocationProperty[] | cdktn.IResolvable;
    }
    class EnterprisePolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EnterprisePolicyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EnterprisePolicyProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
        private _location;
        get location(): EnterprisePolicyLocationPropertyList;
        putLocation(value: EnterprisePolicyLocationProperty[] | cdktn.IResolvable): void;
        resetLocation(): void;
        get locationInput(): cdktn.IResolvable | EnterprisePolicyLocationProperty[] | undefined;
    }
    class EnterprisePolicyPropertyList extends cdktn.ComplexList {
        internalValue?: EnterprisePolicyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EnterprisePolicyPropertyOutputReference;
    }
    interface VpcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#security_groups AwsBedrockagentcoreBrowser#security_groups}
        */
        readonly securityGroups: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#subnets AwsBedrockagentcoreBrowser#subnets}
        */
        readonly subnets: string[];
    }
    class VpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpcConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VpcConfigProperty | cdktn.IResolvable | undefined);
        private _securityGroups?;
        get securityGroups(): string[];
        set securityGroups(value: string[]);
        get securityGroupsInput(): string[] | undefined;
        private _subnets?;
        get subnets(): string[];
        set subnets(value: string[]);
        get subnetsInput(): string[] | undefined;
    }
    class VpcConfigPropertyList extends cdktn.ComplexList {
        internalValue?: VpcConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpcConfigPropertyOutputReference;
    }
    interface NetworkConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#network_mode AwsBedrockagentcoreBrowser#network_mode}
        */
        readonly networkMode: string;
        /**
        * vpc_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#vpc_config AwsBedrockagentcoreBrowser#vpc_config}
        */
        readonly vpcConfig?: VpcConfigProperty[] | cdktn.IResolvable;
    }
    class NetworkConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NetworkConfigurationProperty | cdktn.IResolvable | undefined);
        private _networkMode?;
        get networkMode(): string;
        set networkMode(value: string);
        get networkModeInput(): string | undefined;
        private _vpcConfig;
        get vpcConfig(): VpcConfigPropertyList;
        putVpcConfig(value: VpcConfigProperty[] | cdktn.IResolvable): void;
        resetVpcConfig(): void;
        get vpcConfigInput(): cdktn.IResolvable | VpcConfigProperty[] | undefined;
    }
    class NetworkConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: NetworkConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkConfigurationPropertyOutputReference;
    }
    interface S3LocationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#bucket AwsBedrockagentcoreBrowser#bucket}
        */
        readonly bucket: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#prefix AwsBedrockagentcoreBrowser#prefix}
        */
        readonly prefix: string;
    }
    class S3LocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3LocationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3LocationProperty | cdktn.IResolvable | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        get bucketInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        get prefixInput(): string | undefined;
    }
    class S3LocationPropertyList extends cdktn.ComplexList {
        internalValue?: S3LocationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3LocationPropertyOutputReference;
    }
    interface RecordingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#enabled AwsBedrockagentcoreBrowser#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * s3_location block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#s3_location AwsBedrockagentcoreBrowser#s3_location}
        */
        readonly s3Location?: S3LocationProperty[] | cdktn.IResolvable;
    }
    class RecordingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RecordingProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RecordingProperty | cdktn.IResolvable | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _s3Location;
        get s3Location(): S3LocationPropertyList;
        putS3Location(value: S3LocationProperty[] | cdktn.IResolvable): void;
        resetS3Location(): void;
        get s3LocationInput(): cdktn.IResolvable | S3LocationProperty[] | undefined;
    }
    class RecordingPropertyList extends cdktn.ComplexList {
        internalValue?: RecordingProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RecordingPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#create AwsBedrockagentcoreBrowser#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_browser#delete AwsBedrockagentcoreBrowser#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
