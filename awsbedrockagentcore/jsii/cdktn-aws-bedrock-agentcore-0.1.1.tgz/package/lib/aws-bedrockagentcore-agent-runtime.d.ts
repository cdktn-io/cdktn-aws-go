import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsBedrockagentcoreAgentRuntimeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#agent_runtime_name AwsBedrockagentcoreAgentRuntime#agent_runtime_name}
    */
    readonly agentRuntimeName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#description AwsBedrockagentcoreAgentRuntime#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#environment_variables AwsBedrockagentcoreAgentRuntime#environment_variables}
    */
    readonly environmentVariables?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#lifecycle_configuration AwsBedrockagentcoreAgentRuntime#lifecycle_configuration}
    */
    readonly lifecycleConfiguration?: AwsBedrockagentcoreAgentRuntime.LifecycleConfigurationProperty[] | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#region AwsBedrockagentcoreAgentRuntime#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#role_arn AwsBedrockagentcoreAgentRuntime#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#tags AwsBedrockagentcoreAgentRuntime#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * agent_runtime_artifact block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#agent_runtime_artifact AwsBedrockagentcoreAgentRuntime#agent_runtime_artifact}
    */
    readonly agentRuntimeArtifact?: AwsBedrockagentcoreAgentRuntime.AgentRuntimeArtifactProperty[] | cdktn.IResolvable;
    /**
    * authorizer_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#authorizer_configuration AwsBedrockagentcoreAgentRuntime#authorizer_configuration}
    */
    readonly authorizerConfiguration?: AwsBedrockagentcoreAgentRuntime.AuthorizerConfigurationProperty[] | cdktn.IResolvable;
    /**
    * filesystem_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#filesystem_configuration AwsBedrockagentcoreAgentRuntime#filesystem_configuration}
    */
    readonly filesystemConfiguration?: AwsBedrockagentcoreAgentRuntime.FilesystemConfigurationProperty[] | cdktn.IResolvable;
    /**
    * network_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#network_configuration AwsBedrockagentcoreAgentRuntime#network_configuration}
    */
    readonly networkConfiguration?: AwsBedrockagentcoreAgentRuntime.NetworkConfigurationProperty[] | cdktn.IResolvable;
    /**
    * protocol_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#protocol_configuration AwsBedrockagentcoreAgentRuntime#protocol_configuration}
    */
    readonly protocolConfiguration?: AwsBedrockagentcoreAgentRuntime.ProtocolConfigurationProperty[] | cdktn.IResolvable;
    /**
    * request_header_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#request_header_configuration AwsBedrockagentcoreAgentRuntime#request_header_configuration}
    */
    readonly requestHeaderConfiguration?: AwsBedrockagentcoreAgentRuntime.RequestHeaderConfigurationProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#timeouts AwsBedrockagentcoreAgentRuntime#timeouts}
    */
    readonly timeouts?: AwsBedrockagentcoreAgentRuntime.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime aws_bedrockagentcore_agent_runtime}
*/
export declare class AwsBedrockagentcoreAgentRuntime extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrockagentcore_agent_runtime";
    /**
    * Generates CDKTN code for importing a AwsBedrockagentcoreAgentRuntime resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsBedrockagentcoreAgentRuntime to import
    * @param importFromId The id of the existing AwsBedrockagentcoreAgentRuntime that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsBedrockagentcoreAgentRuntime to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime aws_bedrockagentcore_agent_runtime} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsBedrockagentcoreAgentRuntimeConfig
    */
    constructor(scope: Construct, id: string, config: AwsBedrockagentcoreAgentRuntimeConfig);
    get agentRuntimeArn(): string;
    get agentRuntimeId(): string;
    private _agentRuntimeName?;
    get agentRuntimeName(): string;
    set agentRuntimeName(value: string);
    get agentRuntimeNameInput(): string | undefined;
    get agentRuntimeVersion(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _environmentVariables?;
    get environmentVariables(): {
        [key: string]: string;
    };
    set environmentVariables(value: {
        [key: string]: string;
    });
    resetEnvironmentVariables(): void;
    get environmentVariablesInput(): {
        [key: string]: string;
    } | undefined;
    private _lifecycleConfiguration;
    get lifecycleConfiguration(): AwsBedrockagentcoreAgentRuntime.LifecycleConfigurationPropertyList;
    putLifecycleConfiguration(value: AwsBedrockagentcoreAgentRuntime.LifecycleConfigurationProperty[] | cdktn.IResolvable): void;
    resetLifecycleConfiguration(): void;
    get lifecycleConfigurationInput(): cdktn.IResolvable | AwsBedrockagentcoreAgentRuntime.LifecycleConfigurationProperty[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _workloadIdentityDetails;
    get workloadIdentityDetails(): AwsBedrockagentcoreAgentRuntime.WorkloadIdentityDetailsPropertyList;
    private _agentRuntimeArtifact;
    get agentRuntimeArtifact(): AwsBedrockagentcoreAgentRuntime.AgentRuntimeArtifactPropertyList;
    putAgentRuntimeArtifact(value: AwsBedrockagentcoreAgentRuntime.AgentRuntimeArtifactProperty[] | cdktn.IResolvable): void;
    resetAgentRuntimeArtifact(): void;
    get agentRuntimeArtifactInput(): cdktn.IResolvable | AwsBedrockagentcoreAgentRuntime.AgentRuntimeArtifactProperty[] | undefined;
    private _authorizerConfiguration;
    get authorizerConfiguration(): AwsBedrockagentcoreAgentRuntime.AuthorizerConfigurationPropertyList;
    putAuthorizerConfiguration(value: AwsBedrockagentcoreAgentRuntime.AuthorizerConfigurationProperty[] | cdktn.IResolvable): void;
    resetAuthorizerConfiguration(): void;
    get authorizerConfigurationInput(): cdktn.IResolvable | AwsBedrockagentcoreAgentRuntime.AuthorizerConfigurationProperty[] | undefined;
    private _filesystemConfiguration;
    get filesystemConfiguration(): AwsBedrockagentcoreAgentRuntime.FilesystemConfigurationPropertyList;
    putFilesystemConfiguration(value: AwsBedrockagentcoreAgentRuntime.FilesystemConfigurationProperty[] | cdktn.IResolvable): void;
    resetFilesystemConfiguration(): void;
    get filesystemConfigurationInput(): cdktn.IResolvable | AwsBedrockagentcoreAgentRuntime.FilesystemConfigurationProperty[] | undefined;
    private _networkConfiguration;
    get networkConfiguration(): AwsBedrockagentcoreAgentRuntime.NetworkConfigurationPropertyList;
    putNetworkConfiguration(value: AwsBedrockagentcoreAgentRuntime.NetworkConfigurationProperty[] | cdktn.IResolvable): void;
    resetNetworkConfiguration(): void;
    get networkConfigurationInput(): cdktn.IResolvable | AwsBedrockagentcoreAgentRuntime.NetworkConfigurationProperty[] | undefined;
    private _protocolConfiguration;
    get protocolConfiguration(): AwsBedrockagentcoreAgentRuntime.ProtocolConfigurationPropertyList;
    putProtocolConfiguration(value: AwsBedrockagentcoreAgentRuntime.ProtocolConfigurationProperty[] | cdktn.IResolvable): void;
    resetProtocolConfiguration(): void;
    get protocolConfigurationInput(): cdktn.IResolvable | AwsBedrockagentcoreAgentRuntime.ProtocolConfigurationProperty[] | undefined;
    private _requestHeaderConfiguration;
    get requestHeaderConfiguration(): AwsBedrockagentcoreAgentRuntime.RequestHeaderConfigurationPropertyList;
    putRequestHeaderConfiguration(value: AwsBedrockagentcoreAgentRuntime.RequestHeaderConfigurationProperty[] | cdktn.IResolvable): void;
    resetRequestHeaderConfiguration(): void;
    get requestHeaderConfigurationInput(): cdktn.IResolvable | AwsBedrockagentcoreAgentRuntime.RequestHeaderConfigurationProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsBedrockagentcoreAgentRuntime.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsBedrockagentcoreAgentRuntime.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsBedrockagentcoreAgentRuntime.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsBedrockagentcoreAgentRuntimeLifecycleConfigurationPropertyToTerraform(struct?: AwsBedrockagentcoreAgentRuntime.LifecycleConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeLifecycleConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentcoreAgentRuntime.LifecycleConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeWorkloadIdentityDetailsPropertyToTerraform(struct?: AwsBedrockagentcoreAgentRuntime.WorkloadIdentityDetailsProperty): any;
export declare function awsBedrockagentcoreAgentRuntimeWorkloadIdentityDetailsPropertyToHclTerraform(struct?: AwsBedrockagentcoreAgentRuntime.WorkloadIdentityDetailsProperty): any;
export declare function awsBedrockagentcoreAgentRuntimeS3PropertyToTerraform(struct?: AwsBedrockagentcoreAgentRuntime.S3Property | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeS3PropertyToHclTerraform(struct?: AwsBedrockagentcoreAgentRuntime.S3Property | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeCodePropertyToTerraform(struct?: AwsBedrockagentcoreAgentRuntime.CodeProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeCodePropertyToHclTerraform(struct?: AwsBedrockagentcoreAgentRuntime.CodeProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeCodeConfigurationPropertyToTerraform(struct?: AwsBedrockagentcoreAgentRuntime.CodeConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeCodeConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentcoreAgentRuntime.CodeConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeContainerConfigurationPropertyToTerraform(struct?: AwsBedrockagentcoreAgentRuntime.ContainerConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeContainerConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentcoreAgentRuntime.ContainerConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeAgentRuntimeArtifactPropertyToTerraform(struct?: AwsBedrockagentcoreAgentRuntime.AgentRuntimeArtifactProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeAgentRuntimeArtifactPropertyToHclTerraform(struct?: AwsBedrockagentcoreAgentRuntime.AgentRuntimeArtifactProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeHostingEnvironmentPropertyToTerraform(struct?: AwsBedrockagentcoreAgentRuntime.HostingEnvironmentProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeHostingEnvironmentPropertyToHclTerraform(struct?: AwsBedrockagentcoreAgentRuntime.HostingEnvironmentProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeAllowedWorkloadConfigurationPropertyToTerraform(struct?: AwsBedrockagentcoreAgentRuntime.AllowedWorkloadConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeAllowedWorkloadConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentcoreAgentRuntime.AllowedWorkloadConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeClaimMatchValuePropertyToTerraform(struct?: AwsBedrockagentcoreAgentRuntime.ClaimMatchValueProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeClaimMatchValuePropertyToHclTerraform(struct?: AwsBedrockagentcoreAgentRuntime.ClaimMatchValueProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeAuthorizingClaimMatchValuePropertyToTerraform(struct?: AwsBedrockagentcoreAgentRuntime.AuthorizingClaimMatchValueProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeAuthorizingClaimMatchValuePropertyToHclTerraform(struct?: AwsBedrockagentcoreAgentRuntime.AuthorizingClaimMatchValueProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeCustomClaimPropertyToTerraform(struct?: AwsBedrockagentcoreAgentRuntime.CustomClaimProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeCustomClaimPropertyToHclTerraform(struct?: AwsBedrockagentcoreAgentRuntime.CustomClaimProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourcePropertyToTerraform(struct?: AwsBedrockagentcoreAgentRuntime.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourcePropertyToHclTerraform(struct?: AwsBedrockagentcoreAgentRuntime.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourcePropertyToTerraform(struct?: AwsBedrockagentcoreAgentRuntime.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourcePropertyToHclTerraform(struct?: AwsBedrockagentcoreAgentRuntime.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointPropertyToTerraform(struct?: AwsBedrockagentcoreAgentRuntime.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointPropertyToHclTerraform(struct?: AwsBedrockagentcoreAgentRuntime.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourcePropertyToTerraform(struct?: AwsBedrockagentcoreAgentRuntime.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourcePropertyToHclTerraform(struct?: AwsBedrockagentcoreAgentRuntime.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourcePropertyToTerraform(struct?: AwsBedrockagentcoreAgentRuntime.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourcePropertyToHclTerraform(struct?: AwsBedrockagentcoreAgentRuntime.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointPropertyToTerraform(struct?: AwsBedrockagentcoreAgentRuntime.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointPropertyToHclTerraform(struct?: AwsBedrockagentcoreAgentRuntime.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimePrivateEndpointOverridesPropertyToTerraform(struct?: AwsBedrockagentcoreAgentRuntime.PrivateEndpointOverridesProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimePrivateEndpointOverridesPropertyToHclTerraform(struct?: AwsBedrockagentcoreAgentRuntime.PrivateEndpointOverridesProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeCustomJwtAuthorizerPropertyToTerraform(struct?: AwsBedrockagentcoreAgentRuntime.CustomJwtAuthorizerProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeCustomJwtAuthorizerPropertyToHclTerraform(struct?: AwsBedrockagentcoreAgentRuntime.CustomJwtAuthorizerProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeAuthorizerConfigurationPropertyToTerraform(struct?: AwsBedrockagentcoreAgentRuntime.AuthorizerConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeAuthorizerConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentcoreAgentRuntime.AuthorizerConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeEfsAccessPointPropertyToTerraform(struct?: AwsBedrockagentcoreAgentRuntime.EfsAccessPointProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeEfsAccessPointPropertyToHclTerraform(struct?: AwsBedrockagentcoreAgentRuntime.EfsAccessPointProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeS3FilesAccessPointPropertyToTerraform(struct?: AwsBedrockagentcoreAgentRuntime.S3FilesAccessPointProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeS3FilesAccessPointPropertyToHclTerraform(struct?: AwsBedrockagentcoreAgentRuntime.S3FilesAccessPointProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeSessionStoragePropertyToTerraform(struct?: AwsBedrockagentcoreAgentRuntime.SessionStorageProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeSessionStoragePropertyToHclTerraform(struct?: AwsBedrockagentcoreAgentRuntime.SessionStorageProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeFilesystemConfigurationPropertyToTerraform(struct?: AwsBedrockagentcoreAgentRuntime.FilesystemConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeFilesystemConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentcoreAgentRuntime.FilesystemConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeNetworkModeConfigPropertyToTerraform(struct?: AwsBedrockagentcoreAgentRuntime.NetworkModeConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeNetworkModeConfigPropertyToHclTerraform(struct?: AwsBedrockagentcoreAgentRuntime.NetworkModeConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeNetworkConfigurationPropertyToTerraform(struct?: AwsBedrockagentcoreAgentRuntime.NetworkConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeNetworkConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentcoreAgentRuntime.NetworkConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeProtocolConfigurationPropertyToTerraform(struct?: AwsBedrockagentcoreAgentRuntime.ProtocolConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeProtocolConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentcoreAgentRuntime.ProtocolConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeRequestHeaderConfigurationPropertyToTerraform(struct?: AwsBedrockagentcoreAgentRuntime.RequestHeaderConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeRequestHeaderConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentcoreAgentRuntime.RequestHeaderConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeTimeoutsPropertyToTerraform(struct?: AwsBedrockagentcoreAgentRuntime.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreAgentRuntimeTimeoutsPropertyToHclTerraform(struct?: AwsBedrockagentcoreAgentRuntime.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsBedrockagentcoreAgentRuntime {
    interface LifecycleConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#idle_runtime_session_timeout AwsBedrockagentcoreAgentRuntime#idle_runtime_session_timeout}
        */
        readonly idleRuntimeSessionTimeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#max_lifetime AwsBedrockagentcoreAgentRuntime#max_lifetime}
        */
        readonly maxLifetime?: number;
    }
    class LifecycleConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LifecycleConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LifecycleConfigurationProperty | cdktn.IResolvable | undefined);
        private _idleRuntimeSessionTimeout?;
        get idleRuntimeSessionTimeout(): number;
        set idleRuntimeSessionTimeout(value: number);
        resetIdleRuntimeSessionTimeout(): void;
        get idleRuntimeSessionTimeoutInput(): number | undefined;
        private _maxLifetime?;
        get maxLifetime(): number;
        set maxLifetime(value: number);
        resetMaxLifetime(): void;
        get maxLifetimeInput(): number | undefined;
    }
    class LifecycleConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: LifecycleConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LifecycleConfigurationPropertyOutputReference;
    }
    interface WorkloadIdentityDetailsProperty {
    }
    class WorkloadIdentityDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkloadIdentityDetailsProperty | undefined;
        set internalValue(value: WorkloadIdentityDetailsProperty | undefined);
        get workloadIdentityArn(): string;
    }
    class WorkloadIdentityDetailsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkloadIdentityDetailsPropertyOutputReference;
    }
    interface S3Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#bucket AwsBedrockagentcoreAgentRuntime#bucket}
        */
        readonly bucket: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#prefix AwsBedrockagentcoreAgentRuntime#prefix}
        */
        readonly prefix: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#version_id AwsBedrockagentcoreAgentRuntime#version_id}
        */
        readonly versionId?: string;
    }
    class S3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3Property | cdktn.IResolvable | undefined;
        set internalValue(value: S3Property | cdktn.IResolvable | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        get bucketInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        get prefixInput(): string | undefined;
        private _versionId?;
        get versionId(): string;
        set versionId(value: string);
        resetVersionId(): void;
        get versionIdInput(): string | undefined;
    }
    class S3PropertyList extends cdktn.ComplexList {
        internalValue?: S3Property[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3PropertyOutputReference;
    }
    interface CodeProperty {
        /**
        * s3 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#s3 AwsBedrockagentcoreAgentRuntime#s3}
        */
        readonly s3?: S3Property[] | cdktn.IResolvable;
    }
    class CodePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CodeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CodeProperty | cdktn.IResolvable | undefined);
        private _s3;
        get s3(): S3PropertyList;
        putS3(value: S3Property[] | cdktn.IResolvable): void;
        resetS3(): void;
        get s3Input(): cdktn.IResolvable | S3Property[] | undefined;
    }
    class CodePropertyList extends cdktn.ComplexList {
        internalValue?: CodeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CodePropertyOutputReference;
    }
    interface CodeConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#entry_point AwsBedrockagentcoreAgentRuntime#entry_point}
        */
        readonly entryPoint: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#runtime AwsBedrockagentcoreAgentRuntime#runtime}
        */
        readonly runtime: string;
        /**
        * code block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#code AwsBedrockagentcoreAgentRuntime#code}
        */
        readonly code?: CodeProperty[] | cdktn.IResolvable;
    }
    class CodeConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CodeConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CodeConfigurationProperty | cdktn.IResolvable | undefined);
        private _entryPoint?;
        get entryPoint(): string[];
        set entryPoint(value: string[]);
        get entryPointInput(): string[] | undefined;
        private _runtime?;
        get runtime(): string;
        set runtime(value: string);
        get runtimeInput(): string | undefined;
        private _code;
        get code(): CodePropertyList;
        putCode(value: CodeProperty[] | cdktn.IResolvable): void;
        resetCode(): void;
        get codeInput(): cdktn.IResolvable | CodeProperty[] | undefined;
    }
    class CodeConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: CodeConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CodeConfigurationPropertyOutputReference;
    }
    interface ContainerConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#container_uri AwsBedrockagentcoreAgentRuntime#container_uri}
        */
        readonly containerUri: string;
    }
    class ContainerConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ContainerConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ContainerConfigurationProperty | cdktn.IResolvable | undefined);
        private _containerUri?;
        get containerUri(): string;
        set containerUri(value: string);
        get containerUriInput(): string | undefined;
    }
    class ContainerConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ContainerConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ContainerConfigurationPropertyOutputReference;
    }
    interface AgentRuntimeArtifactProperty {
        /**
        * code_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#code_configuration AwsBedrockagentcoreAgentRuntime#code_configuration}
        */
        readonly codeConfiguration?: CodeConfigurationProperty[] | cdktn.IResolvable;
        /**
        * container_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#container_configuration AwsBedrockagentcoreAgentRuntime#container_configuration}
        */
        readonly containerConfiguration?: ContainerConfigurationProperty[] | cdktn.IResolvable;
    }
    class AgentRuntimeArtifactPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AgentRuntimeArtifactProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AgentRuntimeArtifactProperty | cdktn.IResolvable | undefined);
        private _codeConfiguration;
        get codeConfiguration(): CodeConfigurationPropertyList;
        putCodeConfiguration(value: CodeConfigurationProperty[] | cdktn.IResolvable): void;
        resetCodeConfiguration(): void;
        get codeConfigurationInput(): cdktn.IResolvable | CodeConfigurationProperty[] | undefined;
        private _containerConfiguration;
        get containerConfiguration(): ContainerConfigurationPropertyList;
        putContainerConfiguration(value: ContainerConfigurationProperty[] | cdktn.IResolvable): void;
        resetContainerConfiguration(): void;
        get containerConfigurationInput(): cdktn.IResolvable | ContainerConfigurationProperty[] | undefined;
    }
    class AgentRuntimeArtifactPropertyList extends cdktn.ComplexList {
        internalValue?: AgentRuntimeArtifactProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AgentRuntimeArtifactPropertyOutputReference;
    }
    interface HostingEnvironmentProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#arn AwsBedrockagentcoreAgentRuntime#arn}
        */
        readonly arn: string;
    }
    class HostingEnvironmentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HostingEnvironmentProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HostingEnvironmentProperty | cdktn.IResolvable | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
    }
    class HostingEnvironmentPropertyList extends cdktn.ComplexList {
        internalValue?: HostingEnvironmentProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HostingEnvironmentPropertyOutputReference;
    }
    interface AllowedWorkloadConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#workload_identities AwsBedrockagentcoreAgentRuntime#workload_identities}
        */
        readonly workloadIdentities?: string[];
        /**
        * hosting_environment block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#hosting_environment AwsBedrockagentcoreAgentRuntime#hosting_environment}
        */
        readonly hostingEnvironment?: HostingEnvironmentProperty[] | cdktn.IResolvable;
    }
    class AllowedWorkloadConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AllowedWorkloadConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AllowedWorkloadConfigurationProperty | cdktn.IResolvable | undefined);
        private _workloadIdentities?;
        get workloadIdentities(): string[];
        set workloadIdentities(value: string[]);
        resetWorkloadIdentities(): void;
        get workloadIdentitiesInput(): string[] | undefined;
        private _hostingEnvironment;
        get hostingEnvironment(): HostingEnvironmentPropertyList;
        putHostingEnvironment(value: HostingEnvironmentProperty[] | cdktn.IResolvable): void;
        resetHostingEnvironment(): void;
        get hostingEnvironmentInput(): cdktn.IResolvable | HostingEnvironmentProperty[] | undefined;
    }
    class AllowedWorkloadConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: AllowedWorkloadConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AllowedWorkloadConfigurationPropertyOutputReference;
    }
    interface ClaimMatchValueProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#match_value_string AwsBedrockagentcoreAgentRuntime#match_value_string}
        */
        readonly matchValueString?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#match_value_string_list AwsBedrockagentcoreAgentRuntime#match_value_string_list}
        */
        readonly matchValueStringList?: string[];
    }
    class ClaimMatchValuePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ClaimMatchValueProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ClaimMatchValueProperty | cdktn.IResolvable | undefined);
        private _matchValueString?;
        get matchValueString(): string;
        set matchValueString(value: string);
        resetMatchValueString(): void;
        get matchValueStringInput(): string | undefined;
        private _matchValueStringList?;
        get matchValueStringList(): string[];
        set matchValueStringList(value: string[]);
        resetMatchValueStringList(): void;
        get matchValueStringListInput(): string[] | undefined;
    }
    class ClaimMatchValuePropertyList extends cdktn.ComplexList {
        internalValue?: ClaimMatchValueProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ClaimMatchValuePropertyOutputReference;
    }
    interface AuthorizingClaimMatchValueProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#claim_match_operator AwsBedrockagentcoreAgentRuntime#claim_match_operator}
        */
        readonly claimMatchOperator: string;
        /**
        * claim_match_value block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#claim_match_value AwsBedrockagentcoreAgentRuntime#claim_match_value}
        */
        readonly claimMatchValue?: ClaimMatchValueProperty[] | cdktn.IResolvable;
    }
    class AuthorizingClaimMatchValuePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthorizingClaimMatchValueProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthorizingClaimMatchValueProperty | cdktn.IResolvable | undefined);
        private _claimMatchOperator?;
        get claimMatchOperator(): string;
        set claimMatchOperator(value: string);
        get claimMatchOperatorInput(): string | undefined;
        private _claimMatchValue;
        get claimMatchValue(): ClaimMatchValuePropertyList;
        putClaimMatchValue(value: ClaimMatchValueProperty[] | cdktn.IResolvable): void;
        resetClaimMatchValue(): void;
        get claimMatchValueInput(): cdktn.IResolvable | ClaimMatchValueProperty[] | undefined;
    }
    class AuthorizingClaimMatchValuePropertyList extends cdktn.ComplexList {
        internalValue?: AuthorizingClaimMatchValueProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthorizingClaimMatchValuePropertyOutputReference;
    }
    interface CustomClaimProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#inbound_token_claim_name AwsBedrockagentcoreAgentRuntime#inbound_token_claim_name}
        */
        readonly inboundTokenClaimName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#inbound_token_claim_value_type AwsBedrockagentcoreAgentRuntime#inbound_token_claim_value_type}
        */
        readonly inboundTokenClaimValueType: string;
        /**
        * authorizing_claim_match_value block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#authorizing_claim_match_value AwsBedrockagentcoreAgentRuntime#authorizing_claim_match_value}
        */
        readonly authorizingClaimMatchValue?: AuthorizingClaimMatchValueProperty[] | cdktn.IResolvable;
    }
    class CustomClaimPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomClaimProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CustomClaimProperty | cdktn.IResolvable | undefined);
        private _inboundTokenClaimName?;
        get inboundTokenClaimName(): string;
        set inboundTokenClaimName(value: string);
        get inboundTokenClaimNameInput(): string | undefined;
        private _inboundTokenClaimValueType?;
        get inboundTokenClaimValueType(): string;
        set inboundTokenClaimValueType(value: string);
        get inboundTokenClaimValueTypeInput(): string | undefined;
        private _authorizingClaimMatchValue;
        get authorizingClaimMatchValue(): AuthorizingClaimMatchValuePropertyList;
        putAuthorizingClaimMatchValue(value: AuthorizingClaimMatchValueProperty[] | cdktn.IResolvable): void;
        resetAuthorizingClaimMatchValue(): void;
        get authorizingClaimMatchValueInput(): cdktn.IResolvable | AuthorizingClaimMatchValueProperty[] | undefined;
    }
    class CustomClaimPropertyList extends cdktn.ComplexList {
        internalValue?: CustomClaimProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomClaimPropertyOutputReference;
    }
    interface AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#endpoint_ip_address_type AwsBedrockagentcoreAgentRuntime#endpoint_ip_address_type}
        */
        readonly endpointIpAddressType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#routing_domain AwsBedrockagentcoreAgentRuntime#routing_domain}
        */
        readonly routingDomain?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#security_group_ids AwsBedrockagentcoreAgentRuntime#security_group_ids}
        */
        readonly securityGroupIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#subnet_ids AwsBedrockagentcoreAgentRuntime#subnet_ids}
        */
        readonly subnetIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#tags AwsBedrockagentcoreAgentRuntime#tags}
        */
        readonly tags?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#vpc_identifier AwsBedrockagentcoreAgentRuntime#vpc_identifier}
        */
        readonly vpcIdentifier: string;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceProperty | cdktn.IResolvable | undefined);
        private _endpointIpAddressType?;
        get endpointIpAddressType(): string;
        set endpointIpAddressType(value: string);
        get endpointIpAddressTypeInput(): string | undefined;
        private _routingDomain?;
        get routingDomain(): string;
        set routingDomain(value: string);
        resetRoutingDomain(): void;
        get routingDomainInput(): string | undefined;
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        resetSecurityGroupIds(): void;
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
        private _tags?;
        get tags(): {
            [key: string]: string;
        };
        set tags(value: {
            [key: string]: string;
        });
        resetTags(): void;
        get tagsInput(): {
            [key: string]: string;
        } | undefined;
        private _vpcIdentifier?;
        get vpcIdentifier(): string;
        set vpcIdentifier(value: string);
        get vpcIdentifierInput(): string | undefined;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourcePropertyList extends cdktn.ComplexList {
        internalValue?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourcePropertyOutputReference;
    }
    interface AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#resource_configuration_identifier AwsBedrockagentcoreAgentRuntime#resource_configuration_identifier}
        */
        readonly resourceConfigurationIdentifier: string;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceProperty | cdktn.IResolvable | undefined);
        private _resourceConfigurationIdentifier?;
        get resourceConfigurationIdentifier(): string;
        set resourceConfigurationIdentifier(value: string);
        get resourceConfigurationIdentifierInput(): string | undefined;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourcePropertyList extends cdktn.ComplexList {
        internalValue?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourcePropertyOutputReference;
    }
    interface AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointProperty {
        /**
        * managed_vpc_resource block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#managed_vpc_resource AwsBedrockagentcoreAgentRuntime#managed_vpc_resource}
        */
        readonly managedVpcResource?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceProperty[] | cdktn.IResolvable;
        /**
        * self_managed_lattice_resource block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#self_managed_lattice_resource AwsBedrockagentcoreAgentRuntime#self_managed_lattice_resource}
        */
        readonly selfManagedLatticeResource?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceProperty[] | cdktn.IResolvable;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointProperty | cdktn.IResolvable | undefined);
        private _managedVpcResource;
        get managedVpcResource(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourcePropertyList;
        putManagedVpcResource(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceProperty[] | cdktn.IResolvable): void;
        resetManagedVpcResource(): void;
        get managedVpcResourceInput(): cdktn.IResolvable | AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceProperty[] | undefined;
        private _selfManagedLatticeResource;
        get selfManagedLatticeResource(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourcePropertyList;
        putSelfManagedLatticeResource(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceProperty[] | cdktn.IResolvable): void;
        resetSelfManagedLatticeResource(): void;
        get selfManagedLatticeResourceInput(): cdktn.IResolvable | AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceProperty[] | undefined;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointPropertyList extends cdktn.ComplexList {
        internalValue?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointPropertyOutputReference;
    }
    interface AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#endpoint_ip_address_type AwsBedrockagentcoreAgentRuntime#endpoint_ip_address_type}
        */
        readonly endpointIpAddressType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#routing_domain AwsBedrockagentcoreAgentRuntime#routing_domain}
        */
        readonly routingDomain?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#security_group_ids AwsBedrockagentcoreAgentRuntime#security_group_ids}
        */
        readonly securityGroupIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#subnet_ids AwsBedrockagentcoreAgentRuntime#subnet_ids}
        */
        readonly subnetIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#tags AwsBedrockagentcoreAgentRuntime#tags}
        */
        readonly tags?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#vpc_identifier AwsBedrockagentcoreAgentRuntime#vpc_identifier}
        */
        readonly vpcIdentifier: string;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceProperty | cdktn.IResolvable | undefined);
        private _endpointIpAddressType?;
        get endpointIpAddressType(): string;
        set endpointIpAddressType(value: string);
        get endpointIpAddressTypeInput(): string | undefined;
        private _routingDomain?;
        get routingDomain(): string;
        set routingDomain(value: string);
        resetRoutingDomain(): void;
        get routingDomainInput(): string | undefined;
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        resetSecurityGroupIds(): void;
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
        private _tags?;
        get tags(): {
            [key: string]: string;
        };
        set tags(value: {
            [key: string]: string;
        });
        resetTags(): void;
        get tagsInput(): {
            [key: string]: string;
        } | undefined;
        private _vpcIdentifier?;
        get vpcIdentifier(): string;
        set vpcIdentifier(value: string);
        get vpcIdentifierInput(): string | undefined;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourcePropertyList extends cdktn.ComplexList {
        internalValue?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourcePropertyOutputReference;
    }
    interface AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#resource_configuration_identifier AwsBedrockagentcoreAgentRuntime#resource_configuration_identifier}
        */
        readonly resourceConfigurationIdentifier: string;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceProperty | cdktn.IResolvable | undefined);
        private _resourceConfigurationIdentifier?;
        get resourceConfigurationIdentifier(): string;
        set resourceConfigurationIdentifier(value: string);
        get resourceConfigurationIdentifierInput(): string | undefined;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourcePropertyList extends cdktn.ComplexList {
        internalValue?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourcePropertyOutputReference;
    }
    interface AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointProperty {
        /**
        * managed_vpc_resource block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#managed_vpc_resource AwsBedrockagentcoreAgentRuntime#managed_vpc_resource}
        */
        readonly managedVpcResource?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceProperty[] | cdktn.IResolvable;
        /**
        * self_managed_lattice_resource block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#self_managed_lattice_resource AwsBedrockagentcoreAgentRuntime#self_managed_lattice_resource}
        */
        readonly selfManagedLatticeResource?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceProperty[] | cdktn.IResolvable;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointProperty | cdktn.IResolvable | undefined);
        private _managedVpcResource;
        get managedVpcResource(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourcePropertyList;
        putManagedVpcResource(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceProperty[] | cdktn.IResolvable): void;
        resetManagedVpcResource(): void;
        get managedVpcResourceInput(): cdktn.IResolvable | AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceProperty[] | undefined;
        private _selfManagedLatticeResource;
        get selfManagedLatticeResource(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourcePropertyList;
        putSelfManagedLatticeResource(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceProperty[] | cdktn.IResolvable): void;
        resetSelfManagedLatticeResource(): void;
        get selfManagedLatticeResourceInput(): cdktn.IResolvable | AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceProperty[] | undefined;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointPropertyList extends cdktn.ComplexList {
        internalValue?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointPropertyOutputReference;
    }
    interface PrivateEndpointOverridesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#domain AwsBedrockagentcoreAgentRuntime#domain}
        */
        readonly domain: string;
        /**
        * private_endpoint block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#private_endpoint AwsBedrockagentcoreAgentRuntime#private_endpoint}
        */
        readonly privateEndpoint?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointProperty[] | cdktn.IResolvable;
    }
    class PrivateEndpointOverridesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PrivateEndpointOverridesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PrivateEndpointOverridesProperty | cdktn.IResolvable | undefined);
        private _domain?;
        get domain(): string;
        set domain(value: string);
        get domainInput(): string | undefined;
        private _privateEndpoint;
        get privateEndpoint(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointPropertyList;
        putPrivateEndpoint(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointProperty[] | cdktn.IResolvable): void;
        resetPrivateEndpoint(): void;
        get privateEndpointInput(): cdktn.IResolvable | AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointProperty[] | undefined;
    }
    class PrivateEndpointOverridesPropertyList extends cdktn.ComplexList {
        internalValue?: PrivateEndpointOverridesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PrivateEndpointOverridesPropertyOutputReference;
    }
    interface CustomJwtAuthorizerProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#allowed_audience AwsBedrockagentcoreAgentRuntime#allowed_audience}
        */
        readonly allowedAudience?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#allowed_clients AwsBedrockagentcoreAgentRuntime#allowed_clients}
        */
        readonly allowedClients?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#allowed_scopes AwsBedrockagentcoreAgentRuntime#allowed_scopes}
        */
        readonly allowedScopes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#discovery_url AwsBedrockagentcoreAgentRuntime#discovery_url}
        */
        readonly discoveryUrl: string;
        /**
        * allowed_workload_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#allowed_workload_configuration AwsBedrockagentcoreAgentRuntime#allowed_workload_configuration}
        */
        readonly allowedWorkloadConfiguration?: AllowedWorkloadConfigurationProperty[] | cdktn.IResolvable;
        /**
        * custom_claim block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#custom_claim AwsBedrockagentcoreAgentRuntime#custom_claim}
        */
        readonly customClaim?: CustomClaimProperty[] | cdktn.IResolvable;
        /**
        * private_endpoint block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#private_endpoint AwsBedrockagentcoreAgentRuntime#private_endpoint}
        */
        readonly privateEndpoint?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointProperty[] | cdktn.IResolvable;
        /**
        * private_endpoint_overrides block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#private_endpoint_overrides AwsBedrockagentcoreAgentRuntime#private_endpoint_overrides}
        */
        readonly privateEndpointOverrides?: PrivateEndpointOverridesProperty[] | cdktn.IResolvable;
    }
    class CustomJwtAuthorizerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomJwtAuthorizerProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CustomJwtAuthorizerProperty | cdktn.IResolvable | undefined);
        private _allowedAudience?;
        get allowedAudience(): string[];
        set allowedAudience(value: string[]);
        resetAllowedAudience(): void;
        get allowedAudienceInput(): string[] | undefined;
        private _allowedClients?;
        get allowedClients(): string[];
        set allowedClients(value: string[]);
        resetAllowedClients(): void;
        get allowedClientsInput(): string[] | undefined;
        private _allowedScopes?;
        get allowedScopes(): string[];
        set allowedScopes(value: string[]);
        resetAllowedScopes(): void;
        get allowedScopesInput(): string[] | undefined;
        private _discoveryUrl?;
        get discoveryUrl(): string;
        set discoveryUrl(value: string);
        get discoveryUrlInput(): string | undefined;
        private _allowedWorkloadConfiguration;
        get allowedWorkloadConfiguration(): AllowedWorkloadConfigurationPropertyList;
        putAllowedWorkloadConfiguration(value: AllowedWorkloadConfigurationProperty[] | cdktn.IResolvable): void;
        resetAllowedWorkloadConfiguration(): void;
        get allowedWorkloadConfigurationInput(): cdktn.IResolvable | AllowedWorkloadConfigurationProperty[] | undefined;
        private _customClaim;
        get customClaim(): CustomClaimPropertyList;
        putCustomClaim(value: CustomClaimProperty[] | cdktn.IResolvable): void;
        resetCustomClaim(): void;
        get customClaimInput(): cdktn.IResolvable | CustomClaimProperty[] | undefined;
        private _privateEndpoint;
        get privateEndpoint(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointPropertyList;
        putPrivateEndpoint(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointProperty[] | cdktn.IResolvable): void;
        resetPrivateEndpoint(): void;
        get privateEndpointInput(): cdktn.IResolvable | AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointProperty[] | undefined;
        private _privateEndpointOverrides;
        get privateEndpointOverrides(): PrivateEndpointOverridesPropertyList;
        putPrivateEndpointOverrides(value: PrivateEndpointOverridesProperty[] | cdktn.IResolvable): void;
        resetPrivateEndpointOverrides(): void;
        get privateEndpointOverridesInput(): cdktn.IResolvable | PrivateEndpointOverridesProperty[] | undefined;
    }
    class CustomJwtAuthorizerPropertyList extends cdktn.ComplexList {
        internalValue?: CustomJwtAuthorizerProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomJwtAuthorizerPropertyOutputReference;
    }
    interface AuthorizerConfigurationProperty {
        /**
        * custom_jwt_authorizer block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#custom_jwt_authorizer AwsBedrockagentcoreAgentRuntime#custom_jwt_authorizer}
        */
        readonly customJwtAuthorizer?: CustomJwtAuthorizerProperty[] | cdktn.IResolvable;
    }
    class AuthorizerConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthorizerConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthorizerConfigurationProperty | cdktn.IResolvable | undefined);
        private _customJwtAuthorizer;
        get customJwtAuthorizer(): CustomJwtAuthorizerPropertyList;
        putCustomJwtAuthorizer(value: CustomJwtAuthorizerProperty[] | cdktn.IResolvable): void;
        resetCustomJwtAuthorizer(): void;
        get customJwtAuthorizerInput(): cdktn.IResolvable | CustomJwtAuthorizerProperty[] | undefined;
    }
    class AuthorizerConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: AuthorizerConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthorizerConfigurationPropertyOutputReference;
    }
    interface EfsAccessPointProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#access_point_arn AwsBedrockagentcoreAgentRuntime#access_point_arn}
        */
        readonly accessPointArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#mount_path AwsBedrockagentcoreAgentRuntime#mount_path}
        */
        readonly mountPath: string;
    }
    class EfsAccessPointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EfsAccessPointProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EfsAccessPointProperty | cdktn.IResolvable | undefined);
        private _accessPointArn?;
        get accessPointArn(): string;
        set accessPointArn(value: string);
        get accessPointArnInput(): string | undefined;
        private _mountPath?;
        get mountPath(): string;
        set mountPath(value: string);
        get mountPathInput(): string | undefined;
    }
    class EfsAccessPointPropertyList extends cdktn.ComplexList {
        internalValue?: EfsAccessPointProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EfsAccessPointPropertyOutputReference;
    }
    interface S3FilesAccessPointProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#access_point_arn AwsBedrockagentcoreAgentRuntime#access_point_arn}
        */
        readonly accessPointArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#mount_path AwsBedrockagentcoreAgentRuntime#mount_path}
        */
        readonly mountPath: string;
    }
    class S3FilesAccessPointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3FilesAccessPointProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3FilesAccessPointProperty | cdktn.IResolvable | undefined);
        private _accessPointArn?;
        get accessPointArn(): string;
        set accessPointArn(value: string);
        get accessPointArnInput(): string | undefined;
        private _mountPath?;
        get mountPath(): string;
        set mountPath(value: string);
        get mountPathInput(): string | undefined;
    }
    class S3FilesAccessPointPropertyList extends cdktn.ComplexList {
        internalValue?: S3FilesAccessPointProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3FilesAccessPointPropertyOutputReference;
    }
    interface SessionStorageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#mount_path AwsBedrockagentcoreAgentRuntime#mount_path}
        */
        readonly mountPath: string;
    }
    class SessionStoragePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SessionStorageProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SessionStorageProperty | cdktn.IResolvable | undefined);
        private _mountPath?;
        get mountPath(): string;
        set mountPath(value: string);
        get mountPathInput(): string | undefined;
    }
    class SessionStoragePropertyList extends cdktn.ComplexList {
        internalValue?: SessionStorageProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SessionStoragePropertyOutputReference;
    }
    interface FilesystemConfigurationProperty {
        /**
        * efs_access_point block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#efs_access_point AwsBedrockagentcoreAgentRuntime#efs_access_point}
        */
        readonly efsAccessPoint?: EfsAccessPointProperty[] | cdktn.IResolvable;
        /**
        * s3_files_access_point block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#s3_files_access_point AwsBedrockagentcoreAgentRuntime#s3_files_access_point}
        */
        readonly s3FilesAccessPoint?: S3FilesAccessPointProperty[] | cdktn.IResolvable;
        /**
        * session_storage block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#session_storage AwsBedrockagentcoreAgentRuntime#session_storage}
        */
        readonly sessionStorage?: SessionStorageProperty[] | cdktn.IResolvable;
    }
    class FilesystemConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilesystemConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilesystemConfigurationProperty | cdktn.IResolvable | undefined);
        private _efsAccessPoint;
        get efsAccessPoint(): EfsAccessPointPropertyList;
        putEfsAccessPoint(value: EfsAccessPointProperty[] | cdktn.IResolvable): void;
        resetEfsAccessPoint(): void;
        get efsAccessPointInput(): cdktn.IResolvable | EfsAccessPointProperty[] | undefined;
        private _s3FilesAccessPoint;
        get s3FilesAccessPoint(): S3FilesAccessPointPropertyList;
        putS3FilesAccessPoint(value: S3FilesAccessPointProperty[] | cdktn.IResolvable): void;
        resetS3FilesAccessPoint(): void;
        get s3FilesAccessPointInput(): cdktn.IResolvable | S3FilesAccessPointProperty[] | undefined;
        private _sessionStorage;
        get sessionStorage(): SessionStoragePropertyList;
        putSessionStorage(value: SessionStorageProperty[] | cdktn.IResolvable): void;
        resetSessionStorage(): void;
        get sessionStorageInput(): cdktn.IResolvable | SessionStorageProperty[] | undefined;
    }
    class FilesystemConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: FilesystemConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilesystemConfigurationPropertyOutputReference;
    }
    interface NetworkModeConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#security_groups AwsBedrockagentcoreAgentRuntime#security_groups}
        */
        readonly securityGroups: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#subnets AwsBedrockagentcoreAgentRuntime#subnets}
        */
        readonly subnets: string[];
    }
    class NetworkModeConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkModeConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NetworkModeConfigProperty | cdktn.IResolvable | undefined);
        get requireServiceS3Endpoint(): cdktn.IResolvable;
        private _securityGroups?;
        get securityGroups(): string[];
        set securityGroups(value: string[]);
        get securityGroupsInput(): string[] | undefined;
        private _subnets?;
        get subnets(): string[];
        set subnets(value: string[]);
        get subnetsInput(): string[] | undefined;
    }
    class NetworkModeConfigPropertyList extends cdktn.ComplexList {
        internalValue?: NetworkModeConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkModeConfigPropertyOutputReference;
    }
    interface NetworkConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#network_mode AwsBedrockagentcoreAgentRuntime#network_mode}
        */
        readonly networkMode: string;
        /**
        * network_mode_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#network_mode_config AwsBedrockagentcoreAgentRuntime#network_mode_config}
        */
        readonly networkModeConfig?: NetworkModeConfigProperty[] | cdktn.IResolvable;
    }
    class NetworkConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NetworkConfigurationProperty | cdktn.IResolvable | undefined);
        private _networkMode?;
        get networkMode(): string;
        set networkMode(value: string);
        get networkModeInput(): string | undefined;
        private _networkModeConfig;
        get networkModeConfig(): NetworkModeConfigPropertyList;
        putNetworkModeConfig(value: NetworkModeConfigProperty[] | cdktn.IResolvable): void;
        resetNetworkModeConfig(): void;
        get networkModeConfigInput(): cdktn.IResolvable | NetworkModeConfigProperty[] | undefined;
    }
    class NetworkConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: NetworkConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkConfigurationPropertyOutputReference;
    }
    interface ProtocolConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#server_protocol AwsBedrockagentcoreAgentRuntime#server_protocol}
        */
        readonly serverProtocol?: string;
    }
    class ProtocolConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ProtocolConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ProtocolConfigurationProperty | cdktn.IResolvable | undefined);
        private _serverProtocol?;
        get serverProtocol(): string;
        set serverProtocol(value: string);
        resetServerProtocol(): void;
        get serverProtocolInput(): string | undefined;
    }
    class ProtocolConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ProtocolConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ProtocolConfigurationPropertyOutputReference;
    }
    interface RequestHeaderConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#request_header_allowlist AwsBedrockagentcoreAgentRuntime#request_header_allowlist}
        */
        readonly requestHeaderAllowlist?: string[];
    }
    class RequestHeaderConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RequestHeaderConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RequestHeaderConfigurationProperty | cdktn.IResolvable | undefined);
        private _requestHeaderAllowlist?;
        get requestHeaderAllowlist(): string[];
        set requestHeaderAllowlist(value: string[]);
        resetRequestHeaderAllowlist(): void;
        get requestHeaderAllowlistInput(): string[] | undefined;
    }
    class RequestHeaderConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: RequestHeaderConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RequestHeaderConfigurationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#create AwsBedrockagentcoreAgentRuntime#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#delete AwsBedrockagentcoreAgentRuntime#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_agent_runtime#update AwsBedrockagentcoreAgentRuntime#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
