import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsBedrockagentcoreEvaluatorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#description AwsBedrockagentcoreEvaluator#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#evaluator_name AwsBedrockagentcoreEvaluator#evaluator_name}
    */
    readonly evaluatorName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#kms_key_arn AwsBedrockagentcoreEvaluator#kms_key_arn}
    */
    readonly kmsKeyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#level AwsBedrockagentcoreEvaluator#level}
    */
    readonly level: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#region AwsBedrockagentcoreEvaluator#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#tags AwsBedrockagentcoreEvaluator#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * evaluator_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#evaluator_config AwsBedrockagentcoreEvaluator#evaluator_config}
    */
    readonly evaluatorConfig?: AwsBedrockagentcoreEvaluator.EvaluatorConfigProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#timeouts AwsBedrockagentcoreEvaluator#timeouts}
    */
    readonly timeouts?: AwsBedrockagentcoreEvaluator.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator aws_bedrockagentcore_evaluator}
*/
export declare class AwsBedrockagentcoreEvaluator extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrockagentcore_evaluator";
    /**
    * Generates CDKTN code for importing a AwsBedrockagentcoreEvaluator resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsBedrockagentcoreEvaluator to import
    * @param importFromId The id of the existing AwsBedrockagentcoreEvaluator that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsBedrockagentcoreEvaluator to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator aws_bedrockagentcore_evaluator} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsBedrockagentcoreEvaluatorConfig
    */
    constructor(scope: Construct, id: string, config: AwsBedrockagentcoreEvaluatorConfig);
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get evaluatorArn(): string;
    get evaluatorId(): string;
    private _evaluatorName?;
    get evaluatorName(): string;
    set evaluatorName(value: string);
    get evaluatorNameInput(): string | undefined;
    private _kmsKeyArn?;
    get kmsKeyArn(): string;
    set kmsKeyArn(value: string);
    resetKmsKeyArn(): void;
    get kmsKeyArnInput(): string | undefined;
    private _level?;
    get level(): string;
    set level(value: string);
    get levelInput(): string | undefined;
    get lockedForModification(): cdktn.IResolvable;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _evaluatorConfig;
    get evaluatorConfig(): AwsBedrockagentcoreEvaluator.EvaluatorConfigPropertyList;
    putEvaluatorConfig(value: AwsBedrockagentcoreEvaluator.EvaluatorConfigProperty[] | cdktn.IResolvable): void;
    resetEvaluatorConfig(): void;
    get evaluatorConfigInput(): cdktn.IResolvable | AwsBedrockagentcoreEvaluator.EvaluatorConfigProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsBedrockagentcoreEvaluator.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsBedrockagentcoreEvaluator.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsBedrockagentcoreEvaluator.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsBedrockagentcoreEvaluatorLambdaConfigPropertyToTerraform(struct?: AwsBedrockagentcoreEvaluator.LambdaConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreEvaluatorLambdaConfigPropertyToHclTerraform(struct?: AwsBedrockagentcoreEvaluator.LambdaConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreEvaluatorCodeBasedPropertyToTerraform(struct?: AwsBedrockagentcoreEvaluator.CodeBasedProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreEvaluatorCodeBasedPropertyToHclTerraform(struct?: AwsBedrockagentcoreEvaluator.CodeBasedProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreEvaluatorInferenceConfigPropertyToTerraform(struct?: AwsBedrockagentcoreEvaluator.InferenceConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreEvaluatorInferenceConfigPropertyToHclTerraform(struct?: AwsBedrockagentcoreEvaluator.InferenceConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreEvaluatorBedrockEvaluatorModelConfigPropertyToTerraform(struct?: AwsBedrockagentcoreEvaluator.BedrockEvaluatorModelConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreEvaluatorBedrockEvaluatorModelConfigPropertyToHclTerraform(struct?: AwsBedrockagentcoreEvaluator.BedrockEvaluatorModelConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreEvaluatorModelConfigPropertyToTerraform(struct?: AwsBedrockagentcoreEvaluator.ModelConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreEvaluatorModelConfigPropertyToHclTerraform(struct?: AwsBedrockagentcoreEvaluator.ModelConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreEvaluatorCategoricalPropertyToTerraform(struct?: AwsBedrockagentcoreEvaluator.CategoricalProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreEvaluatorCategoricalPropertyToHclTerraform(struct?: AwsBedrockagentcoreEvaluator.CategoricalProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreEvaluatorNumericalPropertyToTerraform(struct?: AwsBedrockagentcoreEvaluator.NumericalProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreEvaluatorNumericalPropertyToHclTerraform(struct?: AwsBedrockagentcoreEvaluator.NumericalProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreEvaluatorRatingScalePropertyToTerraform(struct?: AwsBedrockagentcoreEvaluator.RatingScaleProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreEvaluatorRatingScalePropertyToHclTerraform(struct?: AwsBedrockagentcoreEvaluator.RatingScaleProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreEvaluatorLlmAsAJudgePropertyToTerraform(struct?: AwsBedrockagentcoreEvaluator.LlmAsAJudgeProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreEvaluatorLlmAsAJudgePropertyToHclTerraform(struct?: AwsBedrockagentcoreEvaluator.LlmAsAJudgeProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreEvaluatorEvaluatorConfigPropertyToTerraform(struct?: AwsBedrockagentcoreEvaluator.EvaluatorConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreEvaluatorEvaluatorConfigPropertyToHclTerraform(struct?: AwsBedrockagentcoreEvaluator.EvaluatorConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreEvaluatorTimeoutsPropertyToTerraform(struct?: AwsBedrockagentcoreEvaluator.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreEvaluatorTimeoutsPropertyToHclTerraform(struct?: AwsBedrockagentcoreEvaluator.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsBedrockagentcoreEvaluator {
    interface LambdaConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#lambda_arn AwsBedrockagentcoreEvaluator#lambda_arn}
        */
        readonly lambdaArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#lambda_timeout_in_seconds AwsBedrockagentcoreEvaluator#lambda_timeout_in_seconds}
        */
        readonly lambdaTimeoutInSeconds?: number;
    }
    class LambdaConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LambdaConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LambdaConfigProperty | cdktn.IResolvable | undefined);
        private _lambdaArn?;
        get lambdaArn(): string;
        set lambdaArn(value: string);
        get lambdaArnInput(): string | undefined;
        private _lambdaTimeoutInSeconds?;
        get lambdaTimeoutInSeconds(): number;
        set lambdaTimeoutInSeconds(value: number);
        resetLambdaTimeoutInSeconds(): void;
        get lambdaTimeoutInSecondsInput(): number | undefined;
    }
    class LambdaConfigPropertyList extends cdktn.ComplexList {
        internalValue?: LambdaConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LambdaConfigPropertyOutputReference;
    }
    interface CodeBasedProperty {
        /**
        * lambda_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#lambda_config AwsBedrockagentcoreEvaluator#lambda_config}
        */
        readonly lambdaConfig?: LambdaConfigProperty[] | cdktn.IResolvable;
    }
    class CodeBasedPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CodeBasedProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CodeBasedProperty | cdktn.IResolvable | undefined);
        private _lambdaConfig;
        get lambdaConfig(): LambdaConfigPropertyList;
        putLambdaConfig(value: LambdaConfigProperty[] | cdktn.IResolvable): void;
        resetLambdaConfig(): void;
        get lambdaConfigInput(): cdktn.IResolvable | LambdaConfigProperty[] | undefined;
    }
    class CodeBasedPropertyList extends cdktn.ComplexList {
        internalValue?: CodeBasedProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CodeBasedPropertyOutputReference;
    }
    interface InferenceConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#max_tokens AwsBedrockagentcoreEvaluator#max_tokens}
        */
        readonly maxTokens?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#stop_sequences AwsBedrockagentcoreEvaluator#stop_sequences}
        */
        readonly stopSequences?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#temperature AwsBedrockagentcoreEvaluator#temperature}
        */
        readonly temperature?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#top_p AwsBedrockagentcoreEvaluator#top_p}
        */
        readonly topP?: number;
    }
    class InferenceConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InferenceConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InferenceConfigProperty | cdktn.IResolvable | undefined);
        private _maxTokens?;
        get maxTokens(): number;
        set maxTokens(value: number);
        resetMaxTokens(): void;
        get maxTokensInput(): number | undefined;
        private _stopSequences?;
        get stopSequences(): string[];
        set stopSequences(value: string[]);
        resetStopSequences(): void;
        get stopSequencesInput(): string[] | undefined;
        private _temperature?;
        get temperature(): number;
        set temperature(value: number);
        resetTemperature(): void;
        get temperatureInput(): number | undefined;
        private _topP?;
        get topP(): number;
        set topP(value: number);
        resetTopP(): void;
        get topPInput(): number | undefined;
    }
    class InferenceConfigPropertyList extends cdktn.ComplexList {
        internalValue?: InferenceConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InferenceConfigPropertyOutputReference;
    }
    interface BedrockEvaluatorModelConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#additional_model_request_fields AwsBedrockagentcoreEvaluator#additional_model_request_fields}
        */
        readonly additionalModelRequestFields?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#model_id AwsBedrockagentcoreEvaluator#model_id}
        */
        readonly modelId: string;
        /**
        * inference_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#inference_config AwsBedrockagentcoreEvaluator#inference_config}
        */
        readonly inferenceConfig?: InferenceConfigProperty[] | cdktn.IResolvable;
    }
    class BedrockEvaluatorModelConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BedrockEvaluatorModelConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: BedrockEvaluatorModelConfigProperty | cdktn.IResolvable | undefined);
        private _additionalModelRequestFields?;
        get additionalModelRequestFields(): string;
        set additionalModelRequestFields(value: string);
        resetAdditionalModelRequestFields(): void;
        get additionalModelRequestFieldsInput(): string | undefined;
        private _modelId?;
        get modelId(): string;
        set modelId(value: string);
        get modelIdInput(): string | undefined;
        private _inferenceConfig;
        get inferenceConfig(): InferenceConfigPropertyList;
        putInferenceConfig(value: InferenceConfigProperty[] | cdktn.IResolvable): void;
        resetInferenceConfig(): void;
        get inferenceConfigInput(): cdktn.IResolvable | InferenceConfigProperty[] | undefined;
    }
    class BedrockEvaluatorModelConfigPropertyList extends cdktn.ComplexList {
        internalValue?: BedrockEvaluatorModelConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BedrockEvaluatorModelConfigPropertyOutputReference;
    }
    interface ModelConfigProperty {
        /**
        * bedrock_evaluator_model_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#bedrock_evaluator_model_config AwsBedrockagentcoreEvaluator#bedrock_evaluator_model_config}
        */
        readonly bedrockEvaluatorModelConfig?: BedrockEvaluatorModelConfigProperty[] | cdktn.IResolvable;
    }
    class ModelConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ModelConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ModelConfigProperty | cdktn.IResolvable | undefined);
        private _bedrockEvaluatorModelConfig;
        get bedrockEvaluatorModelConfig(): BedrockEvaluatorModelConfigPropertyList;
        putBedrockEvaluatorModelConfig(value: BedrockEvaluatorModelConfigProperty[] | cdktn.IResolvable): void;
        resetBedrockEvaluatorModelConfig(): void;
        get bedrockEvaluatorModelConfigInput(): cdktn.IResolvable | BedrockEvaluatorModelConfigProperty[] | undefined;
    }
    class ModelConfigPropertyList extends cdktn.ComplexList {
        internalValue?: ModelConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ModelConfigPropertyOutputReference;
    }
    interface CategoricalProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#definition AwsBedrockagentcoreEvaluator#definition}
        */
        readonly definition: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#label AwsBedrockagentcoreEvaluator#label}
        */
        readonly label: string;
    }
    class CategoricalPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CategoricalProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CategoricalProperty | cdktn.IResolvable | undefined);
        private _definition?;
        get definition(): string;
        set definition(value: string);
        get definitionInput(): string | undefined;
        private _label?;
        get label(): string;
        set label(value: string);
        get labelInput(): string | undefined;
    }
    class CategoricalPropertyList extends cdktn.ComplexList {
        internalValue?: CategoricalProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CategoricalPropertyOutputReference;
    }
    interface NumericalProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#definition AwsBedrockagentcoreEvaluator#definition}
        */
        readonly definition: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#label AwsBedrockagentcoreEvaluator#label}
        */
        readonly label: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#value AwsBedrockagentcoreEvaluator#value}
        */
        readonly value: number;
    }
    class NumericalPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NumericalProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NumericalProperty | cdktn.IResolvable | undefined);
        private _definition?;
        get definition(): string;
        set definition(value: string);
        get definitionInput(): string | undefined;
        private _label?;
        get label(): string;
        set label(value: string);
        get labelInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    class NumericalPropertyList extends cdktn.ComplexList {
        internalValue?: NumericalProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NumericalPropertyOutputReference;
    }
    interface RatingScaleProperty {
        /**
        * categorical block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#categorical AwsBedrockagentcoreEvaluator#categorical}
        */
        readonly categorical?: CategoricalProperty[] | cdktn.IResolvable;
        /**
        * numerical block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#numerical AwsBedrockagentcoreEvaluator#numerical}
        */
        readonly numerical?: NumericalProperty[] | cdktn.IResolvable;
    }
    class RatingScalePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RatingScaleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RatingScaleProperty | cdktn.IResolvable | undefined);
        private _categorical;
        get categorical(): CategoricalPropertyList;
        putCategorical(value: CategoricalProperty[] | cdktn.IResolvable): void;
        resetCategorical(): void;
        get categoricalInput(): cdktn.IResolvable | CategoricalProperty[] | undefined;
        private _numerical;
        get numerical(): NumericalPropertyList;
        putNumerical(value: NumericalProperty[] | cdktn.IResolvable): void;
        resetNumerical(): void;
        get numericalInput(): cdktn.IResolvable | NumericalProperty[] | undefined;
    }
    class RatingScalePropertyList extends cdktn.ComplexList {
        internalValue?: RatingScaleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RatingScalePropertyOutputReference;
    }
    interface LlmAsAJudgeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#instructions AwsBedrockagentcoreEvaluator#instructions}
        */
        readonly instructions: string;
        /**
        * model_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#model_config AwsBedrockagentcoreEvaluator#model_config}
        */
        readonly modelConfig?: ModelConfigProperty[] | cdktn.IResolvable;
        /**
        * rating_scale block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#rating_scale AwsBedrockagentcoreEvaluator#rating_scale}
        */
        readonly ratingScale?: RatingScaleProperty[] | cdktn.IResolvable;
    }
    class LlmAsAJudgePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LlmAsAJudgeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LlmAsAJudgeProperty | cdktn.IResolvable | undefined);
        private _instructions?;
        get instructions(): string;
        set instructions(value: string);
        get instructionsInput(): string | undefined;
        private _modelConfig;
        get modelConfig(): ModelConfigPropertyList;
        putModelConfig(value: ModelConfigProperty[] | cdktn.IResolvable): void;
        resetModelConfig(): void;
        get modelConfigInput(): cdktn.IResolvable | ModelConfigProperty[] | undefined;
        private _ratingScale;
        get ratingScale(): RatingScalePropertyList;
        putRatingScale(value: RatingScaleProperty[] | cdktn.IResolvable): void;
        resetRatingScale(): void;
        get ratingScaleInput(): cdktn.IResolvable | RatingScaleProperty[] | undefined;
    }
    class LlmAsAJudgePropertyList extends cdktn.ComplexList {
        internalValue?: LlmAsAJudgeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LlmAsAJudgePropertyOutputReference;
    }
    interface EvaluatorConfigProperty {
        /**
        * code_based block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#code_based AwsBedrockagentcoreEvaluator#code_based}
        */
        readonly codeBased?: CodeBasedProperty[] | cdktn.IResolvable;
        /**
        * llm_as_a_judge block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#llm_as_a_judge AwsBedrockagentcoreEvaluator#llm_as_a_judge}
        */
        readonly llmAsAJudge?: LlmAsAJudgeProperty[] | cdktn.IResolvable;
    }
    class EvaluatorConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EvaluatorConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EvaluatorConfigProperty | cdktn.IResolvable | undefined);
        private _codeBased;
        get codeBased(): CodeBasedPropertyList;
        putCodeBased(value: CodeBasedProperty[] | cdktn.IResolvable): void;
        resetCodeBased(): void;
        get codeBasedInput(): cdktn.IResolvable | CodeBasedProperty[] | undefined;
        private _llmAsAJudge;
        get llmAsAJudge(): LlmAsAJudgePropertyList;
        putLlmAsAJudge(value: LlmAsAJudgeProperty[] | cdktn.IResolvable): void;
        resetLlmAsAJudge(): void;
        get llmAsAJudgeInput(): cdktn.IResolvable | LlmAsAJudgeProperty[] | undefined;
    }
    class EvaluatorConfigPropertyList extends cdktn.ComplexList {
        internalValue?: EvaluatorConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EvaluatorConfigPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#create AwsBedrockagentcoreEvaluator#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#delete AwsBedrockagentcoreEvaluator#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_evaluator#update AwsBedrockagentcoreEvaluator#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
