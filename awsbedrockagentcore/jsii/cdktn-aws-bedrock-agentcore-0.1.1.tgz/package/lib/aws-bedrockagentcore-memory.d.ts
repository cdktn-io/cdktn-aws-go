import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsBedrockagentcoreMemoryConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory#description AwsBedrockagentcoreMemory#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory#encryption_key_arn AwsBedrockagentcoreMemory#encryption_key_arn}
    */
    readonly encryptionKeyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory#event_expiry_duration AwsBedrockagentcoreMemory#event_expiry_duration}
    */
    readonly eventExpiryDuration: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory#memory_execution_role_arn AwsBedrockagentcoreMemory#memory_execution_role_arn}
    */
    readonly memoryExecutionRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory#name AwsBedrockagentcoreMemory#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory#region AwsBedrockagentcoreMemory#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory#tags AwsBedrockagentcoreMemory#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * indexed_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory#indexed_key AwsBedrockagentcoreMemory#indexed_key}
    */
    readonly indexedKey?: AwsBedrockagentcoreMemory.IndexedKeyProperty[] | cdktn.IResolvable;
    /**
    * stream_delivery_resources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory#stream_delivery_resources AwsBedrockagentcoreMemory#stream_delivery_resources}
    */
    readonly streamDeliveryResources?: AwsBedrockagentcoreMemory.StreamDeliveryResourcesProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory#timeouts AwsBedrockagentcoreMemory#timeouts}
    */
    readonly timeouts?: AwsBedrockagentcoreMemory.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory aws_bedrockagentcore_memory}
*/
export declare class AwsBedrockagentcoreMemory extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrockagentcore_memory";
    /**
    * Generates CDKTN code for importing a AwsBedrockagentcoreMemory resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsBedrockagentcoreMemory to import
    * @param importFromId The id of the existing AwsBedrockagentcoreMemory that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsBedrockagentcoreMemory to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory aws_bedrockagentcore_memory} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsBedrockagentcoreMemoryConfig
    */
    constructor(scope: Construct, id: string, config: AwsBedrockagentcoreMemoryConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _encryptionKeyArn?;
    get encryptionKeyArn(): string;
    set encryptionKeyArn(value: string);
    resetEncryptionKeyArn(): void;
    get encryptionKeyArnInput(): string | undefined;
    private _eventExpiryDuration?;
    get eventExpiryDuration(): number;
    set eventExpiryDuration(value: number);
    get eventExpiryDurationInput(): number | undefined;
    get id(): string;
    private _memoryExecutionRoleArn?;
    get memoryExecutionRoleArn(): string;
    set memoryExecutionRoleArn(value: string);
    resetMemoryExecutionRoleArn(): void;
    get memoryExecutionRoleArnInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _indexedKey;
    get indexedKey(): AwsBedrockagentcoreMemory.IndexedKeyPropertyList;
    putIndexedKey(value: AwsBedrockagentcoreMemory.IndexedKeyProperty[] | cdktn.IResolvable): void;
    resetIndexedKey(): void;
    get indexedKeyInput(): cdktn.IResolvable | AwsBedrockagentcoreMemory.IndexedKeyProperty[] | undefined;
    private _streamDeliveryResources;
    get streamDeliveryResources(): AwsBedrockagentcoreMemory.StreamDeliveryResourcesPropertyList;
    putStreamDeliveryResources(value: AwsBedrockagentcoreMemory.StreamDeliveryResourcesProperty[] | cdktn.IResolvable): void;
    resetStreamDeliveryResources(): void;
    get streamDeliveryResourcesInput(): cdktn.IResolvable | AwsBedrockagentcoreMemory.StreamDeliveryResourcesProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsBedrockagentcoreMemory.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsBedrockagentcoreMemory.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsBedrockagentcoreMemory.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsBedrockagentcoreMemoryIndexedKeyPropertyToTerraform(struct?: AwsBedrockagentcoreMemory.IndexedKeyProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryIndexedKeyPropertyToHclTerraform(struct?: AwsBedrockagentcoreMemory.IndexedKeyProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryContentConfigurationPropertyToTerraform(struct?: AwsBedrockagentcoreMemory.ContentConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryContentConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentcoreMemory.ContentConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryKinesisPropertyToTerraform(struct?: AwsBedrockagentcoreMemory.KinesisProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryKinesisPropertyToHclTerraform(struct?: AwsBedrockagentcoreMemory.KinesisProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryResourcePropertyToTerraform(struct?: AwsBedrockagentcoreMemory.ResourceProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryResourcePropertyToHclTerraform(struct?: AwsBedrockagentcoreMemory.ResourceProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryStreamDeliveryResourcesPropertyToTerraform(struct?: AwsBedrockagentcoreMemory.StreamDeliveryResourcesProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryStreamDeliveryResourcesPropertyToHclTerraform(struct?: AwsBedrockagentcoreMemory.StreamDeliveryResourcesProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryTimeoutsPropertyToTerraform(struct?: AwsBedrockagentcoreMemory.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreMemoryTimeoutsPropertyToHclTerraform(struct?: AwsBedrockagentcoreMemory.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsBedrockagentcoreMemory {
    interface IndexedKeyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory#key AwsBedrockagentcoreMemory#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory#type AwsBedrockagentcoreMemory#type}
        */
        readonly type: string;
    }
    class IndexedKeyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IndexedKeyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IndexedKeyProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class IndexedKeyPropertyList extends cdktn.ComplexList {
        internalValue?: IndexedKeyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IndexedKeyPropertyOutputReference;
    }
    interface ContentConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory#level AwsBedrockagentcoreMemory#level}
        */
        readonly level?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory#type AwsBedrockagentcoreMemory#type}
        */
        readonly type: string;
    }
    class ContentConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ContentConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ContentConfigurationProperty | cdktn.IResolvable | undefined);
        private _level?;
        get level(): string;
        set level(value: string);
        resetLevel(): void;
        get levelInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class ContentConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ContentConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ContentConfigurationPropertyOutputReference;
    }
    interface KinesisProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory#data_stream_arn AwsBedrockagentcoreMemory#data_stream_arn}
        */
        readonly dataStreamArn: string;
        /**
        * content_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory#content_configuration AwsBedrockagentcoreMemory#content_configuration}
        */
        readonly contentConfiguration?: ContentConfigurationProperty[] | cdktn.IResolvable;
    }
    class KinesisPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KinesisProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KinesisProperty | cdktn.IResolvable | undefined);
        private _dataStreamArn?;
        get dataStreamArn(): string;
        set dataStreamArn(value: string);
        get dataStreamArnInput(): string | undefined;
        private _contentConfiguration;
        get contentConfiguration(): ContentConfigurationPropertyList;
        putContentConfiguration(value: ContentConfigurationProperty[] | cdktn.IResolvable): void;
        resetContentConfiguration(): void;
        get contentConfigurationInput(): cdktn.IResolvable | ContentConfigurationProperty[] | undefined;
    }
    class KinesisPropertyList extends cdktn.ComplexList {
        internalValue?: KinesisProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KinesisPropertyOutputReference;
    }
    interface ResourceProperty {
        /**
        * kinesis block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory#kinesis AwsBedrockagentcoreMemory#kinesis}
        */
        readonly kinesis?: KinesisProperty[] | cdktn.IResolvable;
    }
    class ResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceProperty | cdktn.IResolvable | undefined);
        private _kinesis;
        get kinesis(): KinesisPropertyList;
        putKinesis(value: KinesisProperty[] | cdktn.IResolvable): void;
        resetKinesis(): void;
        get kinesisInput(): cdktn.IResolvable | KinesisProperty[] | undefined;
    }
    class ResourcePropertyList extends cdktn.ComplexList {
        internalValue?: ResourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourcePropertyOutputReference;
    }
    interface StreamDeliveryResourcesProperty {
        /**
        * resource block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory#resource AwsBedrockagentcoreMemory#resource}
        */
        readonly resource?: ResourceProperty[] | cdktn.IResolvable;
    }
    class StreamDeliveryResourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StreamDeliveryResourcesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StreamDeliveryResourcesProperty | cdktn.IResolvable | undefined);
        private _resource;
        get resource(): ResourcePropertyList;
        putResource(value: ResourceProperty[] | cdktn.IResolvable): void;
        resetResource(): void;
        get resourceInput(): cdktn.IResolvable | ResourceProperty[] | undefined;
    }
    class StreamDeliveryResourcesPropertyList extends cdktn.ComplexList {
        internalValue?: StreamDeliveryResourcesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StreamDeliveryResourcesPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory#create AwsBedrockagentcoreMemory#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory#delete AwsBedrockagentcoreMemory#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_memory#update AwsBedrockagentcoreMemory#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
