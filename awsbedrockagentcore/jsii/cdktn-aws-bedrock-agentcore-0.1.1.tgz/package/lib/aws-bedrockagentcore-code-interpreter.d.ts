import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsBedrockagentcoreCodeInterpreterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_code_interpreter#description AwsBedrockagentcoreCodeInterpreter#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_code_interpreter#execution_role_arn AwsBedrockagentcoreCodeInterpreter#execution_role_arn}
    */
    readonly executionRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_code_interpreter#name AwsBedrockagentcoreCodeInterpreter#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_code_interpreter#region AwsBedrockagentcoreCodeInterpreter#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_code_interpreter#tags AwsBedrockagentcoreCodeInterpreter#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * certificate block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_code_interpreter#certificate AwsBedrockagentcoreCodeInterpreter#certificate}
    */
    readonly certificate?: AwsBedrockagentcoreCodeInterpreter.CertificateProperty[] | cdktn.IResolvable;
    /**
    * network_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_code_interpreter#network_configuration AwsBedrockagentcoreCodeInterpreter#network_configuration}
    */
    readonly networkConfiguration?: AwsBedrockagentcoreCodeInterpreter.NetworkConfigurationProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_code_interpreter#timeouts AwsBedrockagentcoreCodeInterpreter#timeouts}
    */
    readonly timeouts?: AwsBedrockagentcoreCodeInterpreter.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_code_interpreter aws_bedrockagentcore_code_interpreter}
*/
export declare class AwsBedrockagentcoreCodeInterpreter extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrockagentcore_code_interpreter";
    /**
    * Generates CDKTN code for importing a AwsBedrockagentcoreCodeInterpreter resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsBedrockagentcoreCodeInterpreter to import
    * @param importFromId The id of the existing AwsBedrockagentcoreCodeInterpreter that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_code_interpreter#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsBedrockagentcoreCodeInterpreter to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_code_interpreter aws_bedrockagentcore_code_interpreter} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsBedrockagentcoreCodeInterpreterConfig
    */
    constructor(scope: Construct, id: string, config: AwsBedrockagentcoreCodeInterpreterConfig);
    get codeInterpreterArn(): string;
    get codeInterpreterId(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _executionRoleArn?;
    get executionRoleArn(): string;
    set executionRoleArn(value: string);
    resetExecutionRoleArn(): void;
    get executionRoleArnInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _certificate;
    get certificate(): AwsBedrockagentcoreCodeInterpreter.CertificatePropertyList;
    putCertificate(value: AwsBedrockagentcoreCodeInterpreter.CertificateProperty[] | cdktn.IResolvable): void;
    resetCertificate(): void;
    get certificateInput(): cdktn.IResolvable | AwsBedrockagentcoreCodeInterpreter.CertificateProperty[] | undefined;
    private _networkConfiguration;
    get networkConfiguration(): AwsBedrockagentcoreCodeInterpreter.NetworkConfigurationPropertyList;
    putNetworkConfiguration(value: AwsBedrockagentcoreCodeInterpreter.NetworkConfigurationProperty[] | cdktn.IResolvable): void;
    resetNetworkConfiguration(): void;
    get networkConfigurationInput(): cdktn.IResolvable | AwsBedrockagentcoreCodeInterpreter.NetworkConfigurationProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsBedrockagentcoreCodeInterpreter.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsBedrockagentcoreCodeInterpreter.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsBedrockagentcoreCodeInterpreter.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsBedrockagentcoreCodeInterpreterSecretsManagerPropertyToTerraform(struct?: AwsBedrockagentcoreCodeInterpreter.SecretsManagerProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreCodeInterpreterSecretsManagerPropertyToHclTerraform(struct?: AwsBedrockagentcoreCodeInterpreter.SecretsManagerProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreCodeInterpreterLocationPropertyToTerraform(struct?: AwsBedrockagentcoreCodeInterpreter.LocationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreCodeInterpreterLocationPropertyToHclTerraform(struct?: AwsBedrockagentcoreCodeInterpreter.LocationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreCodeInterpreterCertificatePropertyToTerraform(struct?: AwsBedrockagentcoreCodeInterpreter.CertificateProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreCodeInterpreterCertificatePropertyToHclTerraform(struct?: AwsBedrockagentcoreCodeInterpreter.CertificateProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreCodeInterpreterVpcConfigPropertyToTerraform(struct?: AwsBedrockagentcoreCodeInterpreter.VpcConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreCodeInterpreterVpcConfigPropertyToHclTerraform(struct?: AwsBedrockagentcoreCodeInterpreter.VpcConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreCodeInterpreterNetworkConfigurationPropertyToTerraform(struct?: AwsBedrockagentcoreCodeInterpreter.NetworkConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreCodeInterpreterNetworkConfigurationPropertyToHclTerraform(struct?: AwsBedrockagentcoreCodeInterpreter.NetworkConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreCodeInterpreterTimeoutsPropertyToTerraform(struct?: AwsBedrockagentcoreCodeInterpreter.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsBedrockagentcoreCodeInterpreterTimeoutsPropertyToHclTerraform(struct?: AwsBedrockagentcoreCodeInterpreter.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsBedrockagentcoreCodeInterpreter {
    interface SecretsManagerProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_code_interpreter#secret_arn AwsBedrockagentcoreCodeInterpreter#secret_arn}
        */
        readonly secretArn: string;
    }
    class SecretsManagerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SecretsManagerProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SecretsManagerProperty | cdktn.IResolvable | undefined);
        private _secretArn?;
        get secretArn(): string;
        set secretArn(value: string);
        get secretArnInput(): string | undefined;
    }
    class SecretsManagerPropertyList extends cdktn.ComplexList {
        internalValue?: SecretsManagerProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SecretsManagerPropertyOutputReference;
    }
    interface LocationProperty {
        /**
        * secrets_manager block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_code_interpreter#secrets_manager AwsBedrockagentcoreCodeInterpreter#secrets_manager}
        */
        readonly secretsManager?: SecretsManagerProperty[] | cdktn.IResolvable;
    }
    class LocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LocationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LocationProperty | cdktn.IResolvable | undefined);
        private _secretsManager;
        get secretsManager(): SecretsManagerPropertyList;
        putSecretsManager(value: SecretsManagerProperty[] | cdktn.IResolvable): void;
        resetSecretsManager(): void;
        get secretsManagerInput(): cdktn.IResolvable | SecretsManagerProperty[] | undefined;
    }
    class LocationPropertyList extends cdktn.ComplexList {
        internalValue?: LocationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LocationPropertyOutputReference;
    }
    interface CertificateProperty {
        /**
        * location block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_code_interpreter#location AwsBedrockagentcoreCodeInterpreter#location}
        */
        readonly location?: LocationProperty[] | cdktn.IResolvable;
    }
    class CertificatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CertificateProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CertificateProperty | cdktn.IResolvable | undefined);
        private _location;
        get location(): LocationPropertyList;
        putLocation(value: LocationProperty[] | cdktn.IResolvable): void;
        resetLocation(): void;
        get locationInput(): cdktn.IResolvable | LocationProperty[] | undefined;
    }
    class CertificatePropertyList extends cdktn.ComplexList {
        internalValue?: CertificateProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CertificatePropertyOutputReference;
    }
    interface VpcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_code_interpreter#security_groups AwsBedrockagentcoreCodeInterpreter#security_groups}
        */
        readonly securityGroups: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_code_interpreter#subnets AwsBedrockagentcoreCodeInterpreter#subnets}
        */
        readonly subnets: string[];
    }
    class VpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpcConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VpcConfigProperty | cdktn.IResolvable | undefined);
        private _securityGroups?;
        get securityGroups(): string[];
        set securityGroups(value: string[]);
        get securityGroupsInput(): string[] | undefined;
        private _subnets?;
        get subnets(): string[];
        set subnets(value: string[]);
        get subnetsInput(): string[] | undefined;
    }
    class VpcConfigPropertyList extends cdktn.ComplexList {
        internalValue?: VpcConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpcConfigPropertyOutputReference;
    }
    interface NetworkConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_code_interpreter#network_mode AwsBedrockagentcoreCodeInterpreter#network_mode}
        */
        readonly networkMode: string;
        /**
        * vpc_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_code_interpreter#vpc_config AwsBedrockagentcoreCodeInterpreter#vpc_config}
        */
        readonly vpcConfig?: VpcConfigProperty[] | cdktn.IResolvable;
    }
    class NetworkConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NetworkConfigurationProperty | cdktn.IResolvable | undefined);
        private _networkMode?;
        get networkMode(): string;
        set networkMode(value: string);
        get networkModeInput(): string | undefined;
        private _vpcConfig;
        get vpcConfig(): VpcConfigPropertyList;
        putVpcConfig(value: VpcConfigProperty[] | cdktn.IResolvable): void;
        resetVpcConfig(): void;
        get vpcConfigInput(): cdktn.IResolvable | VpcConfigProperty[] | undefined;
    }
    class NetworkConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: NetworkConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkConfigurationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_code_interpreter#create AwsBedrockagentcoreCodeInterpreter#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_code_interpreter#delete AwsBedrockagentcoreCodeInterpreter#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
