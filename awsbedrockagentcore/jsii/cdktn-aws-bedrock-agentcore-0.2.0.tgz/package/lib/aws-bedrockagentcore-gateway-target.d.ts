import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfGatewayTargetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#description TfGatewayTarget#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#gateway_identifier TfGatewayTarget#gateway_identifier}
    */
    readonly gatewayIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#name TfGatewayTarget#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#region TfGatewayTarget#region}
    */
    readonly region?: string;
    /**
    * credential_provider_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#credential_provider_configuration TfGatewayTarget#credential_provider_configuration}
    */
    readonly credentialProviderConfiguration?: TfGatewayTarget.CredentialProviderConfigurationProperty[] | cdktn.IResolvable;
    /**
    * metadata_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#metadata_configuration TfGatewayTarget#metadata_configuration}
    */
    readonly metadataConfiguration?: TfGatewayTarget.MetadataConfigurationProperty[] | cdktn.IResolvable;
    /**
    * private_endpoint block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#private_endpoint TfGatewayTarget#private_endpoint}
    */
    readonly privateEndpoint?: TfGatewayTarget.PrivateEndpointProperty[] | cdktn.IResolvable;
    /**
    * target_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#target_configuration TfGatewayTarget#target_configuration}
    */
    readonly targetConfiguration?: TfGatewayTarget.TargetConfigurationProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#timeouts TfGatewayTarget#timeouts}
    */
    readonly timeouts?: TfGatewayTarget.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target aws_bedrockagentcore_gateway_target}
*/
export declare class TfGatewayTarget extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrockagentcore_gateway_target";
    /**
    * Generates CDKTN code for importing a TfGatewayTarget resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfGatewayTarget to import
    * @param importFromId The id of the existing TfGatewayTarget that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfGatewayTarget to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target aws_bedrockagentcore_gateway_target} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfGatewayTargetConfig
    */
    constructor(scope: Construct, id: string, config: TfGatewayTargetConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _gatewayIdentifier?;
    get gatewayIdentifier(): string;
    set gatewayIdentifier(value: string);
    get gatewayIdentifierInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get targetId(): string;
    private _credentialProviderConfiguration;
    get credentialProviderConfiguration(): TfGatewayTarget.CredentialProviderConfigurationPropertyList;
    putCredentialProviderConfiguration(value: TfGatewayTarget.CredentialProviderConfigurationProperty[] | cdktn.IResolvable): void;
    resetCredentialProviderConfiguration(): void;
    get credentialProviderConfigurationInput(): cdktn.IResolvable | TfGatewayTarget.CredentialProviderConfigurationProperty[] | undefined;
    private _metadataConfiguration;
    get metadataConfiguration(): TfGatewayTarget.MetadataConfigurationPropertyList;
    putMetadataConfiguration(value: TfGatewayTarget.MetadataConfigurationProperty[] | cdktn.IResolvable): void;
    resetMetadataConfiguration(): void;
    get metadataConfigurationInput(): cdktn.IResolvable | TfGatewayTarget.MetadataConfigurationProperty[] | undefined;
    private _privateEndpoint;
    get privateEndpoint(): TfGatewayTarget.PrivateEndpointPropertyList;
    putPrivateEndpoint(value: TfGatewayTarget.PrivateEndpointProperty[] | cdktn.IResolvable): void;
    resetPrivateEndpoint(): void;
    get privateEndpointInput(): cdktn.IResolvable | TfGatewayTarget.PrivateEndpointProperty[] | undefined;
    private _targetConfiguration;
    get targetConfiguration(): TfGatewayTarget.TargetConfigurationPropertyList;
    putTargetConfiguration(value: TfGatewayTarget.TargetConfigurationProperty[] | cdktn.IResolvable): void;
    resetTargetConfiguration(): void;
    get targetConfigurationInput(): cdktn.IResolvable | TfGatewayTarget.TargetConfigurationProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfGatewayTarget.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfGatewayTarget.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfGatewayTarget.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfGatewayTargetApiKeyPropertyToTerraform(struct?: TfGatewayTarget.ApiKeyProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetApiKeyPropertyToHclTerraform(struct?: TfGatewayTarget.ApiKeyProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetCallerIamCredentialsPropertyToTerraform(struct?: TfGatewayTarget.CallerIamCredentialsProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetCallerIamCredentialsPropertyToHclTerraform(struct?: TfGatewayTarget.CallerIamCredentialsProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetGatewayIamRolePropertyToTerraform(struct?: TfGatewayTarget.GatewayIamRoleProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetGatewayIamRolePropertyToHclTerraform(struct?: TfGatewayTarget.GatewayIamRoleProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetJwtPassthroughPropertyToTerraform(struct?: TfGatewayTarget.JwtPassthroughProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetJwtPassthroughPropertyToHclTerraform(struct?: TfGatewayTarget.JwtPassthroughProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetOauthPropertyToTerraform(struct?: TfGatewayTarget.OauthProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetOauthPropertyToHclTerraform(struct?: TfGatewayTarget.OauthProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetCredentialProviderConfigurationPropertyToTerraform(struct?: TfGatewayTarget.CredentialProviderConfigurationProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetCredentialProviderConfigurationPropertyToHclTerraform(struct?: TfGatewayTarget.CredentialProviderConfigurationProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetMetadataConfigurationPropertyToTerraform(struct?: TfGatewayTarget.MetadataConfigurationProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetMetadataConfigurationPropertyToHclTerraform(struct?: TfGatewayTarget.MetadataConfigurationProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetManagedVpcResourcePropertyToTerraform(struct?: TfGatewayTarget.ManagedVpcResourceProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetManagedVpcResourcePropertyToHclTerraform(struct?: TfGatewayTarget.ManagedVpcResourceProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetSelfManagedLatticeResourcePropertyToTerraform(struct?: TfGatewayTarget.SelfManagedLatticeResourceProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetSelfManagedLatticeResourcePropertyToHclTerraform(struct?: TfGatewayTarget.SelfManagedLatticeResourceProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetPrivateEndpointPropertyToTerraform(struct?: TfGatewayTarget.PrivateEndpointProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetPrivateEndpointPropertyToHclTerraform(struct?: TfGatewayTarget.PrivateEndpointProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetAgentcoreRuntimePropertyToTerraform(struct?: TfGatewayTarget.AgentcoreRuntimeProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetAgentcoreRuntimePropertyToHclTerraform(struct?: TfGatewayTarget.AgentcoreRuntimeProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetHttpPropertyToTerraform(struct?: TfGatewayTarget.HttpProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetHttpPropertyToHclTerraform(struct?: TfGatewayTarget.HttpProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetToolFilterPropertyToTerraform(struct?: TfGatewayTarget.ToolFilterProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetToolFilterPropertyToHclTerraform(struct?: TfGatewayTarget.ToolFilterProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetToolOverridePropertyToTerraform(struct?: TfGatewayTarget.ToolOverrideProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetToolOverridePropertyToHclTerraform(struct?: TfGatewayTarget.ToolOverrideProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetApiGatewayToolConfigurationPropertyToTerraform(struct?: TfGatewayTarget.ApiGatewayToolConfigurationProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetApiGatewayToolConfigurationPropertyToHclTerraform(struct?: TfGatewayTarget.ApiGatewayToolConfigurationProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetApiGatewayPropertyToTerraform(struct?: TfGatewayTarget.ApiGatewayProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetApiGatewayPropertyToHclTerraform(struct?: TfGatewayTarget.ApiGatewayProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsItemsPropertyToTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsItemsProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsItemsPropertyToHclTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsItemsProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsPropertyPropertyToTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsPropertyProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsPropertyPropertyToHclTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsPropertyProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsPropertyToTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsPropertyToHclTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsItemsPropertyToTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsItemsProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsItemsPropertyToHclTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsItemsProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsPropertyPropertyToTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsPropertyProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsPropertyPropertyToHclTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsPropertyProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsPropertyToTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsPropertyToHclTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyPropertyPropertyToTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyPropertyProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyPropertyPropertyToHclTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyPropertyProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyPropertyToTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyPropertyToHclTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetInputSchemaPropertyToTerraform(struct?: TfGatewayTarget.InputSchemaProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetInputSchemaPropertyToHclTerraform(struct?: TfGatewayTarget.InputSchemaProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsItemsPropertyToTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsItemsProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsItemsPropertyToHclTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsItemsProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsPropertyPropertyToTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsPropertyProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsPropertyPropertyToHclTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsPropertyProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsPropertyToTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsPropertyToHclTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsItemsPropertyToTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsItemsProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsItemsPropertyToHclTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsItemsProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsPropertyPropertyToTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsPropertyProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsPropertyPropertyToHclTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsPropertyProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsPropertyToTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsPropertyToHclTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyPropertyPropertyToTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyPropertyProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyPropertyPropertyToHclTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyPropertyProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyPropertyToTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyPropertyToHclTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetOutputSchemaPropertyToTerraform(struct?: TfGatewayTarget.OutputSchemaProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetOutputSchemaPropertyToHclTerraform(struct?: TfGatewayTarget.OutputSchemaProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadPropertyToTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpLambdaToolSchemaInlinePayloadProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpLambdaToolSchemaInlinePayloadPropertyToHclTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpLambdaToolSchemaInlinePayloadProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpLambdaToolSchemaS3PropertyToTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpLambdaToolSchemaS3Property | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpLambdaToolSchemaS3PropertyToHclTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpLambdaToolSchemaS3Property | cdktn.IResolvable): any;
export declare function tfGatewayTargetToolSchemaPropertyToTerraform(struct?: TfGatewayTarget.ToolSchemaProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetToolSchemaPropertyToHclTerraform(struct?: TfGatewayTarget.ToolSchemaProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetLambdaPropertyToTerraform(struct?: TfGatewayTarget.LambdaProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetLambdaPropertyToHclTerraform(struct?: TfGatewayTarget.LambdaProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchemaInlinePayloadPropertyToTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpMcpServerMcpToolSchemaInlinePayloadProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchemaInlinePayloadPropertyToHclTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpMcpServerMcpToolSchemaInlinePayloadProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchemaS3PropertyToTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpMcpServerMcpToolSchemaS3Property | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpMcpServerMcpToolSchemaS3PropertyToHclTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpMcpServerMcpToolSchemaS3Property | cdktn.IResolvable): any;
export declare function tfGatewayTargetMcpToolSchemaPropertyToTerraform(struct?: TfGatewayTarget.McpToolSchemaProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetMcpToolSchemaPropertyToHclTerraform(struct?: TfGatewayTarget.McpToolSchemaProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetMcpServerPropertyToTerraform(struct?: TfGatewayTarget.McpServerProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetMcpServerPropertyToHclTerraform(struct?: TfGatewayTarget.McpServerProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpOpenApiSchemaInlinePayloadPropertyToTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpOpenApiSchemaInlinePayloadProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpOpenApiSchemaInlinePayloadPropertyToHclTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpOpenApiSchemaInlinePayloadProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpOpenApiSchemaS3PropertyToTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpOpenApiSchemaS3Property | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpOpenApiSchemaS3PropertyToHclTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpOpenApiSchemaS3Property | cdktn.IResolvable): any;
export declare function tfGatewayTargetOpenApiSchemaPropertyToTerraform(struct?: TfGatewayTarget.OpenApiSchemaProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetOpenApiSchemaPropertyToHclTerraform(struct?: TfGatewayTarget.OpenApiSchemaProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpSmithyModelInlinePayloadPropertyToTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpSmithyModelInlinePayloadProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpSmithyModelInlinePayloadPropertyToHclTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpSmithyModelInlinePayloadProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpSmithyModelS3PropertyToTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpSmithyModelS3Property | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationMcpSmithyModelS3PropertyToHclTerraform(struct?: TfGatewayTarget.TargetConfigurationMcpSmithyModelS3Property | cdktn.IResolvable): any;
export declare function tfGatewayTargetSmithyModelPropertyToTerraform(struct?: TfGatewayTarget.SmithyModelProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetSmithyModelPropertyToHclTerraform(struct?: TfGatewayTarget.SmithyModelProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetMcpPropertyToTerraform(struct?: TfGatewayTarget.McpProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetMcpPropertyToHclTerraform(struct?: TfGatewayTarget.McpProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationPropertyToTerraform(struct?: TfGatewayTarget.TargetConfigurationProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTargetConfigurationPropertyToHclTerraform(struct?: TfGatewayTarget.TargetConfigurationProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTimeoutsPropertyToTerraform(struct?: TfGatewayTarget.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfGatewayTargetTimeoutsPropertyToHclTerraform(struct?: TfGatewayTarget.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfGatewayTarget {
    interface ApiKeyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#credential_location TfGatewayTarget#credential_location}
        */
        readonly credentialLocation?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#credential_parameter_name TfGatewayTarget#credential_parameter_name}
        */
        readonly credentialParameterName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#credential_prefix TfGatewayTarget#credential_prefix}
        */
        readonly credentialPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#provider_arn TfGatewayTarget#provider_arn}
        */
        readonly providerArn: string;
    }
    class ApiKeyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ApiKeyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ApiKeyProperty | cdktn.IResolvable | undefined);
        private _credentialLocation?;
        get credentialLocation(): string;
        set credentialLocation(value: string);
        resetCredentialLocation(): void;
        get credentialLocationInput(): string | undefined;
        private _credentialParameterName?;
        get credentialParameterName(): string;
        set credentialParameterName(value: string);
        resetCredentialParameterName(): void;
        get credentialParameterNameInput(): string | undefined;
        private _credentialPrefix?;
        get credentialPrefix(): string;
        set credentialPrefix(value: string);
        resetCredentialPrefix(): void;
        get credentialPrefixInput(): string | undefined;
        private _providerArn?;
        get providerArn(): string;
        set providerArn(value: string);
        get providerArnInput(): string | undefined;
    }
    class ApiKeyPropertyList extends cdktn.ComplexList {
        internalValue?: ApiKeyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ApiKeyPropertyOutputReference;
    }
    interface CallerIamCredentialsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#region TfGatewayTarget#region}
        */
        readonly region?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#service TfGatewayTarget#service}
        */
        readonly service: string;
    }
    class CallerIamCredentialsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CallerIamCredentialsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CallerIamCredentialsProperty | cdktn.IResolvable | undefined);
        private _region?;
        get region(): string;
        set region(value: string);
        resetRegion(): void;
        get regionInput(): string | undefined;
        private _service?;
        get service(): string;
        set service(value: string);
        get serviceInput(): string | undefined;
    }
    class CallerIamCredentialsPropertyList extends cdktn.ComplexList {
        internalValue?: CallerIamCredentialsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CallerIamCredentialsPropertyOutputReference;
    }
    interface GatewayIamRoleProperty {
        /**
        * AWS Region used for SigV4 signing of upstream requests. Defaults to the gateway's Region when omitted. Only meaningful when `service` is set.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#region TfGatewayTarget#region}
        */
        readonly region?: string;
        /**
        * The target AWS service name used for SigV4 signing of upstream requests. Required when calling SigV4-protected endpoints such as another Bedrock AgentCore Runtime (use `bedrock-agentcore`). Omit for non-SigV4 IAM-role-based authentication.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#service TfGatewayTarget#service}
        */
        readonly service?: string;
    }
    class GatewayIamRolePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GatewayIamRoleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: GatewayIamRoleProperty | cdktn.IResolvable | undefined);
        private _region?;
        get region(): string;
        set region(value: string);
        resetRegion(): void;
        get regionInput(): string | undefined;
        private _service?;
        get service(): string;
        set service(value: string);
        resetService(): void;
        get serviceInput(): string | undefined;
    }
    class GatewayIamRolePropertyList extends cdktn.ComplexList {
        internalValue?: GatewayIamRoleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GatewayIamRolePropertyOutputReference;
    }
    interface JwtPassthroughProperty {
    }
    class JwtPassthroughPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): JwtPassthroughProperty | cdktn.IResolvable | undefined;
        set internalValue(value: JwtPassthroughProperty | cdktn.IResolvable | undefined);
    }
    class JwtPassthroughPropertyList extends cdktn.ComplexList {
        internalValue?: JwtPassthroughProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): JwtPassthroughPropertyOutputReference;
    }
    interface OauthProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#custom_parameters TfGatewayTarget#custom_parameters}
        */
        readonly customParameters?: {
            [key: string]: string;
        };
        /**
        * The URL where the end user's browser is redirected after obtaining the authorization code. Required when grant_type is AUTHORIZATION_CODE.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#default_return_url TfGatewayTarget#default_return_url}
        */
        readonly defaultReturnUrl?: string;
        /**
        * The OAuth grant type. Valid values are AUTHORIZATION_CODE and CLIENT_CREDENTIALS.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#grant_type TfGatewayTarget#grant_type}
        */
        readonly grantType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#provider_arn TfGatewayTarget#provider_arn}
        */
        readonly providerArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#scopes TfGatewayTarget#scopes}
        */
        readonly scopes: string[];
    }
    class OauthPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OauthProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OauthProperty | cdktn.IResolvable | undefined);
        private _customParameters?;
        get customParameters(): {
            [key: string]: string;
        };
        set customParameters(value: {
            [key: string]: string;
        });
        resetCustomParameters(): void;
        get customParametersInput(): {
            [key: string]: string;
        } | undefined;
        private _defaultReturnUrl?;
        get defaultReturnUrl(): string;
        set defaultReturnUrl(value: string);
        resetDefaultReturnUrl(): void;
        get defaultReturnUrlInput(): string | undefined;
        private _grantType?;
        get grantType(): string;
        set grantType(value: string);
        resetGrantType(): void;
        get grantTypeInput(): string | undefined;
        private _providerArn?;
        get providerArn(): string;
        set providerArn(value: string);
        get providerArnInput(): string | undefined;
        private _scopes?;
        get scopes(): string[];
        set scopes(value: string[]);
        get scopesInput(): string[] | undefined;
    }
    class OauthPropertyList extends cdktn.ComplexList {
        internalValue?: OauthProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OauthPropertyOutputReference;
    }
    interface CredentialProviderConfigurationProperty {
        /**
        * api_key block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#api_key TfGatewayTarget#api_key}
        */
        readonly apiKey?: ApiKeyProperty[] | cdktn.IResolvable;
        /**
        * caller_iam_credentials block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#caller_iam_credentials TfGatewayTarget#caller_iam_credentials}
        */
        readonly callerIamCredentials?: CallerIamCredentialsProperty[] | cdktn.IResolvable;
        /**
        * gateway_iam_role block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#gateway_iam_role TfGatewayTarget#gateway_iam_role}
        */
        readonly gatewayIamRole?: GatewayIamRoleProperty[] | cdktn.IResolvable;
        /**
        * jwt_passthrough block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#jwt_passthrough TfGatewayTarget#jwt_passthrough}
        */
        readonly jwtPassthrough?: JwtPassthroughProperty[] | cdktn.IResolvable;
        /**
        * oauth block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#oauth TfGatewayTarget#oauth}
        */
        readonly oauth?: OauthProperty[] | cdktn.IResolvable;
    }
    class CredentialProviderConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CredentialProviderConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CredentialProviderConfigurationProperty | cdktn.IResolvable | undefined);
        private _apiKey;
        get apiKey(): ApiKeyPropertyList;
        putApiKey(value: ApiKeyProperty[] | cdktn.IResolvable): void;
        resetApiKey(): void;
        get apiKeyInput(): cdktn.IResolvable | ApiKeyProperty[] | undefined;
        private _callerIamCredentials;
        get callerIamCredentials(): CallerIamCredentialsPropertyList;
        putCallerIamCredentials(value: CallerIamCredentialsProperty[] | cdktn.IResolvable): void;
        resetCallerIamCredentials(): void;
        get callerIamCredentialsInput(): cdktn.IResolvable | CallerIamCredentialsProperty[] | undefined;
        private _gatewayIamRole;
        get gatewayIamRole(): GatewayIamRolePropertyList;
        putGatewayIamRole(value: GatewayIamRoleProperty[] | cdktn.IResolvable): void;
        resetGatewayIamRole(): void;
        get gatewayIamRoleInput(): cdktn.IResolvable | GatewayIamRoleProperty[] | undefined;
        private _jwtPassthrough;
        get jwtPassthrough(): JwtPassthroughPropertyList;
        putJwtPassthrough(value: JwtPassthroughProperty[] | cdktn.IResolvable): void;
        resetJwtPassthrough(): void;
        get jwtPassthroughInput(): cdktn.IResolvable | JwtPassthroughProperty[] | undefined;
        private _oauth;
        get oauth(): OauthPropertyList;
        putOauth(value: OauthProperty[] | cdktn.IResolvable): void;
        resetOauth(): void;
        get oauthInput(): cdktn.IResolvable | OauthProperty[] | undefined;
    }
    class CredentialProviderConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: CredentialProviderConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CredentialProviderConfigurationPropertyOutputReference;
    }
    interface MetadataConfigurationProperty {
        /**
        * A list of URL query parameters that are allowed to be propagated from incoming gateway URL to the target.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#allowed_query_parameters TfGatewayTarget#allowed_query_parameters}
        */
        readonly allowedQueryParameters?: string[];
        /**
        * A list of HTTP headers that are allowed to be propagated from incoming client requests to the target.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#allowed_request_headers TfGatewayTarget#allowed_request_headers}
        */
        readonly allowedRequestHeaders?: string[];
        /**
        * A list of HTTP headers that are allowed to be propagated from the target response back to the client.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#allowed_response_headers TfGatewayTarget#allowed_response_headers}
        */
        readonly allowedResponseHeaders?: string[];
    }
    class MetadataConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MetadataConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MetadataConfigurationProperty | cdktn.IResolvable | undefined);
        private _allowedQueryParameters?;
        get allowedQueryParameters(): string[];
        set allowedQueryParameters(value: string[]);
        resetAllowedQueryParameters(): void;
        get allowedQueryParametersInput(): string[] | undefined;
        private _allowedRequestHeaders?;
        get allowedRequestHeaders(): string[];
        set allowedRequestHeaders(value: string[]);
        resetAllowedRequestHeaders(): void;
        get allowedRequestHeadersInput(): string[] | undefined;
        private _allowedResponseHeaders?;
        get allowedResponseHeaders(): string[];
        set allowedResponseHeaders(value: string[]);
        resetAllowedResponseHeaders(): void;
        get allowedResponseHeadersInput(): string[] | undefined;
    }
    class MetadataConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: MetadataConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MetadataConfigurationPropertyOutputReference;
    }
    interface ManagedVpcResourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#endpoint_ip_address_type TfGatewayTarget#endpoint_ip_address_type}
        */
        readonly endpointIpAddressType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#routing_domain TfGatewayTarget#routing_domain}
        */
        readonly routingDomain?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#security_group_ids TfGatewayTarget#security_group_ids}
        */
        readonly securityGroupIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#subnet_ids TfGatewayTarget#subnet_ids}
        */
        readonly subnetIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#tags TfGatewayTarget#tags}
        */
        readonly tags?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#vpc_identifier TfGatewayTarget#vpc_identifier}
        */
        readonly vpcIdentifier: string;
    }
    class ManagedVpcResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ManagedVpcResourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ManagedVpcResourceProperty | cdktn.IResolvable | undefined);
        private _endpointIpAddressType?;
        get endpointIpAddressType(): string;
        set endpointIpAddressType(value: string);
        get endpointIpAddressTypeInput(): string | undefined;
        private _routingDomain?;
        get routingDomain(): string;
        set routingDomain(value: string);
        resetRoutingDomain(): void;
        get routingDomainInput(): string | undefined;
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        resetSecurityGroupIds(): void;
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
        private _tags?;
        get tags(): {
            [key: string]: string;
        };
        set tags(value: {
            [key: string]: string;
        });
        resetTags(): void;
        get tagsInput(): {
            [key: string]: string;
        } | undefined;
        private _vpcIdentifier?;
        get vpcIdentifier(): string;
        set vpcIdentifier(value: string);
        get vpcIdentifierInput(): string | undefined;
    }
    class ManagedVpcResourcePropertyList extends cdktn.ComplexList {
        internalValue?: ManagedVpcResourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ManagedVpcResourcePropertyOutputReference;
    }
    interface SelfManagedLatticeResourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#resource_configuration_identifier TfGatewayTarget#resource_configuration_identifier}
        */
        readonly resourceConfigurationIdentifier: string;
    }
    class SelfManagedLatticeResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SelfManagedLatticeResourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SelfManagedLatticeResourceProperty | cdktn.IResolvable | undefined);
        private _resourceConfigurationIdentifier?;
        get resourceConfigurationIdentifier(): string;
        set resourceConfigurationIdentifier(value: string);
        get resourceConfigurationIdentifierInput(): string | undefined;
    }
    class SelfManagedLatticeResourcePropertyList extends cdktn.ComplexList {
        internalValue?: SelfManagedLatticeResourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SelfManagedLatticeResourcePropertyOutputReference;
    }
    interface PrivateEndpointProperty {
        /**
        * managed_vpc_resource block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#managed_vpc_resource TfGatewayTarget#managed_vpc_resource}
        */
        readonly managedVpcResource?: ManagedVpcResourceProperty[] | cdktn.IResolvable;
        /**
        * self_managed_lattice_resource block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#self_managed_lattice_resource TfGatewayTarget#self_managed_lattice_resource}
        */
        readonly selfManagedLatticeResource?: SelfManagedLatticeResourceProperty[] | cdktn.IResolvable;
    }
    class PrivateEndpointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PrivateEndpointProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PrivateEndpointProperty | cdktn.IResolvable | undefined);
        private _managedVpcResource;
        get managedVpcResource(): ManagedVpcResourcePropertyList;
        putManagedVpcResource(value: ManagedVpcResourceProperty[] | cdktn.IResolvable): void;
        resetManagedVpcResource(): void;
        get managedVpcResourceInput(): cdktn.IResolvable | ManagedVpcResourceProperty[] | undefined;
        private _selfManagedLatticeResource;
        get selfManagedLatticeResource(): SelfManagedLatticeResourcePropertyList;
        putSelfManagedLatticeResource(value: SelfManagedLatticeResourceProperty[] | cdktn.IResolvable): void;
        resetSelfManagedLatticeResource(): void;
        get selfManagedLatticeResourceInput(): cdktn.IResolvable | SelfManagedLatticeResourceProperty[] | undefined;
    }
    class PrivateEndpointPropertyList extends cdktn.ComplexList {
        internalValue?: PrivateEndpointProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PrivateEndpointPropertyOutputReference;
    }
    interface AgentcoreRuntimeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#arn TfGatewayTarget#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#qualifier TfGatewayTarget#qualifier}
        */
        readonly qualifier?: string;
    }
    class AgentcoreRuntimePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AgentcoreRuntimeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AgentcoreRuntimeProperty | cdktn.IResolvable | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _qualifier?;
        get qualifier(): string;
        set qualifier(value: string);
        resetQualifier(): void;
        get qualifierInput(): string | undefined;
    }
    class AgentcoreRuntimePropertyList extends cdktn.ComplexList {
        internalValue?: AgentcoreRuntimeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AgentcoreRuntimePropertyOutputReference;
    }
    interface HttpProperty {
        /**
        * agentcore_runtime block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#agentcore_runtime TfGatewayTarget#agentcore_runtime}
        */
        readonly agentcoreRuntime?: AgentcoreRuntimeProperty[] | cdktn.IResolvable;
    }
    class HttpPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HttpProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HttpProperty | cdktn.IResolvable | undefined);
        private _agentcoreRuntime;
        get agentcoreRuntime(): AgentcoreRuntimePropertyList;
        putAgentcoreRuntime(value: AgentcoreRuntimeProperty[] | cdktn.IResolvable): void;
        resetAgentcoreRuntime(): void;
        get agentcoreRuntimeInput(): cdktn.IResolvable | AgentcoreRuntimeProperty[] | undefined;
    }
    class HttpPropertyList extends cdktn.ComplexList {
        internalValue?: HttpProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HttpPropertyOutputReference;
    }
    interface ToolFilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#filter_path TfGatewayTarget#filter_path}
        */
        readonly filterPath: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#methods TfGatewayTarget#methods}
        */
        readonly methods: string[];
    }
    class ToolFilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ToolFilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ToolFilterProperty | cdktn.IResolvable | undefined);
        private _filterPath?;
        get filterPath(): string;
        set filterPath(value: string);
        get filterPathInput(): string | undefined;
        private _methods?;
        get methods(): string[];
        set methods(value: string[]);
        get methodsInput(): string[] | undefined;
    }
    class ToolFilterPropertyList extends cdktn.ComplexList {
        internalValue?: ToolFilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ToolFilterPropertyOutputReference;
    }
    interface ToolOverrideProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#description TfGatewayTarget#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#method TfGatewayTarget#method}
        */
        readonly method: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#name TfGatewayTarget#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#path TfGatewayTarget#path}
        */
        readonly path: string;
    }
    class ToolOverridePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ToolOverrideProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ToolOverrideProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _method?;
        get method(): string;
        set method(value: string);
        get methodInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _path?;
        get path(): string;
        set path(value: string);
        get pathInput(): string | undefined;
    }
    class ToolOverridePropertyList extends cdktn.ComplexList {
        internalValue?: ToolOverrideProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ToolOverridePropertyOutputReference;
    }
    interface ApiGatewayToolConfigurationProperty {
        /**
        * tool_filter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#tool_filter TfGatewayTarget#tool_filter}
        */
        readonly toolFilter?: ToolFilterProperty[] | cdktn.IResolvable;
        /**
        * tool_override block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#tool_override TfGatewayTarget#tool_override}
        */
        readonly toolOverride?: ToolOverrideProperty[] | cdktn.IResolvable;
    }
    class ApiGatewayToolConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ApiGatewayToolConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ApiGatewayToolConfigurationProperty | cdktn.IResolvable | undefined);
        private _toolFilter;
        get toolFilter(): ToolFilterPropertyList;
        putToolFilter(value: ToolFilterProperty[] | cdktn.IResolvable): void;
        resetToolFilter(): void;
        get toolFilterInput(): cdktn.IResolvable | ToolFilterProperty[] | undefined;
        private _toolOverride;
        get toolOverride(): ToolOverridePropertyList;
        putToolOverride(value: ToolOverrideProperty[] | cdktn.IResolvable): void;
        resetToolOverride(): void;
        get toolOverrideInput(): cdktn.IResolvable | ToolOverrideProperty[] | undefined;
    }
    class ApiGatewayToolConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ApiGatewayToolConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ApiGatewayToolConfigurationPropertyOutputReference;
    }
    interface ApiGatewayProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#rest_api_id TfGatewayTarget#rest_api_id}
        */
        readonly restApiId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#stage TfGatewayTarget#stage}
        */
        readonly stage: string;
        /**
        * api_gateway_tool_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#api_gateway_tool_configuration TfGatewayTarget#api_gateway_tool_configuration}
        */
        readonly apiGatewayToolConfiguration?: ApiGatewayToolConfigurationProperty[] | cdktn.IResolvable;
    }
    class ApiGatewayPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ApiGatewayProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ApiGatewayProperty | cdktn.IResolvable | undefined);
        private _restApiId?;
        get restApiId(): string;
        set restApiId(value: string);
        get restApiIdInput(): string | undefined;
        private _stage?;
        get stage(): string;
        set stage(value: string);
        get stageInput(): string | undefined;
        private _apiGatewayToolConfiguration;
        get apiGatewayToolConfiguration(): ApiGatewayToolConfigurationPropertyList;
        putApiGatewayToolConfiguration(value: ApiGatewayToolConfigurationProperty[] | cdktn.IResolvable): void;
        resetApiGatewayToolConfiguration(): void;
        get apiGatewayToolConfigurationInput(): cdktn.IResolvable | ApiGatewayToolConfigurationProperty[] | undefined;
    }
    class ApiGatewayPropertyList extends cdktn.ComplexList {
        internalValue?: ApiGatewayProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ApiGatewayPropertyOutputReference;
    }
    interface TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsItemsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#description TfGatewayTarget#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#items_json TfGatewayTarget#items_json}
        */
        readonly itemsJson?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#properties_json TfGatewayTarget#properties_json}
        */
        readonly propertiesJson?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#type TfGatewayTarget#type}
        */
        readonly type: string;
    }
    class TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsItemsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsItemsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsItemsProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _itemsJson?;
        get itemsJson(): string;
        set itemsJson(value: string);
        resetItemsJson(): void;
        get itemsJsonInput(): string | undefined;
        private _propertiesJson?;
        get propertiesJson(): string;
        set propertiesJson(value: string);
        resetPropertiesJson(): void;
        get propertiesJsonInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsItemsPropertyList extends cdktn.ComplexList {
        internalValue?: TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsItemsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsItemsPropertyOutputReference;
    }
    interface TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsPropertyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#description TfGatewayTarget#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#items_json TfGatewayTarget#items_json}
        */
        readonly itemsJson?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#name TfGatewayTarget#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#properties_json TfGatewayTarget#properties_json}
        */
        readonly propertiesJson?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#required TfGatewayTarget#required}
        */
        readonly required?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#type TfGatewayTarget#type}
        */
        readonly type: string;
    }
    class TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsPropertyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsPropertyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsPropertyProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _itemsJson?;
        get itemsJson(): string;
        set itemsJson(value: string);
        resetItemsJson(): void;
        get itemsJsonInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _propertiesJson?;
        get propertiesJson(): string;
        set propertiesJson(value: string);
        resetPropertiesJson(): void;
        get propertiesJsonInput(): string | undefined;
        private _required?;
        get required(): boolean | cdktn.IResolvable;
        set required(value: boolean | cdktn.IResolvable);
        resetRequired(): void;
        get requiredInput(): boolean | cdktn.IResolvable | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsPropertyPropertyList extends cdktn.ComplexList {
        internalValue?: TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsPropertyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsPropertyPropertyOutputReference;
    }
    interface TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#description TfGatewayTarget#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#type TfGatewayTarget#type}
        */
        readonly type: string;
        /**
        * items block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#items TfGatewayTarget#items}
        */
        readonly items?: TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsItemsProperty[] | cdktn.IResolvable;
        /**
        * property block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#property TfGatewayTarget#property}
        */
        readonly property?: TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsPropertyProperty[] | cdktn.IResolvable;
    }
    class TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _items;
        get items(): TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsItemsPropertyList;
        putItems(value: TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsItemsProperty[] | cdktn.IResolvable): void;
        resetItems(): void;
        get itemsInput(): cdktn.IResolvable | TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsItemsProperty[] | undefined;
        private _property;
        get property(): TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsPropertyPropertyList;
        putProperty(value: TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsPropertyProperty[] | cdktn.IResolvable): void;
        resetProperty(): void;
        get propertyInput(): cdktn.IResolvable | TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsPropertyProperty[] | undefined;
    }
    class TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsPropertyList extends cdktn.ComplexList {
        internalValue?: TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsPropertyOutputReference;
    }
    interface TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsItemsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#description TfGatewayTarget#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#items_json TfGatewayTarget#items_json}
        */
        readonly itemsJson?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#properties_json TfGatewayTarget#properties_json}
        */
        readonly propertiesJson?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#type TfGatewayTarget#type}
        */
        readonly type: string;
    }
    class TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsItemsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsItemsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsItemsProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _itemsJson?;
        get itemsJson(): string;
        set itemsJson(value: string);
        resetItemsJson(): void;
        get itemsJsonInput(): string | undefined;
        private _propertiesJson?;
        get propertiesJson(): string;
        set propertiesJson(value: string);
        resetPropertiesJson(): void;
        get propertiesJsonInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsItemsPropertyList extends cdktn.ComplexList {
        internalValue?: TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsItemsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsItemsPropertyOutputReference;
    }
    interface TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsPropertyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#description TfGatewayTarget#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#items_json TfGatewayTarget#items_json}
        */
        readonly itemsJson?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#name TfGatewayTarget#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#properties_json TfGatewayTarget#properties_json}
        */
        readonly propertiesJson?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#required TfGatewayTarget#required}
        */
        readonly required?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#type TfGatewayTarget#type}
        */
        readonly type: string;
    }
    class TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsPropertyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsPropertyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsPropertyProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _itemsJson?;
        get itemsJson(): string;
        set itemsJson(value: string);
        resetItemsJson(): void;
        get itemsJsonInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _propertiesJson?;
        get propertiesJson(): string;
        set propertiesJson(value: string);
        resetPropertiesJson(): void;
        get propertiesJsonInput(): string | undefined;
        private _required?;
        get required(): boolean | cdktn.IResolvable;
        set required(value: boolean | cdktn.IResolvable);
        resetRequired(): void;
        get requiredInput(): boolean | cdktn.IResolvable | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsPropertyPropertyList extends cdktn.ComplexList {
        internalValue?: TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsPropertyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsPropertyPropertyOutputReference;
    }
    interface TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#description TfGatewayTarget#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#type TfGatewayTarget#type}
        */
        readonly type: string;
        /**
        * items block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#items TfGatewayTarget#items}
        */
        readonly items?: TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsItemsProperty[] | cdktn.IResolvable;
        /**
        * property block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#property TfGatewayTarget#property}
        */
        readonly property?: TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsPropertyProperty[] | cdktn.IResolvable;
    }
    class TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _items;
        get items(): TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsItemsPropertyList;
        putItems(value: TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsItemsProperty[] | cdktn.IResolvable): void;
        resetItems(): void;
        get itemsInput(): cdktn.IResolvable | TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsItemsProperty[] | undefined;
        private _property;
        get property(): TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsPropertyPropertyList;
        putProperty(value: TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsPropertyProperty[] | cdktn.IResolvable): void;
        resetProperty(): void;
        get propertyInput(): cdktn.IResolvable | TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsPropertyProperty[] | undefined;
    }
    class TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsPropertyList extends cdktn.ComplexList {
        internalValue?: TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsPropertyOutputReference;
    }
    interface TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyPropertyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#description TfGatewayTarget#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#items_json TfGatewayTarget#items_json}
        */
        readonly itemsJson?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#name TfGatewayTarget#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#properties_json TfGatewayTarget#properties_json}
        */
        readonly propertiesJson?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#required TfGatewayTarget#required}
        */
        readonly required?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#type TfGatewayTarget#type}
        */
        readonly type: string;
    }
    class TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyPropertyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyPropertyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyPropertyProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _itemsJson?;
        get itemsJson(): string;
        set itemsJson(value: string);
        resetItemsJson(): void;
        get itemsJsonInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _propertiesJson?;
        get propertiesJson(): string;
        set propertiesJson(value: string);
        resetPropertiesJson(): void;
        get propertiesJsonInput(): string | undefined;
        private _required?;
        get required(): boolean | cdktn.IResolvable;
        set required(value: boolean | cdktn.IResolvable);
        resetRequired(): void;
        get requiredInput(): boolean | cdktn.IResolvable | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyPropertyPropertyList extends cdktn.ComplexList {
        internalValue?: TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyPropertyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyPropertyPropertyOutputReference;
    }
    interface TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#description TfGatewayTarget#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#name TfGatewayTarget#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#required TfGatewayTarget#required}
        */
        readonly required?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#type TfGatewayTarget#type}
        */
        readonly type: string;
        /**
        * items block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#items TfGatewayTarget#items}
        */
        readonly items?: TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsProperty[] | cdktn.IResolvable;
        /**
        * property block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#property TfGatewayTarget#property}
        */
        readonly property?: TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyPropertyProperty[] | cdktn.IResolvable;
    }
    class TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _required?;
        get required(): boolean | cdktn.IResolvable;
        set required(value: boolean | cdktn.IResolvable);
        resetRequired(): void;
        get requiredInput(): boolean | cdktn.IResolvable | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _items;
        get items(): TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsPropertyList;
        putItems(value: TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsProperty[] | cdktn.IResolvable): void;
        resetItems(): void;
        get itemsInput(): cdktn.IResolvable | TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyItemsProperty[] | undefined;
        private _property;
        get property(): TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyPropertyPropertyList;
        putProperty(value: TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyPropertyProperty[] | cdktn.IResolvable): void;
        resetProperty(): void;
        get propertyInput(): cdktn.IResolvable | TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyPropertyProperty[] | undefined;
    }
    class TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyPropertyList extends cdktn.ComplexList {
        internalValue?: TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyPropertyOutputReference;
    }
    interface InputSchemaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#description TfGatewayTarget#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#type TfGatewayTarget#type}
        */
        readonly type: string;
        /**
        * items block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#items TfGatewayTarget#items}
        */
        readonly items?: TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsProperty[] | cdktn.IResolvable;
        /**
        * property block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#property TfGatewayTarget#property}
        */
        readonly property?: TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyProperty[] | cdktn.IResolvable;
    }
    class InputSchemaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InputSchemaProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InputSchemaProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _items;
        get items(): TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsPropertyList;
        putItems(value: TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsProperty[] | cdktn.IResolvable): void;
        resetItems(): void;
        get itemsInput(): cdktn.IResolvable | TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaItemsProperty[] | undefined;
        private _property;
        get property(): TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyPropertyList;
        putProperty(value: TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyProperty[] | cdktn.IResolvable): void;
        resetProperty(): void;
        get propertyInput(): cdktn.IResolvable | TargetConfigurationMcpLambdaToolSchemaInlinePayloadInputSchemaPropertyProperty[] | undefined;
    }
    class InputSchemaPropertyList extends cdktn.ComplexList {
        internalValue?: InputSchemaProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InputSchemaPropertyOutputReference;
    }
    interface TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsItemsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#description TfGatewayTarget#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#items_json TfGatewayTarget#items_json}
        */
        readonly itemsJson?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#properties_json TfGatewayTarget#properties_json}
        */
        readonly propertiesJson?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#type TfGatewayTarget#type}
        */
        readonly type: string;
    }
    class TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsItemsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsItemsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsItemsProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _itemsJson?;
        get itemsJson(): string;
        set itemsJson(value: string);
        resetItemsJson(): void;
        get itemsJsonInput(): string | undefined;
        private _propertiesJson?;
        get propertiesJson(): string;
        set propertiesJson(value: string);
        resetPropertiesJson(): void;
        get propertiesJsonInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsItemsPropertyList extends cdktn.ComplexList {
        internalValue?: TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsItemsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsItemsPropertyOutputReference;
    }
    interface TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsPropertyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#description TfGatewayTarget#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#items_json TfGatewayTarget#items_json}
        */
        readonly itemsJson?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#name TfGatewayTarget#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#properties_json TfGatewayTarget#properties_json}
        */
        readonly propertiesJson?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#required TfGatewayTarget#required}
        */
        readonly required?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#type TfGatewayTarget#type}
        */
        readonly type: string;
    }
    class TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsPropertyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsPropertyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsPropertyProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _itemsJson?;
        get itemsJson(): string;
        set itemsJson(value: string);
        resetItemsJson(): void;
        get itemsJsonInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _propertiesJson?;
        get propertiesJson(): string;
        set propertiesJson(value: string);
        resetPropertiesJson(): void;
        get propertiesJsonInput(): string | undefined;
        private _required?;
        get required(): boolean | cdktn.IResolvable;
        set required(value: boolean | cdktn.IResolvable);
        resetRequired(): void;
        get requiredInput(): boolean | cdktn.IResolvable | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsPropertyPropertyList extends cdktn.ComplexList {
        internalValue?: TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsPropertyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsPropertyPropertyOutputReference;
    }
    interface TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#description TfGatewayTarget#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#type TfGatewayTarget#type}
        */
        readonly type: string;
        /**
        * items block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#items TfGatewayTarget#items}
        */
        readonly items?: TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsItemsProperty[] | cdktn.IResolvable;
        /**
        * property block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#property TfGatewayTarget#property}
        */
        readonly property?: TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsPropertyProperty[] | cdktn.IResolvable;
    }
    class TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _items;
        get items(): TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsItemsPropertyList;
        putItems(value: TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsItemsProperty[] | cdktn.IResolvable): void;
        resetItems(): void;
        get itemsInput(): cdktn.IResolvable | TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsItemsProperty[] | undefined;
        private _property;
        get property(): TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsPropertyPropertyList;
        putProperty(value: TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsPropertyProperty[] | cdktn.IResolvable): void;
        resetProperty(): void;
        get propertyInput(): cdktn.IResolvable | TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsPropertyProperty[] | undefined;
    }
    class TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsPropertyList extends cdktn.ComplexList {
        internalValue?: TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsPropertyOutputReference;
    }
    interface TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsItemsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#description TfGatewayTarget#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#items_json TfGatewayTarget#items_json}
        */
        readonly itemsJson?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#properties_json TfGatewayTarget#properties_json}
        */
        readonly propertiesJson?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#type TfGatewayTarget#type}
        */
        readonly type: string;
    }
    class TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsItemsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsItemsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsItemsProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _itemsJson?;
        get itemsJson(): string;
        set itemsJson(value: string);
        resetItemsJson(): void;
        get itemsJsonInput(): string | undefined;
        private _propertiesJson?;
        get propertiesJson(): string;
        set propertiesJson(value: string);
        resetPropertiesJson(): void;
        get propertiesJsonInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsItemsPropertyList extends cdktn.ComplexList {
        internalValue?: TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsItemsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsItemsPropertyOutputReference;
    }
    interface TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsPropertyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#description TfGatewayTarget#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#items_json TfGatewayTarget#items_json}
        */
        readonly itemsJson?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#name TfGatewayTarget#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#properties_json TfGatewayTarget#properties_json}
        */
        readonly propertiesJson?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#required TfGatewayTarget#required}
        */
        readonly required?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#type TfGatewayTarget#type}
        */
        readonly type: string;
    }
    class TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsPropertyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsPropertyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsPropertyProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _itemsJson?;
        get itemsJson(): string;
        set itemsJson(value: string);
        resetItemsJson(): void;
        get itemsJsonInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _propertiesJson?;
        get propertiesJson(): string;
        set propertiesJson(value: string);
        resetPropertiesJson(): void;
        get propertiesJsonInput(): string | undefined;
        private _required?;
        get required(): boolean | cdktn.IResolvable;
        set required(value: boolean | cdktn.IResolvable);
        resetRequired(): void;
        get requiredInput(): boolean | cdktn.IResolvable | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsPropertyPropertyList extends cdktn.ComplexList {
        internalValue?: TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsPropertyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsPropertyPropertyOutputReference;
    }
    interface TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#description TfGatewayTarget#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#type TfGatewayTarget#type}
        */
        readonly type: string;
        /**
        * items block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#items TfGatewayTarget#items}
        */
        readonly items?: TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsItemsProperty[] | cdktn.IResolvable;
        /**
        * property block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#property TfGatewayTarget#property}
        */
        readonly property?: TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsPropertyProperty[] | cdktn.IResolvable;
    }
    class TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _items;
        get items(): TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsItemsPropertyList;
        putItems(value: TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsItemsProperty[] | cdktn.IResolvable): void;
        resetItems(): void;
        get itemsInput(): cdktn.IResolvable | TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsItemsProperty[] | undefined;
        private _property;
        get property(): TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsPropertyPropertyList;
        putProperty(value: TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsPropertyProperty[] | cdktn.IResolvable): void;
        resetProperty(): void;
        get propertyInput(): cdktn.IResolvable | TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsPropertyProperty[] | undefined;
    }
    class TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsPropertyList extends cdktn.ComplexList {
        internalValue?: TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsPropertyOutputReference;
    }
    interface TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyPropertyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#description TfGatewayTarget#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#items_json TfGatewayTarget#items_json}
        */
        readonly itemsJson?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#name TfGatewayTarget#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#properties_json TfGatewayTarget#properties_json}
        */
        readonly propertiesJson?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#required TfGatewayTarget#required}
        */
        readonly required?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#type TfGatewayTarget#type}
        */
        readonly type: string;
    }
    class TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyPropertyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyPropertyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyPropertyProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _itemsJson?;
        get itemsJson(): string;
        set itemsJson(value: string);
        resetItemsJson(): void;
        get itemsJsonInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _propertiesJson?;
        get propertiesJson(): string;
        set propertiesJson(value: string);
        resetPropertiesJson(): void;
        get propertiesJsonInput(): string | undefined;
        private _required?;
        get required(): boolean | cdktn.IResolvable;
        set required(value: boolean | cdktn.IResolvable);
        resetRequired(): void;
        get requiredInput(): boolean | cdktn.IResolvable | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyPropertyPropertyList extends cdktn.ComplexList {
        internalValue?: TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyPropertyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyPropertyPropertyOutputReference;
    }
    interface TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#description TfGatewayTarget#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#name TfGatewayTarget#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#required TfGatewayTarget#required}
        */
        readonly required?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#type TfGatewayTarget#type}
        */
        readonly type: string;
        /**
        * items block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#items TfGatewayTarget#items}
        */
        readonly items?: TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsProperty[] | cdktn.IResolvable;
        /**
        * property block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#property TfGatewayTarget#property}
        */
        readonly property?: TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyPropertyProperty[] | cdktn.IResolvable;
    }
    class TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _required?;
        get required(): boolean | cdktn.IResolvable;
        set required(value: boolean | cdktn.IResolvable);
        resetRequired(): void;
        get requiredInput(): boolean | cdktn.IResolvable | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _items;
        get items(): TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsPropertyList;
        putItems(value: TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsProperty[] | cdktn.IResolvable): void;
        resetItems(): void;
        get itemsInput(): cdktn.IResolvable | TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyItemsProperty[] | undefined;
        private _property;
        get property(): TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyPropertyPropertyList;
        putProperty(value: TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyPropertyProperty[] | cdktn.IResolvable): void;
        resetProperty(): void;
        get propertyInput(): cdktn.IResolvable | TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyPropertyProperty[] | undefined;
    }
    class TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyPropertyList extends cdktn.ComplexList {
        internalValue?: TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyPropertyOutputReference;
    }
    interface OutputSchemaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#description TfGatewayTarget#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#type TfGatewayTarget#type}
        */
        readonly type: string;
        /**
        * items block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#items TfGatewayTarget#items}
        */
        readonly items?: TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsProperty[] | cdktn.IResolvable;
        /**
        * property block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#property TfGatewayTarget#property}
        */
        readonly property?: TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyProperty[] | cdktn.IResolvable;
    }
    class OutputSchemaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OutputSchemaProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OutputSchemaProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _items;
        get items(): TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsPropertyList;
        putItems(value: TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsProperty[] | cdktn.IResolvable): void;
        resetItems(): void;
        get itemsInput(): cdktn.IResolvable | TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaItemsProperty[] | undefined;
        private _property;
        get property(): TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyPropertyList;
        putProperty(value: TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyProperty[] | cdktn.IResolvable): void;
        resetProperty(): void;
        get propertyInput(): cdktn.IResolvable | TargetConfigurationMcpLambdaToolSchemaInlinePayloadOutputSchemaPropertyProperty[] | undefined;
    }
    class OutputSchemaPropertyList extends cdktn.ComplexList {
        internalValue?: OutputSchemaProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OutputSchemaPropertyOutputReference;
    }
    interface TargetConfigurationMcpLambdaToolSchemaInlinePayloadProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#description TfGatewayTarget#description}
        */
        readonly description: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#name TfGatewayTarget#name}
        */
        readonly name: string;
        /**
        * input_schema block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#input_schema TfGatewayTarget#input_schema}
        */
        readonly inputSchema?: InputSchemaProperty[] | cdktn.IResolvable;
        /**
        * output_schema block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#output_schema TfGatewayTarget#output_schema}
        */
        readonly outputSchema?: OutputSchemaProperty[] | cdktn.IResolvable;
    }
    class TargetConfigurationMcpLambdaToolSchemaInlinePayloadPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetConfigurationMcpLambdaToolSchemaInlinePayloadProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetConfigurationMcpLambdaToolSchemaInlinePayloadProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        get descriptionInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _inputSchema;
        get inputSchema(): InputSchemaPropertyList;
        putInputSchema(value: InputSchemaProperty[] | cdktn.IResolvable): void;
        resetInputSchema(): void;
        get inputSchemaInput(): cdktn.IResolvable | InputSchemaProperty[] | undefined;
        private _outputSchema;
        get outputSchema(): OutputSchemaPropertyList;
        putOutputSchema(value: OutputSchemaProperty[] | cdktn.IResolvable): void;
        resetOutputSchema(): void;
        get outputSchemaInput(): cdktn.IResolvable | OutputSchemaProperty[] | undefined;
    }
    class TargetConfigurationMcpLambdaToolSchemaInlinePayloadPropertyList extends cdktn.ComplexList {
        internalValue?: TargetConfigurationMcpLambdaToolSchemaInlinePayloadProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetConfigurationMcpLambdaToolSchemaInlinePayloadPropertyOutputReference;
    }
    interface TargetConfigurationMcpLambdaToolSchemaS3Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#bucket_owner_account_id TfGatewayTarget#bucket_owner_account_id}
        */
        readonly bucketOwnerAccountId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#uri TfGatewayTarget#uri}
        */
        readonly uri?: string;
    }
    class TargetConfigurationMcpLambdaToolSchemaS3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetConfigurationMcpLambdaToolSchemaS3Property | cdktn.IResolvable | undefined;
        set internalValue(value: TargetConfigurationMcpLambdaToolSchemaS3Property | cdktn.IResolvable | undefined);
        private _bucketOwnerAccountId?;
        get bucketOwnerAccountId(): string;
        set bucketOwnerAccountId(value: string);
        resetBucketOwnerAccountId(): void;
        get bucketOwnerAccountIdInput(): string | undefined;
        private _uri?;
        get uri(): string;
        set uri(value: string);
        resetUri(): void;
        get uriInput(): string | undefined;
    }
    class TargetConfigurationMcpLambdaToolSchemaS3PropertyList extends cdktn.ComplexList {
        internalValue?: TargetConfigurationMcpLambdaToolSchemaS3Property[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetConfigurationMcpLambdaToolSchemaS3PropertyOutputReference;
    }
    interface ToolSchemaProperty {
        /**
        * inline_payload block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#inline_payload TfGatewayTarget#inline_payload}
        */
        readonly inlinePayload?: TargetConfigurationMcpLambdaToolSchemaInlinePayloadProperty[] | cdktn.IResolvable;
        /**
        * s3 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#s3 TfGatewayTarget#s3}
        */
        readonly s3?: TargetConfigurationMcpLambdaToolSchemaS3Property[] | cdktn.IResolvable;
    }
    class ToolSchemaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ToolSchemaProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ToolSchemaProperty | cdktn.IResolvable | undefined);
        private _inlinePayload;
        get inlinePayload(): TargetConfigurationMcpLambdaToolSchemaInlinePayloadPropertyList;
        putInlinePayload(value: TargetConfigurationMcpLambdaToolSchemaInlinePayloadProperty[] | cdktn.IResolvable): void;
        resetInlinePayload(): void;
        get inlinePayloadInput(): cdktn.IResolvable | TargetConfigurationMcpLambdaToolSchemaInlinePayloadProperty[] | undefined;
        private _s3;
        get s3(): TargetConfigurationMcpLambdaToolSchemaS3PropertyList;
        putS3(value: TargetConfigurationMcpLambdaToolSchemaS3Property[] | cdktn.IResolvable): void;
        resetS3(): void;
        get s3Input(): cdktn.IResolvable | TargetConfigurationMcpLambdaToolSchemaS3Property[] | undefined;
    }
    class ToolSchemaPropertyList extends cdktn.ComplexList {
        internalValue?: ToolSchemaProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ToolSchemaPropertyOutputReference;
    }
    interface LambdaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#lambda_arn TfGatewayTarget#lambda_arn}
        */
        readonly lambdaArn: string;
        /**
        * tool_schema block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#tool_schema TfGatewayTarget#tool_schema}
        */
        readonly toolSchema?: ToolSchemaProperty[] | cdktn.IResolvable;
    }
    class LambdaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LambdaProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LambdaProperty | cdktn.IResolvable | undefined);
        private _lambdaArn?;
        get lambdaArn(): string;
        set lambdaArn(value: string);
        get lambdaArnInput(): string | undefined;
        private _toolSchema;
        get toolSchema(): ToolSchemaPropertyList;
        putToolSchema(value: ToolSchemaProperty[] | cdktn.IResolvable): void;
        resetToolSchema(): void;
        get toolSchemaInput(): cdktn.IResolvable | ToolSchemaProperty[] | undefined;
    }
    class LambdaPropertyList extends cdktn.ComplexList {
        internalValue?: LambdaProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LambdaPropertyOutputReference;
    }
    interface TargetConfigurationMcpMcpServerMcpToolSchemaInlinePayloadProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#payload TfGatewayTarget#payload}
        */
        readonly payload: string;
    }
    class TargetConfigurationMcpMcpServerMcpToolSchemaInlinePayloadPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetConfigurationMcpMcpServerMcpToolSchemaInlinePayloadProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetConfigurationMcpMcpServerMcpToolSchemaInlinePayloadProperty | cdktn.IResolvable | undefined);
        private _payload?;
        get payload(): string;
        set payload(value: string);
        get payloadInput(): string | undefined;
    }
    class TargetConfigurationMcpMcpServerMcpToolSchemaInlinePayloadPropertyList extends cdktn.ComplexList {
        internalValue?: TargetConfigurationMcpMcpServerMcpToolSchemaInlinePayloadProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetConfigurationMcpMcpServerMcpToolSchemaInlinePayloadPropertyOutputReference;
    }
    interface TargetConfigurationMcpMcpServerMcpToolSchemaS3Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#bucket_owner_account_id TfGatewayTarget#bucket_owner_account_id}
        */
        readonly bucketOwnerAccountId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#uri TfGatewayTarget#uri}
        */
        readonly uri: string;
    }
    class TargetConfigurationMcpMcpServerMcpToolSchemaS3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetConfigurationMcpMcpServerMcpToolSchemaS3Property | cdktn.IResolvable | undefined;
        set internalValue(value: TargetConfigurationMcpMcpServerMcpToolSchemaS3Property | cdktn.IResolvable | undefined);
        private _bucketOwnerAccountId?;
        get bucketOwnerAccountId(): string;
        set bucketOwnerAccountId(value: string);
        resetBucketOwnerAccountId(): void;
        get bucketOwnerAccountIdInput(): string | undefined;
        private _uri?;
        get uri(): string;
        set uri(value: string);
        get uriInput(): string | undefined;
    }
    class TargetConfigurationMcpMcpServerMcpToolSchemaS3PropertyList extends cdktn.ComplexList {
        internalValue?: TargetConfigurationMcpMcpServerMcpToolSchemaS3Property[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetConfigurationMcpMcpServerMcpToolSchemaS3PropertyOutputReference;
    }
    interface McpToolSchemaProperty {
        /**
        * inline_payload block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#inline_payload TfGatewayTarget#inline_payload}
        */
        readonly inlinePayload?: TargetConfigurationMcpMcpServerMcpToolSchemaInlinePayloadProperty[] | cdktn.IResolvable;
        /**
        * s3 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#s3 TfGatewayTarget#s3}
        */
        readonly s3?: TargetConfigurationMcpMcpServerMcpToolSchemaS3Property[] | cdktn.IResolvable;
    }
    class McpToolSchemaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): McpToolSchemaProperty | cdktn.IResolvable | undefined;
        set internalValue(value: McpToolSchemaProperty | cdktn.IResolvable | undefined);
        private _inlinePayload;
        get inlinePayload(): TargetConfigurationMcpMcpServerMcpToolSchemaInlinePayloadPropertyList;
        putInlinePayload(value: TargetConfigurationMcpMcpServerMcpToolSchemaInlinePayloadProperty[] | cdktn.IResolvable): void;
        resetInlinePayload(): void;
        get inlinePayloadInput(): cdktn.IResolvable | TargetConfigurationMcpMcpServerMcpToolSchemaInlinePayloadProperty[] | undefined;
        private _s3;
        get s3(): TargetConfigurationMcpMcpServerMcpToolSchemaS3PropertyList;
        putS3(value: TargetConfigurationMcpMcpServerMcpToolSchemaS3Property[] | cdktn.IResolvable): void;
        resetS3(): void;
        get s3Input(): cdktn.IResolvable | TargetConfigurationMcpMcpServerMcpToolSchemaS3Property[] | undefined;
    }
    class McpToolSchemaPropertyList extends cdktn.ComplexList {
        internalValue?: McpToolSchemaProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): McpToolSchemaPropertyOutputReference;
    }
    interface McpServerProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#endpoint TfGatewayTarget#endpoint}
        */
        readonly endpoint: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#listing_mode TfGatewayTarget#listing_mode}
        */
        readonly listingMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#resource_priority TfGatewayTarget#resource_priority}
        */
        readonly resourcePriority?: number;
        /**
        * mcp_tool_schema block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#mcp_tool_schema TfGatewayTarget#mcp_tool_schema}
        */
        readonly mcpToolSchema?: McpToolSchemaProperty[] | cdktn.IResolvable;
    }
    class McpServerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): McpServerProperty | cdktn.IResolvable | undefined;
        set internalValue(value: McpServerProperty | cdktn.IResolvable | undefined);
        private _endpoint?;
        get endpoint(): string;
        set endpoint(value: string);
        get endpointInput(): string | undefined;
        private _listingMode?;
        get listingMode(): string;
        set listingMode(value: string);
        resetListingMode(): void;
        get listingModeInput(): string | undefined;
        private _resourcePriority?;
        get resourcePriority(): number;
        set resourcePriority(value: number);
        resetResourcePriority(): void;
        get resourcePriorityInput(): number | undefined;
        private _mcpToolSchema;
        get mcpToolSchema(): McpToolSchemaPropertyList;
        putMcpToolSchema(value: McpToolSchemaProperty[] | cdktn.IResolvable): void;
        resetMcpToolSchema(): void;
        get mcpToolSchemaInput(): cdktn.IResolvable | McpToolSchemaProperty[] | undefined;
    }
    class McpServerPropertyList extends cdktn.ComplexList {
        internalValue?: McpServerProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): McpServerPropertyOutputReference;
    }
    interface TargetConfigurationMcpOpenApiSchemaInlinePayloadProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#payload TfGatewayTarget#payload}
        */
        readonly payload: string;
    }
    class TargetConfigurationMcpOpenApiSchemaInlinePayloadPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetConfigurationMcpOpenApiSchemaInlinePayloadProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetConfigurationMcpOpenApiSchemaInlinePayloadProperty | cdktn.IResolvable | undefined);
        private _payload?;
        get payload(): string;
        set payload(value: string);
        get payloadInput(): string | undefined;
    }
    class TargetConfigurationMcpOpenApiSchemaInlinePayloadPropertyList extends cdktn.ComplexList {
        internalValue?: TargetConfigurationMcpOpenApiSchemaInlinePayloadProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetConfigurationMcpOpenApiSchemaInlinePayloadPropertyOutputReference;
    }
    interface TargetConfigurationMcpOpenApiSchemaS3Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#bucket_owner_account_id TfGatewayTarget#bucket_owner_account_id}
        */
        readonly bucketOwnerAccountId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#uri TfGatewayTarget#uri}
        */
        readonly uri?: string;
    }
    class TargetConfigurationMcpOpenApiSchemaS3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetConfigurationMcpOpenApiSchemaS3Property | cdktn.IResolvable | undefined;
        set internalValue(value: TargetConfigurationMcpOpenApiSchemaS3Property | cdktn.IResolvable | undefined);
        private _bucketOwnerAccountId?;
        get bucketOwnerAccountId(): string;
        set bucketOwnerAccountId(value: string);
        resetBucketOwnerAccountId(): void;
        get bucketOwnerAccountIdInput(): string | undefined;
        private _uri?;
        get uri(): string;
        set uri(value: string);
        resetUri(): void;
        get uriInput(): string | undefined;
    }
    class TargetConfigurationMcpOpenApiSchemaS3PropertyList extends cdktn.ComplexList {
        internalValue?: TargetConfigurationMcpOpenApiSchemaS3Property[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetConfigurationMcpOpenApiSchemaS3PropertyOutputReference;
    }
    interface OpenApiSchemaProperty {
        /**
        * inline_payload block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#inline_payload TfGatewayTarget#inline_payload}
        */
        readonly inlinePayload?: TargetConfigurationMcpOpenApiSchemaInlinePayloadProperty[] | cdktn.IResolvable;
        /**
        * s3 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#s3 TfGatewayTarget#s3}
        */
        readonly s3?: TargetConfigurationMcpOpenApiSchemaS3Property[] | cdktn.IResolvable;
    }
    class OpenApiSchemaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OpenApiSchemaProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OpenApiSchemaProperty | cdktn.IResolvable | undefined);
        private _inlinePayload;
        get inlinePayload(): TargetConfigurationMcpOpenApiSchemaInlinePayloadPropertyList;
        putInlinePayload(value: TargetConfigurationMcpOpenApiSchemaInlinePayloadProperty[] | cdktn.IResolvable): void;
        resetInlinePayload(): void;
        get inlinePayloadInput(): cdktn.IResolvable | TargetConfigurationMcpOpenApiSchemaInlinePayloadProperty[] | undefined;
        private _s3;
        get s3(): TargetConfigurationMcpOpenApiSchemaS3PropertyList;
        putS3(value: TargetConfigurationMcpOpenApiSchemaS3Property[] | cdktn.IResolvable): void;
        resetS3(): void;
        get s3Input(): cdktn.IResolvable | TargetConfigurationMcpOpenApiSchemaS3Property[] | undefined;
    }
    class OpenApiSchemaPropertyList extends cdktn.ComplexList {
        internalValue?: OpenApiSchemaProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OpenApiSchemaPropertyOutputReference;
    }
    interface TargetConfigurationMcpSmithyModelInlinePayloadProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#payload TfGatewayTarget#payload}
        */
        readonly payload: string;
    }
    class TargetConfigurationMcpSmithyModelInlinePayloadPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetConfigurationMcpSmithyModelInlinePayloadProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetConfigurationMcpSmithyModelInlinePayloadProperty | cdktn.IResolvable | undefined);
        private _payload?;
        get payload(): string;
        set payload(value: string);
        get payloadInput(): string | undefined;
    }
    class TargetConfigurationMcpSmithyModelInlinePayloadPropertyList extends cdktn.ComplexList {
        internalValue?: TargetConfigurationMcpSmithyModelInlinePayloadProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetConfigurationMcpSmithyModelInlinePayloadPropertyOutputReference;
    }
    interface TargetConfigurationMcpSmithyModelS3Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#bucket_owner_account_id TfGatewayTarget#bucket_owner_account_id}
        */
        readonly bucketOwnerAccountId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#uri TfGatewayTarget#uri}
        */
        readonly uri?: string;
    }
    class TargetConfigurationMcpSmithyModelS3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetConfigurationMcpSmithyModelS3Property | cdktn.IResolvable | undefined;
        set internalValue(value: TargetConfigurationMcpSmithyModelS3Property | cdktn.IResolvable | undefined);
        private _bucketOwnerAccountId?;
        get bucketOwnerAccountId(): string;
        set bucketOwnerAccountId(value: string);
        resetBucketOwnerAccountId(): void;
        get bucketOwnerAccountIdInput(): string | undefined;
        private _uri?;
        get uri(): string;
        set uri(value: string);
        resetUri(): void;
        get uriInput(): string | undefined;
    }
    class TargetConfigurationMcpSmithyModelS3PropertyList extends cdktn.ComplexList {
        internalValue?: TargetConfigurationMcpSmithyModelS3Property[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetConfigurationMcpSmithyModelS3PropertyOutputReference;
    }
    interface SmithyModelProperty {
        /**
        * inline_payload block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#inline_payload TfGatewayTarget#inline_payload}
        */
        readonly inlinePayload?: TargetConfigurationMcpSmithyModelInlinePayloadProperty[] | cdktn.IResolvable;
        /**
        * s3 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#s3 TfGatewayTarget#s3}
        */
        readonly s3?: TargetConfigurationMcpSmithyModelS3Property[] | cdktn.IResolvable;
    }
    class SmithyModelPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SmithyModelProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SmithyModelProperty | cdktn.IResolvable | undefined);
        private _inlinePayload;
        get inlinePayload(): TargetConfigurationMcpSmithyModelInlinePayloadPropertyList;
        putInlinePayload(value: TargetConfigurationMcpSmithyModelInlinePayloadProperty[] | cdktn.IResolvable): void;
        resetInlinePayload(): void;
        get inlinePayloadInput(): cdktn.IResolvable | TargetConfigurationMcpSmithyModelInlinePayloadProperty[] | undefined;
        private _s3;
        get s3(): TargetConfigurationMcpSmithyModelS3PropertyList;
        putS3(value: TargetConfigurationMcpSmithyModelS3Property[] | cdktn.IResolvable): void;
        resetS3(): void;
        get s3Input(): cdktn.IResolvable | TargetConfigurationMcpSmithyModelS3Property[] | undefined;
    }
    class SmithyModelPropertyList extends cdktn.ComplexList {
        internalValue?: SmithyModelProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SmithyModelPropertyOutputReference;
    }
    interface McpProperty {
        /**
        * api_gateway block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#api_gateway TfGatewayTarget#api_gateway}
        */
        readonly apiGateway?: ApiGatewayProperty[] | cdktn.IResolvable;
        /**
        * lambda block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#lambda TfGatewayTarget#lambda}
        */
        readonly lambda?: LambdaProperty[] | cdktn.IResolvable;
        /**
        * mcp_server block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#mcp_server TfGatewayTarget#mcp_server}
        */
        readonly mcpServer?: McpServerProperty[] | cdktn.IResolvable;
        /**
        * open_api_schema block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#open_api_schema TfGatewayTarget#open_api_schema}
        */
        readonly openApiSchema?: OpenApiSchemaProperty[] | cdktn.IResolvable;
        /**
        * smithy_model block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#smithy_model TfGatewayTarget#smithy_model}
        */
        readonly smithyModel?: SmithyModelProperty[] | cdktn.IResolvable;
    }
    class McpPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): McpProperty | cdktn.IResolvable | undefined;
        set internalValue(value: McpProperty | cdktn.IResolvable | undefined);
        private _apiGateway;
        get apiGateway(): ApiGatewayPropertyList;
        putApiGateway(value: ApiGatewayProperty[] | cdktn.IResolvable): void;
        resetApiGateway(): void;
        get apiGatewayInput(): cdktn.IResolvable | ApiGatewayProperty[] | undefined;
        private _lambda;
        get lambda(): LambdaPropertyList;
        putLambda(value: LambdaProperty[] | cdktn.IResolvable): void;
        resetLambda(): void;
        get lambdaInput(): cdktn.IResolvable | LambdaProperty[] | undefined;
        private _mcpServer;
        get mcpServer(): McpServerPropertyList;
        putMcpServer(value: McpServerProperty[] | cdktn.IResolvable): void;
        resetMcpServer(): void;
        get mcpServerInput(): cdktn.IResolvable | McpServerProperty[] | undefined;
        private _openApiSchema;
        get openApiSchema(): OpenApiSchemaPropertyList;
        putOpenApiSchema(value: OpenApiSchemaProperty[] | cdktn.IResolvable): void;
        resetOpenApiSchema(): void;
        get openApiSchemaInput(): cdktn.IResolvable | OpenApiSchemaProperty[] | undefined;
        private _smithyModel;
        get smithyModel(): SmithyModelPropertyList;
        putSmithyModel(value: SmithyModelProperty[] | cdktn.IResolvable): void;
        resetSmithyModel(): void;
        get smithyModelInput(): cdktn.IResolvable | SmithyModelProperty[] | undefined;
    }
    class McpPropertyList extends cdktn.ComplexList {
        internalValue?: McpProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): McpPropertyOutputReference;
    }
    interface TargetConfigurationProperty {
        /**
        * http block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#http TfGatewayTarget#http}
        */
        readonly http?: HttpProperty[] | cdktn.IResolvable;
        /**
        * mcp block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#mcp TfGatewayTarget#mcp}
        */
        readonly mcp?: McpProperty[] | cdktn.IResolvable;
    }
    class TargetConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetConfigurationProperty | cdktn.IResolvable | undefined);
        private _http;
        get http(): HttpPropertyList;
        putHttp(value: HttpProperty[] | cdktn.IResolvable): void;
        resetHttp(): void;
        get httpInput(): cdktn.IResolvable | HttpProperty[] | undefined;
        private _mcp;
        get mcp(): McpPropertyList;
        putMcp(value: McpProperty[] | cdktn.IResolvable): void;
        resetMcp(): void;
        get mcpInput(): cdktn.IResolvable | McpProperty[] | undefined;
    }
    class TargetConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: TargetConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetConfigurationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#create TfGatewayTarget#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#delete TfGatewayTarget#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_target#update TfGatewayTarget#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
