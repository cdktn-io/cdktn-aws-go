import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_policy#description TfPolicy#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_policy#name TfPolicy#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_policy#policy_engine_id TfPolicy#policy_engine_id}
    */
    readonly policyEngineId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_policy#region TfPolicy#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_policy#validation_mode TfPolicy#validation_mode}
    */
    readonly validationMode?: string;
    /**
    * definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_policy#definition TfPolicy#definition}
    */
    readonly definition?: TfPolicy.DefinitionProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_policy#timeouts TfPolicy#timeouts}
    */
    readonly timeouts?: TfPolicy.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_policy aws_bedrockagentcore_policy}
*/
export declare class TfPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrockagentcore_policy";
    /**
    * Generates CDKTN code for importing a TfPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfPolicy to import
    * @param importFromId The id of the existing TfPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_policy aws_bedrockagentcore_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfPolicyConfig
    */
    constructor(scope: Construct, id: string, config: TfPolicyConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get policyArn(): string;
    private _policyEngineId?;
    get policyEngineId(): string;
    set policyEngineId(value: string);
    get policyEngineIdInput(): string | undefined;
    get policyId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _validationMode?;
    get validationMode(): string;
    set validationMode(value: string);
    resetValidationMode(): void;
    get validationModeInput(): string | undefined;
    private _definition;
    get definition(): TfPolicy.DefinitionPropertyList;
    putDefinition(value: TfPolicy.DefinitionProperty[] | cdktn.IResolvable): void;
    resetDefinition(): void;
    get definitionInput(): cdktn.IResolvable | TfPolicy.DefinitionProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfPolicy.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfPolicy.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfPolicy.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfPolicyCedarPropertyToTerraform(struct?: TfPolicy.CedarProperty | cdktn.IResolvable): any;
export declare function tfPolicyCedarPropertyToHclTerraform(struct?: TfPolicy.CedarProperty | cdktn.IResolvable): any;
export declare function tfPolicyDefinitionPropertyToTerraform(struct?: TfPolicy.DefinitionProperty | cdktn.IResolvable): any;
export declare function tfPolicyDefinitionPropertyToHclTerraform(struct?: TfPolicy.DefinitionProperty | cdktn.IResolvable): any;
export declare function tfPolicyTimeoutsPropertyToTerraform(struct?: TfPolicy.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfPolicyTimeoutsPropertyToHclTerraform(struct?: TfPolicy.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfPolicy {
    interface CedarProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_policy#statement TfPolicy#statement}
        */
        readonly statement: string;
    }
    class CedarPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CedarProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CedarProperty | cdktn.IResolvable | undefined);
        private _statement?;
        get statement(): string;
        set statement(value: string);
        get statementInput(): string | undefined;
    }
    class CedarPropertyList extends cdktn.ComplexList {
        internalValue?: CedarProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CedarPropertyOutputReference;
    }
    interface DefinitionProperty {
        /**
        * cedar block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_policy#cedar TfPolicy#cedar}
        */
        readonly cedar?: CedarProperty[] | cdktn.IResolvable;
    }
    class DefinitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefinitionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefinitionProperty | cdktn.IResolvable | undefined);
        private _cedar;
        get cedar(): CedarPropertyList;
        putCedar(value: CedarProperty[] | cdktn.IResolvable): void;
        resetCedar(): void;
        get cedarInput(): cdktn.IResolvable | CedarProperty[] | undefined;
    }
    class DefinitionPropertyList extends cdktn.ComplexList {
        internalValue?: DefinitionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefinitionPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_policy#create TfPolicy#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_policy#delete TfPolicy#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_policy#update TfPolicy#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
