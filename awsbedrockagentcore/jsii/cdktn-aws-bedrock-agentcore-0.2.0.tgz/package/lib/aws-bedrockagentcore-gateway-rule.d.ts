import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfGatewayRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_rule#description TfGatewayRule#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_rule#gateway_identifier TfGatewayRule#gateway_identifier}
    */
    readonly gatewayIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_rule#priority TfGatewayRule#priority}
    */
    readonly priority: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_rule#region TfGatewayRule#region}
    */
    readonly region?: string;
    /**
    * action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_rule#action TfGatewayRule#action}
    */
    readonly action?: TfGatewayRule.ActionProperty[] | cdktn.IResolvable;
    /**
    * condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_rule#condition TfGatewayRule#condition}
    */
    readonly condition?: TfGatewayRule.ConditionProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_rule#timeouts TfGatewayRule#timeouts}
    */
    readonly timeouts?: TfGatewayRule.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_rule aws_bedrockagentcore_gateway_rule}
*/
export declare class TfGatewayRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrockagentcore_gateway_rule";
    /**
    * Generates CDKTN code for importing a TfGatewayRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfGatewayRule to import
    * @param importFromId The id of the existing TfGatewayRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfGatewayRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_rule aws_bedrockagentcore_gateway_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfGatewayRuleConfig
    */
    constructor(scope: Construct, id: string, config: TfGatewayRuleConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get gatewayArn(): string;
    private _gatewayIdentifier?;
    get gatewayIdentifier(): string;
    set gatewayIdentifier(value: string);
    get gatewayIdentifierInput(): string | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    get priorityInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get ruleId(): string;
    private _system;
    get systemAttribute(): TfGatewayRule.SystemPropertyList;
    private _action;
    get action(): TfGatewayRule.ActionPropertyList;
    putAction(value: TfGatewayRule.ActionProperty[] | cdktn.IResolvable): void;
    resetAction(): void;
    get actionInput(): cdktn.IResolvable | TfGatewayRule.ActionProperty[] | undefined;
    private _condition;
    get condition(): TfGatewayRule.ConditionPropertyList;
    putCondition(value: TfGatewayRule.ConditionProperty[] | cdktn.IResolvable): void;
    resetCondition(): void;
    get conditionInput(): cdktn.IResolvable | TfGatewayRule.ConditionProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfGatewayRule.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfGatewayRule.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfGatewayRule.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfGatewayRuleSystemPropertyToTerraform(struct?: TfGatewayRule.SystemProperty): any;
export declare function tfGatewayRuleSystemPropertyToHclTerraform(struct?: TfGatewayRule.SystemProperty): any;
export declare function tfGatewayRuleStaticOverridePropertyToTerraform(struct?: TfGatewayRule.StaticOverrideProperty | cdktn.IResolvable): any;
export declare function tfGatewayRuleStaticOverridePropertyToHclTerraform(struct?: TfGatewayRule.StaticOverrideProperty | cdktn.IResolvable): any;
export declare function tfGatewayRuleActionConfigurationBundleWeightedOverrideTrafficSplitConfigurationBundlePropertyToTerraform(struct?: TfGatewayRule.ActionConfigurationBundleWeightedOverrideTrafficSplitConfigurationBundleProperty | cdktn.IResolvable): any;
export declare function tfGatewayRuleActionConfigurationBundleWeightedOverrideTrafficSplitConfigurationBundlePropertyToHclTerraform(struct?: TfGatewayRule.ActionConfigurationBundleWeightedOverrideTrafficSplitConfigurationBundleProperty | cdktn.IResolvable): any;
export declare function tfGatewayRuleActionConfigurationBundleWeightedOverrideTrafficSplitPropertyToTerraform(struct?: TfGatewayRule.ActionConfigurationBundleWeightedOverrideTrafficSplitProperty | cdktn.IResolvable): any;
export declare function tfGatewayRuleActionConfigurationBundleWeightedOverrideTrafficSplitPropertyToHclTerraform(struct?: TfGatewayRule.ActionConfigurationBundleWeightedOverrideTrafficSplitProperty | cdktn.IResolvable): any;
export declare function tfGatewayRuleWeightedOverridePropertyToTerraform(struct?: TfGatewayRule.WeightedOverrideProperty | cdktn.IResolvable): any;
export declare function tfGatewayRuleWeightedOverridePropertyToHclTerraform(struct?: TfGatewayRule.WeightedOverrideProperty | cdktn.IResolvable): any;
export declare function tfGatewayRuleActionConfigurationBundlePropertyToTerraform(struct?: TfGatewayRule.ActionConfigurationBundleProperty | cdktn.IResolvable): any;
export declare function tfGatewayRuleActionConfigurationBundlePropertyToHclTerraform(struct?: TfGatewayRule.ActionConfigurationBundleProperty | cdktn.IResolvable): any;
export declare function tfGatewayRuleStaticRoutePropertyToTerraform(struct?: TfGatewayRule.StaticRouteProperty | cdktn.IResolvable): any;
export declare function tfGatewayRuleStaticRoutePropertyToHclTerraform(struct?: TfGatewayRule.StaticRouteProperty | cdktn.IResolvable): any;
export declare function tfGatewayRuleActionRouteToTargetWeightedRouteTrafficSplitPropertyToTerraform(struct?: TfGatewayRule.ActionRouteToTargetWeightedRouteTrafficSplitProperty | cdktn.IResolvable): any;
export declare function tfGatewayRuleActionRouteToTargetWeightedRouteTrafficSplitPropertyToHclTerraform(struct?: TfGatewayRule.ActionRouteToTargetWeightedRouteTrafficSplitProperty | cdktn.IResolvable): any;
export declare function tfGatewayRuleWeightedRoutePropertyToTerraform(struct?: TfGatewayRule.WeightedRouteProperty | cdktn.IResolvable): any;
export declare function tfGatewayRuleWeightedRoutePropertyToHclTerraform(struct?: TfGatewayRule.WeightedRouteProperty | cdktn.IResolvable): any;
export declare function tfGatewayRuleRouteToTargetPropertyToTerraform(struct?: TfGatewayRule.RouteToTargetProperty | cdktn.IResolvable): any;
export declare function tfGatewayRuleRouteToTargetPropertyToHclTerraform(struct?: TfGatewayRule.RouteToTargetProperty | cdktn.IResolvable): any;
export declare function tfGatewayRuleActionPropertyToTerraform(struct?: TfGatewayRule.ActionProperty | cdktn.IResolvable): any;
export declare function tfGatewayRuleActionPropertyToHclTerraform(struct?: TfGatewayRule.ActionProperty | cdktn.IResolvable): any;
export declare function tfGatewayRuleMatchPathsPropertyToTerraform(struct?: TfGatewayRule.MatchPathsProperty | cdktn.IResolvable): any;
export declare function tfGatewayRuleMatchPathsPropertyToHclTerraform(struct?: TfGatewayRule.MatchPathsProperty | cdktn.IResolvable): any;
export declare function tfGatewayRuleIamPrincipalPropertyToTerraform(struct?: TfGatewayRule.IamPrincipalProperty | cdktn.IResolvable): any;
export declare function tfGatewayRuleIamPrincipalPropertyToHclTerraform(struct?: TfGatewayRule.IamPrincipalProperty | cdktn.IResolvable): any;
export declare function tfGatewayRuleAnyOfPropertyToTerraform(struct?: TfGatewayRule.AnyOfProperty | cdktn.IResolvable): any;
export declare function tfGatewayRuleAnyOfPropertyToHclTerraform(struct?: TfGatewayRule.AnyOfProperty | cdktn.IResolvable): any;
export declare function tfGatewayRuleMatchPrincipalsPropertyToTerraform(struct?: TfGatewayRule.MatchPrincipalsProperty | cdktn.IResolvable): any;
export declare function tfGatewayRuleMatchPrincipalsPropertyToHclTerraform(struct?: TfGatewayRule.MatchPrincipalsProperty | cdktn.IResolvable): any;
export declare function tfGatewayRuleConditionPropertyToTerraform(struct?: TfGatewayRule.ConditionProperty | cdktn.IResolvable): any;
export declare function tfGatewayRuleConditionPropertyToHclTerraform(struct?: TfGatewayRule.ConditionProperty | cdktn.IResolvable): any;
export declare function tfGatewayRuleTimeoutsPropertyToTerraform(struct?: TfGatewayRule.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfGatewayRuleTimeoutsPropertyToHclTerraform(struct?: TfGatewayRule.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfGatewayRule {
    interface SystemProperty {
    }
    class SystemPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SystemProperty | undefined;
        set internalValue(value: SystemProperty | undefined);
        get managedBy(): string;
    }
    class SystemPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SystemPropertyOutputReference;
    }
    interface StaticOverrideProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_rule#bundle_arn TfGatewayRule#bundle_arn}
        */
        readonly bundleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_rule#bundle_version TfGatewayRule#bundle_version}
        */
        readonly bundleVersion: string;
    }
    class StaticOverridePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StaticOverrideProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StaticOverrideProperty | cdktn.IResolvable | undefined);
        private _bundleArn?;
        get bundleArn(): string;
        set bundleArn(value: string);
        get bundleArnInput(): string | undefined;
        private _bundleVersion?;
        get bundleVersion(): string;
        set bundleVersion(value: string);
        get bundleVersionInput(): string | undefined;
    }
    class StaticOverridePropertyList extends cdktn.ComplexList {
        internalValue?: StaticOverrideProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StaticOverridePropertyOutputReference;
    }
    interface ActionConfigurationBundleWeightedOverrideTrafficSplitConfigurationBundleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_rule#bundle_arn TfGatewayRule#bundle_arn}
        */
        readonly bundleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_rule#bundle_version TfGatewayRule#bundle_version}
        */
        readonly bundleVersion: string;
    }
    class ActionConfigurationBundleWeightedOverrideTrafficSplitConfigurationBundlePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ActionConfigurationBundleWeightedOverrideTrafficSplitConfigurationBundleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ActionConfigurationBundleWeightedOverrideTrafficSplitConfigurationBundleProperty | cdktn.IResolvable | undefined);
        private _bundleArn?;
        get bundleArn(): string;
        set bundleArn(value: string);
        get bundleArnInput(): string | undefined;
        private _bundleVersion?;
        get bundleVersion(): string;
        set bundleVersion(value: string);
        get bundleVersionInput(): string | undefined;
    }
    class ActionConfigurationBundleWeightedOverrideTrafficSplitConfigurationBundlePropertyList extends cdktn.ComplexList {
        internalValue?: ActionConfigurationBundleWeightedOverrideTrafficSplitConfigurationBundleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ActionConfigurationBundleWeightedOverrideTrafficSplitConfigurationBundlePropertyOutputReference;
    }
    interface ActionConfigurationBundleWeightedOverrideTrafficSplitProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_rule#description TfGatewayRule#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_rule#metadata TfGatewayRule#metadata}
        */
        readonly metadata?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_rule#name TfGatewayRule#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_rule#weight TfGatewayRule#weight}
        */
        readonly weight: number;
        /**
        * configuration_bundle block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_rule#configuration_bundle TfGatewayRule#configuration_bundle}
        */
        readonly configurationBundle?: ActionConfigurationBundleWeightedOverrideTrafficSplitConfigurationBundleProperty[] | cdktn.IResolvable;
    }
    class ActionConfigurationBundleWeightedOverrideTrafficSplitPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ActionConfigurationBundleWeightedOverrideTrafficSplitProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ActionConfigurationBundleWeightedOverrideTrafficSplitProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _metadata?;
        get metadata(): {
            [key: string]: string;
        };
        set metadata(value: {
            [key: string]: string;
        });
        resetMetadata(): void;
        get metadataInput(): {
            [key: string]: string;
        } | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _weight?;
        get weight(): number;
        set weight(value: number);
        get weightInput(): number | undefined;
        private _configurationBundle;
        get configurationBundle(): ActionConfigurationBundleWeightedOverrideTrafficSplitConfigurationBundlePropertyList;
        putConfigurationBundle(value: ActionConfigurationBundleWeightedOverrideTrafficSplitConfigurationBundleProperty[] | cdktn.IResolvable): void;
        resetConfigurationBundle(): void;
        get configurationBundleInput(): cdktn.IResolvable | ActionConfigurationBundleWeightedOverrideTrafficSplitConfigurationBundleProperty[] | undefined;
    }
    class ActionConfigurationBundleWeightedOverrideTrafficSplitPropertyList extends cdktn.ComplexList {
        internalValue?: ActionConfigurationBundleWeightedOverrideTrafficSplitProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ActionConfigurationBundleWeightedOverrideTrafficSplitPropertyOutputReference;
    }
    interface WeightedOverrideProperty {
        /**
        * traffic_split block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_rule#traffic_split TfGatewayRule#traffic_split}
        */
        readonly trafficSplit?: ActionConfigurationBundleWeightedOverrideTrafficSplitProperty[] | cdktn.IResolvable;
    }
    class WeightedOverridePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WeightedOverrideProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WeightedOverrideProperty | cdktn.IResolvable | undefined);
        private _trafficSplit;
        get trafficSplit(): ActionConfigurationBundleWeightedOverrideTrafficSplitPropertyList;
        putTrafficSplit(value: ActionConfigurationBundleWeightedOverrideTrafficSplitProperty[] | cdktn.IResolvable): void;
        resetTrafficSplit(): void;
        get trafficSplitInput(): cdktn.IResolvable | ActionConfigurationBundleWeightedOverrideTrafficSplitProperty[] | undefined;
    }
    class WeightedOverridePropertyList extends cdktn.ComplexList {
        internalValue?: WeightedOverrideProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WeightedOverridePropertyOutputReference;
    }
    interface ActionConfigurationBundleProperty {
        /**
        * static_override block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_rule#static_override TfGatewayRule#static_override}
        */
        readonly staticOverride?: StaticOverrideProperty[] | cdktn.IResolvable;
        /**
        * weighted_override block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_rule#weighted_override TfGatewayRule#weighted_override}
        */
        readonly weightedOverride?: WeightedOverrideProperty[] | cdktn.IResolvable;
    }
    class ActionConfigurationBundlePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ActionConfigurationBundleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ActionConfigurationBundleProperty | cdktn.IResolvable | undefined);
        private _staticOverride;
        get staticOverride(): StaticOverridePropertyList;
        putStaticOverride(value: StaticOverrideProperty[] | cdktn.IResolvable): void;
        resetStaticOverride(): void;
        get staticOverrideInput(): cdktn.IResolvable | StaticOverrideProperty[] | undefined;
        private _weightedOverride;
        get weightedOverride(): WeightedOverridePropertyList;
        putWeightedOverride(value: WeightedOverrideProperty[] | cdktn.IResolvable): void;
        resetWeightedOverride(): void;
        get weightedOverrideInput(): cdktn.IResolvable | WeightedOverrideProperty[] | undefined;
    }
    class ActionConfigurationBundlePropertyList extends cdktn.ComplexList {
        internalValue?: ActionConfigurationBundleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ActionConfigurationBundlePropertyOutputReference;
    }
    interface StaticRouteProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_rule#target_name TfGatewayRule#target_name}
        */
        readonly targetName: string;
    }
    class StaticRoutePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StaticRouteProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StaticRouteProperty | cdktn.IResolvable | undefined);
        private _targetName?;
        get targetName(): string;
        set targetName(value: string);
        get targetNameInput(): string | undefined;
    }
    class StaticRoutePropertyList extends cdktn.ComplexList {
        internalValue?: StaticRouteProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StaticRoutePropertyOutputReference;
    }
    interface ActionRouteToTargetWeightedRouteTrafficSplitProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_rule#description TfGatewayRule#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_rule#metadata TfGatewayRule#metadata}
        */
        readonly metadata?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_rule#name TfGatewayRule#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_rule#target_name TfGatewayRule#target_name}
        */
        readonly targetName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_rule#weight TfGatewayRule#weight}
        */
        readonly weight: number;
    }
    class ActionRouteToTargetWeightedRouteTrafficSplitPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ActionRouteToTargetWeightedRouteTrafficSplitProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ActionRouteToTargetWeightedRouteTrafficSplitProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _metadata?;
        get metadata(): {
            [key: string]: string;
        };
        set metadata(value: {
            [key: string]: string;
        });
        resetMetadata(): void;
        get metadataInput(): {
            [key: string]: string;
        } | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _targetName?;
        get targetName(): string;
        set targetName(value: string);
        get targetNameInput(): string | undefined;
        private _weight?;
        get weight(): number;
        set weight(value: number);
        get weightInput(): number | undefined;
    }
    class ActionRouteToTargetWeightedRouteTrafficSplitPropertyList extends cdktn.ComplexList {
        internalValue?: ActionRouteToTargetWeightedRouteTrafficSplitProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ActionRouteToTargetWeightedRouteTrafficSplitPropertyOutputReference;
    }
    interface WeightedRouteProperty {
        /**
        * traffic_split block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_rule#traffic_split TfGatewayRule#traffic_split}
        */
        readonly trafficSplit?: ActionRouteToTargetWeightedRouteTrafficSplitProperty[] | cdktn.IResolvable;
    }
    class WeightedRoutePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WeightedRouteProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WeightedRouteProperty | cdktn.IResolvable | undefined);
        private _trafficSplit;
        get trafficSplit(): ActionRouteToTargetWeightedRouteTrafficSplitPropertyList;
        putTrafficSplit(value: ActionRouteToTargetWeightedRouteTrafficSplitProperty[] | cdktn.IResolvable): void;
        resetTrafficSplit(): void;
        get trafficSplitInput(): cdktn.IResolvable | ActionRouteToTargetWeightedRouteTrafficSplitProperty[] | undefined;
    }
    class WeightedRoutePropertyList extends cdktn.ComplexList {
        internalValue?: WeightedRouteProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WeightedRoutePropertyOutputReference;
    }
    interface RouteToTargetProperty {
        /**
        * static_route block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_rule#static_route TfGatewayRule#static_route}
        */
        readonly staticRoute?: StaticRouteProperty[] | cdktn.IResolvable;
        /**
        * weighted_route block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_rule#weighted_route TfGatewayRule#weighted_route}
        */
        readonly weightedRoute?: WeightedRouteProperty[] | cdktn.IResolvable;
    }
    class RouteToTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RouteToTargetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RouteToTargetProperty | cdktn.IResolvable | undefined);
        private _staticRoute;
        get staticRoute(): StaticRoutePropertyList;
        putStaticRoute(value: StaticRouteProperty[] | cdktn.IResolvable): void;
        resetStaticRoute(): void;
        get staticRouteInput(): cdktn.IResolvable | StaticRouteProperty[] | undefined;
        private _weightedRoute;
        get weightedRoute(): WeightedRoutePropertyList;
        putWeightedRoute(value: WeightedRouteProperty[] | cdktn.IResolvable): void;
        resetWeightedRoute(): void;
        get weightedRouteInput(): cdktn.IResolvable | WeightedRouteProperty[] | undefined;
    }
    class RouteToTargetPropertyList extends cdktn.ComplexList {
        internalValue?: RouteToTargetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RouteToTargetPropertyOutputReference;
    }
    interface ActionProperty {
        /**
        * configuration_bundle block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_rule#configuration_bundle TfGatewayRule#configuration_bundle}
        */
        readonly configurationBundle?: ActionConfigurationBundleProperty[] | cdktn.IResolvable;
        /**
        * route_to_target block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_rule#route_to_target TfGatewayRule#route_to_target}
        */
        readonly routeToTarget?: RouteToTargetProperty[] | cdktn.IResolvable;
    }
    class ActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ActionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ActionProperty | cdktn.IResolvable | undefined);
        private _configurationBundle;
        get configurationBundle(): ActionConfigurationBundlePropertyList;
        putConfigurationBundle(value: ActionConfigurationBundleProperty[] | cdktn.IResolvable): void;
        resetConfigurationBundle(): void;
        get configurationBundleInput(): cdktn.IResolvable | ActionConfigurationBundleProperty[] | undefined;
        private _routeToTarget;
        get routeToTarget(): RouteToTargetPropertyList;
        putRouteToTarget(value: RouteToTargetProperty[] | cdktn.IResolvable): void;
        resetRouteToTarget(): void;
        get routeToTargetInput(): cdktn.IResolvable | RouteToTargetProperty[] | undefined;
    }
    class ActionPropertyList extends cdktn.ComplexList {
        internalValue?: ActionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ActionPropertyOutputReference;
    }
    interface MatchPathsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_rule#any_of TfGatewayRule#any_of}
        */
        readonly anyOf: string[];
    }
    class MatchPathsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MatchPathsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MatchPathsProperty | cdktn.IResolvable | undefined);
        private _anyOf?;
        get anyOf(): string[];
        set anyOf(value: string[]);
        get anyOfInput(): string[] | undefined;
    }
    class MatchPathsPropertyList extends cdktn.ComplexList {
        internalValue?: MatchPathsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MatchPathsPropertyOutputReference;
    }
    interface IamPrincipalProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_rule#arn TfGatewayRule#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_rule#operator TfGatewayRule#operator}
        */
        readonly operator?: string;
    }
    class IamPrincipalPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IamPrincipalProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IamPrincipalProperty | cdktn.IResolvable | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _operator?;
        get operator(): string;
        set operator(value: string);
        resetOperator(): void;
        get operatorInput(): string | undefined;
    }
    class IamPrincipalPropertyList extends cdktn.ComplexList {
        internalValue?: IamPrincipalProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IamPrincipalPropertyOutputReference;
    }
    interface AnyOfProperty {
        /**
        * iam_principal block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_rule#iam_principal TfGatewayRule#iam_principal}
        */
        readonly iamPrincipal?: IamPrincipalProperty[] | cdktn.IResolvable;
    }
    class AnyOfPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AnyOfProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AnyOfProperty | cdktn.IResolvable | undefined);
        private _iamPrincipal;
        get iamPrincipal(): IamPrincipalPropertyList;
        putIamPrincipal(value: IamPrincipalProperty[] | cdktn.IResolvable): void;
        resetIamPrincipal(): void;
        get iamPrincipalInput(): cdktn.IResolvable | IamPrincipalProperty[] | undefined;
    }
    class AnyOfPropertyList extends cdktn.ComplexList {
        internalValue?: AnyOfProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AnyOfPropertyOutputReference;
    }
    interface MatchPrincipalsProperty {
        /**
        * any_of block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_rule#any_of TfGatewayRule#any_of}
        */
        readonly anyOf?: AnyOfProperty[] | cdktn.IResolvable;
    }
    class MatchPrincipalsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MatchPrincipalsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MatchPrincipalsProperty | cdktn.IResolvable | undefined);
        private _anyOf;
        get anyOf(): AnyOfPropertyList;
        putAnyOf(value: AnyOfProperty[] | cdktn.IResolvable): void;
        resetAnyOf(): void;
        get anyOfInput(): cdktn.IResolvable | AnyOfProperty[] | undefined;
    }
    class MatchPrincipalsPropertyList extends cdktn.ComplexList {
        internalValue?: MatchPrincipalsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MatchPrincipalsPropertyOutputReference;
    }
    interface ConditionProperty {
        /**
        * match_paths block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_rule#match_paths TfGatewayRule#match_paths}
        */
        readonly matchPaths?: MatchPathsProperty[] | cdktn.IResolvable;
        /**
        * match_principals block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_rule#match_principals TfGatewayRule#match_principals}
        */
        readonly matchPrincipals?: MatchPrincipalsProperty[] | cdktn.IResolvable;
    }
    class ConditionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConditionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConditionProperty | cdktn.IResolvable | undefined);
        private _matchPaths;
        get matchPaths(): MatchPathsPropertyList;
        putMatchPaths(value: MatchPathsProperty[] | cdktn.IResolvable): void;
        resetMatchPaths(): void;
        get matchPathsInput(): cdktn.IResolvable | MatchPathsProperty[] | undefined;
        private _matchPrincipals;
        get matchPrincipals(): MatchPrincipalsPropertyList;
        putMatchPrincipals(value: MatchPrincipalsProperty[] | cdktn.IResolvable): void;
        resetMatchPrincipals(): void;
        get matchPrincipalsInput(): cdktn.IResolvable | MatchPrincipalsProperty[] | undefined;
    }
    class ConditionPropertyList extends cdktn.ComplexList {
        internalValue?: ConditionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConditionPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_rule#create TfGatewayRule#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_rule#delete TfGatewayRule#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_gateway_rule#update TfGatewayRule#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
