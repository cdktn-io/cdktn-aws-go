import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfWorkloadIdentityConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_workload_identity#allowed_resource_oauth2_return_urls TfWorkloadIdentity#allowed_resource_oauth2_return_urls}
    */
    readonly allowedResourceOauth2ReturnUrls?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_workload_identity#name TfWorkloadIdentity#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_workload_identity#region TfWorkloadIdentity#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_workload_identity aws_bedrockagentcore_workload_identity}
*/
export declare class TfWorkloadIdentity extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrockagentcore_workload_identity";
    /**
    * Generates CDKTN code for importing a TfWorkloadIdentity resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfWorkloadIdentity to import
    * @param importFromId The id of the existing TfWorkloadIdentity that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_workload_identity#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfWorkloadIdentity to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_workload_identity aws_bedrockagentcore_workload_identity} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfWorkloadIdentityConfig
    */
    constructor(scope: Construct, id: string, config: TfWorkloadIdentityConfig);
    private _allowedResourceOauth2ReturnUrls?;
    get allowedResourceOauth2ReturnUrls(): string[];
    set allowedResourceOauth2ReturnUrls(value: string[]);
    resetAllowedResourceOauth2ReturnUrls(): void;
    get allowedResourceOauth2ReturnUrlsInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get workloadIdentityArn(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
