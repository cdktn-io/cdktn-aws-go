import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfHarnessConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#allowed_tools TfHarness#allowed_tools}
    */
    readonly allowedTools?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#environment_variables TfHarness#environment_variables}
    */
    readonly environmentVariables?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#execution_role_arn TfHarness#execution_role_arn}
    */
    readonly executionRoleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#harness_name TfHarness#harness_name}
    */
    readonly harnessName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#max_iterations TfHarness#max_iterations}
    */
    readonly maxIterations?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#max_tokens TfHarness#max_tokens}
    */
    readonly maxTokens?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#region TfHarness#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#tags TfHarness#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#timeout_seconds TfHarness#timeout_seconds}
    */
    readonly timeoutSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#truncation TfHarness#truncation}
    */
    readonly truncation?: TfHarness.TruncationProperty[] | cdktn.IResolvable;
    /**
    * authorizer_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#authorizer_configuration TfHarness#authorizer_configuration}
    */
    readonly authorizerConfiguration?: TfHarness.AuthorizerConfigurationProperty[] | cdktn.IResolvable;
    /**
    * environment block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#environment TfHarness#environment}
    */
    readonly environment?: TfHarness.EnvironmentProperty[] | cdktn.IResolvable;
    /**
    * environment_artifact block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#environment_artifact TfHarness#environment_artifact}
    */
    readonly environmentArtifact?: TfHarness.EnvironmentArtifactProperty[] | cdktn.IResolvable;
    /**
    * memory block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#memory TfHarness#memory}
    */
    readonly memory?: TfHarness.MemoryProperty[] | cdktn.IResolvable;
    /**
    * model block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#model TfHarness#model}
    */
    readonly model?: TfHarness.ModelProperty[] | cdktn.IResolvable;
    /**
    * skill block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#skill TfHarness#skill}
    */
    readonly skill?: TfHarness.SkillProperty[] | cdktn.IResolvable;
    /**
    * system_prompt block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#system_prompt TfHarness#system_prompt}
    */
    readonly systemPrompt?: TfHarness.SystemPromptProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#timeouts TfHarness#timeouts}
    */
    readonly timeouts?: TfHarness.TimeoutsProperty;
    /**
    * tool block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#tool TfHarness#tool}
    */
    readonly tool?: TfHarness.ToolProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness aws_bedrockagentcore_harness}
*/
export declare class TfHarness extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrockagentcore_harness";
    /**
    * Generates CDKTN code for importing a TfHarness resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfHarness to import
    * @param importFromId The id of the existing TfHarness that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfHarness to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness aws_bedrockagentcore_harness} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfHarnessConfig
    */
    constructor(scope: Construct, id: string, config: TfHarnessConfig);
    private _allowedTools?;
    get allowedTools(): string[];
    set allowedTools(value: string[]);
    resetAllowedTools(): void;
    get allowedToolsInput(): string[] | undefined;
    get arn(): string;
    private _environmentActual;
    get environmentActual(): TfHarness.EnvironmentActualPropertyList;
    private _environmentVariables?;
    get environmentVariables(): {
        [key: string]: string;
    };
    set environmentVariables(value: {
        [key: string]: string;
    });
    resetEnvironmentVariables(): void;
    get environmentVariablesInput(): {
        [key: string]: string;
    } | undefined;
    private _executionRoleArn?;
    get executionRoleArn(): string;
    set executionRoleArn(value: string);
    get executionRoleArnInput(): string | undefined;
    get harnessId(): string;
    private _harnessName?;
    get harnessName(): string;
    set harnessName(value: string);
    get harnessNameInput(): string | undefined;
    private _maxIterations?;
    get maxIterations(): number;
    set maxIterations(value: number);
    resetMaxIterations(): void;
    get maxIterationsInput(): number | undefined;
    private _maxTokens?;
    get maxTokens(): number;
    set maxTokens(value: number);
    resetMaxTokens(): void;
    get maxTokensInput(): number | undefined;
    private _memoryActual;
    get memoryActual(): TfHarness.MemoryActualPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _timeoutSeconds?;
    get timeoutSeconds(): number;
    set timeoutSeconds(value: number);
    resetTimeoutSeconds(): void;
    get timeoutSecondsInput(): number | undefined;
    private _truncation;
    get truncation(): TfHarness.TruncationPropertyList;
    putTruncation(value: TfHarness.TruncationProperty[] | cdktn.IResolvable): void;
    resetTruncation(): void;
    get truncationInput(): cdktn.IResolvable | TfHarness.TruncationProperty[] | undefined;
    private _authorizerConfiguration;
    get authorizerConfiguration(): TfHarness.AuthorizerConfigurationPropertyList;
    putAuthorizerConfiguration(value: TfHarness.AuthorizerConfigurationProperty[] | cdktn.IResolvable): void;
    resetAuthorizerConfiguration(): void;
    get authorizerConfigurationInput(): cdktn.IResolvable | TfHarness.AuthorizerConfigurationProperty[] | undefined;
    private _environment;
    get environment(): TfHarness.EnvironmentPropertyList;
    putEnvironment(value: TfHarness.EnvironmentProperty[] | cdktn.IResolvable): void;
    resetEnvironment(): void;
    get environmentInput(): cdktn.IResolvable | TfHarness.EnvironmentProperty[] | undefined;
    private _environmentArtifact;
    get environmentArtifact(): TfHarness.EnvironmentArtifactPropertyList;
    putEnvironmentArtifact(value: TfHarness.EnvironmentArtifactProperty[] | cdktn.IResolvable): void;
    resetEnvironmentArtifact(): void;
    get environmentArtifactInput(): cdktn.IResolvable | TfHarness.EnvironmentArtifactProperty[] | undefined;
    private _memory;
    get memory(): TfHarness.MemoryPropertyList;
    putMemory(value: TfHarness.MemoryProperty[] | cdktn.IResolvable): void;
    resetMemory(): void;
    get memoryInput(): cdktn.IResolvable | TfHarness.MemoryProperty[] | undefined;
    private _model;
    get model(): TfHarness.ModelPropertyList;
    putModel(value: TfHarness.ModelProperty[] | cdktn.IResolvable): void;
    resetModel(): void;
    get modelInput(): cdktn.IResolvable | TfHarness.ModelProperty[] | undefined;
    private _skill;
    get skill(): TfHarness.SkillPropertyList;
    putSkill(value: TfHarness.SkillProperty[] | cdktn.IResolvable): void;
    resetSkill(): void;
    get skillInput(): cdktn.IResolvable | TfHarness.SkillProperty[] | undefined;
    private _systemPrompt;
    get systemPrompt(): TfHarness.SystemPromptPropertyList;
    putSystemPrompt(value: TfHarness.SystemPromptProperty[] | cdktn.IResolvable): void;
    resetSystemPrompt(): void;
    get systemPromptInput(): cdktn.IResolvable | TfHarness.SystemPromptProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfHarness.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfHarness.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfHarness.TimeoutsProperty | undefined;
    private _tool;
    get tool(): TfHarness.ToolPropertyList;
    putTool(value: TfHarness.ToolProperty[] | cdktn.IResolvable): void;
    resetTool(): void;
    get toolInput(): cdktn.IResolvable | TfHarness.ToolProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPointPropertyToTerraform(struct?: TfHarness.EnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPointProperty): any;
export declare function tfHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPointPropertyToHclTerraform(struct?: TfHarness.EnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPointProperty): any;
export declare function tfHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPointPropertyToTerraform(struct?: TfHarness.EnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPointProperty): any;
export declare function tfHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPointPropertyToHclTerraform(struct?: TfHarness.EnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPointProperty): any;
export declare function tfHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStoragePropertyToTerraform(struct?: TfHarness.EnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStorageProperty): any;
export declare function tfHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStoragePropertyToHclTerraform(struct?: TfHarness.EnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStorageProperty): any;
export declare function tfHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationPropertyToTerraform(struct?: TfHarness.EnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationProperty): any;
export declare function tfHarnessEnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationPropertyToHclTerraform(struct?: TfHarness.EnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationProperty): any;
export declare function tfHarnessEnvironmentActualAgentcoreRuntimeEnvironmentLifecycleConfigurationPropertyToTerraform(struct?: TfHarness.EnvironmentActualAgentcoreRuntimeEnvironmentLifecycleConfigurationProperty): any;
export declare function tfHarnessEnvironmentActualAgentcoreRuntimeEnvironmentLifecycleConfigurationPropertyToHclTerraform(struct?: TfHarness.EnvironmentActualAgentcoreRuntimeEnvironmentLifecycleConfigurationProperty): any;
export declare function tfHarnessEnvironmentActualAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfigPropertyToTerraform(struct?: TfHarness.EnvironmentActualAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfigProperty): any;
export declare function tfHarnessEnvironmentActualAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfigPropertyToHclTerraform(struct?: TfHarness.EnvironmentActualAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfigProperty): any;
export declare function tfHarnessEnvironmentActualAgentcoreRuntimeEnvironmentNetworkConfigurationPropertyToTerraform(struct?: TfHarness.EnvironmentActualAgentcoreRuntimeEnvironmentNetworkConfigurationProperty): any;
export declare function tfHarnessEnvironmentActualAgentcoreRuntimeEnvironmentNetworkConfigurationPropertyToHclTerraform(struct?: TfHarness.EnvironmentActualAgentcoreRuntimeEnvironmentNetworkConfigurationProperty): any;
export declare function tfHarnessEnvironmentActualAgentcoreRuntimeEnvironmentPropertyToTerraform(struct?: TfHarness.EnvironmentActualAgentcoreRuntimeEnvironmentProperty): any;
export declare function tfHarnessEnvironmentActualAgentcoreRuntimeEnvironmentPropertyToHclTerraform(struct?: TfHarness.EnvironmentActualAgentcoreRuntimeEnvironmentProperty): any;
export declare function tfHarnessEnvironmentActualPropertyToTerraform(struct?: TfHarness.EnvironmentActualProperty): any;
export declare function tfHarnessEnvironmentActualPropertyToHclTerraform(struct?: TfHarness.EnvironmentActualProperty): any;
export declare function tfHarnessMemoryActualAgentcoreMemoryConfigurationRetrievalConfigPropertyToTerraform(struct?: TfHarness.MemoryActualAgentcoreMemoryConfigurationRetrievalConfigProperty): any;
export declare function tfHarnessMemoryActualAgentcoreMemoryConfigurationRetrievalConfigPropertyToHclTerraform(struct?: TfHarness.MemoryActualAgentcoreMemoryConfigurationRetrievalConfigProperty): any;
export declare function tfHarnessMemoryActualAgentcoreMemoryConfigurationPropertyToTerraform(struct?: TfHarness.MemoryActualAgentcoreMemoryConfigurationProperty): any;
export declare function tfHarnessMemoryActualAgentcoreMemoryConfigurationPropertyToHclTerraform(struct?: TfHarness.MemoryActualAgentcoreMemoryConfigurationProperty): any;
export declare function tfHarnessMemoryActualDisabledPropertyToTerraform(struct?: TfHarness.MemoryActualDisabledProperty): any;
export declare function tfHarnessMemoryActualDisabledPropertyToHclTerraform(struct?: TfHarness.MemoryActualDisabledProperty): any;
export declare function tfHarnessMemoryActualManagedMemoryConfigurationPropertyToTerraform(struct?: TfHarness.MemoryActualManagedMemoryConfigurationProperty): any;
export declare function tfHarnessMemoryActualManagedMemoryConfigurationPropertyToHclTerraform(struct?: TfHarness.MemoryActualManagedMemoryConfigurationProperty): any;
export declare function tfHarnessMemoryActualPropertyToTerraform(struct?: TfHarness.MemoryActualProperty): any;
export declare function tfHarnessMemoryActualPropertyToHclTerraform(struct?: TfHarness.MemoryActualProperty): any;
export declare function tfHarnessSlidingWindowPropertyToTerraform(struct?: TfHarness.SlidingWindowProperty | cdktn.IResolvable): any;
export declare function tfHarnessSlidingWindowPropertyToHclTerraform(struct?: TfHarness.SlidingWindowProperty | cdktn.IResolvable): any;
export declare function tfHarnessSummarizationPropertyToTerraform(struct?: TfHarness.SummarizationProperty | cdktn.IResolvable): any;
export declare function tfHarnessSummarizationPropertyToHclTerraform(struct?: TfHarness.SummarizationProperty | cdktn.IResolvable): any;
export declare function tfHarnessTruncationConfigPropertyToTerraform(struct?: TfHarness.TruncationConfigProperty | cdktn.IResolvable): any;
export declare function tfHarnessTruncationConfigPropertyToHclTerraform(struct?: TfHarness.TruncationConfigProperty | cdktn.IResolvable): any;
export declare function tfHarnessTruncationPropertyToTerraform(struct?: TfHarness.TruncationProperty | cdktn.IResolvable): any;
export declare function tfHarnessTruncationPropertyToHclTerraform(struct?: TfHarness.TruncationProperty | cdktn.IResolvable): any;
export declare function tfHarnessHostingEnvironmentPropertyToTerraform(struct?: TfHarness.HostingEnvironmentProperty | cdktn.IResolvable): any;
export declare function tfHarnessHostingEnvironmentPropertyToHclTerraform(struct?: TfHarness.HostingEnvironmentProperty | cdktn.IResolvable): any;
export declare function tfHarnessAllowedWorkloadConfigurationPropertyToTerraform(struct?: TfHarness.AllowedWorkloadConfigurationProperty | cdktn.IResolvable): any;
export declare function tfHarnessAllowedWorkloadConfigurationPropertyToHclTerraform(struct?: TfHarness.AllowedWorkloadConfigurationProperty | cdktn.IResolvable): any;
export declare function tfHarnessClaimMatchValuePropertyToTerraform(struct?: TfHarness.ClaimMatchValueProperty | cdktn.IResolvable): any;
export declare function tfHarnessClaimMatchValuePropertyToHclTerraform(struct?: TfHarness.ClaimMatchValueProperty | cdktn.IResolvable): any;
export declare function tfHarnessAuthorizingClaimMatchValuePropertyToTerraform(struct?: TfHarness.AuthorizingClaimMatchValueProperty | cdktn.IResolvable): any;
export declare function tfHarnessAuthorizingClaimMatchValuePropertyToHclTerraform(struct?: TfHarness.AuthorizingClaimMatchValueProperty | cdktn.IResolvable): any;
export declare function tfHarnessCustomClaimPropertyToTerraform(struct?: TfHarness.CustomClaimProperty | cdktn.IResolvable): any;
export declare function tfHarnessCustomClaimPropertyToHclTerraform(struct?: TfHarness.CustomClaimProperty | cdktn.IResolvable): any;
export declare function tfHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourcePropertyToTerraform(struct?: TfHarness.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceProperty | cdktn.IResolvable): any;
export declare function tfHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourcePropertyToHclTerraform(struct?: TfHarness.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceProperty | cdktn.IResolvable): any;
export declare function tfHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourcePropertyToTerraform(struct?: TfHarness.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceProperty | cdktn.IResolvable): any;
export declare function tfHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourcePropertyToHclTerraform(struct?: TfHarness.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceProperty | cdktn.IResolvable): any;
export declare function tfHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointPropertyToTerraform(struct?: TfHarness.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointProperty | cdktn.IResolvable): any;
export declare function tfHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointPropertyToHclTerraform(struct?: TfHarness.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointProperty | cdktn.IResolvable): any;
export declare function tfHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourcePropertyToTerraform(struct?: TfHarness.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceProperty | cdktn.IResolvable): any;
export declare function tfHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourcePropertyToHclTerraform(struct?: TfHarness.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceProperty | cdktn.IResolvable): any;
export declare function tfHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourcePropertyToTerraform(struct?: TfHarness.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceProperty | cdktn.IResolvable): any;
export declare function tfHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourcePropertyToHclTerraform(struct?: TfHarness.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceProperty | cdktn.IResolvable): any;
export declare function tfHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointPropertyToTerraform(struct?: TfHarness.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointProperty | cdktn.IResolvable): any;
export declare function tfHarnessAuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointPropertyToHclTerraform(struct?: TfHarness.AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointProperty | cdktn.IResolvable): any;
export declare function tfHarnessPrivateEndpointOverridesPropertyToTerraform(struct?: TfHarness.PrivateEndpointOverridesProperty | cdktn.IResolvable): any;
export declare function tfHarnessPrivateEndpointOverridesPropertyToHclTerraform(struct?: TfHarness.PrivateEndpointOverridesProperty | cdktn.IResolvable): any;
export declare function tfHarnessCustomJwtAuthorizerPropertyToTerraform(struct?: TfHarness.CustomJwtAuthorizerProperty | cdktn.IResolvable): any;
export declare function tfHarnessCustomJwtAuthorizerPropertyToHclTerraform(struct?: TfHarness.CustomJwtAuthorizerProperty | cdktn.IResolvable): any;
export declare function tfHarnessAuthorizerConfigurationPropertyToTerraform(struct?: TfHarness.AuthorizerConfigurationProperty | cdktn.IResolvable): any;
export declare function tfHarnessAuthorizerConfigurationPropertyToHclTerraform(struct?: TfHarness.AuthorizerConfigurationProperty | cdktn.IResolvable): any;
export declare function tfHarnessEnvironmentAgentcoreRuntimeEnvironmentLifecycleConfigurationPropertyToTerraform(struct?: TfHarness.EnvironmentAgentcoreRuntimeEnvironmentLifecycleConfigurationProperty | cdktn.IResolvable): any;
export declare function tfHarnessEnvironmentAgentcoreRuntimeEnvironmentLifecycleConfigurationPropertyToHclTerraform(struct?: TfHarness.EnvironmentAgentcoreRuntimeEnvironmentLifecycleConfigurationProperty | cdktn.IResolvable): any;
export declare function tfHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPointPropertyToTerraform(struct?: TfHarness.EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPointProperty | cdktn.IResolvable): any;
export declare function tfHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPointPropertyToHclTerraform(struct?: TfHarness.EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPointProperty | cdktn.IResolvable): any;
export declare function tfHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPointPropertyToTerraform(struct?: TfHarness.EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPointProperty | cdktn.IResolvable): any;
export declare function tfHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPointPropertyToHclTerraform(struct?: TfHarness.EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPointProperty | cdktn.IResolvable): any;
export declare function tfHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStoragePropertyToTerraform(struct?: TfHarness.EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStorageProperty | cdktn.IResolvable): any;
export declare function tfHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStoragePropertyToHclTerraform(struct?: TfHarness.EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStorageProperty | cdktn.IResolvable): any;
export declare function tfHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationPropertyToTerraform(struct?: TfHarness.EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationProperty | cdktn.IResolvable): any;
export declare function tfHarnessEnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationPropertyToHclTerraform(struct?: TfHarness.EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationProperty | cdktn.IResolvable): any;
export declare function tfHarnessEnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfigPropertyToTerraform(struct?: TfHarness.EnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfigProperty | cdktn.IResolvable): any;
export declare function tfHarnessEnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfigPropertyToHclTerraform(struct?: TfHarness.EnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfigProperty | cdktn.IResolvable): any;
export declare function tfHarnessEnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationPropertyToTerraform(struct?: TfHarness.EnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationProperty | cdktn.IResolvable): any;
export declare function tfHarnessEnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationPropertyToHclTerraform(struct?: TfHarness.EnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationProperty | cdktn.IResolvable): any;
export declare function tfHarnessEnvironmentAgentcoreRuntimeEnvironmentPropertyToTerraform(struct?: TfHarness.EnvironmentAgentcoreRuntimeEnvironmentProperty | cdktn.IResolvable): any;
export declare function tfHarnessEnvironmentAgentcoreRuntimeEnvironmentPropertyToHclTerraform(struct?: TfHarness.EnvironmentAgentcoreRuntimeEnvironmentProperty | cdktn.IResolvable): any;
export declare function tfHarnessEnvironmentPropertyToTerraform(struct?: TfHarness.EnvironmentProperty | cdktn.IResolvable): any;
export declare function tfHarnessEnvironmentPropertyToHclTerraform(struct?: TfHarness.EnvironmentProperty | cdktn.IResolvable): any;
export declare function tfHarnessContainerConfigurationPropertyToTerraform(struct?: TfHarness.ContainerConfigurationProperty | cdktn.IResolvable): any;
export declare function tfHarnessContainerConfigurationPropertyToHclTerraform(struct?: TfHarness.ContainerConfigurationProperty | cdktn.IResolvable): any;
export declare function tfHarnessEnvironmentArtifactPropertyToTerraform(struct?: TfHarness.EnvironmentArtifactProperty | cdktn.IResolvable): any;
export declare function tfHarnessEnvironmentArtifactPropertyToHclTerraform(struct?: TfHarness.EnvironmentArtifactProperty | cdktn.IResolvable): any;
export declare function tfHarnessMemoryAgentcoreMemoryConfigurationRetrievalConfigPropertyToTerraform(struct?: TfHarness.MemoryAgentcoreMemoryConfigurationRetrievalConfigProperty | cdktn.IResolvable): any;
export declare function tfHarnessMemoryAgentcoreMemoryConfigurationRetrievalConfigPropertyToHclTerraform(struct?: TfHarness.MemoryAgentcoreMemoryConfigurationRetrievalConfigProperty | cdktn.IResolvable): any;
export declare function tfHarnessMemoryAgentcoreMemoryConfigurationPropertyToTerraform(struct?: TfHarness.MemoryAgentcoreMemoryConfigurationProperty | cdktn.IResolvable): any;
export declare function tfHarnessMemoryAgentcoreMemoryConfigurationPropertyToHclTerraform(struct?: TfHarness.MemoryAgentcoreMemoryConfigurationProperty | cdktn.IResolvable): any;
export declare function tfHarnessMemoryDisabledPropertyToTerraform(struct?: TfHarness.MemoryDisabledProperty | cdktn.IResolvable): any;
export declare function tfHarnessMemoryDisabledPropertyToHclTerraform(struct?: TfHarness.MemoryDisabledProperty | cdktn.IResolvable): any;
export declare function tfHarnessMemoryManagedMemoryConfigurationPropertyToTerraform(struct?: TfHarness.MemoryManagedMemoryConfigurationProperty | cdktn.IResolvable): any;
export declare function tfHarnessMemoryManagedMemoryConfigurationPropertyToHclTerraform(struct?: TfHarness.MemoryManagedMemoryConfigurationProperty | cdktn.IResolvable): any;
export declare function tfHarnessMemoryPropertyToTerraform(struct?: TfHarness.MemoryProperty | cdktn.IResolvable): any;
export declare function tfHarnessMemoryPropertyToHclTerraform(struct?: TfHarness.MemoryProperty | cdktn.IResolvable): any;
export declare function tfHarnessBedrockModelConfigPropertyToTerraform(struct?: TfHarness.BedrockModelConfigProperty | cdktn.IResolvable): any;
export declare function tfHarnessBedrockModelConfigPropertyToHclTerraform(struct?: TfHarness.BedrockModelConfigProperty | cdktn.IResolvable): any;
export declare function tfHarnessGeminiModelConfigPropertyToTerraform(struct?: TfHarness.GeminiModelConfigProperty | cdktn.IResolvable): any;
export declare function tfHarnessGeminiModelConfigPropertyToHclTerraform(struct?: TfHarness.GeminiModelConfigProperty | cdktn.IResolvable): any;
export declare function tfHarnessOpenaiModelConfigPropertyToTerraform(struct?: TfHarness.OpenaiModelConfigProperty | cdktn.IResolvable): any;
export declare function tfHarnessOpenaiModelConfigPropertyToHclTerraform(struct?: TfHarness.OpenaiModelConfigProperty | cdktn.IResolvable): any;
export declare function tfHarnessModelPropertyToTerraform(struct?: TfHarness.ModelProperty | cdktn.IResolvable): any;
export declare function tfHarnessModelPropertyToHclTerraform(struct?: TfHarness.ModelProperty | cdktn.IResolvable): any;
export declare function tfHarnessSkillPropertyToTerraform(struct?: TfHarness.SkillProperty | cdktn.IResolvable): any;
export declare function tfHarnessSkillPropertyToHclTerraform(struct?: TfHarness.SkillProperty | cdktn.IResolvable): any;
export declare function tfHarnessSystemPromptPropertyToTerraform(struct?: TfHarness.SystemPromptProperty | cdktn.IResolvable): any;
export declare function tfHarnessSystemPromptPropertyToHclTerraform(struct?: TfHarness.SystemPromptProperty | cdktn.IResolvable): any;
export declare function tfHarnessTimeoutsPropertyToTerraform(struct?: TfHarness.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfHarnessTimeoutsPropertyToHclTerraform(struct?: TfHarness.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfHarnessAgentcoreBrowserPropertyToTerraform(struct?: TfHarness.AgentcoreBrowserProperty | cdktn.IResolvable): any;
export declare function tfHarnessAgentcoreBrowserPropertyToHclTerraform(struct?: TfHarness.AgentcoreBrowserProperty | cdktn.IResolvable): any;
export declare function tfHarnessAgentcoreCodeInterpreterPropertyToTerraform(struct?: TfHarness.AgentcoreCodeInterpreterProperty | cdktn.IResolvable): any;
export declare function tfHarnessAgentcoreCodeInterpreterPropertyToHclTerraform(struct?: TfHarness.AgentcoreCodeInterpreterProperty | cdktn.IResolvable): any;
export declare function tfHarnessOauthPropertyToTerraform(struct?: TfHarness.OauthProperty | cdktn.IResolvable): any;
export declare function tfHarnessOauthPropertyToHclTerraform(struct?: TfHarness.OauthProperty | cdktn.IResolvable): any;
export declare function tfHarnessOutboundAuthPropertyToTerraform(struct?: TfHarness.OutboundAuthProperty | cdktn.IResolvable): any;
export declare function tfHarnessOutboundAuthPropertyToHclTerraform(struct?: TfHarness.OutboundAuthProperty | cdktn.IResolvable): any;
export declare function tfHarnessAgentcoreGatewayPropertyToTerraform(struct?: TfHarness.AgentcoreGatewayProperty | cdktn.IResolvable): any;
export declare function tfHarnessAgentcoreGatewayPropertyToHclTerraform(struct?: TfHarness.AgentcoreGatewayProperty | cdktn.IResolvable): any;
export declare function tfHarnessInlineFunctionPropertyToTerraform(struct?: TfHarness.InlineFunctionProperty | cdktn.IResolvable): any;
export declare function tfHarnessInlineFunctionPropertyToHclTerraform(struct?: TfHarness.InlineFunctionProperty | cdktn.IResolvable): any;
export declare function tfHarnessRemoteMcpPropertyToTerraform(struct?: TfHarness.RemoteMcpProperty | cdktn.IResolvable): any;
export declare function tfHarnessRemoteMcpPropertyToHclTerraform(struct?: TfHarness.RemoteMcpProperty | cdktn.IResolvable): any;
export declare function tfHarnessToolConfigPropertyToTerraform(struct?: TfHarness.ToolConfigProperty | cdktn.IResolvable): any;
export declare function tfHarnessToolConfigPropertyToHclTerraform(struct?: TfHarness.ToolConfigProperty | cdktn.IResolvable): any;
export declare function tfHarnessToolPropertyToTerraform(struct?: TfHarness.ToolProperty | cdktn.IResolvable): any;
export declare function tfHarnessToolPropertyToHclTerraform(struct?: TfHarness.ToolProperty | cdktn.IResolvable): any;
export declare namespace TfHarness {
    interface EnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPointProperty {
    }
    class EnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPointProperty | undefined;
        set internalValue(value: EnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPointProperty | undefined);
        get accessPointArn(): string;
        get mountPath(): string;
    }
    class EnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPointPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPointPropertyOutputReference;
    }
    interface EnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPointProperty {
    }
    class EnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPointProperty | undefined;
        set internalValue(value: EnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPointProperty | undefined);
        get accessPointArn(): string;
        get mountPath(): string;
    }
    class EnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPointPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPointPropertyOutputReference;
    }
    interface EnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStorageProperty {
    }
    class EnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStoragePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStorageProperty | undefined;
        set internalValue(value: EnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStorageProperty | undefined);
        get mountPath(): string;
    }
    class EnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStoragePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStoragePropertyOutputReference;
    }
    interface EnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationProperty {
    }
    class EnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationProperty | undefined;
        set internalValue(value: EnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationProperty | undefined);
        private _efsAccessPoint;
        get efsAccessPoint(): EnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPointPropertyList;
        private _s3FilesAccessPoint;
        get s3FilesAccessPoint(): EnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPointPropertyList;
        private _sessionStorage;
        get sessionStorage(): EnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStoragePropertyList;
    }
    class EnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationPropertyOutputReference;
    }
    interface EnvironmentActualAgentcoreRuntimeEnvironmentLifecycleConfigurationProperty {
    }
    class EnvironmentActualAgentcoreRuntimeEnvironmentLifecycleConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EnvironmentActualAgentcoreRuntimeEnvironmentLifecycleConfigurationProperty | undefined;
        set internalValue(value: EnvironmentActualAgentcoreRuntimeEnvironmentLifecycleConfigurationProperty | undefined);
        get idleRuntimeSessionTimeout(): number;
        get maxLifetime(): number;
    }
    class EnvironmentActualAgentcoreRuntimeEnvironmentLifecycleConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EnvironmentActualAgentcoreRuntimeEnvironmentLifecycleConfigurationPropertyOutputReference;
    }
    interface EnvironmentActualAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfigProperty {
    }
    class EnvironmentActualAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EnvironmentActualAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfigProperty | undefined;
        set internalValue(value: EnvironmentActualAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfigProperty | undefined);
        get requireServiceS3Endpoint(): cdktn.IResolvable;
        get securityGroups(): string[];
        get subnets(): string[];
    }
    class EnvironmentActualAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EnvironmentActualAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfigPropertyOutputReference;
    }
    interface EnvironmentActualAgentcoreRuntimeEnvironmentNetworkConfigurationProperty {
    }
    class EnvironmentActualAgentcoreRuntimeEnvironmentNetworkConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EnvironmentActualAgentcoreRuntimeEnvironmentNetworkConfigurationProperty | undefined;
        set internalValue(value: EnvironmentActualAgentcoreRuntimeEnvironmentNetworkConfigurationProperty | undefined);
        get networkMode(): string;
        private _networkModeConfig;
        get networkModeConfig(): EnvironmentActualAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfigPropertyList;
    }
    class EnvironmentActualAgentcoreRuntimeEnvironmentNetworkConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EnvironmentActualAgentcoreRuntimeEnvironmentNetworkConfigurationPropertyOutputReference;
    }
    interface EnvironmentActualAgentcoreRuntimeEnvironmentProperty {
    }
    class EnvironmentActualAgentcoreRuntimeEnvironmentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EnvironmentActualAgentcoreRuntimeEnvironmentProperty | undefined;
        set internalValue(value: EnvironmentActualAgentcoreRuntimeEnvironmentProperty | undefined);
        get agentRuntimeArn(): string;
        get agentRuntimeId(): string;
        get agentRuntimeName(): string;
        private _filesystemConfiguration;
        get filesystemConfiguration(): EnvironmentActualAgentcoreRuntimeEnvironmentFilesystemConfigurationPropertyList;
        private _lifecycleConfiguration;
        get lifecycleConfiguration(): EnvironmentActualAgentcoreRuntimeEnvironmentLifecycleConfigurationPropertyList;
        private _networkConfiguration;
        get networkConfiguration(): EnvironmentActualAgentcoreRuntimeEnvironmentNetworkConfigurationPropertyList;
    }
    class EnvironmentActualAgentcoreRuntimeEnvironmentPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EnvironmentActualAgentcoreRuntimeEnvironmentPropertyOutputReference;
    }
    interface EnvironmentActualProperty {
    }
    class EnvironmentActualPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EnvironmentActualProperty | undefined;
        set internalValue(value: EnvironmentActualProperty | undefined);
        private _agentcoreRuntimeEnvironment;
        get agentcoreRuntimeEnvironment(): EnvironmentActualAgentcoreRuntimeEnvironmentPropertyList;
    }
    class EnvironmentActualPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EnvironmentActualPropertyOutputReference;
    }
    interface MemoryActualAgentcoreMemoryConfigurationRetrievalConfigProperty {
    }
    class MemoryActualAgentcoreMemoryConfigurationRetrievalConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MemoryActualAgentcoreMemoryConfigurationRetrievalConfigProperty | undefined;
        set internalValue(value: MemoryActualAgentcoreMemoryConfigurationRetrievalConfigProperty | undefined);
        get mapBlockKey(): string;
        get relevanceScore(): number;
        get strategyId(): string;
        get topK(): number;
    }
    class MemoryActualAgentcoreMemoryConfigurationRetrievalConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MemoryActualAgentcoreMemoryConfigurationRetrievalConfigPropertyOutputReference;
    }
    interface MemoryActualAgentcoreMemoryConfigurationProperty {
    }
    class MemoryActualAgentcoreMemoryConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MemoryActualAgentcoreMemoryConfigurationProperty | undefined;
        set internalValue(value: MemoryActualAgentcoreMemoryConfigurationProperty | undefined);
        get actorId(): string;
        get arn(): string;
        get messagesCount(): number;
        private _retrievalConfig;
        get retrievalConfig(): MemoryActualAgentcoreMemoryConfigurationRetrievalConfigPropertyList;
    }
    class MemoryActualAgentcoreMemoryConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MemoryActualAgentcoreMemoryConfigurationPropertyOutputReference;
    }
    interface MemoryActualDisabledProperty {
    }
    class MemoryActualDisabledPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MemoryActualDisabledProperty | undefined;
        set internalValue(value: MemoryActualDisabledProperty | undefined);
    }
    class MemoryActualDisabledPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MemoryActualDisabledPropertyOutputReference;
    }
    interface MemoryActualManagedMemoryConfigurationProperty {
    }
    class MemoryActualManagedMemoryConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MemoryActualManagedMemoryConfigurationProperty | undefined;
        set internalValue(value: MemoryActualManagedMemoryConfigurationProperty | undefined);
        get arn(): string;
        get encryptionKeyArn(): string;
        get eventExpiryDuration(): number;
        get strategies(): string[];
    }
    class MemoryActualManagedMemoryConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MemoryActualManagedMemoryConfigurationPropertyOutputReference;
    }
    interface MemoryActualProperty {
    }
    class MemoryActualPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MemoryActualProperty | undefined;
        set internalValue(value: MemoryActualProperty | undefined);
        private _agentcoreMemoryConfiguration;
        get agentcoreMemoryConfiguration(): MemoryActualAgentcoreMemoryConfigurationPropertyList;
        private _disabled;
        get disabled(): MemoryActualDisabledPropertyList;
        private _managedMemoryConfiguration;
        get managedMemoryConfiguration(): MemoryActualManagedMemoryConfigurationPropertyList;
    }
    class MemoryActualPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MemoryActualPropertyOutputReference;
    }
    interface SlidingWindowProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#messages_count TfHarness#messages_count}
        */
        readonly messagesCount?: number;
    }
    class SlidingWindowPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SlidingWindowProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SlidingWindowProperty | cdktn.IResolvable | undefined);
        private _messagesCount?;
        get messagesCount(): number;
        set messagesCount(value: number);
        resetMessagesCount(): void;
        get messagesCountInput(): number | undefined;
    }
    class SlidingWindowPropertyList extends cdktn.ComplexList {
        internalValue?: SlidingWindowProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SlidingWindowPropertyOutputReference;
    }
    interface SummarizationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#preserve_recent_messages TfHarness#preserve_recent_messages}
        */
        readonly preserveRecentMessages?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#summarization_system_prompt TfHarness#summarization_system_prompt}
        */
        readonly summarizationSystemPrompt?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#summary_ratio TfHarness#summary_ratio}
        */
        readonly summaryRatio?: number;
    }
    class SummarizationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SummarizationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SummarizationProperty | cdktn.IResolvable | undefined);
        private _preserveRecentMessages?;
        get preserveRecentMessages(): number;
        set preserveRecentMessages(value: number);
        resetPreserveRecentMessages(): void;
        get preserveRecentMessagesInput(): number | undefined;
        private _summarizationSystemPrompt?;
        get summarizationSystemPrompt(): string;
        set summarizationSystemPrompt(value: string);
        resetSummarizationSystemPrompt(): void;
        get summarizationSystemPromptInput(): string | undefined;
        private _summaryRatio?;
        get summaryRatio(): number;
        set summaryRatio(value: number);
        resetSummaryRatio(): void;
        get summaryRatioInput(): number | undefined;
    }
    class SummarizationPropertyList extends cdktn.ComplexList {
        internalValue?: SummarizationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SummarizationPropertyOutputReference;
    }
    interface TruncationConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#sliding_window TfHarness#sliding_window}
        */
        readonly slidingWindow?: SlidingWindowProperty[] | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#summarization TfHarness#summarization}
        */
        readonly summarization?: SummarizationProperty[] | cdktn.IResolvable;
    }
    class TruncationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TruncationConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TruncationConfigProperty | cdktn.IResolvable | undefined);
        private _slidingWindow;
        get slidingWindow(): SlidingWindowPropertyList;
        putSlidingWindow(value: SlidingWindowProperty[] | cdktn.IResolvable): void;
        resetSlidingWindow(): void;
        get slidingWindowInput(): cdktn.IResolvable | SlidingWindowProperty[] | undefined;
        private _summarization;
        get summarization(): SummarizationPropertyList;
        putSummarization(value: SummarizationProperty[] | cdktn.IResolvable): void;
        resetSummarization(): void;
        get summarizationInput(): cdktn.IResolvable | SummarizationProperty[] | undefined;
    }
    class TruncationConfigPropertyList extends cdktn.ComplexList {
        internalValue?: TruncationConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TruncationConfigPropertyOutputReference;
    }
    interface TruncationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#config TfHarness#config}
        */
        readonly config?: TruncationConfigProperty[] | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#strategy TfHarness#strategy}
        */
        readonly strategy?: string;
    }
    class TruncationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TruncationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TruncationProperty | cdktn.IResolvable | undefined);
        private _config;
        get config(): TruncationConfigPropertyList;
        putConfig(value: TruncationConfigProperty[] | cdktn.IResolvable): void;
        resetConfig(): void;
        get configInput(): cdktn.IResolvable | TruncationConfigProperty[] | undefined;
        private _strategy?;
        get strategy(): string;
        set strategy(value: string);
        resetStrategy(): void;
        get strategyInput(): string | undefined;
    }
    class TruncationPropertyList extends cdktn.ComplexList {
        internalValue?: TruncationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TruncationPropertyOutputReference;
    }
    interface HostingEnvironmentProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#arn TfHarness#arn}
        */
        readonly arn: string;
    }
    class HostingEnvironmentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HostingEnvironmentProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HostingEnvironmentProperty | cdktn.IResolvable | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
    }
    class HostingEnvironmentPropertyList extends cdktn.ComplexList {
        internalValue?: HostingEnvironmentProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HostingEnvironmentPropertyOutputReference;
    }
    interface AllowedWorkloadConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#workload_identities TfHarness#workload_identities}
        */
        readonly workloadIdentities?: string[];
        /**
        * hosting_environment block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#hosting_environment TfHarness#hosting_environment}
        */
        readonly hostingEnvironment?: HostingEnvironmentProperty[] | cdktn.IResolvable;
    }
    class AllowedWorkloadConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AllowedWorkloadConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AllowedWorkloadConfigurationProperty | cdktn.IResolvable | undefined);
        private _workloadIdentities?;
        get workloadIdentities(): string[];
        set workloadIdentities(value: string[]);
        resetWorkloadIdentities(): void;
        get workloadIdentitiesInput(): string[] | undefined;
        private _hostingEnvironment;
        get hostingEnvironment(): HostingEnvironmentPropertyList;
        putHostingEnvironment(value: HostingEnvironmentProperty[] | cdktn.IResolvable): void;
        resetHostingEnvironment(): void;
        get hostingEnvironmentInput(): cdktn.IResolvable | HostingEnvironmentProperty[] | undefined;
    }
    class AllowedWorkloadConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: AllowedWorkloadConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AllowedWorkloadConfigurationPropertyOutputReference;
    }
    interface ClaimMatchValueProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#match_value_string TfHarness#match_value_string}
        */
        readonly matchValueString?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#match_value_string_list TfHarness#match_value_string_list}
        */
        readonly matchValueStringList?: string[];
    }
    class ClaimMatchValuePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ClaimMatchValueProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ClaimMatchValueProperty | cdktn.IResolvable | undefined);
        private _matchValueString?;
        get matchValueString(): string;
        set matchValueString(value: string);
        resetMatchValueString(): void;
        get matchValueStringInput(): string | undefined;
        private _matchValueStringList?;
        get matchValueStringList(): string[];
        set matchValueStringList(value: string[]);
        resetMatchValueStringList(): void;
        get matchValueStringListInput(): string[] | undefined;
    }
    class ClaimMatchValuePropertyList extends cdktn.ComplexList {
        internalValue?: ClaimMatchValueProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ClaimMatchValuePropertyOutputReference;
    }
    interface AuthorizingClaimMatchValueProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#claim_match_operator TfHarness#claim_match_operator}
        */
        readonly claimMatchOperator: string;
        /**
        * claim_match_value block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#claim_match_value TfHarness#claim_match_value}
        */
        readonly claimMatchValue?: ClaimMatchValueProperty[] | cdktn.IResolvable;
    }
    class AuthorizingClaimMatchValuePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthorizingClaimMatchValueProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthorizingClaimMatchValueProperty | cdktn.IResolvable | undefined);
        private _claimMatchOperator?;
        get claimMatchOperator(): string;
        set claimMatchOperator(value: string);
        get claimMatchOperatorInput(): string | undefined;
        private _claimMatchValue;
        get claimMatchValue(): ClaimMatchValuePropertyList;
        putClaimMatchValue(value: ClaimMatchValueProperty[] | cdktn.IResolvable): void;
        resetClaimMatchValue(): void;
        get claimMatchValueInput(): cdktn.IResolvable | ClaimMatchValueProperty[] | undefined;
    }
    class AuthorizingClaimMatchValuePropertyList extends cdktn.ComplexList {
        internalValue?: AuthorizingClaimMatchValueProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthorizingClaimMatchValuePropertyOutputReference;
    }
    interface CustomClaimProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#inbound_token_claim_name TfHarness#inbound_token_claim_name}
        */
        readonly inboundTokenClaimName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#inbound_token_claim_value_type TfHarness#inbound_token_claim_value_type}
        */
        readonly inboundTokenClaimValueType: string;
        /**
        * authorizing_claim_match_value block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#authorizing_claim_match_value TfHarness#authorizing_claim_match_value}
        */
        readonly authorizingClaimMatchValue?: AuthorizingClaimMatchValueProperty[] | cdktn.IResolvable;
    }
    class CustomClaimPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomClaimProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CustomClaimProperty | cdktn.IResolvable | undefined);
        private _inboundTokenClaimName?;
        get inboundTokenClaimName(): string;
        set inboundTokenClaimName(value: string);
        get inboundTokenClaimNameInput(): string | undefined;
        private _inboundTokenClaimValueType?;
        get inboundTokenClaimValueType(): string;
        set inboundTokenClaimValueType(value: string);
        get inboundTokenClaimValueTypeInput(): string | undefined;
        private _authorizingClaimMatchValue;
        get authorizingClaimMatchValue(): AuthorizingClaimMatchValuePropertyList;
        putAuthorizingClaimMatchValue(value: AuthorizingClaimMatchValueProperty[] | cdktn.IResolvable): void;
        resetAuthorizingClaimMatchValue(): void;
        get authorizingClaimMatchValueInput(): cdktn.IResolvable | AuthorizingClaimMatchValueProperty[] | undefined;
    }
    class CustomClaimPropertyList extends cdktn.ComplexList {
        internalValue?: CustomClaimProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomClaimPropertyOutputReference;
    }
    interface AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#endpoint_ip_address_type TfHarness#endpoint_ip_address_type}
        */
        readonly endpointIpAddressType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#routing_domain TfHarness#routing_domain}
        */
        readonly routingDomain?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#security_group_ids TfHarness#security_group_ids}
        */
        readonly securityGroupIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#subnet_ids TfHarness#subnet_ids}
        */
        readonly subnetIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#tags TfHarness#tags}
        */
        readonly tags?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#vpc_identifier TfHarness#vpc_identifier}
        */
        readonly vpcIdentifier: string;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceProperty | cdktn.IResolvable | undefined);
        private _endpointIpAddressType?;
        get endpointIpAddressType(): string;
        set endpointIpAddressType(value: string);
        get endpointIpAddressTypeInput(): string | undefined;
        private _routingDomain?;
        get routingDomain(): string;
        set routingDomain(value: string);
        resetRoutingDomain(): void;
        get routingDomainInput(): string | undefined;
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        resetSecurityGroupIds(): void;
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
        private _tags?;
        get tags(): {
            [key: string]: string;
        };
        set tags(value: {
            [key: string]: string;
        });
        resetTags(): void;
        get tagsInput(): {
            [key: string]: string;
        } | undefined;
        private _vpcIdentifier?;
        get vpcIdentifier(): string;
        set vpcIdentifier(value: string);
        get vpcIdentifierInput(): string | undefined;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourcePropertyList extends cdktn.ComplexList {
        internalValue?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourcePropertyOutputReference;
    }
    interface AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#resource_configuration_identifier TfHarness#resource_configuration_identifier}
        */
        readonly resourceConfigurationIdentifier: string;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceProperty | cdktn.IResolvable | undefined);
        private _resourceConfigurationIdentifier?;
        get resourceConfigurationIdentifier(): string;
        set resourceConfigurationIdentifier(value: string);
        get resourceConfigurationIdentifierInput(): string | undefined;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourcePropertyList extends cdktn.ComplexList {
        internalValue?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourcePropertyOutputReference;
    }
    interface AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointProperty {
        /**
        * managed_vpc_resource block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#managed_vpc_resource TfHarness#managed_vpc_resource}
        */
        readonly managedVpcResource?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceProperty[] | cdktn.IResolvable;
        /**
        * self_managed_lattice_resource block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#self_managed_lattice_resource TfHarness#self_managed_lattice_resource}
        */
        readonly selfManagedLatticeResource?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceProperty[] | cdktn.IResolvable;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointProperty | cdktn.IResolvable | undefined);
        private _managedVpcResource;
        get managedVpcResource(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourcePropertyList;
        putManagedVpcResource(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceProperty[] | cdktn.IResolvable): void;
        resetManagedVpcResource(): void;
        get managedVpcResourceInput(): cdktn.IResolvable | AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointManagedVpcResourceProperty[] | undefined;
        private _selfManagedLatticeResource;
        get selfManagedLatticeResource(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourcePropertyList;
        putSelfManagedLatticeResource(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceProperty[] | cdktn.IResolvable): void;
        resetSelfManagedLatticeResource(): void;
        get selfManagedLatticeResourceInput(): cdktn.IResolvable | AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointSelfManagedLatticeResourceProperty[] | undefined;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointPropertyList extends cdktn.ComplexList {
        internalValue?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointPropertyOutputReference;
    }
    interface AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#endpoint_ip_address_type TfHarness#endpoint_ip_address_type}
        */
        readonly endpointIpAddressType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#routing_domain TfHarness#routing_domain}
        */
        readonly routingDomain?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#security_group_ids TfHarness#security_group_ids}
        */
        readonly securityGroupIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#subnet_ids TfHarness#subnet_ids}
        */
        readonly subnetIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#tags TfHarness#tags}
        */
        readonly tags?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#vpc_identifier TfHarness#vpc_identifier}
        */
        readonly vpcIdentifier: string;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceProperty | cdktn.IResolvable | undefined);
        private _endpointIpAddressType?;
        get endpointIpAddressType(): string;
        set endpointIpAddressType(value: string);
        get endpointIpAddressTypeInput(): string | undefined;
        private _routingDomain?;
        get routingDomain(): string;
        set routingDomain(value: string);
        resetRoutingDomain(): void;
        get routingDomainInput(): string | undefined;
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        resetSecurityGroupIds(): void;
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
        private _tags?;
        get tags(): {
            [key: string]: string;
        };
        set tags(value: {
            [key: string]: string;
        });
        resetTags(): void;
        get tagsInput(): {
            [key: string]: string;
        } | undefined;
        private _vpcIdentifier?;
        get vpcIdentifier(): string;
        set vpcIdentifier(value: string);
        get vpcIdentifierInput(): string | undefined;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourcePropertyList extends cdktn.ComplexList {
        internalValue?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourcePropertyOutputReference;
    }
    interface AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#resource_configuration_identifier TfHarness#resource_configuration_identifier}
        */
        readonly resourceConfigurationIdentifier: string;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceProperty | cdktn.IResolvable | undefined);
        private _resourceConfigurationIdentifier?;
        get resourceConfigurationIdentifier(): string;
        set resourceConfigurationIdentifier(value: string);
        get resourceConfigurationIdentifierInput(): string | undefined;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourcePropertyList extends cdktn.ComplexList {
        internalValue?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourcePropertyOutputReference;
    }
    interface AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointProperty {
        /**
        * managed_vpc_resource block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#managed_vpc_resource TfHarness#managed_vpc_resource}
        */
        readonly managedVpcResource?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceProperty[] | cdktn.IResolvable;
        /**
        * self_managed_lattice_resource block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#self_managed_lattice_resource TfHarness#self_managed_lattice_resource}
        */
        readonly selfManagedLatticeResource?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceProperty[] | cdktn.IResolvable;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointProperty | cdktn.IResolvable | undefined);
        private _managedVpcResource;
        get managedVpcResource(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourcePropertyList;
        putManagedVpcResource(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceProperty[] | cdktn.IResolvable): void;
        resetManagedVpcResource(): void;
        get managedVpcResourceInput(): cdktn.IResolvable | AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointManagedVpcResourceProperty[] | undefined;
        private _selfManagedLatticeResource;
        get selfManagedLatticeResource(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourcePropertyList;
        putSelfManagedLatticeResource(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceProperty[] | cdktn.IResolvable): void;
        resetSelfManagedLatticeResource(): void;
        get selfManagedLatticeResourceInput(): cdktn.IResolvable | AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointSelfManagedLatticeResourceProperty[] | undefined;
    }
    class AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointPropertyList extends cdktn.ComplexList {
        internalValue?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointPropertyOutputReference;
    }
    interface PrivateEndpointOverridesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#domain TfHarness#domain}
        */
        readonly domain: string;
        /**
        * private_endpoint block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#private_endpoint TfHarness#private_endpoint}
        */
        readonly privateEndpoint?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointProperty[] | cdktn.IResolvable;
    }
    class PrivateEndpointOverridesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PrivateEndpointOverridesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PrivateEndpointOverridesProperty | cdktn.IResolvable | undefined);
        private _domain?;
        get domain(): string;
        set domain(value: string);
        get domainInput(): string | undefined;
        private _privateEndpoint;
        get privateEndpoint(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointPropertyList;
        putPrivateEndpoint(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointProperty[] | cdktn.IResolvable): void;
        resetPrivateEndpoint(): void;
        get privateEndpointInput(): cdktn.IResolvable | AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointOverridesPrivateEndpointProperty[] | undefined;
    }
    class PrivateEndpointOverridesPropertyList extends cdktn.ComplexList {
        internalValue?: PrivateEndpointOverridesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PrivateEndpointOverridesPropertyOutputReference;
    }
    interface CustomJwtAuthorizerProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#allowed_audience TfHarness#allowed_audience}
        */
        readonly allowedAudience?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#allowed_clients TfHarness#allowed_clients}
        */
        readonly allowedClients?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#allowed_scopes TfHarness#allowed_scopes}
        */
        readonly allowedScopes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#discovery_url TfHarness#discovery_url}
        */
        readonly discoveryUrl: string;
        /**
        * allowed_workload_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#allowed_workload_configuration TfHarness#allowed_workload_configuration}
        */
        readonly allowedWorkloadConfiguration?: AllowedWorkloadConfigurationProperty[] | cdktn.IResolvable;
        /**
        * custom_claim block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#custom_claim TfHarness#custom_claim}
        */
        readonly customClaim?: CustomClaimProperty[] | cdktn.IResolvable;
        /**
        * private_endpoint block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#private_endpoint TfHarness#private_endpoint}
        */
        readonly privateEndpoint?: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointProperty[] | cdktn.IResolvable;
        /**
        * private_endpoint_overrides block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#private_endpoint_overrides TfHarness#private_endpoint_overrides}
        */
        readonly privateEndpointOverrides?: PrivateEndpointOverridesProperty[] | cdktn.IResolvable;
    }
    class CustomJwtAuthorizerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomJwtAuthorizerProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CustomJwtAuthorizerProperty | cdktn.IResolvable | undefined);
        private _allowedAudience?;
        get allowedAudience(): string[];
        set allowedAudience(value: string[]);
        resetAllowedAudience(): void;
        get allowedAudienceInput(): string[] | undefined;
        private _allowedClients?;
        get allowedClients(): string[];
        set allowedClients(value: string[]);
        resetAllowedClients(): void;
        get allowedClientsInput(): string[] | undefined;
        private _allowedScopes?;
        get allowedScopes(): string[];
        set allowedScopes(value: string[]);
        resetAllowedScopes(): void;
        get allowedScopesInput(): string[] | undefined;
        private _discoveryUrl?;
        get discoveryUrl(): string;
        set discoveryUrl(value: string);
        get discoveryUrlInput(): string | undefined;
        private _allowedWorkloadConfiguration;
        get allowedWorkloadConfiguration(): AllowedWorkloadConfigurationPropertyList;
        putAllowedWorkloadConfiguration(value: AllowedWorkloadConfigurationProperty[] | cdktn.IResolvable): void;
        resetAllowedWorkloadConfiguration(): void;
        get allowedWorkloadConfigurationInput(): cdktn.IResolvable | AllowedWorkloadConfigurationProperty[] | undefined;
        private _customClaim;
        get customClaim(): CustomClaimPropertyList;
        putCustomClaim(value: CustomClaimProperty[] | cdktn.IResolvable): void;
        resetCustomClaim(): void;
        get customClaimInput(): cdktn.IResolvable | CustomClaimProperty[] | undefined;
        private _privateEndpoint;
        get privateEndpoint(): AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointPropertyList;
        putPrivateEndpoint(value: AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointProperty[] | cdktn.IResolvable): void;
        resetPrivateEndpoint(): void;
        get privateEndpointInput(): cdktn.IResolvable | AuthorizerConfigurationCustomJwtAuthorizerPrivateEndpointProperty[] | undefined;
        private _privateEndpointOverrides;
        get privateEndpointOverrides(): PrivateEndpointOverridesPropertyList;
        putPrivateEndpointOverrides(value: PrivateEndpointOverridesProperty[] | cdktn.IResolvable): void;
        resetPrivateEndpointOverrides(): void;
        get privateEndpointOverridesInput(): cdktn.IResolvable | PrivateEndpointOverridesProperty[] | undefined;
    }
    class CustomJwtAuthorizerPropertyList extends cdktn.ComplexList {
        internalValue?: CustomJwtAuthorizerProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomJwtAuthorizerPropertyOutputReference;
    }
    interface AuthorizerConfigurationProperty {
        /**
        * custom_jwt_authorizer block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#custom_jwt_authorizer TfHarness#custom_jwt_authorizer}
        */
        readonly customJwtAuthorizer?: CustomJwtAuthorizerProperty[] | cdktn.IResolvable;
    }
    class AuthorizerConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthorizerConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthorizerConfigurationProperty | cdktn.IResolvable | undefined);
        private _customJwtAuthorizer;
        get customJwtAuthorizer(): CustomJwtAuthorizerPropertyList;
        putCustomJwtAuthorizer(value: CustomJwtAuthorizerProperty[] | cdktn.IResolvable): void;
        resetCustomJwtAuthorizer(): void;
        get customJwtAuthorizerInput(): cdktn.IResolvable | CustomJwtAuthorizerProperty[] | undefined;
    }
    class AuthorizerConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: AuthorizerConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthorizerConfigurationPropertyOutputReference;
    }
    interface EnvironmentAgentcoreRuntimeEnvironmentLifecycleConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#idle_runtime_session_timeout TfHarness#idle_runtime_session_timeout}
        */
        readonly idleRuntimeSessionTimeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#max_lifetime TfHarness#max_lifetime}
        */
        readonly maxLifetime?: number;
    }
    class EnvironmentAgentcoreRuntimeEnvironmentLifecycleConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EnvironmentAgentcoreRuntimeEnvironmentLifecycleConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EnvironmentAgentcoreRuntimeEnvironmentLifecycleConfigurationProperty | cdktn.IResolvable | undefined);
        private _idleRuntimeSessionTimeout?;
        get idleRuntimeSessionTimeout(): number;
        set idleRuntimeSessionTimeout(value: number);
        resetIdleRuntimeSessionTimeout(): void;
        get idleRuntimeSessionTimeoutInput(): number | undefined;
        private _maxLifetime?;
        get maxLifetime(): number;
        set maxLifetime(value: number);
        resetMaxLifetime(): void;
        get maxLifetimeInput(): number | undefined;
    }
    class EnvironmentAgentcoreRuntimeEnvironmentLifecycleConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: EnvironmentAgentcoreRuntimeEnvironmentLifecycleConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EnvironmentAgentcoreRuntimeEnvironmentLifecycleConfigurationPropertyOutputReference;
    }
    interface EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPointProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#access_point_arn TfHarness#access_point_arn}
        */
        readonly accessPointArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#mount_path TfHarness#mount_path}
        */
        readonly mountPath: string;
    }
    class EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPointProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPointProperty | cdktn.IResolvable | undefined);
        private _accessPointArn?;
        get accessPointArn(): string;
        set accessPointArn(value: string);
        get accessPointArnInput(): string | undefined;
        private _mountPath?;
        get mountPath(): string;
        set mountPath(value: string);
        get mountPathInput(): string | undefined;
    }
    class EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPointPropertyList extends cdktn.ComplexList {
        internalValue?: EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPointProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPointPropertyOutputReference;
    }
    interface EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPointProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#access_point_arn TfHarness#access_point_arn}
        */
        readonly accessPointArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#mount_path TfHarness#mount_path}
        */
        readonly mountPath: string;
    }
    class EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPointProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPointProperty | cdktn.IResolvable | undefined);
        private _accessPointArn?;
        get accessPointArn(): string;
        set accessPointArn(value: string);
        get accessPointArnInput(): string | undefined;
        private _mountPath?;
        get mountPath(): string;
        set mountPath(value: string);
        get mountPathInput(): string | undefined;
    }
    class EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPointPropertyList extends cdktn.ComplexList {
        internalValue?: EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPointProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPointPropertyOutputReference;
    }
    interface EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStorageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#mount_path TfHarness#mount_path}
        */
        readonly mountPath: string;
    }
    class EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStoragePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStorageProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStorageProperty | cdktn.IResolvable | undefined);
        private _mountPath?;
        get mountPath(): string;
        set mountPath(value: string);
        get mountPathInput(): string | undefined;
    }
    class EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStoragePropertyList extends cdktn.ComplexList {
        internalValue?: EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStorageProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStoragePropertyOutputReference;
    }
    interface EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationProperty {
        /**
        * efs_access_point block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#efs_access_point TfHarness#efs_access_point}
        */
        readonly efsAccessPoint?: EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPointProperty[] | cdktn.IResolvable;
        /**
        * s3_files_access_point block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#s3_files_access_point TfHarness#s3_files_access_point}
        */
        readonly s3FilesAccessPoint?: EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPointProperty[] | cdktn.IResolvable;
        /**
        * session_storage block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#session_storage TfHarness#session_storage}
        */
        readonly sessionStorage?: EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStorageProperty[] | cdktn.IResolvable;
    }
    class EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationProperty | cdktn.IResolvable | undefined);
        private _efsAccessPoint;
        get efsAccessPoint(): EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPointPropertyList;
        putEfsAccessPoint(value: EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPointProperty[] | cdktn.IResolvable): void;
        resetEfsAccessPoint(): void;
        get efsAccessPointInput(): cdktn.IResolvable | EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationEfsAccessPointProperty[] | undefined;
        private _s3FilesAccessPoint;
        get s3FilesAccessPoint(): EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPointPropertyList;
        putS3FilesAccessPoint(value: EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPointProperty[] | cdktn.IResolvable): void;
        resetS3FilesAccessPoint(): void;
        get s3FilesAccessPointInput(): cdktn.IResolvable | EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationS3FilesAccessPointProperty[] | undefined;
        private _sessionStorage;
        get sessionStorage(): EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStoragePropertyList;
        putSessionStorage(value: EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStorageProperty[] | cdktn.IResolvable): void;
        resetSessionStorage(): void;
        get sessionStorageInput(): cdktn.IResolvable | EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationSessionStorageProperty[] | undefined;
    }
    class EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationPropertyOutputReference;
    }
    interface EnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#security_groups TfHarness#security_groups}
        */
        readonly securityGroups: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#subnets TfHarness#subnets}
        */
        readonly subnets: string[];
    }
    class EnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfigProperty | cdktn.IResolvable | undefined);
        get requireServiceS3Endpoint(): cdktn.IResolvable;
        private _securityGroups?;
        get securityGroups(): string[];
        set securityGroups(value: string[]);
        get securityGroupsInput(): string[] | undefined;
        private _subnets?;
        get subnets(): string[];
        set subnets(value: string[]);
        get subnetsInput(): string[] | undefined;
    }
    class EnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfigPropertyList extends cdktn.ComplexList {
        internalValue?: EnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfigPropertyOutputReference;
    }
    interface EnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#network_mode TfHarness#network_mode}
        */
        readonly networkMode: string;
        /**
        * network_mode_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#network_mode_config TfHarness#network_mode_config}
        */
        readonly networkModeConfig?: EnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfigProperty[] | cdktn.IResolvable;
    }
    class EnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationProperty | cdktn.IResolvable | undefined);
        private _networkMode?;
        get networkMode(): string;
        set networkMode(value: string);
        get networkModeInput(): string | undefined;
        private _networkModeConfig;
        get networkModeConfig(): EnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfigPropertyList;
        putNetworkModeConfig(value: EnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfigProperty[] | cdktn.IResolvable): void;
        resetNetworkModeConfig(): void;
        get networkModeConfigInput(): cdktn.IResolvable | EnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationNetworkModeConfigProperty[] | undefined;
    }
    class EnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: EnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationPropertyOutputReference;
    }
    interface EnvironmentAgentcoreRuntimeEnvironmentProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#lifecycle_configuration TfHarness#lifecycle_configuration}
        */
        readonly lifecycleConfiguration?: EnvironmentAgentcoreRuntimeEnvironmentLifecycleConfigurationProperty[] | cdktn.IResolvable;
        /**
        * filesystem_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#filesystem_configuration TfHarness#filesystem_configuration}
        */
        readonly filesystemConfiguration?: EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationProperty[] | cdktn.IResolvable;
        /**
        * network_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#network_configuration TfHarness#network_configuration}
        */
        readonly networkConfiguration?: EnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationProperty[] | cdktn.IResolvable;
    }
    class EnvironmentAgentcoreRuntimeEnvironmentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EnvironmentAgentcoreRuntimeEnvironmentProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EnvironmentAgentcoreRuntimeEnvironmentProperty | cdktn.IResolvable | undefined);
        get agentRuntimeArn(): string;
        get agentRuntimeId(): string;
        get agentRuntimeName(): string;
        private _lifecycleConfiguration;
        get lifecycleConfiguration(): EnvironmentAgentcoreRuntimeEnvironmentLifecycleConfigurationPropertyList;
        putLifecycleConfiguration(value: EnvironmentAgentcoreRuntimeEnvironmentLifecycleConfigurationProperty[] | cdktn.IResolvable): void;
        resetLifecycleConfiguration(): void;
        get lifecycleConfigurationInput(): cdktn.IResolvable | EnvironmentAgentcoreRuntimeEnvironmentLifecycleConfigurationProperty[] | undefined;
        private _filesystemConfiguration;
        get filesystemConfiguration(): EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationPropertyList;
        putFilesystemConfiguration(value: EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationProperty[] | cdktn.IResolvable): void;
        resetFilesystemConfiguration(): void;
        get filesystemConfigurationInput(): cdktn.IResolvable | EnvironmentAgentcoreRuntimeEnvironmentFilesystemConfigurationProperty[] | undefined;
        private _networkConfiguration;
        get networkConfiguration(): EnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationPropertyList;
        putNetworkConfiguration(value: EnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationProperty[] | cdktn.IResolvable): void;
        resetNetworkConfiguration(): void;
        get networkConfigurationInput(): cdktn.IResolvable | EnvironmentAgentcoreRuntimeEnvironmentNetworkConfigurationProperty[] | undefined;
    }
    class EnvironmentAgentcoreRuntimeEnvironmentPropertyList extends cdktn.ComplexList {
        internalValue?: EnvironmentAgentcoreRuntimeEnvironmentProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EnvironmentAgentcoreRuntimeEnvironmentPropertyOutputReference;
    }
    interface EnvironmentProperty {
        /**
        * agentcore_runtime_environment block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#agentcore_runtime_environment TfHarness#agentcore_runtime_environment}
        */
        readonly agentcoreRuntimeEnvironment?: EnvironmentAgentcoreRuntimeEnvironmentProperty[] | cdktn.IResolvable;
    }
    class EnvironmentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EnvironmentProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EnvironmentProperty | cdktn.IResolvable | undefined);
        private _agentcoreRuntimeEnvironment;
        get agentcoreRuntimeEnvironment(): EnvironmentAgentcoreRuntimeEnvironmentPropertyList;
        putAgentcoreRuntimeEnvironment(value: EnvironmentAgentcoreRuntimeEnvironmentProperty[] | cdktn.IResolvable): void;
        resetAgentcoreRuntimeEnvironment(): void;
        get agentcoreRuntimeEnvironmentInput(): cdktn.IResolvable | EnvironmentAgentcoreRuntimeEnvironmentProperty[] | undefined;
    }
    class EnvironmentPropertyList extends cdktn.ComplexList {
        internalValue?: EnvironmentProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EnvironmentPropertyOutputReference;
    }
    interface ContainerConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#container_uri TfHarness#container_uri}
        */
        readonly containerUri: string;
    }
    class ContainerConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ContainerConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ContainerConfigurationProperty | cdktn.IResolvable | undefined);
        private _containerUri?;
        get containerUri(): string;
        set containerUri(value: string);
        get containerUriInput(): string | undefined;
    }
    class ContainerConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ContainerConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ContainerConfigurationPropertyOutputReference;
    }
    interface EnvironmentArtifactProperty {
        /**
        * container_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#container_configuration TfHarness#container_configuration}
        */
        readonly containerConfiguration?: ContainerConfigurationProperty[] | cdktn.IResolvable;
    }
    class EnvironmentArtifactPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EnvironmentArtifactProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EnvironmentArtifactProperty | cdktn.IResolvable | undefined);
        private _containerConfiguration;
        get containerConfiguration(): ContainerConfigurationPropertyList;
        putContainerConfiguration(value: ContainerConfigurationProperty[] | cdktn.IResolvable): void;
        resetContainerConfiguration(): void;
        get containerConfigurationInput(): cdktn.IResolvable | ContainerConfigurationProperty[] | undefined;
    }
    class EnvironmentArtifactPropertyList extends cdktn.ComplexList {
        internalValue?: EnvironmentArtifactProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EnvironmentArtifactPropertyOutputReference;
    }
    interface MemoryAgentcoreMemoryConfigurationRetrievalConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#map_block_key TfHarness#map_block_key}
        */
        readonly mapBlockKey: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#relevance_score TfHarness#relevance_score}
        */
        readonly relevanceScore?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#strategy_id TfHarness#strategy_id}
        */
        readonly strategyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#top_k TfHarness#top_k}
        */
        readonly topK?: number;
    }
    class MemoryAgentcoreMemoryConfigurationRetrievalConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MemoryAgentcoreMemoryConfigurationRetrievalConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MemoryAgentcoreMemoryConfigurationRetrievalConfigProperty | cdktn.IResolvable | undefined);
        private _mapBlockKey?;
        get mapBlockKey(): string;
        set mapBlockKey(value: string);
        get mapBlockKeyInput(): string | undefined;
        private _relevanceScore?;
        get relevanceScore(): number;
        set relevanceScore(value: number);
        resetRelevanceScore(): void;
        get relevanceScoreInput(): number | undefined;
        private _strategyId?;
        get strategyId(): string;
        set strategyId(value: string);
        resetStrategyId(): void;
        get strategyIdInput(): string | undefined;
        private _topK?;
        get topK(): number;
        set topK(value: number);
        resetTopK(): void;
        get topKInput(): number | undefined;
    }
    class MemoryAgentcoreMemoryConfigurationRetrievalConfigPropertyList extends cdktn.ComplexList {
        internalValue?: MemoryAgentcoreMemoryConfigurationRetrievalConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MemoryAgentcoreMemoryConfigurationRetrievalConfigPropertyOutputReference;
    }
    interface MemoryAgentcoreMemoryConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#actor_id TfHarness#actor_id}
        */
        readonly actorId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#arn TfHarness#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#messages_count TfHarness#messages_count}
        */
        readonly messagesCount?: number;
        /**
        * retrieval_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#retrieval_config TfHarness#retrieval_config}
        */
        readonly retrievalConfig?: MemoryAgentcoreMemoryConfigurationRetrievalConfigProperty[] | cdktn.IResolvable;
    }
    class MemoryAgentcoreMemoryConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MemoryAgentcoreMemoryConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MemoryAgentcoreMemoryConfigurationProperty | cdktn.IResolvable | undefined);
        private _actorId?;
        get actorId(): string;
        set actorId(value: string);
        resetActorId(): void;
        get actorIdInput(): string | undefined;
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _messagesCount?;
        get messagesCount(): number;
        set messagesCount(value: number);
        resetMessagesCount(): void;
        get messagesCountInput(): number | undefined;
        private _retrievalConfig;
        get retrievalConfig(): MemoryAgentcoreMemoryConfigurationRetrievalConfigPropertyList;
        putRetrievalConfig(value: MemoryAgentcoreMemoryConfigurationRetrievalConfigProperty[] | cdktn.IResolvable): void;
        resetRetrievalConfig(): void;
        get retrievalConfigInput(): cdktn.IResolvable | MemoryAgentcoreMemoryConfigurationRetrievalConfigProperty[] | undefined;
    }
    class MemoryAgentcoreMemoryConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: MemoryAgentcoreMemoryConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MemoryAgentcoreMemoryConfigurationPropertyOutputReference;
    }
    interface MemoryDisabledProperty {
    }
    class MemoryDisabledPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MemoryDisabledProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MemoryDisabledProperty | cdktn.IResolvable | undefined);
    }
    class MemoryDisabledPropertyList extends cdktn.ComplexList {
        internalValue?: MemoryDisabledProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MemoryDisabledPropertyOutputReference;
    }
    interface MemoryManagedMemoryConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#encryption_key_arn TfHarness#encryption_key_arn}
        */
        readonly encryptionKeyArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#event_expiry_duration TfHarness#event_expiry_duration}
        */
        readonly eventExpiryDuration?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#strategies TfHarness#strategies}
        */
        readonly strategies?: string[];
    }
    class MemoryManagedMemoryConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MemoryManagedMemoryConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MemoryManagedMemoryConfigurationProperty | cdktn.IResolvable | undefined);
        get arn(): string;
        private _encryptionKeyArn?;
        get encryptionKeyArn(): string;
        set encryptionKeyArn(value: string);
        resetEncryptionKeyArn(): void;
        get encryptionKeyArnInput(): string | undefined;
        private _eventExpiryDuration?;
        get eventExpiryDuration(): number;
        set eventExpiryDuration(value: number);
        resetEventExpiryDuration(): void;
        get eventExpiryDurationInput(): number | undefined;
        private _strategies?;
        get strategies(): string[];
        set strategies(value: string[]);
        resetStrategies(): void;
        get strategiesInput(): string[] | undefined;
    }
    class MemoryManagedMemoryConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: MemoryManagedMemoryConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MemoryManagedMemoryConfigurationPropertyOutputReference;
    }
    interface MemoryProperty {
        /**
        * agentcore_memory_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#agentcore_memory_configuration TfHarness#agentcore_memory_configuration}
        */
        readonly agentcoreMemoryConfiguration?: MemoryAgentcoreMemoryConfigurationProperty[] | cdktn.IResolvable;
        /**
        * disabled block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#disabled TfHarness#disabled}
        */
        readonly disabled?: MemoryDisabledProperty[] | cdktn.IResolvable;
        /**
        * managed_memory_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#managed_memory_configuration TfHarness#managed_memory_configuration}
        */
        readonly managedMemoryConfiguration?: MemoryManagedMemoryConfigurationProperty[] | cdktn.IResolvable;
    }
    class MemoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MemoryProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MemoryProperty | cdktn.IResolvable | undefined);
        private _agentcoreMemoryConfiguration;
        get agentcoreMemoryConfiguration(): MemoryAgentcoreMemoryConfigurationPropertyList;
        putAgentcoreMemoryConfiguration(value: MemoryAgentcoreMemoryConfigurationProperty[] | cdktn.IResolvable): void;
        resetAgentcoreMemoryConfiguration(): void;
        get agentcoreMemoryConfigurationInput(): cdktn.IResolvable | MemoryAgentcoreMemoryConfigurationProperty[] | undefined;
        private _disabled;
        get disabled(): MemoryDisabledPropertyList;
        putDisabled(value: MemoryDisabledProperty[] | cdktn.IResolvable): void;
        resetDisabled(): void;
        get disabledInput(): cdktn.IResolvable | MemoryDisabledProperty[] | undefined;
        private _managedMemoryConfiguration;
        get managedMemoryConfiguration(): MemoryManagedMemoryConfigurationPropertyList;
        putManagedMemoryConfiguration(value: MemoryManagedMemoryConfigurationProperty[] | cdktn.IResolvable): void;
        resetManagedMemoryConfiguration(): void;
        get managedMemoryConfigurationInput(): cdktn.IResolvable | MemoryManagedMemoryConfigurationProperty[] | undefined;
    }
    class MemoryPropertyList extends cdktn.ComplexList {
        internalValue?: MemoryProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MemoryPropertyOutputReference;
    }
    interface BedrockModelConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#max_tokens TfHarness#max_tokens}
        */
        readonly maxTokens?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#model_id TfHarness#model_id}
        */
        readonly modelId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#temperature TfHarness#temperature}
        */
        readonly temperature?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#top_p TfHarness#top_p}
        */
        readonly topP?: number;
    }
    class BedrockModelConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BedrockModelConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: BedrockModelConfigProperty | cdktn.IResolvable | undefined);
        private _maxTokens?;
        get maxTokens(): number;
        set maxTokens(value: number);
        resetMaxTokens(): void;
        get maxTokensInput(): number | undefined;
        private _modelId?;
        get modelId(): string;
        set modelId(value: string);
        get modelIdInput(): string | undefined;
        private _temperature?;
        get temperature(): number;
        set temperature(value: number);
        resetTemperature(): void;
        get temperatureInput(): number | undefined;
        private _topP?;
        get topP(): number;
        set topP(value: number);
        resetTopP(): void;
        get topPInput(): number | undefined;
    }
    class BedrockModelConfigPropertyList extends cdktn.ComplexList {
        internalValue?: BedrockModelConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BedrockModelConfigPropertyOutputReference;
    }
    interface GeminiModelConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#api_key_arn TfHarness#api_key_arn}
        */
        readonly apiKeyArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#max_tokens TfHarness#max_tokens}
        */
        readonly maxTokens?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#model_id TfHarness#model_id}
        */
        readonly modelId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#temperature TfHarness#temperature}
        */
        readonly temperature?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#top_k TfHarness#top_k}
        */
        readonly topK?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#top_p TfHarness#top_p}
        */
        readonly topP?: number;
    }
    class GeminiModelConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GeminiModelConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: GeminiModelConfigProperty | cdktn.IResolvable | undefined);
        private _apiKeyArn?;
        get apiKeyArn(): string;
        set apiKeyArn(value: string);
        get apiKeyArnInput(): string | undefined;
        private _maxTokens?;
        get maxTokens(): number;
        set maxTokens(value: number);
        resetMaxTokens(): void;
        get maxTokensInput(): number | undefined;
        private _modelId?;
        get modelId(): string;
        set modelId(value: string);
        get modelIdInput(): string | undefined;
        private _temperature?;
        get temperature(): number;
        set temperature(value: number);
        resetTemperature(): void;
        get temperatureInput(): number | undefined;
        private _topK?;
        get topK(): number;
        set topK(value: number);
        resetTopK(): void;
        get topKInput(): number | undefined;
        private _topP?;
        get topP(): number;
        set topP(value: number);
        resetTopP(): void;
        get topPInput(): number | undefined;
    }
    class GeminiModelConfigPropertyList extends cdktn.ComplexList {
        internalValue?: GeminiModelConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GeminiModelConfigPropertyOutputReference;
    }
    interface OpenaiModelConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#api_key_arn TfHarness#api_key_arn}
        */
        readonly apiKeyArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#max_tokens TfHarness#max_tokens}
        */
        readonly maxTokens?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#model_id TfHarness#model_id}
        */
        readonly modelId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#temperature TfHarness#temperature}
        */
        readonly temperature?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#top_p TfHarness#top_p}
        */
        readonly topP?: number;
    }
    class OpenaiModelConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OpenaiModelConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OpenaiModelConfigProperty | cdktn.IResolvable | undefined);
        private _apiKeyArn?;
        get apiKeyArn(): string;
        set apiKeyArn(value: string);
        get apiKeyArnInput(): string | undefined;
        private _maxTokens?;
        get maxTokens(): number;
        set maxTokens(value: number);
        resetMaxTokens(): void;
        get maxTokensInput(): number | undefined;
        private _modelId?;
        get modelId(): string;
        set modelId(value: string);
        get modelIdInput(): string | undefined;
        private _temperature?;
        get temperature(): number;
        set temperature(value: number);
        resetTemperature(): void;
        get temperatureInput(): number | undefined;
        private _topP?;
        get topP(): number;
        set topP(value: number);
        resetTopP(): void;
        get topPInput(): number | undefined;
    }
    class OpenaiModelConfigPropertyList extends cdktn.ComplexList {
        internalValue?: OpenaiModelConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OpenaiModelConfigPropertyOutputReference;
    }
    interface ModelProperty {
        /**
        * bedrock_model_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#bedrock_model_config TfHarness#bedrock_model_config}
        */
        readonly bedrockModelConfig?: BedrockModelConfigProperty[] | cdktn.IResolvable;
        /**
        * gemini_model_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#gemini_model_config TfHarness#gemini_model_config}
        */
        readonly geminiModelConfig?: GeminiModelConfigProperty[] | cdktn.IResolvable;
        /**
        * openai_model_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#openai_model_config TfHarness#openai_model_config}
        */
        readonly openaiModelConfig?: OpenaiModelConfigProperty[] | cdktn.IResolvable;
    }
    class ModelPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ModelProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ModelProperty | cdktn.IResolvable | undefined);
        private _bedrockModelConfig;
        get bedrockModelConfig(): BedrockModelConfigPropertyList;
        putBedrockModelConfig(value: BedrockModelConfigProperty[] | cdktn.IResolvable): void;
        resetBedrockModelConfig(): void;
        get bedrockModelConfigInput(): cdktn.IResolvable | BedrockModelConfigProperty[] | undefined;
        private _geminiModelConfig;
        get geminiModelConfig(): GeminiModelConfigPropertyList;
        putGeminiModelConfig(value: GeminiModelConfigProperty[] | cdktn.IResolvable): void;
        resetGeminiModelConfig(): void;
        get geminiModelConfigInput(): cdktn.IResolvable | GeminiModelConfigProperty[] | undefined;
        private _openaiModelConfig;
        get openaiModelConfig(): OpenaiModelConfigPropertyList;
        putOpenaiModelConfig(value: OpenaiModelConfigProperty[] | cdktn.IResolvable): void;
        resetOpenaiModelConfig(): void;
        get openaiModelConfigInput(): cdktn.IResolvable | OpenaiModelConfigProperty[] | undefined;
    }
    class ModelPropertyList extends cdktn.ComplexList {
        internalValue?: ModelProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ModelPropertyOutputReference;
    }
    interface SkillProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#path TfHarness#path}
        */
        readonly path: string;
    }
    class SkillPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SkillProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SkillProperty | cdktn.IResolvable | undefined);
        private _path?;
        get path(): string;
        set path(value: string);
        get pathInput(): string | undefined;
    }
    class SkillPropertyList extends cdktn.ComplexList {
        internalValue?: SkillProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SkillPropertyOutputReference;
    }
    interface SystemPromptProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#text TfHarness#text}
        */
        readonly text: string;
    }
    class SystemPromptPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SystemPromptProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SystemPromptProperty | cdktn.IResolvable | undefined);
        private _text?;
        get text(): string;
        set text(value: string);
        get textInput(): string | undefined;
    }
    class SystemPromptPropertyList extends cdktn.ComplexList {
        internalValue?: SystemPromptProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SystemPromptPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#create TfHarness#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#delete TfHarness#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#update TfHarness#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface AgentcoreBrowserProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#browser_arn TfHarness#browser_arn}
        */
        readonly browserArn?: string;
    }
    class AgentcoreBrowserPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AgentcoreBrowserProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AgentcoreBrowserProperty | cdktn.IResolvable | undefined);
        private _browserArn?;
        get browserArn(): string;
        set browserArn(value: string);
        resetBrowserArn(): void;
        get browserArnInput(): string | undefined;
    }
    class AgentcoreBrowserPropertyList extends cdktn.ComplexList {
        internalValue?: AgentcoreBrowserProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AgentcoreBrowserPropertyOutputReference;
    }
    interface AgentcoreCodeInterpreterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#code_interpreter_arn TfHarness#code_interpreter_arn}
        */
        readonly codeInterpreterArn?: string;
    }
    class AgentcoreCodeInterpreterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AgentcoreCodeInterpreterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AgentcoreCodeInterpreterProperty | cdktn.IResolvable | undefined);
        private _codeInterpreterArn?;
        get codeInterpreterArn(): string;
        set codeInterpreterArn(value: string);
        resetCodeInterpreterArn(): void;
        get codeInterpreterArnInput(): string | undefined;
    }
    class AgentcoreCodeInterpreterPropertyList extends cdktn.ComplexList {
        internalValue?: AgentcoreCodeInterpreterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AgentcoreCodeInterpreterPropertyOutputReference;
    }
    interface OauthProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#custom_parameters TfHarness#custom_parameters}
        */
        readonly customParameters?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#default_return_url TfHarness#default_return_url}
        */
        readonly defaultReturnUrl?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#grant_type TfHarness#grant_type}
        */
        readonly grantType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#provider_arn TfHarness#provider_arn}
        */
        readonly providerArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#scopes TfHarness#scopes}
        */
        readonly scopes: string[];
    }
    class OauthPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OauthProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OauthProperty | cdktn.IResolvable | undefined);
        private _customParameters?;
        get customParameters(): {
            [key: string]: string;
        };
        set customParameters(value: {
            [key: string]: string;
        });
        resetCustomParameters(): void;
        get customParametersInput(): {
            [key: string]: string;
        } | undefined;
        private _defaultReturnUrl?;
        get defaultReturnUrl(): string;
        set defaultReturnUrl(value: string);
        resetDefaultReturnUrl(): void;
        get defaultReturnUrlInput(): string | undefined;
        private _grantType?;
        get grantType(): string;
        set grantType(value: string);
        resetGrantType(): void;
        get grantTypeInput(): string | undefined;
        private _providerArn?;
        get providerArn(): string;
        set providerArn(value: string);
        get providerArnInput(): string | undefined;
        private _scopes?;
        get scopes(): string[];
        set scopes(value: string[]);
        get scopesInput(): string[] | undefined;
    }
    class OauthPropertyList extends cdktn.ComplexList {
        internalValue?: OauthProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OauthPropertyOutputReference;
    }
    interface OutboundAuthProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#aws_iam TfHarness#aws_iam}
        */
        readonly awsIam?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#none TfHarness#none}
        */
        readonly none?: boolean | cdktn.IResolvable;
        /**
        * oauth block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#oauth TfHarness#oauth}
        */
        readonly oauth?: OauthProperty[] | cdktn.IResolvable;
    }
    class OutboundAuthPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OutboundAuthProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OutboundAuthProperty | cdktn.IResolvable | undefined);
        private _awsIam?;
        get awsIam(): boolean | cdktn.IResolvable;
        set awsIam(value: boolean | cdktn.IResolvable);
        resetAwsIam(): void;
        get awsIamInput(): boolean | cdktn.IResolvable | undefined;
        private _none?;
        get none(): boolean | cdktn.IResolvable;
        set none(value: boolean | cdktn.IResolvable);
        resetNone(): void;
        get noneInput(): boolean | cdktn.IResolvable | undefined;
        private _oauth;
        get oauth(): OauthPropertyList;
        putOauth(value: OauthProperty[] | cdktn.IResolvable): void;
        resetOauth(): void;
        get oauthInput(): cdktn.IResolvable | OauthProperty[] | undefined;
    }
    class OutboundAuthPropertyList extends cdktn.ComplexList {
        internalValue?: OutboundAuthProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OutboundAuthPropertyOutputReference;
    }
    interface AgentcoreGatewayProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#gateway_arn TfHarness#gateway_arn}
        */
        readonly gatewayArn: string;
        /**
        * outbound_auth block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#outbound_auth TfHarness#outbound_auth}
        */
        readonly outboundAuth?: OutboundAuthProperty[] | cdktn.IResolvable;
    }
    class AgentcoreGatewayPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AgentcoreGatewayProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AgentcoreGatewayProperty | cdktn.IResolvable | undefined);
        private _gatewayArn?;
        get gatewayArn(): string;
        set gatewayArn(value: string);
        get gatewayArnInput(): string | undefined;
        private _outboundAuth;
        get outboundAuth(): OutboundAuthPropertyList;
        putOutboundAuth(value: OutboundAuthProperty[] | cdktn.IResolvable): void;
        resetOutboundAuth(): void;
        get outboundAuthInput(): cdktn.IResolvable | OutboundAuthProperty[] | undefined;
    }
    class AgentcoreGatewayPropertyList extends cdktn.ComplexList {
        internalValue?: AgentcoreGatewayProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AgentcoreGatewayPropertyOutputReference;
    }
    interface InlineFunctionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#description TfHarness#description}
        */
        readonly description: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#input_schema TfHarness#input_schema}
        */
        readonly inputSchema: string;
    }
    class InlineFunctionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InlineFunctionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InlineFunctionProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        get descriptionInput(): string | undefined;
        private _inputSchema?;
        get inputSchema(): string;
        set inputSchema(value: string);
        get inputSchemaInput(): string | undefined;
    }
    class InlineFunctionPropertyList extends cdktn.ComplexList {
        internalValue?: InlineFunctionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InlineFunctionPropertyOutputReference;
    }
    interface RemoteMcpProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#headers TfHarness#headers}
        */
        readonly headers?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#url TfHarness#url}
        */
        readonly url: string;
    }
    class RemoteMcpPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RemoteMcpProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RemoteMcpProperty | cdktn.IResolvable | undefined);
        private _headers?;
        get headers(): {
            [key: string]: string;
        };
        set headers(value: {
            [key: string]: string;
        });
        resetHeaders(): void;
        get headersInput(): {
            [key: string]: string;
        } | undefined;
        private _url?;
        get url(): string;
        set url(value: string);
        get urlInput(): string | undefined;
    }
    class RemoteMcpPropertyList extends cdktn.ComplexList {
        internalValue?: RemoteMcpProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RemoteMcpPropertyOutputReference;
    }
    interface ToolConfigProperty {
        /**
        * agentcore_browser block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#agentcore_browser TfHarness#agentcore_browser}
        */
        readonly agentcoreBrowser?: AgentcoreBrowserProperty[] | cdktn.IResolvable;
        /**
        * agentcore_code_interpreter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#agentcore_code_interpreter TfHarness#agentcore_code_interpreter}
        */
        readonly agentcoreCodeInterpreter?: AgentcoreCodeInterpreterProperty[] | cdktn.IResolvable;
        /**
        * agentcore_gateway block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#agentcore_gateway TfHarness#agentcore_gateway}
        */
        readonly agentcoreGateway?: AgentcoreGatewayProperty[] | cdktn.IResolvable;
        /**
        * inline_function block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#inline_function TfHarness#inline_function}
        */
        readonly inlineFunction?: InlineFunctionProperty[] | cdktn.IResolvable;
        /**
        * remote_mcp block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#remote_mcp TfHarness#remote_mcp}
        */
        readonly remoteMcp?: RemoteMcpProperty[] | cdktn.IResolvable;
    }
    class ToolConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ToolConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ToolConfigProperty | cdktn.IResolvable | undefined);
        private _agentcoreBrowser;
        get agentcoreBrowser(): AgentcoreBrowserPropertyList;
        putAgentcoreBrowser(value: AgentcoreBrowserProperty[] | cdktn.IResolvable): void;
        resetAgentcoreBrowser(): void;
        get agentcoreBrowserInput(): cdktn.IResolvable | AgentcoreBrowserProperty[] | undefined;
        private _agentcoreCodeInterpreter;
        get agentcoreCodeInterpreter(): AgentcoreCodeInterpreterPropertyList;
        putAgentcoreCodeInterpreter(value: AgentcoreCodeInterpreterProperty[] | cdktn.IResolvable): void;
        resetAgentcoreCodeInterpreter(): void;
        get agentcoreCodeInterpreterInput(): cdktn.IResolvable | AgentcoreCodeInterpreterProperty[] | undefined;
        private _agentcoreGateway;
        get agentcoreGateway(): AgentcoreGatewayPropertyList;
        putAgentcoreGateway(value: AgentcoreGatewayProperty[] | cdktn.IResolvable): void;
        resetAgentcoreGateway(): void;
        get agentcoreGatewayInput(): cdktn.IResolvable | AgentcoreGatewayProperty[] | undefined;
        private _inlineFunction;
        get inlineFunction(): InlineFunctionPropertyList;
        putInlineFunction(value: InlineFunctionProperty[] | cdktn.IResolvable): void;
        resetInlineFunction(): void;
        get inlineFunctionInput(): cdktn.IResolvable | InlineFunctionProperty[] | undefined;
        private _remoteMcp;
        get remoteMcp(): RemoteMcpPropertyList;
        putRemoteMcp(value: RemoteMcpProperty[] | cdktn.IResolvable): void;
        resetRemoteMcp(): void;
        get remoteMcpInput(): cdktn.IResolvable | RemoteMcpProperty[] | undefined;
    }
    class ToolConfigPropertyList extends cdktn.ComplexList {
        internalValue?: ToolConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ToolConfigPropertyOutputReference;
    }
    interface ToolProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#name TfHarness#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#type TfHarness#type}
        */
        readonly type: string;
        /**
        * config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrockagentcore_harness#config TfHarness#config}
        */
        readonly config?: ToolConfigProperty[] | cdktn.IResolvable;
    }
    class ToolPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ToolProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ToolProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _config;
        get config(): ToolConfigPropertyList;
        putConfig(value: ToolConfigProperty[] | cdktn.IResolvable): void;
        resetConfig(): void;
        get configInput(): cdktn.IResolvable | ToolConfigProperty[] | undefined;
    }
    class ToolPropertyList extends cdktn.ComplexList {
        internalValue?: ToolProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ToolPropertyOutputReference;
    }
}
