import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsInvoicingInvoiceUnitConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/invoicing_invoice_unit#description AwsInvoicingInvoiceUnit#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/invoicing_invoice_unit#invoice_receiver AwsInvoicingInvoiceUnit#invoice_receiver}
    */
    readonly invoiceReceiver: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/invoicing_invoice_unit#name AwsInvoicingInvoiceUnit#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/invoicing_invoice_unit#region AwsInvoicingInvoiceUnit#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/invoicing_invoice_unit#tags AwsInvoicingInvoiceUnit#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/invoicing_invoice_unit#tax_inheritance_disabled AwsInvoicingInvoiceUnit#tax_inheritance_disabled}
    */
    readonly taxInheritanceDisabled?: boolean | cdktn.IResolvable;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/invoicing_invoice_unit#rule AwsInvoicingInvoiceUnit#rule}
    */
    readonly rule?: AwsInvoicingInvoiceUnit.RuleProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/invoicing_invoice_unit#timeouts AwsInvoicingInvoiceUnit#timeouts}
    */
    readonly timeouts?: AwsInvoicingInvoiceUnit.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/invoicing_invoice_unit aws_invoicing_invoice_unit}
*/
export declare class AwsInvoicingInvoiceUnit extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_invoicing_invoice_unit";
    /**
    * Generates CDKTN code for importing a AwsInvoicingInvoiceUnit resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsInvoicingInvoiceUnit to import
    * @param importFromId The id of the existing AwsInvoicingInvoiceUnit that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/invoicing_invoice_unit#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsInvoicingInvoiceUnit to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/invoicing_invoice_unit aws_invoicing_invoice_unit} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsInvoicingInvoiceUnitConfig
    */
    constructor(scope: Construct, id: string, config: AwsInvoicingInvoiceUnitConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _invoiceReceiver?;
    get invoiceReceiver(): string;
    set invoiceReceiver(value: string);
    get invoiceReceiverInput(): string | undefined;
    get lastModified(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _taxInheritanceDisabled?;
    get taxInheritanceDisabled(): boolean | cdktn.IResolvable;
    set taxInheritanceDisabled(value: boolean | cdktn.IResolvable);
    resetTaxInheritanceDisabled(): void;
    get taxInheritanceDisabledInput(): boolean | cdktn.IResolvable | undefined;
    private _rule;
    get rule(): AwsInvoicingInvoiceUnit.RulePropertyList;
    putRule(value: AwsInvoicingInvoiceUnit.RuleProperty[] | cdktn.IResolvable): void;
    resetRule(): void;
    get ruleInput(): cdktn.IResolvable | AwsInvoicingInvoiceUnit.RuleProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsInvoicingInvoiceUnit.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsInvoicingInvoiceUnit.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsInvoicingInvoiceUnit.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsInvoicingInvoiceUnitRulePropertyToTerraform(struct?: AwsInvoicingInvoiceUnit.RuleProperty | cdktn.IResolvable): any;
export declare function awsInvoicingInvoiceUnitRulePropertyToHclTerraform(struct?: AwsInvoicingInvoiceUnit.RuleProperty | cdktn.IResolvable): any;
export declare function awsInvoicingInvoiceUnitTimeoutsPropertyToTerraform(struct?: AwsInvoicingInvoiceUnit.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsInvoicingInvoiceUnitTimeoutsPropertyToHclTerraform(struct?: AwsInvoicingInvoiceUnit.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsInvoicingInvoiceUnit {
    interface RuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/invoicing_invoice_unit#linked_accounts AwsInvoicingInvoiceUnit#linked_accounts}
        */
        readonly linkedAccounts: string[];
    }
    class RulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleProperty | cdktn.IResolvable | undefined);
        private _linkedAccounts?;
        get linkedAccounts(): string[];
        set linkedAccounts(value: string[]);
        get linkedAccountsInput(): string[] | undefined;
    }
    class RulePropertyList extends cdktn.ComplexList {
        internalValue?: RuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulePropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/invoicing_invoice_unit#create AwsInvoicingInvoiceUnit#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/invoicing_invoice_unit#delete AwsInvoicingInvoiceUnit#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/invoicing_invoice_unit#update AwsInvoicingInvoiceUnit#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
