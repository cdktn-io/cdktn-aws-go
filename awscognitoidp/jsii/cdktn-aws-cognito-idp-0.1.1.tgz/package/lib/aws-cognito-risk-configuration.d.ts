import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsCognitoRiskConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_risk_configuration#client_id AwsCognitoRiskConfiguration#client_id}
    */
    readonly clientId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_risk_configuration#id AwsCognitoRiskConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_risk_configuration#region AwsCognitoRiskConfiguration#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_risk_configuration#user_pool_id AwsCognitoRiskConfiguration#user_pool_id}
    */
    readonly userPoolId: string;
    /**
    * account_takeover_risk_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_risk_configuration#account_takeover_risk_configuration AwsCognitoRiskConfiguration#account_takeover_risk_configuration}
    */
    readonly accountTakeoverRiskConfiguration?: AwsCognitoRiskConfiguration.AccountTakeoverRiskConfigurationProperty;
    /**
    * compromised_credentials_risk_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_risk_configuration#compromised_credentials_risk_configuration AwsCognitoRiskConfiguration#compromised_credentials_risk_configuration}
    */
    readonly compromisedCredentialsRiskConfiguration?: AwsCognitoRiskConfiguration.CompromisedCredentialsRiskConfigurationProperty;
    /**
    * risk_exception_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_risk_configuration#risk_exception_configuration AwsCognitoRiskConfiguration#risk_exception_configuration}
    */
    readonly riskExceptionConfiguration?: AwsCognitoRiskConfiguration.RiskExceptionConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_risk_configuration aws_cognito_risk_configuration}
*/
export declare class AwsCognitoRiskConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cognito_risk_configuration";
    /**
    * Generates CDKTN code for importing a AwsCognitoRiskConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCognitoRiskConfiguration to import
    * @param importFromId The id of the existing AwsCognitoRiskConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_risk_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCognitoRiskConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_risk_configuration aws_cognito_risk_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsCognitoRiskConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsCognitoRiskConfigurationConfig);
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    resetClientId(): void;
    get clientIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _userPoolId?;
    get userPoolId(): string;
    set userPoolId(value: string);
    get userPoolIdInput(): string | undefined;
    private _accountTakeoverRiskConfiguration;
    get accountTakeoverRiskConfiguration(): AwsCognitoRiskConfiguration.AccountTakeoverRiskConfigurationPropertyOutputReference;
    putAccountTakeoverRiskConfiguration(value: AwsCognitoRiskConfiguration.AccountTakeoverRiskConfigurationProperty): void;
    resetAccountTakeoverRiskConfiguration(): void;
    get accountTakeoverRiskConfigurationInput(): AwsCognitoRiskConfiguration.AccountTakeoverRiskConfigurationProperty | undefined;
    private _compromisedCredentialsRiskConfiguration;
    get compromisedCredentialsRiskConfiguration(): AwsCognitoRiskConfiguration.CompromisedCredentialsRiskConfigurationPropertyOutputReference;
    putCompromisedCredentialsRiskConfiguration(value: AwsCognitoRiskConfiguration.CompromisedCredentialsRiskConfigurationProperty): void;
    resetCompromisedCredentialsRiskConfiguration(): void;
    get compromisedCredentialsRiskConfigurationInput(): AwsCognitoRiskConfiguration.CompromisedCredentialsRiskConfigurationProperty | undefined;
    private _riskExceptionConfiguration;
    get riskExceptionConfiguration(): AwsCognitoRiskConfiguration.RiskExceptionConfigurationPropertyOutputReference;
    putRiskExceptionConfiguration(value: AwsCognitoRiskConfiguration.RiskExceptionConfigurationProperty): void;
    resetRiskExceptionConfiguration(): void;
    get riskExceptionConfigurationInput(): AwsCognitoRiskConfiguration.RiskExceptionConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsCognitoRiskConfigurationHighActionPropertyToTerraform(struct?: AwsCognitoRiskConfiguration.HighActionPropertyOutputReference | AwsCognitoRiskConfiguration.HighActionProperty): any;
export declare function awsCognitoRiskConfigurationHighActionPropertyToHclTerraform(struct?: AwsCognitoRiskConfiguration.HighActionPropertyOutputReference | AwsCognitoRiskConfiguration.HighActionProperty): any;
export declare function awsCognitoRiskConfigurationLowActionPropertyToTerraform(struct?: AwsCognitoRiskConfiguration.LowActionPropertyOutputReference | AwsCognitoRiskConfiguration.LowActionProperty): any;
export declare function awsCognitoRiskConfigurationLowActionPropertyToHclTerraform(struct?: AwsCognitoRiskConfiguration.LowActionPropertyOutputReference | AwsCognitoRiskConfiguration.LowActionProperty): any;
export declare function awsCognitoRiskConfigurationMediumActionPropertyToTerraform(struct?: AwsCognitoRiskConfiguration.MediumActionPropertyOutputReference | AwsCognitoRiskConfiguration.MediumActionProperty): any;
export declare function awsCognitoRiskConfigurationMediumActionPropertyToHclTerraform(struct?: AwsCognitoRiskConfiguration.MediumActionPropertyOutputReference | AwsCognitoRiskConfiguration.MediumActionProperty): any;
export declare function awsCognitoRiskConfigurationAccountTakeoverRiskConfigurationActionsPropertyToTerraform(struct?: AwsCognitoRiskConfiguration.AccountTakeoverRiskConfigurationActionsPropertyOutputReference | AwsCognitoRiskConfiguration.AccountTakeoverRiskConfigurationActionsProperty): any;
export declare function awsCognitoRiskConfigurationAccountTakeoverRiskConfigurationActionsPropertyToHclTerraform(struct?: AwsCognitoRiskConfiguration.AccountTakeoverRiskConfigurationActionsPropertyOutputReference | AwsCognitoRiskConfiguration.AccountTakeoverRiskConfigurationActionsProperty): any;
export declare function awsCognitoRiskConfigurationBlockEmailPropertyToTerraform(struct?: AwsCognitoRiskConfiguration.BlockEmailPropertyOutputReference | AwsCognitoRiskConfiguration.BlockEmailProperty): any;
export declare function awsCognitoRiskConfigurationBlockEmailPropertyToHclTerraform(struct?: AwsCognitoRiskConfiguration.BlockEmailPropertyOutputReference | AwsCognitoRiskConfiguration.BlockEmailProperty): any;
export declare function awsCognitoRiskConfigurationMfaEmailPropertyToTerraform(struct?: AwsCognitoRiskConfiguration.MfaEmailPropertyOutputReference | AwsCognitoRiskConfiguration.MfaEmailProperty): any;
export declare function awsCognitoRiskConfigurationMfaEmailPropertyToHclTerraform(struct?: AwsCognitoRiskConfiguration.MfaEmailPropertyOutputReference | AwsCognitoRiskConfiguration.MfaEmailProperty): any;
export declare function awsCognitoRiskConfigurationNoActionEmailPropertyToTerraform(struct?: AwsCognitoRiskConfiguration.NoActionEmailPropertyOutputReference | AwsCognitoRiskConfiguration.NoActionEmailProperty): any;
export declare function awsCognitoRiskConfigurationNoActionEmailPropertyToHclTerraform(struct?: AwsCognitoRiskConfiguration.NoActionEmailPropertyOutputReference | AwsCognitoRiskConfiguration.NoActionEmailProperty): any;
export declare function awsCognitoRiskConfigurationNotifyConfigurationPropertyToTerraform(struct?: AwsCognitoRiskConfiguration.NotifyConfigurationPropertyOutputReference | AwsCognitoRiskConfiguration.NotifyConfigurationProperty): any;
export declare function awsCognitoRiskConfigurationNotifyConfigurationPropertyToHclTerraform(struct?: AwsCognitoRiskConfiguration.NotifyConfigurationPropertyOutputReference | AwsCognitoRiskConfiguration.NotifyConfigurationProperty): any;
export declare function awsCognitoRiskConfigurationAccountTakeoverRiskConfigurationPropertyToTerraform(struct?: AwsCognitoRiskConfiguration.AccountTakeoverRiskConfigurationPropertyOutputReference | AwsCognitoRiskConfiguration.AccountTakeoverRiskConfigurationProperty): any;
export declare function awsCognitoRiskConfigurationAccountTakeoverRiskConfigurationPropertyToHclTerraform(struct?: AwsCognitoRiskConfiguration.AccountTakeoverRiskConfigurationPropertyOutputReference | AwsCognitoRiskConfiguration.AccountTakeoverRiskConfigurationProperty): any;
export declare function awsCognitoRiskConfigurationCompromisedCredentialsRiskConfigurationActionsPropertyToTerraform(struct?: AwsCognitoRiskConfiguration.CompromisedCredentialsRiskConfigurationActionsPropertyOutputReference | AwsCognitoRiskConfiguration.CompromisedCredentialsRiskConfigurationActionsProperty): any;
export declare function awsCognitoRiskConfigurationCompromisedCredentialsRiskConfigurationActionsPropertyToHclTerraform(struct?: AwsCognitoRiskConfiguration.CompromisedCredentialsRiskConfigurationActionsPropertyOutputReference | AwsCognitoRiskConfiguration.CompromisedCredentialsRiskConfigurationActionsProperty): any;
export declare function awsCognitoRiskConfigurationCompromisedCredentialsRiskConfigurationPropertyToTerraform(struct?: AwsCognitoRiskConfiguration.CompromisedCredentialsRiskConfigurationPropertyOutputReference | AwsCognitoRiskConfiguration.CompromisedCredentialsRiskConfigurationProperty): any;
export declare function awsCognitoRiskConfigurationCompromisedCredentialsRiskConfigurationPropertyToHclTerraform(struct?: AwsCognitoRiskConfiguration.CompromisedCredentialsRiskConfigurationPropertyOutputReference | AwsCognitoRiskConfiguration.CompromisedCredentialsRiskConfigurationProperty): any;
export declare function awsCognitoRiskConfigurationRiskExceptionConfigurationPropertyToTerraform(struct?: AwsCognitoRiskConfiguration.RiskExceptionConfigurationPropertyOutputReference | AwsCognitoRiskConfiguration.RiskExceptionConfigurationProperty): any;
export declare function awsCognitoRiskConfigurationRiskExceptionConfigurationPropertyToHclTerraform(struct?: AwsCognitoRiskConfiguration.RiskExceptionConfigurationPropertyOutputReference | AwsCognitoRiskConfiguration.RiskExceptionConfigurationProperty): any;
export declare namespace AwsCognitoRiskConfiguration {
    interface HighActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_risk_configuration#event_action AwsCognitoRiskConfiguration#event_action}
        */
        readonly eventAction: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_risk_configuration#notify AwsCognitoRiskConfiguration#notify}
        */
        readonly notify: boolean | cdktn.IResolvable;
    }
    class HighActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HighActionProperty | undefined;
        set internalValue(value: HighActionProperty | undefined);
        private _eventAction?;
        get eventAction(): string;
        set eventAction(value: string);
        get eventActionInput(): string | undefined;
        private _notify?;
        get notify(): boolean | cdktn.IResolvable;
        set notify(value: boolean | cdktn.IResolvable);
        get notifyInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface LowActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_risk_configuration#event_action AwsCognitoRiskConfiguration#event_action}
        */
        readonly eventAction: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_risk_configuration#notify AwsCognitoRiskConfiguration#notify}
        */
        readonly notify: boolean | cdktn.IResolvable;
    }
    class LowActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LowActionProperty | undefined;
        set internalValue(value: LowActionProperty | undefined);
        private _eventAction?;
        get eventAction(): string;
        set eventAction(value: string);
        get eventActionInput(): string | undefined;
        private _notify?;
        get notify(): boolean | cdktn.IResolvable;
        set notify(value: boolean | cdktn.IResolvable);
        get notifyInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface MediumActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_risk_configuration#event_action AwsCognitoRiskConfiguration#event_action}
        */
        readonly eventAction: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_risk_configuration#notify AwsCognitoRiskConfiguration#notify}
        */
        readonly notify: boolean | cdktn.IResolvable;
    }
    class MediumActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MediumActionProperty | undefined;
        set internalValue(value: MediumActionProperty | undefined);
        private _eventAction?;
        get eventAction(): string;
        set eventAction(value: string);
        get eventActionInput(): string | undefined;
        private _notify?;
        get notify(): boolean | cdktn.IResolvable;
        set notify(value: boolean | cdktn.IResolvable);
        get notifyInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface AccountTakeoverRiskConfigurationActionsProperty {
        /**
        * high_action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_risk_configuration#high_action AwsCognitoRiskConfiguration#high_action}
        */
        readonly highAction?: HighActionProperty;
        /**
        * low_action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_risk_configuration#low_action AwsCognitoRiskConfiguration#low_action}
        */
        readonly lowAction?: LowActionProperty;
        /**
        * medium_action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_risk_configuration#medium_action AwsCognitoRiskConfiguration#medium_action}
        */
        readonly mediumAction?: MediumActionProperty;
    }
    class AccountTakeoverRiskConfigurationActionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AccountTakeoverRiskConfigurationActionsProperty | undefined;
        set internalValue(value: AccountTakeoverRiskConfigurationActionsProperty | undefined);
        private _highAction;
        get highAction(): HighActionPropertyOutputReference;
        putHighAction(value: HighActionProperty): void;
        resetHighAction(): void;
        get highActionInput(): HighActionProperty | undefined;
        private _lowAction;
        get lowAction(): LowActionPropertyOutputReference;
        putLowAction(value: LowActionProperty): void;
        resetLowAction(): void;
        get lowActionInput(): LowActionProperty | undefined;
        private _mediumAction;
        get mediumAction(): MediumActionPropertyOutputReference;
        putMediumAction(value: MediumActionProperty): void;
        resetMediumAction(): void;
        get mediumActionInput(): MediumActionProperty | undefined;
    }
    interface BlockEmailProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_risk_configuration#html_body AwsCognitoRiskConfiguration#html_body}
        */
        readonly htmlBody: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_risk_configuration#subject AwsCognitoRiskConfiguration#subject}
        */
        readonly subject: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_risk_configuration#text_body AwsCognitoRiskConfiguration#text_body}
        */
        readonly textBody: string;
    }
    class BlockEmailPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BlockEmailProperty | undefined;
        set internalValue(value: BlockEmailProperty | undefined);
        private _htmlBody?;
        get htmlBody(): string;
        set htmlBody(value: string);
        get htmlBodyInput(): string | undefined;
        private _subject?;
        get subject(): string;
        set subject(value: string);
        get subjectInput(): string | undefined;
        private _textBody?;
        get textBody(): string;
        set textBody(value: string);
        get textBodyInput(): string | undefined;
    }
    interface MfaEmailProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_risk_configuration#html_body AwsCognitoRiskConfiguration#html_body}
        */
        readonly htmlBody: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_risk_configuration#subject AwsCognitoRiskConfiguration#subject}
        */
        readonly subject: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_risk_configuration#text_body AwsCognitoRiskConfiguration#text_body}
        */
        readonly textBody: string;
    }
    class MfaEmailPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MfaEmailProperty | undefined;
        set internalValue(value: MfaEmailProperty | undefined);
        private _htmlBody?;
        get htmlBody(): string;
        set htmlBody(value: string);
        get htmlBodyInput(): string | undefined;
        private _subject?;
        get subject(): string;
        set subject(value: string);
        get subjectInput(): string | undefined;
        private _textBody?;
        get textBody(): string;
        set textBody(value: string);
        get textBodyInput(): string | undefined;
    }
    interface NoActionEmailProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_risk_configuration#html_body AwsCognitoRiskConfiguration#html_body}
        */
        readonly htmlBody: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_risk_configuration#subject AwsCognitoRiskConfiguration#subject}
        */
        readonly subject: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_risk_configuration#text_body AwsCognitoRiskConfiguration#text_body}
        */
        readonly textBody: string;
    }
    class NoActionEmailPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NoActionEmailProperty | undefined;
        set internalValue(value: NoActionEmailProperty | undefined);
        private _htmlBody?;
        get htmlBody(): string;
        set htmlBody(value: string);
        get htmlBodyInput(): string | undefined;
        private _subject?;
        get subject(): string;
        set subject(value: string);
        get subjectInput(): string | undefined;
        private _textBody?;
        get textBody(): string;
        set textBody(value: string);
        get textBodyInput(): string | undefined;
    }
    interface NotifyConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_risk_configuration#from AwsCognitoRiskConfiguration#from}
        */
        readonly from?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_risk_configuration#reply_to AwsCognitoRiskConfiguration#reply_to}
        */
        readonly replyTo?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_risk_configuration#source_arn AwsCognitoRiskConfiguration#source_arn}
        */
        readonly sourceArn: string;
        /**
        * block_email block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_risk_configuration#block_email AwsCognitoRiskConfiguration#block_email}
        */
        readonly blockEmail?: BlockEmailProperty;
        /**
        * mfa_email block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_risk_configuration#mfa_email AwsCognitoRiskConfiguration#mfa_email}
        */
        readonly mfaEmail?: MfaEmailProperty;
        /**
        * no_action_email block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_risk_configuration#no_action_email AwsCognitoRiskConfiguration#no_action_email}
        */
        readonly noActionEmail?: NoActionEmailProperty;
    }
    class NotifyConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NotifyConfigurationProperty | undefined;
        set internalValue(value: NotifyConfigurationProperty | undefined);
        private _from?;
        get from(): string;
        set from(value: string);
        resetFrom(): void;
        get fromInput(): string | undefined;
        private _replyTo?;
        get replyTo(): string;
        set replyTo(value: string);
        resetReplyTo(): void;
        get replyToInput(): string | undefined;
        private _sourceArn?;
        get sourceArn(): string;
        set sourceArn(value: string);
        get sourceArnInput(): string | undefined;
        private _blockEmail;
        get blockEmail(): BlockEmailPropertyOutputReference;
        putBlockEmail(value: BlockEmailProperty): void;
        resetBlockEmail(): void;
        get blockEmailInput(): BlockEmailProperty | undefined;
        private _mfaEmail;
        get mfaEmail(): MfaEmailPropertyOutputReference;
        putMfaEmail(value: MfaEmailProperty): void;
        resetMfaEmail(): void;
        get mfaEmailInput(): MfaEmailProperty | undefined;
        private _noActionEmail;
        get noActionEmail(): NoActionEmailPropertyOutputReference;
        putNoActionEmail(value: NoActionEmailProperty): void;
        resetNoActionEmail(): void;
        get noActionEmailInput(): NoActionEmailProperty | undefined;
    }
    interface AccountTakeoverRiskConfigurationProperty {
        /**
        * actions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_risk_configuration#actions AwsCognitoRiskConfiguration#actions}
        */
        readonly actions: AccountTakeoverRiskConfigurationActionsProperty;
        /**
        * notify_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_risk_configuration#notify_configuration AwsCognitoRiskConfiguration#notify_configuration}
        */
        readonly notifyConfiguration?: NotifyConfigurationProperty;
    }
    class AccountTakeoverRiskConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AccountTakeoverRiskConfigurationProperty | undefined;
        set internalValue(value: AccountTakeoverRiskConfigurationProperty | undefined);
        private _actions;
        get actions(): AccountTakeoverRiskConfigurationActionsPropertyOutputReference;
        putActions(value: AccountTakeoverRiskConfigurationActionsProperty): void;
        get actionsInput(): AccountTakeoverRiskConfigurationActionsProperty | undefined;
        private _notifyConfiguration;
        get notifyConfiguration(): NotifyConfigurationPropertyOutputReference;
        putNotifyConfiguration(value: NotifyConfigurationProperty): void;
        resetNotifyConfiguration(): void;
        get notifyConfigurationInput(): NotifyConfigurationProperty | undefined;
    }
    interface CompromisedCredentialsRiskConfigurationActionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_risk_configuration#event_action AwsCognitoRiskConfiguration#event_action}
        */
        readonly eventAction: string;
    }
    class CompromisedCredentialsRiskConfigurationActionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CompromisedCredentialsRiskConfigurationActionsProperty | undefined;
        set internalValue(value: CompromisedCredentialsRiskConfigurationActionsProperty | undefined);
        private _eventAction?;
        get eventAction(): string;
        set eventAction(value: string);
        get eventActionInput(): string | undefined;
    }
    interface CompromisedCredentialsRiskConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_risk_configuration#event_filter AwsCognitoRiskConfiguration#event_filter}
        */
        readonly eventFilter?: string[];
        /**
        * actions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_risk_configuration#actions AwsCognitoRiskConfiguration#actions}
        */
        readonly actions: CompromisedCredentialsRiskConfigurationActionsProperty;
    }
    class CompromisedCredentialsRiskConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CompromisedCredentialsRiskConfigurationProperty | undefined;
        set internalValue(value: CompromisedCredentialsRiskConfigurationProperty | undefined);
        private _eventFilter?;
        get eventFilter(): string[];
        set eventFilter(value: string[]);
        resetEventFilter(): void;
        get eventFilterInput(): string[] | undefined;
        private _actions;
        get actions(): CompromisedCredentialsRiskConfigurationActionsPropertyOutputReference;
        putActions(value: CompromisedCredentialsRiskConfigurationActionsProperty): void;
        get actionsInput(): CompromisedCredentialsRiskConfigurationActionsProperty | undefined;
    }
    interface RiskExceptionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_risk_configuration#blocked_ip_range_list AwsCognitoRiskConfiguration#blocked_ip_range_list}
        */
        readonly blockedIpRangeList?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_risk_configuration#skipped_ip_range_list AwsCognitoRiskConfiguration#skipped_ip_range_list}
        */
        readonly skippedIpRangeList?: string[];
    }
    class RiskExceptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RiskExceptionConfigurationProperty | undefined;
        set internalValue(value: RiskExceptionConfigurationProperty | undefined);
        private _blockedIpRangeList?;
        get blockedIpRangeList(): string[];
        set blockedIpRangeList(value: string[]);
        resetBlockedIpRangeList(): void;
        get blockedIpRangeListInput(): string[] | undefined;
        private _skippedIpRangeList?;
        get skippedIpRangeList(): string[];
        set skippedIpRangeList(value: string[]);
        resetSkippedIpRangeList(): void;
        get skippedIpRangeListInput(): string[] | undefined;
    }
}
