import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsCognitoUserPoolConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cognito_user_pool#region DataAwsCognitoUserPool#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cognito_user_pool#user_pool_id DataAwsCognitoUserPool#user_pool_id}
    */
    readonly userPoolId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cognito_user_pool aws_cognito_user_pool}
*/
export declare class DataAwsCognitoUserPool extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_cognito_user_pool";
    /**
    * Generates CDKTN code for importing a DataAwsCognitoUserPool resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsCognitoUserPool to import
    * @param importFromId The id of the existing DataAwsCognitoUserPool that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cognito_user_pool#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsCognitoUserPool to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cognito_user_pool aws_cognito_user_pool} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsCognitoUserPoolConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsCognitoUserPoolConfig);
    private _accountRecoverySetting;
    get accountRecoverySetting(): DataAwsCognitoUserPool.AccountRecoverySettingPropertyList;
    private _adminCreateUserConfig;
    get adminCreateUserConfig(): DataAwsCognitoUserPool.AdminCreateUserConfigPropertyList;
    get arn(): string;
    get autoVerifiedAttributes(): string[];
    get creationDate(): string;
    get customDomain(): string;
    get deletionProtection(): string;
    private _deviceConfiguration;
    get deviceConfiguration(): DataAwsCognitoUserPool.DeviceConfigurationPropertyList;
    get domain(): string;
    private _emailConfiguration;
    get emailConfiguration(): DataAwsCognitoUserPool.EmailConfigurationPropertyList;
    get estimatedNumberOfUsers(): number;
    get id(): string;
    private _lambdaConfig;
    get lambdaConfig(): DataAwsCognitoUserPool.LambdaConfigPropertyList;
    get lastModifiedDate(): string;
    get mfaConfiguration(): string;
    get name(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _schemaAttributes;
    get schemaAttributes(): DataAwsCognitoUserPool.SchemaAttributesPropertyList;
    get smsAuthenticationMessage(): string;
    get smsConfigurationFailure(): string;
    get smsVerificationMessage(): string;
    private _tags;
    get tags(): cdktn.StringMap;
    private _userPoolAddOns;
    get userPoolAddOns(): DataAwsCognitoUserPool.UserPoolAddOnsPropertyList;
    private _userPoolId?;
    get userPoolId(): string;
    set userPoolId(value: string);
    get userPoolIdInput(): string | undefined;
    private _userPoolTags;
    get userPoolTags(): cdktn.StringMap;
    get usernameAttributes(): string[];
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsCognitoUserPoolRecoveryMechanismPropertyToTerraform(struct?: DataAwsCognitoUserPool.RecoveryMechanismProperty): any;
export declare function dataAwsCognitoUserPoolRecoveryMechanismPropertyToHclTerraform(struct?: DataAwsCognitoUserPool.RecoveryMechanismProperty): any;
export declare function dataAwsCognitoUserPoolAccountRecoverySettingPropertyToTerraform(struct?: DataAwsCognitoUserPool.AccountRecoverySettingProperty): any;
export declare function dataAwsCognitoUserPoolAccountRecoverySettingPropertyToHclTerraform(struct?: DataAwsCognitoUserPool.AccountRecoverySettingProperty): any;
export declare function dataAwsCognitoUserPoolInviteMessageTemplatePropertyToTerraform(struct?: DataAwsCognitoUserPool.InviteMessageTemplateProperty): any;
export declare function dataAwsCognitoUserPoolInviteMessageTemplatePropertyToHclTerraform(struct?: DataAwsCognitoUserPool.InviteMessageTemplateProperty): any;
export declare function dataAwsCognitoUserPoolAdminCreateUserConfigPropertyToTerraform(struct?: DataAwsCognitoUserPool.AdminCreateUserConfigProperty): any;
export declare function dataAwsCognitoUserPoolAdminCreateUserConfigPropertyToHclTerraform(struct?: DataAwsCognitoUserPool.AdminCreateUserConfigProperty): any;
export declare function dataAwsCognitoUserPoolDeviceConfigurationPropertyToTerraform(struct?: DataAwsCognitoUserPool.DeviceConfigurationProperty): any;
export declare function dataAwsCognitoUserPoolDeviceConfigurationPropertyToHclTerraform(struct?: DataAwsCognitoUserPool.DeviceConfigurationProperty): any;
export declare function dataAwsCognitoUserPoolEmailConfigurationPropertyToTerraform(struct?: DataAwsCognitoUserPool.EmailConfigurationProperty): any;
export declare function dataAwsCognitoUserPoolEmailConfigurationPropertyToHclTerraform(struct?: DataAwsCognitoUserPool.EmailConfigurationProperty): any;
export declare function dataAwsCognitoUserPoolCustomEmailSenderPropertyToTerraform(struct?: DataAwsCognitoUserPool.CustomEmailSenderProperty): any;
export declare function dataAwsCognitoUserPoolCustomEmailSenderPropertyToHclTerraform(struct?: DataAwsCognitoUserPool.CustomEmailSenderProperty): any;
export declare function dataAwsCognitoUserPoolCustomSmsSenderPropertyToTerraform(struct?: DataAwsCognitoUserPool.CustomSmsSenderProperty): any;
export declare function dataAwsCognitoUserPoolCustomSmsSenderPropertyToHclTerraform(struct?: DataAwsCognitoUserPool.CustomSmsSenderProperty): any;
export declare function dataAwsCognitoUserPoolPreTokenGenerationConfigPropertyToTerraform(struct?: DataAwsCognitoUserPool.PreTokenGenerationConfigProperty): any;
export declare function dataAwsCognitoUserPoolPreTokenGenerationConfigPropertyToHclTerraform(struct?: DataAwsCognitoUserPool.PreTokenGenerationConfigProperty): any;
export declare function dataAwsCognitoUserPoolLambdaConfigPropertyToTerraform(struct?: DataAwsCognitoUserPool.LambdaConfigProperty): any;
export declare function dataAwsCognitoUserPoolLambdaConfigPropertyToHclTerraform(struct?: DataAwsCognitoUserPool.LambdaConfigProperty): any;
export declare function dataAwsCognitoUserPoolNumberAttributeConstraintsPropertyToTerraform(struct?: DataAwsCognitoUserPool.NumberAttributeConstraintsProperty): any;
export declare function dataAwsCognitoUserPoolNumberAttributeConstraintsPropertyToHclTerraform(struct?: DataAwsCognitoUserPool.NumberAttributeConstraintsProperty): any;
export declare function dataAwsCognitoUserPoolStringAttributeConstraintsPropertyToTerraform(struct?: DataAwsCognitoUserPool.StringAttributeConstraintsProperty): any;
export declare function dataAwsCognitoUserPoolStringAttributeConstraintsPropertyToHclTerraform(struct?: DataAwsCognitoUserPool.StringAttributeConstraintsProperty): any;
export declare function dataAwsCognitoUserPoolSchemaAttributesPropertyToTerraform(struct?: DataAwsCognitoUserPool.SchemaAttributesProperty): any;
export declare function dataAwsCognitoUserPoolSchemaAttributesPropertyToHclTerraform(struct?: DataAwsCognitoUserPool.SchemaAttributesProperty): any;
export declare function dataAwsCognitoUserPoolAdvancedSecurityAdditionalFlowsPropertyToTerraform(struct?: DataAwsCognitoUserPool.AdvancedSecurityAdditionalFlowsProperty): any;
export declare function dataAwsCognitoUserPoolAdvancedSecurityAdditionalFlowsPropertyToHclTerraform(struct?: DataAwsCognitoUserPool.AdvancedSecurityAdditionalFlowsProperty): any;
export declare function dataAwsCognitoUserPoolUserPoolAddOnsPropertyToTerraform(struct?: DataAwsCognitoUserPool.UserPoolAddOnsProperty): any;
export declare function dataAwsCognitoUserPoolUserPoolAddOnsPropertyToHclTerraform(struct?: DataAwsCognitoUserPool.UserPoolAddOnsProperty): any;
export declare namespace DataAwsCognitoUserPool {
    interface RecoveryMechanismProperty {
    }
    class RecoveryMechanismPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RecoveryMechanismProperty | undefined;
        set internalValue(value: RecoveryMechanismProperty | undefined);
        get name(): string;
        get priority(): number;
    }
    class RecoveryMechanismPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RecoveryMechanismPropertyOutputReference;
    }
    interface AccountRecoverySettingProperty {
    }
    class AccountRecoverySettingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AccountRecoverySettingProperty | undefined;
        set internalValue(value: AccountRecoverySettingProperty | undefined);
        private _recoveryMechanism;
        get recoveryMechanism(): RecoveryMechanismPropertyList;
    }
    class AccountRecoverySettingPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AccountRecoverySettingPropertyOutputReference;
    }
    interface InviteMessageTemplateProperty {
    }
    class InviteMessageTemplatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InviteMessageTemplateProperty | undefined;
        set internalValue(value: InviteMessageTemplateProperty | undefined);
        get emailMessage(): string;
        get emailSubject(): string;
        get smsMessage(): string;
    }
    class InviteMessageTemplatePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InviteMessageTemplatePropertyOutputReference;
    }
    interface AdminCreateUserConfigProperty {
    }
    class AdminCreateUserConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AdminCreateUserConfigProperty | undefined;
        set internalValue(value: AdminCreateUserConfigProperty | undefined);
        get allowAdminCreateUserOnly(): cdktn.IResolvable;
        private _inviteMessageTemplate;
        get inviteMessageTemplate(): InviteMessageTemplatePropertyList;
        get unusedAccountValidityDays(): number;
    }
    class AdminCreateUserConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AdminCreateUserConfigPropertyOutputReference;
    }
    interface DeviceConfigurationProperty {
    }
    class DeviceConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DeviceConfigurationProperty | undefined;
        set internalValue(value: DeviceConfigurationProperty | undefined);
        get challengeRequiredOnNewDevice(): cdktn.IResolvable;
        get deviceOnlyRememberedOnUserPrompt(): cdktn.IResolvable;
    }
    class DeviceConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DeviceConfigurationPropertyOutputReference;
    }
    interface EmailConfigurationProperty {
    }
    class EmailConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EmailConfigurationProperty | undefined;
        set internalValue(value: EmailConfigurationProperty | undefined);
        get configurationSet(): string;
        get emailSendingAccount(): string;
        get from(): string;
        get replyToEmailAddress(): string;
        get sourceArn(): string;
    }
    class EmailConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EmailConfigurationPropertyOutputReference;
    }
    interface CustomEmailSenderProperty {
    }
    class CustomEmailSenderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomEmailSenderProperty | undefined;
        set internalValue(value: CustomEmailSenderProperty | undefined);
        get lambdaArn(): string;
        get lambdaVersion(): string;
    }
    class CustomEmailSenderPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomEmailSenderPropertyOutputReference;
    }
    interface CustomSmsSenderProperty {
    }
    class CustomSmsSenderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomSmsSenderProperty | undefined;
        set internalValue(value: CustomSmsSenderProperty | undefined);
        get lambdaArn(): string;
        get lambdaVersion(): string;
    }
    class CustomSmsSenderPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomSmsSenderPropertyOutputReference;
    }
    interface PreTokenGenerationConfigProperty {
    }
    class PreTokenGenerationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PreTokenGenerationConfigProperty | undefined;
        set internalValue(value: PreTokenGenerationConfigProperty | undefined);
        get lambdaArn(): string;
        get lambdaVersion(): string;
    }
    class PreTokenGenerationConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PreTokenGenerationConfigPropertyOutputReference;
    }
    interface LambdaConfigProperty {
    }
    class LambdaConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LambdaConfigProperty | undefined;
        set internalValue(value: LambdaConfigProperty | undefined);
        get createAuthChallenge(): string;
        private _customEmailSender;
        get customEmailSender(): CustomEmailSenderPropertyList;
        get customMessage(): string;
        private _customSmsSender;
        get customSmsSender(): CustomSmsSenderPropertyList;
        get defineAuthChallenge(): string;
        get kmsKeyId(): string;
        get postAuthentication(): string;
        get postConfirmation(): string;
        get preAuthentication(): string;
        get preSignUp(): string;
        get preTokenGeneration(): string;
        private _preTokenGenerationConfig;
        get preTokenGenerationConfig(): PreTokenGenerationConfigPropertyList;
        get userMigration(): string;
        get verifyAuthChallengeResponse(): string;
    }
    class LambdaConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LambdaConfigPropertyOutputReference;
    }
    interface NumberAttributeConstraintsProperty {
    }
    class NumberAttributeConstraintsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NumberAttributeConstraintsProperty | undefined;
        set internalValue(value: NumberAttributeConstraintsProperty | undefined);
        get maxValue(): string;
        get minValue(): string;
    }
    class NumberAttributeConstraintsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NumberAttributeConstraintsPropertyOutputReference;
    }
    interface StringAttributeConstraintsProperty {
    }
    class StringAttributeConstraintsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StringAttributeConstraintsProperty | undefined;
        set internalValue(value: StringAttributeConstraintsProperty | undefined);
        get maxLength(): string;
        get minLength(): string;
    }
    class StringAttributeConstraintsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StringAttributeConstraintsPropertyOutputReference;
    }
    interface SchemaAttributesProperty {
    }
    class SchemaAttributesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SchemaAttributesProperty | undefined;
        set internalValue(value: SchemaAttributesProperty | undefined);
        get attributeDataType(): string;
        get developerOnlyAttribute(): cdktn.IResolvable;
        get mutable(): cdktn.IResolvable;
        get name(): string;
        private _numberAttributeConstraints;
        get numberAttributeConstraints(): NumberAttributeConstraintsPropertyList;
        get required(): cdktn.IResolvable;
        private _stringAttributeConstraints;
        get stringAttributeConstraints(): StringAttributeConstraintsPropertyList;
    }
    class SchemaAttributesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SchemaAttributesPropertyOutputReference;
    }
    interface AdvancedSecurityAdditionalFlowsProperty {
    }
    class AdvancedSecurityAdditionalFlowsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AdvancedSecurityAdditionalFlowsProperty | undefined;
        set internalValue(value: AdvancedSecurityAdditionalFlowsProperty | undefined);
        get customAuthMode(): string;
    }
    class AdvancedSecurityAdditionalFlowsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AdvancedSecurityAdditionalFlowsPropertyOutputReference;
    }
    interface UserPoolAddOnsProperty {
    }
    class UserPoolAddOnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UserPoolAddOnsProperty | undefined;
        set internalValue(value: UserPoolAddOnsProperty | undefined);
        private _advancedSecurityAdditionalFlows;
        get advancedSecurityAdditionalFlows(): AdvancedSecurityAdditionalFlowsPropertyList;
        get advancedSecurityMode(): string;
    }
    class UserPoolAddOnsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UserPoolAddOnsPropertyOutputReference;
    }
}
