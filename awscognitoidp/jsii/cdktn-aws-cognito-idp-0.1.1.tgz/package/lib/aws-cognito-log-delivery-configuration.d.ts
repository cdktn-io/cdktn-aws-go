import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsCognitoLogDeliveryConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_log_delivery_configuration#region AwsCognitoLogDeliveryConfiguration#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_log_delivery_configuration#user_pool_id AwsCognitoLogDeliveryConfiguration#user_pool_id}
    */
    readonly userPoolId: string;
    /**
    * log_configurations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_log_delivery_configuration#log_configurations AwsCognitoLogDeliveryConfiguration#log_configurations}
    */
    readonly logConfigurations?: AwsCognitoLogDeliveryConfiguration.LogConfigurationsProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_log_delivery_configuration aws_cognito_log_delivery_configuration}
*/
export declare class AwsCognitoLogDeliveryConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cognito_log_delivery_configuration";
    /**
    * Generates CDKTN code for importing a AwsCognitoLogDeliveryConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCognitoLogDeliveryConfiguration to import
    * @param importFromId The id of the existing AwsCognitoLogDeliveryConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_log_delivery_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCognitoLogDeliveryConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_log_delivery_configuration aws_cognito_log_delivery_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsCognitoLogDeliveryConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsCognitoLogDeliveryConfigurationConfig);
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _userPoolId?;
    get userPoolId(): string;
    set userPoolId(value: string);
    get userPoolIdInput(): string | undefined;
    private _logConfigurations;
    get logConfigurations(): AwsCognitoLogDeliveryConfiguration.LogConfigurationsPropertyList;
    putLogConfigurations(value: AwsCognitoLogDeliveryConfiguration.LogConfigurationsProperty[] | cdktn.IResolvable): void;
    resetLogConfigurations(): void;
    get logConfigurationsInput(): cdktn.IResolvable | AwsCognitoLogDeliveryConfiguration.LogConfigurationsProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsCognitoLogDeliveryConfigurationCloudWatchLogsConfigurationPropertyToTerraform(struct?: AwsCognitoLogDeliveryConfiguration.CloudWatchLogsConfigurationProperty | cdktn.IResolvable): any;
export declare function awsCognitoLogDeliveryConfigurationCloudWatchLogsConfigurationPropertyToHclTerraform(struct?: AwsCognitoLogDeliveryConfiguration.CloudWatchLogsConfigurationProperty | cdktn.IResolvable): any;
export declare function awsCognitoLogDeliveryConfigurationFirehoseConfigurationPropertyToTerraform(struct?: AwsCognitoLogDeliveryConfiguration.FirehoseConfigurationProperty | cdktn.IResolvable): any;
export declare function awsCognitoLogDeliveryConfigurationFirehoseConfigurationPropertyToHclTerraform(struct?: AwsCognitoLogDeliveryConfiguration.FirehoseConfigurationProperty | cdktn.IResolvable): any;
export declare function awsCognitoLogDeliveryConfigurationS3ConfigurationPropertyToTerraform(struct?: AwsCognitoLogDeliveryConfiguration.S3ConfigurationProperty | cdktn.IResolvable): any;
export declare function awsCognitoLogDeliveryConfigurationS3ConfigurationPropertyToHclTerraform(struct?: AwsCognitoLogDeliveryConfiguration.S3ConfigurationProperty | cdktn.IResolvable): any;
export declare function awsCognitoLogDeliveryConfigurationLogConfigurationsPropertyToTerraform(struct?: AwsCognitoLogDeliveryConfiguration.LogConfigurationsProperty | cdktn.IResolvable): any;
export declare function awsCognitoLogDeliveryConfigurationLogConfigurationsPropertyToHclTerraform(struct?: AwsCognitoLogDeliveryConfiguration.LogConfigurationsProperty | cdktn.IResolvable): any;
export declare namespace AwsCognitoLogDeliveryConfiguration {
    interface CloudWatchLogsConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_log_delivery_configuration#log_group_arn AwsCognitoLogDeliveryConfiguration#log_group_arn}
        */
        readonly logGroupArn?: string;
    }
    class CloudWatchLogsConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CloudWatchLogsConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CloudWatchLogsConfigurationProperty | cdktn.IResolvable | undefined);
        private _logGroupArn?;
        get logGroupArn(): string;
        set logGroupArn(value: string);
        resetLogGroupArn(): void;
        get logGroupArnInput(): string | undefined;
    }
    class CloudWatchLogsConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: CloudWatchLogsConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CloudWatchLogsConfigurationPropertyOutputReference;
    }
    interface FirehoseConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_log_delivery_configuration#stream_arn AwsCognitoLogDeliveryConfiguration#stream_arn}
        */
        readonly streamArn?: string;
    }
    class FirehoseConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FirehoseConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FirehoseConfigurationProperty | cdktn.IResolvable | undefined);
        private _streamArn?;
        get streamArn(): string;
        set streamArn(value: string);
        resetStreamArn(): void;
        get streamArnInput(): string | undefined;
    }
    class FirehoseConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: FirehoseConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FirehoseConfigurationPropertyOutputReference;
    }
    interface S3ConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_log_delivery_configuration#bucket_arn AwsCognitoLogDeliveryConfiguration#bucket_arn}
        */
        readonly bucketArn?: string;
    }
    class S3ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3ConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3ConfigurationProperty | cdktn.IResolvable | undefined);
        private _bucketArn?;
        get bucketArn(): string;
        set bucketArn(value: string);
        resetBucketArn(): void;
        get bucketArnInput(): string | undefined;
    }
    class S3ConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: S3ConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3ConfigurationPropertyOutputReference;
    }
    interface LogConfigurationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_log_delivery_configuration#event_source AwsCognitoLogDeliveryConfiguration#event_source}
        */
        readonly eventSource: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_log_delivery_configuration#log_level AwsCognitoLogDeliveryConfiguration#log_level}
        */
        readonly logLevel: string;
        /**
        * cloud_watch_logs_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_log_delivery_configuration#cloud_watch_logs_configuration AwsCognitoLogDeliveryConfiguration#cloud_watch_logs_configuration}
        */
        readonly cloudWatchLogsConfiguration?: CloudWatchLogsConfigurationProperty[] | cdktn.IResolvable;
        /**
        * firehose_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_log_delivery_configuration#firehose_configuration AwsCognitoLogDeliveryConfiguration#firehose_configuration}
        */
        readonly firehoseConfiguration?: FirehoseConfigurationProperty[] | cdktn.IResolvable;
        /**
        * s3_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_log_delivery_configuration#s3_configuration AwsCognitoLogDeliveryConfiguration#s3_configuration}
        */
        readonly s3Configuration?: S3ConfigurationProperty[] | cdktn.IResolvable;
    }
    class LogConfigurationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LogConfigurationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LogConfigurationsProperty | cdktn.IResolvable | undefined);
        private _eventSource?;
        get eventSource(): string;
        set eventSource(value: string);
        get eventSourceInput(): string | undefined;
        private _logLevel?;
        get logLevel(): string;
        set logLevel(value: string);
        get logLevelInput(): string | undefined;
        private _cloudWatchLogsConfiguration;
        get cloudWatchLogsConfiguration(): CloudWatchLogsConfigurationPropertyList;
        putCloudWatchLogsConfiguration(value: CloudWatchLogsConfigurationProperty[] | cdktn.IResolvable): void;
        resetCloudWatchLogsConfiguration(): void;
        get cloudWatchLogsConfigurationInput(): cdktn.IResolvable | CloudWatchLogsConfigurationProperty[] | undefined;
        private _firehoseConfiguration;
        get firehoseConfiguration(): FirehoseConfigurationPropertyList;
        putFirehoseConfiguration(value: FirehoseConfigurationProperty[] | cdktn.IResolvable): void;
        resetFirehoseConfiguration(): void;
        get firehoseConfigurationInput(): cdktn.IResolvable | FirehoseConfigurationProperty[] | undefined;
        private _s3Configuration;
        get s3Configuration(): S3ConfigurationPropertyList;
        putS3Configuration(value: S3ConfigurationProperty[] | cdktn.IResolvable): void;
        resetS3Configuration(): void;
        get s3ConfigurationInput(): cdktn.IResolvable | S3ConfigurationProperty[] | undefined;
    }
    class LogConfigurationsPropertyList extends cdktn.ComplexList {
        internalValue?: LogConfigurationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LogConfigurationsPropertyOutputReference;
    }
}
