import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfUserPoolConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cognito_user_pool#region DataTfUserPool#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cognito_user_pool#user_pool_id DataTfUserPool#user_pool_id}
    */
    readonly userPoolId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cognito_user_pool aws_cognito_user_pool}
*/
export declare class DataTfUserPool extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_cognito_user_pool";
    /**
    * Generates CDKTN code for importing a DataTfUserPool resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfUserPool to import
    * @param importFromId The id of the existing DataTfUserPool that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cognito_user_pool#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfUserPool to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cognito_user_pool aws_cognito_user_pool} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfUserPoolConfig
    */
    constructor(scope: Construct, id: string, config: DataTfUserPoolConfig);
    private _accountRecoverySetting;
    get accountRecoverySetting(): DataTfUserPool.AccountRecoverySettingPropertyList;
    private _adminCreateUserConfig;
    get adminCreateUserConfig(): DataTfUserPool.AdminCreateUserConfigPropertyList;
    get arn(): string;
    get autoVerifiedAttributes(): string[];
    get creationDate(): string;
    get customDomain(): string;
    get deletionProtection(): string;
    private _deviceConfiguration;
    get deviceConfiguration(): DataTfUserPool.DeviceConfigurationPropertyList;
    get domain(): string;
    private _emailConfiguration;
    get emailConfiguration(): DataTfUserPool.EmailConfigurationPropertyList;
    get estimatedNumberOfUsers(): number;
    get id(): string;
    private _lambdaConfig;
    get lambdaConfig(): DataTfUserPool.LambdaConfigPropertyList;
    get lastModifiedDate(): string;
    get mfaConfiguration(): string;
    get name(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _schemaAttributes;
    get schemaAttributes(): DataTfUserPool.SchemaAttributesPropertyList;
    get smsAuthenticationMessage(): string;
    get smsConfigurationFailure(): string;
    get smsVerificationMessage(): string;
    private _tags;
    get tags(): cdktn.StringMap;
    private _userPoolAddOns;
    get userPoolAddOns(): DataTfUserPool.UserPoolAddOnsPropertyList;
    private _userPoolId?;
    get userPoolId(): string;
    set userPoolId(value: string);
    get userPoolIdInput(): string | undefined;
    private _userPoolTags;
    get userPoolTags(): cdktn.StringMap;
    get usernameAttributes(): string[];
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfUserPoolRecoveryMechanismPropertyToTerraform(struct?: DataTfUserPool.RecoveryMechanismProperty): any;
export declare function dataTfUserPoolRecoveryMechanismPropertyToHclTerraform(struct?: DataTfUserPool.RecoveryMechanismProperty): any;
export declare function dataTfUserPoolAccountRecoverySettingPropertyToTerraform(struct?: DataTfUserPool.AccountRecoverySettingProperty): any;
export declare function dataTfUserPoolAccountRecoverySettingPropertyToHclTerraform(struct?: DataTfUserPool.AccountRecoverySettingProperty): any;
export declare function dataTfUserPoolInviteMessageTemplatePropertyToTerraform(struct?: DataTfUserPool.InviteMessageTemplateProperty): any;
export declare function dataTfUserPoolInviteMessageTemplatePropertyToHclTerraform(struct?: DataTfUserPool.InviteMessageTemplateProperty): any;
export declare function dataTfUserPoolAdminCreateUserConfigPropertyToTerraform(struct?: DataTfUserPool.AdminCreateUserConfigProperty): any;
export declare function dataTfUserPoolAdminCreateUserConfigPropertyToHclTerraform(struct?: DataTfUserPool.AdminCreateUserConfigProperty): any;
export declare function dataTfUserPoolDeviceConfigurationPropertyToTerraform(struct?: DataTfUserPool.DeviceConfigurationProperty): any;
export declare function dataTfUserPoolDeviceConfigurationPropertyToHclTerraform(struct?: DataTfUserPool.DeviceConfigurationProperty): any;
export declare function dataTfUserPoolEmailConfigurationPropertyToTerraform(struct?: DataTfUserPool.EmailConfigurationProperty): any;
export declare function dataTfUserPoolEmailConfigurationPropertyToHclTerraform(struct?: DataTfUserPool.EmailConfigurationProperty): any;
export declare function dataTfUserPoolCustomEmailSenderPropertyToTerraform(struct?: DataTfUserPool.CustomEmailSenderProperty): any;
export declare function dataTfUserPoolCustomEmailSenderPropertyToHclTerraform(struct?: DataTfUserPool.CustomEmailSenderProperty): any;
export declare function dataTfUserPoolCustomSmsSenderPropertyToTerraform(struct?: DataTfUserPool.CustomSmsSenderProperty): any;
export declare function dataTfUserPoolCustomSmsSenderPropertyToHclTerraform(struct?: DataTfUserPool.CustomSmsSenderProperty): any;
export declare function dataTfUserPoolPreTokenGenerationConfigPropertyToTerraform(struct?: DataTfUserPool.PreTokenGenerationConfigProperty): any;
export declare function dataTfUserPoolPreTokenGenerationConfigPropertyToHclTerraform(struct?: DataTfUserPool.PreTokenGenerationConfigProperty): any;
export declare function dataTfUserPoolLambdaConfigPropertyToTerraform(struct?: DataTfUserPool.LambdaConfigProperty): any;
export declare function dataTfUserPoolLambdaConfigPropertyToHclTerraform(struct?: DataTfUserPool.LambdaConfigProperty): any;
export declare function dataTfUserPoolNumberAttributeConstraintsPropertyToTerraform(struct?: DataTfUserPool.NumberAttributeConstraintsProperty): any;
export declare function dataTfUserPoolNumberAttributeConstraintsPropertyToHclTerraform(struct?: DataTfUserPool.NumberAttributeConstraintsProperty): any;
export declare function dataTfUserPoolStringAttributeConstraintsPropertyToTerraform(struct?: DataTfUserPool.StringAttributeConstraintsProperty): any;
export declare function dataTfUserPoolStringAttributeConstraintsPropertyToHclTerraform(struct?: DataTfUserPool.StringAttributeConstraintsProperty): any;
export declare function dataTfUserPoolSchemaAttributesPropertyToTerraform(struct?: DataTfUserPool.SchemaAttributesProperty): any;
export declare function dataTfUserPoolSchemaAttributesPropertyToHclTerraform(struct?: DataTfUserPool.SchemaAttributesProperty): any;
export declare function dataTfUserPoolAdvancedSecurityAdditionalFlowsPropertyToTerraform(struct?: DataTfUserPool.AdvancedSecurityAdditionalFlowsProperty): any;
export declare function dataTfUserPoolAdvancedSecurityAdditionalFlowsPropertyToHclTerraform(struct?: DataTfUserPool.AdvancedSecurityAdditionalFlowsProperty): any;
export declare function dataTfUserPoolUserPoolAddOnsPropertyToTerraform(struct?: DataTfUserPool.UserPoolAddOnsProperty): any;
export declare function dataTfUserPoolUserPoolAddOnsPropertyToHclTerraform(struct?: DataTfUserPool.UserPoolAddOnsProperty): any;
export declare namespace DataTfUserPool {
    interface RecoveryMechanismProperty {
    }
    class RecoveryMechanismPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RecoveryMechanismProperty | undefined;
        set internalValue(value: RecoveryMechanismProperty | undefined);
        get name(): string;
        get priority(): number;
    }
    class RecoveryMechanismPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RecoveryMechanismPropertyOutputReference;
    }
    interface AccountRecoverySettingProperty {
    }
    class AccountRecoverySettingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AccountRecoverySettingProperty | undefined;
        set internalValue(value: AccountRecoverySettingProperty | undefined);
        private _recoveryMechanism;
        get recoveryMechanism(): RecoveryMechanismPropertyList;
    }
    class AccountRecoverySettingPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AccountRecoverySettingPropertyOutputReference;
    }
    interface InviteMessageTemplateProperty {
    }
    class InviteMessageTemplatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InviteMessageTemplateProperty | undefined;
        set internalValue(value: InviteMessageTemplateProperty | undefined);
        get emailMessage(): string;
        get emailSubject(): string;
        get smsMessage(): string;
    }
    class InviteMessageTemplatePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InviteMessageTemplatePropertyOutputReference;
    }
    interface AdminCreateUserConfigProperty {
    }
    class AdminCreateUserConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AdminCreateUserConfigProperty | undefined;
        set internalValue(value: AdminCreateUserConfigProperty | undefined);
        get allowAdminCreateUserOnly(): cdktn.IResolvable;
        private _inviteMessageTemplate;
        get inviteMessageTemplate(): InviteMessageTemplatePropertyList;
        get unusedAccountValidityDays(): number;
    }
    class AdminCreateUserConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AdminCreateUserConfigPropertyOutputReference;
    }
    interface DeviceConfigurationProperty {
    }
    class DeviceConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DeviceConfigurationProperty | undefined;
        set internalValue(value: DeviceConfigurationProperty | undefined);
        get challengeRequiredOnNewDevice(): cdktn.IResolvable;
        get deviceOnlyRememberedOnUserPrompt(): cdktn.IResolvable;
    }
    class DeviceConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DeviceConfigurationPropertyOutputReference;
    }
    interface EmailConfigurationProperty {
    }
    class EmailConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EmailConfigurationProperty | undefined;
        set internalValue(value: EmailConfigurationProperty | undefined);
        get configurationSet(): string;
        get emailSendingAccount(): string;
        get from(): string;
        get replyToEmailAddress(): string;
        get sourceArn(): string;
    }
    class EmailConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EmailConfigurationPropertyOutputReference;
    }
    interface CustomEmailSenderProperty {
    }
    class CustomEmailSenderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomEmailSenderProperty | undefined;
        set internalValue(value: CustomEmailSenderProperty | undefined);
        get lambdaArn(): string;
        get lambdaVersion(): string;
    }
    class CustomEmailSenderPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomEmailSenderPropertyOutputReference;
    }
    interface CustomSmsSenderProperty {
    }
    class CustomSmsSenderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomSmsSenderProperty | undefined;
        set internalValue(value: CustomSmsSenderProperty | undefined);
        get lambdaArn(): string;
        get lambdaVersion(): string;
    }
    class CustomSmsSenderPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomSmsSenderPropertyOutputReference;
    }
    interface PreTokenGenerationConfigProperty {
    }
    class PreTokenGenerationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PreTokenGenerationConfigProperty | undefined;
        set internalValue(value: PreTokenGenerationConfigProperty | undefined);
        get lambdaArn(): string;
        get lambdaVersion(): string;
    }
    class PreTokenGenerationConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PreTokenGenerationConfigPropertyOutputReference;
    }
    interface LambdaConfigProperty {
    }
    class LambdaConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LambdaConfigProperty | undefined;
        set internalValue(value: LambdaConfigProperty | undefined);
        get createAuthChallenge(): string;
        private _customEmailSender;
        get customEmailSender(): CustomEmailSenderPropertyList;
        get customMessage(): string;
        private _customSmsSender;
        get customSmsSender(): CustomSmsSenderPropertyList;
        get defineAuthChallenge(): string;
        get kmsKeyId(): string;
        get postAuthentication(): string;
        get postConfirmation(): string;
        get preAuthentication(): string;
        get preSignUp(): string;
        get preTokenGeneration(): string;
        private _preTokenGenerationConfig;
        get preTokenGenerationConfig(): PreTokenGenerationConfigPropertyList;
        get userMigration(): string;
        get verifyAuthChallengeResponse(): string;
    }
    class LambdaConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LambdaConfigPropertyOutputReference;
    }
    interface NumberAttributeConstraintsProperty {
    }
    class NumberAttributeConstraintsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NumberAttributeConstraintsProperty | undefined;
        set internalValue(value: NumberAttributeConstraintsProperty | undefined);
        get maxValue(): string;
        get minValue(): string;
    }
    class NumberAttributeConstraintsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NumberAttributeConstraintsPropertyOutputReference;
    }
    interface StringAttributeConstraintsProperty {
    }
    class StringAttributeConstraintsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StringAttributeConstraintsProperty | undefined;
        set internalValue(value: StringAttributeConstraintsProperty | undefined);
        get maxLength(): string;
        get minLength(): string;
    }
    class StringAttributeConstraintsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StringAttributeConstraintsPropertyOutputReference;
    }
    interface SchemaAttributesProperty {
    }
    class SchemaAttributesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SchemaAttributesProperty | undefined;
        set internalValue(value: SchemaAttributesProperty | undefined);
        get attributeDataType(): string;
        get developerOnlyAttribute(): cdktn.IResolvable;
        get mutable(): cdktn.IResolvable;
        get name(): string;
        private _numberAttributeConstraints;
        get numberAttributeConstraints(): NumberAttributeConstraintsPropertyList;
        get required(): cdktn.IResolvable;
        private _stringAttributeConstraints;
        get stringAttributeConstraints(): StringAttributeConstraintsPropertyList;
    }
    class SchemaAttributesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SchemaAttributesPropertyOutputReference;
    }
    interface AdvancedSecurityAdditionalFlowsProperty {
    }
    class AdvancedSecurityAdditionalFlowsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AdvancedSecurityAdditionalFlowsProperty | undefined;
        set internalValue(value: AdvancedSecurityAdditionalFlowsProperty | undefined);
        get customAuthMode(): string;
    }
    class AdvancedSecurityAdditionalFlowsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AdvancedSecurityAdditionalFlowsPropertyOutputReference;
    }
    interface UserPoolAddOnsProperty {
    }
    class UserPoolAddOnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UserPoolAddOnsProperty | undefined;
        set internalValue(value: UserPoolAddOnsProperty | undefined);
        private _advancedSecurityAdditionalFlows;
        get advancedSecurityAdditionalFlows(): AdvancedSecurityAdditionalFlowsPropertyList;
        get advancedSecurityMode(): string;
    }
    class UserPoolAddOnsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UserPoolAddOnsPropertyOutputReference;
    }
}
