import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfManagedUserPoolClientConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_user_pool_client#access_token_validity TfManagedUserPoolClient#access_token_validity}
    */
    readonly accessTokenValidity?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_user_pool_client#allowed_oauth_flows TfManagedUserPoolClient#allowed_oauth_flows}
    */
    readonly allowedOauthFlows?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_user_pool_client#allowed_oauth_flows_user_pool_client TfManagedUserPoolClient#allowed_oauth_flows_user_pool_client}
    */
    readonly allowedOauthFlowsUserPoolClient?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_user_pool_client#allowed_oauth_scopes TfManagedUserPoolClient#allowed_oauth_scopes}
    */
    readonly allowedOauthScopes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_user_pool_client#auth_session_validity TfManagedUserPoolClient#auth_session_validity}
    */
    readonly authSessionValidity?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_user_pool_client#callback_urls TfManagedUserPoolClient#callback_urls}
    */
    readonly callbackUrls?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_user_pool_client#default_redirect_uri TfManagedUserPoolClient#default_redirect_uri}
    */
    readonly defaultRedirectUri?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_user_pool_client#enable_propagate_additional_user_context_data TfManagedUserPoolClient#enable_propagate_additional_user_context_data}
    */
    readonly enablePropagateAdditionalUserContextData?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_user_pool_client#enable_token_revocation TfManagedUserPoolClient#enable_token_revocation}
    */
    readonly enableTokenRevocation?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_user_pool_client#explicit_auth_flows TfManagedUserPoolClient#explicit_auth_flows}
    */
    readonly explicitAuthFlows?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_user_pool_client#id_token_validity TfManagedUserPoolClient#id_token_validity}
    */
    readonly idTokenValidity?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_user_pool_client#logout_urls TfManagedUserPoolClient#logout_urls}
    */
    readonly logoutUrls?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_user_pool_client#name_pattern TfManagedUserPoolClient#name_pattern}
    */
    readonly namePattern?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_user_pool_client#name_prefix TfManagedUserPoolClient#name_prefix}
    */
    readonly namePrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_user_pool_client#prevent_user_existence_errors TfManagedUserPoolClient#prevent_user_existence_errors}
    */
    readonly preventUserExistenceErrors?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_user_pool_client#read_attributes TfManagedUserPoolClient#read_attributes}
    */
    readonly readAttributes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_user_pool_client#refresh_token_validity TfManagedUserPoolClient#refresh_token_validity}
    */
    readonly refreshTokenValidity?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_user_pool_client#region TfManagedUserPoolClient#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_user_pool_client#supported_identity_providers TfManagedUserPoolClient#supported_identity_providers}
    */
    readonly supportedIdentityProviders?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_user_pool_client#user_pool_id TfManagedUserPoolClient#user_pool_id}
    */
    readonly userPoolId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_user_pool_client#write_attributes TfManagedUserPoolClient#write_attributes}
    */
    readonly writeAttributes?: string[];
    /**
    * analytics_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_user_pool_client#analytics_configuration TfManagedUserPoolClient#analytics_configuration}
    */
    readonly analyticsConfiguration?: TfManagedUserPoolClient.AnalyticsConfigurationProperty[] | cdktn.IResolvable;
    /**
    * refresh_token_rotation block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_user_pool_client#refresh_token_rotation TfManagedUserPoolClient#refresh_token_rotation}
    */
    readonly refreshTokenRotation?: TfManagedUserPoolClient.RefreshTokenRotationProperty[] | cdktn.IResolvable;
    /**
    * token_validity_units block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_user_pool_client#token_validity_units TfManagedUserPoolClient#token_validity_units}
    */
    readonly tokenValidityUnits?: TfManagedUserPoolClient.TokenValidityUnitsProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_user_pool_client aws_cognito_managed_user_pool_client}
*/
export declare class TfManagedUserPoolClient extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cognito_managed_user_pool_client";
    /**
    * Generates CDKTN code for importing a TfManagedUserPoolClient resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfManagedUserPoolClient to import
    * @param importFromId The id of the existing TfManagedUserPoolClient that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_user_pool_client#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfManagedUserPoolClient to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_user_pool_client aws_cognito_managed_user_pool_client} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfManagedUserPoolClientConfig
    */
    constructor(scope: Construct, id: string, config: TfManagedUserPoolClientConfig);
    private _accessTokenValidity?;
    get accessTokenValidity(): number;
    set accessTokenValidity(value: number);
    resetAccessTokenValidity(): void;
    get accessTokenValidityInput(): number | undefined;
    private _allowedOauthFlows?;
    get allowedOauthFlows(): string[];
    set allowedOauthFlows(value: string[]);
    resetAllowedOauthFlows(): void;
    get allowedOauthFlowsInput(): string[] | undefined;
    private _allowedOauthFlowsUserPoolClient?;
    get allowedOauthFlowsUserPoolClient(): boolean | cdktn.IResolvable;
    set allowedOauthFlowsUserPoolClient(value: boolean | cdktn.IResolvable);
    resetAllowedOauthFlowsUserPoolClient(): void;
    get allowedOauthFlowsUserPoolClientInput(): boolean | cdktn.IResolvable | undefined;
    private _allowedOauthScopes?;
    get allowedOauthScopes(): string[];
    set allowedOauthScopes(value: string[]);
    resetAllowedOauthScopes(): void;
    get allowedOauthScopesInput(): string[] | undefined;
    private _authSessionValidity?;
    get authSessionValidity(): number;
    set authSessionValidity(value: number);
    resetAuthSessionValidity(): void;
    get authSessionValidityInput(): number | undefined;
    private _callbackUrls?;
    get callbackUrls(): string[];
    set callbackUrls(value: string[]);
    resetCallbackUrls(): void;
    get callbackUrlsInput(): string[] | undefined;
    get clientSecret(): string;
    private _defaultRedirectUri?;
    get defaultRedirectUri(): string;
    set defaultRedirectUri(value: string);
    resetDefaultRedirectUri(): void;
    get defaultRedirectUriInput(): string | undefined;
    private _enablePropagateAdditionalUserContextData?;
    get enablePropagateAdditionalUserContextData(): boolean | cdktn.IResolvable;
    set enablePropagateAdditionalUserContextData(value: boolean | cdktn.IResolvable);
    resetEnablePropagateAdditionalUserContextData(): void;
    get enablePropagateAdditionalUserContextDataInput(): boolean | cdktn.IResolvable | undefined;
    private _enableTokenRevocation?;
    get enableTokenRevocation(): boolean | cdktn.IResolvable;
    set enableTokenRevocation(value: boolean | cdktn.IResolvable);
    resetEnableTokenRevocation(): void;
    get enableTokenRevocationInput(): boolean | cdktn.IResolvable | undefined;
    private _explicitAuthFlows?;
    get explicitAuthFlows(): string[];
    set explicitAuthFlows(value: string[]);
    resetExplicitAuthFlows(): void;
    get explicitAuthFlowsInput(): string[] | undefined;
    get id(): string;
    private _idTokenValidity?;
    get idTokenValidity(): number;
    set idTokenValidity(value: number);
    resetIdTokenValidity(): void;
    get idTokenValidityInput(): number | undefined;
    private _logoutUrls?;
    get logoutUrls(): string[];
    set logoutUrls(value: string[]);
    resetLogoutUrls(): void;
    get logoutUrlsInput(): string[] | undefined;
    get name(): string;
    private _namePattern?;
    get namePattern(): string;
    set namePattern(value: string);
    resetNamePattern(): void;
    get namePatternInput(): string | undefined;
    private _namePrefix?;
    get namePrefix(): string;
    set namePrefix(value: string);
    resetNamePrefix(): void;
    get namePrefixInput(): string | undefined;
    private _preventUserExistenceErrors?;
    get preventUserExistenceErrors(): string;
    set preventUserExistenceErrors(value: string);
    resetPreventUserExistenceErrors(): void;
    get preventUserExistenceErrorsInput(): string | undefined;
    private _readAttributes?;
    get readAttributes(): string[];
    set readAttributes(value: string[]);
    resetReadAttributes(): void;
    get readAttributesInput(): string[] | undefined;
    private _refreshTokenValidity?;
    get refreshTokenValidity(): number;
    set refreshTokenValidity(value: number);
    resetRefreshTokenValidity(): void;
    get refreshTokenValidityInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _supportedIdentityProviders?;
    get supportedIdentityProviders(): string[];
    set supportedIdentityProviders(value: string[]);
    resetSupportedIdentityProviders(): void;
    get supportedIdentityProvidersInput(): string[] | undefined;
    private _userPoolId?;
    get userPoolId(): string;
    set userPoolId(value: string);
    get userPoolIdInput(): string | undefined;
    private _writeAttributes?;
    get writeAttributes(): string[];
    set writeAttributes(value: string[]);
    resetWriteAttributes(): void;
    get writeAttributesInput(): string[] | undefined;
    private _analyticsConfiguration;
    get analyticsConfiguration(): TfManagedUserPoolClient.AnalyticsConfigurationPropertyList;
    putAnalyticsConfiguration(value: TfManagedUserPoolClient.AnalyticsConfigurationProperty[] | cdktn.IResolvable): void;
    resetAnalyticsConfiguration(): void;
    get analyticsConfigurationInput(): cdktn.IResolvable | TfManagedUserPoolClient.AnalyticsConfigurationProperty[] | undefined;
    private _refreshTokenRotation;
    get refreshTokenRotation(): TfManagedUserPoolClient.RefreshTokenRotationPropertyList;
    putRefreshTokenRotation(value: TfManagedUserPoolClient.RefreshTokenRotationProperty[] | cdktn.IResolvable): void;
    resetRefreshTokenRotation(): void;
    get refreshTokenRotationInput(): cdktn.IResolvable | TfManagedUserPoolClient.RefreshTokenRotationProperty[] | undefined;
    private _tokenValidityUnits;
    get tokenValidityUnits(): TfManagedUserPoolClient.TokenValidityUnitsPropertyList;
    putTokenValidityUnits(value: TfManagedUserPoolClient.TokenValidityUnitsProperty[] | cdktn.IResolvable): void;
    resetTokenValidityUnits(): void;
    get tokenValidityUnitsInput(): cdktn.IResolvable | TfManagedUserPoolClient.TokenValidityUnitsProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfManagedUserPoolClientAnalyticsConfigurationPropertyToTerraform(struct?: TfManagedUserPoolClient.AnalyticsConfigurationProperty | cdktn.IResolvable): any;
export declare function tfManagedUserPoolClientAnalyticsConfigurationPropertyToHclTerraform(struct?: TfManagedUserPoolClient.AnalyticsConfigurationProperty | cdktn.IResolvable): any;
export declare function tfManagedUserPoolClientRefreshTokenRotationPropertyToTerraform(struct?: TfManagedUserPoolClient.RefreshTokenRotationProperty | cdktn.IResolvable): any;
export declare function tfManagedUserPoolClientRefreshTokenRotationPropertyToHclTerraform(struct?: TfManagedUserPoolClient.RefreshTokenRotationProperty | cdktn.IResolvable): any;
export declare function tfManagedUserPoolClientTokenValidityUnitsPropertyToTerraform(struct?: TfManagedUserPoolClient.TokenValidityUnitsProperty | cdktn.IResolvable): any;
export declare function tfManagedUserPoolClientTokenValidityUnitsPropertyToHclTerraform(struct?: TfManagedUserPoolClient.TokenValidityUnitsProperty | cdktn.IResolvable): any;
export declare namespace TfManagedUserPoolClient {
    interface AnalyticsConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_user_pool_client#application_arn TfManagedUserPoolClient#application_arn}
        */
        readonly applicationArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_user_pool_client#application_id TfManagedUserPoolClient#application_id}
        */
        readonly applicationId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_user_pool_client#external_id TfManagedUserPoolClient#external_id}
        */
        readonly externalId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_user_pool_client#role_arn TfManagedUserPoolClient#role_arn}
        */
        readonly roleArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_user_pool_client#user_data_shared TfManagedUserPoolClient#user_data_shared}
        */
        readonly userDataShared?: boolean | cdktn.IResolvable;
    }
    class AnalyticsConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AnalyticsConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AnalyticsConfigurationProperty | cdktn.IResolvable | undefined);
        private _applicationArn?;
        get applicationArn(): string;
        set applicationArn(value: string);
        resetApplicationArn(): void;
        get applicationArnInput(): string | undefined;
        private _applicationId?;
        get applicationId(): string;
        set applicationId(value: string);
        resetApplicationId(): void;
        get applicationIdInput(): string | undefined;
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        resetExternalId(): void;
        get externalIdInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        resetRoleArn(): void;
        get roleArnInput(): string | undefined;
        private _userDataShared?;
        get userDataShared(): boolean | cdktn.IResolvable;
        set userDataShared(value: boolean | cdktn.IResolvable);
        resetUserDataShared(): void;
        get userDataSharedInput(): boolean | cdktn.IResolvable | undefined;
    }
    class AnalyticsConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: AnalyticsConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AnalyticsConfigurationPropertyOutputReference;
    }
    interface RefreshTokenRotationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_user_pool_client#feature TfManagedUserPoolClient#feature}
        */
        readonly feature: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_user_pool_client#retry_grace_period_seconds TfManagedUserPoolClient#retry_grace_period_seconds}
        */
        readonly retryGracePeriodSeconds?: number;
    }
    class RefreshTokenRotationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RefreshTokenRotationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RefreshTokenRotationProperty | cdktn.IResolvable | undefined);
        private _feature?;
        get feature(): string;
        set feature(value: string);
        get featureInput(): string | undefined;
        private _retryGracePeriodSeconds?;
        get retryGracePeriodSeconds(): number;
        set retryGracePeriodSeconds(value: number);
        resetRetryGracePeriodSeconds(): void;
        get retryGracePeriodSecondsInput(): number | undefined;
    }
    class RefreshTokenRotationPropertyList extends cdktn.ComplexList {
        internalValue?: RefreshTokenRotationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RefreshTokenRotationPropertyOutputReference;
    }
    interface TokenValidityUnitsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_user_pool_client#access_token TfManagedUserPoolClient#access_token}
        */
        readonly accessToken?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_user_pool_client#id_token TfManagedUserPoolClient#id_token}
        */
        readonly idToken?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_user_pool_client#refresh_token TfManagedUserPoolClient#refresh_token}
        */
        readonly refreshToken?: string;
    }
    class TokenValidityUnitsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TokenValidityUnitsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TokenValidityUnitsProperty | cdktn.IResolvable | undefined);
        private _accessToken?;
        get accessToken(): string;
        set accessToken(value: string);
        resetAccessToken(): void;
        get accessTokenInput(): string | undefined;
        private _idToken?;
        get idToken(): string;
        set idToken(value: string);
        resetIdToken(): void;
        get idTokenInput(): string | undefined;
        private _refreshToken?;
        get refreshToken(): string;
        set refreshToken(value: string);
        resetRefreshToken(): void;
        get refreshTokenInput(): string | undefined;
    }
    class TokenValidityUnitsPropertyList extends cdktn.ComplexList {
        internalValue?: TokenValidityUnitsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TokenValidityUnitsPropertyOutputReference;
    }
}
