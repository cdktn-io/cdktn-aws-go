import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfUserPoolClientConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cognito_user_pool_client#client_id DataTfUserPoolClient#client_id}
    */
    readonly clientId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cognito_user_pool_client#id DataTfUserPoolClient#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cognito_user_pool_client#region DataTfUserPoolClient#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cognito_user_pool_client#user_pool_id DataTfUserPoolClient#user_pool_id}
    */
    readonly userPoolId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cognito_user_pool_client aws_cognito_user_pool_client}
*/
export declare class DataTfUserPoolClient extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_cognito_user_pool_client";
    /**
    * Generates CDKTN code for importing a DataTfUserPoolClient resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfUserPoolClient to import
    * @param importFromId The id of the existing DataTfUserPoolClient that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cognito_user_pool_client#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfUserPoolClient to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cognito_user_pool_client aws_cognito_user_pool_client} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfUserPoolClientConfig
    */
    constructor(scope: Construct, id: string, config: DataTfUserPoolClientConfig);
    get accessTokenValidity(): number;
    get allowedOauthFlows(): string[];
    get allowedOauthFlowsUserPoolClient(): cdktn.IResolvable;
    get allowedOauthScopes(): string[];
    private _analyticsConfiguration;
    get analyticsConfiguration(): DataTfUserPoolClient.AnalyticsConfigurationPropertyList;
    get callbackUrls(): string[];
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    get clientIdInput(): string | undefined;
    get clientSecret(): string;
    get defaultRedirectUri(): string;
    get enablePropagateAdditionalUserContextData(): cdktn.IResolvable;
    get enableTokenRevocation(): cdktn.IResolvable;
    get explicitAuthFlows(): string[];
    get generateSecret(): cdktn.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get idTokenValidity(): number;
    get logoutUrls(): string[];
    get name(): string;
    get preventUserExistenceErrors(): string;
    get readAttributes(): string[];
    private _refreshTokenRotation;
    get refreshTokenRotation(): DataTfUserPoolClient.RefreshTokenRotationPropertyList;
    get refreshTokenValidity(): number;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get supportedIdentityProviders(): string[];
    private _tokenValidityUnits;
    get tokenValidityUnits(): DataTfUserPoolClient.TokenValidityUnitsPropertyList;
    private _userPoolId?;
    get userPoolId(): string;
    set userPoolId(value: string);
    get userPoolIdInput(): string | undefined;
    get writeAttributes(): string[];
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfUserPoolClientAnalyticsConfigurationPropertyToTerraform(struct?: DataTfUserPoolClient.AnalyticsConfigurationProperty): any;
export declare function dataTfUserPoolClientAnalyticsConfigurationPropertyToHclTerraform(struct?: DataTfUserPoolClient.AnalyticsConfigurationProperty): any;
export declare function dataTfUserPoolClientRefreshTokenRotationPropertyToTerraform(struct?: DataTfUserPoolClient.RefreshTokenRotationProperty): any;
export declare function dataTfUserPoolClientRefreshTokenRotationPropertyToHclTerraform(struct?: DataTfUserPoolClient.RefreshTokenRotationProperty): any;
export declare function dataTfUserPoolClientTokenValidityUnitsPropertyToTerraform(struct?: DataTfUserPoolClient.TokenValidityUnitsProperty): any;
export declare function dataTfUserPoolClientTokenValidityUnitsPropertyToHclTerraform(struct?: DataTfUserPoolClient.TokenValidityUnitsProperty): any;
export declare namespace DataTfUserPoolClient {
    interface AnalyticsConfigurationProperty {
    }
    class AnalyticsConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AnalyticsConfigurationProperty | undefined;
        set internalValue(value: AnalyticsConfigurationProperty | undefined);
        get applicationArn(): string;
        get applicationId(): string;
        get externalId(): string;
        get roleArn(): string;
        get userDataShared(): cdktn.IResolvable;
    }
    class AnalyticsConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AnalyticsConfigurationPropertyOutputReference;
    }
    interface RefreshTokenRotationProperty {
    }
    class RefreshTokenRotationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RefreshTokenRotationProperty | undefined;
        set internalValue(value: RefreshTokenRotationProperty | undefined);
        get feature(): string;
        get retryGracePeriodSeconds(): number;
    }
    class RefreshTokenRotationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RefreshTokenRotationPropertyOutputReference;
    }
    interface TokenValidityUnitsProperty {
    }
    class TokenValidityUnitsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TokenValidityUnitsProperty | undefined;
        set internalValue(value: TokenValidityUnitsProperty | undefined);
        get accessToken(): string;
        get idToken(): string;
        get refreshToken(): string;
    }
    class TokenValidityUnitsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TokenValidityUnitsPropertyOutputReference;
    }
}
