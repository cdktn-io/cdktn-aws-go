import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfUserPoolConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#alias_attributes TfUserPool#alias_attributes}
    */
    readonly aliasAttributes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#auto_verified_attributes TfUserPool#auto_verified_attributes}
    */
    readonly autoVerifiedAttributes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#deletion_protection TfUserPool#deletion_protection}
    */
    readonly deletionProtection?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#email_verification_message TfUserPool#email_verification_message}
    */
    readonly emailVerificationMessage?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#email_verification_subject TfUserPool#email_verification_subject}
    */
    readonly emailVerificationSubject?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#id TfUserPool#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#mfa_configuration TfUserPool#mfa_configuration}
    */
    readonly mfaConfiguration?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#name TfUserPool#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#region TfUserPool#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#sms_authentication_message TfUserPool#sms_authentication_message}
    */
    readonly smsAuthenticationMessage?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#sms_verification_message TfUserPool#sms_verification_message}
    */
    readonly smsVerificationMessage?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#tags TfUserPool#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#tags_all TfUserPool#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#user_pool_tier TfUserPool#user_pool_tier}
    */
    readonly userPoolTier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#username_attributes TfUserPool#username_attributes}
    */
    readonly usernameAttributes?: string[];
    /**
    * account_recovery_setting block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#account_recovery_setting TfUserPool#account_recovery_setting}
    */
    readonly accountRecoverySetting?: TfUserPool.AccountRecoverySettingProperty;
    /**
    * admin_create_user_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#admin_create_user_config TfUserPool#admin_create_user_config}
    */
    readonly adminCreateUserConfig?: TfUserPool.AdminCreateUserConfigProperty;
    /**
    * device_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#device_configuration TfUserPool#device_configuration}
    */
    readonly deviceConfiguration?: TfUserPool.DeviceConfigurationProperty;
    /**
    * email_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#email_configuration TfUserPool#email_configuration}
    */
    readonly emailConfiguration?: TfUserPool.EmailConfigurationProperty;
    /**
    * email_mfa_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#email_mfa_configuration TfUserPool#email_mfa_configuration}
    */
    readonly emailMfaConfiguration?: TfUserPool.EmailMfaConfigurationProperty;
    /**
    * lambda_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#lambda_config TfUserPool#lambda_config}
    */
    readonly lambdaConfig?: TfUserPool.LambdaConfigProperty;
    /**
    * password_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#password_policy TfUserPool#password_policy}
    */
    readonly passwordPolicy?: TfUserPool.PasswordPolicyProperty;
    /**
    * schema block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#schema TfUserPool#schema}
    */
    readonly schema?: TfUserPool.SchemaProperty[] | cdktn.IResolvable;
    /**
    * sign_in_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#sign_in_policy TfUserPool#sign_in_policy}
    */
    readonly signInPolicy?: TfUserPool.SignInPolicyProperty;
    /**
    * sms_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#sms_configuration TfUserPool#sms_configuration}
    */
    readonly smsConfiguration?: TfUserPool.SmsConfigurationProperty;
    /**
    * software_token_mfa_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#software_token_mfa_configuration TfUserPool#software_token_mfa_configuration}
    */
    readonly softwareTokenMfaConfiguration?: TfUserPool.SoftwareTokenMfaConfigurationProperty;
    /**
    * user_attribute_update_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#user_attribute_update_settings TfUserPool#user_attribute_update_settings}
    */
    readonly userAttributeUpdateSettings?: TfUserPool.UserAttributeUpdateSettingsProperty;
    /**
    * user_pool_add_ons block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#user_pool_add_ons TfUserPool#user_pool_add_ons}
    */
    readonly userPoolAddOns?: TfUserPool.UserPoolAddOnsProperty;
    /**
    * username_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#username_configuration TfUserPool#username_configuration}
    */
    readonly usernameConfiguration?: TfUserPool.UsernameConfigurationProperty;
    /**
    * verification_message_template block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#verification_message_template TfUserPool#verification_message_template}
    */
    readonly verificationMessageTemplate?: TfUserPool.VerificationMessageTemplateProperty;
    /**
    * web_authn_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#web_authn_configuration TfUserPool#web_authn_configuration}
    */
    readonly webAuthnConfiguration?: TfUserPool.WebAuthnConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool aws_cognito_user_pool}
*/
export declare class TfUserPool extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cognito_user_pool";
    /**
    * Generates CDKTN code for importing a TfUserPool resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfUserPool to import
    * @param importFromId The id of the existing TfUserPool that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfUserPool to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool aws_cognito_user_pool} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfUserPoolConfig
    */
    constructor(scope: Construct, id: string, config: TfUserPoolConfig);
    private _aliasAttributes?;
    get aliasAttributes(): string[];
    set aliasAttributes(value: string[]);
    resetAliasAttributes(): void;
    get aliasAttributesInput(): string[] | undefined;
    get arn(): string;
    private _autoVerifiedAttributes?;
    get autoVerifiedAttributes(): string[];
    set autoVerifiedAttributes(value: string[]);
    resetAutoVerifiedAttributes(): void;
    get autoVerifiedAttributesInput(): string[] | undefined;
    get creationDate(): string;
    get customDomain(): string;
    private _deletionProtection?;
    get deletionProtection(): string;
    set deletionProtection(value: string);
    resetDeletionProtection(): void;
    get deletionProtectionInput(): string | undefined;
    get domain(): string;
    private _emailVerificationMessage?;
    get emailVerificationMessage(): string;
    set emailVerificationMessage(value: string);
    resetEmailVerificationMessage(): void;
    get emailVerificationMessageInput(): string | undefined;
    private _emailVerificationSubject?;
    get emailVerificationSubject(): string;
    set emailVerificationSubject(value: string);
    resetEmailVerificationSubject(): void;
    get emailVerificationSubjectInput(): string | undefined;
    get endpoint(): string;
    get estimatedNumberOfUsers(): number;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastModifiedDate(): string;
    private _mfaConfiguration?;
    get mfaConfiguration(): string;
    set mfaConfiguration(value: string);
    resetMfaConfiguration(): void;
    get mfaConfigurationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _smsAuthenticationMessage?;
    get smsAuthenticationMessage(): string;
    set smsAuthenticationMessage(value: string);
    resetSmsAuthenticationMessage(): void;
    get smsAuthenticationMessageInput(): string | undefined;
    private _smsVerificationMessage?;
    get smsVerificationMessage(): string;
    set smsVerificationMessage(value: string);
    resetSmsVerificationMessage(): void;
    get smsVerificationMessageInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _userPoolTier?;
    get userPoolTier(): string;
    set userPoolTier(value: string);
    resetUserPoolTier(): void;
    get userPoolTierInput(): string | undefined;
    private _usernameAttributes?;
    get usernameAttributes(): string[];
    set usernameAttributes(value: string[]);
    resetUsernameAttributes(): void;
    get usernameAttributesInput(): string[] | undefined;
    private _accountRecoverySetting;
    get accountRecoverySetting(): TfUserPool.AccountRecoverySettingPropertyOutputReference;
    putAccountRecoverySetting(value: TfUserPool.AccountRecoverySettingProperty): void;
    resetAccountRecoverySetting(): void;
    get accountRecoverySettingInput(): TfUserPool.AccountRecoverySettingProperty | undefined;
    private _adminCreateUserConfig;
    get adminCreateUserConfig(): TfUserPool.AdminCreateUserConfigPropertyOutputReference;
    putAdminCreateUserConfig(value: TfUserPool.AdminCreateUserConfigProperty): void;
    resetAdminCreateUserConfig(): void;
    get adminCreateUserConfigInput(): TfUserPool.AdminCreateUserConfigProperty | undefined;
    private _deviceConfiguration;
    get deviceConfiguration(): TfUserPool.DeviceConfigurationPropertyOutputReference;
    putDeviceConfiguration(value: TfUserPool.DeviceConfigurationProperty): void;
    resetDeviceConfiguration(): void;
    get deviceConfigurationInput(): TfUserPool.DeviceConfigurationProperty | undefined;
    private _emailConfiguration;
    get emailConfiguration(): TfUserPool.EmailConfigurationPropertyOutputReference;
    putEmailConfiguration(value: TfUserPool.EmailConfigurationProperty): void;
    resetEmailConfiguration(): void;
    get emailConfigurationInput(): TfUserPool.EmailConfigurationProperty | undefined;
    private _emailMfaConfiguration;
    get emailMfaConfiguration(): TfUserPool.EmailMfaConfigurationPropertyOutputReference;
    putEmailMfaConfiguration(value: TfUserPool.EmailMfaConfigurationProperty): void;
    resetEmailMfaConfiguration(): void;
    get emailMfaConfigurationInput(): TfUserPool.EmailMfaConfigurationProperty | undefined;
    private _lambdaConfig;
    get lambdaConfig(): TfUserPool.LambdaConfigPropertyOutputReference;
    putLambdaConfig(value: TfUserPool.LambdaConfigProperty): void;
    resetLambdaConfig(): void;
    get lambdaConfigInput(): TfUserPool.LambdaConfigProperty | undefined;
    private _passwordPolicy;
    get passwordPolicy(): TfUserPool.PasswordPolicyPropertyOutputReference;
    putPasswordPolicy(value: TfUserPool.PasswordPolicyProperty): void;
    resetPasswordPolicy(): void;
    get passwordPolicyInput(): TfUserPool.PasswordPolicyProperty | undefined;
    private _schema;
    get schema(): TfUserPool.SchemaPropertyList;
    putSchema(value: TfUserPool.SchemaProperty[] | cdktn.IResolvable): void;
    resetSchema(): void;
    get schemaInput(): cdktn.IResolvable | TfUserPool.SchemaProperty[] | undefined;
    private _signInPolicy;
    get signInPolicy(): TfUserPool.SignInPolicyPropertyOutputReference;
    putSignInPolicy(value: TfUserPool.SignInPolicyProperty): void;
    resetSignInPolicy(): void;
    get signInPolicyInput(): TfUserPool.SignInPolicyProperty | undefined;
    private _smsConfiguration;
    get smsConfiguration(): TfUserPool.SmsConfigurationPropertyOutputReference;
    putSmsConfiguration(value: TfUserPool.SmsConfigurationProperty): void;
    resetSmsConfiguration(): void;
    get smsConfigurationInput(): TfUserPool.SmsConfigurationProperty | undefined;
    private _softwareTokenMfaConfiguration;
    get softwareTokenMfaConfiguration(): TfUserPool.SoftwareTokenMfaConfigurationPropertyOutputReference;
    putSoftwareTokenMfaConfiguration(value: TfUserPool.SoftwareTokenMfaConfigurationProperty): void;
    resetSoftwareTokenMfaConfiguration(): void;
    get softwareTokenMfaConfigurationInput(): TfUserPool.SoftwareTokenMfaConfigurationProperty | undefined;
    private _userAttributeUpdateSettings;
    get userAttributeUpdateSettings(): TfUserPool.UserAttributeUpdateSettingsPropertyOutputReference;
    putUserAttributeUpdateSettings(value: TfUserPool.UserAttributeUpdateSettingsProperty): void;
    resetUserAttributeUpdateSettings(): void;
    get userAttributeUpdateSettingsInput(): TfUserPool.UserAttributeUpdateSettingsProperty | undefined;
    private _userPoolAddOns;
    get userPoolAddOns(): TfUserPool.UserPoolAddOnsPropertyOutputReference;
    putUserPoolAddOns(value: TfUserPool.UserPoolAddOnsProperty): void;
    resetUserPoolAddOns(): void;
    get userPoolAddOnsInput(): TfUserPool.UserPoolAddOnsProperty | undefined;
    private _usernameConfiguration;
    get usernameConfiguration(): TfUserPool.UsernameConfigurationPropertyOutputReference;
    putUsernameConfiguration(value: TfUserPool.UsernameConfigurationProperty): void;
    resetUsernameConfiguration(): void;
    get usernameConfigurationInput(): TfUserPool.UsernameConfigurationProperty | undefined;
    private _verificationMessageTemplate;
    get verificationMessageTemplate(): TfUserPool.VerificationMessageTemplatePropertyOutputReference;
    putVerificationMessageTemplate(value: TfUserPool.VerificationMessageTemplateProperty): void;
    resetVerificationMessageTemplate(): void;
    get verificationMessageTemplateInput(): TfUserPool.VerificationMessageTemplateProperty | undefined;
    private _webAuthnConfiguration;
    get webAuthnConfiguration(): TfUserPool.WebAuthnConfigurationPropertyOutputReference;
    putWebAuthnConfiguration(value: TfUserPool.WebAuthnConfigurationProperty): void;
    resetWebAuthnConfiguration(): void;
    get webAuthnConfigurationInput(): TfUserPool.WebAuthnConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfUserPoolRecoveryMechanismPropertyToTerraform(struct?: TfUserPool.RecoveryMechanismProperty | cdktn.IResolvable): any;
export declare function tfUserPoolRecoveryMechanismPropertyToHclTerraform(struct?: TfUserPool.RecoveryMechanismProperty | cdktn.IResolvable): any;
export declare function tfUserPoolAccountRecoverySettingPropertyToTerraform(struct?: TfUserPool.AccountRecoverySettingPropertyOutputReference | TfUserPool.AccountRecoverySettingProperty): any;
export declare function tfUserPoolAccountRecoverySettingPropertyToHclTerraform(struct?: TfUserPool.AccountRecoverySettingPropertyOutputReference | TfUserPool.AccountRecoverySettingProperty): any;
export declare function tfUserPoolInviteMessageTemplatePropertyToTerraform(struct?: TfUserPool.InviteMessageTemplatePropertyOutputReference | TfUserPool.InviteMessageTemplateProperty): any;
export declare function tfUserPoolInviteMessageTemplatePropertyToHclTerraform(struct?: TfUserPool.InviteMessageTemplatePropertyOutputReference | TfUserPool.InviteMessageTemplateProperty): any;
export declare function tfUserPoolAdminCreateUserConfigPropertyToTerraform(struct?: TfUserPool.AdminCreateUserConfigPropertyOutputReference | TfUserPool.AdminCreateUserConfigProperty): any;
export declare function tfUserPoolAdminCreateUserConfigPropertyToHclTerraform(struct?: TfUserPool.AdminCreateUserConfigPropertyOutputReference | TfUserPool.AdminCreateUserConfigProperty): any;
export declare function tfUserPoolDeviceConfigurationPropertyToTerraform(struct?: TfUserPool.DeviceConfigurationPropertyOutputReference | TfUserPool.DeviceConfigurationProperty): any;
export declare function tfUserPoolDeviceConfigurationPropertyToHclTerraform(struct?: TfUserPool.DeviceConfigurationPropertyOutputReference | TfUserPool.DeviceConfigurationProperty): any;
export declare function tfUserPoolEmailConfigurationPropertyToTerraform(struct?: TfUserPool.EmailConfigurationPropertyOutputReference | TfUserPool.EmailConfigurationProperty): any;
export declare function tfUserPoolEmailConfigurationPropertyToHclTerraform(struct?: TfUserPool.EmailConfigurationPropertyOutputReference | TfUserPool.EmailConfigurationProperty): any;
export declare function tfUserPoolEmailMfaConfigurationPropertyToTerraform(struct?: TfUserPool.EmailMfaConfigurationPropertyOutputReference | TfUserPool.EmailMfaConfigurationProperty): any;
export declare function tfUserPoolEmailMfaConfigurationPropertyToHclTerraform(struct?: TfUserPool.EmailMfaConfigurationPropertyOutputReference | TfUserPool.EmailMfaConfigurationProperty): any;
export declare function tfUserPoolCustomEmailSenderPropertyToTerraform(struct?: TfUserPool.CustomEmailSenderPropertyOutputReference | TfUserPool.CustomEmailSenderProperty): any;
export declare function tfUserPoolCustomEmailSenderPropertyToHclTerraform(struct?: TfUserPool.CustomEmailSenderPropertyOutputReference | TfUserPool.CustomEmailSenderProperty): any;
export declare function tfUserPoolCustomSmsSenderPropertyToTerraform(struct?: TfUserPool.CustomSmsSenderPropertyOutputReference | TfUserPool.CustomSmsSenderProperty): any;
export declare function tfUserPoolCustomSmsSenderPropertyToHclTerraform(struct?: TfUserPool.CustomSmsSenderPropertyOutputReference | TfUserPool.CustomSmsSenderProperty): any;
export declare function tfUserPoolPreTokenGenerationConfigPropertyToTerraform(struct?: TfUserPool.PreTokenGenerationConfigPropertyOutputReference | TfUserPool.PreTokenGenerationConfigProperty): any;
export declare function tfUserPoolPreTokenGenerationConfigPropertyToHclTerraform(struct?: TfUserPool.PreTokenGenerationConfigPropertyOutputReference | TfUserPool.PreTokenGenerationConfigProperty): any;
export declare function tfUserPoolLambdaConfigPropertyToTerraform(struct?: TfUserPool.LambdaConfigPropertyOutputReference | TfUserPool.LambdaConfigProperty): any;
export declare function tfUserPoolLambdaConfigPropertyToHclTerraform(struct?: TfUserPool.LambdaConfigPropertyOutputReference | TfUserPool.LambdaConfigProperty): any;
export declare function tfUserPoolPasswordPolicyPropertyToTerraform(struct?: TfUserPool.PasswordPolicyPropertyOutputReference | TfUserPool.PasswordPolicyProperty): any;
export declare function tfUserPoolPasswordPolicyPropertyToHclTerraform(struct?: TfUserPool.PasswordPolicyPropertyOutputReference | TfUserPool.PasswordPolicyProperty): any;
export declare function tfUserPoolNumberAttributeConstraintsPropertyToTerraform(struct?: TfUserPool.NumberAttributeConstraintsPropertyOutputReference | TfUserPool.NumberAttributeConstraintsProperty): any;
export declare function tfUserPoolNumberAttributeConstraintsPropertyToHclTerraform(struct?: TfUserPool.NumberAttributeConstraintsPropertyOutputReference | TfUserPool.NumberAttributeConstraintsProperty): any;
export declare function tfUserPoolStringAttributeConstraintsPropertyToTerraform(struct?: TfUserPool.StringAttributeConstraintsPropertyOutputReference | TfUserPool.StringAttributeConstraintsProperty): any;
export declare function tfUserPoolStringAttributeConstraintsPropertyToHclTerraform(struct?: TfUserPool.StringAttributeConstraintsPropertyOutputReference | TfUserPool.StringAttributeConstraintsProperty): any;
export declare function tfUserPoolSchemaPropertyToTerraform(struct?: TfUserPool.SchemaProperty | cdktn.IResolvable): any;
export declare function tfUserPoolSchemaPropertyToHclTerraform(struct?: TfUserPool.SchemaProperty | cdktn.IResolvable): any;
export declare function tfUserPoolSignInPolicyPropertyToTerraform(struct?: TfUserPool.SignInPolicyPropertyOutputReference | TfUserPool.SignInPolicyProperty): any;
export declare function tfUserPoolSignInPolicyPropertyToHclTerraform(struct?: TfUserPool.SignInPolicyPropertyOutputReference | TfUserPool.SignInPolicyProperty): any;
export declare function tfUserPoolSmsConfigurationPropertyToTerraform(struct?: TfUserPool.SmsConfigurationPropertyOutputReference | TfUserPool.SmsConfigurationProperty): any;
export declare function tfUserPoolSmsConfigurationPropertyToHclTerraform(struct?: TfUserPool.SmsConfigurationPropertyOutputReference | TfUserPool.SmsConfigurationProperty): any;
export declare function tfUserPoolSoftwareTokenMfaConfigurationPropertyToTerraform(struct?: TfUserPool.SoftwareTokenMfaConfigurationPropertyOutputReference | TfUserPool.SoftwareTokenMfaConfigurationProperty): any;
export declare function tfUserPoolSoftwareTokenMfaConfigurationPropertyToHclTerraform(struct?: TfUserPool.SoftwareTokenMfaConfigurationPropertyOutputReference | TfUserPool.SoftwareTokenMfaConfigurationProperty): any;
export declare function tfUserPoolUserAttributeUpdateSettingsPropertyToTerraform(struct?: TfUserPool.UserAttributeUpdateSettingsPropertyOutputReference | TfUserPool.UserAttributeUpdateSettingsProperty): any;
export declare function tfUserPoolUserAttributeUpdateSettingsPropertyToHclTerraform(struct?: TfUserPool.UserAttributeUpdateSettingsPropertyOutputReference | TfUserPool.UserAttributeUpdateSettingsProperty): any;
export declare function tfUserPoolAdvancedSecurityAdditionalFlowsPropertyToTerraform(struct?: TfUserPool.AdvancedSecurityAdditionalFlowsPropertyOutputReference | TfUserPool.AdvancedSecurityAdditionalFlowsProperty): any;
export declare function tfUserPoolAdvancedSecurityAdditionalFlowsPropertyToHclTerraform(struct?: TfUserPool.AdvancedSecurityAdditionalFlowsPropertyOutputReference | TfUserPool.AdvancedSecurityAdditionalFlowsProperty): any;
export declare function tfUserPoolUserPoolAddOnsPropertyToTerraform(struct?: TfUserPool.UserPoolAddOnsPropertyOutputReference | TfUserPool.UserPoolAddOnsProperty): any;
export declare function tfUserPoolUserPoolAddOnsPropertyToHclTerraform(struct?: TfUserPool.UserPoolAddOnsPropertyOutputReference | TfUserPool.UserPoolAddOnsProperty): any;
export declare function tfUserPoolUsernameConfigurationPropertyToTerraform(struct?: TfUserPool.UsernameConfigurationPropertyOutputReference | TfUserPool.UsernameConfigurationProperty): any;
export declare function tfUserPoolUsernameConfigurationPropertyToHclTerraform(struct?: TfUserPool.UsernameConfigurationPropertyOutputReference | TfUserPool.UsernameConfigurationProperty): any;
export declare function tfUserPoolVerificationMessageTemplatePropertyToTerraform(struct?: TfUserPool.VerificationMessageTemplatePropertyOutputReference | TfUserPool.VerificationMessageTemplateProperty): any;
export declare function tfUserPoolVerificationMessageTemplatePropertyToHclTerraform(struct?: TfUserPool.VerificationMessageTemplatePropertyOutputReference | TfUserPool.VerificationMessageTemplateProperty): any;
export declare function tfUserPoolWebAuthnConfigurationPropertyToTerraform(struct?: TfUserPool.WebAuthnConfigurationPropertyOutputReference | TfUserPool.WebAuthnConfigurationProperty): any;
export declare function tfUserPoolWebAuthnConfigurationPropertyToHclTerraform(struct?: TfUserPool.WebAuthnConfigurationPropertyOutputReference | TfUserPool.WebAuthnConfigurationProperty): any;
export declare namespace TfUserPool {
    interface RecoveryMechanismProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#name TfUserPool#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#priority TfUserPool#priority}
        */
        readonly priority: number;
    }
    class RecoveryMechanismPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RecoveryMechanismProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RecoveryMechanismProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _priority?;
        get priority(): number;
        set priority(value: number);
        get priorityInput(): number | undefined;
    }
    class RecoveryMechanismPropertyList extends cdktn.ComplexList {
        internalValue?: RecoveryMechanismProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RecoveryMechanismPropertyOutputReference;
    }
    interface AccountRecoverySettingProperty {
        /**
        * recovery_mechanism block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#recovery_mechanism TfUserPool#recovery_mechanism}
        */
        readonly recoveryMechanism?: RecoveryMechanismProperty[] | cdktn.IResolvable;
    }
    class AccountRecoverySettingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AccountRecoverySettingProperty | undefined;
        set internalValue(value: AccountRecoverySettingProperty | undefined);
        private _recoveryMechanism;
        get recoveryMechanism(): RecoveryMechanismPropertyList;
        putRecoveryMechanism(value: RecoveryMechanismProperty[] | cdktn.IResolvable): void;
        resetRecoveryMechanism(): void;
        get recoveryMechanismInput(): cdktn.IResolvable | RecoveryMechanismProperty[] | undefined;
    }
    interface InviteMessageTemplateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#email_message TfUserPool#email_message}
        */
        readonly emailMessage?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#email_subject TfUserPool#email_subject}
        */
        readonly emailSubject?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#sms_message TfUserPool#sms_message}
        */
        readonly smsMessage?: string;
    }
    class InviteMessageTemplatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InviteMessageTemplateProperty | undefined;
        set internalValue(value: InviteMessageTemplateProperty | undefined);
        private _emailMessage?;
        get emailMessage(): string;
        set emailMessage(value: string);
        resetEmailMessage(): void;
        get emailMessageInput(): string | undefined;
        private _emailSubject?;
        get emailSubject(): string;
        set emailSubject(value: string);
        resetEmailSubject(): void;
        get emailSubjectInput(): string | undefined;
        private _smsMessage?;
        get smsMessage(): string;
        set smsMessage(value: string);
        resetSmsMessage(): void;
        get smsMessageInput(): string | undefined;
    }
    interface AdminCreateUserConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#allow_admin_create_user_only TfUserPool#allow_admin_create_user_only}
        */
        readonly allowAdminCreateUserOnly?: boolean | cdktn.IResolvable;
        /**
        * invite_message_template block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#invite_message_template TfUserPool#invite_message_template}
        */
        readonly inviteMessageTemplate?: InviteMessageTemplateProperty;
    }
    class AdminCreateUserConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AdminCreateUserConfigProperty | undefined;
        set internalValue(value: AdminCreateUserConfigProperty | undefined);
        private _allowAdminCreateUserOnly?;
        get allowAdminCreateUserOnly(): boolean | cdktn.IResolvable;
        set allowAdminCreateUserOnly(value: boolean | cdktn.IResolvable);
        resetAllowAdminCreateUserOnly(): void;
        get allowAdminCreateUserOnlyInput(): boolean | cdktn.IResolvable | undefined;
        private _inviteMessageTemplate;
        get inviteMessageTemplate(): InviteMessageTemplatePropertyOutputReference;
        putInviteMessageTemplate(value: InviteMessageTemplateProperty): void;
        resetInviteMessageTemplate(): void;
        get inviteMessageTemplateInput(): InviteMessageTemplateProperty | undefined;
    }
    interface DeviceConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#challenge_required_on_new_device TfUserPool#challenge_required_on_new_device}
        */
        readonly challengeRequiredOnNewDevice?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#device_only_remembered_on_user_prompt TfUserPool#device_only_remembered_on_user_prompt}
        */
        readonly deviceOnlyRememberedOnUserPrompt?: boolean | cdktn.IResolvable;
    }
    class DeviceConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DeviceConfigurationProperty | undefined;
        set internalValue(value: DeviceConfigurationProperty | undefined);
        private _challengeRequiredOnNewDevice?;
        get challengeRequiredOnNewDevice(): boolean | cdktn.IResolvable;
        set challengeRequiredOnNewDevice(value: boolean | cdktn.IResolvable);
        resetChallengeRequiredOnNewDevice(): void;
        get challengeRequiredOnNewDeviceInput(): boolean | cdktn.IResolvable | undefined;
        private _deviceOnlyRememberedOnUserPrompt?;
        get deviceOnlyRememberedOnUserPrompt(): boolean | cdktn.IResolvable;
        set deviceOnlyRememberedOnUserPrompt(value: boolean | cdktn.IResolvable);
        resetDeviceOnlyRememberedOnUserPrompt(): void;
        get deviceOnlyRememberedOnUserPromptInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface EmailConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#configuration_set TfUserPool#configuration_set}
        */
        readonly configurationSet?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#email_sending_account TfUserPool#email_sending_account}
        */
        readonly emailSendingAccount?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#from_email_address TfUserPool#from_email_address}
        */
        readonly fromEmailAddress?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#reply_to_email_address TfUserPool#reply_to_email_address}
        */
        readonly replyToEmailAddress?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#source_arn TfUserPool#source_arn}
        */
        readonly sourceArn?: string;
    }
    class EmailConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EmailConfigurationProperty | undefined;
        set internalValue(value: EmailConfigurationProperty | undefined);
        private _configurationSet?;
        get configurationSet(): string;
        set configurationSet(value: string);
        resetConfigurationSet(): void;
        get configurationSetInput(): string | undefined;
        private _emailSendingAccount?;
        get emailSendingAccount(): string;
        set emailSendingAccount(value: string);
        resetEmailSendingAccount(): void;
        get emailSendingAccountInput(): string | undefined;
        private _fromEmailAddress?;
        get fromEmailAddress(): string;
        set fromEmailAddress(value: string);
        resetFromEmailAddress(): void;
        get fromEmailAddressInput(): string | undefined;
        private _replyToEmailAddress?;
        get replyToEmailAddress(): string;
        set replyToEmailAddress(value: string);
        resetReplyToEmailAddress(): void;
        get replyToEmailAddressInput(): string | undefined;
        private _sourceArn?;
        get sourceArn(): string;
        set sourceArn(value: string);
        resetSourceArn(): void;
        get sourceArnInput(): string | undefined;
    }
    interface EmailMfaConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#message TfUserPool#message}
        */
        readonly message?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#subject TfUserPool#subject}
        */
        readonly subject?: string;
    }
    class EmailMfaConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EmailMfaConfigurationProperty | undefined;
        set internalValue(value: EmailMfaConfigurationProperty | undefined);
        private _message?;
        get message(): string;
        set message(value: string);
        resetMessage(): void;
        get messageInput(): string | undefined;
        private _subject?;
        get subject(): string;
        set subject(value: string);
        resetSubject(): void;
        get subjectInput(): string | undefined;
    }
    interface CustomEmailSenderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#lambda_arn TfUserPool#lambda_arn}
        */
        readonly lambdaArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#lambda_version TfUserPool#lambda_version}
        */
        readonly lambdaVersion: string;
    }
    class CustomEmailSenderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CustomEmailSenderProperty | undefined;
        set internalValue(value: CustomEmailSenderProperty | undefined);
        private _lambdaArn?;
        get lambdaArn(): string;
        set lambdaArn(value: string);
        get lambdaArnInput(): string | undefined;
        private _lambdaVersion?;
        get lambdaVersion(): string;
        set lambdaVersion(value: string);
        get lambdaVersionInput(): string | undefined;
    }
    interface CustomSmsSenderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#lambda_arn TfUserPool#lambda_arn}
        */
        readonly lambdaArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#lambda_version TfUserPool#lambda_version}
        */
        readonly lambdaVersion: string;
    }
    class CustomSmsSenderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CustomSmsSenderProperty | undefined;
        set internalValue(value: CustomSmsSenderProperty | undefined);
        private _lambdaArn?;
        get lambdaArn(): string;
        set lambdaArn(value: string);
        get lambdaArnInput(): string | undefined;
        private _lambdaVersion?;
        get lambdaVersion(): string;
        set lambdaVersion(value: string);
        get lambdaVersionInput(): string | undefined;
    }
    interface PreTokenGenerationConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#lambda_arn TfUserPool#lambda_arn}
        */
        readonly lambdaArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#lambda_version TfUserPool#lambda_version}
        */
        readonly lambdaVersion: string;
    }
    class PreTokenGenerationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PreTokenGenerationConfigProperty | undefined;
        set internalValue(value: PreTokenGenerationConfigProperty | undefined);
        private _lambdaArn?;
        get lambdaArn(): string;
        set lambdaArn(value: string);
        get lambdaArnInput(): string | undefined;
        private _lambdaVersion?;
        get lambdaVersion(): string;
        set lambdaVersion(value: string);
        get lambdaVersionInput(): string | undefined;
    }
    interface LambdaConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#create_auth_challenge TfUserPool#create_auth_challenge}
        */
        readonly createAuthChallenge?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#custom_message TfUserPool#custom_message}
        */
        readonly customMessage?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#define_auth_challenge TfUserPool#define_auth_challenge}
        */
        readonly defineAuthChallenge?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#kms_key_id TfUserPool#kms_key_id}
        */
        readonly kmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#post_authentication TfUserPool#post_authentication}
        */
        readonly postAuthentication?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#post_confirmation TfUserPool#post_confirmation}
        */
        readonly postConfirmation?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#pre_authentication TfUserPool#pre_authentication}
        */
        readonly preAuthentication?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#pre_sign_up TfUserPool#pre_sign_up}
        */
        readonly preSignUp?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#pre_token_generation TfUserPool#pre_token_generation}
        */
        readonly preTokenGeneration?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#user_migration TfUserPool#user_migration}
        */
        readonly userMigration?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#verify_auth_challenge_response TfUserPool#verify_auth_challenge_response}
        */
        readonly verifyAuthChallengeResponse?: string;
        /**
        * custom_email_sender block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#custom_email_sender TfUserPool#custom_email_sender}
        */
        readonly customEmailSender?: CustomEmailSenderProperty;
        /**
        * custom_sms_sender block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#custom_sms_sender TfUserPool#custom_sms_sender}
        */
        readonly customSmsSender?: CustomSmsSenderProperty;
        /**
        * pre_token_generation_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#pre_token_generation_config TfUserPool#pre_token_generation_config}
        */
        readonly preTokenGenerationConfig?: PreTokenGenerationConfigProperty;
    }
    class LambdaConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LambdaConfigProperty | undefined;
        set internalValue(value: LambdaConfigProperty | undefined);
        private _createAuthChallenge?;
        get createAuthChallenge(): string;
        set createAuthChallenge(value: string);
        resetCreateAuthChallenge(): void;
        get createAuthChallengeInput(): string | undefined;
        private _customMessage?;
        get customMessage(): string;
        set customMessage(value: string);
        resetCustomMessage(): void;
        get customMessageInput(): string | undefined;
        private _defineAuthChallenge?;
        get defineAuthChallenge(): string;
        set defineAuthChallenge(value: string);
        resetDefineAuthChallenge(): void;
        get defineAuthChallengeInput(): string | undefined;
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
        private _postAuthentication?;
        get postAuthentication(): string;
        set postAuthentication(value: string);
        resetPostAuthentication(): void;
        get postAuthenticationInput(): string | undefined;
        private _postConfirmation?;
        get postConfirmation(): string;
        set postConfirmation(value: string);
        resetPostConfirmation(): void;
        get postConfirmationInput(): string | undefined;
        private _preAuthentication?;
        get preAuthentication(): string;
        set preAuthentication(value: string);
        resetPreAuthentication(): void;
        get preAuthenticationInput(): string | undefined;
        private _preSignUp?;
        get preSignUp(): string;
        set preSignUp(value: string);
        resetPreSignUp(): void;
        get preSignUpInput(): string | undefined;
        private _preTokenGeneration?;
        get preTokenGeneration(): string;
        set preTokenGeneration(value: string);
        resetPreTokenGeneration(): void;
        get preTokenGenerationInput(): string | undefined;
        private _userMigration?;
        get userMigration(): string;
        set userMigration(value: string);
        resetUserMigration(): void;
        get userMigrationInput(): string | undefined;
        private _verifyAuthChallengeResponse?;
        get verifyAuthChallengeResponse(): string;
        set verifyAuthChallengeResponse(value: string);
        resetVerifyAuthChallengeResponse(): void;
        get verifyAuthChallengeResponseInput(): string | undefined;
        private _customEmailSender;
        get customEmailSender(): CustomEmailSenderPropertyOutputReference;
        putCustomEmailSender(value: CustomEmailSenderProperty): void;
        resetCustomEmailSender(): void;
        get customEmailSenderInput(): CustomEmailSenderProperty | undefined;
        private _customSmsSender;
        get customSmsSender(): CustomSmsSenderPropertyOutputReference;
        putCustomSmsSender(value: CustomSmsSenderProperty): void;
        resetCustomSmsSender(): void;
        get customSmsSenderInput(): CustomSmsSenderProperty | undefined;
        private _preTokenGenerationConfig;
        get preTokenGenerationConfig(): PreTokenGenerationConfigPropertyOutputReference;
        putPreTokenGenerationConfig(value: PreTokenGenerationConfigProperty): void;
        resetPreTokenGenerationConfig(): void;
        get preTokenGenerationConfigInput(): PreTokenGenerationConfigProperty | undefined;
    }
    interface PasswordPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#minimum_length TfUserPool#minimum_length}
        */
        readonly minimumLength?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#password_history_size TfUserPool#password_history_size}
        */
        readonly passwordHistorySize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#require_lowercase TfUserPool#require_lowercase}
        */
        readonly requireLowercase?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#require_numbers TfUserPool#require_numbers}
        */
        readonly requireNumbers?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#require_symbols TfUserPool#require_symbols}
        */
        readonly requireSymbols?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#require_uppercase TfUserPool#require_uppercase}
        */
        readonly requireUppercase?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#temporary_password_validity_days TfUserPool#temporary_password_validity_days}
        */
        readonly temporaryPasswordValidityDays?: number;
    }
    class PasswordPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PasswordPolicyProperty | undefined;
        set internalValue(value: PasswordPolicyProperty | undefined);
        private _minimumLength?;
        get minimumLength(): number;
        set minimumLength(value: number);
        resetMinimumLength(): void;
        get minimumLengthInput(): number | undefined;
        private _passwordHistorySize?;
        get passwordHistorySize(): number;
        set passwordHistorySize(value: number);
        resetPasswordHistorySize(): void;
        get passwordHistorySizeInput(): number | undefined;
        private _requireLowercase?;
        get requireLowercase(): boolean | cdktn.IResolvable;
        set requireLowercase(value: boolean | cdktn.IResolvable);
        resetRequireLowercase(): void;
        get requireLowercaseInput(): boolean | cdktn.IResolvable | undefined;
        private _requireNumbers?;
        get requireNumbers(): boolean | cdktn.IResolvable;
        set requireNumbers(value: boolean | cdktn.IResolvable);
        resetRequireNumbers(): void;
        get requireNumbersInput(): boolean | cdktn.IResolvable | undefined;
        private _requireSymbols?;
        get requireSymbols(): boolean | cdktn.IResolvable;
        set requireSymbols(value: boolean | cdktn.IResolvable);
        resetRequireSymbols(): void;
        get requireSymbolsInput(): boolean | cdktn.IResolvable | undefined;
        private _requireUppercase?;
        get requireUppercase(): boolean | cdktn.IResolvable;
        set requireUppercase(value: boolean | cdktn.IResolvable);
        resetRequireUppercase(): void;
        get requireUppercaseInput(): boolean | cdktn.IResolvable | undefined;
        private _temporaryPasswordValidityDays?;
        get temporaryPasswordValidityDays(): number;
        set temporaryPasswordValidityDays(value: number);
        resetTemporaryPasswordValidityDays(): void;
        get temporaryPasswordValidityDaysInput(): number | undefined;
    }
    interface NumberAttributeConstraintsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#max_value TfUserPool#max_value}
        */
        readonly maxValue?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#min_value TfUserPool#min_value}
        */
        readonly minValue?: string;
    }
    class NumberAttributeConstraintsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NumberAttributeConstraintsProperty | undefined;
        set internalValue(value: NumberAttributeConstraintsProperty | undefined);
        private _maxValue?;
        get maxValue(): string;
        set maxValue(value: string);
        resetMaxValue(): void;
        get maxValueInput(): string | undefined;
        private _minValue?;
        get minValue(): string;
        set minValue(value: string);
        resetMinValue(): void;
        get minValueInput(): string | undefined;
    }
    interface StringAttributeConstraintsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#max_length TfUserPool#max_length}
        */
        readonly maxLength?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#min_length TfUserPool#min_length}
        */
        readonly minLength?: string;
    }
    class StringAttributeConstraintsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StringAttributeConstraintsProperty | undefined;
        set internalValue(value: StringAttributeConstraintsProperty | undefined);
        private _maxLength?;
        get maxLength(): string;
        set maxLength(value: string);
        resetMaxLength(): void;
        get maxLengthInput(): string | undefined;
        private _minLength?;
        get minLength(): string;
        set minLength(value: string);
        resetMinLength(): void;
        get minLengthInput(): string | undefined;
    }
    interface SchemaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#attribute_data_type TfUserPool#attribute_data_type}
        */
        readonly attributeDataType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#developer_only_attribute TfUserPool#developer_only_attribute}
        */
        readonly developerOnlyAttribute?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#mutable TfUserPool#mutable}
        */
        readonly mutable?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#name TfUserPool#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#required TfUserPool#required}
        */
        readonly required?: boolean | cdktn.IResolvable;
        /**
        * number_attribute_constraints block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#number_attribute_constraints TfUserPool#number_attribute_constraints}
        */
        readonly numberAttributeConstraints?: NumberAttributeConstraintsProperty;
        /**
        * string_attribute_constraints block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#string_attribute_constraints TfUserPool#string_attribute_constraints}
        */
        readonly stringAttributeConstraints?: StringAttributeConstraintsProperty;
    }
    class SchemaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SchemaProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SchemaProperty | cdktn.IResolvable | undefined);
        private _attributeDataType?;
        get attributeDataType(): string;
        set attributeDataType(value: string);
        get attributeDataTypeInput(): string | undefined;
        private _developerOnlyAttribute?;
        get developerOnlyAttribute(): boolean | cdktn.IResolvable;
        set developerOnlyAttribute(value: boolean | cdktn.IResolvable);
        resetDeveloperOnlyAttribute(): void;
        get developerOnlyAttributeInput(): boolean | cdktn.IResolvable | undefined;
        private _mutable?;
        get mutable(): boolean | cdktn.IResolvable;
        set mutable(value: boolean | cdktn.IResolvable);
        resetMutable(): void;
        get mutableInput(): boolean | cdktn.IResolvable | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _required?;
        get required(): boolean | cdktn.IResolvable;
        set required(value: boolean | cdktn.IResolvable);
        resetRequired(): void;
        get requiredInput(): boolean | cdktn.IResolvable | undefined;
        private _numberAttributeConstraints;
        get numberAttributeConstraints(): NumberAttributeConstraintsPropertyOutputReference;
        putNumberAttributeConstraints(value: NumberAttributeConstraintsProperty): void;
        resetNumberAttributeConstraints(): void;
        get numberAttributeConstraintsInput(): NumberAttributeConstraintsProperty | undefined;
        private _stringAttributeConstraints;
        get stringAttributeConstraints(): StringAttributeConstraintsPropertyOutputReference;
        putStringAttributeConstraints(value: StringAttributeConstraintsProperty): void;
        resetStringAttributeConstraints(): void;
        get stringAttributeConstraintsInput(): StringAttributeConstraintsProperty | undefined;
    }
    class SchemaPropertyList extends cdktn.ComplexList {
        internalValue?: SchemaProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SchemaPropertyOutputReference;
    }
    interface SignInPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#allowed_first_auth_factors TfUserPool#allowed_first_auth_factors}
        */
        readonly allowedFirstAuthFactors?: string[];
    }
    class SignInPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SignInPolicyProperty | undefined;
        set internalValue(value: SignInPolicyProperty | undefined);
        private _allowedFirstAuthFactors?;
        get allowedFirstAuthFactors(): string[];
        set allowedFirstAuthFactors(value: string[]);
        resetAllowedFirstAuthFactors(): void;
        get allowedFirstAuthFactorsInput(): string[] | undefined;
    }
    interface SmsConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#external_id TfUserPool#external_id}
        */
        readonly externalId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#sns_caller_arn TfUserPool#sns_caller_arn}
        */
        readonly snsCallerArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#sns_region TfUserPool#sns_region}
        */
        readonly snsRegion?: string;
    }
    class SmsConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SmsConfigurationProperty | undefined;
        set internalValue(value: SmsConfigurationProperty | undefined);
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        get externalIdInput(): string | undefined;
        private _snsCallerArn?;
        get snsCallerArn(): string;
        set snsCallerArn(value: string);
        get snsCallerArnInput(): string | undefined;
        private _snsRegion?;
        get snsRegion(): string;
        set snsRegion(value: string);
        resetSnsRegion(): void;
        get snsRegionInput(): string | undefined;
    }
    interface SoftwareTokenMfaConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#enabled TfUserPool#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
    }
    class SoftwareTokenMfaConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SoftwareTokenMfaConfigurationProperty | undefined;
        set internalValue(value: SoftwareTokenMfaConfigurationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface UserAttributeUpdateSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#attributes_require_verification_before_update TfUserPool#attributes_require_verification_before_update}
        */
        readonly attributesRequireVerificationBeforeUpdate: string[];
    }
    class UserAttributeUpdateSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UserAttributeUpdateSettingsProperty | undefined;
        set internalValue(value: UserAttributeUpdateSettingsProperty | undefined);
        private _attributesRequireVerificationBeforeUpdate?;
        get attributesRequireVerificationBeforeUpdate(): string[];
        set attributesRequireVerificationBeforeUpdate(value: string[]);
        get attributesRequireVerificationBeforeUpdateInput(): string[] | undefined;
    }
    interface AdvancedSecurityAdditionalFlowsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#custom_auth_mode TfUserPool#custom_auth_mode}
        */
        readonly customAuthMode?: string;
    }
    class AdvancedSecurityAdditionalFlowsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AdvancedSecurityAdditionalFlowsProperty | undefined;
        set internalValue(value: AdvancedSecurityAdditionalFlowsProperty | undefined);
        private _customAuthMode?;
        get customAuthMode(): string;
        set customAuthMode(value: string);
        resetCustomAuthMode(): void;
        get customAuthModeInput(): string | undefined;
    }
    interface UserPoolAddOnsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#advanced_security_mode TfUserPool#advanced_security_mode}
        */
        readonly advancedSecurityMode: string;
        /**
        * advanced_security_additional_flows block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#advanced_security_additional_flows TfUserPool#advanced_security_additional_flows}
        */
        readonly advancedSecurityAdditionalFlows?: AdvancedSecurityAdditionalFlowsProperty;
    }
    class UserPoolAddOnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UserPoolAddOnsProperty | undefined;
        set internalValue(value: UserPoolAddOnsProperty | undefined);
        private _advancedSecurityMode?;
        get advancedSecurityMode(): string;
        set advancedSecurityMode(value: string);
        get advancedSecurityModeInput(): string | undefined;
        private _advancedSecurityAdditionalFlows;
        get advancedSecurityAdditionalFlows(): AdvancedSecurityAdditionalFlowsPropertyOutputReference;
        putAdvancedSecurityAdditionalFlows(value: AdvancedSecurityAdditionalFlowsProperty): void;
        resetAdvancedSecurityAdditionalFlows(): void;
        get advancedSecurityAdditionalFlowsInput(): AdvancedSecurityAdditionalFlowsProperty | undefined;
    }
    interface UsernameConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#case_sensitive TfUserPool#case_sensitive}
        */
        readonly caseSensitive?: boolean | cdktn.IResolvable;
    }
    class UsernameConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UsernameConfigurationProperty | undefined;
        set internalValue(value: UsernameConfigurationProperty | undefined);
        private _caseSensitive?;
        get caseSensitive(): boolean | cdktn.IResolvable;
        set caseSensitive(value: boolean | cdktn.IResolvable);
        resetCaseSensitive(): void;
        get caseSensitiveInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface VerificationMessageTemplateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#default_email_option TfUserPool#default_email_option}
        */
        readonly defaultEmailOption?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#email_message TfUserPool#email_message}
        */
        readonly emailMessage?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#email_message_by_link TfUserPool#email_message_by_link}
        */
        readonly emailMessageByLink?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#email_subject TfUserPool#email_subject}
        */
        readonly emailSubject?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#email_subject_by_link TfUserPool#email_subject_by_link}
        */
        readonly emailSubjectByLink?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#sms_message TfUserPool#sms_message}
        */
        readonly smsMessage?: string;
    }
    class VerificationMessageTemplatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VerificationMessageTemplateProperty | undefined;
        set internalValue(value: VerificationMessageTemplateProperty | undefined);
        private _defaultEmailOption?;
        get defaultEmailOption(): string;
        set defaultEmailOption(value: string);
        resetDefaultEmailOption(): void;
        get defaultEmailOptionInput(): string | undefined;
        private _emailMessage?;
        get emailMessage(): string;
        set emailMessage(value: string);
        resetEmailMessage(): void;
        get emailMessageInput(): string | undefined;
        private _emailMessageByLink?;
        get emailMessageByLink(): string;
        set emailMessageByLink(value: string);
        resetEmailMessageByLink(): void;
        get emailMessageByLinkInput(): string | undefined;
        private _emailSubject?;
        get emailSubject(): string;
        set emailSubject(value: string);
        resetEmailSubject(): void;
        get emailSubjectInput(): string | undefined;
        private _emailSubjectByLink?;
        get emailSubjectByLink(): string;
        set emailSubjectByLink(value: string);
        resetEmailSubjectByLink(): void;
        get emailSubjectByLinkInput(): string | undefined;
        private _smsMessage?;
        get smsMessage(): string;
        set smsMessage(value: string);
        resetSmsMessage(): void;
        get smsMessageInput(): string | undefined;
    }
    interface WebAuthnConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#relying_party_id TfUserPool#relying_party_id}
        */
        readonly relyingPartyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#user_verification TfUserPool#user_verification}
        */
        readonly userVerification?: string;
    }
    class WebAuthnConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): WebAuthnConfigurationProperty | undefined;
        set internalValue(value: WebAuthnConfigurationProperty | undefined);
        private _relyingPartyId?;
        get relyingPartyId(): string;
        set relyingPartyId(value: string);
        resetRelyingPartyId(): void;
        get relyingPartyIdInput(): string | undefined;
        private _userVerification?;
        get userVerification(): string;
        set userVerification(value: string);
        resetUserVerification(): void;
        get userVerificationInput(): string | undefined;
    }
}
