import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfResourceServerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_resource_server#id TfResourceServer#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_resource_server#identifier TfResourceServer#identifier}
    */
    readonly identifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_resource_server#name TfResourceServer#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_resource_server#region TfResourceServer#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_resource_server#user_pool_id TfResourceServer#user_pool_id}
    */
    readonly userPoolId: string;
    /**
    * scope block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_resource_server#scope TfResourceServer#scope}
    */
    readonly scope?: TfResourceServer.ScopeProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_resource_server aws_cognito_resource_server}
*/
export declare class TfResourceServer extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cognito_resource_server";
    /**
    * Generates CDKTN code for importing a TfResourceServer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfResourceServer to import
    * @param importFromId The id of the existing TfResourceServer that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_resource_server#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfResourceServer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_resource_server aws_cognito_resource_server} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfResourceServerConfig
    */
    constructor(scope: Construct, id: string, config: TfResourceServerConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identifier?;
    get identifier(): string;
    set identifier(value: string);
    get identifierInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get scopeIdentifiers(): string[];
    private _userPoolId?;
    get userPoolId(): string;
    set userPoolId(value: string);
    get userPoolIdInput(): string | undefined;
    private _scope;
    get scope(): TfResourceServer.ScopePropertyList;
    putScope(value: TfResourceServer.ScopeProperty[] | cdktn.IResolvable): void;
    resetScope(): void;
    get scopeInput(): cdktn.IResolvable | TfResourceServer.ScopeProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfResourceServerScopePropertyToTerraform(struct?: TfResourceServer.ScopeProperty | cdktn.IResolvable): any;
export declare function tfResourceServerScopePropertyToHclTerraform(struct?: TfResourceServer.ScopeProperty | cdktn.IResolvable): any;
export declare namespace TfResourceServer {
    interface ScopeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_resource_server#scope_description TfResourceServer#scope_description}
        */
        readonly scopeDescription: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_resource_server#scope_name TfResourceServer#scope_name}
        */
        readonly scopeName: string;
    }
    class ScopePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ScopeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ScopeProperty | cdktn.IResolvable | undefined);
        private _scopeDescription?;
        get scopeDescription(): string;
        set scopeDescription(value: string);
        get scopeDescriptionInput(): string | undefined;
        private _scopeName?;
        get scopeName(): string;
        set scopeName(value: string);
        get scopeNameInput(): string | undefined;
    }
    class ScopePropertyList extends cdktn.ComplexList {
        internalValue?: ScopeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ScopePropertyOutputReference;
    }
}
