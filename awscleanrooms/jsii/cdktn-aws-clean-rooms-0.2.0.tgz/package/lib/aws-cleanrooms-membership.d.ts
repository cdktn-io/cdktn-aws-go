import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfMembershipConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_membership#collaboration_id TfMembership#collaboration_id}
    */
    readonly collaborationId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_membership#query_log_status TfMembership#query_log_status}
    */
    readonly queryLogStatus: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_membership#region TfMembership#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_membership#tags TfMembership#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * default_result_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_membership#default_result_configuration TfMembership#default_result_configuration}
    */
    readonly defaultResultConfiguration?: TfMembership.DefaultResultConfigurationProperty[] | cdktn.IResolvable;
    /**
    * payment_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_membership#payment_configuration TfMembership#payment_configuration}
    */
    readonly paymentConfiguration?: TfMembership.PaymentConfigurationProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_membership aws_cleanrooms_membership}
*/
export declare class TfMembership extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cleanrooms_membership";
    /**
    * Generates CDKTN code for importing a TfMembership resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfMembership to import
    * @param importFromId The id of the existing TfMembership that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_membership#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfMembership to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_membership aws_cleanrooms_membership} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfMembershipConfig
    */
    constructor(scope: Construct, id: string, config: TfMembershipConfig);
    get arn(): string;
    get collaborationArn(): string;
    get collaborationCreatorAccountId(): string;
    get collaborationCreatorDisplayName(): string;
    private _collaborationId?;
    get collaborationId(): string;
    set collaborationId(value: string);
    get collaborationIdInput(): string | undefined;
    get collaborationName(): string;
    get createTime(): string;
    get id(): string;
    get memberAbilities(): string[];
    private _queryLogStatus?;
    get queryLogStatus(): string;
    set queryLogStatus(value: string);
    get queryLogStatusInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    get updateTime(): string;
    private _defaultResultConfiguration;
    get defaultResultConfiguration(): TfMembership.DefaultResultConfigurationPropertyList;
    putDefaultResultConfiguration(value: TfMembership.DefaultResultConfigurationProperty[] | cdktn.IResolvable): void;
    resetDefaultResultConfiguration(): void;
    get defaultResultConfigurationInput(): cdktn.IResolvable | TfMembership.DefaultResultConfigurationProperty[] | undefined;
    private _paymentConfiguration;
    get paymentConfiguration(): TfMembership.PaymentConfigurationPropertyList;
    putPaymentConfiguration(value: TfMembership.PaymentConfigurationProperty[] | cdktn.IResolvable): void;
    resetPaymentConfiguration(): void;
    get paymentConfigurationInput(): cdktn.IResolvable | TfMembership.PaymentConfigurationProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfMembershipS3PropertyToTerraform(struct?: TfMembership.S3Property | cdktn.IResolvable): any;
export declare function tfMembershipS3PropertyToHclTerraform(struct?: TfMembership.S3Property | cdktn.IResolvable): any;
export declare function tfMembershipOutputConfigurationPropertyToTerraform(struct?: TfMembership.OutputConfigurationProperty | cdktn.IResolvable): any;
export declare function tfMembershipOutputConfigurationPropertyToHclTerraform(struct?: TfMembership.OutputConfigurationProperty | cdktn.IResolvable): any;
export declare function tfMembershipDefaultResultConfigurationPropertyToTerraform(struct?: TfMembership.DefaultResultConfigurationProperty | cdktn.IResolvable): any;
export declare function tfMembershipDefaultResultConfigurationPropertyToHclTerraform(struct?: TfMembership.DefaultResultConfigurationProperty | cdktn.IResolvable): any;
export declare function tfMembershipQueryComputePropertyToTerraform(struct?: TfMembership.QueryComputeProperty | cdktn.IResolvable): any;
export declare function tfMembershipQueryComputePropertyToHclTerraform(struct?: TfMembership.QueryComputeProperty | cdktn.IResolvable): any;
export declare function tfMembershipPaymentConfigurationPropertyToTerraform(struct?: TfMembership.PaymentConfigurationProperty | cdktn.IResolvable): any;
export declare function tfMembershipPaymentConfigurationPropertyToHclTerraform(struct?: TfMembership.PaymentConfigurationProperty | cdktn.IResolvable): any;
export declare namespace TfMembership {
    interface S3Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_membership#bucket TfMembership#bucket}
        */
        readonly bucket: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_membership#key_prefix TfMembership#key_prefix}
        */
        readonly keyPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_membership#result_format TfMembership#result_format}
        */
        readonly resultFormat: string;
    }
    class S3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3Property | cdktn.IResolvable | undefined;
        set internalValue(value: S3Property | cdktn.IResolvable | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        get bucketInput(): string | undefined;
        private _keyPrefix?;
        get keyPrefix(): string;
        set keyPrefix(value: string);
        resetKeyPrefix(): void;
        get keyPrefixInput(): string | undefined;
        private _resultFormat?;
        get resultFormat(): string;
        set resultFormat(value: string);
        get resultFormatInput(): string | undefined;
    }
    class S3PropertyList extends cdktn.ComplexList {
        internalValue?: S3Property[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3PropertyOutputReference;
    }
    interface OutputConfigurationProperty {
        /**
        * s3 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_membership#s3 TfMembership#s3}
        */
        readonly s3?: S3Property[] | cdktn.IResolvable;
    }
    class OutputConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OutputConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OutputConfigurationProperty | cdktn.IResolvable | undefined);
        private _s3;
        get s3(): S3PropertyList;
        putS3(value: S3Property[] | cdktn.IResolvable): void;
        resetS3(): void;
        get s3Input(): cdktn.IResolvable | S3Property[] | undefined;
    }
    class OutputConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: OutputConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OutputConfigurationPropertyOutputReference;
    }
    interface DefaultResultConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_membership#role_arn TfMembership#role_arn}
        */
        readonly roleArn?: string;
        /**
        * output_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_membership#output_configuration TfMembership#output_configuration}
        */
        readonly outputConfiguration?: OutputConfigurationProperty[] | cdktn.IResolvable;
    }
    class DefaultResultConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DefaultResultConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DefaultResultConfigurationProperty | cdktn.IResolvable | undefined);
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        resetRoleArn(): void;
        get roleArnInput(): string | undefined;
        private _outputConfiguration;
        get outputConfiguration(): OutputConfigurationPropertyList;
        putOutputConfiguration(value: OutputConfigurationProperty[] | cdktn.IResolvable): void;
        resetOutputConfiguration(): void;
        get outputConfigurationInput(): cdktn.IResolvable | OutputConfigurationProperty[] | undefined;
    }
    class DefaultResultConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: DefaultResultConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DefaultResultConfigurationPropertyOutputReference;
    }
    interface QueryComputeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_membership#is_responsible TfMembership#is_responsible}
        */
        readonly isResponsible: boolean | cdktn.IResolvable;
    }
    class QueryComputePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): QueryComputeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: QueryComputeProperty | cdktn.IResolvable | undefined);
        private _isResponsible?;
        get isResponsible(): boolean | cdktn.IResolvable;
        set isResponsible(value: boolean | cdktn.IResolvable);
        get isResponsibleInput(): boolean | cdktn.IResolvable | undefined;
    }
    class QueryComputePropertyList extends cdktn.ComplexList {
        internalValue?: QueryComputeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): QueryComputePropertyOutputReference;
    }
    interface PaymentConfigurationProperty {
        /**
        * query_compute block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_membership#query_compute TfMembership#query_compute}
        */
        readonly queryCompute?: QueryComputeProperty[] | cdktn.IResolvable;
    }
    class PaymentConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PaymentConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PaymentConfigurationProperty | cdktn.IResolvable | undefined);
        private _queryCompute;
        get queryCompute(): QueryComputePropertyList;
        putQueryCompute(value: QueryComputeProperty[] | cdktn.IResolvable): void;
        resetQueryCompute(): void;
        get queryComputeInput(): cdktn.IResolvable | QueryComputeProperty[] | undefined;
    }
    class PaymentConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: PaymentConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PaymentConfigurationPropertyOutputReference;
    }
}
