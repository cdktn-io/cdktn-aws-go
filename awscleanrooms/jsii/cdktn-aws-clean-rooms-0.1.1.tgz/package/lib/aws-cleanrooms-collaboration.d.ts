import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsCleanroomsCollaborationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_collaboration#analytics_engine AwsCleanroomsCollaboration#analytics_engine}
    */
    readonly analyticsEngine?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_collaboration#creator_display_name AwsCleanroomsCollaboration#creator_display_name}
    */
    readonly creatorDisplayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_collaboration#creator_member_abilities AwsCleanroomsCollaboration#creator_member_abilities}
    */
    readonly creatorMemberAbilities: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_collaboration#description AwsCleanroomsCollaboration#description}
    */
    readonly description: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_collaboration#name AwsCleanroomsCollaboration#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_collaboration#query_log_status AwsCleanroomsCollaboration#query_log_status}
    */
    readonly queryLogStatus: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_collaboration#region AwsCleanroomsCollaboration#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_collaboration#tags AwsCleanroomsCollaboration#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_collaboration#tags_all AwsCleanroomsCollaboration#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * data_encryption_metadata block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_collaboration#data_encryption_metadata AwsCleanroomsCollaboration#data_encryption_metadata}
    */
    readonly dataEncryptionMetadata?: AwsCleanroomsCollaboration.DataEncryptionMetadataProperty;
    /**
    * member block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_collaboration#member AwsCleanroomsCollaboration#member}
    */
    readonly member?: AwsCleanroomsCollaboration.MemberProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_collaboration#timeouts AwsCleanroomsCollaboration#timeouts}
    */
    readonly timeouts?: AwsCleanroomsCollaboration.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_collaboration aws_cleanrooms_collaboration}
*/
export declare class AwsCleanroomsCollaboration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cleanrooms_collaboration";
    /**
    * Generates CDKTN code for importing a AwsCleanroomsCollaboration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCleanroomsCollaboration to import
    * @param importFromId The id of the existing AwsCleanroomsCollaboration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_collaboration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCleanroomsCollaboration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_collaboration aws_cleanrooms_collaboration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsCleanroomsCollaborationConfig
    */
    constructor(scope: Construct, id: string, config: AwsCleanroomsCollaborationConfig);
    private _analyticsEngine?;
    get analyticsEngine(): string;
    set analyticsEngine(value: string);
    resetAnalyticsEngine(): void;
    get analyticsEngineInput(): string | undefined;
    get arn(): string;
    get createTime(): string;
    private _creatorDisplayName?;
    get creatorDisplayName(): string;
    set creatorDisplayName(value: string);
    get creatorDisplayNameInput(): string | undefined;
    private _creatorMemberAbilities?;
    get creatorMemberAbilities(): string[];
    set creatorMemberAbilities(value: string[]);
    get creatorMemberAbilitiesInput(): string[] | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _queryLogStatus?;
    get queryLogStatus(): string;
    set queryLogStatus(value: string);
    get queryLogStatusInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get updateTime(): string;
    private _dataEncryptionMetadata;
    get dataEncryptionMetadata(): AwsCleanroomsCollaboration.DataEncryptionMetadataPropertyOutputReference;
    putDataEncryptionMetadata(value: AwsCleanroomsCollaboration.DataEncryptionMetadataProperty): void;
    resetDataEncryptionMetadata(): void;
    get dataEncryptionMetadataInput(): AwsCleanroomsCollaboration.DataEncryptionMetadataProperty | undefined;
    private _member;
    get member(): AwsCleanroomsCollaboration.MemberPropertyList;
    putMember(value: AwsCleanroomsCollaboration.MemberProperty[] | cdktn.IResolvable): void;
    resetMember(): void;
    get memberInput(): cdktn.IResolvable | AwsCleanroomsCollaboration.MemberProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsCleanroomsCollaboration.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsCleanroomsCollaboration.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsCleanroomsCollaboration.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsCleanroomsCollaborationDataEncryptionMetadataPropertyToTerraform(struct?: AwsCleanroomsCollaboration.DataEncryptionMetadataPropertyOutputReference | AwsCleanroomsCollaboration.DataEncryptionMetadataProperty): any;
export declare function awsCleanroomsCollaborationDataEncryptionMetadataPropertyToHclTerraform(struct?: AwsCleanroomsCollaboration.DataEncryptionMetadataPropertyOutputReference | AwsCleanroomsCollaboration.DataEncryptionMetadataProperty): any;
export declare function awsCleanroomsCollaborationMemberPropertyToTerraform(struct?: AwsCleanroomsCollaboration.MemberProperty | cdktn.IResolvable): any;
export declare function awsCleanroomsCollaborationMemberPropertyToHclTerraform(struct?: AwsCleanroomsCollaboration.MemberProperty | cdktn.IResolvable): any;
export declare function awsCleanroomsCollaborationTimeoutsPropertyToTerraform(struct?: AwsCleanroomsCollaboration.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsCleanroomsCollaborationTimeoutsPropertyToHclTerraform(struct?: AwsCleanroomsCollaboration.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsCleanroomsCollaboration {
    interface DataEncryptionMetadataProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_collaboration#allow_clear_text AwsCleanroomsCollaboration#allow_clear_text}
        */
        readonly allowClearText: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_collaboration#allow_duplicates AwsCleanroomsCollaboration#allow_duplicates}
        */
        readonly allowDuplicates: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_collaboration#allow_joins_on_columns_with_different_names AwsCleanroomsCollaboration#allow_joins_on_columns_with_different_names}
        */
        readonly allowJoinsOnColumnsWithDifferentNames: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_collaboration#preserve_nulls AwsCleanroomsCollaboration#preserve_nulls}
        */
        readonly preserveNulls: boolean | cdktn.IResolvable;
    }
    class DataEncryptionMetadataPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DataEncryptionMetadataProperty | undefined;
        set internalValue(value: DataEncryptionMetadataProperty | undefined);
        private _allowClearText?;
        get allowClearText(): boolean | cdktn.IResolvable;
        set allowClearText(value: boolean | cdktn.IResolvable);
        get allowClearTextInput(): boolean | cdktn.IResolvable | undefined;
        private _allowDuplicates?;
        get allowDuplicates(): boolean | cdktn.IResolvable;
        set allowDuplicates(value: boolean | cdktn.IResolvable);
        get allowDuplicatesInput(): boolean | cdktn.IResolvable | undefined;
        private _allowJoinsOnColumnsWithDifferentNames?;
        get allowJoinsOnColumnsWithDifferentNames(): boolean | cdktn.IResolvable;
        set allowJoinsOnColumnsWithDifferentNames(value: boolean | cdktn.IResolvable);
        get allowJoinsOnColumnsWithDifferentNamesInput(): boolean | cdktn.IResolvable | undefined;
        private _preserveNulls?;
        get preserveNulls(): boolean | cdktn.IResolvable;
        set preserveNulls(value: boolean | cdktn.IResolvable);
        get preserveNullsInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface MemberProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_collaboration#account_id AwsCleanroomsCollaboration#account_id}
        */
        readonly accountId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_collaboration#display_name AwsCleanroomsCollaboration#display_name}
        */
        readonly displayName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_collaboration#member_abilities AwsCleanroomsCollaboration#member_abilities}
        */
        readonly memberAbilities: string[];
    }
    class MemberPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MemberProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MemberProperty | cdktn.IResolvable | undefined);
        private _accountId?;
        get accountId(): string;
        set accountId(value: string);
        get accountIdInput(): string | undefined;
        private _displayName?;
        get displayName(): string;
        set displayName(value: string);
        get displayNameInput(): string | undefined;
        private _memberAbilities?;
        get memberAbilities(): string[];
        set memberAbilities(value: string[]);
        get memberAbilitiesInput(): string[] | undefined;
        get status(): string;
    }
    class MemberPropertyList extends cdktn.ComplexList {
        internalValue?: MemberProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MemberPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_collaboration#create AwsCleanroomsCollaboration#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_collaboration#delete AwsCleanroomsCollaboration#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cleanrooms_collaboration#update AwsCleanroomsCollaboration#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
