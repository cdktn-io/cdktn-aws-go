import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSecuritylakeCustomLogSourceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_custom_log_source#event_classes AwsSecuritylakeCustomLogSource#event_classes}
    */
    readonly eventClasses?: string[];
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_custom_log_source#region AwsSecuritylakeCustomLogSource#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_custom_log_source#source_name AwsSecuritylakeCustomLogSource#source_name}
    */
    readonly sourceName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_custom_log_source#source_version AwsSecuritylakeCustomLogSource#source_version}
    */
    readonly sourceVersion?: string;
    /**
    * configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_custom_log_source#configuration AwsSecuritylakeCustomLogSource#configuration}
    */
    readonly configuration?: AwsSecuritylakeCustomLogSource.ConfigurationProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_custom_log_source aws_securitylake_custom_log_source}
*/
export declare class AwsSecuritylakeCustomLogSource extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_securitylake_custom_log_source";
    /**
    * Generates CDKTN code for importing a AwsSecuritylakeCustomLogSource resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSecuritylakeCustomLogSource to import
    * @param importFromId The id of the existing AwsSecuritylakeCustomLogSource that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_custom_log_source#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSecuritylakeCustomLogSource to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_custom_log_source aws_securitylake_custom_log_source} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSecuritylakeCustomLogSourceConfig
    */
    constructor(scope: Construct, id: string, config: AwsSecuritylakeCustomLogSourceConfig);
    private _attributes;
    get attributes(): AwsSecuritylakeCustomLogSource.AttributesPropertyList;
    private _eventClasses?;
    get eventClasses(): string[];
    set eventClasses(value: string[]);
    resetEventClasses(): void;
    get eventClassesInput(): string[] | undefined;
    get id(): string;
    private _providerDetails;
    get providerDetails(): AwsSecuritylakeCustomLogSource.ProviderDetailsPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _sourceName?;
    get sourceName(): string;
    set sourceName(value: string);
    get sourceNameInput(): string | undefined;
    private _sourceVersion?;
    get sourceVersion(): string;
    set sourceVersion(value: string);
    resetSourceVersion(): void;
    get sourceVersionInput(): string | undefined;
    private _configuration;
    get configuration(): AwsSecuritylakeCustomLogSource.ConfigurationPropertyList;
    putConfiguration(value: AwsSecuritylakeCustomLogSource.ConfigurationProperty[] | cdktn.IResolvable): void;
    resetConfiguration(): void;
    get configurationInput(): cdktn.IResolvable | AwsSecuritylakeCustomLogSource.ConfigurationProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSecuritylakeCustomLogSourceAttributesPropertyToTerraform(struct?: AwsSecuritylakeCustomLogSource.AttributesProperty): any;
export declare function awsSecuritylakeCustomLogSourceAttributesPropertyToHclTerraform(struct?: AwsSecuritylakeCustomLogSource.AttributesProperty): any;
export declare function awsSecuritylakeCustomLogSourceProviderDetailsPropertyToTerraform(struct?: AwsSecuritylakeCustomLogSource.ProviderDetailsProperty): any;
export declare function awsSecuritylakeCustomLogSourceProviderDetailsPropertyToHclTerraform(struct?: AwsSecuritylakeCustomLogSource.ProviderDetailsProperty): any;
export declare function awsSecuritylakeCustomLogSourceCrawlerConfigurationPropertyToTerraform(struct?: AwsSecuritylakeCustomLogSource.CrawlerConfigurationProperty | cdktn.IResolvable): any;
export declare function awsSecuritylakeCustomLogSourceCrawlerConfigurationPropertyToHclTerraform(struct?: AwsSecuritylakeCustomLogSource.CrawlerConfigurationProperty | cdktn.IResolvable): any;
export declare function awsSecuritylakeCustomLogSourceProviderIdentityPropertyToTerraform(struct?: AwsSecuritylakeCustomLogSource.ProviderIdentityProperty | cdktn.IResolvable): any;
export declare function awsSecuritylakeCustomLogSourceProviderIdentityPropertyToHclTerraform(struct?: AwsSecuritylakeCustomLogSource.ProviderIdentityProperty | cdktn.IResolvable): any;
export declare function awsSecuritylakeCustomLogSourceConfigurationPropertyToTerraform(struct?: AwsSecuritylakeCustomLogSource.ConfigurationProperty | cdktn.IResolvable): any;
export declare function awsSecuritylakeCustomLogSourceConfigurationPropertyToHclTerraform(struct?: AwsSecuritylakeCustomLogSource.ConfigurationProperty | cdktn.IResolvable): any;
export declare namespace AwsSecuritylakeCustomLogSource {
    interface AttributesProperty {
    }
    class AttributesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AttributesProperty | undefined;
        set internalValue(value: AttributesProperty | undefined);
        get crawlerArn(): string;
        get databaseArn(): string;
        get tableArn(): string;
    }
    class AttributesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AttributesPropertyOutputReference;
    }
    interface ProviderDetailsProperty {
    }
    class ProviderDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ProviderDetailsProperty | undefined;
        set internalValue(value: ProviderDetailsProperty | undefined);
        get location(): string;
        get roleArn(): string;
    }
    class ProviderDetailsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ProviderDetailsPropertyOutputReference;
    }
    interface CrawlerConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_custom_log_source#role_arn AwsSecuritylakeCustomLogSource#role_arn}
        */
        readonly roleArn: string;
    }
    class CrawlerConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CrawlerConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CrawlerConfigurationProperty | cdktn.IResolvable | undefined);
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
    }
    class CrawlerConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: CrawlerConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CrawlerConfigurationPropertyOutputReference;
    }
    interface ProviderIdentityProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_custom_log_source#external_id AwsSecuritylakeCustomLogSource#external_id}
        */
        readonly externalId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_custom_log_source#principal AwsSecuritylakeCustomLogSource#principal}
        */
        readonly principal: string;
    }
    class ProviderIdentityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ProviderIdentityProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ProviderIdentityProperty | cdktn.IResolvable | undefined);
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        get externalIdInput(): string | undefined;
        private _principal?;
        get principal(): string;
        set principal(value: string);
        get principalInput(): string | undefined;
    }
    class ProviderIdentityPropertyList extends cdktn.ComplexList {
        internalValue?: ProviderIdentityProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ProviderIdentityPropertyOutputReference;
    }
    interface ConfigurationProperty {
        /**
        * crawler_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_custom_log_source#crawler_configuration AwsSecuritylakeCustomLogSource#crawler_configuration}
        */
        readonly crawlerConfiguration?: CrawlerConfigurationProperty[] | cdktn.IResolvable;
        /**
        * provider_identity block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_custom_log_source#provider_identity AwsSecuritylakeCustomLogSource#provider_identity}
        */
        readonly providerIdentity?: ProviderIdentityProperty[] | cdktn.IResolvable;
    }
    class ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConfigurationProperty | cdktn.IResolvable | undefined);
        private _crawlerConfiguration;
        get crawlerConfiguration(): CrawlerConfigurationPropertyList;
        putCrawlerConfiguration(value: CrawlerConfigurationProperty[] | cdktn.IResolvable): void;
        resetCrawlerConfiguration(): void;
        get crawlerConfigurationInput(): cdktn.IResolvable | CrawlerConfigurationProperty[] | undefined;
        private _providerIdentity;
        get providerIdentity(): ProviderIdentityPropertyList;
        putProviderIdentity(value: ProviderIdentityProperty[] | cdktn.IResolvable): void;
        resetProviderIdentity(): void;
        get providerIdentityInput(): cdktn.IResolvable | ProviderIdentityProperty[] | undefined;
    }
    class ConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConfigurationPropertyOutputReference;
    }
}
