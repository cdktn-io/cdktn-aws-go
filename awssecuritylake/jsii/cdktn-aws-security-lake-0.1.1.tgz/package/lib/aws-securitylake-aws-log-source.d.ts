import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSecuritylakeAwsLogSourceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_aws_log_source#region AwsSecuritylakeAwsLogSource#region}
    */
    readonly region?: string;
    /**
    * source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_aws_log_source#source AwsSecuritylakeAwsLogSource#source}
    */
    readonly source?: AwsSecuritylakeAwsLogSource.SourceProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_aws_log_source aws_securitylake_aws_log_source}
*/
export declare class AwsSecuritylakeAwsLogSource extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_securitylake_aws_log_source";
    /**
    * Generates CDKTN code for importing a AwsSecuritylakeAwsLogSource resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSecuritylakeAwsLogSource to import
    * @param importFromId The id of the existing AwsSecuritylakeAwsLogSource that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_aws_log_source#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSecuritylakeAwsLogSource to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_aws_log_source aws_securitylake_aws_log_source} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSecuritylakeAwsLogSourceConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsSecuritylakeAwsLogSourceConfig);
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _source;
    get source(): AwsSecuritylakeAwsLogSource.SourcePropertyList;
    putSource(value: AwsSecuritylakeAwsLogSource.SourceProperty[] | cdktn.IResolvable): void;
    resetSource(): void;
    get sourceInput(): cdktn.IResolvable | AwsSecuritylakeAwsLogSource.SourceProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSecuritylakeAwsLogSourceSourcePropertyToTerraform(struct?: AwsSecuritylakeAwsLogSource.SourceProperty | cdktn.IResolvable): any;
export declare function awsSecuritylakeAwsLogSourceSourcePropertyToHclTerraform(struct?: AwsSecuritylakeAwsLogSource.SourceProperty | cdktn.IResolvable): any;
export declare namespace AwsSecuritylakeAwsLogSource {
    interface SourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_aws_log_source#accounts AwsSecuritylakeAwsLogSource#accounts}
        */
        readonly accounts?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_aws_log_source#regions AwsSecuritylakeAwsLogSource#regions}
        */
        readonly regions: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_aws_log_source#source_name AwsSecuritylakeAwsLogSource#source_name}
        */
        readonly sourceName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_aws_log_source#source_version AwsSecuritylakeAwsLogSource#source_version}
        */
        readonly sourceVersion?: string;
    }
    class SourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SourceProperty | cdktn.IResolvable | undefined);
        private _accounts?;
        get accounts(): string[];
        set accounts(value: string[]);
        resetAccounts(): void;
        get accountsInput(): string[] | undefined;
        private _regions?;
        get regions(): string[];
        set regions(value: string[]);
        get regionsInput(): string[] | undefined;
        private _sourceName?;
        get sourceName(): string;
        set sourceName(value: string);
        get sourceNameInput(): string | undefined;
        private _sourceVersion?;
        get sourceVersion(): string;
        set sourceVersion(value: string);
        resetSourceVersion(): void;
        get sourceVersionInput(): string | undefined;
    }
    class SourcePropertyList extends cdktn.ComplexList {
        internalValue?: SourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SourcePropertyOutputReference;
    }
}
