import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSecuritylakeSubscriberConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_subscriber#access_type AwsSecuritylakeSubscriber#access_type}
    */
    readonly accessType?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_subscriber#region AwsSecuritylakeSubscriber#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_subscriber#subscriber_description AwsSecuritylakeSubscriber#subscriber_description}
    */
    readonly subscriberDescription?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_subscriber#subscriber_name AwsSecuritylakeSubscriber#subscriber_name}
    */
    readonly subscriberName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_subscriber#tags AwsSecuritylakeSubscriber#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_subscriber#source AwsSecuritylakeSubscriber#source}
    */
    readonly source?: AwsSecuritylakeSubscriber.SourceProperty[] | cdktn.IResolvable;
    /**
    * subscriber_identity block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_subscriber#subscriber_identity AwsSecuritylakeSubscriber#subscriber_identity}
    */
    readonly subscriberIdentity?: AwsSecuritylakeSubscriber.SubscriberIdentityProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_subscriber#timeouts AwsSecuritylakeSubscriber#timeouts}
    */
    readonly timeouts?: AwsSecuritylakeSubscriber.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_subscriber aws_securitylake_subscriber}
*/
export declare class AwsSecuritylakeSubscriber extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_securitylake_subscriber";
    /**
    * Generates CDKTN code for importing a AwsSecuritylakeSubscriber resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSecuritylakeSubscriber to import
    * @param importFromId The id of the existing AwsSecuritylakeSubscriber that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_subscriber#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSecuritylakeSubscriber to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_subscriber aws_securitylake_subscriber} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSecuritylakeSubscriberConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsSecuritylakeSubscriberConfig);
    private _accessType?;
    get accessType(): string;
    set accessType(value: string);
    resetAccessType(): void;
    get accessTypeInput(): string | undefined;
    get arn(): string;
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get resourceShareArn(): string;
    get resourceShareName(): string;
    get roleArn(): string;
    get s3BucketArn(): string;
    private _subscriberDescription?;
    get subscriberDescription(): string;
    set subscriberDescription(value: string);
    resetSubscriberDescription(): void;
    get subscriberDescriptionInput(): string | undefined;
    get subscriberEndpoint(): string;
    private _subscriberName?;
    get subscriberName(): string;
    set subscriberName(value: string);
    resetSubscriberName(): void;
    get subscriberNameInput(): string | undefined;
    get subscriberStatus(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _source;
    get source(): AwsSecuritylakeSubscriber.SourcePropertyList;
    putSource(value: AwsSecuritylakeSubscriber.SourceProperty[] | cdktn.IResolvable): void;
    resetSource(): void;
    get sourceInput(): cdktn.IResolvable | AwsSecuritylakeSubscriber.SourceProperty[] | undefined;
    private _subscriberIdentity;
    get subscriberIdentity(): AwsSecuritylakeSubscriber.SubscriberIdentityPropertyList;
    putSubscriberIdentity(value: AwsSecuritylakeSubscriber.SubscriberIdentityProperty[] | cdktn.IResolvable): void;
    resetSubscriberIdentity(): void;
    get subscriberIdentityInput(): cdktn.IResolvable | AwsSecuritylakeSubscriber.SubscriberIdentityProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsSecuritylakeSubscriber.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsSecuritylakeSubscriber.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsSecuritylakeSubscriber.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSecuritylakeSubscriberAwsLogSourceResourcePropertyToTerraform(struct?: AwsSecuritylakeSubscriber.AwsLogSourceResourceProperty | cdktn.IResolvable): any;
export declare function awsSecuritylakeSubscriberAwsLogSourceResourcePropertyToHclTerraform(struct?: AwsSecuritylakeSubscriber.AwsLogSourceResourceProperty | cdktn.IResolvable): any;
export declare function awsSecuritylakeSubscriberAttributesPropertyToTerraform(struct?: AwsSecuritylakeSubscriber.AttributesProperty): any;
export declare function awsSecuritylakeSubscriberAttributesPropertyToHclTerraform(struct?: AwsSecuritylakeSubscriber.AttributesProperty): any;
export declare function awsSecuritylakeSubscriberProviderPropertyToTerraform(struct?: AwsSecuritylakeSubscriber.ProviderProperty): any;
export declare function awsSecuritylakeSubscriberProviderPropertyToHclTerraform(struct?: AwsSecuritylakeSubscriber.ProviderProperty): any;
export declare function awsSecuritylakeSubscriberCustomLogSourceResourcePropertyToTerraform(struct?: AwsSecuritylakeSubscriber.CustomLogSourceResourceProperty | cdktn.IResolvable): any;
export declare function awsSecuritylakeSubscriberCustomLogSourceResourcePropertyToHclTerraform(struct?: AwsSecuritylakeSubscriber.CustomLogSourceResourceProperty | cdktn.IResolvable): any;
export declare function awsSecuritylakeSubscriberSourcePropertyToTerraform(struct?: AwsSecuritylakeSubscriber.SourceProperty | cdktn.IResolvable): any;
export declare function awsSecuritylakeSubscriberSourcePropertyToHclTerraform(struct?: AwsSecuritylakeSubscriber.SourceProperty | cdktn.IResolvable): any;
export declare function awsSecuritylakeSubscriberSubscriberIdentityPropertyToTerraform(struct?: AwsSecuritylakeSubscriber.SubscriberIdentityProperty | cdktn.IResolvable): any;
export declare function awsSecuritylakeSubscriberSubscriberIdentityPropertyToHclTerraform(struct?: AwsSecuritylakeSubscriber.SubscriberIdentityProperty | cdktn.IResolvable): any;
export declare function awsSecuritylakeSubscriberTimeoutsPropertyToTerraform(struct?: AwsSecuritylakeSubscriber.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsSecuritylakeSubscriberTimeoutsPropertyToHclTerraform(struct?: AwsSecuritylakeSubscriber.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsSecuritylakeSubscriber {
    interface AwsLogSourceResourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_subscriber#source_name AwsSecuritylakeSubscriber#source_name}
        */
        readonly sourceName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_subscriber#source_version AwsSecuritylakeSubscriber#source_version}
        */
        readonly sourceVersion?: string;
    }
    class AwsLogSourceResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AwsLogSourceResourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AwsLogSourceResourceProperty | cdktn.IResolvable | undefined);
        private _sourceName?;
        get sourceName(): string;
        set sourceName(value: string);
        get sourceNameInput(): string | undefined;
        private _sourceVersion?;
        get sourceVersion(): string;
        set sourceVersion(value: string);
        resetSourceVersion(): void;
        get sourceVersionInput(): string | undefined;
    }
    class AwsLogSourceResourcePropertyList extends cdktn.ComplexList {
        internalValue?: AwsLogSourceResourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AwsLogSourceResourcePropertyOutputReference;
    }
    interface AttributesProperty {
    }
    class AttributesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AttributesProperty | undefined;
        set internalValue(value: AttributesProperty | undefined);
        get crawlerArn(): string;
        get databaseArn(): string;
        get tableArn(): string;
    }
    class AttributesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AttributesPropertyOutputReference;
    }
    interface ProviderProperty {
    }
    class ProviderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ProviderProperty | undefined;
        set internalValue(value: ProviderProperty | undefined);
        get location(): string;
        get roleArn(): string;
    }
    class ProviderPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ProviderPropertyOutputReference;
    }
    interface CustomLogSourceResourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_subscriber#source_name AwsSecuritylakeSubscriber#source_name}
        */
        readonly sourceName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_subscriber#source_version AwsSecuritylakeSubscriber#source_version}
        */
        readonly sourceVersion?: string;
    }
    class CustomLogSourceResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomLogSourceResourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CustomLogSourceResourceProperty | cdktn.IResolvable | undefined);
        private _attributes;
        get attributes(): AttributesPropertyList;
        private _provider;
        get provider(): ProviderPropertyList;
        private _sourceName?;
        get sourceName(): string;
        set sourceName(value: string);
        get sourceNameInput(): string | undefined;
        private _sourceVersion?;
        get sourceVersion(): string;
        set sourceVersion(value: string);
        resetSourceVersion(): void;
        get sourceVersionInput(): string | undefined;
    }
    class CustomLogSourceResourcePropertyList extends cdktn.ComplexList {
        internalValue?: CustomLogSourceResourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomLogSourceResourcePropertyOutputReference;
    }
    interface SourceProperty {
        /**
        * aws_log_source_resource block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_subscriber#aws_log_source_resource AwsSecuritylakeSubscriber#aws_log_source_resource}
        */
        readonly awsLogSourceResource?: AwsLogSourceResourceProperty[] | cdktn.IResolvable;
        /**
        * custom_log_source_resource block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_subscriber#custom_log_source_resource AwsSecuritylakeSubscriber#custom_log_source_resource}
        */
        readonly customLogSourceResource?: CustomLogSourceResourceProperty[] | cdktn.IResolvable;
    }
    class SourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SourceProperty | cdktn.IResolvable | undefined);
        private _awsLogSourceResource;
        get awsLogSourceResource(): AwsLogSourceResourcePropertyList;
        putAwsLogSourceResource(value: AwsLogSourceResourceProperty[] | cdktn.IResolvable): void;
        resetAwsLogSourceResource(): void;
        get awsLogSourceResourceInput(): cdktn.IResolvable | AwsLogSourceResourceProperty[] | undefined;
        private _customLogSourceResource;
        get customLogSourceResource(): CustomLogSourceResourcePropertyList;
        putCustomLogSourceResource(value: CustomLogSourceResourceProperty[] | cdktn.IResolvable): void;
        resetCustomLogSourceResource(): void;
        get customLogSourceResourceInput(): cdktn.IResolvable | CustomLogSourceResourceProperty[] | undefined;
    }
    class SourcePropertyList extends cdktn.ComplexList {
        internalValue?: SourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SourcePropertyOutputReference;
    }
    interface SubscriberIdentityProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_subscriber#external_id AwsSecuritylakeSubscriber#external_id}
        */
        readonly externalId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_subscriber#principal AwsSecuritylakeSubscriber#principal}
        */
        readonly principal: string;
    }
    class SubscriberIdentityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SubscriberIdentityProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SubscriberIdentityProperty | cdktn.IResolvable | undefined);
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        get externalIdInput(): string | undefined;
        private _principal?;
        get principal(): string;
        set principal(value: string);
        get principalInput(): string | undefined;
    }
    class SubscriberIdentityPropertyList extends cdktn.ComplexList {
        internalValue?: SubscriberIdentityProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SubscriberIdentityPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_subscriber#create AwsSecuritylakeSubscriber#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_subscriber#delete AwsSecuritylakeSubscriber#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securitylake_subscriber#update AwsSecuritylakeSubscriber#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
