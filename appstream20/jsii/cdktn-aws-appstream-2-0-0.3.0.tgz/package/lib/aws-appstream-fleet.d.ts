import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsFleetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#description AwsFleet#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#disconnect_timeout_in_seconds AwsFleet#disconnect_timeout_in_seconds}
    */
    readonly disconnectTimeoutInSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#display_name AwsFleet#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#enable_default_internet_access AwsFleet#enable_default_internet_access}
    */
    readonly enableDefaultInternetAccess?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#fleet_type AwsFleet#fleet_type}
    */
    readonly fleetType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#iam_role_arn AwsFleet#iam_role_arn}
    */
    readonly iamRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#id AwsFleet#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#idle_disconnect_timeout_in_seconds AwsFleet#idle_disconnect_timeout_in_seconds}
    */
    readonly idleDisconnectTimeoutInSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#image_arn AwsFleet#image_arn}
    */
    readonly imageArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#image_name AwsFleet#image_name}
    */
    readonly imageName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#instance_type AwsFleet#instance_type}
    */
    readonly instanceType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#max_sessions_per_instance AwsFleet#max_sessions_per_instance}
    */
    readonly maxSessionsPerInstance?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#max_user_duration_in_seconds AwsFleet#max_user_duration_in_seconds}
    */
    readonly maxUserDurationInSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#name AwsFleet#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#region AwsFleet#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#stream_view AwsFleet#stream_view}
    */
    readonly streamView?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#tags AwsFleet#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#tags_all AwsFleet#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * compute_capacity block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#compute_capacity AwsFleet#compute_capacity}
    */
    readonly computeCapacity: AwsFleet.ComputeCapacityProperty;
    /**
    * domain_join_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#domain_join_info AwsFleet#domain_join_info}
    */
    readonly domainJoinInfo?: AwsFleet.DomainJoinInfoProperty;
    /**
    * vpc_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#vpc_config AwsFleet#vpc_config}
    */
    readonly vpcConfig?: AwsFleet.VpcConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet aws_appstream_fleet}
*/
export declare class AwsFleet extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_appstream_fleet";
    /**
    * Generates CDKTN code for importing a AwsFleet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsFleet to import
    * @param importFromId The id of the existing AwsFleet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsFleet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet aws_appstream_fleet} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsFleetConfig
    */
    constructor(scope: Construct, id: string, config: AwsFleetConfig);
    get arn(): string;
    get createdTime(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _disconnectTimeoutInSeconds?;
    get disconnectTimeoutInSeconds(): number;
    set disconnectTimeoutInSeconds(value: number);
    resetDisconnectTimeoutInSeconds(): void;
    get disconnectTimeoutInSecondsInput(): number | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _enableDefaultInternetAccess?;
    get enableDefaultInternetAccess(): boolean | cdktn.IResolvable;
    set enableDefaultInternetAccess(value: boolean | cdktn.IResolvable);
    resetEnableDefaultInternetAccess(): void;
    get enableDefaultInternetAccessInput(): boolean | cdktn.IResolvable | undefined;
    private _fleetType?;
    get fleetType(): string;
    set fleetType(value: string);
    resetFleetType(): void;
    get fleetTypeInput(): string | undefined;
    private _iamRoleArn?;
    get iamRoleArn(): string;
    set iamRoleArn(value: string);
    resetIamRoleArn(): void;
    get iamRoleArnInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _idleDisconnectTimeoutInSeconds?;
    get idleDisconnectTimeoutInSeconds(): number;
    set idleDisconnectTimeoutInSeconds(value: number);
    resetIdleDisconnectTimeoutInSeconds(): void;
    get idleDisconnectTimeoutInSecondsInput(): number | undefined;
    private _imageArn?;
    get imageArn(): string;
    set imageArn(value: string);
    resetImageArn(): void;
    get imageArnInput(): string | undefined;
    private _imageName?;
    get imageName(): string;
    set imageName(value: string);
    resetImageName(): void;
    get imageNameInput(): string | undefined;
    private _instanceType?;
    get instanceType(): string;
    set instanceType(value: string);
    get instanceTypeInput(): string | undefined;
    private _maxSessionsPerInstance?;
    get maxSessionsPerInstance(): number;
    set maxSessionsPerInstance(value: number);
    resetMaxSessionsPerInstance(): void;
    get maxSessionsPerInstanceInput(): number | undefined;
    private _maxUserDurationInSeconds?;
    get maxUserDurationInSeconds(): number;
    set maxUserDurationInSeconds(value: number);
    resetMaxUserDurationInSeconds(): void;
    get maxUserDurationInSecondsInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get state(): string;
    private _streamView?;
    get streamView(): string;
    set streamView(value: string);
    resetStreamView(): void;
    get streamViewInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _computeCapacity;
    get computeCapacity(): AwsFleet.ComputeCapacityPropertyOutputReference;
    putComputeCapacity(value: AwsFleet.ComputeCapacityProperty): void;
    get computeCapacityInput(): AwsFleet.ComputeCapacityProperty | undefined;
    private _domainJoinInfo;
    get domainJoinInfo(): AwsFleet.DomainJoinInfoPropertyOutputReference;
    putDomainJoinInfo(value: AwsFleet.DomainJoinInfoProperty): void;
    resetDomainJoinInfo(): void;
    get domainJoinInfoInput(): AwsFleet.DomainJoinInfoProperty | undefined;
    private _vpcConfig;
    get vpcConfig(): AwsFleet.VpcConfigPropertyOutputReference;
    putVpcConfig(value: AwsFleet.VpcConfigProperty): void;
    resetVpcConfig(): void;
    get vpcConfigInput(): AwsFleet.VpcConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsFleetComputeCapacityPropertyToTerraform(struct?: AwsFleet.ComputeCapacityPropertyOutputReference | AwsFleet.ComputeCapacityProperty): any;
export declare function awsFleetComputeCapacityPropertyToHclTerraform(struct?: AwsFleet.ComputeCapacityPropertyOutputReference | AwsFleet.ComputeCapacityProperty): any;
export declare function awsFleetDomainJoinInfoPropertyToTerraform(struct?: AwsFleet.DomainJoinInfoPropertyOutputReference | AwsFleet.DomainJoinInfoProperty): any;
export declare function awsFleetDomainJoinInfoPropertyToHclTerraform(struct?: AwsFleet.DomainJoinInfoPropertyOutputReference | AwsFleet.DomainJoinInfoProperty): any;
export declare function awsFleetVpcConfigPropertyToTerraform(struct?: AwsFleet.VpcConfigPropertyOutputReference | AwsFleet.VpcConfigProperty): any;
export declare function awsFleetVpcConfigPropertyToHclTerraform(struct?: AwsFleet.VpcConfigPropertyOutputReference | AwsFleet.VpcConfigProperty): any;
export declare namespace AwsFleet {
    interface ComputeCapacityProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#desired_instances AwsFleet#desired_instances}
        */
        readonly desiredInstances?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#desired_sessions AwsFleet#desired_sessions}
        */
        readonly desiredSessions?: number;
    }
    class ComputeCapacityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ComputeCapacityProperty | undefined;
        set internalValue(value: ComputeCapacityProperty | undefined);
        get available(): number;
        private _desiredInstances?;
        get desiredInstances(): number;
        set desiredInstances(value: number);
        resetDesiredInstances(): void;
        get desiredInstancesInput(): number | undefined;
        private _desiredSessions?;
        get desiredSessions(): number;
        set desiredSessions(value: number);
        resetDesiredSessions(): void;
        get desiredSessionsInput(): number | undefined;
        get inUse(): number;
        get running(): number;
    }
    interface DomainJoinInfoProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#directory_name AwsFleet#directory_name}
        */
        readonly directoryName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#organizational_unit_distinguished_name AwsFleet#organizational_unit_distinguished_name}
        */
        readonly organizationalUnitDistinguishedName?: string;
    }
    class DomainJoinInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DomainJoinInfoProperty | undefined;
        set internalValue(value: DomainJoinInfoProperty | undefined);
        private _directoryName?;
        get directoryName(): string;
        set directoryName(value: string);
        resetDirectoryName(): void;
        get directoryNameInput(): string | undefined;
        private _organizationalUnitDistinguishedName?;
        get organizationalUnitDistinguishedName(): string;
        set organizationalUnitDistinguishedName(value: string);
        resetOrganizationalUnitDistinguishedName(): void;
        get organizationalUnitDistinguishedNameInput(): string | undefined;
    }
    interface VpcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#security_group_ids AwsFleet#security_group_ids}
        */
        readonly securityGroupIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appstream_fleet#subnet_ids AwsFleet#subnet_ids}
        */
        readonly subnetIds?: string[];
    }
    class VpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcConfigProperty | undefined;
        set internalValue(value: VpcConfigProperty | undefined);
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        resetSecurityGroupIds(): void;
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        resetSubnetIds(): void;
        get subnetIdsInput(): string[] | undefined;
    }
}
