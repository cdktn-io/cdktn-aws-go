import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDeploymentStrategyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appconfig_deployment_strategy#deployment_duration_in_minutes AwsDeploymentStrategy#deployment_duration_in_minutes}
    */
    readonly deploymentDurationInMinutes: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appconfig_deployment_strategy#description AwsDeploymentStrategy#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appconfig_deployment_strategy#final_bake_time_in_minutes AwsDeploymentStrategy#final_bake_time_in_minutes}
    */
    readonly finalBakeTimeInMinutes?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appconfig_deployment_strategy#growth_factor AwsDeploymentStrategy#growth_factor}
    */
    readonly growthFactor: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appconfig_deployment_strategy#growth_type AwsDeploymentStrategy#growth_type}
    */
    readonly growthType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appconfig_deployment_strategy#id AwsDeploymentStrategy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appconfig_deployment_strategy#name AwsDeploymentStrategy#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appconfig_deployment_strategy#region AwsDeploymentStrategy#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appconfig_deployment_strategy#replicate_to AwsDeploymentStrategy#replicate_to}
    */
    readonly replicateTo: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appconfig_deployment_strategy#tags AwsDeploymentStrategy#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appconfig_deployment_strategy#tags_all AwsDeploymentStrategy#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appconfig_deployment_strategy aws_appconfig_deployment_strategy}
*/
export declare class AwsDeploymentStrategy extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_appconfig_deployment_strategy";
    /**
    * Generates CDKTN code for importing a AwsDeploymentStrategy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDeploymentStrategy to import
    * @param importFromId The id of the existing AwsDeploymentStrategy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appconfig_deployment_strategy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDeploymentStrategy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appconfig_deployment_strategy aws_appconfig_deployment_strategy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDeploymentStrategyConfig
    */
    constructor(scope: Construct, id: string, config: AwsDeploymentStrategyConfig);
    get arn(): string;
    private _deploymentDurationInMinutes?;
    get deploymentDurationInMinutes(): number;
    set deploymentDurationInMinutes(value: number);
    get deploymentDurationInMinutesInput(): number | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _finalBakeTimeInMinutes?;
    get finalBakeTimeInMinutes(): number;
    set finalBakeTimeInMinutes(value: number);
    resetFinalBakeTimeInMinutes(): void;
    get finalBakeTimeInMinutesInput(): number | undefined;
    private _growthFactor?;
    get growthFactor(): number;
    set growthFactor(value: number);
    get growthFactorInput(): number | undefined;
    private _growthType?;
    get growthType(): string;
    set growthType(value: string);
    resetGrowthType(): void;
    get growthTypeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _replicateTo?;
    get replicateTo(): string;
    set replicateTo(value: string);
    get replicateToInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
