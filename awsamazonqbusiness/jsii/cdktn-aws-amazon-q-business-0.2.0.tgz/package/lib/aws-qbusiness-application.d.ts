import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfApplicationConfig extends cdktn.TerraformMetaArguments {
    /**
    * A description of the Amazon Q application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/qbusiness_application#description TfApplication#description}
    */
    readonly description?: string;
    /**
    * The display name of the Amazon Q application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/qbusiness_application#display_name TfApplication#display_name}
    */
    readonly displayName: string;
    /**
    * The Amazon Resource Name (ARN) of the IAM service role that provides permissions for the Amazon Q application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/qbusiness_application#iam_service_role_arn TfApplication#iam_service_role_arn}
    */
    readonly iamServiceRoleArn: string;
    /**
    * ARN of the IAM Identity Center instance you are either creating for—or connecting to—your Amazon Q Business application
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/qbusiness_application#identity_center_instance_arn TfApplication#identity_center_instance_arn}
    */
    readonly identityCenterInstanceArn: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/qbusiness_application#region TfApplication#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/qbusiness_application#tags TfApplication#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * attachments_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/qbusiness_application#attachments_configuration TfApplication#attachments_configuration}
    */
    readonly attachmentsConfiguration?: TfApplication.AttachmentsConfigurationProperty[] | cdktn.IResolvable;
    /**
    * encryption_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/qbusiness_application#encryption_configuration TfApplication#encryption_configuration}
    */
    readonly encryptionConfiguration?: TfApplication.EncryptionConfigurationProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/qbusiness_application#timeouts TfApplication#timeouts}
    */
    readonly timeouts?: TfApplication.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/qbusiness_application aws_qbusiness_application}
*/
export declare class TfApplication extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_qbusiness_application";
    /**
    * Generates CDKTN code for importing a TfApplication resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfApplication to import
    * @param importFromId The id of the existing TfApplication that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/qbusiness_application#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfApplication to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/qbusiness_application aws_qbusiness_application} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfApplicationConfig
    */
    constructor(scope: Construct, id: string, config: TfApplicationConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _iamServiceRoleArn?;
    get iamServiceRoleArn(): string;
    set iamServiceRoleArn(value: string);
    get iamServiceRoleArnInput(): string | undefined;
    get id(): string;
    get identityCenterApplicationArn(): string;
    private _identityCenterInstanceArn?;
    get identityCenterInstanceArn(): string;
    set identityCenterInstanceArn(value: string);
    get identityCenterInstanceArnInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _attachmentsConfiguration;
    get attachmentsConfiguration(): TfApplication.AttachmentsConfigurationPropertyList;
    putAttachmentsConfiguration(value: TfApplication.AttachmentsConfigurationProperty[] | cdktn.IResolvable): void;
    resetAttachmentsConfiguration(): void;
    get attachmentsConfigurationInput(): cdktn.IResolvable | TfApplication.AttachmentsConfigurationProperty[] | undefined;
    private _encryptionConfiguration;
    get encryptionConfiguration(): TfApplication.EncryptionConfigurationPropertyList;
    putEncryptionConfiguration(value: TfApplication.EncryptionConfigurationProperty[] | cdktn.IResolvable): void;
    resetEncryptionConfiguration(): void;
    get encryptionConfigurationInput(): cdktn.IResolvable | TfApplication.EncryptionConfigurationProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfApplication.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfApplication.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfApplication.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfApplicationAttachmentsConfigurationPropertyToTerraform(struct?: TfApplication.AttachmentsConfigurationProperty | cdktn.IResolvable): any;
export declare function tfApplicationAttachmentsConfigurationPropertyToHclTerraform(struct?: TfApplication.AttachmentsConfigurationProperty | cdktn.IResolvable): any;
export declare function tfApplicationEncryptionConfigurationPropertyToTerraform(struct?: TfApplication.EncryptionConfigurationProperty | cdktn.IResolvable): any;
export declare function tfApplicationEncryptionConfigurationPropertyToHclTerraform(struct?: TfApplication.EncryptionConfigurationProperty | cdktn.IResolvable): any;
export declare function tfApplicationTimeoutsPropertyToTerraform(struct?: TfApplication.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfApplicationTimeoutsPropertyToHclTerraform(struct?: TfApplication.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfApplication {
    interface AttachmentsConfigurationProperty {
        /**
        * Status information about whether file upload functionality is activated or deactivated for your end user.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/qbusiness_application#attachments_control_mode TfApplication#attachments_control_mode}
        */
        readonly attachmentsControlMode: string;
    }
    class AttachmentsConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AttachmentsConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AttachmentsConfigurationProperty | cdktn.IResolvable | undefined);
        private _attachmentsControlMode?;
        get attachmentsControlMode(): string;
        set attachmentsControlMode(value: string);
        get attachmentsControlModeInput(): string | undefined;
    }
    class AttachmentsConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: AttachmentsConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AttachmentsConfigurationPropertyOutputReference;
    }
    interface EncryptionConfigurationProperty {
        /**
        * The identifier of the AWS KMS key that is used to encrypt your data. Amazon Q doesn't support asymmetric keys.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/qbusiness_application#kms_key_id TfApplication#kms_key_id}
        */
        readonly kmsKeyId: string;
    }
    class EncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EncryptionConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EncryptionConfigurationProperty | cdktn.IResolvable | undefined);
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        get kmsKeyIdInput(): string | undefined;
    }
    class EncryptionConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: EncryptionConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EncryptionConfigurationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/qbusiness_application#create TfApplication#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/qbusiness_application#delete TfApplication#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/qbusiness_application#update TfApplication#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
