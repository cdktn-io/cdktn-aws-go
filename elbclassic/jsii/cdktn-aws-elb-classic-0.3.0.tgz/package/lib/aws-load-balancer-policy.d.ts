import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsLoadBalancerPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/load_balancer_policy#id AwsLoadBalancerPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/load_balancer_policy#load_balancer_name AwsLoadBalancerPolicy#load_balancer_name}
    */
    readonly loadBalancerName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/load_balancer_policy#policy_name AwsLoadBalancerPolicy#policy_name}
    */
    readonly policyName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/load_balancer_policy#policy_type_name AwsLoadBalancerPolicy#policy_type_name}
    */
    readonly policyTypeName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/load_balancer_policy#region AwsLoadBalancerPolicy#region}
    */
    readonly region?: string;
    /**
    * policy_attribute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/load_balancer_policy#policy_attribute AwsLoadBalancerPolicy#policy_attribute}
    */
    readonly policyAttribute?: AwsLoadBalancerPolicy.PolicyAttributeProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/load_balancer_policy aws_load_balancer_policy}
*/
export declare class AwsLoadBalancerPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_load_balancer_policy";
    /**
    * Generates CDKTN code for importing a AwsLoadBalancerPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsLoadBalancerPolicy to import
    * @param importFromId The id of the existing AwsLoadBalancerPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/load_balancer_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsLoadBalancerPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/load_balancer_policy aws_load_balancer_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsLoadBalancerPolicyConfig
    */
    constructor(scope: Construct, id: string, config: AwsLoadBalancerPolicyConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _loadBalancerName?;
    get loadBalancerName(): string;
    set loadBalancerName(value: string);
    get loadBalancerNameInput(): string | undefined;
    private _policyName?;
    get policyName(): string;
    set policyName(value: string);
    get policyNameInput(): string | undefined;
    private _policyTypeName?;
    get policyTypeName(): string;
    set policyTypeName(value: string);
    get policyTypeNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _policyAttribute;
    get policyAttribute(): AwsLoadBalancerPolicy.PolicyAttributePropertyList;
    putPolicyAttribute(value: AwsLoadBalancerPolicy.PolicyAttributeProperty[] | cdktn.IResolvable): void;
    resetPolicyAttribute(): void;
    get policyAttributeInput(): cdktn.IResolvable | AwsLoadBalancerPolicy.PolicyAttributeProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsLoadBalancerPolicyPolicyAttributePropertyToTerraform(struct?: AwsLoadBalancerPolicy.PolicyAttributeProperty | cdktn.IResolvable): any;
export declare function awsLoadBalancerPolicyPolicyAttributePropertyToHclTerraform(struct?: AwsLoadBalancerPolicy.PolicyAttributeProperty | cdktn.IResolvable): any;
export declare namespace AwsLoadBalancerPolicy {
    interface PolicyAttributeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/load_balancer_policy#name AwsLoadBalancerPolicy#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/load_balancer_policy#value AwsLoadBalancerPolicy#value}
        */
        readonly value?: string;
    }
    class PolicyAttributePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PolicyAttributeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PolicyAttributeProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
    class PolicyAttributePropertyList extends cdktn.ComplexList {
        internalValue?: PolicyAttributeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PolicyAttributePropertyOutputReference;
    }
}
