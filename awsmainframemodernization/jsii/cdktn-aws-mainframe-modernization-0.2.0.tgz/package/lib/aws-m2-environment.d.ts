import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfEnvironmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#apply_changes_during_maintenance_window TfEnvironment#apply_changes_during_maintenance_window}
    */
    readonly applyChangesDuringMaintenanceWindow?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#description TfEnvironment#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#engine_type TfEnvironment#engine_type}
    */
    readonly engineType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#engine_version TfEnvironment#engine_version}
    */
    readonly engineVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#force_update TfEnvironment#force_update}
    */
    readonly forceUpdate?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#instance_type TfEnvironment#instance_type}
    */
    readonly instanceType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#kms_key_id TfEnvironment#kms_key_id}
    */
    readonly kmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#name TfEnvironment#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#preferred_maintenance_window TfEnvironment#preferred_maintenance_window}
    */
    readonly preferredMaintenanceWindow?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#publicly_accessible TfEnvironment#publicly_accessible}
    */
    readonly publiclyAccessible?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#region TfEnvironment#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#security_group_ids TfEnvironment#security_group_ids}
    */
    readonly securityGroupIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#subnet_ids TfEnvironment#subnet_ids}
    */
    readonly subnetIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#tags TfEnvironment#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * high_availability_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#high_availability_config TfEnvironment#high_availability_config}
    */
    readonly highAvailabilityConfig?: TfEnvironment.HighAvailabilityConfigProperty[] | cdktn.IResolvable;
    /**
    * storage_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#storage_configuration TfEnvironment#storage_configuration}
    */
    readonly storageConfiguration?: TfEnvironment.StorageConfigurationProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#timeouts TfEnvironment#timeouts}
    */
    readonly timeouts?: TfEnvironment.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment aws_m2_environment}
*/
export declare class TfEnvironment extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_m2_environment";
    /**
    * Generates CDKTN code for importing a TfEnvironment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfEnvironment to import
    * @param importFromId The id of the existing TfEnvironment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfEnvironment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment aws_m2_environment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfEnvironmentConfig
    */
    constructor(scope: Construct, id: string, config: TfEnvironmentConfig);
    private _applyChangesDuringMaintenanceWindow?;
    get applyChangesDuringMaintenanceWindow(): boolean | cdktn.IResolvable;
    set applyChangesDuringMaintenanceWindow(value: boolean | cdktn.IResolvable);
    resetApplyChangesDuringMaintenanceWindow(): void;
    get applyChangesDuringMaintenanceWindowInput(): boolean | cdktn.IResolvable | undefined;
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _engineType?;
    get engineType(): string;
    set engineType(value: string);
    get engineTypeInput(): string | undefined;
    private _engineVersion?;
    get engineVersion(): string;
    set engineVersion(value: string);
    resetEngineVersion(): void;
    get engineVersionInput(): string | undefined;
    get environmentId(): string;
    private _forceUpdate?;
    get forceUpdate(): boolean | cdktn.IResolvable;
    set forceUpdate(value: boolean | cdktn.IResolvable);
    resetForceUpdate(): void;
    get forceUpdateInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    private _instanceType?;
    get instanceType(): string;
    set instanceType(value: string);
    get instanceTypeInput(): string | undefined;
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    resetKmsKeyId(): void;
    get kmsKeyIdInput(): string | undefined;
    get loadBalancerArn(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _preferredMaintenanceWindow?;
    get preferredMaintenanceWindow(): string;
    set preferredMaintenanceWindow(value: string);
    resetPreferredMaintenanceWindow(): void;
    get preferredMaintenanceWindowInput(): string | undefined;
    private _publiclyAccessible?;
    get publiclyAccessible(): boolean | cdktn.IResolvable;
    set publiclyAccessible(value: boolean | cdktn.IResolvable);
    resetPubliclyAccessible(): void;
    get publiclyAccessibleInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _securityGroupIds?;
    get securityGroupIds(): string[];
    set securityGroupIds(value: string[]);
    resetSecurityGroupIds(): void;
    get securityGroupIdsInput(): string[] | undefined;
    private _subnetIds?;
    get subnetIds(): string[];
    set subnetIds(value: string[]);
    resetSubnetIds(): void;
    get subnetIdsInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _highAvailabilityConfig;
    get highAvailabilityConfig(): TfEnvironment.HighAvailabilityConfigPropertyList;
    putHighAvailabilityConfig(value: TfEnvironment.HighAvailabilityConfigProperty[] | cdktn.IResolvable): void;
    resetHighAvailabilityConfig(): void;
    get highAvailabilityConfigInput(): cdktn.IResolvable | TfEnvironment.HighAvailabilityConfigProperty[] | undefined;
    private _storageConfiguration;
    get storageConfiguration(): TfEnvironment.StorageConfigurationPropertyList;
    putStorageConfiguration(value: TfEnvironment.StorageConfigurationProperty[] | cdktn.IResolvable): void;
    resetStorageConfiguration(): void;
    get storageConfigurationInput(): cdktn.IResolvable | TfEnvironment.StorageConfigurationProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfEnvironment.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfEnvironment.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfEnvironment.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfEnvironmentHighAvailabilityConfigPropertyToTerraform(struct?: TfEnvironment.HighAvailabilityConfigProperty | cdktn.IResolvable): any;
export declare function tfEnvironmentHighAvailabilityConfigPropertyToHclTerraform(struct?: TfEnvironment.HighAvailabilityConfigProperty | cdktn.IResolvable): any;
export declare function tfEnvironmentEfsPropertyToTerraform(struct?: TfEnvironment.EfsProperty | cdktn.IResolvable): any;
export declare function tfEnvironmentEfsPropertyToHclTerraform(struct?: TfEnvironment.EfsProperty | cdktn.IResolvable): any;
export declare function tfEnvironmentFsxPropertyToTerraform(struct?: TfEnvironment.FsxProperty | cdktn.IResolvable): any;
export declare function tfEnvironmentFsxPropertyToHclTerraform(struct?: TfEnvironment.FsxProperty | cdktn.IResolvable): any;
export declare function tfEnvironmentStorageConfigurationPropertyToTerraform(struct?: TfEnvironment.StorageConfigurationProperty | cdktn.IResolvable): any;
export declare function tfEnvironmentStorageConfigurationPropertyToHclTerraform(struct?: TfEnvironment.StorageConfigurationProperty | cdktn.IResolvable): any;
export declare function tfEnvironmentTimeoutsPropertyToTerraform(struct?: TfEnvironment.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfEnvironmentTimeoutsPropertyToHclTerraform(struct?: TfEnvironment.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfEnvironment {
    interface HighAvailabilityConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#desired_capacity TfEnvironment#desired_capacity}
        */
        readonly desiredCapacity: number;
    }
    class HighAvailabilityConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HighAvailabilityConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HighAvailabilityConfigProperty | cdktn.IResolvable | undefined);
        private _desiredCapacity?;
        get desiredCapacity(): number;
        set desiredCapacity(value: number);
        get desiredCapacityInput(): number | undefined;
    }
    class HighAvailabilityConfigPropertyList extends cdktn.ComplexList {
        internalValue?: HighAvailabilityConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HighAvailabilityConfigPropertyOutputReference;
    }
    interface EfsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#file_system_id TfEnvironment#file_system_id}
        */
        readonly fileSystemId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#mount_point TfEnvironment#mount_point}
        */
        readonly mountPoint: string;
    }
    class EfsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EfsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EfsProperty | cdktn.IResolvable | undefined);
        private _fileSystemId?;
        get fileSystemId(): string;
        set fileSystemId(value: string);
        get fileSystemIdInput(): string | undefined;
        private _mountPoint?;
        get mountPoint(): string;
        set mountPoint(value: string);
        get mountPointInput(): string | undefined;
    }
    class EfsPropertyList extends cdktn.ComplexList {
        internalValue?: EfsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EfsPropertyOutputReference;
    }
    interface FsxProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#file_system_id TfEnvironment#file_system_id}
        */
        readonly fileSystemId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#mount_point TfEnvironment#mount_point}
        */
        readonly mountPoint: string;
    }
    class FsxPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FsxProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FsxProperty | cdktn.IResolvable | undefined);
        private _fileSystemId?;
        get fileSystemId(): string;
        set fileSystemId(value: string);
        get fileSystemIdInput(): string | undefined;
        private _mountPoint?;
        get mountPoint(): string;
        set mountPoint(value: string);
        get mountPointInput(): string | undefined;
    }
    class FsxPropertyList extends cdktn.ComplexList {
        internalValue?: FsxProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FsxPropertyOutputReference;
    }
    interface StorageConfigurationProperty {
        /**
        * efs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#efs TfEnvironment#efs}
        */
        readonly efs?: EfsProperty[] | cdktn.IResolvable;
        /**
        * fsx block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#fsx TfEnvironment#fsx}
        */
        readonly fsx?: FsxProperty[] | cdktn.IResolvable;
    }
    class StorageConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StorageConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StorageConfigurationProperty | cdktn.IResolvable | undefined);
        private _efs;
        get efs(): EfsPropertyList;
        putEfs(value: EfsProperty[] | cdktn.IResolvable): void;
        resetEfs(): void;
        get efsInput(): cdktn.IResolvable | EfsProperty[] | undefined;
        private _fsx;
        get fsx(): FsxPropertyList;
        putFsx(value: FsxProperty[] | cdktn.IResolvable): void;
        resetFsx(): void;
        get fsxInput(): cdktn.IResolvable | FsxProperty[] | undefined;
    }
    class StorageConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: StorageConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StorageConfigurationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#create TfEnvironment#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#delete TfEnvironment#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#update TfEnvironment#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
