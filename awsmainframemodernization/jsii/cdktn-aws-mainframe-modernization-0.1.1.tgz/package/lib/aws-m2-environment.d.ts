import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsM2EnvironmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#apply_changes_during_maintenance_window AwsM2Environment#apply_changes_during_maintenance_window}
    */
    readonly applyChangesDuringMaintenanceWindow?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#description AwsM2Environment#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#engine_type AwsM2Environment#engine_type}
    */
    readonly engineType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#engine_version AwsM2Environment#engine_version}
    */
    readonly engineVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#force_update AwsM2Environment#force_update}
    */
    readonly forceUpdate?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#instance_type AwsM2Environment#instance_type}
    */
    readonly instanceType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#kms_key_id AwsM2Environment#kms_key_id}
    */
    readonly kmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#name AwsM2Environment#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#preferred_maintenance_window AwsM2Environment#preferred_maintenance_window}
    */
    readonly preferredMaintenanceWindow?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#publicly_accessible AwsM2Environment#publicly_accessible}
    */
    readonly publiclyAccessible?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#region AwsM2Environment#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#security_group_ids AwsM2Environment#security_group_ids}
    */
    readonly securityGroupIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#subnet_ids AwsM2Environment#subnet_ids}
    */
    readonly subnetIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#tags AwsM2Environment#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * high_availability_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#high_availability_config AwsM2Environment#high_availability_config}
    */
    readonly highAvailabilityConfig?: AwsM2Environment.HighAvailabilityConfigProperty[] | cdktn.IResolvable;
    /**
    * storage_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#storage_configuration AwsM2Environment#storage_configuration}
    */
    readonly storageConfiguration?: AwsM2Environment.StorageConfigurationProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#timeouts AwsM2Environment#timeouts}
    */
    readonly timeouts?: AwsM2Environment.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment aws_m2_environment}
*/
export declare class AwsM2Environment extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_m2_environment";
    /**
    * Generates CDKTN code for importing a AwsM2Environment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsM2Environment to import
    * @param importFromId The id of the existing AwsM2Environment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsM2Environment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment aws_m2_environment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsM2EnvironmentConfig
    */
    constructor(scope: Construct, id: string, config: AwsM2EnvironmentConfig);
    private _applyChangesDuringMaintenanceWindow?;
    get applyChangesDuringMaintenanceWindow(): boolean | cdktn.IResolvable;
    set applyChangesDuringMaintenanceWindow(value: boolean | cdktn.IResolvable);
    resetApplyChangesDuringMaintenanceWindow(): void;
    get applyChangesDuringMaintenanceWindowInput(): boolean | cdktn.IResolvable | undefined;
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _engineType?;
    get engineType(): string;
    set engineType(value: string);
    get engineTypeInput(): string | undefined;
    private _engineVersion?;
    get engineVersion(): string;
    set engineVersion(value: string);
    resetEngineVersion(): void;
    get engineVersionInput(): string | undefined;
    get environmentId(): string;
    private _forceUpdate?;
    get forceUpdate(): boolean | cdktn.IResolvable;
    set forceUpdate(value: boolean | cdktn.IResolvable);
    resetForceUpdate(): void;
    get forceUpdateInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    private _instanceType?;
    get instanceType(): string;
    set instanceType(value: string);
    get instanceTypeInput(): string | undefined;
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    resetKmsKeyId(): void;
    get kmsKeyIdInput(): string | undefined;
    get loadBalancerArn(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _preferredMaintenanceWindow?;
    get preferredMaintenanceWindow(): string;
    set preferredMaintenanceWindow(value: string);
    resetPreferredMaintenanceWindow(): void;
    get preferredMaintenanceWindowInput(): string | undefined;
    private _publiclyAccessible?;
    get publiclyAccessible(): boolean | cdktn.IResolvable;
    set publiclyAccessible(value: boolean | cdktn.IResolvable);
    resetPubliclyAccessible(): void;
    get publiclyAccessibleInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _securityGroupIds?;
    get securityGroupIds(): string[];
    set securityGroupIds(value: string[]);
    resetSecurityGroupIds(): void;
    get securityGroupIdsInput(): string[] | undefined;
    private _subnetIds?;
    get subnetIds(): string[];
    set subnetIds(value: string[]);
    resetSubnetIds(): void;
    get subnetIdsInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _highAvailabilityConfig;
    get highAvailabilityConfig(): AwsM2Environment.HighAvailabilityConfigPropertyList;
    putHighAvailabilityConfig(value: AwsM2Environment.HighAvailabilityConfigProperty[] | cdktn.IResolvable): void;
    resetHighAvailabilityConfig(): void;
    get highAvailabilityConfigInput(): cdktn.IResolvable | AwsM2Environment.HighAvailabilityConfigProperty[] | undefined;
    private _storageConfiguration;
    get storageConfiguration(): AwsM2Environment.StorageConfigurationPropertyList;
    putStorageConfiguration(value: AwsM2Environment.StorageConfigurationProperty[] | cdktn.IResolvable): void;
    resetStorageConfiguration(): void;
    get storageConfigurationInput(): cdktn.IResolvable | AwsM2Environment.StorageConfigurationProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsM2Environment.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsM2Environment.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsM2Environment.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsM2EnvironmentHighAvailabilityConfigPropertyToTerraform(struct?: AwsM2Environment.HighAvailabilityConfigProperty | cdktn.IResolvable): any;
export declare function awsM2EnvironmentHighAvailabilityConfigPropertyToHclTerraform(struct?: AwsM2Environment.HighAvailabilityConfigProperty | cdktn.IResolvable): any;
export declare function awsM2EnvironmentEfsPropertyToTerraform(struct?: AwsM2Environment.EfsProperty | cdktn.IResolvable): any;
export declare function awsM2EnvironmentEfsPropertyToHclTerraform(struct?: AwsM2Environment.EfsProperty | cdktn.IResolvable): any;
export declare function awsM2EnvironmentFsxPropertyToTerraform(struct?: AwsM2Environment.FsxProperty | cdktn.IResolvable): any;
export declare function awsM2EnvironmentFsxPropertyToHclTerraform(struct?: AwsM2Environment.FsxProperty | cdktn.IResolvable): any;
export declare function awsM2EnvironmentStorageConfigurationPropertyToTerraform(struct?: AwsM2Environment.StorageConfigurationProperty | cdktn.IResolvable): any;
export declare function awsM2EnvironmentStorageConfigurationPropertyToHclTerraform(struct?: AwsM2Environment.StorageConfigurationProperty | cdktn.IResolvable): any;
export declare function awsM2EnvironmentTimeoutsPropertyToTerraform(struct?: AwsM2Environment.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsM2EnvironmentTimeoutsPropertyToHclTerraform(struct?: AwsM2Environment.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsM2Environment {
    interface HighAvailabilityConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#desired_capacity AwsM2Environment#desired_capacity}
        */
        readonly desiredCapacity: number;
    }
    class HighAvailabilityConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HighAvailabilityConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HighAvailabilityConfigProperty | cdktn.IResolvable | undefined);
        private _desiredCapacity?;
        get desiredCapacity(): number;
        set desiredCapacity(value: number);
        get desiredCapacityInput(): number | undefined;
    }
    class HighAvailabilityConfigPropertyList extends cdktn.ComplexList {
        internalValue?: HighAvailabilityConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HighAvailabilityConfigPropertyOutputReference;
    }
    interface EfsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#file_system_id AwsM2Environment#file_system_id}
        */
        readonly fileSystemId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#mount_point AwsM2Environment#mount_point}
        */
        readonly mountPoint: string;
    }
    class EfsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EfsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EfsProperty | cdktn.IResolvable | undefined);
        private _fileSystemId?;
        get fileSystemId(): string;
        set fileSystemId(value: string);
        get fileSystemIdInput(): string | undefined;
        private _mountPoint?;
        get mountPoint(): string;
        set mountPoint(value: string);
        get mountPointInput(): string | undefined;
    }
    class EfsPropertyList extends cdktn.ComplexList {
        internalValue?: EfsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EfsPropertyOutputReference;
    }
    interface FsxProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#file_system_id AwsM2Environment#file_system_id}
        */
        readonly fileSystemId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#mount_point AwsM2Environment#mount_point}
        */
        readonly mountPoint: string;
    }
    class FsxPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FsxProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FsxProperty | cdktn.IResolvable | undefined);
        private _fileSystemId?;
        get fileSystemId(): string;
        set fileSystemId(value: string);
        get fileSystemIdInput(): string | undefined;
        private _mountPoint?;
        get mountPoint(): string;
        set mountPoint(value: string);
        get mountPointInput(): string | undefined;
    }
    class FsxPropertyList extends cdktn.ComplexList {
        internalValue?: FsxProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FsxPropertyOutputReference;
    }
    interface StorageConfigurationProperty {
        /**
        * efs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#efs AwsM2Environment#efs}
        */
        readonly efs?: EfsProperty[] | cdktn.IResolvable;
        /**
        * fsx block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#fsx AwsM2Environment#fsx}
        */
        readonly fsx?: FsxProperty[] | cdktn.IResolvable;
    }
    class StorageConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StorageConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StorageConfigurationProperty | cdktn.IResolvable | undefined);
        private _efs;
        get efs(): EfsPropertyList;
        putEfs(value: EfsProperty[] | cdktn.IResolvable): void;
        resetEfs(): void;
        get efsInput(): cdktn.IResolvable | EfsProperty[] | undefined;
        private _fsx;
        get fsx(): FsxPropertyList;
        putFsx(value: FsxProperty[] | cdktn.IResolvable): void;
        resetFsx(): void;
        get fsxInput(): cdktn.IResolvable | FsxProperty[] | undefined;
    }
    class StorageConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: StorageConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StorageConfigurationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#create AwsM2Environment#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#delete AwsM2Environment#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/m2_environment#update AwsM2Environment#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
