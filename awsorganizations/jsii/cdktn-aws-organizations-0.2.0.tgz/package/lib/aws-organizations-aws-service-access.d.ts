import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfAwsServiceAccessConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/organizations_aws_service_access#service_principal TfAwsServiceAccess#service_principal}
    */
    readonly servicePrincipal: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/organizations_aws_service_access aws_organizations_aws_service_access}
*/
export declare class TfAwsServiceAccess extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_organizations_aws_service_access";
    /**
    * Generates CDKTN code for importing a TfAwsServiceAccess resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfAwsServiceAccess to import
    * @param importFromId The id of the existing TfAwsServiceAccess that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/organizations_aws_service_access#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfAwsServiceAccess to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/organizations_aws_service_access aws_organizations_aws_service_access} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfAwsServiceAccessConfig
    */
    constructor(scope: Construct, id: string, config: TfAwsServiceAccessConfig);
    get dateEnabled(): string;
    private _servicePrincipal?;
    get servicePrincipal(): string;
    set servicePrincipal(value: string);
    get servicePrincipalInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
