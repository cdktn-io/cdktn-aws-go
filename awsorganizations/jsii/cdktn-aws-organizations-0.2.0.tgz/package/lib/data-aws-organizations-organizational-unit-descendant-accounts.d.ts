import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfOrganizationalUnitDescendantAccountsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/organizations_organizational_unit_descendant_accounts#id DataTfOrganizationalUnitDescendantAccounts#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/organizations_organizational_unit_descendant_accounts#parent_id DataTfOrganizationalUnitDescendantAccounts#parent_id}
    */
    readonly parentId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/organizations_organizational_unit_descendant_accounts aws_organizations_organizational_unit_descendant_accounts}
*/
export declare class DataTfOrganizationalUnitDescendantAccounts extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_organizations_organizational_unit_descendant_accounts";
    /**
    * Generates CDKTN code for importing a DataTfOrganizationalUnitDescendantAccounts resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfOrganizationalUnitDescendantAccounts to import
    * @param importFromId The id of the existing DataTfOrganizationalUnitDescendantAccounts that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/organizations_organizational_unit_descendant_accounts#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfOrganizationalUnitDescendantAccounts to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/organizations_organizational_unit_descendant_accounts aws_organizations_organizational_unit_descendant_accounts} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfOrganizationalUnitDescendantAccountsConfig
    */
    constructor(scope: Construct, id: string, config: DataTfOrganizationalUnitDescendantAccountsConfig);
    private _accounts;
    get accounts(): DataTfOrganizationalUnitDescendantAccounts.AccountsPropertyList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _parentId?;
    get parentId(): string;
    set parentId(value: string);
    get parentIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfOrganizationalUnitDescendantAccountsAccountsPropertyToTerraform(struct?: DataTfOrganizationalUnitDescendantAccounts.AccountsProperty): any;
export declare function dataTfOrganizationalUnitDescendantAccountsAccountsPropertyToHclTerraform(struct?: DataTfOrganizationalUnitDescendantAccounts.AccountsProperty): any;
export declare namespace DataTfOrganizationalUnitDescendantAccounts {
    interface AccountsProperty {
    }
    class AccountsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AccountsProperty | undefined;
        set internalValue(value: AccountsProperty | undefined);
        get arn(): string;
        get email(): string;
        get id(): string;
        get joinedMethod(): string;
        get joinedTimestamp(): string;
        get name(): string;
        get state(): string;
        get status(): string;
    }
    class AccountsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AccountsPropertyOutputReference;
    }
}
