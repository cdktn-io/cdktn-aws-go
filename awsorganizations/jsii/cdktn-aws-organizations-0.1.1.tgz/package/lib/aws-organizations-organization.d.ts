import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsOrganizationsOrganizationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/organizations_organization#aws_service_access_principals AwsOrganizationsOrganization#aws_service_access_principals}
    */
    readonly awsServiceAccessPrincipals?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/organizations_organization#enabled_policy_types AwsOrganizationsOrganization#enabled_policy_types}
    */
    readonly enabledPolicyTypes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/organizations_organization#feature_set AwsOrganizationsOrganization#feature_set}
    */
    readonly featureSet?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/organizations_organization#id AwsOrganizationsOrganization#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/organizations_organization#return_organization_only AwsOrganizationsOrganization#return_organization_only}
    */
    readonly returnOrganizationOnly?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/organizations_organization aws_organizations_organization}
*/
export declare class AwsOrganizationsOrganization extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_organizations_organization";
    /**
    * Generates CDKTN code for importing a AwsOrganizationsOrganization resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsOrganizationsOrganization to import
    * @param importFromId The id of the existing AwsOrganizationsOrganization that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/organizations_organization#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsOrganizationsOrganization to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/organizations_organization aws_organizations_organization} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsOrganizationsOrganizationConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsOrganizationsOrganizationConfig);
    private _accounts;
    get accounts(): AwsOrganizationsOrganization.AccountsPropertyList;
    get arn(): string;
    private _awsServiceAccessPrincipals?;
    get awsServiceAccessPrincipals(): string[];
    set awsServiceAccessPrincipals(value: string[]);
    resetAwsServiceAccessPrincipals(): void;
    get awsServiceAccessPrincipalsInput(): string[] | undefined;
    private _enabledPolicyTypes?;
    get enabledPolicyTypes(): string[];
    set enabledPolicyTypes(value: string[]);
    resetEnabledPolicyTypes(): void;
    get enabledPolicyTypesInput(): string[] | undefined;
    private _featureSet?;
    get featureSet(): string;
    set featureSet(value: string);
    resetFeatureSet(): void;
    get featureSetInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get masterAccountArn(): string;
    get masterAccountEmail(): string;
    get masterAccountId(): string;
    get masterAccountName(): string;
    private _nonMasterAccounts;
    get nonMasterAccounts(): AwsOrganizationsOrganization.NonMasterAccountsPropertyList;
    private _returnOrganizationOnly?;
    get returnOrganizationOnly(): boolean | cdktn.IResolvable;
    set returnOrganizationOnly(value: boolean | cdktn.IResolvable);
    resetReturnOrganizationOnly(): void;
    get returnOrganizationOnlyInput(): boolean | cdktn.IResolvable | undefined;
    private _roots;
    get roots(): AwsOrganizationsOrganization.RootsPropertyList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsOrganizationsOrganizationAccountsPropertyToTerraform(struct?: AwsOrganizationsOrganization.AccountsProperty): any;
export declare function awsOrganizationsOrganizationAccountsPropertyToHclTerraform(struct?: AwsOrganizationsOrganization.AccountsProperty): any;
export declare function awsOrganizationsOrganizationNonMasterAccountsPropertyToTerraform(struct?: AwsOrganizationsOrganization.NonMasterAccountsProperty): any;
export declare function awsOrganizationsOrganizationNonMasterAccountsPropertyToHclTerraform(struct?: AwsOrganizationsOrganization.NonMasterAccountsProperty): any;
export declare function awsOrganizationsOrganizationPolicyTypesPropertyToTerraform(struct?: AwsOrganizationsOrganization.PolicyTypesProperty): any;
export declare function awsOrganizationsOrganizationPolicyTypesPropertyToHclTerraform(struct?: AwsOrganizationsOrganization.PolicyTypesProperty): any;
export declare function awsOrganizationsOrganizationRootsPropertyToTerraform(struct?: AwsOrganizationsOrganization.RootsProperty): any;
export declare function awsOrganizationsOrganizationRootsPropertyToHclTerraform(struct?: AwsOrganizationsOrganization.RootsProperty): any;
export declare namespace AwsOrganizationsOrganization {
    interface AccountsProperty {
    }
    class AccountsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AccountsProperty | undefined;
        set internalValue(value: AccountsProperty | undefined);
        get arn(): string;
        get email(): string;
        get id(): string;
        get joinedMethod(): string;
        get joinedTimestamp(): string;
        get name(): string;
        get state(): string;
        get status(): string;
    }
    class AccountsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AccountsPropertyOutputReference;
    }
    interface NonMasterAccountsProperty {
    }
    class NonMasterAccountsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NonMasterAccountsProperty | undefined;
        set internalValue(value: NonMasterAccountsProperty | undefined);
        get arn(): string;
        get email(): string;
        get id(): string;
        get joinedMethod(): string;
        get joinedTimestamp(): string;
        get name(): string;
        get state(): string;
        get status(): string;
    }
    class NonMasterAccountsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NonMasterAccountsPropertyOutputReference;
    }
    interface PolicyTypesProperty {
    }
    class PolicyTypesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PolicyTypesProperty | undefined;
        set internalValue(value: PolicyTypesProperty | undefined);
        get status(): string;
        get type(): string;
    }
    class PolicyTypesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PolicyTypesPropertyOutputReference;
    }
    interface RootsProperty {
    }
    class RootsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RootsProperty | undefined;
        set internalValue(value: RootsProperty | undefined);
        get arn(): string;
        get id(): string;
        get name(): string;
        private _policyTypes;
        get policyTypes(): PolicyTypesPropertyList;
    }
    class RootsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RootsPropertyOutputReference;
    }
}
