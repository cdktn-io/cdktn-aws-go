import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsOrganizationsDelegatedServicesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/organizations_delegated_services#account_id DataAwsOrganizationsDelegatedServices#account_id}
    */
    readonly accountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/organizations_delegated_services#id DataAwsOrganizationsDelegatedServices#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/organizations_delegated_services aws_organizations_delegated_services}
*/
export declare class DataAwsOrganizationsDelegatedServices extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_organizations_delegated_services";
    /**
    * Generates CDKTN code for importing a DataAwsOrganizationsDelegatedServices resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsOrganizationsDelegatedServices to import
    * @param importFromId The id of the existing DataAwsOrganizationsDelegatedServices that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/organizations_delegated_services#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsOrganizationsDelegatedServices to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/organizations_delegated_services aws_organizations_delegated_services} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsOrganizationsDelegatedServicesConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsOrganizationsDelegatedServicesConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _delegatedServices;
    get delegatedServices(): DataAwsOrganizationsDelegatedServices.DelegatedServicesPropertyList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsOrganizationsDelegatedServicesDelegatedServicesPropertyToTerraform(struct?: DataAwsOrganizationsDelegatedServices.DelegatedServicesProperty): any;
export declare function dataAwsOrganizationsDelegatedServicesDelegatedServicesPropertyToHclTerraform(struct?: DataAwsOrganizationsDelegatedServices.DelegatedServicesProperty): any;
export declare namespace DataAwsOrganizationsDelegatedServices {
    interface DelegatedServicesProperty {
    }
    class DelegatedServicesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DelegatedServicesProperty | undefined;
        set internalValue(value: DelegatedServicesProperty | undefined);
        get delegationEnabledDate(): string;
        get servicePrincipal(): string;
    }
    class DelegatedServicesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DelegatedServicesPropertyOutputReference;
    }
}
