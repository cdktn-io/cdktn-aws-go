import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsImagesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecr_images#region DataAwsImages#region}
    */
    readonly region?: string;
    /**
    * ID of the registry (AWS account ID)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecr_images#registry_id DataAwsImages#registry_id}
    */
    readonly registryId?: string;
    /**
    * Name of the repository
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecr_images#repository_name DataAwsImages#repository_name}
    */
    readonly repositoryName: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecr_images aws_ecr_images}
*/
export declare class DataAwsImages extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_ecr_images";
    /**
    * Generates CDKTN code for importing a DataAwsImages resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsImages to import
    * @param importFromId The id of the existing DataAwsImages that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecr_images#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsImages to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecr_images aws_ecr_images} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsImagesConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsImagesConfig);
    private _imageIds;
    get imageIds(): DataAwsImages.ImageIdsPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _registryId?;
    get registryId(): string;
    set registryId(value: string);
    resetRegistryId(): void;
    get registryIdInput(): string | undefined;
    private _repositoryName?;
    get repositoryName(): string;
    set repositoryName(value: string);
    get repositoryNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsImagesImageIdsPropertyToTerraform(struct?: DataAwsImages.ImageIdsProperty): any;
export declare function dataAwsImagesImageIdsPropertyToHclTerraform(struct?: DataAwsImages.ImageIdsProperty): any;
export declare namespace DataAwsImages {
    interface ImageIdsProperty {
    }
    class ImageIdsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ImageIdsProperty | undefined;
        set internalValue(value: ImageIdsProperty | undefined);
        get imageDigest(): string;
        get imageTag(): string;
    }
    class ImageIdsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ImageIdsPropertyOutputReference;
    }
}
