import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsLifecyclePolicyDocumentConfig extends cdktn.TerraformMetaArguments {
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecr_lifecycle_policy_document#rule DataAwsLifecyclePolicyDocument#rule}
    */
    readonly rule?: DataAwsLifecyclePolicyDocument.RuleProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecr_lifecycle_policy_document aws_ecr_lifecycle_policy_document}
*/
export declare class DataAwsLifecyclePolicyDocument extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_ecr_lifecycle_policy_document";
    /**
    * Generates CDKTN code for importing a DataAwsLifecyclePolicyDocument resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsLifecyclePolicyDocument to import
    * @param importFromId The id of the existing DataAwsLifecyclePolicyDocument that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecr_lifecycle_policy_document#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsLifecyclePolicyDocument to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecr_lifecycle_policy_document aws_ecr_lifecycle_policy_document} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsLifecyclePolicyDocumentConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsLifecyclePolicyDocumentConfig);
    get json(): string;
    private _rule;
    get rule(): DataAwsLifecyclePolicyDocument.RulePropertyList;
    putRule(value: DataAwsLifecyclePolicyDocument.RuleProperty[] | cdktn.IResolvable): void;
    resetRule(): void;
    get ruleInput(): cdktn.IResolvable | DataAwsLifecyclePolicyDocument.RuleProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsLifecyclePolicyDocumentActionPropertyToTerraform(struct?: DataAwsLifecyclePolicyDocument.ActionProperty | cdktn.IResolvable): any;
export declare function dataAwsLifecyclePolicyDocumentActionPropertyToHclTerraform(struct?: DataAwsLifecyclePolicyDocument.ActionProperty | cdktn.IResolvable): any;
export declare function dataAwsLifecyclePolicyDocumentSelectionPropertyToTerraform(struct?: DataAwsLifecyclePolicyDocument.SelectionProperty | cdktn.IResolvable): any;
export declare function dataAwsLifecyclePolicyDocumentSelectionPropertyToHclTerraform(struct?: DataAwsLifecyclePolicyDocument.SelectionProperty | cdktn.IResolvable): any;
export declare function dataAwsLifecyclePolicyDocumentRulePropertyToTerraform(struct?: DataAwsLifecyclePolicyDocument.RuleProperty | cdktn.IResolvable): any;
export declare function dataAwsLifecyclePolicyDocumentRulePropertyToHclTerraform(struct?: DataAwsLifecyclePolicyDocument.RuleProperty | cdktn.IResolvable): any;
export declare namespace DataAwsLifecyclePolicyDocument {
    interface ActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecr_lifecycle_policy_document#target_storage_class DataAwsLifecyclePolicyDocument#target_storage_class}
        */
        readonly targetStorageClass?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecr_lifecycle_policy_document#type DataAwsLifecyclePolicyDocument#type}
        */
        readonly type: string;
    }
    class ActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ActionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ActionProperty | cdktn.IResolvable | undefined);
        private _targetStorageClass?;
        get targetStorageClass(): string;
        set targetStorageClass(value: string);
        resetTargetStorageClass(): void;
        get targetStorageClassInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class ActionPropertyList extends cdktn.ComplexList {
        internalValue?: ActionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ActionPropertyOutputReference;
    }
    interface SelectionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecr_lifecycle_policy_document#count_number DataAwsLifecyclePolicyDocument#count_number}
        */
        readonly countNumber: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecr_lifecycle_policy_document#count_type DataAwsLifecyclePolicyDocument#count_type}
        */
        readonly countType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecr_lifecycle_policy_document#count_unit DataAwsLifecyclePolicyDocument#count_unit}
        */
        readonly countUnit?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecr_lifecycle_policy_document#storage_class DataAwsLifecyclePolicyDocument#storage_class}
        */
        readonly storageClass?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecr_lifecycle_policy_document#tag_pattern_list DataAwsLifecyclePolicyDocument#tag_pattern_list}
        */
        readonly tagPatternList?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecr_lifecycle_policy_document#tag_prefix_list DataAwsLifecyclePolicyDocument#tag_prefix_list}
        */
        readonly tagPrefixList?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecr_lifecycle_policy_document#tag_status DataAwsLifecyclePolicyDocument#tag_status}
        */
        readonly tagStatus: string;
    }
    class SelectionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SelectionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SelectionProperty | cdktn.IResolvable | undefined);
        private _countNumber?;
        get countNumber(): number;
        set countNumber(value: number);
        get countNumberInput(): number | undefined;
        private _countType?;
        get countType(): string;
        set countType(value: string);
        get countTypeInput(): string | undefined;
        private _countUnit?;
        get countUnit(): string;
        set countUnit(value: string);
        resetCountUnit(): void;
        get countUnitInput(): string | undefined;
        private _storageClass?;
        get storageClass(): string;
        set storageClass(value: string);
        resetStorageClass(): void;
        get storageClassInput(): string | undefined;
        private _tagPatternList?;
        get tagPatternList(): string[];
        set tagPatternList(value: string[]);
        resetTagPatternList(): void;
        get tagPatternListInput(): string[] | undefined;
        private _tagPrefixList?;
        get tagPrefixList(): string[];
        set tagPrefixList(value: string[]);
        resetTagPrefixList(): void;
        get tagPrefixListInput(): string[] | undefined;
        private _tagStatus?;
        get tagStatus(): string;
        set tagStatus(value: string);
        get tagStatusInput(): string | undefined;
    }
    class SelectionPropertyList extends cdktn.ComplexList {
        internalValue?: SelectionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SelectionPropertyOutputReference;
    }
    interface RuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecr_lifecycle_policy_document#description DataAwsLifecyclePolicyDocument#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecr_lifecycle_policy_document#priority DataAwsLifecyclePolicyDocument#priority}
        */
        readonly priority: number;
        /**
        * action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecr_lifecycle_policy_document#action DataAwsLifecyclePolicyDocument#action}
        */
        readonly action?: ActionProperty[] | cdktn.IResolvable;
        /**
        * selection block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecr_lifecycle_policy_document#selection DataAwsLifecyclePolicyDocument#selection}
        */
        readonly selection?: SelectionProperty[] | cdktn.IResolvable;
    }
    class RulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _priority?;
        get priority(): number;
        set priority(value: number);
        get priorityInput(): number | undefined;
        private _action;
        get action(): ActionPropertyList;
        putAction(value: ActionProperty[] | cdktn.IResolvable): void;
        resetAction(): void;
        get actionInput(): cdktn.IResolvable | ActionProperty[] | undefined;
        private _selection;
        get selection(): SelectionPropertyList;
        putSelection(value: SelectionProperty[] | cdktn.IResolvable): void;
        resetSelection(): void;
        get selectionInput(): cdktn.IResolvable | SelectionProperty[] | undefined;
    }
    class RulePropertyList extends cdktn.ComplexList {
        internalValue?: RuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulePropertyOutputReference;
    }
}
