import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsRepositoryConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_repository#force_delete AwsRepository#force_delete}
    */
    readonly forceDelete?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_repository#id AwsRepository#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_repository#image_tag_mutability AwsRepository#image_tag_mutability}
    */
    readonly imageTagMutability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_repository#name AwsRepository#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_repository#region AwsRepository#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_repository#tags AwsRepository#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_repository#tags_all AwsRepository#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * encryption_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_repository#encryption_configuration AwsRepository#encryption_configuration}
    */
    readonly encryptionConfiguration?: AwsRepository.EncryptionConfigurationProperty[] | cdktn.IResolvable;
    /**
    * image_scanning_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_repository#image_scanning_configuration AwsRepository#image_scanning_configuration}
    */
    readonly imageScanningConfiguration?: AwsRepository.ImageScanningConfigurationProperty;
    /**
    * image_tag_mutability_exclusion_filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_repository#image_tag_mutability_exclusion_filter AwsRepository#image_tag_mutability_exclusion_filter}
    */
    readonly imageTagMutabilityExclusionFilter?: AwsRepository.ImageTagMutabilityExclusionFilterProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_repository#timeouts AwsRepository#timeouts}
    */
    readonly timeouts?: AwsRepository.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_repository aws_ecr_repository}
*/
export declare class AwsRepository extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ecr_repository";
    /**
    * Generates CDKTN code for importing a AwsRepository resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsRepository to import
    * @param importFromId The id of the existing AwsRepository that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_repository#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsRepository to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_repository aws_ecr_repository} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsRepositoryConfig
    */
    constructor(scope: Construct, id: string, config: AwsRepositoryConfig);
    get arn(): string;
    private _forceDelete?;
    get forceDelete(): boolean | cdktn.IResolvable;
    set forceDelete(value: boolean | cdktn.IResolvable);
    resetForceDelete(): void;
    get forceDeleteInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _imageTagMutability?;
    get imageTagMutability(): string;
    set imageTagMutability(value: string);
    resetImageTagMutability(): void;
    get imageTagMutabilityInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get registryId(): string;
    get repositoryUrl(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _encryptionConfiguration;
    get encryptionConfiguration(): AwsRepository.EncryptionConfigurationPropertyList;
    putEncryptionConfiguration(value: AwsRepository.EncryptionConfigurationProperty[] | cdktn.IResolvable): void;
    resetEncryptionConfiguration(): void;
    get encryptionConfigurationInput(): cdktn.IResolvable | AwsRepository.EncryptionConfigurationProperty[] | undefined;
    private _imageScanningConfiguration;
    get imageScanningConfiguration(): AwsRepository.ImageScanningConfigurationPropertyOutputReference;
    putImageScanningConfiguration(value: AwsRepository.ImageScanningConfigurationProperty): void;
    resetImageScanningConfiguration(): void;
    get imageScanningConfigurationInput(): AwsRepository.ImageScanningConfigurationProperty | undefined;
    private _imageTagMutabilityExclusionFilter;
    get imageTagMutabilityExclusionFilter(): AwsRepository.ImageTagMutabilityExclusionFilterPropertyList;
    putImageTagMutabilityExclusionFilter(value: AwsRepository.ImageTagMutabilityExclusionFilterProperty[] | cdktn.IResolvable): void;
    resetImageTagMutabilityExclusionFilter(): void;
    get imageTagMutabilityExclusionFilterInput(): cdktn.IResolvable | AwsRepository.ImageTagMutabilityExclusionFilterProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsRepository.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsRepository.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsRepository.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsRepositoryEncryptionConfigurationPropertyToTerraform(struct?: AwsRepository.EncryptionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsRepositoryEncryptionConfigurationPropertyToHclTerraform(struct?: AwsRepository.EncryptionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsRepositoryImageScanningConfigurationPropertyToTerraform(struct?: AwsRepository.ImageScanningConfigurationPropertyOutputReference | AwsRepository.ImageScanningConfigurationProperty): any;
export declare function awsRepositoryImageScanningConfigurationPropertyToHclTerraform(struct?: AwsRepository.ImageScanningConfigurationPropertyOutputReference | AwsRepository.ImageScanningConfigurationProperty): any;
export declare function awsRepositoryImageTagMutabilityExclusionFilterPropertyToTerraform(struct?: AwsRepository.ImageTagMutabilityExclusionFilterProperty | cdktn.IResolvable): any;
export declare function awsRepositoryImageTagMutabilityExclusionFilterPropertyToHclTerraform(struct?: AwsRepository.ImageTagMutabilityExclusionFilterProperty | cdktn.IResolvable): any;
export declare function awsRepositoryTimeoutsPropertyToTerraform(struct?: AwsRepository.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsRepositoryTimeoutsPropertyToHclTerraform(struct?: AwsRepository.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsRepository {
    interface EncryptionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_repository#encryption_type AwsRepository#encryption_type}
        */
        readonly encryptionType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_repository#kms_key AwsRepository#kms_key}
        */
        readonly kmsKey?: string;
    }
    class EncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EncryptionConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EncryptionConfigurationProperty | cdktn.IResolvable | undefined);
        private _encryptionType?;
        get encryptionType(): string;
        set encryptionType(value: string);
        resetEncryptionType(): void;
        get encryptionTypeInput(): string | undefined;
        private _kmsKey?;
        get kmsKey(): string;
        set kmsKey(value: string);
        resetKmsKey(): void;
        get kmsKeyInput(): string | undefined;
    }
    class EncryptionConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: EncryptionConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EncryptionConfigurationPropertyOutputReference;
    }
    interface ImageScanningConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_repository#scan_on_push AwsRepository#scan_on_push}
        */
        readonly scanOnPush: boolean | cdktn.IResolvable;
    }
    class ImageScanningConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ImageScanningConfigurationProperty | undefined;
        set internalValue(value: ImageScanningConfigurationProperty | undefined);
        private _scanOnPush?;
        get scanOnPush(): boolean | cdktn.IResolvable;
        set scanOnPush(value: boolean | cdktn.IResolvable);
        get scanOnPushInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface ImageTagMutabilityExclusionFilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_repository#filter AwsRepository#filter}
        */
        readonly filter: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_repository#filter_type AwsRepository#filter_type}
        */
        readonly filterType: string;
    }
    class ImageTagMutabilityExclusionFilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ImageTagMutabilityExclusionFilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ImageTagMutabilityExclusionFilterProperty | cdktn.IResolvable | undefined);
        private _filter?;
        get filter(): string;
        set filter(value: string);
        get filterInput(): string | undefined;
        private _filterType?;
        get filterType(): string;
        set filterType(value: string);
        get filterTypeInput(): string | undefined;
    }
    class ImageTagMutabilityExclusionFilterPropertyList extends cdktn.ComplexList {
        internalValue?: ImageTagMutabilityExclusionFilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ImageTagMutabilityExclusionFilterPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_repository#delete AwsRepository#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
