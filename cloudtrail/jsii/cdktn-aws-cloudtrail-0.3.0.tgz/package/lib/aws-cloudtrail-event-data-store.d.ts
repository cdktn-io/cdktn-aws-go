import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsEventDataStoreConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail_event_data_store#billing_mode AwsEventDataStore#billing_mode}
    */
    readonly billingMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail_event_data_store#id AwsEventDataStore#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail_event_data_store#kms_key_id AwsEventDataStore#kms_key_id}
    */
    readonly kmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail_event_data_store#multi_region_enabled AwsEventDataStore#multi_region_enabled}
    */
    readonly multiRegionEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail_event_data_store#name AwsEventDataStore#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail_event_data_store#organization_enabled AwsEventDataStore#organization_enabled}
    */
    readonly organizationEnabled?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail_event_data_store#region AwsEventDataStore#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail_event_data_store#retention_period AwsEventDataStore#retention_period}
    */
    readonly retentionPeriod?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail_event_data_store#suspend AwsEventDataStore#suspend}
    */
    readonly suspend?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail_event_data_store#tags AwsEventDataStore#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail_event_data_store#tags_all AwsEventDataStore#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail_event_data_store#termination_protection_enabled AwsEventDataStore#termination_protection_enabled}
    */
    readonly terminationProtectionEnabled?: boolean | cdktn.IResolvable;
    /**
    * advanced_event_selector block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail_event_data_store#advanced_event_selector AwsEventDataStore#advanced_event_selector}
    */
    readonly advancedEventSelector?: AwsEventDataStore.AdvancedEventSelectorProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail_event_data_store#timeouts AwsEventDataStore#timeouts}
    */
    readonly timeouts?: AwsEventDataStore.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail_event_data_store aws_cloudtrail_event_data_store}
*/
export declare class AwsEventDataStore extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudtrail_event_data_store";
    /**
    * Generates CDKTN code for importing a AwsEventDataStore resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsEventDataStore to import
    * @param importFromId The id of the existing AwsEventDataStore that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail_event_data_store#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsEventDataStore to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail_event_data_store aws_cloudtrail_event_data_store} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsEventDataStoreConfig
    */
    constructor(scope: Construct, id: string, config: AwsEventDataStoreConfig);
    get arn(): string;
    private _billingMode?;
    get billingMode(): string;
    set billingMode(value: string);
    resetBillingMode(): void;
    get billingModeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    resetKmsKeyId(): void;
    get kmsKeyIdInput(): string | undefined;
    private _multiRegionEnabled?;
    get multiRegionEnabled(): boolean | cdktn.IResolvable;
    set multiRegionEnabled(value: boolean | cdktn.IResolvable);
    resetMultiRegionEnabled(): void;
    get multiRegionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _organizationEnabled?;
    get organizationEnabled(): boolean | cdktn.IResolvable;
    set organizationEnabled(value: boolean | cdktn.IResolvable);
    resetOrganizationEnabled(): void;
    get organizationEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _retentionPeriod?;
    get retentionPeriod(): number;
    set retentionPeriod(value: number);
    resetRetentionPeriod(): void;
    get retentionPeriodInput(): number | undefined;
    private _suspend?;
    get suspend(): string;
    set suspend(value: string);
    resetSuspend(): void;
    get suspendInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _terminationProtectionEnabled?;
    get terminationProtectionEnabled(): boolean | cdktn.IResolvable;
    set terminationProtectionEnabled(value: boolean | cdktn.IResolvable);
    resetTerminationProtectionEnabled(): void;
    get terminationProtectionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _advancedEventSelector;
    get advancedEventSelector(): AwsEventDataStore.AdvancedEventSelectorPropertyList;
    putAdvancedEventSelector(value: AwsEventDataStore.AdvancedEventSelectorProperty[] | cdktn.IResolvable): void;
    resetAdvancedEventSelector(): void;
    get advancedEventSelectorInput(): cdktn.IResolvable | AwsEventDataStore.AdvancedEventSelectorProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsEventDataStore.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsEventDataStore.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsEventDataStore.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsEventDataStoreFieldSelectorPropertyToTerraform(struct?: AwsEventDataStore.FieldSelectorProperty | cdktn.IResolvable): any;
export declare function awsEventDataStoreFieldSelectorPropertyToHclTerraform(struct?: AwsEventDataStore.FieldSelectorProperty | cdktn.IResolvable): any;
export declare function awsEventDataStoreAdvancedEventSelectorPropertyToTerraform(struct?: AwsEventDataStore.AdvancedEventSelectorProperty | cdktn.IResolvable): any;
export declare function awsEventDataStoreAdvancedEventSelectorPropertyToHclTerraform(struct?: AwsEventDataStore.AdvancedEventSelectorProperty | cdktn.IResolvable): any;
export declare function awsEventDataStoreTimeoutsPropertyToTerraform(struct?: AwsEventDataStore.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsEventDataStoreTimeoutsPropertyToHclTerraform(struct?: AwsEventDataStore.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsEventDataStore {
    interface FieldSelectorProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail_event_data_store#ends_with AwsEventDataStore#ends_with}
        */
        readonly endsWith?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail_event_data_store#equals AwsEventDataStore#equals}
        */
        readonly equalTo?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail_event_data_store#field AwsEventDataStore#field}
        */
        readonly field?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail_event_data_store#not_ends_with AwsEventDataStore#not_ends_with}
        */
        readonly notEndsWith?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail_event_data_store#not_equals AwsEventDataStore#not_equals}
        */
        readonly notEquals?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail_event_data_store#not_starts_with AwsEventDataStore#not_starts_with}
        */
        readonly notStartsWith?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail_event_data_store#starts_with AwsEventDataStore#starts_with}
        */
        readonly startsWith?: string[];
    }
    class FieldSelectorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FieldSelectorProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FieldSelectorProperty | cdktn.IResolvable | undefined);
        private _endsWith?;
        get endsWith(): string[];
        set endsWith(value: string[]);
        resetEndsWith(): void;
        get endsWithInput(): string[] | undefined;
        private _equals?;
        get equalTo(): string[];
        set equalTo(value: string[]);
        resetEqualTo(): void;
        get equalToInput(): string[] | undefined;
        private _field?;
        get field(): string;
        set field(value: string);
        resetField(): void;
        get fieldInput(): string | undefined;
        private _notEndsWith?;
        get notEndsWith(): string[];
        set notEndsWith(value: string[]);
        resetNotEndsWith(): void;
        get notEndsWithInput(): string[] | undefined;
        private _notEquals?;
        get notEquals(): string[];
        set notEquals(value: string[]);
        resetNotEquals(): void;
        get notEqualsInput(): string[] | undefined;
        private _notStartsWith?;
        get notStartsWith(): string[];
        set notStartsWith(value: string[]);
        resetNotStartsWith(): void;
        get notStartsWithInput(): string[] | undefined;
        private _startsWith?;
        get startsWith(): string[];
        set startsWith(value: string[]);
        resetStartsWith(): void;
        get startsWithInput(): string[] | undefined;
    }
    class FieldSelectorPropertyList extends cdktn.ComplexList {
        internalValue?: FieldSelectorProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FieldSelectorPropertyOutputReference;
    }
    interface AdvancedEventSelectorProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail_event_data_store#name AwsEventDataStore#name}
        */
        readonly name?: string;
        /**
        * field_selector block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail_event_data_store#field_selector AwsEventDataStore#field_selector}
        */
        readonly fieldSelector?: FieldSelectorProperty[] | cdktn.IResolvable;
    }
    class AdvancedEventSelectorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AdvancedEventSelectorProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AdvancedEventSelectorProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _fieldSelector;
        get fieldSelector(): FieldSelectorPropertyList;
        putFieldSelector(value: FieldSelectorProperty[] | cdktn.IResolvable): void;
        resetFieldSelector(): void;
        get fieldSelectorInput(): cdktn.IResolvable | FieldSelectorProperty[] | undefined;
    }
    class AdvancedEventSelectorPropertyList extends cdktn.ComplexList {
        internalValue?: AdvancedEventSelectorProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AdvancedEventSelectorPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail_event_data_store#create AwsEventDataStore#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail_event_data_store#delete AwsEventDataStore#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail_event_data_store#update AwsEventDataStore#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
