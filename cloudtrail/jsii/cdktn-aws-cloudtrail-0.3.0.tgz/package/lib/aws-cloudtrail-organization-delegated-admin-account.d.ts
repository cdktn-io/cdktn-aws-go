import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsOrganizationDelegatedAdminAccountConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail_organization_delegated_admin_account#account_id AwsOrganizationDelegatedAdminAccount#account_id}
    */
    readonly accountId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail_organization_delegated_admin_account aws_cloudtrail_organization_delegated_admin_account}
*/
export declare class AwsOrganizationDelegatedAdminAccount extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudtrail_organization_delegated_admin_account";
    /**
    * Generates CDKTN code for importing a AwsOrganizationDelegatedAdminAccount resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsOrganizationDelegatedAdminAccount to import
    * @param importFromId The id of the existing AwsOrganizationDelegatedAdminAccount that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail_organization_delegated_admin_account#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsOrganizationDelegatedAdminAccount to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudtrail_organization_delegated_admin_account aws_cloudtrail_organization_delegated_admin_account} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsOrganizationDelegatedAdminAccountConfig
    */
    constructor(scope: Construct, id: string, config: AwsOrganizationDelegatedAdminAccountConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    get arn(): string;
    get email(): string;
    get id(): string;
    get name(): string;
    get servicePrincipal(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
