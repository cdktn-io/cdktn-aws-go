import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsComputeoptimizerRecommendationPreferencesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences#enhanced_infrastructure_metrics AwsComputeoptimizerRecommendationPreferences#enhanced_infrastructure_metrics}
    */
    readonly enhancedInfrastructureMetrics?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences#inferred_workload_types AwsComputeoptimizerRecommendationPreferences#inferred_workload_types}
    */
    readonly inferredWorkloadTypes?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences#look_back_period AwsComputeoptimizerRecommendationPreferences#look_back_period}
    */
    readonly lookBackPeriod?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences#region AwsComputeoptimizerRecommendationPreferences#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences#resource_type AwsComputeoptimizerRecommendationPreferences#resource_type}
    */
    readonly resourceType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences#savings_estimation_mode AwsComputeoptimizerRecommendationPreferences#savings_estimation_mode}
    */
    readonly savingsEstimationMode?: string;
    /**
    * external_metrics_preference block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences#external_metrics_preference AwsComputeoptimizerRecommendationPreferences#external_metrics_preference}
    */
    readonly externalMetricsPreference?: AwsComputeoptimizerRecommendationPreferences.ExternalMetricsPreferenceProperty[] | cdktn.IResolvable;
    /**
    * preferred_resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences#preferred_resource AwsComputeoptimizerRecommendationPreferences#preferred_resource}
    */
    readonly preferredResource?: AwsComputeoptimizerRecommendationPreferences.PreferredResourceProperty[] | cdktn.IResolvable;
    /**
    * scope block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences#scope AwsComputeoptimizerRecommendationPreferences#scope}
    */
    readonly scope?: AwsComputeoptimizerRecommendationPreferences.ScopeProperty[] | cdktn.IResolvable;
    /**
    * utilization_preference block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences#utilization_preference AwsComputeoptimizerRecommendationPreferences#utilization_preference}
    */
    readonly utilizationPreference?: AwsComputeoptimizerRecommendationPreferences.UtilizationPreferenceProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences aws_computeoptimizer_recommendation_preferences}
*/
export declare class AwsComputeoptimizerRecommendationPreferences extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_computeoptimizer_recommendation_preferences";
    /**
    * Generates CDKTN code for importing a AwsComputeoptimizerRecommendationPreferences resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsComputeoptimizerRecommendationPreferences to import
    * @param importFromId The id of the existing AwsComputeoptimizerRecommendationPreferences that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsComputeoptimizerRecommendationPreferences to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences aws_computeoptimizer_recommendation_preferences} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsComputeoptimizerRecommendationPreferencesConfig
    */
    constructor(scope: Construct, id: string, config: AwsComputeoptimizerRecommendationPreferencesConfig);
    private _enhancedInfrastructureMetrics?;
    get enhancedInfrastructureMetrics(): string;
    set enhancedInfrastructureMetrics(value: string);
    resetEnhancedInfrastructureMetrics(): void;
    get enhancedInfrastructureMetricsInput(): string | undefined;
    get id(): string;
    private _inferredWorkloadTypes?;
    get inferredWorkloadTypes(): string;
    set inferredWorkloadTypes(value: string);
    resetInferredWorkloadTypes(): void;
    get inferredWorkloadTypesInput(): string | undefined;
    private _lookBackPeriod?;
    get lookBackPeriod(): string;
    set lookBackPeriod(value: string);
    resetLookBackPeriod(): void;
    get lookBackPeriodInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourceType?;
    get resourceType(): string;
    set resourceType(value: string);
    get resourceTypeInput(): string | undefined;
    private _savingsEstimationMode?;
    get savingsEstimationMode(): string;
    set savingsEstimationMode(value: string);
    resetSavingsEstimationMode(): void;
    get savingsEstimationModeInput(): string | undefined;
    private _externalMetricsPreference;
    get externalMetricsPreference(): AwsComputeoptimizerRecommendationPreferences.ExternalMetricsPreferencePropertyList;
    putExternalMetricsPreference(value: AwsComputeoptimizerRecommendationPreferences.ExternalMetricsPreferenceProperty[] | cdktn.IResolvable): void;
    resetExternalMetricsPreference(): void;
    get externalMetricsPreferenceInput(): cdktn.IResolvable | AwsComputeoptimizerRecommendationPreferences.ExternalMetricsPreferenceProperty[] | undefined;
    private _preferredResource;
    get preferredResource(): AwsComputeoptimizerRecommendationPreferences.PreferredResourcePropertyList;
    putPreferredResource(value: AwsComputeoptimizerRecommendationPreferences.PreferredResourceProperty[] | cdktn.IResolvable): void;
    resetPreferredResource(): void;
    get preferredResourceInput(): cdktn.IResolvable | AwsComputeoptimizerRecommendationPreferences.PreferredResourceProperty[] | undefined;
    private _scope;
    get scope(): AwsComputeoptimizerRecommendationPreferences.ScopePropertyList;
    putScope(value: AwsComputeoptimizerRecommendationPreferences.ScopeProperty[] | cdktn.IResolvable): void;
    resetScope(): void;
    get scopeInput(): cdktn.IResolvable | AwsComputeoptimizerRecommendationPreferences.ScopeProperty[] | undefined;
    private _utilizationPreference;
    get utilizationPreference(): AwsComputeoptimizerRecommendationPreferences.UtilizationPreferencePropertyList;
    putUtilizationPreference(value: AwsComputeoptimizerRecommendationPreferences.UtilizationPreferenceProperty[] | cdktn.IResolvable): void;
    resetUtilizationPreference(): void;
    get utilizationPreferenceInput(): cdktn.IResolvable | AwsComputeoptimizerRecommendationPreferences.UtilizationPreferenceProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsComputeoptimizerRecommendationPreferencesExternalMetricsPreferencePropertyToTerraform(struct?: AwsComputeoptimizerRecommendationPreferences.ExternalMetricsPreferenceProperty | cdktn.IResolvable): any;
export declare function awsComputeoptimizerRecommendationPreferencesExternalMetricsPreferencePropertyToHclTerraform(struct?: AwsComputeoptimizerRecommendationPreferences.ExternalMetricsPreferenceProperty | cdktn.IResolvable): any;
export declare function awsComputeoptimizerRecommendationPreferencesPreferredResourcePropertyToTerraform(struct?: AwsComputeoptimizerRecommendationPreferences.PreferredResourceProperty | cdktn.IResolvable): any;
export declare function awsComputeoptimizerRecommendationPreferencesPreferredResourcePropertyToHclTerraform(struct?: AwsComputeoptimizerRecommendationPreferences.PreferredResourceProperty | cdktn.IResolvable): any;
export declare function awsComputeoptimizerRecommendationPreferencesScopePropertyToTerraform(struct?: AwsComputeoptimizerRecommendationPreferences.ScopeProperty | cdktn.IResolvable): any;
export declare function awsComputeoptimizerRecommendationPreferencesScopePropertyToHclTerraform(struct?: AwsComputeoptimizerRecommendationPreferences.ScopeProperty | cdktn.IResolvable): any;
export declare function awsComputeoptimizerRecommendationPreferencesMetricParametersPropertyToTerraform(struct?: AwsComputeoptimizerRecommendationPreferences.MetricParametersProperty | cdktn.IResolvable): any;
export declare function awsComputeoptimizerRecommendationPreferencesMetricParametersPropertyToHclTerraform(struct?: AwsComputeoptimizerRecommendationPreferences.MetricParametersProperty | cdktn.IResolvable): any;
export declare function awsComputeoptimizerRecommendationPreferencesUtilizationPreferencePropertyToTerraform(struct?: AwsComputeoptimizerRecommendationPreferences.UtilizationPreferenceProperty | cdktn.IResolvable): any;
export declare function awsComputeoptimizerRecommendationPreferencesUtilizationPreferencePropertyToHclTerraform(struct?: AwsComputeoptimizerRecommendationPreferences.UtilizationPreferenceProperty | cdktn.IResolvable): any;
export declare namespace AwsComputeoptimizerRecommendationPreferences {
    interface ExternalMetricsPreferenceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences#source AwsComputeoptimizerRecommendationPreferences#source}
        */
        readonly source: string;
    }
    class ExternalMetricsPreferencePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExternalMetricsPreferenceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ExternalMetricsPreferenceProperty | cdktn.IResolvable | undefined);
        private _source?;
        get source(): string;
        set source(value: string);
        get sourceInput(): string | undefined;
    }
    class ExternalMetricsPreferencePropertyList extends cdktn.ComplexList {
        internalValue?: ExternalMetricsPreferenceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExternalMetricsPreferencePropertyOutputReference;
    }
    interface PreferredResourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences#exclude_list AwsComputeoptimizerRecommendationPreferences#exclude_list}
        */
        readonly excludeList?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences#include_list AwsComputeoptimizerRecommendationPreferences#include_list}
        */
        readonly includeList?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences#name AwsComputeoptimizerRecommendationPreferences#name}
        */
        readonly name: string;
    }
    class PreferredResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PreferredResourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PreferredResourceProperty | cdktn.IResolvable | undefined);
        private _excludeList?;
        get excludeList(): string[];
        set excludeList(value: string[]);
        resetExcludeList(): void;
        get excludeListInput(): string[] | undefined;
        private _includeList?;
        get includeList(): string[];
        set includeList(value: string[]);
        resetIncludeList(): void;
        get includeListInput(): string[] | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    class PreferredResourcePropertyList extends cdktn.ComplexList {
        internalValue?: PreferredResourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PreferredResourcePropertyOutputReference;
    }
    interface ScopeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences#name AwsComputeoptimizerRecommendationPreferences#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences#value AwsComputeoptimizerRecommendationPreferences#value}
        */
        readonly value: string;
    }
    class ScopePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ScopeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ScopeProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ScopePropertyList extends cdktn.ComplexList {
        internalValue?: ScopeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ScopePropertyOutputReference;
    }
    interface MetricParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences#headroom AwsComputeoptimizerRecommendationPreferences#headroom}
        */
        readonly headroom: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences#threshold AwsComputeoptimizerRecommendationPreferences#threshold}
        */
        readonly threshold?: string;
    }
    class MetricParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MetricParametersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MetricParametersProperty | cdktn.IResolvable | undefined);
        private _headroom?;
        get headroom(): string;
        set headroom(value: string);
        get headroomInput(): string | undefined;
        private _threshold?;
        get threshold(): string;
        set threshold(value: string);
        resetThreshold(): void;
        get thresholdInput(): string | undefined;
    }
    class MetricParametersPropertyList extends cdktn.ComplexList {
        internalValue?: MetricParametersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MetricParametersPropertyOutputReference;
    }
    interface UtilizationPreferenceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences#metric_name AwsComputeoptimizerRecommendationPreferences#metric_name}
        */
        readonly metricName: string;
        /**
        * metric_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences#metric_parameters AwsComputeoptimizerRecommendationPreferences#metric_parameters}
        */
        readonly metricParameters?: MetricParametersProperty[] | cdktn.IResolvable;
    }
    class UtilizationPreferencePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UtilizationPreferenceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: UtilizationPreferenceProperty | cdktn.IResolvable | undefined);
        private _metricName?;
        get metricName(): string;
        set metricName(value: string);
        get metricNameInput(): string | undefined;
        private _metricParameters;
        get metricParameters(): MetricParametersPropertyList;
        putMetricParameters(value: MetricParametersProperty[] | cdktn.IResolvable): void;
        resetMetricParameters(): void;
        get metricParametersInput(): cdktn.IResolvable | MetricParametersProperty[] | undefined;
    }
    class UtilizationPreferencePropertyList extends cdktn.ComplexList {
        internalValue?: UtilizationPreferenceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UtilizationPreferencePropertyOutputReference;
    }
}
