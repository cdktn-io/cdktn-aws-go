import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfRecommendationPreferencesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences#enhanced_infrastructure_metrics TfRecommendationPreferences#enhanced_infrastructure_metrics}
    */
    readonly enhancedInfrastructureMetrics?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences#inferred_workload_types TfRecommendationPreferences#inferred_workload_types}
    */
    readonly inferredWorkloadTypes?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences#look_back_period TfRecommendationPreferences#look_back_period}
    */
    readonly lookBackPeriod?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences#region TfRecommendationPreferences#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences#resource_type TfRecommendationPreferences#resource_type}
    */
    readonly resourceType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences#savings_estimation_mode TfRecommendationPreferences#savings_estimation_mode}
    */
    readonly savingsEstimationMode?: string;
    /**
    * external_metrics_preference block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences#external_metrics_preference TfRecommendationPreferences#external_metrics_preference}
    */
    readonly externalMetricsPreference?: TfRecommendationPreferences.ExternalMetricsPreferenceProperty[] | cdktn.IResolvable;
    /**
    * preferred_resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences#preferred_resource TfRecommendationPreferences#preferred_resource}
    */
    readonly preferredResource?: TfRecommendationPreferences.PreferredResourceProperty[] | cdktn.IResolvable;
    /**
    * scope block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences#scope TfRecommendationPreferences#scope}
    */
    readonly scope?: TfRecommendationPreferences.ScopeProperty[] | cdktn.IResolvable;
    /**
    * utilization_preference block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences#utilization_preference TfRecommendationPreferences#utilization_preference}
    */
    readonly utilizationPreference?: TfRecommendationPreferences.UtilizationPreferenceProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences aws_computeoptimizer_recommendation_preferences}
*/
export declare class TfRecommendationPreferences extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_computeoptimizer_recommendation_preferences";
    /**
    * Generates CDKTN code for importing a TfRecommendationPreferences resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfRecommendationPreferences to import
    * @param importFromId The id of the existing TfRecommendationPreferences that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfRecommendationPreferences to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences aws_computeoptimizer_recommendation_preferences} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfRecommendationPreferencesConfig
    */
    constructor(scope: Construct, id: string, config: TfRecommendationPreferencesConfig);
    private _enhancedInfrastructureMetrics?;
    get enhancedInfrastructureMetrics(): string;
    set enhancedInfrastructureMetrics(value: string);
    resetEnhancedInfrastructureMetrics(): void;
    get enhancedInfrastructureMetricsInput(): string | undefined;
    get id(): string;
    private _inferredWorkloadTypes?;
    get inferredWorkloadTypes(): string;
    set inferredWorkloadTypes(value: string);
    resetInferredWorkloadTypes(): void;
    get inferredWorkloadTypesInput(): string | undefined;
    private _lookBackPeriod?;
    get lookBackPeriod(): string;
    set lookBackPeriod(value: string);
    resetLookBackPeriod(): void;
    get lookBackPeriodInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourceType?;
    get resourceType(): string;
    set resourceType(value: string);
    get resourceTypeInput(): string | undefined;
    private _savingsEstimationMode?;
    get savingsEstimationMode(): string;
    set savingsEstimationMode(value: string);
    resetSavingsEstimationMode(): void;
    get savingsEstimationModeInput(): string | undefined;
    private _externalMetricsPreference;
    get externalMetricsPreference(): TfRecommendationPreferences.ExternalMetricsPreferencePropertyList;
    putExternalMetricsPreference(value: TfRecommendationPreferences.ExternalMetricsPreferenceProperty[] | cdktn.IResolvable): void;
    resetExternalMetricsPreference(): void;
    get externalMetricsPreferenceInput(): cdktn.IResolvable | TfRecommendationPreferences.ExternalMetricsPreferenceProperty[] | undefined;
    private _preferredResource;
    get preferredResource(): TfRecommendationPreferences.PreferredResourcePropertyList;
    putPreferredResource(value: TfRecommendationPreferences.PreferredResourceProperty[] | cdktn.IResolvable): void;
    resetPreferredResource(): void;
    get preferredResourceInput(): cdktn.IResolvable | TfRecommendationPreferences.PreferredResourceProperty[] | undefined;
    private _scope;
    get scope(): TfRecommendationPreferences.ScopePropertyList;
    putScope(value: TfRecommendationPreferences.ScopeProperty[] | cdktn.IResolvable): void;
    resetScope(): void;
    get scopeInput(): cdktn.IResolvable | TfRecommendationPreferences.ScopeProperty[] | undefined;
    private _utilizationPreference;
    get utilizationPreference(): TfRecommendationPreferences.UtilizationPreferencePropertyList;
    putUtilizationPreference(value: TfRecommendationPreferences.UtilizationPreferenceProperty[] | cdktn.IResolvable): void;
    resetUtilizationPreference(): void;
    get utilizationPreferenceInput(): cdktn.IResolvable | TfRecommendationPreferences.UtilizationPreferenceProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfRecommendationPreferencesExternalMetricsPreferencePropertyToTerraform(struct?: TfRecommendationPreferences.ExternalMetricsPreferenceProperty | cdktn.IResolvable): any;
export declare function tfRecommendationPreferencesExternalMetricsPreferencePropertyToHclTerraform(struct?: TfRecommendationPreferences.ExternalMetricsPreferenceProperty | cdktn.IResolvable): any;
export declare function tfRecommendationPreferencesPreferredResourcePropertyToTerraform(struct?: TfRecommendationPreferences.PreferredResourceProperty | cdktn.IResolvable): any;
export declare function tfRecommendationPreferencesPreferredResourcePropertyToHclTerraform(struct?: TfRecommendationPreferences.PreferredResourceProperty | cdktn.IResolvable): any;
export declare function tfRecommendationPreferencesScopePropertyToTerraform(struct?: TfRecommendationPreferences.ScopeProperty | cdktn.IResolvable): any;
export declare function tfRecommendationPreferencesScopePropertyToHclTerraform(struct?: TfRecommendationPreferences.ScopeProperty | cdktn.IResolvable): any;
export declare function tfRecommendationPreferencesMetricParametersPropertyToTerraform(struct?: TfRecommendationPreferences.MetricParametersProperty | cdktn.IResolvable): any;
export declare function tfRecommendationPreferencesMetricParametersPropertyToHclTerraform(struct?: TfRecommendationPreferences.MetricParametersProperty | cdktn.IResolvable): any;
export declare function tfRecommendationPreferencesUtilizationPreferencePropertyToTerraform(struct?: TfRecommendationPreferences.UtilizationPreferenceProperty | cdktn.IResolvable): any;
export declare function tfRecommendationPreferencesUtilizationPreferencePropertyToHclTerraform(struct?: TfRecommendationPreferences.UtilizationPreferenceProperty | cdktn.IResolvable): any;
export declare namespace TfRecommendationPreferences {
    interface ExternalMetricsPreferenceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences#source TfRecommendationPreferences#source}
        */
        readonly source: string;
    }
    class ExternalMetricsPreferencePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExternalMetricsPreferenceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ExternalMetricsPreferenceProperty | cdktn.IResolvable | undefined);
        private _source?;
        get source(): string;
        set source(value: string);
        get sourceInput(): string | undefined;
    }
    class ExternalMetricsPreferencePropertyList extends cdktn.ComplexList {
        internalValue?: ExternalMetricsPreferenceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExternalMetricsPreferencePropertyOutputReference;
    }
    interface PreferredResourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences#exclude_list TfRecommendationPreferences#exclude_list}
        */
        readonly excludeList?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences#include_list TfRecommendationPreferences#include_list}
        */
        readonly includeList?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences#name TfRecommendationPreferences#name}
        */
        readonly name: string;
    }
    class PreferredResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PreferredResourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PreferredResourceProperty | cdktn.IResolvable | undefined);
        private _excludeList?;
        get excludeList(): string[];
        set excludeList(value: string[]);
        resetExcludeList(): void;
        get excludeListInput(): string[] | undefined;
        private _includeList?;
        get includeList(): string[];
        set includeList(value: string[]);
        resetIncludeList(): void;
        get includeListInput(): string[] | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    class PreferredResourcePropertyList extends cdktn.ComplexList {
        internalValue?: PreferredResourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PreferredResourcePropertyOutputReference;
    }
    interface ScopeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences#name TfRecommendationPreferences#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences#value TfRecommendationPreferences#value}
        */
        readonly value: string;
    }
    class ScopePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ScopeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ScopeProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ScopePropertyList extends cdktn.ComplexList {
        internalValue?: ScopeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ScopePropertyOutputReference;
    }
    interface MetricParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences#headroom TfRecommendationPreferences#headroom}
        */
        readonly headroom: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences#threshold TfRecommendationPreferences#threshold}
        */
        readonly threshold?: string;
    }
    class MetricParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MetricParametersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MetricParametersProperty | cdktn.IResolvable | undefined);
        private _headroom?;
        get headroom(): string;
        set headroom(value: string);
        get headroomInput(): string | undefined;
        private _threshold?;
        get threshold(): string;
        set threshold(value: string);
        resetThreshold(): void;
        get thresholdInput(): string | undefined;
    }
    class MetricParametersPropertyList extends cdktn.ComplexList {
        internalValue?: MetricParametersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MetricParametersPropertyOutputReference;
    }
    interface UtilizationPreferenceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences#metric_name TfRecommendationPreferences#metric_name}
        */
        readonly metricName: string;
        /**
        * metric_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/computeoptimizer_recommendation_preferences#metric_parameters TfRecommendationPreferences#metric_parameters}
        */
        readonly metricParameters?: MetricParametersProperty[] | cdktn.IResolvable;
    }
    class UtilizationPreferencePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UtilizationPreferenceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: UtilizationPreferenceProperty | cdktn.IResolvable | undefined);
        private _metricName?;
        get metricName(): string;
        set metricName(value: string);
        get metricNameInput(): string | undefined;
        private _metricParameters;
        get metricParameters(): MetricParametersPropertyList;
        putMetricParameters(value: MetricParametersProperty[] | cdktn.IResolvable): void;
        resetMetricParameters(): void;
        get metricParametersInput(): cdktn.IResolvable | MetricParametersProperty[] | undefined;
    }
    class UtilizationPreferencePropertyList extends cdktn.ComplexList {
        internalValue?: UtilizationPreferenceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UtilizationPreferencePropertyOutputReference;
    }
}
