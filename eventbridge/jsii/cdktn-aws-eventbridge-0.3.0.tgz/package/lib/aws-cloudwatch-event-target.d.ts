import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsTargetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#arn AwsTarget#arn}
    */
    readonly arn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#event_bus_name AwsTarget#event_bus_name}
    */
    readonly eventBusName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#force_destroy AwsTarget#force_destroy}
    */
    readonly forceDestroy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#id AwsTarget#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#input AwsTarget#input}
    */
    readonly input?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#input_path AwsTarget#input_path}
    */
    readonly inputPath?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#region AwsTarget#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#role_arn AwsTarget#role_arn}
    */
    readonly roleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#rule AwsTarget#rule}
    */
    readonly rule: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#target_id AwsTarget#target_id}
    */
    readonly targetId?: string;
    /**
    * appsync_target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#appsync_target AwsTarget#appsync_target}
    */
    readonly appsyncTarget?: AwsTarget.AppsyncTargetProperty;
    /**
    * batch_target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#batch_target AwsTarget#batch_target}
    */
    readonly batchTarget?: AwsTarget.BatchTargetProperty;
    /**
    * dead_letter_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#dead_letter_config AwsTarget#dead_letter_config}
    */
    readonly deadLetterConfig?: AwsTarget.DeadLetterConfigProperty;
    /**
    * ecs_target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#ecs_target AwsTarget#ecs_target}
    */
    readonly ecsTarget?: AwsTarget.EcsTargetProperty;
    /**
    * http_target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#http_target AwsTarget#http_target}
    */
    readonly httpTarget?: AwsTarget.HttpTargetProperty;
    /**
    * input_transformer block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#input_transformer AwsTarget#input_transformer}
    */
    readonly inputTransformer?: AwsTarget.InputTransformerProperty;
    /**
    * kinesis_target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#kinesis_target AwsTarget#kinesis_target}
    */
    readonly kinesisTarget?: AwsTarget.KinesisTargetProperty;
    /**
    * redshift_target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#redshift_target AwsTarget#redshift_target}
    */
    readonly redshiftTarget?: AwsTarget.RedshiftTargetProperty;
    /**
    * retry_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#retry_policy AwsTarget#retry_policy}
    */
    readonly retryPolicy?: AwsTarget.RetryPolicyProperty;
    /**
    * run_command_targets block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#run_command_targets AwsTarget#run_command_targets}
    */
    readonly runCommandTargets?: AwsTarget.RunCommandTargetsProperty[] | cdktn.IResolvable;
    /**
    * sagemaker_pipeline_target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#sagemaker_pipeline_target AwsTarget#sagemaker_pipeline_target}
    */
    readonly sagemakerPipelineTarget?: AwsTarget.SagemakerPipelineTargetProperty;
    /**
    * sqs_target block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#sqs_target AwsTarget#sqs_target}
    */
    readonly sqsTarget?: AwsTarget.SqsTargetProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target aws_cloudwatch_event_target}
*/
export declare class AwsTarget extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudwatch_event_target";
    /**
    * Generates CDKTN code for importing a AwsTarget resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsTarget to import
    * @param importFromId The id of the existing AwsTarget that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsTarget to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target aws_cloudwatch_event_target} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsTargetConfig
    */
    constructor(scope: Construct, id: string, config: AwsTargetConfig);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    get arnInput(): string | undefined;
    private _eventBusName?;
    get eventBusName(): string;
    set eventBusName(value: string);
    resetEventBusName(): void;
    get eventBusNameInput(): string | undefined;
    private _forceDestroy?;
    get forceDestroy(): boolean | cdktn.IResolvable;
    set forceDestroy(value: boolean | cdktn.IResolvable);
    resetForceDestroy(): void;
    get forceDestroyInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _input?;
    get input(): string;
    set input(value: string);
    resetInput(): void;
    get inputInput(): string | undefined;
    private _inputPath?;
    get inputPath(): string;
    set inputPath(value: string);
    resetInputPath(): void;
    get inputPathInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
    private _rule?;
    get rule(): string;
    set rule(value: string);
    get ruleInput(): string | undefined;
    private _targetId?;
    get targetId(): string;
    set targetId(value: string);
    resetTargetId(): void;
    get targetIdInput(): string | undefined;
    private _appsyncTarget;
    get appsyncTarget(): AwsTarget.AppsyncTargetPropertyOutputReference;
    putAppsyncTarget(value: AwsTarget.AppsyncTargetProperty): void;
    resetAppsyncTarget(): void;
    get appsyncTargetInput(): AwsTarget.AppsyncTargetProperty | undefined;
    private _batchTarget;
    get batchTarget(): AwsTarget.BatchTargetPropertyOutputReference;
    putBatchTarget(value: AwsTarget.BatchTargetProperty): void;
    resetBatchTarget(): void;
    get batchTargetInput(): AwsTarget.BatchTargetProperty | undefined;
    private _deadLetterConfig;
    get deadLetterConfig(): AwsTarget.DeadLetterConfigPropertyOutputReference;
    putDeadLetterConfig(value: AwsTarget.DeadLetterConfigProperty): void;
    resetDeadLetterConfig(): void;
    get deadLetterConfigInput(): AwsTarget.DeadLetterConfigProperty | undefined;
    private _ecsTarget;
    get ecsTarget(): AwsTarget.EcsTargetPropertyOutputReference;
    putEcsTarget(value: AwsTarget.EcsTargetProperty): void;
    resetEcsTarget(): void;
    get ecsTargetInput(): AwsTarget.EcsTargetProperty | undefined;
    private _httpTarget;
    get httpTarget(): AwsTarget.HttpTargetPropertyOutputReference;
    putHttpTarget(value: AwsTarget.HttpTargetProperty): void;
    resetHttpTarget(): void;
    get httpTargetInput(): AwsTarget.HttpTargetProperty | undefined;
    private _inputTransformer;
    get inputTransformer(): AwsTarget.InputTransformerPropertyOutputReference;
    putInputTransformer(value: AwsTarget.InputTransformerProperty): void;
    resetInputTransformer(): void;
    get inputTransformerInput(): AwsTarget.InputTransformerProperty | undefined;
    private _kinesisTarget;
    get kinesisTarget(): AwsTarget.KinesisTargetPropertyOutputReference;
    putKinesisTarget(value: AwsTarget.KinesisTargetProperty): void;
    resetKinesisTarget(): void;
    get kinesisTargetInput(): AwsTarget.KinesisTargetProperty | undefined;
    private _redshiftTarget;
    get redshiftTarget(): AwsTarget.RedshiftTargetPropertyOutputReference;
    putRedshiftTarget(value: AwsTarget.RedshiftTargetProperty): void;
    resetRedshiftTarget(): void;
    get redshiftTargetInput(): AwsTarget.RedshiftTargetProperty | undefined;
    private _retryPolicy;
    get retryPolicy(): AwsTarget.RetryPolicyPropertyOutputReference;
    putRetryPolicy(value: AwsTarget.RetryPolicyProperty): void;
    resetRetryPolicy(): void;
    get retryPolicyInput(): AwsTarget.RetryPolicyProperty | undefined;
    private _runCommandTargets;
    get runCommandTargets(): AwsTarget.RunCommandTargetsPropertyList;
    putRunCommandTargets(value: AwsTarget.RunCommandTargetsProperty[] | cdktn.IResolvable): void;
    resetRunCommandTargets(): void;
    get runCommandTargetsInput(): cdktn.IResolvable | AwsTarget.RunCommandTargetsProperty[] | undefined;
    private _sagemakerPipelineTarget;
    get sagemakerPipelineTarget(): AwsTarget.SagemakerPipelineTargetPropertyOutputReference;
    putSagemakerPipelineTarget(value: AwsTarget.SagemakerPipelineTargetProperty): void;
    resetSagemakerPipelineTarget(): void;
    get sagemakerPipelineTargetInput(): AwsTarget.SagemakerPipelineTargetProperty | undefined;
    private _sqsTarget;
    get sqsTarget(): AwsTarget.SqsTargetPropertyOutputReference;
    putSqsTarget(value: AwsTarget.SqsTargetProperty): void;
    resetSqsTarget(): void;
    get sqsTargetInput(): AwsTarget.SqsTargetProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsTargetAppsyncTargetPropertyToTerraform(struct?: AwsTarget.AppsyncTargetPropertyOutputReference | AwsTarget.AppsyncTargetProperty): any;
export declare function awsTargetAppsyncTargetPropertyToHclTerraform(struct?: AwsTarget.AppsyncTargetPropertyOutputReference | AwsTarget.AppsyncTargetProperty): any;
export declare function awsTargetBatchTargetPropertyToTerraform(struct?: AwsTarget.BatchTargetPropertyOutputReference | AwsTarget.BatchTargetProperty): any;
export declare function awsTargetBatchTargetPropertyToHclTerraform(struct?: AwsTarget.BatchTargetPropertyOutputReference | AwsTarget.BatchTargetProperty): any;
export declare function awsTargetDeadLetterConfigPropertyToTerraform(struct?: AwsTarget.DeadLetterConfigPropertyOutputReference | AwsTarget.DeadLetterConfigProperty): any;
export declare function awsTargetDeadLetterConfigPropertyToHclTerraform(struct?: AwsTarget.DeadLetterConfigPropertyOutputReference | AwsTarget.DeadLetterConfigProperty): any;
export declare function awsTargetCapacityProviderStrategyPropertyToTerraform(struct?: AwsTarget.CapacityProviderStrategyProperty | cdktn.IResolvable): any;
export declare function awsTargetCapacityProviderStrategyPropertyToHclTerraform(struct?: AwsTarget.CapacityProviderStrategyProperty | cdktn.IResolvable): any;
export declare function awsTargetNetworkConfigurationPropertyToTerraform(struct?: AwsTarget.NetworkConfigurationPropertyOutputReference | AwsTarget.NetworkConfigurationProperty): any;
export declare function awsTargetNetworkConfigurationPropertyToHclTerraform(struct?: AwsTarget.NetworkConfigurationPropertyOutputReference | AwsTarget.NetworkConfigurationProperty): any;
export declare function awsTargetOrderedPlacementStrategyPropertyToTerraform(struct?: AwsTarget.OrderedPlacementStrategyProperty | cdktn.IResolvable): any;
export declare function awsTargetOrderedPlacementStrategyPropertyToHclTerraform(struct?: AwsTarget.OrderedPlacementStrategyProperty | cdktn.IResolvable): any;
export declare function awsTargetPlacementConstraintPropertyToTerraform(struct?: AwsTarget.PlacementConstraintProperty | cdktn.IResolvable): any;
export declare function awsTargetPlacementConstraintPropertyToHclTerraform(struct?: AwsTarget.PlacementConstraintProperty | cdktn.IResolvable): any;
export declare function awsTargetEcsTargetPropertyToTerraform(struct?: AwsTarget.EcsTargetPropertyOutputReference | AwsTarget.EcsTargetProperty): any;
export declare function awsTargetEcsTargetPropertyToHclTerraform(struct?: AwsTarget.EcsTargetPropertyOutputReference | AwsTarget.EcsTargetProperty): any;
export declare function awsTargetHttpTargetPropertyToTerraform(struct?: AwsTarget.HttpTargetPropertyOutputReference | AwsTarget.HttpTargetProperty): any;
export declare function awsTargetHttpTargetPropertyToHclTerraform(struct?: AwsTarget.HttpTargetPropertyOutputReference | AwsTarget.HttpTargetProperty): any;
export declare function awsTargetInputTransformerPropertyToTerraform(struct?: AwsTarget.InputTransformerPropertyOutputReference | AwsTarget.InputTransformerProperty): any;
export declare function awsTargetInputTransformerPropertyToHclTerraform(struct?: AwsTarget.InputTransformerPropertyOutputReference | AwsTarget.InputTransformerProperty): any;
export declare function awsTargetKinesisTargetPropertyToTerraform(struct?: AwsTarget.KinesisTargetPropertyOutputReference | AwsTarget.KinesisTargetProperty): any;
export declare function awsTargetKinesisTargetPropertyToHclTerraform(struct?: AwsTarget.KinesisTargetPropertyOutputReference | AwsTarget.KinesisTargetProperty): any;
export declare function awsTargetRedshiftTargetPropertyToTerraform(struct?: AwsTarget.RedshiftTargetPropertyOutputReference | AwsTarget.RedshiftTargetProperty): any;
export declare function awsTargetRedshiftTargetPropertyToHclTerraform(struct?: AwsTarget.RedshiftTargetPropertyOutputReference | AwsTarget.RedshiftTargetProperty): any;
export declare function awsTargetRetryPolicyPropertyToTerraform(struct?: AwsTarget.RetryPolicyPropertyOutputReference | AwsTarget.RetryPolicyProperty): any;
export declare function awsTargetRetryPolicyPropertyToHclTerraform(struct?: AwsTarget.RetryPolicyPropertyOutputReference | AwsTarget.RetryPolicyProperty): any;
export declare function awsTargetRunCommandTargetsPropertyToTerraform(struct?: AwsTarget.RunCommandTargetsProperty | cdktn.IResolvable): any;
export declare function awsTargetRunCommandTargetsPropertyToHclTerraform(struct?: AwsTarget.RunCommandTargetsProperty | cdktn.IResolvable): any;
export declare function awsTargetPipelineParameterListPropertyToTerraform(struct?: AwsTarget.PipelineParameterListProperty | cdktn.IResolvable): any;
export declare function awsTargetPipelineParameterListPropertyToHclTerraform(struct?: AwsTarget.PipelineParameterListProperty | cdktn.IResolvable): any;
export declare function awsTargetSagemakerPipelineTargetPropertyToTerraform(struct?: AwsTarget.SagemakerPipelineTargetPropertyOutputReference | AwsTarget.SagemakerPipelineTargetProperty): any;
export declare function awsTargetSagemakerPipelineTargetPropertyToHclTerraform(struct?: AwsTarget.SagemakerPipelineTargetPropertyOutputReference | AwsTarget.SagemakerPipelineTargetProperty): any;
export declare function awsTargetSqsTargetPropertyToTerraform(struct?: AwsTarget.SqsTargetPropertyOutputReference | AwsTarget.SqsTargetProperty): any;
export declare function awsTargetSqsTargetPropertyToHclTerraform(struct?: AwsTarget.SqsTargetPropertyOutputReference | AwsTarget.SqsTargetProperty): any;
export declare namespace AwsTarget {
    interface AppsyncTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#graphql_operation AwsTarget#graphql_operation}
        */
        readonly graphqlOperation?: string;
    }
    class AppsyncTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AppsyncTargetProperty | undefined;
        set internalValue(value: AppsyncTargetProperty | undefined);
        private _graphqlOperation?;
        get graphqlOperation(): string;
        set graphqlOperation(value: string);
        resetGraphqlOperation(): void;
        get graphqlOperationInput(): string | undefined;
    }
    interface BatchTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#array_size AwsTarget#array_size}
        */
        readonly arraySize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#job_attempts AwsTarget#job_attempts}
        */
        readonly jobAttempts?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#job_definition AwsTarget#job_definition}
        */
        readonly jobDefinition: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#job_name AwsTarget#job_name}
        */
        readonly jobName: string;
    }
    class BatchTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BatchTargetProperty | undefined;
        set internalValue(value: BatchTargetProperty | undefined);
        private _arraySize?;
        get arraySize(): number;
        set arraySize(value: number);
        resetArraySize(): void;
        get arraySizeInput(): number | undefined;
        private _jobAttempts?;
        get jobAttempts(): number;
        set jobAttempts(value: number);
        resetJobAttempts(): void;
        get jobAttemptsInput(): number | undefined;
        private _jobDefinition?;
        get jobDefinition(): string;
        set jobDefinition(value: string);
        get jobDefinitionInput(): string | undefined;
        private _jobName?;
        get jobName(): string;
        set jobName(value: string);
        get jobNameInput(): string | undefined;
    }
    interface DeadLetterConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#arn AwsTarget#arn}
        */
        readonly arn?: string;
    }
    class DeadLetterConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DeadLetterConfigProperty | undefined;
        set internalValue(value: DeadLetterConfigProperty | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        resetArn(): void;
        get arnInput(): string | undefined;
    }
    interface CapacityProviderStrategyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#base AwsTarget#base}
        */
        readonly base?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#capacity_provider AwsTarget#capacity_provider}
        */
        readonly capacityProvider: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#weight AwsTarget#weight}
        */
        readonly weight?: number;
    }
    class CapacityProviderStrategyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CapacityProviderStrategyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CapacityProviderStrategyProperty | cdktn.IResolvable | undefined);
        private _base?;
        get base(): number;
        set base(value: number);
        resetBase(): void;
        get baseInput(): number | undefined;
        private _capacityProvider?;
        get capacityProvider(): string;
        set capacityProvider(value: string);
        get capacityProviderInput(): string | undefined;
        private _weight?;
        get weight(): number;
        set weight(value: number);
        resetWeight(): void;
        get weightInput(): number | undefined;
    }
    class CapacityProviderStrategyPropertyList extends cdktn.ComplexList {
        internalValue?: CapacityProviderStrategyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CapacityProviderStrategyPropertyOutputReference;
    }
    interface NetworkConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#assign_public_ip AwsTarget#assign_public_ip}
        */
        readonly assignPublicIp?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#security_groups AwsTarget#security_groups}
        */
        readonly securityGroups?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#subnets AwsTarget#subnets}
        */
        readonly subnets: string[];
    }
    class NetworkConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NetworkConfigurationProperty | undefined;
        set internalValue(value: NetworkConfigurationProperty | undefined);
        private _assignPublicIp?;
        get assignPublicIp(): boolean | cdktn.IResolvable;
        set assignPublicIp(value: boolean | cdktn.IResolvable);
        resetAssignPublicIp(): void;
        get assignPublicIpInput(): boolean | cdktn.IResolvable | undefined;
        private _securityGroups?;
        get securityGroups(): string[];
        set securityGroups(value: string[]);
        resetSecurityGroups(): void;
        get securityGroupsInput(): string[] | undefined;
        private _subnets?;
        get subnets(): string[];
        set subnets(value: string[]);
        get subnetsInput(): string[] | undefined;
    }
    interface OrderedPlacementStrategyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#field AwsTarget#field}
        */
        readonly field?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#type AwsTarget#type}
        */
        readonly type: string;
    }
    class OrderedPlacementStrategyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OrderedPlacementStrategyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OrderedPlacementStrategyProperty | cdktn.IResolvable | undefined);
        private _field?;
        get field(): string;
        set field(value: string);
        resetField(): void;
        get fieldInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class OrderedPlacementStrategyPropertyList extends cdktn.ComplexList {
        internalValue?: OrderedPlacementStrategyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OrderedPlacementStrategyPropertyOutputReference;
    }
    interface PlacementConstraintProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#expression AwsTarget#expression}
        */
        readonly expression?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#type AwsTarget#type}
        */
        readonly type: string;
    }
    class PlacementConstraintPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PlacementConstraintProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PlacementConstraintProperty | cdktn.IResolvable | undefined);
        private _expression?;
        get expression(): string;
        set expression(value: string);
        resetExpression(): void;
        get expressionInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class PlacementConstraintPropertyList extends cdktn.ComplexList {
        internalValue?: PlacementConstraintProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PlacementConstraintPropertyOutputReference;
    }
    interface EcsTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#enable_ecs_managed_tags AwsTarget#enable_ecs_managed_tags}
        */
        readonly enableEcsManagedTags?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#enable_execute_command AwsTarget#enable_execute_command}
        */
        readonly enableExecuteCommand?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#group AwsTarget#group}
        */
        readonly group?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#launch_type AwsTarget#launch_type}
        */
        readonly launchType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#platform_version AwsTarget#platform_version}
        */
        readonly platformVersion?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#propagate_tags AwsTarget#propagate_tags}
        */
        readonly propagateTags?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#tags AwsTarget#tags}
        */
        readonly tags?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#task_count AwsTarget#task_count}
        */
        readonly taskCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#task_definition_arn AwsTarget#task_definition_arn}
        */
        readonly taskDefinitionArn: string;
        /**
        * capacity_provider_strategy block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#capacity_provider_strategy AwsTarget#capacity_provider_strategy}
        */
        readonly capacityProviderStrategy?: CapacityProviderStrategyProperty[] | cdktn.IResolvable;
        /**
        * network_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#network_configuration AwsTarget#network_configuration}
        */
        readonly networkConfiguration?: NetworkConfigurationProperty;
        /**
        * ordered_placement_strategy block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#ordered_placement_strategy AwsTarget#ordered_placement_strategy}
        */
        readonly orderedPlacementStrategy?: OrderedPlacementStrategyProperty[] | cdktn.IResolvable;
        /**
        * placement_constraint block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#placement_constraint AwsTarget#placement_constraint}
        */
        readonly placementConstraint?: PlacementConstraintProperty[] | cdktn.IResolvable;
    }
    class EcsTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EcsTargetProperty | undefined;
        set internalValue(value: EcsTargetProperty | undefined);
        private _enableEcsManagedTags?;
        get enableEcsManagedTags(): boolean | cdktn.IResolvable;
        set enableEcsManagedTags(value: boolean | cdktn.IResolvable);
        resetEnableEcsManagedTags(): void;
        get enableEcsManagedTagsInput(): boolean | cdktn.IResolvable | undefined;
        private _enableExecuteCommand?;
        get enableExecuteCommand(): boolean | cdktn.IResolvable;
        set enableExecuteCommand(value: boolean | cdktn.IResolvable);
        resetEnableExecuteCommand(): void;
        get enableExecuteCommandInput(): boolean | cdktn.IResolvable | undefined;
        private _group?;
        get group(): string;
        set group(value: string);
        resetGroup(): void;
        get groupInput(): string | undefined;
        private _launchType?;
        get launchType(): string;
        set launchType(value: string);
        resetLaunchType(): void;
        get launchTypeInput(): string | undefined;
        private _platformVersion?;
        get platformVersion(): string;
        set platformVersion(value: string);
        resetPlatformVersion(): void;
        get platformVersionInput(): string | undefined;
        private _propagateTags?;
        get propagateTags(): string;
        set propagateTags(value: string);
        resetPropagateTags(): void;
        get propagateTagsInput(): string | undefined;
        private _tags?;
        get tags(): {
            [key: string]: string;
        };
        set tags(value: {
            [key: string]: string;
        });
        resetTags(): void;
        get tagsInput(): {
            [key: string]: string;
        } | undefined;
        private _taskCount?;
        get taskCount(): number;
        set taskCount(value: number);
        resetTaskCount(): void;
        get taskCountInput(): number | undefined;
        private _taskDefinitionArn?;
        get taskDefinitionArn(): string;
        set taskDefinitionArn(value: string);
        get taskDefinitionArnInput(): string | undefined;
        private _capacityProviderStrategy;
        get capacityProviderStrategy(): CapacityProviderStrategyPropertyList;
        putCapacityProviderStrategy(value: CapacityProviderStrategyProperty[] | cdktn.IResolvable): void;
        resetCapacityProviderStrategy(): void;
        get capacityProviderStrategyInput(): cdktn.IResolvable | CapacityProviderStrategyProperty[] | undefined;
        private _networkConfiguration;
        get networkConfiguration(): NetworkConfigurationPropertyOutputReference;
        putNetworkConfiguration(value: NetworkConfigurationProperty): void;
        resetNetworkConfiguration(): void;
        get networkConfigurationInput(): NetworkConfigurationProperty | undefined;
        private _orderedPlacementStrategy;
        get orderedPlacementStrategy(): OrderedPlacementStrategyPropertyList;
        putOrderedPlacementStrategy(value: OrderedPlacementStrategyProperty[] | cdktn.IResolvable): void;
        resetOrderedPlacementStrategy(): void;
        get orderedPlacementStrategyInput(): cdktn.IResolvable | OrderedPlacementStrategyProperty[] | undefined;
        private _placementConstraint;
        get placementConstraint(): PlacementConstraintPropertyList;
        putPlacementConstraint(value: PlacementConstraintProperty[] | cdktn.IResolvable): void;
        resetPlacementConstraint(): void;
        get placementConstraintInput(): cdktn.IResolvable | PlacementConstraintProperty[] | undefined;
    }
    interface HttpTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#header_parameters AwsTarget#header_parameters}
        */
        readonly headerParameters?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#path_parameter_values AwsTarget#path_parameter_values}
        */
        readonly pathParameterValues?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#query_string_parameters AwsTarget#query_string_parameters}
        */
        readonly queryStringParameters?: {
            [key: string]: string;
        };
    }
    class HttpTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HttpTargetProperty | undefined;
        set internalValue(value: HttpTargetProperty | undefined);
        private _headerParameters?;
        get headerParameters(): {
            [key: string]: string;
        };
        set headerParameters(value: {
            [key: string]: string;
        });
        resetHeaderParameters(): void;
        get headerParametersInput(): {
            [key: string]: string;
        } | undefined;
        private _pathParameterValues?;
        get pathParameterValues(): string[];
        set pathParameterValues(value: string[]);
        resetPathParameterValues(): void;
        get pathParameterValuesInput(): string[] | undefined;
        private _queryStringParameters?;
        get queryStringParameters(): {
            [key: string]: string;
        };
        set queryStringParameters(value: {
            [key: string]: string;
        });
        resetQueryStringParameters(): void;
        get queryStringParametersInput(): {
            [key: string]: string;
        } | undefined;
    }
    interface InputTransformerProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#input_paths AwsTarget#input_paths}
        */
        readonly inputPaths?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#input_template AwsTarget#input_template}
        */
        readonly inputTemplate: string;
    }
    class InputTransformerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InputTransformerProperty | undefined;
        set internalValue(value: InputTransformerProperty | undefined);
        private _inputPaths?;
        get inputPaths(): {
            [key: string]: string;
        };
        set inputPaths(value: {
            [key: string]: string;
        });
        resetInputPaths(): void;
        get inputPathsInput(): {
            [key: string]: string;
        } | undefined;
        private _inputTemplate?;
        get inputTemplate(): string;
        set inputTemplate(value: string);
        get inputTemplateInput(): string | undefined;
    }
    interface KinesisTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#partition_key_path AwsTarget#partition_key_path}
        */
        readonly partitionKeyPath?: string;
    }
    class KinesisTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KinesisTargetProperty | undefined;
        set internalValue(value: KinesisTargetProperty | undefined);
        private _partitionKeyPath?;
        get partitionKeyPath(): string;
        set partitionKeyPath(value: string);
        resetPartitionKeyPath(): void;
        get partitionKeyPathInput(): string | undefined;
    }
    interface RedshiftTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#database AwsTarget#database}
        */
        readonly database: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#db_user AwsTarget#db_user}
        */
        readonly dbUser?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#secrets_manager_arn AwsTarget#secrets_manager_arn}
        */
        readonly secretsManagerArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#sql AwsTarget#sql}
        */
        readonly sql?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#statement_name AwsTarget#statement_name}
        */
        readonly statementName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#with_event AwsTarget#with_event}
        */
        readonly withEvent?: boolean | cdktn.IResolvable;
    }
    class RedshiftTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RedshiftTargetProperty | undefined;
        set internalValue(value: RedshiftTargetProperty | undefined);
        private _database?;
        get database(): string;
        set database(value: string);
        get databaseInput(): string | undefined;
        private _dbUser?;
        get dbUser(): string;
        set dbUser(value: string);
        resetDbUser(): void;
        get dbUserInput(): string | undefined;
        private _secretsManagerArn?;
        get secretsManagerArn(): string;
        set secretsManagerArn(value: string);
        resetSecretsManagerArn(): void;
        get secretsManagerArnInput(): string | undefined;
        private _sql?;
        get sql(): string;
        set sql(value: string);
        resetSql(): void;
        get sqlInput(): string | undefined;
        private _statementName?;
        get statementName(): string;
        set statementName(value: string);
        resetStatementName(): void;
        get statementNameInput(): string | undefined;
        private _withEvent?;
        get withEvent(): boolean | cdktn.IResolvable;
        set withEvent(value: boolean | cdktn.IResolvable);
        resetWithEvent(): void;
        get withEventInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface RetryPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#maximum_event_age_in_seconds AwsTarget#maximum_event_age_in_seconds}
        */
        readonly maximumEventAgeInSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#maximum_retry_attempts AwsTarget#maximum_retry_attempts}
        */
        readonly maximumRetryAttempts?: number;
    }
    class RetryPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RetryPolicyProperty | undefined;
        set internalValue(value: RetryPolicyProperty | undefined);
        private _maximumEventAgeInSeconds?;
        get maximumEventAgeInSeconds(): number;
        set maximumEventAgeInSeconds(value: number);
        resetMaximumEventAgeInSeconds(): void;
        get maximumEventAgeInSecondsInput(): number | undefined;
        private _maximumRetryAttempts?;
        get maximumRetryAttempts(): number;
        set maximumRetryAttempts(value: number);
        resetMaximumRetryAttempts(): void;
        get maximumRetryAttemptsInput(): number | undefined;
    }
    interface RunCommandTargetsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#key AwsTarget#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#values AwsTarget#values}
        */
        readonly values: string[];
    }
    class RunCommandTargetsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RunCommandTargetsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RunCommandTargetsProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class RunCommandTargetsPropertyList extends cdktn.ComplexList {
        internalValue?: RunCommandTargetsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RunCommandTargetsPropertyOutputReference;
    }
    interface PipelineParameterListProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#name AwsTarget#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#value AwsTarget#value}
        */
        readonly value: string;
    }
    class PipelineParameterListPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PipelineParameterListProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PipelineParameterListProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class PipelineParameterListPropertyList extends cdktn.ComplexList {
        internalValue?: PipelineParameterListProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PipelineParameterListPropertyOutputReference;
    }
    interface SagemakerPipelineTargetProperty {
        /**
        * pipeline_parameter_list block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#pipeline_parameter_list AwsTarget#pipeline_parameter_list}
        */
        readonly pipelineParameterList?: PipelineParameterListProperty[] | cdktn.IResolvable;
    }
    class SagemakerPipelineTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SagemakerPipelineTargetProperty | undefined;
        set internalValue(value: SagemakerPipelineTargetProperty | undefined);
        private _pipelineParameterList;
        get pipelineParameterList(): PipelineParameterListPropertyList;
        putPipelineParameterList(value: PipelineParameterListProperty[] | cdktn.IResolvable): void;
        resetPipelineParameterList(): void;
        get pipelineParameterListInput(): cdktn.IResolvable | PipelineParameterListProperty[] | undefined;
    }
    interface SqsTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_target#message_group_id AwsTarget#message_group_id}
        */
        readonly messageGroupId?: string;
    }
    class SqsTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SqsTargetProperty | undefined;
        set internalValue(value: SqsTargetProperty | undefined);
        private _messageGroupId?;
        get messageGroupId(): string;
        set messageGroupId(value: string);
        resetMessageGroupId(): void;
        get messageGroupIdInput(): string | undefined;
    }
}
