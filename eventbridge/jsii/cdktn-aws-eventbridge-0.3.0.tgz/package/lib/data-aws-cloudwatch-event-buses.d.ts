import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsBusesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudwatch_event_buses#name_prefix DataAwsBuses#name_prefix}
    */
    readonly namePrefix?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudwatch_event_buses#region DataAwsBuses#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudwatch_event_buses aws_cloudwatch_event_buses}
*/
export declare class DataAwsBuses extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_cloudwatch_event_buses";
    /**
    * Generates CDKTN code for importing a DataAwsBuses resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsBuses to import
    * @param importFromId The id of the existing DataAwsBuses that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudwatch_event_buses#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsBuses to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cloudwatch_event_buses aws_cloudwatch_event_buses} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsBusesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsBusesConfig);
    private _eventBuses;
    get eventBuses(): DataAwsBuses.EventBusesPropertyList;
    private _namePrefix?;
    get namePrefix(): string;
    set namePrefix(value: string);
    resetNamePrefix(): void;
    get namePrefixInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsBusesEventBusesPropertyToTerraform(struct?: DataAwsBuses.EventBusesProperty): any;
export declare function dataAwsBusesEventBusesPropertyToHclTerraform(struct?: DataAwsBuses.EventBusesProperty): any;
export declare namespace DataAwsBuses {
    interface EventBusesProperty {
    }
    class EventBusesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EventBusesProperty | undefined;
        set internalValue(value: EventBusesProperty | undefined);
        get arn(): string;
        get creationTime(): string;
        get description(): string;
        get lastModifiedTime(): string;
        get name(): string;
        get policy(): string;
    }
    class EventBusesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EventBusesPropertyOutputReference;
    }
}
