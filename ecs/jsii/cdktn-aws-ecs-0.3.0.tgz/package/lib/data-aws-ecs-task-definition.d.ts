import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsTaskDefinitionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecs_task_definition#id DataAwsTaskDefinition#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecs_task_definition#region DataAwsTaskDefinition#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecs_task_definition#task_definition DataAwsTaskDefinition#task_definition}
    */
    readonly taskDefinition: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecs_task_definition aws_ecs_task_definition}
*/
export declare class DataAwsTaskDefinition extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_ecs_task_definition";
    /**
    * Generates CDKTN code for importing a DataAwsTaskDefinition resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsTaskDefinition to import
    * @param importFromId The id of the existing DataAwsTaskDefinition that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecs_task_definition#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsTaskDefinition to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecs_task_definition aws_ecs_task_definition} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsTaskDefinitionConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsTaskDefinitionConfig);
    get arn(): string;
    get arnWithoutRevision(): string;
    get containerDefinitions(): string;
    get cpu(): string;
    get enableFaultInjection(): cdktn.IResolvable;
    private _ephemeralStorage;
    get ephemeralStorage(): DataAwsTaskDefinition.EphemeralStoragePropertyList;
    get executionRoleArn(): string;
    get family(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ipcMode(): string;
    get memory(): string;
    get networkMode(): string;
    get pidMode(): string;
    private _placementConstraints;
    get placementConstraints(): DataAwsTaskDefinition.PlacementConstraintsPropertyList;
    private _proxyConfiguration;
    get proxyConfiguration(): DataAwsTaskDefinition.ProxyConfigurationPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get requiresCompatibilities(): string[];
    get revision(): number;
    private _runtimePlatform;
    get runtimePlatform(): DataAwsTaskDefinition.RuntimePlatformPropertyList;
    get status(): string;
    private _taskDefinition?;
    get taskDefinition(): string;
    set taskDefinition(value: string);
    get taskDefinitionInput(): string | undefined;
    get taskRoleArn(): string;
    private _volume;
    get volume(): DataAwsTaskDefinition.VolumePropertyList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsTaskDefinitionEphemeralStoragePropertyToTerraform(struct?: DataAwsTaskDefinition.EphemeralStorageProperty): any;
export declare function dataAwsTaskDefinitionEphemeralStoragePropertyToHclTerraform(struct?: DataAwsTaskDefinition.EphemeralStorageProperty): any;
export declare function dataAwsTaskDefinitionPlacementConstraintsPropertyToTerraform(struct?: DataAwsTaskDefinition.PlacementConstraintsProperty): any;
export declare function dataAwsTaskDefinitionPlacementConstraintsPropertyToHclTerraform(struct?: DataAwsTaskDefinition.PlacementConstraintsProperty): any;
export declare function dataAwsTaskDefinitionProxyConfigurationPropertyToTerraform(struct?: DataAwsTaskDefinition.ProxyConfigurationProperty): any;
export declare function dataAwsTaskDefinitionProxyConfigurationPropertyToHclTerraform(struct?: DataAwsTaskDefinition.ProxyConfigurationProperty): any;
export declare function dataAwsTaskDefinitionRuntimePlatformPropertyToTerraform(struct?: DataAwsTaskDefinition.RuntimePlatformProperty): any;
export declare function dataAwsTaskDefinitionRuntimePlatformPropertyToHclTerraform(struct?: DataAwsTaskDefinition.RuntimePlatformProperty): any;
export declare function dataAwsTaskDefinitionDockerVolumeConfigurationPropertyToTerraform(struct?: DataAwsTaskDefinition.DockerVolumeConfigurationProperty): any;
export declare function dataAwsTaskDefinitionDockerVolumeConfigurationPropertyToHclTerraform(struct?: DataAwsTaskDefinition.DockerVolumeConfigurationProperty): any;
export declare function dataAwsTaskDefinitionVolumeEfsVolumeConfigurationAuthorizationConfigPropertyToTerraform(struct?: DataAwsTaskDefinition.VolumeEfsVolumeConfigurationAuthorizationConfigProperty): any;
export declare function dataAwsTaskDefinitionVolumeEfsVolumeConfigurationAuthorizationConfigPropertyToHclTerraform(struct?: DataAwsTaskDefinition.VolumeEfsVolumeConfigurationAuthorizationConfigProperty): any;
export declare function dataAwsTaskDefinitionEfsVolumeConfigurationPropertyToTerraform(struct?: DataAwsTaskDefinition.EfsVolumeConfigurationProperty): any;
export declare function dataAwsTaskDefinitionEfsVolumeConfigurationPropertyToHclTerraform(struct?: DataAwsTaskDefinition.EfsVolumeConfigurationProperty): any;
export declare function dataAwsTaskDefinitionVolumeFsxWindowsFileServerVolumeConfigurationAuthorizationConfigPropertyToTerraform(struct?: DataAwsTaskDefinition.VolumeFsxWindowsFileServerVolumeConfigurationAuthorizationConfigProperty): any;
export declare function dataAwsTaskDefinitionVolumeFsxWindowsFileServerVolumeConfigurationAuthorizationConfigPropertyToHclTerraform(struct?: DataAwsTaskDefinition.VolumeFsxWindowsFileServerVolumeConfigurationAuthorizationConfigProperty): any;
export declare function dataAwsTaskDefinitionFsxWindowsFileServerVolumeConfigurationPropertyToTerraform(struct?: DataAwsTaskDefinition.FsxWindowsFileServerVolumeConfigurationProperty): any;
export declare function dataAwsTaskDefinitionFsxWindowsFileServerVolumeConfigurationPropertyToHclTerraform(struct?: DataAwsTaskDefinition.FsxWindowsFileServerVolumeConfigurationProperty): any;
export declare function dataAwsTaskDefinitionS3filesVolumeConfigurationPropertyToTerraform(struct?: DataAwsTaskDefinition.S3filesVolumeConfigurationProperty): any;
export declare function dataAwsTaskDefinitionS3filesVolumeConfigurationPropertyToHclTerraform(struct?: DataAwsTaskDefinition.S3filesVolumeConfigurationProperty): any;
export declare function dataAwsTaskDefinitionVolumePropertyToTerraform(struct?: DataAwsTaskDefinition.VolumeProperty): any;
export declare function dataAwsTaskDefinitionVolumePropertyToHclTerraform(struct?: DataAwsTaskDefinition.VolumeProperty): any;
export declare namespace DataAwsTaskDefinition {
    interface EphemeralStorageProperty {
    }
    class EphemeralStoragePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EphemeralStorageProperty | undefined;
        set internalValue(value: EphemeralStorageProperty | undefined);
        get sizeInGib(): number;
    }
    class EphemeralStoragePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EphemeralStoragePropertyOutputReference;
    }
    interface PlacementConstraintsProperty {
    }
    class PlacementConstraintsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PlacementConstraintsProperty | undefined;
        set internalValue(value: PlacementConstraintsProperty | undefined);
        get expression(): string;
        get type(): string;
    }
    class PlacementConstraintsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PlacementConstraintsPropertyOutputReference;
    }
    interface ProxyConfigurationProperty {
    }
    class ProxyConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ProxyConfigurationProperty | undefined;
        set internalValue(value: ProxyConfigurationProperty | undefined);
        get containerName(): string;
        private _properties;
        get properties(): cdktn.StringMap;
        get type(): string;
    }
    class ProxyConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ProxyConfigurationPropertyOutputReference;
    }
    interface RuntimePlatformProperty {
    }
    class RuntimePlatformPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuntimePlatformProperty | undefined;
        set internalValue(value: RuntimePlatformProperty | undefined);
        get cpuArchitecture(): string;
        get operatingSystemFamily(): string;
    }
    class RuntimePlatformPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuntimePlatformPropertyOutputReference;
    }
    interface DockerVolumeConfigurationProperty {
    }
    class DockerVolumeConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DockerVolumeConfigurationProperty | undefined;
        set internalValue(value: DockerVolumeConfigurationProperty | undefined);
        get autoprovision(): cdktn.IResolvable;
        get driver(): string;
        private _driverOpts;
        get driverOpts(): cdktn.StringMap;
        private _labels;
        get labels(): cdktn.StringMap;
        get scope(): string;
    }
    class DockerVolumeConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DockerVolumeConfigurationPropertyOutputReference;
    }
    interface VolumeEfsVolumeConfigurationAuthorizationConfigProperty {
    }
    class VolumeEfsVolumeConfigurationAuthorizationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VolumeEfsVolumeConfigurationAuthorizationConfigProperty | undefined;
        set internalValue(value: VolumeEfsVolumeConfigurationAuthorizationConfigProperty | undefined);
        get accessPointId(): string;
        get iam(): string;
    }
    class VolumeEfsVolumeConfigurationAuthorizationConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VolumeEfsVolumeConfigurationAuthorizationConfigPropertyOutputReference;
    }
    interface EfsVolumeConfigurationProperty {
    }
    class EfsVolumeConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EfsVolumeConfigurationProperty | undefined;
        set internalValue(value: EfsVolumeConfigurationProperty | undefined);
        private _authorizationConfig;
        get authorizationConfig(): VolumeEfsVolumeConfigurationAuthorizationConfigPropertyList;
        get fileSystemId(): string;
        get rootDirectory(): string;
        get transitEncryption(): string;
        get transitEncryptionPort(): number;
    }
    class EfsVolumeConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EfsVolumeConfigurationPropertyOutputReference;
    }
    interface VolumeFsxWindowsFileServerVolumeConfigurationAuthorizationConfigProperty {
    }
    class VolumeFsxWindowsFileServerVolumeConfigurationAuthorizationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VolumeFsxWindowsFileServerVolumeConfigurationAuthorizationConfigProperty | undefined;
        set internalValue(value: VolumeFsxWindowsFileServerVolumeConfigurationAuthorizationConfigProperty | undefined);
        get credentialsParameter(): string;
        get domain(): string;
    }
    class VolumeFsxWindowsFileServerVolumeConfigurationAuthorizationConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VolumeFsxWindowsFileServerVolumeConfigurationAuthorizationConfigPropertyOutputReference;
    }
    interface FsxWindowsFileServerVolumeConfigurationProperty {
    }
    class FsxWindowsFileServerVolumeConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FsxWindowsFileServerVolumeConfigurationProperty | undefined;
        set internalValue(value: FsxWindowsFileServerVolumeConfigurationProperty | undefined);
        private _authorizationConfig;
        get authorizationConfig(): VolumeFsxWindowsFileServerVolumeConfigurationAuthorizationConfigPropertyList;
        get fileSystemId(): string;
        get rootDirectory(): string;
    }
    class FsxWindowsFileServerVolumeConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FsxWindowsFileServerVolumeConfigurationPropertyOutputReference;
    }
    interface S3filesVolumeConfigurationProperty {
    }
    class S3filesVolumeConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3filesVolumeConfigurationProperty | undefined;
        set internalValue(value: S3filesVolumeConfigurationProperty | undefined);
        get accessPointArn(): string;
        get fileSystemArn(): string;
        get rootDirectory(): string;
        get transitEncryptionPort(): number;
    }
    class S3filesVolumeConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3filesVolumeConfigurationPropertyOutputReference;
    }
    interface VolumeProperty {
    }
    class VolumePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VolumeProperty | undefined;
        set internalValue(value: VolumeProperty | undefined);
        get configureAtLaunch(): cdktn.IResolvable;
        private _dockerVolumeConfiguration;
        get dockerVolumeConfiguration(): DockerVolumeConfigurationPropertyList;
        private _efsVolumeConfiguration;
        get efsVolumeConfiguration(): EfsVolumeConfigurationPropertyList;
        private _fsxWindowsFileServerVolumeConfiguration;
        get fsxWindowsFileServerVolumeConfiguration(): FsxWindowsFileServerVolumeConfigurationPropertyList;
        get hostPath(): string;
        get name(): string;
        private _s3FilesVolumeConfiguration;
        get s3FilesVolumeConfiguration(): S3filesVolumeConfigurationPropertyList;
    }
    class VolumePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VolumePropertyOutputReference;
    }
}
