import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsServiceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#availability_zone_rebalancing AwsService#availability_zone_rebalancing}
    */
    readonly availabilityZoneRebalancing?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#cluster AwsService#cluster}
    */
    readonly cluster?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#deployment_maximum_percent AwsService#deployment_maximum_percent}
    */
    readonly deploymentMaximumPercent?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#deployment_minimum_healthy_percent AwsService#deployment_minimum_healthy_percent}
    */
    readonly deploymentMinimumHealthyPercent?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#desired_count AwsService#desired_count}
    */
    readonly desiredCount?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#enable_ecs_managed_tags AwsService#enable_ecs_managed_tags}
    */
    readonly enableEcsManagedTags?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#enable_execute_command AwsService#enable_execute_command}
    */
    readonly enableExecuteCommand?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#force_delete AwsService#force_delete}
    */
    readonly forceDelete?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#force_new_deployment AwsService#force_new_deployment}
    */
    readonly forceNewDeployment?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#health_check_grace_period_seconds AwsService#health_check_grace_period_seconds}
    */
    readonly healthCheckGracePeriodSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#iam_role AwsService#iam_role}
    */
    readonly iamRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#id AwsService#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#launch_type AwsService#launch_type}
    */
    readonly launchType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#name AwsService#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#platform_version AwsService#platform_version}
    */
    readonly platformVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#propagate_tags AwsService#propagate_tags}
    */
    readonly propagateTags?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#region AwsService#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#scheduling_strategy AwsService#scheduling_strategy}
    */
    readonly schedulingStrategy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#sigint_rollback AwsService#sigint_rollback}
    */
    readonly sigintRollback?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#tags AwsService#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#tags_all AwsService#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#task_definition AwsService#task_definition}
    */
    readonly taskDefinition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#triggers AwsService#triggers}
    */
    readonly triggers?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#wait_for_steady_state AwsService#wait_for_steady_state}
    */
    readonly waitForSteadyState?: boolean | cdktn.IResolvable;
    /**
    * alarms block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#alarms AwsService#alarms}
    */
    readonly alarms?: AwsService.AlarmsProperty;
    /**
    * capacity_provider_strategy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#capacity_provider_strategy AwsService#capacity_provider_strategy}
    */
    readonly capacityProviderStrategy?: AwsService.CapacityProviderStrategyProperty[] | cdktn.IResolvable;
    /**
    * deployment_circuit_breaker block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#deployment_circuit_breaker AwsService#deployment_circuit_breaker}
    */
    readonly deploymentCircuitBreaker?: AwsService.DeploymentCircuitBreakerProperty;
    /**
    * deployment_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#deployment_configuration AwsService#deployment_configuration}
    */
    readonly deploymentConfiguration?: AwsService.DeploymentConfigurationProperty;
    /**
    * deployment_controller block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#deployment_controller AwsService#deployment_controller}
    */
    readonly deploymentController?: AwsService.DeploymentControllerProperty;
    /**
    * load_balancer block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#load_balancer AwsService#load_balancer}
    */
    readonly loadBalancer?: AwsService.LoadBalancerProperty[] | cdktn.IResolvable;
    /**
    * network_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#network_configuration AwsService#network_configuration}
    */
    readonly networkConfiguration?: AwsService.NetworkConfigurationProperty;
    /**
    * ordered_placement_strategy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#ordered_placement_strategy AwsService#ordered_placement_strategy}
    */
    readonly orderedPlacementStrategy?: AwsService.OrderedPlacementStrategyProperty[] | cdktn.IResolvable;
    /**
    * placement_constraints block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#placement_constraints AwsService#placement_constraints}
    */
    readonly placementConstraints?: AwsService.PlacementConstraintsProperty[] | cdktn.IResolvable;
    /**
    * service_connect_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#service_connect_configuration AwsService#service_connect_configuration}
    */
    readonly serviceConnectConfiguration?: AwsService.ServiceConnectConfigurationProperty;
    /**
    * service_registries block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#service_registries AwsService#service_registries}
    */
    readonly serviceRegistries?: AwsService.ServiceRegistriesProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#timeouts AwsService#timeouts}
    */
    readonly timeouts?: AwsService.TimeoutsProperty;
    /**
    * volume_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#volume_configuration AwsService#volume_configuration}
    */
    readonly volumeConfiguration?: AwsService.VolumeConfigurationProperty;
    /**
    * vpc_lattice_configurations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#vpc_lattice_configurations AwsService#vpc_lattice_configurations}
    */
    readonly vpcLatticeConfigurations?: AwsService.VpcLatticeConfigurationsProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service aws_ecs_service}
*/
export declare class AwsService extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ecs_service";
    /**
    * Generates CDKTN code for importing a AwsService resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsService to import
    * @param importFromId The id of the existing AwsService that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsService to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service aws_ecs_service} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsServiceConfig
    */
    constructor(scope: Construct, id: string, config: AwsServiceConfig);
    get arn(): string;
    private _availabilityZoneRebalancing?;
    get availabilityZoneRebalancing(): string;
    set availabilityZoneRebalancing(value: string);
    resetAvailabilityZoneRebalancing(): void;
    get availabilityZoneRebalancingInput(): string | undefined;
    private _cluster?;
    get cluster(): string;
    set cluster(value: string);
    resetCluster(): void;
    get clusterInput(): string | undefined;
    private _deploymentMaximumPercent?;
    get deploymentMaximumPercent(): number;
    set deploymentMaximumPercent(value: number);
    resetDeploymentMaximumPercent(): void;
    get deploymentMaximumPercentInput(): number | undefined;
    private _deploymentMinimumHealthyPercent?;
    get deploymentMinimumHealthyPercent(): number;
    set deploymentMinimumHealthyPercent(value: number);
    resetDeploymentMinimumHealthyPercent(): void;
    get deploymentMinimumHealthyPercentInput(): number | undefined;
    private _desiredCount?;
    get desiredCount(): number;
    set desiredCount(value: number);
    resetDesiredCount(): void;
    get desiredCountInput(): number | undefined;
    private _enableEcsManagedTags?;
    get enableEcsManagedTags(): boolean | cdktn.IResolvable;
    set enableEcsManagedTags(value: boolean | cdktn.IResolvable);
    resetEnableEcsManagedTags(): void;
    get enableEcsManagedTagsInput(): boolean | cdktn.IResolvable | undefined;
    private _enableExecuteCommand?;
    get enableExecuteCommand(): boolean | cdktn.IResolvable;
    set enableExecuteCommand(value: boolean | cdktn.IResolvable);
    resetEnableExecuteCommand(): void;
    get enableExecuteCommandInput(): boolean | cdktn.IResolvable | undefined;
    private _forceDelete?;
    get forceDelete(): boolean | cdktn.IResolvable;
    set forceDelete(value: boolean | cdktn.IResolvable);
    resetForceDelete(): void;
    get forceDeleteInput(): boolean | cdktn.IResolvable | undefined;
    private _forceNewDeployment?;
    get forceNewDeployment(): boolean | cdktn.IResolvable;
    set forceNewDeployment(value: boolean | cdktn.IResolvable);
    resetForceNewDeployment(): void;
    get forceNewDeploymentInput(): boolean | cdktn.IResolvable | undefined;
    private _healthCheckGracePeriodSeconds?;
    get healthCheckGracePeriodSeconds(): number;
    set healthCheckGracePeriodSeconds(value: number);
    resetHealthCheckGracePeriodSeconds(): void;
    get healthCheckGracePeriodSecondsInput(): number | undefined;
    private _iamRole?;
    get iamRole(): string;
    set iamRole(value: string);
    resetIamRole(): void;
    get iamRoleInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _launchType?;
    get launchType(): string;
    set launchType(value: string);
    resetLaunchType(): void;
    get launchTypeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _platformVersion?;
    get platformVersion(): string;
    set platformVersion(value: string);
    resetPlatformVersion(): void;
    get platformVersionInput(): string | undefined;
    private _propagateTags?;
    get propagateTags(): string;
    set propagateTags(value: string);
    resetPropagateTags(): void;
    get propagateTagsInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _schedulingStrategy?;
    get schedulingStrategy(): string;
    set schedulingStrategy(value: string);
    resetSchedulingStrategy(): void;
    get schedulingStrategyInput(): string | undefined;
    private _sigintRollback?;
    get sigintRollback(): boolean | cdktn.IResolvable;
    set sigintRollback(value: boolean | cdktn.IResolvable);
    resetSigintRollback(): void;
    get sigintRollbackInput(): boolean | cdktn.IResolvable | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _taskDefinition?;
    get taskDefinition(): string;
    set taskDefinition(value: string);
    resetTaskDefinition(): void;
    get taskDefinitionInput(): string | undefined;
    private _triggers?;
    get triggers(): {
        [key: string]: string;
    };
    set triggers(value: {
        [key: string]: string;
    });
    resetTriggers(): void;
    get triggersInput(): {
        [key: string]: string;
    } | undefined;
    private _waitForSteadyState?;
    get waitForSteadyState(): boolean | cdktn.IResolvable;
    set waitForSteadyState(value: boolean | cdktn.IResolvable);
    resetWaitForSteadyState(): void;
    get waitForSteadyStateInput(): boolean | cdktn.IResolvable | undefined;
    private _alarms;
    get alarms(): AwsService.AlarmsPropertyOutputReference;
    putAlarms(value: AwsService.AlarmsProperty): void;
    resetAlarms(): void;
    get alarmsInput(): AwsService.AlarmsProperty | undefined;
    private _capacityProviderStrategy;
    get capacityProviderStrategy(): AwsService.CapacityProviderStrategyPropertyList;
    putCapacityProviderStrategy(value: AwsService.CapacityProviderStrategyProperty[] | cdktn.IResolvable): void;
    resetCapacityProviderStrategy(): void;
    get capacityProviderStrategyInput(): cdktn.IResolvable | AwsService.CapacityProviderStrategyProperty[] | undefined;
    private _deploymentCircuitBreaker;
    get deploymentCircuitBreaker(): AwsService.DeploymentCircuitBreakerPropertyOutputReference;
    putDeploymentCircuitBreaker(value: AwsService.DeploymentCircuitBreakerProperty): void;
    resetDeploymentCircuitBreaker(): void;
    get deploymentCircuitBreakerInput(): AwsService.DeploymentCircuitBreakerProperty | undefined;
    private _deploymentConfiguration;
    get deploymentConfiguration(): AwsService.DeploymentConfigurationPropertyOutputReference;
    putDeploymentConfiguration(value: AwsService.DeploymentConfigurationProperty): void;
    resetDeploymentConfiguration(): void;
    get deploymentConfigurationInput(): AwsService.DeploymentConfigurationProperty | undefined;
    private _deploymentController;
    get deploymentController(): AwsService.DeploymentControllerPropertyOutputReference;
    putDeploymentController(value: AwsService.DeploymentControllerProperty): void;
    resetDeploymentController(): void;
    get deploymentControllerInput(): AwsService.DeploymentControllerProperty | undefined;
    private _loadBalancer;
    get loadBalancer(): AwsService.LoadBalancerPropertyList;
    putLoadBalancer(value: AwsService.LoadBalancerProperty[] | cdktn.IResolvable): void;
    resetLoadBalancer(): void;
    get loadBalancerInput(): cdktn.IResolvable | AwsService.LoadBalancerProperty[] | undefined;
    private _networkConfiguration;
    get networkConfiguration(): AwsService.NetworkConfigurationPropertyOutputReference;
    putNetworkConfiguration(value: AwsService.NetworkConfigurationProperty): void;
    resetNetworkConfiguration(): void;
    get networkConfigurationInput(): AwsService.NetworkConfigurationProperty | undefined;
    private _orderedPlacementStrategy;
    get orderedPlacementStrategy(): AwsService.OrderedPlacementStrategyPropertyList;
    putOrderedPlacementStrategy(value: AwsService.OrderedPlacementStrategyProperty[] | cdktn.IResolvable): void;
    resetOrderedPlacementStrategy(): void;
    get orderedPlacementStrategyInput(): cdktn.IResolvable | AwsService.OrderedPlacementStrategyProperty[] | undefined;
    private _placementConstraints;
    get placementConstraints(): AwsService.PlacementConstraintsPropertyList;
    putPlacementConstraints(value: AwsService.PlacementConstraintsProperty[] | cdktn.IResolvable): void;
    resetPlacementConstraints(): void;
    get placementConstraintsInput(): cdktn.IResolvable | AwsService.PlacementConstraintsProperty[] | undefined;
    private _serviceConnectConfiguration;
    get serviceConnectConfiguration(): AwsService.ServiceConnectConfigurationPropertyOutputReference;
    putServiceConnectConfiguration(value: AwsService.ServiceConnectConfigurationProperty): void;
    resetServiceConnectConfiguration(): void;
    get serviceConnectConfigurationInput(): AwsService.ServiceConnectConfigurationProperty | undefined;
    private _serviceRegistries;
    get serviceRegistries(): AwsService.ServiceRegistriesPropertyOutputReference;
    putServiceRegistries(value: AwsService.ServiceRegistriesProperty): void;
    resetServiceRegistries(): void;
    get serviceRegistriesInput(): AwsService.ServiceRegistriesProperty | undefined;
    private _timeouts;
    get timeouts(): AwsService.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsService.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsService.TimeoutsProperty | undefined;
    private _volumeConfiguration;
    get volumeConfiguration(): AwsService.VolumeConfigurationPropertyOutputReference;
    putVolumeConfiguration(value: AwsService.VolumeConfigurationProperty): void;
    resetVolumeConfiguration(): void;
    get volumeConfigurationInput(): AwsService.VolumeConfigurationProperty | undefined;
    private _vpcLatticeConfigurations;
    get vpcLatticeConfigurations(): AwsService.VpcLatticeConfigurationsPropertyList;
    putVpcLatticeConfigurations(value: AwsService.VpcLatticeConfigurationsProperty[] | cdktn.IResolvable): void;
    resetVpcLatticeConfigurations(): void;
    get vpcLatticeConfigurationsInput(): cdktn.IResolvable | AwsService.VpcLatticeConfigurationsProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsServiceAlarmsPropertyToTerraform(struct?: AwsService.AlarmsPropertyOutputReference | AwsService.AlarmsProperty): any;
export declare function awsServiceAlarmsPropertyToHclTerraform(struct?: AwsService.AlarmsPropertyOutputReference | AwsService.AlarmsProperty): any;
export declare function awsServiceCapacityProviderStrategyPropertyToTerraform(struct?: AwsService.CapacityProviderStrategyProperty | cdktn.IResolvable): any;
export declare function awsServiceCapacityProviderStrategyPropertyToHclTerraform(struct?: AwsService.CapacityProviderStrategyProperty | cdktn.IResolvable): any;
export declare function awsServiceDeploymentCircuitBreakerPropertyToTerraform(struct?: AwsService.DeploymentCircuitBreakerPropertyOutputReference | AwsService.DeploymentCircuitBreakerProperty): any;
export declare function awsServiceDeploymentCircuitBreakerPropertyToHclTerraform(struct?: AwsService.DeploymentCircuitBreakerPropertyOutputReference | AwsService.DeploymentCircuitBreakerProperty): any;
export declare function awsServiceCanaryConfigurationPropertyToTerraform(struct?: AwsService.CanaryConfigurationPropertyOutputReference | AwsService.CanaryConfigurationProperty): any;
export declare function awsServiceCanaryConfigurationPropertyToHclTerraform(struct?: AwsService.CanaryConfigurationPropertyOutputReference | AwsService.CanaryConfigurationProperty): any;
export declare function awsServiceLifecycleHookPropertyToTerraform(struct?: AwsService.LifecycleHookProperty | cdktn.IResolvable): any;
export declare function awsServiceLifecycleHookPropertyToHclTerraform(struct?: AwsService.LifecycleHookProperty | cdktn.IResolvable): any;
export declare function awsServiceLinearConfigurationPropertyToTerraform(struct?: AwsService.LinearConfigurationPropertyOutputReference | AwsService.LinearConfigurationProperty): any;
export declare function awsServiceLinearConfigurationPropertyToHclTerraform(struct?: AwsService.LinearConfigurationPropertyOutputReference | AwsService.LinearConfigurationProperty): any;
export declare function awsServiceDeploymentConfigurationPropertyToTerraform(struct?: AwsService.DeploymentConfigurationPropertyOutputReference | AwsService.DeploymentConfigurationProperty): any;
export declare function awsServiceDeploymentConfigurationPropertyToHclTerraform(struct?: AwsService.DeploymentConfigurationPropertyOutputReference | AwsService.DeploymentConfigurationProperty): any;
export declare function awsServiceDeploymentControllerPropertyToTerraform(struct?: AwsService.DeploymentControllerPropertyOutputReference | AwsService.DeploymentControllerProperty): any;
export declare function awsServiceDeploymentControllerPropertyToHclTerraform(struct?: AwsService.DeploymentControllerPropertyOutputReference | AwsService.DeploymentControllerProperty): any;
export declare function awsServiceAdvancedConfigurationPropertyToTerraform(struct?: AwsService.AdvancedConfigurationPropertyOutputReference | AwsService.AdvancedConfigurationProperty): any;
export declare function awsServiceAdvancedConfigurationPropertyToHclTerraform(struct?: AwsService.AdvancedConfigurationPropertyOutputReference | AwsService.AdvancedConfigurationProperty): any;
export declare function awsServiceLoadBalancerPropertyToTerraform(struct?: AwsService.LoadBalancerProperty | cdktn.IResolvable): any;
export declare function awsServiceLoadBalancerPropertyToHclTerraform(struct?: AwsService.LoadBalancerProperty | cdktn.IResolvable): any;
export declare function awsServiceNetworkConfigurationPropertyToTerraform(struct?: AwsService.NetworkConfigurationPropertyOutputReference | AwsService.NetworkConfigurationProperty): any;
export declare function awsServiceNetworkConfigurationPropertyToHclTerraform(struct?: AwsService.NetworkConfigurationPropertyOutputReference | AwsService.NetworkConfigurationProperty): any;
export declare function awsServiceOrderedPlacementStrategyPropertyToTerraform(struct?: AwsService.OrderedPlacementStrategyProperty | cdktn.IResolvable): any;
export declare function awsServiceOrderedPlacementStrategyPropertyToHclTerraform(struct?: AwsService.OrderedPlacementStrategyProperty | cdktn.IResolvable): any;
export declare function awsServicePlacementConstraintsPropertyToTerraform(struct?: AwsService.PlacementConstraintsProperty | cdktn.IResolvable): any;
export declare function awsServicePlacementConstraintsPropertyToHclTerraform(struct?: AwsService.PlacementConstraintsProperty | cdktn.IResolvable): any;
export declare function awsServiceAccessLogConfigurationPropertyToTerraform(struct?: AwsService.AccessLogConfigurationPropertyOutputReference | AwsService.AccessLogConfigurationProperty): any;
export declare function awsServiceAccessLogConfigurationPropertyToHclTerraform(struct?: AwsService.AccessLogConfigurationPropertyOutputReference | AwsService.AccessLogConfigurationProperty): any;
export declare function awsServiceSecretOptionPropertyToTerraform(struct?: AwsService.SecretOptionProperty | cdktn.IResolvable): any;
export declare function awsServiceSecretOptionPropertyToHclTerraform(struct?: AwsService.SecretOptionProperty | cdktn.IResolvable): any;
export declare function awsServiceLogConfigurationPropertyToTerraform(struct?: AwsService.LogConfigurationPropertyOutputReference | AwsService.LogConfigurationProperty): any;
export declare function awsServiceLogConfigurationPropertyToHclTerraform(struct?: AwsService.LogConfigurationPropertyOutputReference | AwsService.LogConfigurationProperty): any;
export declare function awsServiceValuePropertyToTerraform(struct?: AwsService.ValuePropertyOutputReference | AwsService.ValueProperty): any;
export declare function awsServiceValuePropertyToHclTerraform(struct?: AwsService.ValuePropertyOutputReference | AwsService.ValueProperty): any;
export declare function awsServiceHeaderPropertyToTerraform(struct?: AwsService.HeaderPropertyOutputReference | AwsService.HeaderProperty): any;
export declare function awsServiceHeaderPropertyToHclTerraform(struct?: AwsService.HeaderPropertyOutputReference | AwsService.HeaderProperty): any;
export declare function awsServiceTestTrafficRulesPropertyToTerraform(struct?: AwsService.TestTrafficRulesProperty | cdktn.IResolvable): any;
export declare function awsServiceTestTrafficRulesPropertyToHclTerraform(struct?: AwsService.TestTrafficRulesProperty | cdktn.IResolvable): any;
export declare function awsServiceClientAliasPropertyToTerraform(struct?: AwsService.ClientAliasPropertyOutputReference | AwsService.ClientAliasProperty): any;
export declare function awsServiceClientAliasPropertyToHclTerraform(struct?: AwsService.ClientAliasPropertyOutputReference | AwsService.ClientAliasProperty): any;
export declare function awsServiceTimeoutPropertyToTerraform(struct?: AwsService.TimeoutPropertyOutputReference | AwsService.TimeoutProperty): any;
export declare function awsServiceTimeoutPropertyToHclTerraform(struct?: AwsService.TimeoutPropertyOutputReference | AwsService.TimeoutProperty): any;
export declare function awsServiceIssuerCertAuthorityPropertyToTerraform(struct?: AwsService.IssuerCertAuthorityPropertyOutputReference | AwsService.IssuerCertAuthorityProperty): any;
export declare function awsServiceIssuerCertAuthorityPropertyToHclTerraform(struct?: AwsService.IssuerCertAuthorityPropertyOutputReference | AwsService.IssuerCertAuthorityProperty): any;
export declare function awsServiceTlsPropertyToTerraform(struct?: AwsService.TlsPropertyOutputReference | AwsService.TlsProperty): any;
export declare function awsServiceTlsPropertyToHclTerraform(struct?: AwsService.TlsPropertyOutputReference | AwsService.TlsProperty): any;
export declare function awsServiceServicePropertyToTerraform(struct?: AwsService.ServiceProperty | cdktn.IResolvable): any;
export declare function awsServiceServicePropertyToHclTerraform(struct?: AwsService.ServiceProperty | cdktn.IResolvable): any;
export declare function awsServiceServiceConnectConfigurationPropertyToTerraform(struct?: AwsService.ServiceConnectConfigurationPropertyOutputReference | AwsService.ServiceConnectConfigurationProperty): any;
export declare function awsServiceServiceConnectConfigurationPropertyToHclTerraform(struct?: AwsService.ServiceConnectConfigurationPropertyOutputReference | AwsService.ServiceConnectConfigurationProperty): any;
export declare function awsServiceServiceRegistriesPropertyToTerraform(struct?: AwsService.ServiceRegistriesPropertyOutputReference | AwsService.ServiceRegistriesProperty): any;
export declare function awsServiceServiceRegistriesPropertyToHclTerraform(struct?: AwsService.ServiceRegistriesPropertyOutputReference | AwsService.ServiceRegistriesProperty): any;
export declare function awsServiceTimeoutsPropertyToTerraform(struct?: AwsService.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsServiceTimeoutsPropertyToHclTerraform(struct?: AwsService.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsServiceTagSpecificationsPropertyToTerraform(struct?: AwsService.TagSpecificationsProperty | cdktn.IResolvable): any;
export declare function awsServiceTagSpecificationsPropertyToHclTerraform(struct?: AwsService.TagSpecificationsProperty | cdktn.IResolvable): any;
export declare function awsServiceManagedEbsVolumePropertyToTerraform(struct?: AwsService.ManagedEbsVolumePropertyOutputReference | AwsService.ManagedEbsVolumeProperty): any;
export declare function awsServiceManagedEbsVolumePropertyToHclTerraform(struct?: AwsService.ManagedEbsVolumePropertyOutputReference | AwsService.ManagedEbsVolumeProperty): any;
export declare function awsServiceVolumeConfigurationPropertyToTerraform(struct?: AwsService.VolumeConfigurationPropertyOutputReference | AwsService.VolumeConfigurationProperty): any;
export declare function awsServiceVolumeConfigurationPropertyToHclTerraform(struct?: AwsService.VolumeConfigurationPropertyOutputReference | AwsService.VolumeConfigurationProperty): any;
export declare function awsServiceVpcLatticeConfigurationsPropertyToTerraform(struct?: AwsService.VpcLatticeConfigurationsProperty | cdktn.IResolvable): any;
export declare function awsServiceVpcLatticeConfigurationsPropertyToHclTerraform(struct?: AwsService.VpcLatticeConfigurationsProperty | cdktn.IResolvable): any;
export declare namespace AwsService {
    interface AlarmsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#alarm_names AwsService#alarm_names}
        */
        readonly alarmNames: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#enable AwsService#enable}
        */
        readonly enable: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#rollback AwsService#rollback}
        */
        readonly rollback: boolean | cdktn.IResolvable;
    }
    class AlarmsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AlarmsProperty | undefined;
        set internalValue(value: AlarmsProperty | undefined);
        private _alarmNames?;
        get alarmNames(): string[];
        set alarmNames(value: string[]);
        get alarmNamesInput(): string[] | undefined;
        private _enable?;
        get enable(): boolean | cdktn.IResolvable;
        set enable(value: boolean | cdktn.IResolvable);
        get enableInput(): boolean | cdktn.IResolvable | undefined;
        private _rollback?;
        get rollback(): boolean | cdktn.IResolvable;
        set rollback(value: boolean | cdktn.IResolvable);
        get rollbackInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface CapacityProviderStrategyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#base AwsService#base}
        */
        readonly base?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#capacity_provider AwsService#capacity_provider}
        */
        readonly capacityProvider: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#weight AwsService#weight}
        */
        readonly weight?: number;
    }
    class CapacityProviderStrategyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CapacityProviderStrategyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CapacityProviderStrategyProperty | cdktn.IResolvable | undefined);
        private _base?;
        get base(): number;
        set base(value: number);
        resetBase(): void;
        get baseInput(): number | undefined;
        private _capacityProvider?;
        get capacityProvider(): string;
        set capacityProvider(value: string);
        get capacityProviderInput(): string | undefined;
        private _weight?;
        get weight(): number;
        set weight(value: number);
        resetWeight(): void;
        get weightInput(): number | undefined;
    }
    class CapacityProviderStrategyPropertyList extends cdktn.ComplexList {
        internalValue?: CapacityProviderStrategyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CapacityProviderStrategyPropertyOutputReference;
    }
    interface DeploymentCircuitBreakerProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#enable AwsService#enable}
        */
        readonly enable: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#rollback AwsService#rollback}
        */
        readonly rollback: boolean | cdktn.IResolvable;
    }
    class DeploymentCircuitBreakerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DeploymentCircuitBreakerProperty | undefined;
        set internalValue(value: DeploymentCircuitBreakerProperty | undefined);
        private _enable?;
        get enable(): boolean | cdktn.IResolvable;
        set enable(value: boolean | cdktn.IResolvable);
        get enableInput(): boolean | cdktn.IResolvable | undefined;
        private _rollback?;
        get rollback(): boolean | cdktn.IResolvable;
        set rollback(value: boolean | cdktn.IResolvable);
        get rollbackInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface CanaryConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#canary_bake_time_in_minutes AwsService#canary_bake_time_in_minutes}
        */
        readonly canaryBakeTimeInMinutes?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#canary_percent AwsService#canary_percent}
        */
        readonly canaryPercent?: number;
    }
    class CanaryConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CanaryConfigurationProperty | undefined;
        set internalValue(value: CanaryConfigurationProperty | undefined);
        private _canaryBakeTimeInMinutes?;
        get canaryBakeTimeInMinutes(): string;
        set canaryBakeTimeInMinutes(value: string);
        resetCanaryBakeTimeInMinutes(): void;
        get canaryBakeTimeInMinutesInput(): string | undefined;
        private _canaryPercent?;
        get canaryPercent(): number;
        set canaryPercent(value: number);
        resetCanaryPercent(): void;
        get canaryPercentInput(): number | undefined;
    }
    interface LifecycleHookProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#hook_details AwsService#hook_details}
        */
        readonly hookDetails?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#hook_target_arn AwsService#hook_target_arn}
        */
        readonly hookTargetArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#lifecycle_stages AwsService#lifecycle_stages}
        */
        readonly lifecycleStages: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#role_arn AwsService#role_arn}
        */
        readonly roleArn: string;
    }
    class LifecycleHookPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LifecycleHookProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LifecycleHookProperty | cdktn.IResolvable | undefined);
        private _hookDetails?;
        get hookDetails(): string;
        set hookDetails(value: string);
        resetHookDetails(): void;
        get hookDetailsInput(): string | undefined;
        private _hookTargetArn?;
        get hookTargetArn(): string;
        set hookTargetArn(value: string);
        get hookTargetArnInput(): string | undefined;
        private _lifecycleStages?;
        get lifecycleStages(): string[];
        set lifecycleStages(value: string[]);
        get lifecycleStagesInput(): string[] | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
    }
    class LifecycleHookPropertyList extends cdktn.ComplexList {
        internalValue?: LifecycleHookProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LifecycleHookPropertyOutputReference;
    }
    interface LinearConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#step_bake_time_in_minutes AwsService#step_bake_time_in_minutes}
        */
        readonly stepBakeTimeInMinutes?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#step_percent AwsService#step_percent}
        */
        readonly stepPercent?: number;
    }
    class LinearConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LinearConfigurationProperty | undefined;
        set internalValue(value: LinearConfigurationProperty | undefined);
        private _stepBakeTimeInMinutes?;
        get stepBakeTimeInMinutes(): string;
        set stepBakeTimeInMinutes(value: string);
        resetStepBakeTimeInMinutes(): void;
        get stepBakeTimeInMinutesInput(): string | undefined;
        private _stepPercent?;
        get stepPercent(): number;
        set stepPercent(value: number);
        resetStepPercent(): void;
        get stepPercentInput(): number | undefined;
    }
    interface DeploymentConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#bake_time_in_minutes AwsService#bake_time_in_minutes}
        */
        readonly bakeTimeInMinutes?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#strategy AwsService#strategy}
        */
        readonly strategy?: string;
        /**
        * canary_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#canary_configuration AwsService#canary_configuration}
        */
        readonly canaryConfiguration?: CanaryConfigurationProperty;
        /**
        * lifecycle_hook block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#lifecycle_hook AwsService#lifecycle_hook}
        */
        readonly lifecycleHook?: LifecycleHookProperty[] | cdktn.IResolvable;
        /**
        * linear_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#linear_configuration AwsService#linear_configuration}
        */
        readonly linearConfiguration?: LinearConfigurationProperty;
    }
    class DeploymentConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DeploymentConfigurationProperty | undefined;
        set internalValue(value: DeploymentConfigurationProperty | undefined);
        private _bakeTimeInMinutes?;
        get bakeTimeInMinutes(): string;
        set bakeTimeInMinutes(value: string);
        resetBakeTimeInMinutes(): void;
        get bakeTimeInMinutesInput(): string | undefined;
        private _strategy?;
        get strategy(): string;
        set strategy(value: string);
        resetStrategy(): void;
        get strategyInput(): string | undefined;
        private _canaryConfiguration;
        get canaryConfiguration(): CanaryConfigurationPropertyOutputReference;
        putCanaryConfiguration(value: CanaryConfigurationProperty): void;
        resetCanaryConfiguration(): void;
        get canaryConfigurationInput(): CanaryConfigurationProperty | undefined;
        private _lifecycleHook;
        get lifecycleHook(): LifecycleHookPropertyList;
        putLifecycleHook(value: LifecycleHookProperty[] | cdktn.IResolvable): void;
        resetLifecycleHook(): void;
        get lifecycleHookInput(): cdktn.IResolvable | LifecycleHookProperty[] | undefined;
        private _linearConfiguration;
        get linearConfiguration(): LinearConfigurationPropertyOutputReference;
        putLinearConfiguration(value: LinearConfigurationProperty): void;
        resetLinearConfiguration(): void;
        get linearConfigurationInput(): LinearConfigurationProperty | undefined;
    }
    interface DeploymentControllerProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#type AwsService#type}
        */
        readonly type?: string;
    }
    class DeploymentControllerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DeploymentControllerProperty | undefined;
        set internalValue(value: DeploymentControllerProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
    }
    interface AdvancedConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#alternate_target_group_arn AwsService#alternate_target_group_arn}
        */
        readonly alternateTargetGroupArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#production_listener_rule AwsService#production_listener_rule}
        */
        readonly productionListenerRule: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#role_arn AwsService#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#test_listener_rule AwsService#test_listener_rule}
        */
        readonly testListenerRule?: string;
    }
    class AdvancedConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AdvancedConfigurationProperty | undefined;
        set internalValue(value: AdvancedConfigurationProperty | undefined);
        private _alternateTargetGroupArn?;
        get alternateTargetGroupArn(): string;
        set alternateTargetGroupArn(value: string);
        get alternateTargetGroupArnInput(): string | undefined;
        private _productionListenerRule?;
        get productionListenerRule(): string;
        set productionListenerRule(value: string);
        get productionListenerRuleInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _testListenerRule?;
        get testListenerRule(): string;
        set testListenerRule(value: string);
        resetTestListenerRule(): void;
        get testListenerRuleInput(): string | undefined;
    }
    interface LoadBalancerProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#container_name AwsService#container_name}
        */
        readonly containerName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#container_port AwsService#container_port}
        */
        readonly containerPort: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#elb_name AwsService#elb_name}
        */
        readonly elbName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#target_group_arn AwsService#target_group_arn}
        */
        readonly targetGroupArn?: string;
        /**
        * advanced_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#advanced_configuration AwsService#advanced_configuration}
        */
        readonly advancedConfiguration?: AdvancedConfigurationProperty;
    }
    class LoadBalancerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LoadBalancerProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LoadBalancerProperty | cdktn.IResolvable | undefined);
        private _containerName?;
        get containerName(): string;
        set containerName(value: string);
        get containerNameInput(): string | undefined;
        private _containerPort?;
        get containerPort(): number;
        set containerPort(value: number);
        get containerPortInput(): number | undefined;
        private _elbName?;
        get elbName(): string;
        set elbName(value: string);
        resetElbName(): void;
        get elbNameInput(): string | undefined;
        private _targetGroupArn?;
        get targetGroupArn(): string;
        set targetGroupArn(value: string);
        resetTargetGroupArn(): void;
        get targetGroupArnInput(): string | undefined;
        private _advancedConfiguration;
        get advancedConfiguration(): AdvancedConfigurationPropertyOutputReference;
        putAdvancedConfiguration(value: AdvancedConfigurationProperty): void;
        resetAdvancedConfiguration(): void;
        get advancedConfigurationInput(): AdvancedConfigurationProperty | undefined;
    }
    class LoadBalancerPropertyList extends cdktn.ComplexList {
        internalValue?: LoadBalancerProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LoadBalancerPropertyOutputReference;
    }
    interface NetworkConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#assign_public_ip AwsService#assign_public_ip}
        */
        readonly assignPublicIp?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#security_groups AwsService#security_groups}
        */
        readonly securityGroups?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#subnets AwsService#subnets}
        */
        readonly subnets: string[];
    }
    class NetworkConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NetworkConfigurationProperty | undefined;
        set internalValue(value: NetworkConfigurationProperty | undefined);
        private _assignPublicIp?;
        get assignPublicIp(): boolean | cdktn.IResolvable;
        set assignPublicIp(value: boolean | cdktn.IResolvable);
        resetAssignPublicIp(): void;
        get assignPublicIpInput(): boolean | cdktn.IResolvable | undefined;
        private _securityGroups?;
        get securityGroups(): string[];
        set securityGroups(value: string[]);
        resetSecurityGroups(): void;
        get securityGroupsInput(): string[] | undefined;
        private _subnets?;
        get subnets(): string[];
        set subnets(value: string[]);
        get subnetsInput(): string[] | undefined;
    }
    interface OrderedPlacementStrategyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#field AwsService#field}
        */
        readonly field?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#type AwsService#type}
        */
        readonly type: string;
    }
    class OrderedPlacementStrategyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OrderedPlacementStrategyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OrderedPlacementStrategyProperty | cdktn.IResolvable | undefined);
        private _field?;
        get field(): string;
        set field(value: string);
        resetField(): void;
        get fieldInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class OrderedPlacementStrategyPropertyList extends cdktn.ComplexList {
        internalValue?: OrderedPlacementStrategyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OrderedPlacementStrategyPropertyOutputReference;
    }
    interface PlacementConstraintsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#expression AwsService#expression}
        */
        readonly expression?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#type AwsService#type}
        */
        readonly type: string;
    }
    class PlacementConstraintsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PlacementConstraintsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PlacementConstraintsProperty | cdktn.IResolvable | undefined);
        private _expression?;
        get expression(): string;
        set expression(value: string);
        resetExpression(): void;
        get expressionInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class PlacementConstraintsPropertyList extends cdktn.ComplexList {
        internalValue?: PlacementConstraintsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PlacementConstraintsPropertyOutputReference;
    }
    interface AccessLogConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#format AwsService#format}
        */
        readonly format: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#include_query_parameters AwsService#include_query_parameters}
        */
        readonly includeQueryParameters?: string;
    }
    class AccessLogConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AccessLogConfigurationProperty | undefined;
        set internalValue(value: AccessLogConfigurationProperty | undefined);
        private _format?;
        get format(): string;
        set format(value: string);
        get formatInput(): string | undefined;
        private _includeQueryParameters?;
        get includeQueryParameters(): string;
        set includeQueryParameters(value: string);
        resetIncludeQueryParameters(): void;
        get includeQueryParametersInput(): string | undefined;
    }
    interface SecretOptionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#name AwsService#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#value_from AwsService#value_from}
        */
        readonly valueFrom: string;
    }
    class SecretOptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SecretOptionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SecretOptionProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _valueFrom?;
        get valueFrom(): string;
        set valueFrom(value: string);
        get valueFromInput(): string | undefined;
    }
    class SecretOptionPropertyList extends cdktn.ComplexList {
        internalValue?: SecretOptionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SecretOptionPropertyOutputReference;
    }
    interface LogConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#log_driver AwsService#log_driver}
        */
        readonly logDriver: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#options AwsService#options}
        */
        readonly options?: {
            [key: string]: string;
        };
        /**
        * secret_option block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#secret_option AwsService#secret_option}
        */
        readonly secretOption?: SecretOptionProperty[] | cdktn.IResolvable;
    }
    class LogConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LogConfigurationProperty | undefined;
        set internalValue(value: LogConfigurationProperty | undefined);
        private _logDriver?;
        get logDriver(): string;
        set logDriver(value: string);
        get logDriverInput(): string | undefined;
        private _options?;
        get options(): {
            [key: string]: string;
        };
        set options(value: {
            [key: string]: string;
        });
        resetOptions(): void;
        get optionsInput(): {
            [key: string]: string;
        } | undefined;
        private _secretOption;
        get secretOption(): SecretOptionPropertyList;
        putSecretOption(value: SecretOptionProperty[] | cdktn.IResolvable): void;
        resetSecretOption(): void;
        get secretOptionInput(): cdktn.IResolvable | SecretOptionProperty[] | undefined;
    }
    interface ValueProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#exact AwsService#exact}
        */
        readonly exact: string;
    }
    class ValuePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ValueProperty | undefined;
        set internalValue(value: ValueProperty | undefined);
        private _exact?;
        get exact(): string;
        set exact(value: string);
        get exactInput(): string | undefined;
    }
    interface HeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#name AwsService#name}
        */
        readonly name: string;
        /**
        * value block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#value AwsService#value}
        */
        readonly value: ValueProperty;
    }
    class HeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HeaderProperty | undefined;
        set internalValue(value: HeaderProperty | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value;
        get value(): ValuePropertyOutputReference;
        putValue(value: ValueProperty): void;
        get valueInput(): ValueProperty | undefined;
    }
    interface TestTrafficRulesProperty {
        /**
        * header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#header AwsService#header}
        */
        readonly header?: HeaderProperty;
    }
    class TestTrafficRulesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TestTrafficRulesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TestTrafficRulesProperty | cdktn.IResolvable | undefined);
        private _header;
        get header(): HeaderPropertyOutputReference;
        putHeader(value: HeaderProperty): void;
        resetHeader(): void;
        get headerInput(): HeaderProperty | undefined;
    }
    class TestTrafficRulesPropertyList extends cdktn.ComplexList {
        internalValue?: TestTrafficRulesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TestTrafficRulesPropertyOutputReference;
    }
    interface ClientAliasProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#dns_name AwsService#dns_name}
        */
        readonly dnsName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#port AwsService#port}
        */
        readonly port: number;
        /**
        * test_traffic_rules block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#test_traffic_rules AwsService#test_traffic_rules}
        */
        readonly testTrafficRules?: TestTrafficRulesProperty[] | cdktn.IResolvable;
    }
    class ClientAliasPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ClientAliasProperty | undefined;
        set internalValue(value: ClientAliasProperty | undefined);
        private _dnsName?;
        get dnsName(): string;
        set dnsName(value: string);
        resetDnsName(): void;
        get dnsNameInput(): string | undefined;
        private _port?;
        get port(): number;
        set port(value: number);
        get portInput(): number | undefined;
        private _testTrafficRules;
        get testTrafficRules(): TestTrafficRulesPropertyList;
        putTestTrafficRules(value: TestTrafficRulesProperty[] | cdktn.IResolvable): void;
        resetTestTrafficRules(): void;
        get testTrafficRulesInput(): cdktn.IResolvable | TestTrafficRulesProperty[] | undefined;
    }
    interface TimeoutProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#idle_timeout_seconds AwsService#idle_timeout_seconds}
        */
        readonly idleTimeoutSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#per_request_timeout_seconds AwsService#per_request_timeout_seconds}
        */
        readonly perRequestTimeoutSeconds?: number;
    }
    class TimeoutPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutProperty | undefined;
        set internalValue(value: TimeoutProperty | undefined);
        private _idleTimeoutSeconds?;
        get idleTimeoutSeconds(): number;
        set idleTimeoutSeconds(value: number);
        resetIdleTimeoutSeconds(): void;
        get idleTimeoutSecondsInput(): number | undefined;
        private _perRequestTimeoutSeconds?;
        get perRequestTimeoutSeconds(): number;
        set perRequestTimeoutSeconds(value: number);
        resetPerRequestTimeoutSeconds(): void;
        get perRequestTimeoutSecondsInput(): number | undefined;
    }
    interface IssuerCertAuthorityProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#aws_pca_authority_arn AwsService#aws_pca_authority_arn}
        */
        readonly awsPcaAuthorityArn: string;
    }
    class IssuerCertAuthorityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IssuerCertAuthorityProperty | undefined;
        set internalValue(value: IssuerCertAuthorityProperty | undefined);
        private _awsPcaAuthorityArn?;
        get awsPcaAuthorityArn(): string;
        set awsPcaAuthorityArn(value: string);
        get awsPcaAuthorityArnInput(): string | undefined;
    }
    interface TlsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#kms_key AwsService#kms_key}
        */
        readonly kmsKey?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#role_arn AwsService#role_arn}
        */
        readonly roleArn?: string;
        /**
        * issuer_cert_authority block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#issuer_cert_authority AwsService#issuer_cert_authority}
        */
        readonly issuerCertAuthority: IssuerCertAuthorityProperty;
    }
    class TlsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TlsProperty | undefined;
        set internalValue(value: TlsProperty | undefined);
        private _kmsKey?;
        get kmsKey(): string;
        set kmsKey(value: string);
        resetKmsKey(): void;
        get kmsKeyInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        resetRoleArn(): void;
        get roleArnInput(): string | undefined;
        private _issuerCertAuthority;
        get issuerCertAuthority(): IssuerCertAuthorityPropertyOutputReference;
        putIssuerCertAuthority(value: IssuerCertAuthorityProperty): void;
        get issuerCertAuthorityInput(): IssuerCertAuthorityProperty | undefined;
    }
    interface ServiceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#discovery_name AwsService#discovery_name}
        */
        readonly discoveryName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#ingress_port_override AwsService#ingress_port_override}
        */
        readonly ingressPortOverride?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#port_name AwsService#port_name}
        */
        readonly portName: string;
        /**
        * client_alias block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#client_alias AwsService#client_alias}
        */
        readonly clientAlias?: ClientAliasProperty;
        /**
        * timeout block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#timeout AwsService#timeout}
        */
        readonly timeout?: TimeoutProperty;
        /**
        * tls block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#tls AwsService#tls}
        */
        readonly tls?: TlsProperty;
    }
    class ServicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ServiceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ServiceProperty | cdktn.IResolvable | undefined);
        private _discoveryName?;
        get discoveryName(): string;
        set discoveryName(value: string);
        resetDiscoveryName(): void;
        get discoveryNameInput(): string | undefined;
        private _ingressPortOverride?;
        get ingressPortOverride(): number;
        set ingressPortOverride(value: number);
        resetIngressPortOverride(): void;
        get ingressPortOverrideInput(): number | undefined;
        private _portName?;
        get portName(): string;
        set portName(value: string);
        get portNameInput(): string | undefined;
        private _clientAlias;
        get clientAlias(): ClientAliasPropertyOutputReference;
        putClientAlias(value: ClientAliasProperty): void;
        resetClientAlias(): void;
        get clientAliasInput(): ClientAliasProperty | undefined;
        private _timeout;
        get timeout(): TimeoutPropertyOutputReference;
        putTimeout(value: TimeoutProperty): void;
        resetTimeout(): void;
        get timeoutInput(): TimeoutProperty | undefined;
        private _tls;
        get tls(): TlsPropertyOutputReference;
        putTls(value: TlsProperty): void;
        resetTls(): void;
        get tlsInput(): TlsProperty | undefined;
    }
    class ServicePropertyList extends cdktn.ComplexList {
        internalValue?: ServiceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ServicePropertyOutputReference;
    }
    interface ServiceConnectConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#enabled AwsService#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#namespace AwsService#namespace}
        */
        readonly namespace?: string;
        /**
        * access_log_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#access_log_configuration AwsService#access_log_configuration}
        */
        readonly accessLogConfiguration?: AccessLogConfigurationProperty;
        /**
        * log_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#log_configuration AwsService#log_configuration}
        */
        readonly logConfiguration?: LogConfigurationProperty;
        /**
        * service block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#service AwsService#service}
        */
        readonly service?: ServiceProperty[] | cdktn.IResolvable;
    }
    class ServiceConnectConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ServiceConnectConfigurationProperty | undefined;
        set internalValue(value: ServiceConnectConfigurationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _namespace?;
        get namespace(): string;
        set namespace(value: string);
        resetNamespace(): void;
        get namespaceInput(): string | undefined;
        private _accessLogConfiguration;
        get accessLogConfiguration(): AccessLogConfigurationPropertyOutputReference;
        putAccessLogConfiguration(value: AccessLogConfigurationProperty): void;
        resetAccessLogConfiguration(): void;
        get accessLogConfigurationInput(): AccessLogConfigurationProperty | undefined;
        private _logConfiguration;
        get logConfiguration(): LogConfigurationPropertyOutputReference;
        putLogConfiguration(value: LogConfigurationProperty): void;
        resetLogConfiguration(): void;
        get logConfigurationInput(): LogConfigurationProperty | undefined;
        private _service;
        get service(): ServicePropertyList;
        putService(value: ServiceProperty[] | cdktn.IResolvable): void;
        resetService(): void;
        get serviceInput(): cdktn.IResolvable | ServiceProperty[] | undefined;
    }
    interface ServiceRegistriesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#container_name AwsService#container_name}
        */
        readonly containerName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#container_port AwsService#container_port}
        */
        readonly containerPort?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#port AwsService#port}
        */
        readonly port?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#registry_arn AwsService#registry_arn}
        */
        readonly registryArn: string;
    }
    class ServiceRegistriesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ServiceRegistriesProperty | undefined;
        set internalValue(value: ServiceRegistriesProperty | undefined);
        private _containerName?;
        get containerName(): string;
        set containerName(value: string);
        resetContainerName(): void;
        get containerNameInput(): string | undefined;
        private _containerPort?;
        get containerPort(): number;
        set containerPort(value: number);
        resetContainerPort(): void;
        get containerPortInput(): number | undefined;
        private _port?;
        get port(): number;
        set port(value: number);
        resetPort(): void;
        get portInput(): number | undefined;
        private _registryArn?;
        get registryArn(): string;
        set registryArn(value: string);
        get registryArnInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#create AwsService#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#delete AwsService#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#update AwsService#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface TagSpecificationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#propagate_tags AwsService#propagate_tags}
        */
        readonly propagateTags?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#resource_type AwsService#resource_type}
        */
        readonly resourceType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#tags AwsService#tags}
        */
        readonly tags?: {
            [key: string]: string;
        };
    }
    class TagSpecificationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TagSpecificationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TagSpecificationsProperty | cdktn.IResolvable | undefined);
        private _propagateTags?;
        get propagateTags(): string;
        set propagateTags(value: string);
        resetPropagateTags(): void;
        get propagateTagsInput(): string | undefined;
        private _resourceType?;
        get resourceType(): string;
        set resourceType(value: string);
        get resourceTypeInput(): string | undefined;
        private _tags?;
        get tags(): {
            [key: string]: string;
        };
        set tags(value: {
            [key: string]: string;
        });
        resetTags(): void;
        get tagsInput(): {
            [key: string]: string;
        } | undefined;
    }
    class TagSpecificationsPropertyList extends cdktn.ComplexList {
        internalValue?: TagSpecificationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TagSpecificationsPropertyOutputReference;
    }
    interface ManagedEbsVolumeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#encrypted AwsService#encrypted}
        */
        readonly encrypted?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#file_system_type AwsService#file_system_type}
        */
        readonly fileSystemType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#iops AwsService#iops}
        */
        readonly iops?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#kms_key_id AwsService#kms_key_id}
        */
        readonly kmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#role_arn AwsService#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#size_in_gb AwsService#size_in_gb}
        */
        readonly sizeInGb?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#snapshot_id AwsService#snapshot_id}
        */
        readonly snapshotId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#throughput AwsService#throughput}
        */
        readonly throughput?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#volume_initialization_rate AwsService#volume_initialization_rate}
        */
        readonly volumeInitializationRate?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#volume_type AwsService#volume_type}
        */
        readonly volumeType?: string;
        /**
        * tag_specifications block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#tag_specifications AwsService#tag_specifications}
        */
        readonly tagSpecifications?: TagSpecificationsProperty[] | cdktn.IResolvable;
    }
    class ManagedEbsVolumePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ManagedEbsVolumeProperty | undefined;
        set internalValue(value: ManagedEbsVolumeProperty | undefined);
        private _encrypted?;
        get encrypted(): boolean | cdktn.IResolvable;
        set encrypted(value: boolean | cdktn.IResolvable);
        resetEncrypted(): void;
        get encryptedInput(): boolean | cdktn.IResolvable | undefined;
        private _fileSystemType?;
        get fileSystemType(): string;
        set fileSystemType(value: string);
        resetFileSystemType(): void;
        get fileSystemTypeInput(): string | undefined;
        private _iops?;
        get iops(): number;
        set iops(value: number);
        resetIops(): void;
        get iopsInput(): number | undefined;
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _sizeInGb?;
        get sizeInGb(): number;
        set sizeInGb(value: number);
        resetSizeInGb(): void;
        get sizeInGbInput(): number | undefined;
        private _snapshotId?;
        get snapshotId(): string;
        set snapshotId(value: string);
        resetSnapshotId(): void;
        get snapshotIdInput(): string | undefined;
        private _throughput?;
        get throughput(): number;
        set throughput(value: number);
        resetThroughput(): void;
        get throughputInput(): number | undefined;
        private _volumeInitializationRate?;
        get volumeInitializationRate(): number;
        set volumeInitializationRate(value: number);
        resetVolumeInitializationRate(): void;
        get volumeInitializationRateInput(): number | undefined;
        private _volumeType?;
        get volumeType(): string;
        set volumeType(value: string);
        resetVolumeType(): void;
        get volumeTypeInput(): string | undefined;
        private _tagSpecifications;
        get tagSpecifications(): TagSpecificationsPropertyList;
        putTagSpecifications(value: TagSpecificationsProperty[] | cdktn.IResolvable): void;
        resetTagSpecifications(): void;
        get tagSpecificationsInput(): cdktn.IResolvable | TagSpecificationsProperty[] | undefined;
    }
    interface VolumeConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#name AwsService#name}
        */
        readonly name: string;
        /**
        * managed_ebs_volume block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#managed_ebs_volume AwsService#managed_ebs_volume}
        */
        readonly managedEbsVolume: ManagedEbsVolumeProperty;
    }
    class VolumeConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VolumeConfigurationProperty | undefined;
        set internalValue(value: VolumeConfigurationProperty | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _managedEbsVolume;
        get managedEbsVolume(): ManagedEbsVolumePropertyOutputReference;
        putManagedEbsVolume(value: ManagedEbsVolumeProperty): void;
        get managedEbsVolumeInput(): ManagedEbsVolumeProperty | undefined;
    }
    interface VpcLatticeConfigurationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#port_name AwsService#port_name}
        */
        readonly portName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#role_arn AwsService#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_service#target_group_arn AwsService#target_group_arn}
        */
        readonly targetGroupArn: string;
    }
    class VpcLatticeConfigurationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpcLatticeConfigurationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VpcLatticeConfigurationsProperty | cdktn.IResolvable | undefined);
        private _portName?;
        get portName(): string;
        set portName(value: string);
        get portNameInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _targetGroupArn?;
        get targetGroupArn(): string;
        set targetGroupArn(value: string);
        get targetGroupArnInput(): string | undefined;
    }
    class VpcLatticeConfigurationsPropertyList extends cdktn.ComplexList {
        internalValue?: VpcLatticeConfigurationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpcLatticeConfigurationsPropertyOutputReference;
    }
}
