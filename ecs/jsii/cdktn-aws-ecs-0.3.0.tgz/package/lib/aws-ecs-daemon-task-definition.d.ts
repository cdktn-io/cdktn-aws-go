import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDaemonTaskDefinitionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#cpu AwsDaemonTaskDefinition#cpu}
    */
    readonly cpu?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#execution_role_arn AwsDaemonTaskDefinition#execution_role_arn}
    */
    readonly executionRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#family AwsDaemonTaskDefinition#family}
    */
    readonly family: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#memory AwsDaemonTaskDefinition#memory}
    */
    readonly memory?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#region AwsDaemonTaskDefinition#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#tags AwsDaemonTaskDefinition#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#task_role_arn AwsDaemonTaskDefinition#task_role_arn}
    */
    readonly taskRoleArn?: string;
    /**
    * container_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#container_definition AwsDaemonTaskDefinition#container_definition}
    */
    readonly containerDefinition?: AwsDaemonTaskDefinition.ContainerDefinitionProperty[] | cdktn.IResolvable;
    /**
    * volume block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#volume AwsDaemonTaskDefinition#volume}
    */
    readonly volume?: AwsDaemonTaskDefinition.VolumeProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition aws_ecs_daemon_task_definition}
*/
export declare class AwsDaemonTaskDefinition extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ecs_daemon_task_definition";
    /**
    * Generates CDKTN code for importing a AwsDaemonTaskDefinition resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDaemonTaskDefinition to import
    * @param importFromId The id of the existing AwsDaemonTaskDefinition that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDaemonTaskDefinition to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition aws_ecs_daemon_task_definition} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDaemonTaskDefinitionConfig
    */
    constructor(scope: Construct, id: string, config: AwsDaemonTaskDefinitionConfig);
    get arn(): string;
    private _cpu?;
    get cpu(): string;
    set cpu(value: string);
    resetCpu(): void;
    get cpuInput(): string | undefined;
    private _executionRoleArn?;
    get executionRoleArn(): string;
    set executionRoleArn(value: string);
    resetExecutionRoleArn(): void;
    get executionRoleArnInput(): string | undefined;
    private _family?;
    get family(): string;
    set family(value: string);
    get familyInput(): string | undefined;
    private _memory?;
    get memory(): string;
    set memory(value: string);
    resetMemory(): void;
    get memoryInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get revision(): number;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _taskRoleArn?;
    get taskRoleArn(): string;
    set taskRoleArn(value: string);
    resetTaskRoleArn(): void;
    get taskRoleArnInput(): string | undefined;
    private _containerDefinition;
    get containerDefinition(): AwsDaemonTaskDefinition.ContainerDefinitionPropertyList;
    putContainerDefinition(value: AwsDaemonTaskDefinition.ContainerDefinitionProperty[] | cdktn.IResolvable): void;
    resetContainerDefinition(): void;
    get containerDefinitionInput(): cdktn.IResolvable | AwsDaemonTaskDefinition.ContainerDefinitionProperty[] | undefined;
    private _volume;
    get volume(): AwsDaemonTaskDefinition.VolumePropertyList;
    putVolume(value: AwsDaemonTaskDefinition.VolumeProperty[] | cdktn.IResolvable): void;
    resetVolume(): void;
    get volumeInput(): cdktn.IResolvable | AwsDaemonTaskDefinition.VolumeProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDaemonTaskDefinitionDependsOnPropertyToTerraform(struct?: AwsDaemonTaskDefinition.DependsOnProperty | cdktn.IResolvable): any;
export declare function awsDaemonTaskDefinitionDependsOnPropertyToHclTerraform(struct?: AwsDaemonTaskDefinition.DependsOnProperty | cdktn.IResolvable): any;
export declare function awsDaemonTaskDefinitionEnvironmentPropertyToTerraform(struct?: AwsDaemonTaskDefinition.EnvironmentProperty | cdktn.IResolvable): any;
export declare function awsDaemonTaskDefinitionEnvironmentPropertyToHclTerraform(struct?: AwsDaemonTaskDefinition.EnvironmentProperty | cdktn.IResolvable): any;
export declare function awsDaemonTaskDefinitionEnvironmentFilePropertyToTerraform(struct?: AwsDaemonTaskDefinition.EnvironmentFileProperty | cdktn.IResolvable): any;
export declare function awsDaemonTaskDefinitionEnvironmentFilePropertyToHclTerraform(struct?: AwsDaemonTaskDefinition.EnvironmentFileProperty | cdktn.IResolvable): any;
export declare function awsDaemonTaskDefinitionFirelensConfigurationPropertyToTerraform(struct?: AwsDaemonTaskDefinition.FirelensConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDaemonTaskDefinitionFirelensConfigurationPropertyToHclTerraform(struct?: AwsDaemonTaskDefinition.FirelensConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDaemonTaskDefinitionHealthCheckPropertyToTerraform(struct?: AwsDaemonTaskDefinition.HealthCheckProperty | cdktn.IResolvable): any;
export declare function awsDaemonTaskDefinitionHealthCheckPropertyToHclTerraform(struct?: AwsDaemonTaskDefinition.HealthCheckProperty | cdktn.IResolvable): any;
export declare function awsDaemonTaskDefinitionCapabilitiesPropertyToTerraform(struct?: AwsDaemonTaskDefinition.CapabilitiesProperty | cdktn.IResolvable): any;
export declare function awsDaemonTaskDefinitionCapabilitiesPropertyToHclTerraform(struct?: AwsDaemonTaskDefinition.CapabilitiesProperty | cdktn.IResolvable): any;
export declare function awsDaemonTaskDefinitionDevicePropertyToTerraform(struct?: AwsDaemonTaskDefinition.DeviceProperty | cdktn.IResolvable): any;
export declare function awsDaemonTaskDefinitionDevicePropertyToHclTerraform(struct?: AwsDaemonTaskDefinition.DeviceProperty | cdktn.IResolvable): any;
export declare function awsDaemonTaskDefinitionTmpfsPropertyToTerraform(struct?: AwsDaemonTaskDefinition.TmpfsProperty | cdktn.IResolvable): any;
export declare function awsDaemonTaskDefinitionTmpfsPropertyToHclTerraform(struct?: AwsDaemonTaskDefinition.TmpfsProperty | cdktn.IResolvable): any;
export declare function awsDaemonTaskDefinitionLinuxParametersPropertyToTerraform(struct?: AwsDaemonTaskDefinition.LinuxParametersProperty | cdktn.IResolvable): any;
export declare function awsDaemonTaskDefinitionLinuxParametersPropertyToHclTerraform(struct?: AwsDaemonTaskDefinition.LinuxParametersProperty | cdktn.IResolvable): any;
export declare function awsDaemonTaskDefinitionSecretOptionPropertyToTerraform(struct?: AwsDaemonTaskDefinition.SecretOptionProperty | cdktn.IResolvable): any;
export declare function awsDaemonTaskDefinitionSecretOptionPropertyToHclTerraform(struct?: AwsDaemonTaskDefinition.SecretOptionProperty | cdktn.IResolvable): any;
export declare function awsDaemonTaskDefinitionLogConfigurationPropertyToTerraform(struct?: AwsDaemonTaskDefinition.LogConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDaemonTaskDefinitionLogConfigurationPropertyToHclTerraform(struct?: AwsDaemonTaskDefinition.LogConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDaemonTaskDefinitionMountPointPropertyToTerraform(struct?: AwsDaemonTaskDefinition.MountPointProperty | cdktn.IResolvable): any;
export declare function awsDaemonTaskDefinitionMountPointPropertyToHclTerraform(struct?: AwsDaemonTaskDefinition.MountPointProperty | cdktn.IResolvable): any;
export declare function awsDaemonTaskDefinitionRepositoryCredentialsPropertyToTerraform(struct?: AwsDaemonTaskDefinition.RepositoryCredentialsProperty | cdktn.IResolvable): any;
export declare function awsDaemonTaskDefinitionRepositoryCredentialsPropertyToHclTerraform(struct?: AwsDaemonTaskDefinition.RepositoryCredentialsProperty | cdktn.IResolvable): any;
export declare function awsDaemonTaskDefinitionRestartPolicyPropertyToTerraform(struct?: AwsDaemonTaskDefinition.RestartPolicyProperty | cdktn.IResolvable): any;
export declare function awsDaemonTaskDefinitionRestartPolicyPropertyToHclTerraform(struct?: AwsDaemonTaskDefinition.RestartPolicyProperty | cdktn.IResolvable): any;
export declare function awsDaemonTaskDefinitionSecretPropertyToTerraform(struct?: AwsDaemonTaskDefinition.SecretProperty | cdktn.IResolvable): any;
export declare function awsDaemonTaskDefinitionSecretPropertyToHclTerraform(struct?: AwsDaemonTaskDefinition.SecretProperty | cdktn.IResolvable): any;
export declare function awsDaemonTaskDefinitionSystemControlPropertyToTerraform(struct?: AwsDaemonTaskDefinition.SystemControlProperty | cdktn.IResolvable): any;
export declare function awsDaemonTaskDefinitionSystemControlPropertyToHclTerraform(struct?: AwsDaemonTaskDefinition.SystemControlProperty | cdktn.IResolvable): any;
export declare function awsDaemonTaskDefinitionUlimitPropertyToTerraform(struct?: AwsDaemonTaskDefinition.UlimitProperty | cdktn.IResolvable): any;
export declare function awsDaemonTaskDefinitionUlimitPropertyToHclTerraform(struct?: AwsDaemonTaskDefinition.UlimitProperty | cdktn.IResolvable): any;
export declare function awsDaemonTaskDefinitionContainerDefinitionPropertyToTerraform(struct?: AwsDaemonTaskDefinition.ContainerDefinitionProperty | cdktn.IResolvable): any;
export declare function awsDaemonTaskDefinitionContainerDefinitionPropertyToHclTerraform(struct?: AwsDaemonTaskDefinition.ContainerDefinitionProperty | cdktn.IResolvable): any;
export declare function awsDaemonTaskDefinitionHostPropertyToTerraform(struct?: AwsDaemonTaskDefinition.HostProperty | cdktn.IResolvable): any;
export declare function awsDaemonTaskDefinitionHostPropertyToHclTerraform(struct?: AwsDaemonTaskDefinition.HostProperty | cdktn.IResolvable): any;
export declare function awsDaemonTaskDefinitionVolumePropertyToTerraform(struct?: AwsDaemonTaskDefinition.VolumeProperty | cdktn.IResolvable): any;
export declare function awsDaemonTaskDefinitionVolumePropertyToHclTerraform(struct?: AwsDaemonTaskDefinition.VolumeProperty | cdktn.IResolvable): any;
export declare namespace AwsDaemonTaskDefinition {
    interface DependsOnProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#condition AwsDaemonTaskDefinition#condition}
        */
        readonly condition: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#container_name AwsDaemonTaskDefinition#container_name}
        */
        readonly containerName: string;
    }
    class DependsOnPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DependsOnProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DependsOnProperty | cdktn.IResolvable | undefined);
        private _condition?;
        get condition(): string;
        set condition(value: string);
        get conditionInput(): string | undefined;
        private _containerName?;
        get containerName(): string;
        set containerName(value: string);
        get containerNameInput(): string | undefined;
    }
    class DependsOnPropertyList extends cdktn.ComplexList {
        internalValue?: DependsOnProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DependsOnPropertyOutputReference;
    }
    interface EnvironmentProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#name AwsDaemonTaskDefinition#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#value AwsDaemonTaskDefinition#value}
        */
        readonly value?: string;
    }
    class EnvironmentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EnvironmentProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EnvironmentProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
    class EnvironmentPropertyList extends cdktn.ComplexList {
        internalValue?: EnvironmentProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EnvironmentPropertyOutputReference;
    }
    interface EnvironmentFileProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#type AwsDaemonTaskDefinition#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#value AwsDaemonTaskDefinition#value}
        */
        readonly value: string;
    }
    class EnvironmentFilePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EnvironmentFileProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EnvironmentFileProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class EnvironmentFilePropertyList extends cdktn.ComplexList {
        internalValue?: EnvironmentFileProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EnvironmentFilePropertyOutputReference;
    }
    interface FirelensConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#options AwsDaemonTaskDefinition#options}
        */
        readonly options?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#type AwsDaemonTaskDefinition#type}
        */
        readonly type: string;
    }
    class FirelensConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FirelensConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FirelensConfigurationProperty | cdktn.IResolvable | undefined);
        private _options?;
        get options(): {
            [key: string]: string;
        };
        set options(value: {
            [key: string]: string;
        });
        resetOptions(): void;
        get optionsInput(): {
            [key: string]: string;
        } | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class FirelensConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: FirelensConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FirelensConfigurationPropertyOutputReference;
    }
    interface HealthCheckProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#command AwsDaemonTaskDefinition#command}
        */
        readonly command: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#interval AwsDaemonTaskDefinition#interval}
        */
        readonly interval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#retries AwsDaemonTaskDefinition#retries}
        */
        readonly retries?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#start_period AwsDaemonTaskDefinition#start_period}
        */
        readonly startPeriod?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#timeout AwsDaemonTaskDefinition#timeout}
        */
        readonly timeout?: number;
    }
    class HealthCheckPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HealthCheckProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HealthCheckProperty | cdktn.IResolvable | undefined);
        private _command?;
        get command(): string[];
        set command(value: string[]);
        get commandInput(): string[] | undefined;
        private _interval?;
        get interval(): number;
        set interval(value: number);
        resetInterval(): void;
        get intervalInput(): number | undefined;
        private _retries?;
        get retries(): number;
        set retries(value: number);
        resetRetries(): void;
        get retriesInput(): number | undefined;
        private _startPeriod?;
        get startPeriod(): number;
        set startPeriod(value: number);
        resetStartPeriod(): void;
        get startPeriodInput(): number | undefined;
        private _timeout?;
        get timeout(): number;
        set timeout(value: number);
        resetTimeout(): void;
        get timeoutInput(): number | undefined;
    }
    class HealthCheckPropertyList extends cdktn.ComplexList {
        internalValue?: HealthCheckProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HealthCheckPropertyOutputReference;
    }
    interface CapabilitiesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#add AwsDaemonTaskDefinition#add}
        */
        readonly add?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#drop AwsDaemonTaskDefinition#drop}
        */
        readonly drop?: string[];
    }
    class CapabilitiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CapabilitiesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CapabilitiesProperty | cdktn.IResolvable | undefined);
        private _add?;
        get add(): string[];
        set add(value: string[]);
        resetAdd(): void;
        get addInput(): string[] | undefined;
        private _drop?;
        get drop(): string[];
        set drop(value: string[]);
        resetDrop(): void;
        get dropInput(): string[] | undefined;
    }
    class CapabilitiesPropertyList extends cdktn.ComplexList {
        internalValue?: CapabilitiesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CapabilitiesPropertyOutputReference;
    }
    interface DeviceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#container_path AwsDaemonTaskDefinition#container_path}
        */
        readonly containerPath?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#host_path AwsDaemonTaskDefinition#host_path}
        */
        readonly hostPath: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#permissions AwsDaemonTaskDefinition#permissions}
        */
        readonly permissions?: string[];
    }
    class DevicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DeviceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DeviceProperty | cdktn.IResolvable | undefined);
        private _containerPath?;
        get containerPath(): string;
        set containerPath(value: string);
        resetContainerPath(): void;
        get containerPathInput(): string | undefined;
        private _hostPath?;
        get hostPath(): string;
        set hostPath(value: string);
        get hostPathInput(): string | undefined;
        private _permissions?;
        get permissions(): string[];
        set permissions(value: string[]);
        resetPermissions(): void;
        get permissionsInput(): string[] | undefined;
    }
    class DevicePropertyList extends cdktn.ComplexList {
        internalValue?: DeviceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DevicePropertyOutputReference;
    }
    interface TmpfsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#container_path AwsDaemonTaskDefinition#container_path}
        */
        readonly containerPath: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#mount_options AwsDaemonTaskDefinition#mount_options}
        */
        readonly mountOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#size AwsDaemonTaskDefinition#size}
        */
        readonly size: number;
    }
    class TmpfsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TmpfsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TmpfsProperty | cdktn.IResolvable | undefined);
        private _containerPath?;
        get containerPath(): string;
        set containerPath(value: string);
        get containerPathInput(): string | undefined;
        private _mountOptions?;
        get mountOptions(): string[];
        set mountOptions(value: string[]);
        resetMountOptions(): void;
        get mountOptionsInput(): string[] | undefined;
        private _size?;
        get size(): number;
        set size(value: number);
        get sizeInput(): number | undefined;
    }
    class TmpfsPropertyList extends cdktn.ComplexList {
        internalValue?: TmpfsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TmpfsPropertyOutputReference;
    }
    interface LinuxParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#init_process_enabled AwsDaemonTaskDefinition#init_process_enabled}
        */
        readonly initProcessEnabled?: boolean | cdktn.IResolvable;
        /**
        * capabilities block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#capabilities AwsDaemonTaskDefinition#capabilities}
        */
        readonly capabilities?: CapabilitiesProperty[] | cdktn.IResolvable;
        /**
        * device block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#device AwsDaemonTaskDefinition#device}
        */
        readonly device?: DeviceProperty[] | cdktn.IResolvable;
        /**
        * tmpfs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#tmpfs AwsDaemonTaskDefinition#tmpfs}
        */
        readonly tmpfs?: TmpfsProperty[] | cdktn.IResolvable;
    }
    class LinuxParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LinuxParametersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LinuxParametersProperty | cdktn.IResolvable | undefined);
        private _initProcessEnabled?;
        get initProcessEnabled(): boolean | cdktn.IResolvable;
        set initProcessEnabled(value: boolean | cdktn.IResolvable);
        resetInitProcessEnabled(): void;
        get initProcessEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _capabilities;
        get capabilities(): CapabilitiesPropertyList;
        putCapabilities(value: CapabilitiesProperty[] | cdktn.IResolvable): void;
        resetCapabilities(): void;
        get capabilitiesInput(): cdktn.IResolvable | CapabilitiesProperty[] | undefined;
        private _device;
        get device(): DevicePropertyList;
        putDevice(value: DeviceProperty[] | cdktn.IResolvable): void;
        resetDevice(): void;
        get deviceInput(): cdktn.IResolvable | DeviceProperty[] | undefined;
        private _tmpfs;
        get tmpfs(): TmpfsPropertyList;
        putTmpfs(value: TmpfsProperty[] | cdktn.IResolvable): void;
        resetTmpfs(): void;
        get tmpfsInput(): cdktn.IResolvable | TmpfsProperty[] | undefined;
    }
    class LinuxParametersPropertyList extends cdktn.ComplexList {
        internalValue?: LinuxParametersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LinuxParametersPropertyOutputReference;
    }
    interface SecretOptionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#name AwsDaemonTaskDefinition#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#value_from AwsDaemonTaskDefinition#value_from}
        */
        readonly valueFrom: string;
    }
    class SecretOptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SecretOptionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SecretOptionProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _valueFrom?;
        get valueFrom(): string;
        set valueFrom(value: string);
        get valueFromInput(): string | undefined;
    }
    class SecretOptionPropertyList extends cdktn.ComplexList {
        internalValue?: SecretOptionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SecretOptionPropertyOutputReference;
    }
    interface LogConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#log_driver AwsDaemonTaskDefinition#log_driver}
        */
        readonly logDriver: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#options AwsDaemonTaskDefinition#options}
        */
        readonly options?: {
            [key: string]: string;
        };
        /**
        * secret_option block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#secret_option AwsDaemonTaskDefinition#secret_option}
        */
        readonly secretOption?: SecretOptionProperty[] | cdktn.IResolvable;
    }
    class LogConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LogConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LogConfigurationProperty | cdktn.IResolvable | undefined);
        private _logDriver?;
        get logDriver(): string;
        set logDriver(value: string);
        get logDriverInput(): string | undefined;
        private _options?;
        get options(): {
            [key: string]: string;
        };
        set options(value: {
            [key: string]: string;
        });
        resetOptions(): void;
        get optionsInput(): {
            [key: string]: string;
        } | undefined;
        private _secretOption;
        get secretOption(): SecretOptionPropertyList;
        putSecretOption(value: SecretOptionProperty[] | cdktn.IResolvable): void;
        resetSecretOption(): void;
        get secretOptionInput(): cdktn.IResolvable | SecretOptionProperty[] | undefined;
    }
    class LogConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: LogConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LogConfigurationPropertyOutputReference;
    }
    interface MountPointProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#container_path AwsDaemonTaskDefinition#container_path}
        */
        readonly containerPath?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#read_only AwsDaemonTaskDefinition#read_only}
        */
        readonly readOnly?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#source_volume AwsDaemonTaskDefinition#source_volume}
        */
        readonly sourceVolume?: string;
    }
    class MountPointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MountPointProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MountPointProperty | cdktn.IResolvable | undefined);
        private _containerPath?;
        get containerPath(): string;
        set containerPath(value: string);
        resetContainerPath(): void;
        get containerPathInput(): string | undefined;
        private _readOnly?;
        get readOnly(): boolean | cdktn.IResolvable;
        set readOnly(value: boolean | cdktn.IResolvable);
        resetReadOnly(): void;
        get readOnlyInput(): boolean | cdktn.IResolvable | undefined;
        private _sourceVolume?;
        get sourceVolume(): string;
        set sourceVolume(value: string);
        resetSourceVolume(): void;
        get sourceVolumeInput(): string | undefined;
    }
    class MountPointPropertyList extends cdktn.ComplexList {
        internalValue?: MountPointProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MountPointPropertyOutputReference;
    }
    interface RepositoryCredentialsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#credentials_parameter AwsDaemonTaskDefinition#credentials_parameter}
        */
        readonly credentialsParameter: string;
    }
    class RepositoryCredentialsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RepositoryCredentialsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RepositoryCredentialsProperty | cdktn.IResolvable | undefined);
        private _credentialsParameter?;
        get credentialsParameter(): string;
        set credentialsParameter(value: string);
        get credentialsParameterInput(): string | undefined;
    }
    class RepositoryCredentialsPropertyList extends cdktn.ComplexList {
        internalValue?: RepositoryCredentialsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RepositoryCredentialsPropertyOutputReference;
    }
    interface RestartPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#enabled AwsDaemonTaskDefinition#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#ignored_exit_codes AwsDaemonTaskDefinition#ignored_exit_codes}
        */
        readonly ignoredExitCodes?: number[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#restart_attempt_period AwsDaemonTaskDefinition#restart_attempt_period}
        */
        readonly restartAttemptPeriod?: number;
    }
    class RestartPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RestartPolicyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RestartPolicyProperty | cdktn.IResolvable | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _ignoredExitCodes?;
        get ignoredExitCodes(): number[];
        set ignoredExitCodes(value: number[]);
        resetIgnoredExitCodes(): void;
        get ignoredExitCodesInput(): number[] | undefined;
        private _restartAttemptPeriod?;
        get restartAttemptPeriod(): number;
        set restartAttemptPeriod(value: number);
        resetRestartAttemptPeriod(): void;
        get restartAttemptPeriodInput(): number | undefined;
    }
    class RestartPolicyPropertyList extends cdktn.ComplexList {
        internalValue?: RestartPolicyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RestartPolicyPropertyOutputReference;
    }
    interface SecretProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#name AwsDaemonTaskDefinition#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#value_from AwsDaemonTaskDefinition#value_from}
        */
        readonly valueFrom: string;
    }
    class SecretPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SecretProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SecretProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _valueFrom?;
        get valueFrom(): string;
        set valueFrom(value: string);
        get valueFromInput(): string | undefined;
    }
    class SecretPropertyList extends cdktn.ComplexList {
        internalValue?: SecretProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SecretPropertyOutputReference;
    }
    interface SystemControlProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#namespace AwsDaemonTaskDefinition#namespace}
        */
        readonly namespace?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#value AwsDaemonTaskDefinition#value}
        */
        readonly value?: string;
    }
    class SystemControlPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SystemControlProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SystemControlProperty | cdktn.IResolvable | undefined);
        private _namespace?;
        get namespace(): string;
        set namespace(value: string);
        resetNamespace(): void;
        get namespaceInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
    class SystemControlPropertyList extends cdktn.ComplexList {
        internalValue?: SystemControlProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SystemControlPropertyOutputReference;
    }
    interface UlimitProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#hard_limit AwsDaemonTaskDefinition#hard_limit}
        */
        readonly hardLimit: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#name AwsDaemonTaskDefinition#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#soft_limit AwsDaemonTaskDefinition#soft_limit}
        */
        readonly softLimit: number;
    }
    class UlimitPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UlimitProperty | cdktn.IResolvable | undefined;
        set internalValue(value: UlimitProperty | cdktn.IResolvable | undefined);
        private _hardLimit?;
        get hardLimit(): number;
        set hardLimit(value: number);
        get hardLimitInput(): number | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _softLimit?;
        get softLimit(): number;
        set softLimit(value: number);
        get softLimitInput(): number | undefined;
    }
    class UlimitPropertyList extends cdktn.ComplexList {
        internalValue?: UlimitProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UlimitPropertyOutputReference;
    }
    interface ContainerDefinitionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#command AwsDaemonTaskDefinition#command}
        */
        readonly command?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#cpu AwsDaemonTaskDefinition#cpu}
        */
        readonly cpu?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#entry_point AwsDaemonTaskDefinition#entry_point}
        */
        readonly entryPoint?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#essential AwsDaemonTaskDefinition#essential}
        */
        readonly essential?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#image AwsDaemonTaskDefinition#image}
        */
        readonly image: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#interactive AwsDaemonTaskDefinition#interactive}
        */
        readonly interactive?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#memory AwsDaemonTaskDefinition#memory}
        */
        readonly memory?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#memory_reservation AwsDaemonTaskDefinition#memory_reservation}
        */
        readonly memoryReservation?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#name AwsDaemonTaskDefinition#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#privileged AwsDaemonTaskDefinition#privileged}
        */
        readonly privileged?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#pseudo_terminal AwsDaemonTaskDefinition#pseudo_terminal}
        */
        readonly pseudoTerminal?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#readonly_root_filesystem AwsDaemonTaskDefinition#readonly_root_filesystem}
        */
        readonly readonlyRootFilesystem?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#start_timeout AwsDaemonTaskDefinition#start_timeout}
        */
        readonly startTimeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#stop_timeout AwsDaemonTaskDefinition#stop_timeout}
        */
        readonly stopTimeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#user AwsDaemonTaskDefinition#user}
        */
        readonly user?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#working_directory AwsDaemonTaskDefinition#working_directory}
        */
        readonly workingDirectory?: string;
        /**
        * depends_on block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#depends_on AwsDaemonTaskDefinition#depends_on}
        */
        readonly dependsOn?: DependsOnProperty[] | cdktn.IResolvable;
        /**
        * environment block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#environment AwsDaemonTaskDefinition#environment}
        */
        readonly environment?: EnvironmentProperty[] | cdktn.IResolvable;
        /**
        * environment_file block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#environment_file AwsDaemonTaskDefinition#environment_file}
        */
        readonly environmentFile?: EnvironmentFileProperty[] | cdktn.IResolvable;
        /**
        * firelens_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#firelens_configuration AwsDaemonTaskDefinition#firelens_configuration}
        */
        readonly firelensConfiguration?: FirelensConfigurationProperty[] | cdktn.IResolvable;
        /**
        * health_check block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#health_check AwsDaemonTaskDefinition#health_check}
        */
        readonly healthCheck?: HealthCheckProperty[] | cdktn.IResolvable;
        /**
        * linux_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#linux_parameters AwsDaemonTaskDefinition#linux_parameters}
        */
        readonly linuxParameters?: LinuxParametersProperty[] | cdktn.IResolvable;
        /**
        * log_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#log_configuration AwsDaemonTaskDefinition#log_configuration}
        */
        readonly logConfiguration?: LogConfigurationProperty[] | cdktn.IResolvable;
        /**
        * mount_point block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#mount_point AwsDaemonTaskDefinition#mount_point}
        */
        readonly mountPoint?: MountPointProperty[] | cdktn.IResolvable;
        /**
        * repository_credentials block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#repository_credentials AwsDaemonTaskDefinition#repository_credentials}
        */
        readonly repositoryCredentials?: RepositoryCredentialsProperty[] | cdktn.IResolvable;
        /**
        * restart_policy block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#restart_policy AwsDaemonTaskDefinition#restart_policy}
        */
        readonly restartPolicy?: RestartPolicyProperty[] | cdktn.IResolvable;
        /**
        * secret block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#secret AwsDaemonTaskDefinition#secret}
        */
        readonly secret?: SecretProperty[] | cdktn.IResolvable;
        /**
        * system_control block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#system_control AwsDaemonTaskDefinition#system_control}
        */
        readonly systemControl?: SystemControlProperty[] | cdktn.IResolvable;
        /**
        * ulimit block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#ulimit AwsDaemonTaskDefinition#ulimit}
        */
        readonly ulimit?: UlimitProperty[] | cdktn.IResolvable;
    }
    class ContainerDefinitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ContainerDefinitionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ContainerDefinitionProperty | cdktn.IResolvable | undefined);
        private _command?;
        get command(): string[];
        set command(value: string[]);
        resetCommand(): void;
        get commandInput(): string[] | undefined;
        private _cpu?;
        get cpu(): number;
        set cpu(value: number);
        resetCpu(): void;
        get cpuInput(): number | undefined;
        private _entryPoint?;
        get entryPoint(): string[];
        set entryPoint(value: string[]);
        resetEntryPoint(): void;
        get entryPointInput(): string[] | undefined;
        private _essential?;
        get essential(): boolean | cdktn.IResolvable;
        set essential(value: boolean | cdktn.IResolvable);
        resetEssential(): void;
        get essentialInput(): boolean | cdktn.IResolvable | undefined;
        private _image?;
        get image(): string;
        set image(value: string);
        get imageInput(): string | undefined;
        private _interactive?;
        get interactive(): boolean | cdktn.IResolvable;
        set interactive(value: boolean | cdktn.IResolvable);
        resetInteractive(): void;
        get interactiveInput(): boolean | cdktn.IResolvable | undefined;
        private _memory?;
        get memory(): number;
        set memory(value: number);
        resetMemory(): void;
        get memoryInput(): number | undefined;
        private _memoryReservation?;
        get memoryReservation(): number;
        set memoryReservation(value: number);
        resetMemoryReservation(): void;
        get memoryReservationInput(): number | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _privileged?;
        get privileged(): boolean | cdktn.IResolvable;
        set privileged(value: boolean | cdktn.IResolvable);
        resetPrivileged(): void;
        get privilegedInput(): boolean | cdktn.IResolvable | undefined;
        private _pseudoTerminal?;
        get pseudoTerminal(): boolean | cdktn.IResolvable;
        set pseudoTerminal(value: boolean | cdktn.IResolvable);
        resetPseudoTerminal(): void;
        get pseudoTerminalInput(): boolean | cdktn.IResolvable | undefined;
        private _readonlyRootFilesystem?;
        get readonlyRootFilesystem(): boolean | cdktn.IResolvable;
        set readonlyRootFilesystem(value: boolean | cdktn.IResolvable);
        resetReadonlyRootFilesystem(): void;
        get readonlyRootFilesystemInput(): boolean | cdktn.IResolvable | undefined;
        private _startTimeout?;
        get startTimeout(): number;
        set startTimeout(value: number);
        resetStartTimeout(): void;
        get startTimeoutInput(): number | undefined;
        private _stopTimeout?;
        get stopTimeout(): number;
        set stopTimeout(value: number);
        resetStopTimeout(): void;
        get stopTimeoutInput(): number | undefined;
        private _user?;
        get user(): string;
        set user(value: string);
        resetUser(): void;
        get userInput(): string | undefined;
        private _workingDirectory?;
        get workingDirectory(): string;
        set workingDirectory(value: string);
        resetWorkingDirectory(): void;
        get workingDirectoryInput(): string | undefined;
        private _dependsOn;
        get dependsOn(): DependsOnPropertyList;
        putDependsOn(value: DependsOnProperty[] | cdktn.IResolvable): void;
        resetDependsOn(): void;
        get dependsOnInput(): cdktn.IResolvable | DependsOnProperty[] | undefined;
        private _environment;
        get environment(): EnvironmentPropertyList;
        putEnvironment(value: EnvironmentProperty[] | cdktn.IResolvable): void;
        resetEnvironment(): void;
        get environmentInput(): cdktn.IResolvable | EnvironmentProperty[] | undefined;
        private _environmentFile;
        get environmentFile(): EnvironmentFilePropertyList;
        putEnvironmentFile(value: EnvironmentFileProperty[] | cdktn.IResolvable): void;
        resetEnvironmentFile(): void;
        get environmentFileInput(): cdktn.IResolvable | EnvironmentFileProperty[] | undefined;
        private _firelensConfiguration;
        get firelensConfiguration(): FirelensConfigurationPropertyList;
        putFirelensConfiguration(value: FirelensConfigurationProperty[] | cdktn.IResolvable): void;
        resetFirelensConfiguration(): void;
        get firelensConfigurationInput(): cdktn.IResolvable | FirelensConfigurationProperty[] | undefined;
        private _healthCheck;
        get healthCheck(): HealthCheckPropertyList;
        putHealthCheck(value: HealthCheckProperty[] | cdktn.IResolvable): void;
        resetHealthCheck(): void;
        get healthCheckInput(): cdktn.IResolvable | HealthCheckProperty[] | undefined;
        private _linuxParameters;
        get linuxParameters(): LinuxParametersPropertyList;
        putLinuxParameters(value: LinuxParametersProperty[] | cdktn.IResolvable): void;
        resetLinuxParameters(): void;
        get linuxParametersInput(): cdktn.IResolvable | LinuxParametersProperty[] | undefined;
        private _logConfiguration;
        get logConfiguration(): LogConfigurationPropertyList;
        putLogConfiguration(value: LogConfigurationProperty[] | cdktn.IResolvable): void;
        resetLogConfiguration(): void;
        get logConfigurationInput(): cdktn.IResolvable | LogConfigurationProperty[] | undefined;
        private _mountPoint;
        get mountPoint(): MountPointPropertyList;
        putMountPoint(value: MountPointProperty[] | cdktn.IResolvable): void;
        resetMountPoint(): void;
        get mountPointInput(): cdktn.IResolvable | MountPointProperty[] | undefined;
        private _repositoryCredentials;
        get repositoryCredentials(): RepositoryCredentialsPropertyList;
        putRepositoryCredentials(value: RepositoryCredentialsProperty[] | cdktn.IResolvable): void;
        resetRepositoryCredentials(): void;
        get repositoryCredentialsInput(): cdktn.IResolvable | RepositoryCredentialsProperty[] | undefined;
        private _restartPolicy;
        get restartPolicy(): RestartPolicyPropertyList;
        putRestartPolicy(value: RestartPolicyProperty[] | cdktn.IResolvable): void;
        resetRestartPolicy(): void;
        get restartPolicyInput(): cdktn.IResolvable | RestartPolicyProperty[] | undefined;
        private _secret;
        get secret(): SecretPropertyList;
        putSecret(value: SecretProperty[] | cdktn.IResolvable): void;
        resetSecret(): void;
        get secretInput(): cdktn.IResolvable | SecretProperty[] | undefined;
        private _systemControl;
        get systemControl(): SystemControlPropertyList;
        putSystemControl(value: SystemControlProperty[] | cdktn.IResolvable): void;
        resetSystemControl(): void;
        get systemControlInput(): cdktn.IResolvable | SystemControlProperty[] | undefined;
        private _ulimit;
        get ulimit(): UlimitPropertyList;
        putUlimit(value: UlimitProperty[] | cdktn.IResolvable): void;
        resetUlimit(): void;
        get ulimitInput(): cdktn.IResolvable | UlimitProperty[] | undefined;
    }
    class ContainerDefinitionPropertyList extends cdktn.ComplexList {
        internalValue?: ContainerDefinitionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ContainerDefinitionPropertyOutputReference;
    }
    interface HostProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#source_path AwsDaemonTaskDefinition#source_path}
        */
        readonly sourcePath?: string;
    }
    class HostPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HostProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HostProperty | cdktn.IResolvable | undefined);
        private _sourcePath?;
        get sourcePath(): string;
        set sourcePath(value: string);
        resetSourcePath(): void;
        get sourcePathInput(): string | undefined;
    }
    class HostPropertyList extends cdktn.ComplexList {
        internalValue?: HostProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HostPropertyOutputReference;
    }
    interface VolumeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#name AwsDaemonTaskDefinition#name}
        */
        readonly name: string;
        /**
        * host block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_daemon_task_definition#host AwsDaemonTaskDefinition#host}
        */
        readonly host?: HostProperty[] | cdktn.IResolvable;
    }
    class VolumePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VolumeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VolumeProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _host;
        get host(): HostPropertyList;
        putHost(value: HostProperty[] | cdktn.IResolvable): void;
        resetHost(): void;
        get hostInput(): cdktn.IResolvable | HostProperty[] | undefined;
    }
    class VolumePropertyList extends cdktn.ComplexList {
        internalValue?: VolumeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VolumePropertyOutputReference;
    }
}
