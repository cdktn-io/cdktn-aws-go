import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsTaskDefinitionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#container_definitions AwsTaskDefinition#container_definitions}
    */
    readonly containerDefinitions: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#cpu AwsTaskDefinition#cpu}
    */
    readonly cpu?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#enable_fault_injection AwsTaskDefinition#enable_fault_injection}
    */
    readonly enableFaultInjection?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#execution_role_arn AwsTaskDefinition#execution_role_arn}
    */
    readonly executionRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#family AwsTaskDefinition#family}
    */
    readonly family: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#id AwsTaskDefinition#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#ipc_mode AwsTaskDefinition#ipc_mode}
    */
    readonly ipcMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#memory AwsTaskDefinition#memory}
    */
    readonly memory?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#network_mode AwsTaskDefinition#network_mode}
    */
    readonly networkMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#pid_mode AwsTaskDefinition#pid_mode}
    */
    readonly pidMode?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#region AwsTaskDefinition#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#requires_compatibilities AwsTaskDefinition#requires_compatibilities}
    */
    readonly requiresCompatibilities?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#skip_destroy AwsTaskDefinition#skip_destroy}
    */
    readonly skipDestroy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#tags AwsTaskDefinition#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#tags_all AwsTaskDefinition#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#task_role_arn AwsTaskDefinition#task_role_arn}
    */
    readonly taskRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#track_latest AwsTaskDefinition#track_latest}
    */
    readonly trackLatest?: boolean | cdktn.IResolvable;
    /**
    * ephemeral_storage block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#ephemeral_storage AwsTaskDefinition#ephemeral_storage}
    */
    readonly ephemeralStorage?: AwsTaskDefinition.EphemeralStorageProperty;
    /**
    * placement_constraints block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#placement_constraints AwsTaskDefinition#placement_constraints}
    */
    readonly placementConstraints?: AwsTaskDefinition.PlacementConstraintsProperty[] | cdktn.IResolvable;
    /**
    * proxy_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#proxy_configuration AwsTaskDefinition#proxy_configuration}
    */
    readonly proxyConfiguration?: AwsTaskDefinition.ProxyConfigurationProperty;
    /**
    * runtime_platform block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#runtime_platform AwsTaskDefinition#runtime_platform}
    */
    readonly runtimePlatform?: AwsTaskDefinition.RuntimePlatformProperty;
    /**
    * volume block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#volume AwsTaskDefinition#volume}
    */
    readonly volume?: AwsTaskDefinition.VolumeProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition aws_ecs_task_definition}
*/
export declare class AwsTaskDefinition extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ecs_task_definition";
    /**
    * Generates CDKTN code for importing a AwsTaskDefinition resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsTaskDefinition to import
    * @param importFromId The id of the existing AwsTaskDefinition that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsTaskDefinition to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition aws_ecs_task_definition} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsTaskDefinitionConfig
    */
    constructor(scope: Construct, id: string, config: AwsTaskDefinitionConfig);
    get arn(): string;
    get arnWithoutRevision(): string;
    private _containerDefinitions?;
    get containerDefinitions(): string;
    set containerDefinitions(value: string);
    get containerDefinitionsInput(): string | undefined;
    private _cpu?;
    get cpu(): string;
    set cpu(value: string);
    resetCpu(): void;
    get cpuInput(): string | undefined;
    private _enableFaultInjection?;
    get enableFaultInjection(): boolean | cdktn.IResolvable;
    set enableFaultInjection(value: boolean | cdktn.IResolvable);
    resetEnableFaultInjection(): void;
    get enableFaultInjectionInput(): boolean | cdktn.IResolvable | undefined;
    private _executionRoleArn?;
    get executionRoleArn(): string;
    set executionRoleArn(value: string);
    resetExecutionRoleArn(): void;
    get executionRoleArnInput(): string | undefined;
    private _family?;
    get family(): string;
    set family(value: string);
    get familyInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipcMode?;
    get ipcMode(): string;
    set ipcMode(value: string);
    resetIpcMode(): void;
    get ipcModeInput(): string | undefined;
    private _memory?;
    get memory(): string;
    set memory(value: string);
    resetMemory(): void;
    get memoryInput(): string | undefined;
    private _networkMode?;
    get networkMode(): string;
    set networkMode(value: string);
    resetNetworkMode(): void;
    get networkModeInput(): string | undefined;
    private _pidMode?;
    get pidMode(): string;
    set pidMode(value: string);
    resetPidMode(): void;
    get pidModeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _requiresCompatibilities?;
    get requiresCompatibilities(): string[];
    set requiresCompatibilities(value: string[]);
    resetRequiresCompatibilities(): void;
    get requiresCompatibilitiesInput(): string[] | undefined;
    get revision(): number;
    private _skipDestroy?;
    get skipDestroy(): boolean | cdktn.IResolvable;
    set skipDestroy(value: boolean | cdktn.IResolvable);
    resetSkipDestroy(): void;
    get skipDestroyInput(): boolean | cdktn.IResolvable | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _taskRoleArn?;
    get taskRoleArn(): string;
    set taskRoleArn(value: string);
    resetTaskRoleArn(): void;
    get taskRoleArnInput(): string | undefined;
    private _trackLatest?;
    get trackLatest(): boolean | cdktn.IResolvable;
    set trackLatest(value: boolean | cdktn.IResolvable);
    resetTrackLatest(): void;
    get trackLatestInput(): boolean | cdktn.IResolvable | undefined;
    private _ephemeralStorage;
    get ephemeralStorage(): AwsTaskDefinition.EphemeralStoragePropertyOutputReference;
    putEphemeralStorage(value: AwsTaskDefinition.EphemeralStorageProperty): void;
    resetEphemeralStorage(): void;
    get ephemeralStorageInput(): AwsTaskDefinition.EphemeralStorageProperty | undefined;
    private _placementConstraints;
    get placementConstraints(): AwsTaskDefinition.PlacementConstraintsPropertyList;
    putPlacementConstraints(value: AwsTaskDefinition.PlacementConstraintsProperty[] | cdktn.IResolvable): void;
    resetPlacementConstraints(): void;
    get placementConstraintsInput(): cdktn.IResolvable | AwsTaskDefinition.PlacementConstraintsProperty[] | undefined;
    private _proxyConfiguration;
    get proxyConfiguration(): AwsTaskDefinition.ProxyConfigurationPropertyOutputReference;
    putProxyConfiguration(value: AwsTaskDefinition.ProxyConfigurationProperty): void;
    resetProxyConfiguration(): void;
    get proxyConfigurationInput(): AwsTaskDefinition.ProxyConfigurationProperty | undefined;
    private _runtimePlatform;
    get runtimePlatform(): AwsTaskDefinition.RuntimePlatformPropertyOutputReference;
    putRuntimePlatform(value: AwsTaskDefinition.RuntimePlatformProperty): void;
    resetRuntimePlatform(): void;
    get runtimePlatformInput(): AwsTaskDefinition.RuntimePlatformProperty | undefined;
    private _volume;
    get volume(): AwsTaskDefinition.VolumePropertyList;
    putVolume(value: AwsTaskDefinition.VolumeProperty[] | cdktn.IResolvable): void;
    resetVolume(): void;
    get volumeInput(): cdktn.IResolvable | AwsTaskDefinition.VolumeProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsTaskDefinitionEphemeralStoragePropertyToTerraform(struct?: AwsTaskDefinition.EphemeralStoragePropertyOutputReference | AwsTaskDefinition.EphemeralStorageProperty): any;
export declare function awsTaskDefinitionEphemeralStoragePropertyToHclTerraform(struct?: AwsTaskDefinition.EphemeralStoragePropertyOutputReference | AwsTaskDefinition.EphemeralStorageProperty): any;
export declare function awsTaskDefinitionPlacementConstraintsPropertyToTerraform(struct?: AwsTaskDefinition.PlacementConstraintsProperty | cdktn.IResolvable): any;
export declare function awsTaskDefinitionPlacementConstraintsPropertyToHclTerraform(struct?: AwsTaskDefinition.PlacementConstraintsProperty | cdktn.IResolvable): any;
export declare function awsTaskDefinitionProxyConfigurationPropertyToTerraform(struct?: AwsTaskDefinition.ProxyConfigurationPropertyOutputReference | AwsTaskDefinition.ProxyConfigurationProperty): any;
export declare function awsTaskDefinitionProxyConfigurationPropertyToHclTerraform(struct?: AwsTaskDefinition.ProxyConfigurationPropertyOutputReference | AwsTaskDefinition.ProxyConfigurationProperty): any;
export declare function awsTaskDefinitionRuntimePlatformPropertyToTerraform(struct?: AwsTaskDefinition.RuntimePlatformPropertyOutputReference | AwsTaskDefinition.RuntimePlatformProperty): any;
export declare function awsTaskDefinitionRuntimePlatformPropertyToHclTerraform(struct?: AwsTaskDefinition.RuntimePlatformPropertyOutputReference | AwsTaskDefinition.RuntimePlatformProperty): any;
export declare function awsTaskDefinitionDockerVolumeConfigurationPropertyToTerraform(struct?: AwsTaskDefinition.DockerVolumeConfigurationPropertyOutputReference | AwsTaskDefinition.DockerVolumeConfigurationProperty): any;
export declare function awsTaskDefinitionDockerVolumeConfigurationPropertyToHclTerraform(struct?: AwsTaskDefinition.DockerVolumeConfigurationPropertyOutputReference | AwsTaskDefinition.DockerVolumeConfigurationProperty): any;
export declare function awsTaskDefinitionVolumeEfsVolumeConfigurationAuthorizationConfigPropertyToTerraform(struct?: AwsTaskDefinition.VolumeEfsVolumeConfigurationAuthorizationConfigPropertyOutputReference | AwsTaskDefinition.VolumeEfsVolumeConfigurationAuthorizationConfigProperty): any;
export declare function awsTaskDefinitionVolumeEfsVolumeConfigurationAuthorizationConfigPropertyToHclTerraform(struct?: AwsTaskDefinition.VolumeEfsVolumeConfigurationAuthorizationConfigPropertyOutputReference | AwsTaskDefinition.VolumeEfsVolumeConfigurationAuthorizationConfigProperty): any;
export declare function awsTaskDefinitionEfsVolumeConfigurationPropertyToTerraform(struct?: AwsTaskDefinition.EfsVolumeConfigurationPropertyOutputReference | AwsTaskDefinition.EfsVolumeConfigurationProperty): any;
export declare function awsTaskDefinitionEfsVolumeConfigurationPropertyToHclTerraform(struct?: AwsTaskDefinition.EfsVolumeConfigurationPropertyOutputReference | AwsTaskDefinition.EfsVolumeConfigurationProperty): any;
export declare function awsTaskDefinitionVolumeFsxWindowsFileServerVolumeConfigurationAuthorizationConfigPropertyToTerraform(struct?: AwsTaskDefinition.VolumeFsxWindowsFileServerVolumeConfigurationAuthorizationConfigPropertyOutputReference | AwsTaskDefinition.VolumeFsxWindowsFileServerVolumeConfigurationAuthorizationConfigProperty): any;
export declare function awsTaskDefinitionVolumeFsxWindowsFileServerVolumeConfigurationAuthorizationConfigPropertyToHclTerraform(struct?: AwsTaskDefinition.VolumeFsxWindowsFileServerVolumeConfigurationAuthorizationConfigPropertyOutputReference | AwsTaskDefinition.VolumeFsxWindowsFileServerVolumeConfigurationAuthorizationConfigProperty): any;
export declare function awsTaskDefinitionFsxWindowsFileServerVolumeConfigurationPropertyToTerraform(struct?: AwsTaskDefinition.FsxWindowsFileServerVolumeConfigurationPropertyOutputReference | AwsTaskDefinition.FsxWindowsFileServerVolumeConfigurationProperty): any;
export declare function awsTaskDefinitionFsxWindowsFileServerVolumeConfigurationPropertyToHclTerraform(struct?: AwsTaskDefinition.FsxWindowsFileServerVolumeConfigurationPropertyOutputReference | AwsTaskDefinition.FsxWindowsFileServerVolumeConfigurationProperty): any;
export declare function awsTaskDefinitionS3filesVolumeConfigurationPropertyToTerraform(struct?: AwsTaskDefinition.S3filesVolumeConfigurationPropertyOutputReference | AwsTaskDefinition.S3filesVolumeConfigurationProperty): any;
export declare function awsTaskDefinitionS3filesVolumeConfigurationPropertyToHclTerraform(struct?: AwsTaskDefinition.S3filesVolumeConfigurationPropertyOutputReference | AwsTaskDefinition.S3filesVolumeConfigurationProperty): any;
export declare function awsTaskDefinitionVolumePropertyToTerraform(struct?: AwsTaskDefinition.VolumeProperty | cdktn.IResolvable): any;
export declare function awsTaskDefinitionVolumePropertyToHclTerraform(struct?: AwsTaskDefinition.VolumeProperty | cdktn.IResolvable): any;
export declare namespace AwsTaskDefinition {
    interface EphemeralStorageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#size_in_gib AwsTaskDefinition#size_in_gib}
        */
        readonly sizeInGib: number;
    }
    class EphemeralStoragePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EphemeralStorageProperty | undefined;
        set internalValue(value: EphemeralStorageProperty | undefined);
        private _sizeInGib?;
        get sizeInGib(): number;
        set sizeInGib(value: number);
        get sizeInGibInput(): number | undefined;
    }
    interface PlacementConstraintsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#expression AwsTaskDefinition#expression}
        */
        readonly expression?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#type AwsTaskDefinition#type}
        */
        readonly type: string;
    }
    class PlacementConstraintsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PlacementConstraintsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PlacementConstraintsProperty | cdktn.IResolvable | undefined);
        private _expression?;
        get expression(): string;
        set expression(value: string);
        resetExpression(): void;
        get expressionInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class PlacementConstraintsPropertyList extends cdktn.ComplexList {
        internalValue?: PlacementConstraintsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PlacementConstraintsPropertyOutputReference;
    }
    interface ProxyConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#container_name AwsTaskDefinition#container_name}
        */
        readonly containerName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#properties AwsTaskDefinition#properties}
        */
        readonly properties?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#type AwsTaskDefinition#type}
        */
        readonly type?: string;
    }
    class ProxyConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ProxyConfigurationProperty | undefined;
        set internalValue(value: ProxyConfigurationProperty | undefined);
        private _containerName?;
        get containerName(): string;
        set containerName(value: string);
        get containerNameInput(): string | undefined;
        private _properties?;
        get properties(): {
            [key: string]: string;
        };
        set properties(value: {
            [key: string]: string;
        });
        resetProperties(): void;
        get propertiesInput(): {
            [key: string]: string;
        } | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
    }
    interface RuntimePlatformProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#cpu_architecture AwsTaskDefinition#cpu_architecture}
        */
        readonly cpuArchitecture?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#operating_system_family AwsTaskDefinition#operating_system_family}
        */
        readonly operatingSystemFamily?: string;
    }
    class RuntimePlatformPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuntimePlatformProperty | undefined;
        set internalValue(value: RuntimePlatformProperty | undefined);
        private _cpuArchitecture?;
        get cpuArchitecture(): string;
        set cpuArchitecture(value: string);
        resetCpuArchitecture(): void;
        get cpuArchitectureInput(): string | undefined;
        private _operatingSystemFamily?;
        get operatingSystemFamily(): string;
        set operatingSystemFamily(value: string);
        resetOperatingSystemFamily(): void;
        get operatingSystemFamilyInput(): string | undefined;
    }
    interface DockerVolumeConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#autoprovision AwsTaskDefinition#autoprovision}
        */
        readonly autoprovision?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#driver AwsTaskDefinition#driver}
        */
        readonly driver?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#driver_opts AwsTaskDefinition#driver_opts}
        */
        readonly driverOpts?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#labels AwsTaskDefinition#labels}
        */
        readonly labels?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#scope AwsTaskDefinition#scope}
        */
        readonly scope?: string;
    }
    class DockerVolumeConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DockerVolumeConfigurationProperty | undefined;
        set internalValue(value: DockerVolumeConfigurationProperty | undefined);
        private _autoprovision?;
        get autoprovision(): boolean | cdktn.IResolvable;
        set autoprovision(value: boolean | cdktn.IResolvable);
        resetAutoprovision(): void;
        get autoprovisionInput(): boolean | cdktn.IResolvable | undefined;
        private _driver?;
        get driver(): string;
        set driver(value: string);
        resetDriver(): void;
        get driverInput(): string | undefined;
        private _driverOpts?;
        get driverOpts(): {
            [key: string]: string;
        };
        set driverOpts(value: {
            [key: string]: string;
        });
        resetDriverOpts(): void;
        get driverOptsInput(): {
            [key: string]: string;
        } | undefined;
        private _labels?;
        get labels(): {
            [key: string]: string;
        };
        set labels(value: {
            [key: string]: string;
        });
        resetLabels(): void;
        get labelsInput(): {
            [key: string]: string;
        } | undefined;
        private _scope?;
        get scope(): string;
        set scope(value: string);
        resetScope(): void;
        get scopeInput(): string | undefined;
    }
    interface VolumeEfsVolumeConfigurationAuthorizationConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#access_point_id AwsTaskDefinition#access_point_id}
        */
        readonly accessPointId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#iam AwsTaskDefinition#iam}
        */
        readonly iam?: string;
    }
    class VolumeEfsVolumeConfigurationAuthorizationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VolumeEfsVolumeConfigurationAuthorizationConfigProperty | undefined;
        set internalValue(value: VolumeEfsVolumeConfigurationAuthorizationConfigProperty | undefined);
        private _accessPointId?;
        get accessPointId(): string;
        set accessPointId(value: string);
        resetAccessPointId(): void;
        get accessPointIdInput(): string | undefined;
        private _iam?;
        get iam(): string;
        set iam(value: string);
        resetIam(): void;
        get iamInput(): string | undefined;
    }
    interface EfsVolumeConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#file_system_id AwsTaskDefinition#file_system_id}
        */
        readonly fileSystemId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#root_directory AwsTaskDefinition#root_directory}
        */
        readonly rootDirectory?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#transit_encryption AwsTaskDefinition#transit_encryption}
        */
        readonly transitEncryption?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#transit_encryption_port AwsTaskDefinition#transit_encryption_port}
        */
        readonly transitEncryptionPort?: number;
        /**
        * authorization_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#authorization_config AwsTaskDefinition#authorization_config}
        */
        readonly authorizationConfig?: VolumeEfsVolumeConfigurationAuthorizationConfigProperty;
    }
    class EfsVolumeConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EfsVolumeConfigurationProperty | undefined;
        set internalValue(value: EfsVolumeConfigurationProperty | undefined);
        private _fileSystemId?;
        get fileSystemId(): string;
        set fileSystemId(value: string);
        get fileSystemIdInput(): string | undefined;
        private _rootDirectory?;
        get rootDirectory(): string;
        set rootDirectory(value: string);
        resetRootDirectory(): void;
        get rootDirectoryInput(): string | undefined;
        private _transitEncryption?;
        get transitEncryption(): string;
        set transitEncryption(value: string);
        resetTransitEncryption(): void;
        get transitEncryptionInput(): string | undefined;
        private _transitEncryptionPort?;
        get transitEncryptionPort(): number;
        set transitEncryptionPort(value: number);
        resetTransitEncryptionPort(): void;
        get transitEncryptionPortInput(): number | undefined;
        private _authorizationConfig;
        get authorizationConfig(): VolumeEfsVolumeConfigurationAuthorizationConfigPropertyOutputReference;
        putAuthorizationConfig(value: VolumeEfsVolumeConfigurationAuthorizationConfigProperty): void;
        resetAuthorizationConfig(): void;
        get authorizationConfigInput(): VolumeEfsVolumeConfigurationAuthorizationConfigProperty | undefined;
    }
    interface VolumeFsxWindowsFileServerVolumeConfigurationAuthorizationConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#credentials_parameter AwsTaskDefinition#credentials_parameter}
        */
        readonly credentialsParameter: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#domain AwsTaskDefinition#domain}
        */
        readonly domain: string;
    }
    class VolumeFsxWindowsFileServerVolumeConfigurationAuthorizationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VolumeFsxWindowsFileServerVolumeConfigurationAuthorizationConfigProperty | undefined;
        set internalValue(value: VolumeFsxWindowsFileServerVolumeConfigurationAuthorizationConfigProperty | undefined);
        private _credentialsParameter?;
        get credentialsParameter(): string;
        set credentialsParameter(value: string);
        get credentialsParameterInput(): string | undefined;
        private _domain?;
        get domain(): string;
        set domain(value: string);
        get domainInput(): string | undefined;
    }
    interface FsxWindowsFileServerVolumeConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#file_system_id AwsTaskDefinition#file_system_id}
        */
        readonly fileSystemId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#root_directory AwsTaskDefinition#root_directory}
        */
        readonly rootDirectory: string;
        /**
        * authorization_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#authorization_config AwsTaskDefinition#authorization_config}
        */
        readonly authorizationConfig: VolumeFsxWindowsFileServerVolumeConfigurationAuthorizationConfigProperty;
    }
    class FsxWindowsFileServerVolumeConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FsxWindowsFileServerVolumeConfigurationProperty | undefined;
        set internalValue(value: FsxWindowsFileServerVolumeConfigurationProperty | undefined);
        private _fileSystemId?;
        get fileSystemId(): string;
        set fileSystemId(value: string);
        get fileSystemIdInput(): string | undefined;
        private _rootDirectory?;
        get rootDirectory(): string;
        set rootDirectory(value: string);
        get rootDirectoryInput(): string | undefined;
        private _authorizationConfig;
        get authorizationConfig(): VolumeFsxWindowsFileServerVolumeConfigurationAuthorizationConfigPropertyOutputReference;
        putAuthorizationConfig(value: VolumeFsxWindowsFileServerVolumeConfigurationAuthorizationConfigProperty): void;
        get authorizationConfigInput(): VolumeFsxWindowsFileServerVolumeConfigurationAuthorizationConfigProperty | undefined;
    }
    interface S3filesVolumeConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#access_point_arn AwsTaskDefinition#access_point_arn}
        */
        readonly accessPointArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#file_system_arn AwsTaskDefinition#file_system_arn}
        */
        readonly fileSystemArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#root_directory AwsTaskDefinition#root_directory}
        */
        readonly rootDirectory?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#transit_encryption_port AwsTaskDefinition#transit_encryption_port}
        */
        readonly transitEncryptionPort?: number;
    }
    class S3filesVolumeConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3filesVolumeConfigurationProperty | undefined;
        set internalValue(value: S3filesVolumeConfigurationProperty | undefined);
        private _accessPointArn?;
        get accessPointArn(): string;
        set accessPointArn(value: string);
        resetAccessPointArn(): void;
        get accessPointArnInput(): string | undefined;
        private _fileSystemArn?;
        get fileSystemArn(): string;
        set fileSystemArn(value: string);
        get fileSystemArnInput(): string | undefined;
        private _rootDirectory?;
        get rootDirectory(): string;
        set rootDirectory(value: string);
        resetRootDirectory(): void;
        get rootDirectoryInput(): string | undefined;
        private _transitEncryptionPort?;
        get transitEncryptionPort(): number;
        set transitEncryptionPort(value: number);
        resetTransitEncryptionPort(): void;
        get transitEncryptionPortInput(): number | undefined;
    }
    interface VolumeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#configure_at_launch AwsTaskDefinition#configure_at_launch}
        */
        readonly configureAtLaunch?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#host_path AwsTaskDefinition#host_path}
        */
        readonly hostPath?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#name AwsTaskDefinition#name}
        */
        readonly name: string;
        /**
        * docker_volume_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#docker_volume_configuration AwsTaskDefinition#docker_volume_configuration}
        */
        readonly dockerVolumeConfiguration?: DockerVolumeConfigurationProperty;
        /**
        * efs_volume_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#efs_volume_configuration AwsTaskDefinition#efs_volume_configuration}
        */
        readonly efsVolumeConfiguration?: EfsVolumeConfigurationProperty;
        /**
        * fsx_windows_file_server_volume_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#fsx_windows_file_server_volume_configuration AwsTaskDefinition#fsx_windows_file_server_volume_configuration}
        */
        readonly fsxWindowsFileServerVolumeConfiguration?: FsxWindowsFileServerVolumeConfigurationProperty;
        /**
        * s3files_volume_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_task_definition#s3files_volume_configuration AwsTaskDefinition#s3files_volume_configuration}
        */
        readonly s3FilesVolumeConfiguration?: S3filesVolumeConfigurationProperty;
    }
    class VolumePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VolumeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VolumeProperty | cdktn.IResolvable | undefined);
        private _configureAtLaunch?;
        get configureAtLaunch(): boolean | cdktn.IResolvable;
        set configureAtLaunch(value: boolean | cdktn.IResolvable);
        resetConfigureAtLaunch(): void;
        get configureAtLaunchInput(): boolean | cdktn.IResolvable | undefined;
        private _hostPath?;
        get hostPath(): string;
        set hostPath(value: string);
        resetHostPath(): void;
        get hostPathInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _dockerVolumeConfiguration;
        get dockerVolumeConfiguration(): DockerVolumeConfigurationPropertyOutputReference;
        putDockerVolumeConfiguration(value: DockerVolumeConfigurationProperty): void;
        resetDockerVolumeConfiguration(): void;
        get dockerVolumeConfigurationInput(): DockerVolumeConfigurationProperty | undefined;
        private _efsVolumeConfiguration;
        get efsVolumeConfiguration(): EfsVolumeConfigurationPropertyOutputReference;
        putEfsVolumeConfiguration(value: EfsVolumeConfigurationProperty): void;
        resetEfsVolumeConfiguration(): void;
        get efsVolumeConfigurationInput(): EfsVolumeConfigurationProperty | undefined;
        private _fsxWindowsFileServerVolumeConfiguration;
        get fsxWindowsFileServerVolumeConfiguration(): FsxWindowsFileServerVolumeConfigurationPropertyOutputReference;
        putFsxWindowsFileServerVolumeConfiguration(value: FsxWindowsFileServerVolumeConfigurationProperty): void;
        resetFsxWindowsFileServerVolumeConfiguration(): void;
        get fsxWindowsFileServerVolumeConfigurationInput(): FsxWindowsFileServerVolumeConfigurationProperty | undefined;
        private _s3FilesVolumeConfiguration;
        get s3FilesVolumeConfiguration(): S3filesVolumeConfigurationPropertyOutputReference;
        putS3FilesVolumeConfiguration(value: S3filesVolumeConfigurationProperty): void;
        resetS3FilesVolumeConfiguration(): void;
        get s3FilesVolumeConfigurationInput(): S3filesVolumeConfigurationProperty | undefined;
    }
    class VolumePropertyList extends cdktn.ComplexList {
        internalValue?: VolumeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VolumePropertyOutputReference;
    }
}
