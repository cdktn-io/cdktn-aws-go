import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsExpressGatewayServiceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_express_gateway_service#cluster AwsExpressGatewayService#cluster}
    */
    readonly cluster?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_express_gateway_service#cpu AwsExpressGatewayService#cpu}
    */
    readonly cpu?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_express_gateway_service#execution_role_arn AwsExpressGatewayService#execution_role_arn}
    */
    readonly executionRoleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_express_gateway_service#health_check_path AwsExpressGatewayService#health_check_path}
    */
    readonly healthCheckPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_express_gateway_service#infrastructure_role_arn AwsExpressGatewayService#infrastructure_role_arn}
    */
    readonly infrastructureRoleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_express_gateway_service#memory AwsExpressGatewayService#memory}
    */
    readonly memory?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_express_gateway_service#network_configuration AwsExpressGatewayService#network_configuration}
    */
    readonly networkConfiguration?: AwsExpressGatewayService.NetworkConfigurationProperty[] | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_express_gateway_service#region AwsExpressGatewayService#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_express_gateway_service#scaling_target AwsExpressGatewayService#scaling_target}
    */
    readonly scalingTarget?: AwsExpressGatewayService.ScalingTargetProperty[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_express_gateway_service#service_name AwsExpressGatewayService#service_name}
    */
    readonly serviceName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_express_gateway_service#tags AwsExpressGatewayService#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_express_gateway_service#task_role_arn AwsExpressGatewayService#task_role_arn}
    */
    readonly taskRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_express_gateway_service#wait_for_steady_state AwsExpressGatewayService#wait_for_steady_state}
    */
    readonly waitForSteadyState?: boolean | cdktn.IResolvable;
    /**
    * primary_container block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_express_gateway_service#primary_container AwsExpressGatewayService#primary_container}
    */
    readonly primaryContainer?: AwsExpressGatewayService.PrimaryContainerProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_express_gateway_service#timeouts AwsExpressGatewayService#timeouts}
    */
    readonly timeouts?: AwsExpressGatewayService.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_express_gateway_service aws_ecs_express_gateway_service}
*/
export declare class AwsExpressGatewayService extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ecs_express_gateway_service";
    /**
    * Generates CDKTN code for importing a AwsExpressGatewayService resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsExpressGatewayService to import
    * @param importFromId The id of the existing AwsExpressGatewayService that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_express_gateway_service#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsExpressGatewayService to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_express_gateway_service aws_ecs_express_gateway_service} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsExpressGatewayServiceConfig
    */
    constructor(scope: Construct, id: string, config: AwsExpressGatewayServiceConfig);
    private _cluster?;
    get cluster(): string;
    set cluster(value: string);
    resetCluster(): void;
    get clusterInput(): string | undefined;
    private _cpu?;
    get cpu(): string;
    set cpu(value: string);
    resetCpu(): void;
    get cpuInput(): string | undefined;
    get currentDeployment(): string;
    private _executionRoleArn?;
    get executionRoleArn(): string;
    set executionRoleArn(value: string);
    get executionRoleArnInput(): string | undefined;
    private _healthCheckPath?;
    get healthCheckPath(): string;
    set healthCheckPath(value: string);
    resetHealthCheckPath(): void;
    get healthCheckPathInput(): string | undefined;
    private _infrastructureRoleArn?;
    get infrastructureRoleArn(): string;
    set infrastructureRoleArn(value: string);
    get infrastructureRoleArnInput(): string | undefined;
    private _ingressPaths;
    get ingressPaths(): AwsExpressGatewayService.IngressPathsPropertyList;
    private _memory?;
    get memory(): string;
    set memory(value: string);
    resetMemory(): void;
    get memoryInput(): string | undefined;
    private _networkConfiguration;
    get networkConfiguration(): AwsExpressGatewayService.NetworkConfigurationPropertyList;
    putNetworkConfiguration(value: AwsExpressGatewayService.NetworkConfigurationProperty[] | cdktn.IResolvable): void;
    resetNetworkConfiguration(): void;
    get networkConfigurationInput(): cdktn.IResolvable | AwsExpressGatewayService.NetworkConfigurationProperty[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _scalingTarget;
    get scalingTarget(): AwsExpressGatewayService.ScalingTargetPropertyList;
    putScalingTarget(value: AwsExpressGatewayService.ScalingTargetProperty[] | cdktn.IResolvable): void;
    resetScalingTarget(): void;
    get scalingTargetInput(): cdktn.IResolvable | AwsExpressGatewayService.ScalingTargetProperty[] | undefined;
    get serviceArn(): string;
    private _serviceName?;
    get serviceName(): string;
    set serviceName(value: string);
    resetServiceName(): void;
    get serviceNameInput(): string | undefined;
    get serviceRevisionArn(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _taskRoleArn?;
    get taskRoleArn(): string;
    set taskRoleArn(value: string);
    resetTaskRoleArn(): void;
    get taskRoleArnInput(): string | undefined;
    private _waitForSteadyState?;
    get waitForSteadyState(): boolean | cdktn.IResolvable;
    set waitForSteadyState(value: boolean | cdktn.IResolvable);
    resetWaitForSteadyState(): void;
    get waitForSteadyStateInput(): boolean | cdktn.IResolvable | undefined;
    private _primaryContainer;
    get primaryContainer(): AwsExpressGatewayService.PrimaryContainerPropertyList;
    putPrimaryContainer(value: AwsExpressGatewayService.PrimaryContainerProperty[] | cdktn.IResolvable): void;
    resetPrimaryContainer(): void;
    get primaryContainerInput(): cdktn.IResolvable | AwsExpressGatewayService.PrimaryContainerProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsExpressGatewayService.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsExpressGatewayService.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsExpressGatewayService.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsExpressGatewayServiceIngressPathsPropertyToTerraform(struct?: AwsExpressGatewayService.IngressPathsProperty): any;
export declare function awsExpressGatewayServiceIngressPathsPropertyToHclTerraform(struct?: AwsExpressGatewayService.IngressPathsProperty): any;
export declare function awsExpressGatewayServiceNetworkConfigurationPropertyToTerraform(struct?: AwsExpressGatewayService.NetworkConfigurationProperty | cdktn.IResolvable): any;
export declare function awsExpressGatewayServiceNetworkConfigurationPropertyToHclTerraform(struct?: AwsExpressGatewayService.NetworkConfigurationProperty | cdktn.IResolvable): any;
export declare function awsExpressGatewayServiceScalingTargetPropertyToTerraform(struct?: AwsExpressGatewayService.ScalingTargetProperty | cdktn.IResolvable): any;
export declare function awsExpressGatewayServiceScalingTargetPropertyToHclTerraform(struct?: AwsExpressGatewayService.ScalingTargetProperty | cdktn.IResolvable): any;
export declare function awsExpressGatewayServiceAwsLogsConfigurationPropertyToTerraform(struct?: AwsExpressGatewayService.AwsLogsConfigurationProperty | cdktn.IResolvable): any;
export declare function awsExpressGatewayServiceAwsLogsConfigurationPropertyToHclTerraform(struct?: AwsExpressGatewayService.AwsLogsConfigurationProperty | cdktn.IResolvable): any;
export declare function awsExpressGatewayServiceEnvironmentPropertyToTerraform(struct?: AwsExpressGatewayService.EnvironmentProperty | cdktn.IResolvable): any;
export declare function awsExpressGatewayServiceEnvironmentPropertyToHclTerraform(struct?: AwsExpressGatewayService.EnvironmentProperty | cdktn.IResolvable): any;
export declare function awsExpressGatewayServiceRepositoryCredentialsPropertyToTerraform(struct?: AwsExpressGatewayService.RepositoryCredentialsProperty | cdktn.IResolvable): any;
export declare function awsExpressGatewayServiceRepositoryCredentialsPropertyToHclTerraform(struct?: AwsExpressGatewayService.RepositoryCredentialsProperty | cdktn.IResolvable): any;
export declare function awsExpressGatewayServiceSecretPropertyToTerraform(struct?: AwsExpressGatewayService.SecretProperty | cdktn.IResolvable): any;
export declare function awsExpressGatewayServiceSecretPropertyToHclTerraform(struct?: AwsExpressGatewayService.SecretProperty | cdktn.IResolvable): any;
export declare function awsExpressGatewayServicePrimaryContainerPropertyToTerraform(struct?: AwsExpressGatewayService.PrimaryContainerProperty | cdktn.IResolvable): any;
export declare function awsExpressGatewayServicePrimaryContainerPropertyToHclTerraform(struct?: AwsExpressGatewayService.PrimaryContainerProperty | cdktn.IResolvable): any;
export declare function awsExpressGatewayServiceTimeoutsPropertyToTerraform(struct?: AwsExpressGatewayService.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsExpressGatewayServiceTimeoutsPropertyToHclTerraform(struct?: AwsExpressGatewayService.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsExpressGatewayService {
    interface IngressPathsProperty {
    }
    class IngressPathsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IngressPathsProperty | undefined;
        set internalValue(value: IngressPathsProperty | undefined);
        get accessType(): string;
        get endpoint(): string;
    }
    class IngressPathsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IngressPathsPropertyOutputReference;
    }
    interface NetworkConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_express_gateway_service#security_groups AwsExpressGatewayService#security_groups}
        */
        readonly securityGroups?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_express_gateway_service#subnets AwsExpressGatewayService#subnets}
        */
        readonly subnets?: string[];
    }
    class NetworkConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NetworkConfigurationProperty | cdktn.IResolvable | undefined);
        private _securityGroups?;
        get securityGroups(): string[];
        set securityGroups(value: string[]);
        resetSecurityGroups(): void;
        get securityGroupsInput(): string[] | undefined;
        private _subnets?;
        get subnets(): string[];
        set subnets(value: string[]);
        resetSubnets(): void;
        get subnetsInput(): string[] | undefined;
    }
    class NetworkConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: NetworkConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkConfigurationPropertyOutputReference;
    }
    interface ScalingTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_express_gateway_service#auto_scaling_metric AwsExpressGatewayService#auto_scaling_metric}
        */
        readonly autoScalingMetric?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_express_gateway_service#auto_scaling_target_value AwsExpressGatewayService#auto_scaling_target_value}
        */
        readonly autoScalingTargetValue?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_express_gateway_service#max_task_count AwsExpressGatewayService#max_task_count}
        */
        readonly maxTaskCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_express_gateway_service#min_task_count AwsExpressGatewayService#min_task_count}
        */
        readonly minTaskCount?: number;
    }
    class ScalingTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ScalingTargetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ScalingTargetProperty | cdktn.IResolvable | undefined);
        private _autoScalingMetric?;
        get autoScalingMetric(): string;
        set autoScalingMetric(value: string);
        resetAutoScalingMetric(): void;
        get autoScalingMetricInput(): string | undefined;
        private _autoScalingTargetValue?;
        get autoScalingTargetValue(): number;
        set autoScalingTargetValue(value: number);
        resetAutoScalingTargetValue(): void;
        get autoScalingTargetValueInput(): number | undefined;
        private _maxTaskCount?;
        get maxTaskCount(): number;
        set maxTaskCount(value: number);
        resetMaxTaskCount(): void;
        get maxTaskCountInput(): number | undefined;
        private _minTaskCount?;
        get minTaskCount(): number;
        set minTaskCount(value: number);
        resetMinTaskCount(): void;
        get minTaskCountInput(): number | undefined;
    }
    class ScalingTargetPropertyList extends cdktn.ComplexList {
        internalValue?: ScalingTargetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ScalingTargetPropertyOutputReference;
    }
    interface AwsLogsConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_express_gateway_service#log_group AwsExpressGatewayService#log_group}
        */
        readonly logGroup?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_express_gateway_service#log_stream_prefix AwsExpressGatewayService#log_stream_prefix}
        */
        readonly logStreamPrefix?: string;
    }
    class AwsLogsConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AwsLogsConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AwsLogsConfigurationProperty | cdktn.IResolvable | undefined);
        private _logGroup?;
        get logGroup(): string;
        set logGroup(value: string);
        resetLogGroup(): void;
        get logGroupInput(): string | undefined;
        private _logStreamPrefix?;
        get logStreamPrefix(): string;
        set logStreamPrefix(value: string);
        resetLogStreamPrefix(): void;
        get logStreamPrefixInput(): string | undefined;
    }
    class AwsLogsConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: AwsLogsConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AwsLogsConfigurationPropertyOutputReference;
    }
    interface EnvironmentProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_express_gateway_service#name AwsExpressGatewayService#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_express_gateway_service#value AwsExpressGatewayService#value}
        */
        readonly value: string;
    }
    class EnvironmentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EnvironmentProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EnvironmentProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class EnvironmentPropertyList extends cdktn.ComplexList {
        internalValue?: EnvironmentProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EnvironmentPropertyOutputReference;
    }
    interface RepositoryCredentialsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_express_gateway_service#credentials_parameter AwsExpressGatewayService#credentials_parameter}
        */
        readonly credentialsParameter: string;
    }
    class RepositoryCredentialsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RepositoryCredentialsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RepositoryCredentialsProperty | cdktn.IResolvable | undefined);
        private _credentialsParameter?;
        get credentialsParameter(): string;
        set credentialsParameter(value: string);
        get credentialsParameterInput(): string | undefined;
    }
    class RepositoryCredentialsPropertyList extends cdktn.ComplexList {
        internalValue?: RepositoryCredentialsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RepositoryCredentialsPropertyOutputReference;
    }
    interface SecretProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_express_gateway_service#name AwsExpressGatewayService#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_express_gateway_service#value_from AwsExpressGatewayService#value_from}
        */
        readonly valueFrom: string;
    }
    class SecretPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SecretProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SecretProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _valueFrom?;
        get valueFrom(): string;
        set valueFrom(value: string);
        get valueFromInput(): string | undefined;
    }
    class SecretPropertyList extends cdktn.ComplexList {
        internalValue?: SecretProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SecretPropertyOutputReference;
    }
    interface PrimaryContainerProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_express_gateway_service#aws_logs_configuration AwsExpressGatewayService#aws_logs_configuration}
        */
        readonly awsLogsConfiguration?: AwsLogsConfigurationProperty[] | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_express_gateway_service#command AwsExpressGatewayService#command}
        */
        readonly command?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_express_gateway_service#container_port AwsExpressGatewayService#container_port}
        */
        readonly containerPort?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_express_gateway_service#image AwsExpressGatewayService#image}
        */
        readonly image: string;
        /**
        * environment block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_express_gateway_service#environment AwsExpressGatewayService#environment}
        */
        readonly environment?: EnvironmentProperty[] | cdktn.IResolvable;
        /**
        * repository_credentials block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_express_gateway_service#repository_credentials AwsExpressGatewayService#repository_credentials}
        */
        readonly repositoryCredentials?: RepositoryCredentialsProperty[] | cdktn.IResolvable;
        /**
        * secret block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_express_gateway_service#secret AwsExpressGatewayService#secret}
        */
        readonly secret?: SecretProperty[] | cdktn.IResolvable;
    }
    class PrimaryContainerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PrimaryContainerProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PrimaryContainerProperty | cdktn.IResolvable | undefined);
        private _awsLogsConfiguration;
        get awsLogsConfiguration(): AwsLogsConfigurationPropertyList;
        putAwsLogsConfiguration(value: AwsLogsConfigurationProperty[] | cdktn.IResolvable): void;
        resetAwsLogsConfiguration(): void;
        get awsLogsConfigurationInput(): cdktn.IResolvable | AwsLogsConfigurationProperty[] | undefined;
        private _command?;
        get command(): string[];
        set command(value: string[]);
        resetCommand(): void;
        get commandInput(): string[] | undefined;
        private _containerPort?;
        get containerPort(): number;
        set containerPort(value: number);
        resetContainerPort(): void;
        get containerPortInput(): number | undefined;
        private _image?;
        get image(): string;
        set image(value: string);
        get imageInput(): string | undefined;
        private _environment;
        get environment(): EnvironmentPropertyList;
        putEnvironment(value: EnvironmentProperty[] | cdktn.IResolvable): void;
        resetEnvironment(): void;
        get environmentInput(): cdktn.IResolvable | EnvironmentProperty[] | undefined;
        private _repositoryCredentials;
        get repositoryCredentials(): RepositoryCredentialsPropertyList;
        putRepositoryCredentials(value: RepositoryCredentialsProperty[] | cdktn.IResolvable): void;
        resetRepositoryCredentials(): void;
        get repositoryCredentialsInput(): cdktn.IResolvable | RepositoryCredentialsProperty[] | undefined;
        private _secret;
        get secret(): SecretPropertyList;
        putSecret(value: SecretProperty[] | cdktn.IResolvable): void;
        resetSecret(): void;
        get secretInput(): cdktn.IResolvable | SecretProperty[] | undefined;
    }
    class PrimaryContainerPropertyList extends cdktn.ComplexList {
        internalValue?: PrimaryContainerProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PrimaryContainerPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_express_gateway_service#create AwsExpressGatewayService#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_express_gateway_service#delete AwsExpressGatewayService#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_express_gateway_service#update AwsExpressGatewayService#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
