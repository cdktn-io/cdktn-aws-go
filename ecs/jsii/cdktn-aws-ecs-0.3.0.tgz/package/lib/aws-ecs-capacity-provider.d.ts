import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsCapacityProviderConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#cluster AwsCapacityProvider#cluster}
    */
    readonly cluster?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#id AwsCapacityProvider#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#name AwsCapacityProvider#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#region AwsCapacityProvider#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#tags AwsCapacityProvider#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#tags_all AwsCapacityProvider#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * auto_scaling_group_provider block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#auto_scaling_group_provider AwsCapacityProvider#auto_scaling_group_provider}
    */
    readonly autoScalingGroupProvider?: AwsCapacityProvider.AutoScalingGroupProviderProperty;
    /**
    * managed_instances_provider block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#managed_instances_provider AwsCapacityProvider#managed_instances_provider}
    */
    readonly managedInstancesProvider?: AwsCapacityProvider.ManagedInstancesProviderProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider aws_ecs_capacity_provider}
*/
export declare class AwsCapacityProvider extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ecs_capacity_provider";
    /**
    * Generates CDKTN code for importing a AwsCapacityProvider resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCapacityProvider to import
    * @param importFromId The id of the existing AwsCapacityProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCapacityProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider aws_ecs_capacity_provider} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsCapacityProviderConfig
    */
    constructor(scope: Construct, id: string, config: AwsCapacityProviderConfig);
    get arn(): string;
    private _cluster?;
    get cluster(): string;
    set cluster(value: string);
    resetCluster(): void;
    get clusterInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _autoScalingGroupProvider;
    get autoScalingGroupProvider(): AwsCapacityProvider.AutoScalingGroupProviderPropertyOutputReference;
    putAutoScalingGroupProvider(value: AwsCapacityProvider.AutoScalingGroupProviderProperty): void;
    resetAutoScalingGroupProvider(): void;
    get autoScalingGroupProviderInput(): AwsCapacityProvider.AutoScalingGroupProviderProperty | undefined;
    private _managedInstancesProvider;
    get managedInstancesProvider(): AwsCapacityProvider.ManagedInstancesProviderPropertyOutputReference;
    putManagedInstancesProvider(value: AwsCapacityProvider.ManagedInstancesProviderProperty): void;
    resetManagedInstancesProvider(): void;
    get managedInstancesProviderInput(): AwsCapacityProvider.ManagedInstancesProviderProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsCapacityProviderManagedScalingPropertyToTerraform(struct?: AwsCapacityProvider.ManagedScalingPropertyOutputReference | AwsCapacityProvider.ManagedScalingProperty): any;
export declare function awsCapacityProviderManagedScalingPropertyToHclTerraform(struct?: AwsCapacityProvider.ManagedScalingPropertyOutputReference | AwsCapacityProvider.ManagedScalingProperty): any;
export declare function awsCapacityProviderAutoScalingGroupProviderPropertyToTerraform(struct?: AwsCapacityProvider.AutoScalingGroupProviderPropertyOutputReference | AwsCapacityProvider.AutoScalingGroupProviderProperty): any;
export declare function awsCapacityProviderAutoScalingGroupProviderPropertyToHclTerraform(struct?: AwsCapacityProvider.AutoScalingGroupProviderPropertyOutputReference | AwsCapacityProvider.AutoScalingGroupProviderProperty): any;
export declare function awsCapacityProviderInfrastructureOptimizationPropertyToTerraform(struct?: AwsCapacityProvider.InfrastructureOptimizationPropertyOutputReference | AwsCapacityProvider.InfrastructureOptimizationProperty): any;
export declare function awsCapacityProviderInfrastructureOptimizationPropertyToHclTerraform(struct?: AwsCapacityProvider.InfrastructureOptimizationPropertyOutputReference | AwsCapacityProvider.InfrastructureOptimizationProperty): any;
export declare function awsCapacityProviderCapacityReservationsPropertyToTerraform(struct?: AwsCapacityProvider.CapacityReservationsPropertyOutputReference | AwsCapacityProvider.CapacityReservationsProperty): any;
export declare function awsCapacityProviderCapacityReservationsPropertyToHclTerraform(struct?: AwsCapacityProvider.CapacityReservationsPropertyOutputReference | AwsCapacityProvider.CapacityReservationsProperty): any;
export declare function awsCapacityProviderAcceleratorCountPropertyToTerraform(struct?: AwsCapacityProvider.AcceleratorCountPropertyOutputReference | AwsCapacityProvider.AcceleratorCountProperty): any;
export declare function awsCapacityProviderAcceleratorCountPropertyToHclTerraform(struct?: AwsCapacityProvider.AcceleratorCountPropertyOutputReference | AwsCapacityProvider.AcceleratorCountProperty): any;
export declare function awsCapacityProviderAcceleratorTotalMemoryMibPropertyToTerraform(struct?: AwsCapacityProvider.AcceleratorTotalMemoryMibPropertyOutputReference | AwsCapacityProvider.AcceleratorTotalMemoryMibProperty): any;
export declare function awsCapacityProviderAcceleratorTotalMemoryMibPropertyToHclTerraform(struct?: AwsCapacityProvider.AcceleratorTotalMemoryMibPropertyOutputReference | AwsCapacityProvider.AcceleratorTotalMemoryMibProperty): any;
export declare function awsCapacityProviderBaselineEbsBandwidthMbpsPropertyToTerraform(struct?: AwsCapacityProvider.BaselineEbsBandwidthMbpsPropertyOutputReference | AwsCapacityProvider.BaselineEbsBandwidthMbpsProperty): any;
export declare function awsCapacityProviderBaselineEbsBandwidthMbpsPropertyToHclTerraform(struct?: AwsCapacityProvider.BaselineEbsBandwidthMbpsPropertyOutputReference | AwsCapacityProvider.BaselineEbsBandwidthMbpsProperty): any;
export declare function awsCapacityProviderMemoryGibPerVcpuPropertyToTerraform(struct?: AwsCapacityProvider.MemoryGibPerVcpuPropertyOutputReference | AwsCapacityProvider.MemoryGibPerVcpuProperty): any;
export declare function awsCapacityProviderMemoryGibPerVcpuPropertyToHclTerraform(struct?: AwsCapacityProvider.MemoryGibPerVcpuPropertyOutputReference | AwsCapacityProvider.MemoryGibPerVcpuProperty): any;
export declare function awsCapacityProviderMemoryMibPropertyToTerraform(struct?: AwsCapacityProvider.MemoryMibPropertyOutputReference | AwsCapacityProvider.MemoryMibProperty): any;
export declare function awsCapacityProviderMemoryMibPropertyToHclTerraform(struct?: AwsCapacityProvider.MemoryMibPropertyOutputReference | AwsCapacityProvider.MemoryMibProperty): any;
export declare function awsCapacityProviderNetworkBandwidthGbpsPropertyToTerraform(struct?: AwsCapacityProvider.NetworkBandwidthGbpsPropertyOutputReference | AwsCapacityProvider.NetworkBandwidthGbpsProperty): any;
export declare function awsCapacityProviderNetworkBandwidthGbpsPropertyToHclTerraform(struct?: AwsCapacityProvider.NetworkBandwidthGbpsPropertyOutputReference | AwsCapacityProvider.NetworkBandwidthGbpsProperty): any;
export declare function awsCapacityProviderNetworkInterfaceCountPropertyToTerraform(struct?: AwsCapacityProvider.NetworkInterfaceCountPropertyOutputReference | AwsCapacityProvider.NetworkInterfaceCountProperty): any;
export declare function awsCapacityProviderNetworkInterfaceCountPropertyToHclTerraform(struct?: AwsCapacityProvider.NetworkInterfaceCountPropertyOutputReference | AwsCapacityProvider.NetworkInterfaceCountProperty): any;
export declare function awsCapacityProviderTotalLocalStorageGbPropertyToTerraform(struct?: AwsCapacityProvider.TotalLocalStorageGbPropertyOutputReference | AwsCapacityProvider.TotalLocalStorageGbProperty): any;
export declare function awsCapacityProviderTotalLocalStorageGbPropertyToHclTerraform(struct?: AwsCapacityProvider.TotalLocalStorageGbPropertyOutputReference | AwsCapacityProvider.TotalLocalStorageGbProperty): any;
export declare function awsCapacityProviderVcpuCountPropertyToTerraform(struct?: AwsCapacityProvider.VcpuCountPropertyOutputReference | AwsCapacityProvider.VcpuCountProperty): any;
export declare function awsCapacityProviderVcpuCountPropertyToHclTerraform(struct?: AwsCapacityProvider.VcpuCountPropertyOutputReference | AwsCapacityProvider.VcpuCountProperty): any;
export declare function awsCapacityProviderInstanceRequirementsPropertyToTerraform(struct?: AwsCapacityProvider.InstanceRequirementsPropertyOutputReference | AwsCapacityProvider.InstanceRequirementsProperty): any;
export declare function awsCapacityProviderInstanceRequirementsPropertyToHclTerraform(struct?: AwsCapacityProvider.InstanceRequirementsPropertyOutputReference | AwsCapacityProvider.InstanceRequirementsProperty): any;
export declare function awsCapacityProviderLocalStorageConfigurationPropertyToTerraform(struct?: AwsCapacityProvider.LocalStorageConfigurationPropertyOutputReference | AwsCapacityProvider.LocalStorageConfigurationProperty): any;
export declare function awsCapacityProviderLocalStorageConfigurationPropertyToHclTerraform(struct?: AwsCapacityProvider.LocalStorageConfigurationPropertyOutputReference | AwsCapacityProvider.LocalStorageConfigurationProperty): any;
export declare function awsCapacityProviderNetworkConfigurationPropertyToTerraform(struct?: AwsCapacityProvider.NetworkConfigurationPropertyOutputReference | AwsCapacityProvider.NetworkConfigurationProperty): any;
export declare function awsCapacityProviderNetworkConfigurationPropertyToHclTerraform(struct?: AwsCapacityProvider.NetworkConfigurationPropertyOutputReference | AwsCapacityProvider.NetworkConfigurationProperty): any;
export declare function awsCapacityProviderStorageConfigurationPropertyToTerraform(struct?: AwsCapacityProvider.StorageConfigurationPropertyOutputReference | AwsCapacityProvider.StorageConfigurationProperty): any;
export declare function awsCapacityProviderStorageConfigurationPropertyToHclTerraform(struct?: AwsCapacityProvider.StorageConfigurationPropertyOutputReference | AwsCapacityProvider.StorageConfigurationProperty): any;
export declare function awsCapacityProviderInstanceLaunchTemplatePropertyToTerraform(struct?: AwsCapacityProvider.InstanceLaunchTemplatePropertyOutputReference | AwsCapacityProvider.InstanceLaunchTemplateProperty): any;
export declare function awsCapacityProviderInstanceLaunchTemplatePropertyToHclTerraform(struct?: AwsCapacityProvider.InstanceLaunchTemplatePropertyOutputReference | AwsCapacityProvider.InstanceLaunchTemplateProperty): any;
export declare function awsCapacityProviderManagedInstancesProviderPropertyToTerraform(struct?: AwsCapacityProvider.ManagedInstancesProviderPropertyOutputReference | AwsCapacityProvider.ManagedInstancesProviderProperty): any;
export declare function awsCapacityProviderManagedInstancesProviderPropertyToHclTerraform(struct?: AwsCapacityProvider.ManagedInstancesProviderPropertyOutputReference | AwsCapacityProvider.ManagedInstancesProviderProperty): any;
export declare namespace AwsCapacityProvider {
    interface ManagedScalingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#instance_warmup_period AwsCapacityProvider#instance_warmup_period}
        */
        readonly instanceWarmupPeriod?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#maximum_scaling_step_size AwsCapacityProvider#maximum_scaling_step_size}
        */
        readonly maximumScalingStepSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#minimum_scaling_step_size AwsCapacityProvider#minimum_scaling_step_size}
        */
        readonly minimumScalingStepSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#status AwsCapacityProvider#status}
        */
        readonly status?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#target_capacity AwsCapacityProvider#target_capacity}
        */
        readonly targetCapacity?: number;
    }
    class ManagedScalingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ManagedScalingProperty | undefined;
        set internalValue(value: ManagedScalingProperty | undefined);
        private _instanceWarmupPeriod?;
        get instanceWarmupPeriod(): number;
        set instanceWarmupPeriod(value: number);
        resetInstanceWarmupPeriod(): void;
        get instanceWarmupPeriodInput(): number | undefined;
        private _maximumScalingStepSize?;
        get maximumScalingStepSize(): number;
        set maximumScalingStepSize(value: number);
        resetMaximumScalingStepSize(): void;
        get maximumScalingStepSizeInput(): number | undefined;
        private _minimumScalingStepSize?;
        get minimumScalingStepSize(): number;
        set minimumScalingStepSize(value: number);
        resetMinimumScalingStepSize(): void;
        get minimumScalingStepSizeInput(): number | undefined;
        private _status?;
        get status(): string;
        set status(value: string);
        resetStatus(): void;
        get statusInput(): string | undefined;
        private _targetCapacity?;
        get targetCapacity(): number;
        set targetCapacity(value: number);
        resetTargetCapacity(): void;
        get targetCapacityInput(): number | undefined;
    }
    interface AutoScalingGroupProviderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#auto_scaling_group_arn AwsCapacityProvider#auto_scaling_group_arn}
        */
        readonly autoScalingGroupArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#managed_draining AwsCapacityProvider#managed_draining}
        */
        readonly managedDraining?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#managed_termination_protection AwsCapacityProvider#managed_termination_protection}
        */
        readonly managedTerminationProtection?: string;
        /**
        * managed_scaling block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#managed_scaling AwsCapacityProvider#managed_scaling}
        */
        readonly managedScaling?: ManagedScalingProperty;
    }
    class AutoScalingGroupProviderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AutoScalingGroupProviderProperty | undefined;
        set internalValue(value: AutoScalingGroupProviderProperty | undefined);
        private _autoScalingGroupArn?;
        get autoScalingGroupArn(): string;
        set autoScalingGroupArn(value: string);
        get autoScalingGroupArnInput(): string | undefined;
        private _managedDraining?;
        get managedDraining(): string;
        set managedDraining(value: string);
        resetManagedDraining(): void;
        get managedDrainingInput(): string | undefined;
        private _managedTerminationProtection?;
        get managedTerminationProtection(): string;
        set managedTerminationProtection(value: string);
        resetManagedTerminationProtection(): void;
        get managedTerminationProtectionInput(): string | undefined;
        private _managedScaling;
        get managedScaling(): ManagedScalingPropertyOutputReference;
        putManagedScaling(value: ManagedScalingProperty): void;
        resetManagedScaling(): void;
        get managedScalingInput(): ManagedScalingProperty | undefined;
    }
    interface InfrastructureOptimizationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#scale_in_after AwsCapacityProvider#scale_in_after}
        */
        readonly scaleInAfter?: number;
    }
    class InfrastructureOptimizationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InfrastructureOptimizationProperty | undefined;
        set internalValue(value: InfrastructureOptimizationProperty | undefined);
        private _scaleInAfter?;
        get scaleInAfter(): number;
        set scaleInAfter(value: number);
        resetScaleInAfter(): void;
        get scaleInAfterInput(): number | undefined;
    }
    interface CapacityReservationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#reservation_group_arn AwsCapacityProvider#reservation_group_arn}
        */
        readonly reservationGroupArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#reservation_preference AwsCapacityProvider#reservation_preference}
        */
        readonly reservationPreference?: string;
    }
    class CapacityReservationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CapacityReservationsProperty | undefined;
        set internalValue(value: CapacityReservationsProperty | undefined);
        private _reservationGroupArn?;
        get reservationGroupArn(): string;
        set reservationGroupArn(value: string);
        resetReservationGroupArn(): void;
        get reservationGroupArnInput(): string | undefined;
        private _reservationPreference?;
        get reservationPreference(): string;
        set reservationPreference(value: string);
        resetReservationPreference(): void;
        get reservationPreferenceInput(): string | undefined;
    }
    interface AcceleratorCountProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#max AwsCapacityProvider#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#min AwsCapacityProvider#min}
        */
        readonly min?: number;
    }
    class AcceleratorCountPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AcceleratorCountProperty | undefined;
        set internalValue(value: AcceleratorCountProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface AcceleratorTotalMemoryMibProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#max AwsCapacityProvider#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#min AwsCapacityProvider#min}
        */
        readonly min?: number;
    }
    class AcceleratorTotalMemoryMibPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AcceleratorTotalMemoryMibProperty | undefined;
        set internalValue(value: AcceleratorTotalMemoryMibProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface BaselineEbsBandwidthMbpsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#max AwsCapacityProvider#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#min AwsCapacityProvider#min}
        */
        readonly min?: number;
    }
    class BaselineEbsBandwidthMbpsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BaselineEbsBandwidthMbpsProperty | undefined;
        set internalValue(value: BaselineEbsBandwidthMbpsProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface MemoryGibPerVcpuProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#max AwsCapacityProvider#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#min AwsCapacityProvider#min}
        */
        readonly min?: number;
    }
    class MemoryGibPerVcpuPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MemoryGibPerVcpuProperty | undefined;
        set internalValue(value: MemoryGibPerVcpuProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface MemoryMibProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#max AwsCapacityProvider#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#min AwsCapacityProvider#min}
        */
        readonly min: number;
    }
    class MemoryMibPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MemoryMibProperty | undefined;
        set internalValue(value: MemoryMibProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        get minInput(): number | undefined;
    }
    interface NetworkBandwidthGbpsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#max AwsCapacityProvider#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#min AwsCapacityProvider#min}
        */
        readonly min?: number;
    }
    class NetworkBandwidthGbpsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NetworkBandwidthGbpsProperty | undefined;
        set internalValue(value: NetworkBandwidthGbpsProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface NetworkInterfaceCountProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#max AwsCapacityProvider#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#min AwsCapacityProvider#min}
        */
        readonly min?: number;
    }
    class NetworkInterfaceCountPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NetworkInterfaceCountProperty | undefined;
        set internalValue(value: NetworkInterfaceCountProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface TotalLocalStorageGbProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#max AwsCapacityProvider#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#min AwsCapacityProvider#min}
        */
        readonly min?: number;
    }
    class TotalLocalStorageGbPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TotalLocalStorageGbProperty | undefined;
        set internalValue(value: TotalLocalStorageGbProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        resetMin(): void;
        get minInput(): number | undefined;
    }
    interface VcpuCountProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#max AwsCapacityProvider#max}
        */
        readonly max?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#min AwsCapacityProvider#min}
        */
        readonly min: number;
    }
    class VcpuCountPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VcpuCountProperty | undefined;
        set internalValue(value: VcpuCountProperty | undefined);
        private _max?;
        get max(): number;
        set max(value: number);
        resetMax(): void;
        get maxInput(): number | undefined;
        private _min?;
        get min(): number;
        set min(value: number);
        get minInput(): number | undefined;
    }
    interface InstanceRequirementsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#accelerator_manufacturers AwsCapacityProvider#accelerator_manufacturers}
        */
        readonly acceleratorManufacturers?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#accelerator_names AwsCapacityProvider#accelerator_names}
        */
        readonly acceleratorNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#accelerator_types AwsCapacityProvider#accelerator_types}
        */
        readonly acceleratorTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#allowed_instance_types AwsCapacityProvider#allowed_instance_types}
        */
        readonly allowedInstanceTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#bare_metal AwsCapacityProvider#bare_metal}
        */
        readonly bareMetal?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#burstable_performance AwsCapacityProvider#burstable_performance}
        */
        readonly burstablePerformance?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#cpu_manufacturers AwsCapacityProvider#cpu_manufacturers}
        */
        readonly cpuManufacturers?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#excluded_instance_types AwsCapacityProvider#excluded_instance_types}
        */
        readonly excludedInstanceTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#instance_generations AwsCapacityProvider#instance_generations}
        */
        readonly instanceGenerations?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#local_storage AwsCapacityProvider#local_storage}
        */
        readonly localStorage?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#local_storage_types AwsCapacityProvider#local_storage_types}
        */
        readonly localStorageTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#max_spot_price_as_percentage_of_optimal_on_demand_price AwsCapacityProvider#max_spot_price_as_percentage_of_optimal_on_demand_price}
        */
        readonly maxSpotPriceAsPercentageOfOptimalOnDemandPrice?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#on_demand_max_price_percentage_over_lowest_price AwsCapacityProvider#on_demand_max_price_percentage_over_lowest_price}
        */
        readonly onDemandMaxPricePercentageOverLowestPrice?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#require_hibernate_support AwsCapacityProvider#require_hibernate_support}
        */
        readonly requireHibernateSupport?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#spot_max_price_percentage_over_lowest_price AwsCapacityProvider#spot_max_price_percentage_over_lowest_price}
        */
        readonly spotMaxPricePercentageOverLowestPrice?: number;
        /**
        * accelerator_count block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#accelerator_count AwsCapacityProvider#accelerator_count}
        */
        readonly acceleratorCount?: AcceleratorCountProperty;
        /**
        * accelerator_total_memory_mib block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#accelerator_total_memory_mib AwsCapacityProvider#accelerator_total_memory_mib}
        */
        readonly acceleratorTotalMemoryMib?: AcceleratorTotalMemoryMibProperty;
        /**
        * baseline_ebs_bandwidth_mbps block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#baseline_ebs_bandwidth_mbps AwsCapacityProvider#baseline_ebs_bandwidth_mbps}
        */
        readonly baselineEbsBandwidthMbps?: BaselineEbsBandwidthMbpsProperty;
        /**
        * memory_gib_per_vcpu block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#memory_gib_per_vcpu AwsCapacityProvider#memory_gib_per_vcpu}
        */
        readonly memoryGibPerVcpu?: MemoryGibPerVcpuProperty;
        /**
        * memory_mib block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#memory_mib AwsCapacityProvider#memory_mib}
        */
        readonly memoryMib: MemoryMibProperty;
        /**
        * network_bandwidth_gbps block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#network_bandwidth_gbps AwsCapacityProvider#network_bandwidth_gbps}
        */
        readonly networkBandwidthGbps?: NetworkBandwidthGbpsProperty;
        /**
        * network_interface_count block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#network_interface_count AwsCapacityProvider#network_interface_count}
        */
        readonly networkInterfaceCount?: NetworkInterfaceCountProperty;
        /**
        * total_local_storage_gb block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#total_local_storage_gb AwsCapacityProvider#total_local_storage_gb}
        */
        readonly totalLocalStorageGb?: TotalLocalStorageGbProperty;
        /**
        * vcpu_count block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#vcpu_count AwsCapacityProvider#vcpu_count}
        */
        readonly vcpuCount: VcpuCountProperty;
    }
    class InstanceRequirementsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InstanceRequirementsProperty | undefined;
        set internalValue(value: InstanceRequirementsProperty | undefined);
        private _acceleratorManufacturers?;
        get acceleratorManufacturers(): string[];
        set acceleratorManufacturers(value: string[]);
        resetAcceleratorManufacturers(): void;
        get acceleratorManufacturersInput(): string[] | undefined;
        private _acceleratorNames?;
        get acceleratorNames(): string[];
        set acceleratorNames(value: string[]);
        resetAcceleratorNames(): void;
        get acceleratorNamesInput(): string[] | undefined;
        private _acceleratorTypes?;
        get acceleratorTypes(): string[];
        set acceleratorTypes(value: string[]);
        resetAcceleratorTypes(): void;
        get acceleratorTypesInput(): string[] | undefined;
        private _allowedInstanceTypes?;
        get allowedInstanceTypes(): string[];
        set allowedInstanceTypes(value: string[]);
        resetAllowedInstanceTypes(): void;
        get allowedInstanceTypesInput(): string[] | undefined;
        private _bareMetal?;
        get bareMetal(): string;
        set bareMetal(value: string);
        resetBareMetal(): void;
        get bareMetalInput(): string | undefined;
        private _burstablePerformance?;
        get burstablePerformance(): string;
        set burstablePerformance(value: string);
        resetBurstablePerformance(): void;
        get burstablePerformanceInput(): string | undefined;
        private _cpuManufacturers?;
        get cpuManufacturers(): string[];
        set cpuManufacturers(value: string[]);
        resetCpuManufacturers(): void;
        get cpuManufacturersInput(): string[] | undefined;
        private _excludedInstanceTypes?;
        get excludedInstanceTypes(): string[];
        set excludedInstanceTypes(value: string[]);
        resetExcludedInstanceTypes(): void;
        get excludedInstanceTypesInput(): string[] | undefined;
        private _instanceGenerations?;
        get instanceGenerations(): string[];
        set instanceGenerations(value: string[]);
        resetInstanceGenerations(): void;
        get instanceGenerationsInput(): string[] | undefined;
        private _localStorage?;
        get localStorage(): string;
        set localStorage(value: string);
        resetLocalStorage(): void;
        get localStorageInput(): string | undefined;
        private _localStorageTypes?;
        get localStorageTypes(): string[];
        set localStorageTypes(value: string[]);
        resetLocalStorageTypes(): void;
        get localStorageTypesInput(): string[] | undefined;
        private _maxSpotPriceAsPercentageOfOptimalOnDemandPrice?;
        get maxSpotPriceAsPercentageOfOptimalOnDemandPrice(): number;
        set maxSpotPriceAsPercentageOfOptimalOnDemandPrice(value: number);
        resetMaxSpotPriceAsPercentageOfOptimalOnDemandPrice(): void;
        get maxSpotPriceAsPercentageOfOptimalOnDemandPriceInput(): number | undefined;
        private _onDemandMaxPricePercentageOverLowestPrice?;
        get onDemandMaxPricePercentageOverLowestPrice(): number;
        set onDemandMaxPricePercentageOverLowestPrice(value: number);
        resetOnDemandMaxPricePercentageOverLowestPrice(): void;
        get onDemandMaxPricePercentageOverLowestPriceInput(): number | undefined;
        private _requireHibernateSupport?;
        get requireHibernateSupport(): boolean | cdktn.IResolvable;
        set requireHibernateSupport(value: boolean | cdktn.IResolvable);
        resetRequireHibernateSupport(): void;
        get requireHibernateSupportInput(): boolean | cdktn.IResolvable | undefined;
        private _spotMaxPricePercentageOverLowestPrice?;
        get spotMaxPricePercentageOverLowestPrice(): number;
        set spotMaxPricePercentageOverLowestPrice(value: number);
        resetSpotMaxPricePercentageOverLowestPrice(): void;
        get spotMaxPricePercentageOverLowestPriceInput(): number | undefined;
        private _acceleratorCount;
        get acceleratorCount(): AcceleratorCountPropertyOutputReference;
        putAcceleratorCount(value: AcceleratorCountProperty): void;
        resetAcceleratorCount(): void;
        get acceleratorCountInput(): AcceleratorCountProperty | undefined;
        private _acceleratorTotalMemoryMib;
        get acceleratorTotalMemoryMib(): AcceleratorTotalMemoryMibPropertyOutputReference;
        putAcceleratorTotalMemoryMib(value: AcceleratorTotalMemoryMibProperty): void;
        resetAcceleratorTotalMemoryMib(): void;
        get acceleratorTotalMemoryMibInput(): AcceleratorTotalMemoryMibProperty | undefined;
        private _baselineEbsBandwidthMbps;
        get baselineEbsBandwidthMbps(): BaselineEbsBandwidthMbpsPropertyOutputReference;
        putBaselineEbsBandwidthMbps(value: BaselineEbsBandwidthMbpsProperty): void;
        resetBaselineEbsBandwidthMbps(): void;
        get baselineEbsBandwidthMbpsInput(): BaselineEbsBandwidthMbpsProperty | undefined;
        private _memoryGibPerVcpu;
        get memoryGibPerVcpu(): MemoryGibPerVcpuPropertyOutputReference;
        putMemoryGibPerVcpu(value: MemoryGibPerVcpuProperty): void;
        resetMemoryGibPerVcpu(): void;
        get memoryGibPerVcpuInput(): MemoryGibPerVcpuProperty | undefined;
        private _memoryMib;
        get memoryMib(): MemoryMibPropertyOutputReference;
        putMemoryMib(value: MemoryMibProperty): void;
        get memoryMibInput(): MemoryMibProperty | undefined;
        private _networkBandwidthGbps;
        get networkBandwidthGbps(): NetworkBandwidthGbpsPropertyOutputReference;
        putNetworkBandwidthGbps(value: NetworkBandwidthGbpsProperty): void;
        resetNetworkBandwidthGbps(): void;
        get networkBandwidthGbpsInput(): NetworkBandwidthGbpsProperty | undefined;
        private _networkInterfaceCount;
        get networkInterfaceCount(): NetworkInterfaceCountPropertyOutputReference;
        putNetworkInterfaceCount(value: NetworkInterfaceCountProperty): void;
        resetNetworkInterfaceCount(): void;
        get networkInterfaceCountInput(): NetworkInterfaceCountProperty | undefined;
        private _totalLocalStorageGb;
        get totalLocalStorageGb(): TotalLocalStorageGbPropertyOutputReference;
        putTotalLocalStorageGb(value: TotalLocalStorageGbProperty): void;
        resetTotalLocalStorageGb(): void;
        get totalLocalStorageGbInput(): TotalLocalStorageGbProperty | undefined;
        private _vcpuCount;
        get vcpuCount(): VcpuCountPropertyOutputReference;
        putVcpuCount(value: VcpuCountProperty): void;
        get vcpuCountInput(): VcpuCountProperty | undefined;
    }
    interface LocalStorageConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#use_local_storage AwsCapacityProvider#use_local_storage}
        */
        readonly useLocalStorage?: boolean | cdktn.IResolvable;
    }
    class LocalStorageConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LocalStorageConfigurationProperty | undefined;
        set internalValue(value: LocalStorageConfigurationProperty | undefined);
        private _useLocalStorage?;
        get useLocalStorage(): boolean | cdktn.IResolvable;
        set useLocalStorage(value: boolean | cdktn.IResolvable);
        resetUseLocalStorage(): void;
        get useLocalStorageInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface NetworkConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#security_groups AwsCapacityProvider#security_groups}
        */
        readonly securityGroups?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#subnets AwsCapacityProvider#subnets}
        */
        readonly subnets: string[];
    }
    class NetworkConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NetworkConfigurationProperty | undefined;
        set internalValue(value: NetworkConfigurationProperty | undefined);
        private _securityGroups?;
        get securityGroups(): string[];
        set securityGroups(value: string[]);
        resetSecurityGroups(): void;
        get securityGroupsInput(): string[] | undefined;
        private _subnets?;
        get subnets(): string[];
        set subnets(value: string[]);
        get subnetsInput(): string[] | undefined;
    }
    interface StorageConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#storage_size_gib AwsCapacityProvider#storage_size_gib}
        */
        readonly storageSizeGib: number;
    }
    class StorageConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StorageConfigurationProperty | undefined;
        set internalValue(value: StorageConfigurationProperty | undefined);
        private _storageSizeGib?;
        get storageSizeGib(): number;
        set storageSizeGib(value: number);
        get storageSizeGibInput(): number | undefined;
    }
    interface InstanceLaunchTemplateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#capacity_option_type AwsCapacityProvider#capacity_option_type}
        */
        readonly capacityOptionType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#ec2_instance_profile_arn AwsCapacityProvider#ec2_instance_profile_arn}
        */
        readonly ec2InstanceProfileArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#monitoring AwsCapacityProvider#monitoring}
        */
        readonly monitoring?: string;
        /**
        * capacity_reservations block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#capacity_reservations AwsCapacityProvider#capacity_reservations}
        */
        readonly capacityReservations?: CapacityReservationsProperty;
        /**
        * instance_requirements block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#instance_requirements AwsCapacityProvider#instance_requirements}
        */
        readonly instanceRequirements?: InstanceRequirementsProperty;
        /**
        * local_storage_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#local_storage_configuration AwsCapacityProvider#local_storage_configuration}
        */
        readonly localStorageConfiguration?: LocalStorageConfigurationProperty;
        /**
        * network_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#network_configuration AwsCapacityProvider#network_configuration}
        */
        readonly networkConfiguration: NetworkConfigurationProperty;
        /**
        * storage_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#storage_configuration AwsCapacityProvider#storage_configuration}
        */
        readonly storageConfiguration?: StorageConfigurationProperty;
    }
    class InstanceLaunchTemplatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InstanceLaunchTemplateProperty | undefined;
        set internalValue(value: InstanceLaunchTemplateProperty | undefined);
        private _capacityOptionType?;
        get capacityOptionType(): string;
        set capacityOptionType(value: string);
        resetCapacityOptionType(): void;
        get capacityOptionTypeInput(): string | undefined;
        private _ec2InstanceProfileArn?;
        get ec2InstanceProfileArn(): string;
        set ec2InstanceProfileArn(value: string);
        get ec2InstanceProfileArnInput(): string | undefined;
        private _monitoring?;
        get monitoring(): string;
        set monitoring(value: string);
        resetMonitoring(): void;
        get monitoringInput(): string | undefined;
        private _capacityReservations;
        get capacityReservations(): CapacityReservationsPropertyOutputReference;
        putCapacityReservations(value: CapacityReservationsProperty): void;
        resetCapacityReservations(): void;
        get capacityReservationsInput(): CapacityReservationsProperty | undefined;
        private _instanceRequirements;
        get instanceRequirements(): InstanceRequirementsPropertyOutputReference;
        putInstanceRequirements(value: InstanceRequirementsProperty): void;
        resetInstanceRequirements(): void;
        get instanceRequirementsInput(): InstanceRequirementsProperty | undefined;
        private _localStorageConfiguration;
        get localStorageConfiguration(): LocalStorageConfigurationPropertyOutputReference;
        putLocalStorageConfiguration(value: LocalStorageConfigurationProperty): void;
        resetLocalStorageConfiguration(): void;
        get localStorageConfigurationInput(): LocalStorageConfigurationProperty | undefined;
        private _networkConfiguration;
        get networkConfiguration(): NetworkConfigurationPropertyOutputReference;
        putNetworkConfiguration(value: NetworkConfigurationProperty): void;
        get networkConfigurationInput(): NetworkConfigurationProperty | undefined;
        private _storageConfiguration;
        get storageConfiguration(): StorageConfigurationPropertyOutputReference;
        putStorageConfiguration(value: StorageConfigurationProperty): void;
        resetStorageConfiguration(): void;
        get storageConfigurationInput(): StorageConfigurationProperty | undefined;
    }
    interface ManagedInstancesProviderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#infrastructure_role_arn AwsCapacityProvider#infrastructure_role_arn}
        */
        readonly infrastructureRoleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#propagate_tags AwsCapacityProvider#propagate_tags}
        */
        readonly propagateTags?: string;
        /**
        * infrastructure_optimization block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#infrastructure_optimization AwsCapacityProvider#infrastructure_optimization}
        */
        readonly infrastructureOptimization?: InfrastructureOptimizationProperty;
        /**
        * instance_launch_template block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecs_capacity_provider#instance_launch_template AwsCapacityProvider#instance_launch_template}
        */
        readonly instanceLaunchTemplate: InstanceLaunchTemplateProperty;
    }
    class ManagedInstancesProviderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ManagedInstancesProviderProperty | undefined;
        set internalValue(value: ManagedInstancesProviderProperty | undefined);
        private _infrastructureRoleArn?;
        get infrastructureRoleArn(): string;
        set infrastructureRoleArn(value: string);
        get infrastructureRoleArnInput(): string | undefined;
        private _propagateTags?;
        get propagateTags(): string;
        set propagateTags(value: string);
        resetPropagateTags(): void;
        get propagateTagsInput(): string | undefined;
        private _infrastructureOptimization;
        get infrastructureOptimization(): InfrastructureOptimizationPropertyOutputReference;
        putInfrastructureOptimization(value: InfrastructureOptimizationProperty): void;
        resetInfrastructureOptimization(): void;
        get infrastructureOptimizationInput(): InfrastructureOptimizationProperty | undefined;
        private _instanceLaunchTemplate;
        get instanceLaunchTemplate(): InstanceLaunchTemplatePropertyOutputReference;
        putInstanceLaunchTemplate(value: InstanceLaunchTemplateProperty): void;
        get instanceLaunchTemplateInput(): InstanceLaunchTemplateProperty | undefined;
    }
}
