import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfPlanConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssmcontacts_plan#contact_id DataTfPlan#contact_id}
    */
    readonly contactId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssmcontacts_plan#id DataTfPlan#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssmcontacts_plan#region DataTfPlan#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssmcontacts_plan aws_ssmcontacts_plan}
*/
export declare class DataTfPlan extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_ssmcontacts_plan";
    /**
    * Generates CDKTN code for importing a DataTfPlan resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfPlan to import
    * @param importFromId The id of the existing DataTfPlan that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssmcontacts_plan#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfPlan to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssmcontacts_plan aws_ssmcontacts_plan} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfPlanConfig
    */
    constructor(scope: Construct, id: string, config: DataTfPlanConfig);
    private _contactId?;
    get contactId(): string;
    set contactId(value: string);
    get contactIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _stage;
    get stage(): DataTfPlan.StagePropertyList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfPlanChannelTargetInfoPropertyToTerraform(struct?: DataTfPlan.ChannelTargetInfoProperty): any;
export declare function dataTfPlanChannelTargetInfoPropertyToHclTerraform(struct?: DataTfPlan.ChannelTargetInfoProperty): any;
export declare function dataTfPlanContactTargetInfoPropertyToTerraform(struct?: DataTfPlan.ContactTargetInfoProperty): any;
export declare function dataTfPlanContactTargetInfoPropertyToHclTerraform(struct?: DataTfPlan.ContactTargetInfoProperty): any;
export declare function dataTfPlanTargetPropertyToTerraform(struct?: DataTfPlan.TargetProperty): any;
export declare function dataTfPlanTargetPropertyToHclTerraform(struct?: DataTfPlan.TargetProperty): any;
export declare function dataTfPlanStagePropertyToTerraform(struct?: DataTfPlan.StageProperty): any;
export declare function dataTfPlanStagePropertyToHclTerraform(struct?: DataTfPlan.StageProperty): any;
export declare namespace DataTfPlan {
    interface ChannelTargetInfoProperty {
    }
    class ChannelTargetInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ChannelTargetInfoProperty | undefined;
        set internalValue(value: ChannelTargetInfoProperty | undefined);
        get contactChannelId(): string;
        get retryIntervalInMinutes(): number;
    }
    class ChannelTargetInfoPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ChannelTargetInfoPropertyOutputReference;
    }
    interface ContactTargetInfoProperty {
    }
    class ContactTargetInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ContactTargetInfoProperty | undefined;
        set internalValue(value: ContactTargetInfoProperty | undefined);
        get contactId(): string;
        get isEssential(): cdktn.IResolvable;
    }
    class ContactTargetInfoPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ContactTargetInfoPropertyOutputReference;
    }
    interface TargetProperty {
    }
    class TargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetProperty | undefined;
        set internalValue(value: TargetProperty | undefined);
        private _channelTargetInfo;
        get channelTargetInfo(): ChannelTargetInfoPropertyList;
        private _contactTargetInfo;
        get contactTargetInfo(): ContactTargetInfoPropertyList;
    }
    class TargetPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetPropertyOutputReference;
    }
    interface StageProperty {
    }
    class StagePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StageProperty | undefined;
        set internalValue(value: StageProperty | undefined);
        get durationInMinutes(): number;
        private _target;
        get target(): TargetPropertyList;
    }
    class StagePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StagePropertyOutputReference;
    }
}
