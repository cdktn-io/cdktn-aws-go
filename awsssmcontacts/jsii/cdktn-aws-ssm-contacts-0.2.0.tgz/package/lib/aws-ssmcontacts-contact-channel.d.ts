import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfContactChannelConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_contact_channel#contact_id TfContactChannel#contact_id}
    */
    readonly contactId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_contact_channel#id TfContactChannel#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_contact_channel#name TfContactChannel#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_contact_channel#region TfContactChannel#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_contact_channel#type TfContactChannel#type}
    */
    readonly type: string;
    /**
    * delivery_address block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_contact_channel#delivery_address TfContactChannel#delivery_address}
    */
    readonly deliveryAddress: TfContactChannel.DeliveryAddressProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_contact_channel aws_ssmcontacts_contact_channel}
*/
export declare class TfContactChannel extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ssmcontacts_contact_channel";
    /**
    * Generates CDKTN code for importing a TfContactChannel resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfContactChannel to import
    * @param importFromId The id of the existing TfContactChannel that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_contact_channel#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfContactChannel to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_contact_channel aws_ssmcontacts_contact_channel} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfContactChannelConfig
    */
    constructor(scope: Construct, id: string, config: TfContactChannelConfig);
    get activationStatus(): string;
    get arn(): string;
    private _contactId?;
    get contactId(): string;
    set contactId(value: string);
    get contactIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _deliveryAddress;
    get deliveryAddress(): TfContactChannel.DeliveryAddressPropertyOutputReference;
    putDeliveryAddress(value: TfContactChannel.DeliveryAddressProperty): void;
    get deliveryAddressInput(): TfContactChannel.DeliveryAddressProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfContactChannelDeliveryAddressPropertyToTerraform(struct?: TfContactChannel.DeliveryAddressPropertyOutputReference | TfContactChannel.DeliveryAddressProperty): any;
export declare function tfContactChannelDeliveryAddressPropertyToHclTerraform(struct?: TfContactChannel.DeliveryAddressPropertyOutputReference | TfContactChannel.DeliveryAddressProperty): any;
export declare namespace TfContactChannel {
    interface DeliveryAddressProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_contact_channel#simple_address TfContactChannel#simple_address}
        */
        readonly simpleAddress: string;
    }
    class DeliveryAddressPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DeliveryAddressProperty | undefined;
        set internalValue(value: DeliveryAddressProperty | undefined);
        private _simpleAddress?;
        get simpleAddress(): string;
        set simpleAddress(value: string);
        get simpleAddressInput(): string | undefined;
    }
}
