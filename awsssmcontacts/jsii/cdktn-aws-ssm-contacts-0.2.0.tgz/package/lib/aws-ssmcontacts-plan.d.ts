import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfPlanConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_plan#contact_id TfPlan#contact_id}
    */
    readonly contactId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_plan#id TfPlan#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_plan#region TfPlan#region}
    */
    readonly region?: string;
    /**
    * stage block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_plan#stage TfPlan#stage}
    */
    readonly stage: TfPlan.StageProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_plan aws_ssmcontacts_plan}
*/
export declare class TfPlan extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ssmcontacts_plan";
    /**
    * Generates CDKTN code for importing a TfPlan resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfPlan to import
    * @param importFromId The id of the existing TfPlan that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_plan#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfPlan to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_plan aws_ssmcontacts_plan} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfPlanConfig
    */
    constructor(scope: Construct, id: string, config: TfPlanConfig);
    private _contactId?;
    get contactId(): string;
    set contactId(value: string);
    get contactIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _stage;
    get stage(): TfPlan.StagePropertyList;
    putStage(value: TfPlan.StageProperty[] | cdktn.IResolvable): void;
    get stageInput(): cdktn.IResolvable | TfPlan.StageProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfPlanChannelTargetInfoPropertyToTerraform(struct?: TfPlan.ChannelTargetInfoPropertyOutputReference | TfPlan.ChannelTargetInfoProperty): any;
export declare function tfPlanChannelTargetInfoPropertyToHclTerraform(struct?: TfPlan.ChannelTargetInfoPropertyOutputReference | TfPlan.ChannelTargetInfoProperty): any;
export declare function tfPlanContactTargetInfoPropertyToTerraform(struct?: TfPlan.ContactTargetInfoPropertyOutputReference | TfPlan.ContactTargetInfoProperty): any;
export declare function tfPlanContactTargetInfoPropertyToHclTerraform(struct?: TfPlan.ContactTargetInfoPropertyOutputReference | TfPlan.ContactTargetInfoProperty): any;
export declare function tfPlanTargetPropertyToTerraform(struct?: TfPlan.TargetProperty | cdktn.IResolvable): any;
export declare function tfPlanTargetPropertyToHclTerraform(struct?: TfPlan.TargetProperty | cdktn.IResolvable): any;
export declare function tfPlanStagePropertyToTerraform(struct?: TfPlan.StageProperty | cdktn.IResolvable): any;
export declare function tfPlanStagePropertyToHclTerraform(struct?: TfPlan.StageProperty | cdktn.IResolvable): any;
export declare namespace TfPlan {
    interface ChannelTargetInfoProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_plan#contact_channel_id TfPlan#contact_channel_id}
        */
        readonly contactChannelId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_plan#retry_interval_in_minutes TfPlan#retry_interval_in_minutes}
        */
        readonly retryIntervalInMinutes?: number;
    }
    class ChannelTargetInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ChannelTargetInfoProperty | undefined;
        set internalValue(value: ChannelTargetInfoProperty | undefined);
        private _contactChannelId?;
        get contactChannelId(): string;
        set contactChannelId(value: string);
        get contactChannelIdInput(): string | undefined;
        private _retryIntervalInMinutes?;
        get retryIntervalInMinutes(): number;
        set retryIntervalInMinutes(value: number);
        resetRetryIntervalInMinutes(): void;
        get retryIntervalInMinutesInput(): number | undefined;
    }
    interface ContactTargetInfoProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_plan#contact_id TfPlan#contact_id}
        */
        readonly contactId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_plan#is_essential TfPlan#is_essential}
        */
        readonly isEssential: boolean | cdktn.IResolvable;
    }
    class ContactTargetInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ContactTargetInfoProperty | undefined;
        set internalValue(value: ContactTargetInfoProperty | undefined);
        private _contactId?;
        get contactId(): string;
        set contactId(value: string);
        resetContactId(): void;
        get contactIdInput(): string | undefined;
        private _isEssential?;
        get isEssential(): boolean | cdktn.IResolvable;
        set isEssential(value: boolean | cdktn.IResolvable);
        get isEssentialInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface TargetProperty {
        /**
        * channel_target_info block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_plan#channel_target_info TfPlan#channel_target_info}
        */
        readonly channelTargetInfo?: ChannelTargetInfoProperty;
        /**
        * contact_target_info block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_plan#contact_target_info TfPlan#contact_target_info}
        */
        readonly contactTargetInfo?: ContactTargetInfoProperty;
    }
    class TargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetProperty | cdktn.IResolvable | undefined);
        private _channelTargetInfo;
        get channelTargetInfo(): ChannelTargetInfoPropertyOutputReference;
        putChannelTargetInfo(value: ChannelTargetInfoProperty): void;
        resetChannelTargetInfo(): void;
        get channelTargetInfoInput(): ChannelTargetInfoProperty | undefined;
        private _contactTargetInfo;
        get contactTargetInfo(): ContactTargetInfoPropertyOutputReference;
        putContactTargetInfo(value: ContactTargetInfoProperty): void;
        resetContactTargetInfo(): void;
        get contactTargetInfoInput(): ContactTargetInfoProperty | undefined;
    }
    class TargetPropertyList extends cdktn.ComplexList {
        internalValue?: TargetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetPropertyOutputReference;
    }
    interface StageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_plan#duration_in_minutes TfPlan#duration_in_minutes}
        */
        readonly durationInMinutes: number;
        /**
        * target block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_plan#target TfPlan#target}
        */
        readonly target?: TargetProperty[] | cdktn.IResolvable;
    }
    class StagePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StageProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StageProperty | cdktn.IResolvable | undefined);
        private _durationInMinutes?;
        get durationInMinutes(): number;
        set durationInMinutes(value: number);
        get durationInMinutesInput(): number | undefined;
        private _target;
        get target(): TargetPropertyList;
        putTarget(value: TargetProperty[] | cdktn.IResolvable): void;
        resetTarget(): void;
        get targetInput(): cdktn.IResolvable | TargetProperty[] | undefined;
    }
    class StagePropertyList extends cdktn.ComplexList {
        internalValue?: StageProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StagePropertyOutputReference;
    }
}
