import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsSsmcontactsRotationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssmcontacts_rotation#arn DataAwsSsmcontactsRotation#arn}
    */
    readonly arn: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssmcontacts_rotation#region DataAwsSsmcontactsRotation#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssmcontacts_rotation aws_ssmcontacts_rotation}
*/
export declare class DataAwsSsmcontactsRotation extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_ssmcontacts_rotation";
    /**
    * Generates CDKTN code for importing a DataAwsSsmcontactsRotation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsSsmcontactsRotation to import
    * @param importFromId The id of the existing DataAwsSsmcontactsRotation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssmcontacts_rotation#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsSsmcontactsRotation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssmcontacts_rotation aws_ssmcontacts_rotation} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsSsmcontactsRotationConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsSsmcontactsRotationConfig);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    get arnInput(): string | undefined;
    get contactIds(): string[];
    get id(): string;
    get name(): string;
    private _recurrence;
    get recurrence(): DataAwsSsmcontactsRotation.RecurrencePropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get startTime(): string;
    private _tags;
    get tags(): cdktn.StringMap;
    get timeZoneId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsSsmcontactsRotationDailySettingsPropertyToTerraform(struct?: DataAwsSsmcontactsRotation.DailySettingsProperty): any;
export declare function dataAwsSsmcontactsRotationDailySettingsPropertyToHclTerraform(struct?: DataAwsSsmcontactsRotation.DailySettingsProperty): any;
export declare function dataAwsSsmcontactsRotationRecurrenceMonthlySettingsHandOffTimePropertyToTerraform(struct?: DataAwsSsmcontactsRotation.RecurrenceMonthlySettingsHandOffTimeProperty): any;
export declare function dataAwsSsmcontactsRotationRecurrenceMonthlySettingsHandOffTimePropertyToHclTerraform(struct?: DataAwsSsmcontactsRotation.RecurrenceMonthlySettingsHandOffTimeProperty): any;
export declare function dataAwsSsmcontactsRotationMonthlySettingsPropertyToTerraform(struct?: DataAwsSsmcontactsRotation.MonthlySettingsProperty): any;
export declare function dataAwsSsmcontactsRotationMonthlySettingsPropertyToHclTerraform(struct?: DataAwsSsmcontactsRotation.MonthlySettingsProperty): any;
export declare function dataAwsSsmcontactsRotationEndPropertyToTerraform(struct?: DataAwsSsmcontactsRotation.EndProperty): any;
export declare function dataAwsSsmcontactsRotationEndPropertyToHclTerraform(struct?: DataAwsSsmcontactsRotation.EndProperty): any;
export declare function dataAwsSsmcontactsRotationStartPropertyToTerraform(struct?: DataAwsSsmcontactsRotation.StartProperty): any;
export declare function dataAwsSsmcontactsRotationStartPropertyToHclTerraform(struct?: DataAwsSsmcontactsRotation.StartProperty): any;
export declare function dataAwsSsmcontactsRotationCoverageTimesPropertyToTerraform(struct?: DataAwsSsmcontactsRotation.CoverageTimesProperty): any;
export declare function dataAwsSsmcontactsRotationCoverageTimesPropertyToHclTerraform(struct?: DataAwsSsmcontactsRotation.CoverageTimesProperty): any;
export declare function dataAwsSsmcontactsRotationShiftCoveragesPropertyToTerraform(struct?: DataAwsSsmcontactsRotation.ShiftCoveragesProperty): any;
export declare function dataAwsSsmcontactsRotationShiftCoveragesPropertyToHclTerraform(struct?: DataAwsSsmcontactsRotation.ShiftCoveragesProperty): any;
export declare function dataAwsSsmcontactsRotationRecurrenceWeeklySettingsHandOffTimePropertyToTerraform(struct?: DataAwsSsmcontactsRotation.RecurrenceWeeklySettingsHandOffTimeProperty): any;
export declare function dataAwsSsmcontactsRotationRecurrenceWeeklySettingsHandOffTimePropertyToHclTerraform(struct?: DataAwsSsmcontactsRotation.RecurrenceWeeklySettingsHandOffTimeProperty): any;
export declare function dataAwsSsmcontactsRotationWeeklySettingsPropertyToTerraform(struct?: DataAwsSsmcontactsRotation.WeeklySettingsProperty): any;
export declare function dataAwsSsmcontactsRotationWeeklySettingsPropertyToHclTerraform(struct?: DataAwsSsmcontactsRotation.WeeklySettingsProperty): any;
export declare function dataAwsSsmcontactsRotationRecurrencePropertyToTerraform(struct?: DataAwsSsmcontactsRotation.RecurrenceProperty): any;
export declare function dataAwsSsmcontactsRotationRecurrencePropertyToHclTerraform(struct?: DataAwsSsmcontactsRotation.RecurrenceProperty): any;
export declare namespace DataAwsSsmcontactsRotation {
    interface DailySettingsProperty {
    }
    class DailySettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DailySettingsProperty | undefined;
        set internalValue(value: DailySettingsProperty | undefined);
        get hourOfDay(): number;
        get minuteOfHour(): number;
    }
    class DailySettingsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DailySettingsPropertyOutputReference;
    }
    interface RecurrenceMonthlySettingsHandOffTimeProperty {
    }
    class RecurrenceMonthlySettingsHandOffTimePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RecurrenceMonthlySettingsHandOffTimeProperty | undefined;
        set internalValue(value: RecurrenceMonthlySettingsHandOffTimeProperty | undefined);
        get hourOfDay(): number;
        get minuteOfHour(): number;
    }
    class RecurrenceMonthlySettingsHandOffTimePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RecurrenceMonthlySettingsHandOffTimePropertyOutputReference;
    }
    interface MonthlySettingsProperty {
    }
    class MonthlySettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MonthlySettingsProperty | undefined;
        set internalValue(value: MonthlySettingsProperty | undefined);
        get dayOfMonth(): number;
        private _handOffTime;
        get handOffTime(): RecurrenceMonthlySettingsHandOffTimePropertyList;
    }
    class MonthlySettingsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MonthlySettingsPropertyOutputReference;
    }
    interface EndProperty {
    }
    class EndPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EndProperty | undefined;
        set internalValue(value: EndProperty | undefined);
        get hourOfDay(): number;
        get minuteOfHour(): number;
    }
    class EndPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EndPropertyOutputReference;
    }
    interface StartProperty {
    }
    class StartPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StartProperty | undefined;
        set internalValue(value: StartProperty | undefined);
        get hourOfDay(): number;
        get minuteOfHour(): number;
    }
    class StartPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StartPropertyOutputReference;
    }
    interface CoverageTimesProperty {
    }
    class CoverageTimesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CoverageTimesProperty | undefined;
        set internalValue(value: CoverageTimesProperty | undefined);
        private _end;
        get end(): EndPropertyList;
        private _start;
        get start(): StartPropertyList;
    }
    class CoverageTimesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CoverageTimesPropertyOutputReference;
    }
    interface ShiftCoveragesProperty {
    }
    class ShiftCoveragesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ShiftCoveragesProperty | undefined;
        set internalValue(value: ShiftCoveragesProperty | undefined);
        private _coverageTimes;
        get coverageTimes(): CoverageTimesPropertyList;
        get mapBlockKey(): string;
    }
    class ShiftCoveragesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ShiftCoveragesPropertyOutputReference;
    }
    interface RecurrenceWeeklySettingsHandOffTimeProperty {
    }
    class RecurrenceWeeklySettingsHandOffTimePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RecurrenceWeeklySettingsHandOffTimeProperty | undefined;
        set internalValue(value: RecurrenceWeeklySettingsHandOffTimeProperty | undefined);
        get hourOfDay(): number;
        get minuteOfHour(): number;
    }
    class RecurrenceWeeklySettingsHandOffTimePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RecurrenceWeeklySettingsHandOffTimePropertyOutputReference;
    }
    interface WeeklySettingsProperty {
    }
    class WeeklySettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WeeklySettingsProperty | undefined;
        set internalValue(value: WeeklySettingsProperty | undefined);
        get dayOfWeek(): string;
        private _handOffTime;
        get handOffTime(): RecurrenceWeeklySettingsHandOffTimePropertyList;
    }
    class WeeklySettingsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WeeklySettingsPropertyOutputReference;
    }
    interface RecurrenceProperty {
    }
    class RecurrencePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RecurrenceProperty | undefined;
        set internalValue(value: RecurrenceProperty | undefined);
        private _dailySettings;
        get dailySettings(): DailySettingsPropertyList;
        private _monthlySettings;
        get monthlySettings(): MonthlySettingsPropertyList;
        get numberOfOnCalls(): number;
        get recurrenceMultiplier(): number;
        private _shiftCoverages;
        get shiftCoverages(): ShiftCoveragesPropertyList;
        private _weeklySettings;
        get weeklySettings(): WeeklySettingsPropertyList;
    }
    class RecurrencePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RecurrencePropertyOutputReference;
    }
}
