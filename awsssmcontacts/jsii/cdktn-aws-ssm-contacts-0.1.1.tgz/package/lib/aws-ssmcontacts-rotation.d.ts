import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSsmcontactsRotationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_rotation#contact_ids AwsSsmcontactsRotation#contact_ids}
    */
    readonly contactIds: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_rotation#name AwsSsmcontactsRotation#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_rotation#region AwsSsmcontactsRotation#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_rotation#start_time AwsSsmcontactsRotation#start_time}
    */
    readonly startTime?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_rotation#tags AwsSsmcontactsRotation#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_rotation#time_zone_id AwsSsmcontactsRotation#time_zone_id}
    */
    readonly timeZoneId: string;
    /**
    * recurrence block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_rotation#recurrence AwsSsmcontactsRotation#recurrence}
    */
    readonly recurrence?: AwsSsmcontactsRotation.RecurrenceProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_rotation aws_ssmcontacts_rotation}
*/
export declare class AwsSsmcontactsRotation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ssmcontacts_rotation";
    /**
    * Generates CDKTN code for importing a AwsSsmcontactsRotation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSsmcontactsRotation to import
    * @param importFromId The id of the existing AwsSsmcontactsRotation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_rotation#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSsmcontactsRotation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_rotation aws_ssmcontacts_rotation} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSsmcontactsRotationConfig
    */
    constructor(scope: Construct, id: string, config: AwsSsmcontactsRotationConfig);
    get arn(): string;
    private _contactIds?;
    get contactIds(): string[];
    set contactIds(value: string[]);
    get contactIdsInput(): string[] | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _startTime?;
    get startTime(): string;
    set startTime(value: string);
    resetStartTime(): void;
    get startTimeInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _timeZoneId?;
    get timeZoneId(): string;
    set timeZoneId(value: string);
    get timeZoneIdInput(): string | undefined;
    private _recurrence;
    get recurrence(): AwsSsmcontactsRotation.RecurrencePropertyList;
    putRecurrence(value: AwsSsmcontactsRotation.RecurrenceProperty[] | cdktn.IResolvable): void;
    resetRecurrence(): void;
    get recurrenceInput(): cdktn.IResolvable | AwsSsmcontactsRotation.RecurrenceProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSsmcontactsRotationDailySettingsPropertyToTerraform(struct?: AwsSsmcontactsRotation.DailySettingsProperty | cdktn.IResolvable): any;
export declare function awsSsmcontactsRotationDailySettingsPropertyToHclTerraform(struct?: AwsSsmcontactsRotation.DailySettingsProperty | cdktn.IResolvable): any;
export declare function awsSsmcontactsRotationRecurrenceMonthlySettingsHandOffTimePropertyToTerraform(struct?: AwsSsmcontactsRotation.RecurrenceMonthlySettingsHandOffTimeProperty | cdktn.IResolvable): any;
export declare function awsSsmcontactsRotationRecurrenceMonthlySettingsHandOffTimePropertyToHclTerraform(struct?: AwsSsmcontactsRotation.RecurrenceMonthlySettingsHandOffTimeProperty | cdktn.IResolvable): any;
export declare function awsSsmcontactsRotationMonthlySettingsPropertyToTerraform(struct?: AwsSsmcontactsRotation.MonthlySettingsProperty | cdktn.IResolvable): any;
export declare function awsSsmcontactsRotationMonthlySettingsPropertyToHclTerraform(struct?: AwsSsmcontactsRotation.MonthlySettingsProperty | cdktn.IResolvable): any;
export declare function awsSsmcontactsRotationEndPropertyToTerraform(struct?: AwsSsmcontactsRotation.EndProperty | cdktn.IResolvable): any;
export declare function awsSsmcontactsRotationEndPropertyToHclTerraform(struct?: AwsSsmcontactsRotation.EndProperty | cdktn.IResolvable): any;
export declare function awsSsmcontactsRotationStartPropertyToTerraform(struct?: AwsSsmcontactsRotation.StartProperty | cdktn.IResolvable): any;
export declare function awsSsmcontactsRotationStartPropertyToHclTerraform(struct?: AwsSsmcontactsRotation.StartProperty | cdktn.IResolvable): any;
export declare function awsSsmcontactsRotationCoverageTimesPropertyToTerraform(struct?: AwsSsmcontactsRotation.CoverageTimesProperty | cdktn.IResolvable): any;
export declare function awsSsmcontactsRotationCoverageTimesPropertyToHclTerraform(struct?: AwsSsmcontactsRotation.CoverageTimesProperty | cdktn.IResolvable): any;
export declare function awsSsmcontactsRotationShiftCoveragesPropertyToTerraform(struct?: AwsSsmcontactsRotation.ShiftCoveragesProperty | cdktn.IResolvable): any;
export declare function awsSsmcontactsRotationShiftCoveragesPropertyToHclTerraform(struct?: AwsSsmcontactsRotation.ShiftCoveragesProperty | cdktn.IResolvable): any;
export declare function awsSsmcontactsRotationRecurrenceWeeklySettingsHandOffTimePropertyToTerraform(struct?: AwsSsmcontactsRotation.RecurrenceWeeklySettingsHandOffTimeProperty | cdktn.IResolvable): any;
export declare function awsSsmcontactsRotationRecurrenceWeeklySettingsHandOffTimePropertyToHclTerraform(struct?: AwsSsmcontactsRotation.RecurrenceWeeklySettingsHandOffTimeProperty | cdktn.IResolvable): any;
export declare function awsSsmcontactsRotationWeeklySettingsPropertyToTerraform(struct?: AwsSsmcontactsRotation.WeeklySettingsProperty | cdktn.IResolvable): any;
export declare function awsSsmcontactsRotationWeeklySettingsPropertyToHclTerraform(struct?: AwsSsmcontactsRotation.WeeklySettingsProperty | cdktn.IResolvable): any;
export declare function awsSsmcontactsRotationRecurrencePropertyToTerraform(struct?: AwsSsmcontactsRotation.RecurrenceProperty | cdktn.IResolvable): any;
export declare function awsSsmcontactsRotationRecurrencePropertyToHclTerraform(struct?: AwsSsmcontactsRotation.RecurrenceProperty | cdktn.IResolvable): any;
export declare namespace AwsSsmcontactsRotation {
    interface DailySettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_rotation#hour_of_day AwsSsmcontactsRotation#hour_of_day}
        */
        readonly hourOfDay: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_rotation#minute_of_hour AwsSsmcontactsRotation#minute_of_hour}
        */
        readonly minuteOfHour: number;
    }
    class DailySettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DailySettingsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DailySettingsProperty | cdktn.IResolvable | undefined);
        private _hourOfDay?;
        get hourOfDay(): number;
        set hourOfDay(value: number);
        get hourOfDayInput(): number | undefined;
        private _minuteOfHour?;
        get minuteOfHour(): number;
        set minuteOfHour(value: number);
        get minuteOfHourInput(): number | undefined;
    }
    class DailySettingsPropertyList extends cdktn.ComplexList {
        internalValue?: DailySettingsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DailySettingsPropertyOutputReference;
    }
    interface RecurrenceMonthlySettingsHandOffTimeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_rotation#hour_of_day AwsSsmcontactsRotation#hour_of_day}
        */
        readonly hourOfDay: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_rotation#minute_of_hour AwsSsmcontactsRotation#minute_of_hour}
        */
        readonly minuteOfHour: number;
    }
    class RecurrenceMonthlySettingsHandOffTimePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RecurrenceMonthlySettingsHandOffTimeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RecurrenceMonthlySettingsHandOffTimeProperty | cdktn.IResolvable | undefined);
        private _hourOfDay?;
        get hourOfDay(): number;
        set hourOfDay(value: number);
        get hourOfDayInput(): number | undefined;
        private _minuteOfHour?;
        get minuteOfHour(): number;
        set minuteOfHour(value: number);
        get minuteOfHourInput(): number | undefined;
    }
    class RecurrenceMonthlySettingsHandOffTimePropertyList extends cdktn.ComplexList {
        internalValue?: RecurrenceMonthlySettingsHandOffTimeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RecurrenceMonthlySettingsHandOffTimePropertyOutputReference;
    }
    interface MonthlySettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_rotation#day_of_month AwsSsmcontactsRotation#day_of_month}
        */
        readonly dayOfMonth: number;
        /**
        * hand_off_time block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_rotation#hand_off_time AwsSsmcontactsRotation#hand_off_time}
        */
        readonly handOffTime?: RecurrenceMonthlySettingsHandOffTimeProperty[] | cdktn.IResolvable;
    }
    class MonthlySettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MonthlySettingsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MonthlySettingsProperty | cdktn.IResolvable | undefined);
        private _dayOfMonth?;
        get dayOfMonth(): number;
        set dayOfMonth(value: number);
        get dayOfMonthInput(): number | undefined;
        private _handOffTime;
        get handOffTime(): RecurrenceMonthlySettingsHandOffTimePropertyList;
        putHandOffTime(value: RecurrenceMonthlySettingsHandOffTimeProperty[] | cdktn.IResolvable): void;
        resetHandOffTime(): void;
        get handOffTimeInput(): cdktn.IResolvable | RecurrenceMonthlySettingsHandOffTimeProperty[] | undefined;
    }
    class MonthlySettingsPropertyList extends cdktn.ComplexList {
        internalValue?: MonthlySettingsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MonthlySettingsPropertyOutputReference;
    }
    interface EndProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_rotation#hour_of_day AwsSsmcontactsRotation#hour_of_day}
        */
        readonly hourOfDay: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_rotation#minute_of_hour AwsSsmcontactsRotation#minute_of_hour}
        */
        readonly minuteOfHour: number;
    }
    class EndPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EndProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EndProperty | cdktn.IResolvable | undefined);
        private _hourOfDay?;
        get hourOfDay(): number;
        set hourOfDay(value: number);
        get hourOfDayInput(): number | undefined;
        private _minuteOfHour?;
        get minuteOfHour(): number;
        set minuteOfHour(value: number);
        get minuteOfHourInput(): number | undefined;
    }
    class EndPropertyList extends cdktn.ComplexList {
        internalValue?: EndProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EndPropertyOutputReference;
    }
    interface StartProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_rotation#hour_of_day AwsSsmcontactsRotation#hour_of_day}
        */
        readonly hourOfDay: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_rotation#minute_of_hour AwsSsmcontactsRotation#minute_of_hour}
        */
        readonly minuteOfHour: number;
    }
    class StartPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StartProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StartProperty | cdktn.IResolvable | undefined);
        private _hourOfDay?;
        get hourOfDay(): number;
        set hourOfDay(value: number);
        get hourOfDayInput(): number | undefined;
        private _minuteOfHour?;
        get minuteOfHour(): number;
        set minuteOfHour(value: number);
        get minuteOfHourInput(): number | undefined;
    }
    class StartPropertyList extends cdktn.ComplexList {
        internalValue?: StartProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StartPropertyOutputReference;
    }
    interface CoverageTimesProperty {
        /**
        * end block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_rotation#end AwsSsmcontactsRotation#end}
        */
        readonly end?: EndProperty[] | cdktn.IResolvable;
        /**
        * start block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_rotation#start AwsSsmcontactsRotation#start}
        */
        readonly start?: StartProperty[] | cdktn.IResolvable;
    }
    class CoverageTimesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CoverageTimesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CoverageTimesProperty | cdktn.IResolvable | undefined);
        private _end;
        get end(): EndPropertyList;
        putEnd(value: EndProperty[] | cdktn.IResolvable): void;
        resetEnd(): void;
        get endInput(): cdktn.IResolvable | EndProperty[] | undefined;
        private _start;
        get start(): StartPropertyList;
        putStart(value: StartProperty[] | cdktn.IResolvable): void;
        resetStart(): void;
        get startInput(): cdktn.IResolvable | StartProperty[] | undefined;
    }
    class CoverageTimesPropertyList extends cdktn.ComplexList {
        internalValue?: CoverageTimesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CoverageTimesPropertyOutputReference;
    }
    interface ShiftCoveragesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_rotation#map_block_key AwsSsmcontactsRotation#map_block_key}
        */
        readonly mapBlockKey: string;
        /**
        * coverage_times block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_rotation#coverage_times AwsSsmcontactsRotation#coverage_times}
        */
        readonly coverageTimes?: CoverageTimesProperty[] | cdktn.IResolvable;
    }
    class ShiftCoveragesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ShiftCoveragesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ShiftCoveragesProperty | cdktn.IResolvable | undefined);
        private _mapBlockKey?;
        get mapBlockKey(): string;
        set mapBlockKey(value: string);
        get mapBlockKeyInput(): string | undefined;
        private _coverageTimes;
        get coverageTimes(): CoverageTimesPropertyList;
        putCoverageTimes(value: CoverageTimesProperty[] | cdktn.IResolvable): void;
        resetCoverageTimes(): void;
        get coverageTimesInput(): cdktn.IResolvable | CoverageTimesProperty[] | undefined;
    }
    class ShiftCoveragesPropertyList extends cdktn.ComplexList {
        internalValue?: ShiftCoveragesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ShiftCoveragesPropertyOutputReference;
    }
    interface RecurrenceWeeklySettingsHandOffTimeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_rotation#hour_of_day AwsSsmcontactsRotation#hour_of_day}
        */
        readonly hourOfDay: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_rotation#minute_of_hour AwsSsmcontactsRotation#minute_of_hour}
        */
        readonly minuteOfHour: number;
    }
    class RecurrenceWeeklySettingsHandOffTimePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RecurrenceWeeklySettingsHandOffTimeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RecurrenceWeeklySettingsHandOffTimeProperty | cdktn.IResolvable | undefined);
        private _hourOfDay?;
        get hourOfDay(): number;
        set hourOfDay(value: number);
        get hourOfDayInput(): number | undefined;
        private _minuteOfHour?;
        get minuteOfHour(): number;
        set minuteOfHour(value: number);
        get minuteOfHourInput(): number | undefined;
    }
    class RecurrenceWeeklySettingsHandOffTimePropertyList extends cdktn.ComplexList {
        internalValue?: RecurrenceWeeklySettingsHandOffTimeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RecurrenceWeeklySettingsHandOffTimePropertyOutputReference;
    }
    interface WeeklySettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_rotation#day_of_week AwsSsmcontactsRotation#day_of_week}
        */
        readonly dayOfWeek: string;
        /**
        * hand_off_time block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_rotation#hand_off_time AwsSsmcontactsRotation#hand_off_time}
        */
        readonly handOffTime?: RecurrenceWeeklySettingsHandOffTimeProperty[] | cdktn.IResolvable;
    }
    class WeeklySettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WeeklySettingsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WeeklySettingsProperty | cdktn.IResolvable | undefined);
        private _dayOfWeek?;
        get dayOfWeek(): string;
        set dayOfWeek(value: string);
        get dayOfWeekInput(): string | undefined;
        private _handOffTime;
        get handOffTime(): RecurrenceWeeklySettingsHandOffTimePropertyList;
        putHandOffTime(value: RecurrenceWeeklySettingsHandOffTimeProperty[] | cdktn.IResolvable): void;
        resetHandOffTime(): void;
        get handOffTimeInput(): cdktn.IResolvable | RecurrenceWeeklySettingsHandOffTimeProperty[] | undefined;
    }
    class WeeklySettingsPropertyList extends cdktn.ComplexList {
        internalValue?: WeeklySettingsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WeeklySettingsPropertyOutputReference;
    }
    interface RecurrenceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_rotation#number_of_on_calls AwsSsmcontactsRotation#number_of_on_calls}
        */
        readonly numberOfOnCalls: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_rotation#recurrence_multiplier AwsSsmcontactsRotation#recurrence_multiplier}
        */
        readonly recurrenceMultiplier: number;
        /**
        * daily_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_rotation#daily_settings AwsSsmcontactsRotation#daily_settings}
        */
        readonly dailySettings?: DailySettingsProperty[] | cdktn.IResolvable;
        /**
        * monthly_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_rotation#monthly_settings AwsSsmcontactsRotation#monthly_settings}
        */
        readonly monthlySettings?: MonthlySettingsProperty[] | cdktn.IResolvable;
        /**
        * shift_coverages block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_rotation#shift_coverages AwsSsmcontactsRotation#shift_coverages}
        */
        readonly shiftCoverages?: ShiftCoveragesProperty[] | cdktn.IResolvable;
        /**
        * weekly_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssmcontacts_rotation#weekly_settings AwsSsmcontactsRotation#weekly_settings}
        */
        readonly weeklySettings?: WeeklySettingsProperty[] | cdktn.IResolvable;
    }
    class RecurrencePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RecurrenceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RecurrenceProperty | cdktn.IResolvable | undefined);
        private _numberOfOnCalls?;
        get numberOfOnCalls(): number;
        set numberOfOnCalls(value: number);
        get numberOfOnCallsInput(): number | undefined;
        private _recurrenceMultiplier?;
        get recurrenceMultiplier(): number;
        set recurrenceMultiplier(value: number);
        get recurrenceMultiplierInput(): number | undefined;
        private _dailySettings;
        get dailySettings(): DailySettingsPropertyList;
        putDailySettings(value: DailySettingsProperty[] | cdktn.IResolvable): void;
        resetDailySettings(): void;
        get dailySettingsInput(): cdktn.IResolvable | DailySettingsProperty[] | undefined;
        private _monthlySettings;
        get monthlySettings(): MonthlySettingsPropertyList;
        putMonthlySettings(value: MonthlySettingsProperty[] | cdktn.IResolvable): void;
        resetMonthlySettings(): void;
        get monthlySettingsInput(): cdktn.IResolvable | MonthlySettingsProperty[] | undefined;
        private _shiftCoverages;
        get shiftCoverages(): ShiftCoveragesPropertyList;
        putShiftCoverages(value: ShiftCoveragesProperty[] | cdktn.IResolvable): void;
        resetShiftCoverages(): void;
        get shiftCoveragesInput(): cdktn.IResolvable | ShiftCoveragesProperty[] | undefined;
        private _weeklySettings;
        get weeklySettings(): WeeklySettingsPropertyList;
        putWeeklySettings(value: WeeklySettingsProperty[] | cdktn.IResolvable): void;
        resetWeeklySettings(): void;
        get weeklySettingsInput(): cdktn.IResolvable | WeeklySettingsProperty[] | undefined;
    }
    class RecurrencePropertyList extends cdktn.ComplexList {
        internalValue?: RecurrenceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RecurrencePropertyOutputReference;
    }
}
