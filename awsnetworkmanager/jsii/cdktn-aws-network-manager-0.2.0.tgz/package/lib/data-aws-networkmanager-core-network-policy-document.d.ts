import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfCoreNetworkPolicyDocumentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#id DataTfCoreNetworkPolicyDocument#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#version DataTfCoreNetworkPolicyDocument#version}
    */
    readonly version?: string;
    /**
    * attachment_policies block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#attachment_policies DataTfCoreNetworkPolicyDocument#attachment_policies}
    */
    readonly attachmentPolicies?: DataTfCoreNetworkPolicyDocument.AttachmentPoliciesProperty[] | cdktn.IResolvable;
    /**
    * attachment_routing_policy_rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#attachment_routing_policy_rules DataTfCoreNetworkPolicyDocument#attachment_routing_policy_rules}
    */
    readonly attachmentRoutingPolicyRules?: DataTfCoreNetworkPolicyDocument.AttachmentRoutingPolicyRulesProperty[] | cdktn.IResolvable;
    /**
    * core_network_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#core_network_configuration DataTfCoreNetworkPolicyDocument#core_network_configuration}
    */
    readonly coreNetworkConfiguration: DataTfCoreNetworkPolicyDocument.CoreNetworkConfigurationProperty[] | cdktn.IResolvable;
    /**
    * network_function_groups block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#network_function_groups DataTfCoreNetworkPolicyDocument#network_function_groups}
    */
    readonly networkFunctionGroups?: DataTfCoreNetworkPolicyDocument.NetworkFunctionGroupsProperty[] | cdktn.IResolvable;
    /**
    * routing_policies block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#routing_policies DataTfCoreNetworkPolicyDocument#routing_policies}
    */
    readonly routingPolicies?: DataTfCoreNetworkPolicyDocument.RoutingPoliciesProperty[] | cdktn.IResolvable;
    /**
    * segment_actions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#segment_actions DataTfCoreNetworkPolicyDocument#segment_actions}
    */
    readonly segmentActions?: DataTfCoreNetworkPolicyDocument.SegmentActionsProperty[] | cdktn.IResolvable;
    /**
    * segments block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#segments DataTfCoreNetworkPolicyDocument#segments}
    */
    readonly segments: DataTfCoreNetworkPolicyDocument.SegmentsProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document aws_networkmanager_core_network_policy_document}
*/
export declare class DataTfCoreNetworkPolicyDocument extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_networkmanager_core_network_policy_document";
    /**
    * Generates CDKTN code for importing a DataTfCoreNetworkPolicyDocument resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfCoreNetworkPolicyDocument to import
    * @param importFromId The id of the existing DataTfCoreNetworkPolicyDocument that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfCoreNetworkPolicyDocument to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document aws_networkmanager_core_network_policy_document} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfCoreNetworkPolicyDocumentConfig
    */
    constructor(scope: Construct, id: string, config: DataTfCoreNetworkPolicyDocumentConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get json(): string;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
    private _attachmentPolicies;
    get attachmentPolicies(): DataTfCoreNetworkPolicyDocument.AttachmentPoliciesPropertyList;
    putAttachmentPolicies(value: DataTfCoreNetworkPolicyDocument.AttachmentPoliciesProperty[] | cdktn.IResolvable): void;
    resetAttachmentPolicies(): void;
    get attachmentPoliciesInput(): cdktn.IResolvable | DataTfCoreNetworkPolicyDocument.AttachmentPoliciesProperty[] | undefined;
    private _attachmentRoutingPolicyRules;
    get attachmentRoutingPolicyRules(): DataTfCoreNetworkPolicyDocument.AttachmentRoutingPolicyRulesPropertyList;
    putAttachmentRoutingPolicyRules(value: DataTfCoreNetworkPolicyDocument.AttachmentRoutingPolicyRulesProperty[] | cdktn.IResolvable): void;
    resetAttachmentRoutingPolicyRules(): void;
    get attachmentRoutingPolicyRulesInput(): cdktn.IResolvable | DataTfCoreNetworkPolicyDocument.AttachmentRoutingPolicyRulesProperty[] | undefined;
    private _coreNetworkConfiguration;
    get coreNetworkConfiguration(): DataTfCoreNetworkPolicyDocument.CoreNetworkConfigurationPropertyList;
    putCoreNetworkConfiguration(value: DataTfCoreNetworkPolicyDocument.CoreNetworkConfigurationProperty[] | cdktn.IResolvable): void;
    get coreNetworkConfigurationInput(): cdktn.IResolvable | DataTfCoreNetworkPolicyDocument.CoreNetworkConfigurationProperty[] | undefined;
    private _networkFunctionGroups;
    get networkFunctionGroups(): DataTfCoreNetworkPolicyDocument.NetworkFunctionGroupsPropertyList;
    putNetworkFunctionGroups(value: DataTfCoreNetworkPolicyDocument.NetworkFunctionGroupsProperty[] | cdktn.IResolvable): void;
    resetNetworkFunctionGroups(): void;
    get networkFunctionGroupsInput(): cdktn.IResolvable | DataTfCoreNetworkPolicyDocument.NetworkFunctionGroupsProperty[] | undefined;
    private _routingPolicies;
    get routingPolicies(): DataTfCoreNetworkPolicyDocument.RoutingPoliciesPropertyList;
    putRoutingPolicies(value: DataTfCoreNetworkPolicyDocument.RoutingPoliciesProperty[] | cdktn.IResolvable): void;
    resetRoutingPolicies(): void;
    get routingPoliciesInput(): cdktn.IResolvable | DataTfCoreNetworkPolicyDocument.RoutingPoliciesProperty[] | undefined;
    private _segmentActions;
    get segmentActions(): DataTfCoreNetworkPolicyDocument.SegmentActionsPropertyList;
    putSegmentActions(value: DataTfCoreNetworkPolicyDocument.SegmentActionsProperty[] | cdktn.IResolvable): void;
    resetSegmentActions(): void;
    get segmentActionsInput(): cdktn.IResolvable | DataTfCoreNetworkPolicyDocument.SegmentActionsProperty[] | undefined;
    private _segments;
    get segments(): DataTfCoreNetworkPolicyDocument.SegmentsPropertyList;
    putSegments(value: DataTfCoreNetworkPolicyDocument.SegmentsProperty[] | cdktn.IResolvable): void;
    get segmentsInput(): cdktn.IResolvable | DataTfCoreNetworkPolicyDocument.SegmentsProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfCoreNetworkPolicyDocumentAttachmentPoliciesActionPropertyToTerraform(struct?: DataTfCoreNetworkPolicyDocument.AttachmentPoliciesActionPropertyOutputReference | DataTfCoreNetworkPolicyDocument.AttachmentPoliciesActionProperty): any;
export declare function dataTfCoreNetworkPolicyDocumentAttachmentPoliciesActionPropertyToHclTerraform(struct?: DataTfCoreNetworkPolicyDocument.AttachmentPoliciesActionPropertyOutputReference | DataTfCoreNetworkPolicyDocument.AttachmentPoliciesActionProperty): any;
export declare function dataTfCoreNetworkPolicyDocumentAttachmentPoliciesConditionsPropertyToTerraform(struct?: DataTfCoreNetworkPolicyDocument.AttachmentPoliciesConditionsProperty | cdktn.IResolvable): any;
export declare function dataTfCoreNetworkPolicyDocumentAttachmentPoliciesConditionsPropertyToHclTerraform(struct?: DataTfCoreNetworkPolicyDocument.AttachmentPoliciesConditionsProperty | cdktn.IResolvable): any;
export declare function dataTfCoreNetworkPolicyDocumentAttachmentPoliciesPropertyToTerraform(struct?: DataTfCoreNetworkPolicyDocument.AttachmentPoliciesProperty | cdktn.IResolvable): any;
export declare function dataTfCoreNetworkPolicyDocumentAttachmentPoliciesPropertyToHclTerraform(struct?: DataTfCoreNetworkPolicyDocument.AttachmentPoliciesProperty | cdktn.IResolvable): any;
export declare function dataTfCoreNetworkPolicyDocumentAttachmentRoutingPolicyRulesActionPropertyToTerraform(struct?: DataTfCoreNetworkPolicyDocument.AttachmentRoutingPolicyRulesActionPropertyOutputReference | DataTfCoreNetworkPolicyDocument.AttachmentRoutingPolicyRulesActionProperty): any;
export declare function dataTfCoreNetworkPolicyDocumentAttachmentRoutingPolicyRulesActionPropertyToHclTerraform(struct?: DataTfCoreNetworkPolicyDocument.AttachmentRoutingPolicyRulesActionPropertyOutputReference | DataTfCoreNetworkPolicyDocument.AttachmentRoutingPolicyRulesActionProperty): any;
export declare function dataTfCoreNetworkPolicyDocumentAttachmentRoutingPolicyRulesConditionsPropertyToTerraform(struct?: DataTfCoreNetworkPolicyDocument.AttachmentRoutingPolicyRulesConditionsProperty | cdktn.IResolvable): any;
export declare function dataTfCoreNetworkPolicyDocumentAttachmentRoutingPolicyRulesConditionsPropertyToHclTerraform(struct?: DataTfCoreNetworkPolicyDocument.AttachmentRoutingPolicyRulesConditionsProperty | cdktn.IResolvable): any;
export declare function dataTfCoreNetworkPolicyDocumentAttachmentRoutingPolicyRulesPropertyToTerraform(struct?: DataTfCoreNetworkPolicyDocument.AttachmentRoutingPolicyRulesProperty | cdktn.IResolvable): any;
export declare function dataTfCoreNetworkPolicyDocumentAttachmentRoutingPolicyRulesPropertyToHclTerraform(struct?: DataTfCoreNetworkPolicyDocument.AttachmentRoutingPolicyRulesProperty | cdktn.IResolvable): any;
export declare function dataTfCoreNetworkPolicyDocumentEdgeLocationsPropertyToTerraform(struct?: DataTfCoreNetworkPolicyDocument.EdgeLocationsProperty | cdktn.IResolvable): any;
export declare function dataTfCoreNetworkPolicyDocumentEdgeLocationsPropertyToHclTerraform(struct?: DataTfCoreNetworkPolicyDocument.EdgeLocationsProperty | cdktn.IResolvable): any;
export declare function dataTfCoreNetworkPolicyDocumentCoreNetworkConfigurationPropertyToTerraform(struct?: DataTfCoreNetworkPolicyDocument.CoreNetworkConfigurationProperty | cdktn.IResolvable): any;
export declare function dataTfCoreNetworkPolicyDocumentCoreNetworkConfigurationPropertyToHclTerraform(struct?: DataTfCoreNetworkPolicyDocument.CoreNetworkConfigurationProperty | cdktn.IResolvable): any;
export declare function dataTfCoreNetworkPolicyDocumentNetworkFunctionGroupsPropertyToTerraform(struct?: DataTfCoreNetworkPolicyDocument.NetworkFunctionGroupsProperty | cdktn.IResolvable): any;
export declare function dataTfCoreNetworkPolicyDocumentNetworkFunctionGroupsPropertyToHclTerraform(struct?: DataTfCoreNetworkPolicyDocument.NetworkFunctionGroupsProperty | cdktn.IResolvable): any;
export declare function dataTfCoreNetworkPolicyDocumentRoutingPoliciesRoutingPolicyRulesRuleDefinitionActionPropertyToTerraform(struct?: DataTfCoreNetworkPolicyDocument.RoutingPoliciesRoutingPolicyRulesRuleDefinitionActionPropertyOutputReference | DataTfCoreNetworkPolicyDocument.RoutingPoliciesRoutingPolicyRulesRuleDefinitionActionProperty): any;
export declare function dataTfCoreNetworkPolicyDocumentRoutingPoliciesRoutingPolicyRulesRuleDefinitionActionPropertyToHclTerraform(struct?: DataTfCoreNetworkPolicyDocument.RoutingPoliciesRoutingPolicyRulesRuleDefinitionActionPropertyOutputReference | DataTfCoreNetworkPolicyDocument.RoutingPoliciesRoutingPolicyRulesRuleDefinitionActionProperty): any;
export declare function dataTfCoreNetworkPolicyDocumentMatchConditionsPropertyToTerraform(struct?: DataTfCoreNetworkPolicyDocument.MatchConditionsProperty | cdktn.IResolvable): any;
export declare function dataTfCoreNetworkPolicyDocumentMatchConditionsPropertyToHclTerraform(struct?: DataTfCoreNetworkPolicyDocument.MatchConditionsProperty | cdktn.IResolvable): any;
export declare function dataTfCoreNetworkPolicyDocumentRuleDefinitionPropertyToTerraform(struct?: DataTfCoreNetworkPolicyDocument.RuleDefinitionPropertyOutputReference | DataTfCoreNetworkPolicyDocument.RuleDefinitionProperty): any;
export declare function dataTfCoreNetworkPolicyDocumentRuleDefinitionPropertyToHclTerraform(struct?: DataTfCoreNetworkPolicyDocument.RuleDefinitionPropertyOutputReference | DataTfCoreNetworkPolicyDocument.RuleDefinitionProperty): any;
export declare function dataTfCoreNetworkPolicyDocumentRoutingPolicyRulesPropertyToTerraform(struct?: DataTfCoreNetworkPolicyDocument.RoutingPolicyRulesProperty | cdktn.IResolvable): any;
export declare function dataTfCoreNetworkPolicyDocumentRoutingPolicyRulesPropertyToHclTerraform(struct?: DataTfCoreNetworkPolicyDocument.RoutingPolicyRulesProperty | cdktn.IResolvable): any;
export declare function dataTfCoreNetworkPolicyDocumentRoutingPoliciesPropertyToTerraform(struct?: DataTfCoreNetworkPolicyDocument.RoutingPoliciesProperty | cdktn.IResolvable): any;
export declare function dataTfCoreNetworkPolicyDocumentRoutingPoliciesPropertyToHclTerraform(struct?: DataTfCoreNetworkPolicyDocument.RoutingPoliciesProperty | cdktn.IResolvable): any;
export declare function dataTfCoreNetworkPolicyDocumentEdgeLocationAssociationPropertyToTerraform(struct?: DataTfCoreNetworkPolicyDocument.EdgeLocationAssociationPropertyOutputReference | DataTfCoreNetworkPolicyDocument.EdgeLocationAssociationProperty): any;
export declare function dataTfCoreNetworkPolicyDocumentEdgeLocationAssociationPropertyToHclTerraform(struct?: DataTfCoreNetworkPolicyDocument.EdgeLocationAssociationPropertyOutputReference | DataTfCoreNetworkPolicyDocument.EdgeLocationAssociationProperty): any;
export declare function dataTfCoreNetworkPolicyDocumentWithEdgeOverridePropertyToTerraform(struct?: DataTfCoreNetworkPolicyDocument.WithEdgeOverrideProperty | cdktn.IResolvable): any;
export declare function dataTfCoreNetworkPolicyDocumentWithEdgeOverridePropertyToHclTerraform(struct?: DataTfCoreNetworkPolicyDocument.WithEdgeOverrideProperty | cdktn.IResolvable): any;
export declare function dataTfCoreNetworkPolicyDocumentViaPropertyToTerraform(struct?: DataTfCoreNetworkPolicyDocument.ViaPropertyOutputReference | DataTfCoreNetworkPolicyDocument.ViaProperty): any;
export declare function dataTfCoreNetworkPolicyDocumentViaPropertyToHclTerraform(struct?: DataTfCoreNetworkPolicyDocument.ViaPropertyOutputReference | DataTfCoreNetworkPolicyDocument.ViaProperty): any;
export declare function dataTfCoreNetworkPolicyDocumentWhenSentToPropertyToTerraform(struct?: DataTfCoreNetworkPolicyDocument.WhenSentToPropertyOutputReference | DataTfCoreNetworkPolicyDocument.WhenSentToProperty): any;
export declare function dataTfCoreNetworkPolicyDocumentWhenSentToPropertyToHclTerraform(struct?: DataTfCoreNetworkPolicyDocument.WhenSentToPropertyOutputReference | DataTfCoreNetworkPolicyDocument.WhenSentToProperty): any;
export declare function dataTfCoreNetworkPolicyDocumentSegmentActionsPropertyToTerraform(struct?: DataTfCoreNetworkPolicyDocument.SegmentActionsProperty | cdktn.IResolvable): any;
export declare function dataTfCoreNetworkPolicyDocumentSegmentActionsPropertyToHclTerraform(struct?: DataTfCoreNetworkPolicyDocument.SegmentActionsProperty | cdktn.IResolvable): any;
export declare function dataTfCoreNetworkPolicyDocumentSegmentsPropertyToTerraform(struct?: DataTfCoreNetworkPolicyDocument.SegmentsProperty | cdktn.IResolvable): any;
export declare function dataTfCoreNetworkPolicyDocumentSegmentsPropertyToHclTerraform(struct?: DataTfCoreNetworkPolicyDocument.SegmentsProperty | cdktn.IResolvable): any;
export declare namespace DataTfCoreNetworkPolicyDocument {
    interface AttachmentPoliciesActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#add_to_network_function_group DataTfCoreNetworkPolicyDocument#add_to_network_function_group}
        */
        readonly addToNetworkFunctionGroup?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#association_method DataTfCoreNetworkPolicyDocument#association_method}
        */
        readonly associationMethod?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#require_acceptance DataTfCoreNetworkPolicyDocument#require_acceptance}
        */
        readonly requireAcceptance?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#segment DataTfCoreNetworkPolicyDocument#segment}
        */
        readonly segment?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#tag_value_of_key DataTfCoreNetworkPolicyDocument#tag_value_of_key}
        */
        readonly tagValueOfKey?: string;
    }
    class AttachmentPoliciesActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AttachmentPoliciesActionProperty | undefined;
        set internalValue(value: AttachmentPoliciesActionProperty | undefined);
        private _addToNetworkFunctionGroup?;
        get addToNetworkFunctionGroup(): string;
        set addToNetworkFunctionGroup(value: string);
        resetAddToNetworkFunctionGroup(): void;
        get addToNetworkFunctionGroupInput(): string | undefined;
        private _associationMethod?;
        get associationMethod(): string;
        set associationMethod(value: string);
        resetAssociationMethod(): void;
        get associationMethodInput(): string | undefined;
        private _requireAcceptance?;
        get requireAcceptance(): boolean | cdktn.IResolvable;
        set requireAcceptance(value: boolean | cdktn.IResolvable);
        resetRequireAcceptance(): void;
        get requireAcceptanceInput(): boolean | cdktn.IResolvable | undefined;
        private _segment?;
        get segment(): string;
        set segment(value: string);
        resetSegment(): void;
        get segmentInput(): string | undefined;
        private _tagValueOfKey?;
        get tagValueOfKey(): string;
        set tagValueOfKey(value: string);
        resetTagValueOfKey(): void;
        get tagValueOfKeyInput(): string | undefined;
    }
    interface AttachmentPoliciesConditionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#key DataTfCoreNetworkPolicyDocument#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#operator DataTfCoreNetworkPolicyDocument#operator}
        */
        readonly operator?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#type DataTfCoreNetworkPolicyDocument#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#value DataTfCoreNetworkPolicyDocument#value}
        */
        readonly value?: string;
    }
    class AttachmentPoliciesConditionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AttachmentPoliciesConditionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AttachmentPoliciesConditionsProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _operator?;
        get operator(): string;
        set operator(value: string);
        resetOperator(): void;
        get operatorInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
    class AttachmentPoliciesConditionsPropertyList extends cdktn.ComplexList {
        internalValue?: AttachmentPoliciesConditionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AttachmentPoliciesConditionsPropertyOutputReference;
    }
    interface AttachmentPoliciesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#condition_logic DataTfCoreNetworkPolicyDocument#condition_logic}
        */
        readonly conditionLogic?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#description DataTfCoreNetworkPolicyDocument#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#rule_number DataTfCoreNetworkPolicyDocument#rule_number}
        */
        readonly ruleNumber: number;
        /**
        * action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#action DataTfCoreNetworkPolicyDocument#action}
        */
        readonly action: AttachmentPoliciesActionProperty;
        /**
        * conditions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#conditions DataTfCoreNetworkPolicyDocument#conditions}
        */
        readonly conditions: AttachmentPoliciesConditionsProperty[] | cdktn.IResolvable;
    }
    class AttachmentPoliciesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AttachmentPoliciesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AttachmentPoliciesProperty | cdktn.IResolvable | undefined);
        private _conditionLogic?;
        get conditionLogic(): string;
        set conditionLogic(value: string);
        resetConditionLogic(): void;
        get conditionLogicInput(): string | undefined;
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _ruleNumber?;
        get ruleNumber(): number;
        set ruleNumber(value: number);
        get ruleNumberInput(): number | undefined;
        private _action;
        get action(): AttachmentPoliciesActionPropertyOutputReference;
        putAction(value: AttachmentPoliciesActionProperty): void;
        get actionInput(): AttachmentPoliciesActionProperty | undefined;
        private _conditions;
        get conditions(): AttachmentPoliciesConditionsPropertyList;
        putConditions(value: AttachmentPoliciesConditionsProperty[] | cdktn.IResolvable): void;
        get conditionsInput(): cdktn.IResolvable | AttachmentPoliciesConditionsProperty[] | undefined;
    }
    class AttachmentPoliciesPropertyList extends cdktn.ComplexList {
        internalValue?: AttachmentPoliciesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AttachmentPoliciesPropertyOutputReference;
    }
    interface AttachmentRoutingPolicyRulesActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#associate_routing_policies DataTfCoreNetworkPolicyDocument#associate_routing_policies}
        */
        readonly associateRoutingPolicies: string[];
    }
    class AttachmentRoutingPolicyRulesActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AttachmentRoutingPolicyRulesActionProperty | undefined;
        set internalValue(value: AttachmentRoutingPolicyRulesActionProperty | undefined);
        private _associateRoutingPolicies?;
        get associateRoutingPolicies(): string[];
        set associateRoutingPolicies(value: string[]);
        get associateRoutingPoliciesInput(): string[] | undefined;
    }
    interface AttachmentRoutingPolicyRulesConditionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#type DataTfCoreNetworkPolicyDocument#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#value DataTfCoreNetworkPolicyDocument#value}
        */
        readonly value: string;
    }
    class AttachmentRoutingPolicyRulesConditionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AttachmentRoutingPolicyRulesConditionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AttachmentRoutingPolicyRulesConditionsProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class AttachmentRoutingPolicyRulesConditionsPropertyList extends cdktn.ComplexList {
        internalValue?: AttachmentRoutingPolicyRulesConditionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AttachmentRoutingPolicyRulesConditionsPropertyOutputReference;
    }
    interface AttachmentRoutingPolicyRulesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#description DataTfCoreNetworkPolicyDocument#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#edge_locations DataTfCoreNetworkPolicyDocument#edge_locations}
        */
        readonly edgeLocations?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#rule_number DataTfCoreNetworkPolicyDocument#rule_number}
        */
        readonly ruleNumber: number;
        /**
        * action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#action DataTfCoreNetworkPolicyDocument#action}
        */
        readonly action: AttachmentRoutingPolicyRulesActionProperty;
        /**
        * conditions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#conditions DataTfCoreNetworkPolicyDocument#conditions}
        */
        readonly conditions: AttachmentRoutingPolicyRulesConditionsProperty[] | cdktn.IResolvable;
    }
    class AttachmentRoutingPolicyRulesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AttachmentRoutingPolicyRulesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AttachmentRoutingPolicyRulesProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _edgeLocations?;
        get edgeLocations(): string[];
        set edgeLocations(value: string[]);
        resetEdgeLocations(): void;
        get edgeLocationsInput(): string[] | undefined;
        private _ruleNumber?;
        get ruleNumber(): number;
        set ruleNumber(value: number);
        get ruleNumberInput(): number | undefined;
        private _action;
        get action(): AttachmentRoutingPolicyRulesActionPropertyOutputReference;
        putAction(value: AttachmentRoutingPolicyRulesActionProperty): void;
        get actionInput(): AttachmentRoutingPolicyRulesActionProperty | undefined;
        private _conditions;
        get conditions(): AttachmentRoutingPolicyRulesConditionsPropertyList;
        putConditions(value: AttachmentRoutingPolicyRulesConditionsProperty[] | cdktn.IResolvable): void;
        get conditionsInput(): cdktn.IResolvable | AttachmentRoutingPolicyRulesConditionsProperty[] | undefined;
    }
    class AttachmentRoutingPolicyRulesPropertyList extends cdktn.ComplexList {
        internalValue?: AttachmentRoutingPolicyRulesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AttachmentRoutingPolicyRulesPropertyOutputReference;
    }
    interface EdgeLocationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#asn DataTfCoreNetworkPolicyDocument#asn}
        */
        readonly asn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#inside_cidr_blocks DataTfCoreNetworkPolicyDocument#inside_cidr_blocks}
        */
        readonly insideCidrBlocks?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#location DataTfCoreNetworkPolicyDocument#location}
        */
        readonly location: string;
    }
    class EdgeLocationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EdgeLocationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EdgeLocationsProperty | cdktn.IResolvable | undefined);
        private _asn?;
        get asn(): string;
        set asn(value: string);
        resetAsn(): void;
        get asnInput(): string | undefined;
        private _insideCidrBlocks?;
        get insideCidrBlocks(): string[];
        set insideCidrBlocks(value: string[]);
        resetInsideCidrBlocks(): void;
        get insideCidrBlocksInput(): string[] | undefined;
        private _location?;
        get location(): string;
        set location(value: string);
        get locationInput(): string | undefined;
    }
    class EdgeLocationsPropertyList extends cdktn.ComplexList {
        internalValue?: EdgeLocationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EdgeLocationsPropertyOutputReference;
    }
    interface CoreNetworkConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#asn_ranges DataTfCoreNetworkPolicyDocument#asn_ranges}
        */
        readonly asnRanges: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#dns_support DataTfCoreNetworkPolicyDocument#dns_support}
        */
        readonly dnsSupport?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#inside_cidr_blocks DataTfCoreNetworkPolicyDocument#inside_cidr_blocks}
        */
        readonly insideCidrBlocks?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#security_group_referencing_support DataTfCoreNetworkPolicyDocument#security_group_referencing_support}
        */
        readonly securityGroupReferencingSupport?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#vpn_ecmp_support DataTfCoreNetworkPolicyDocument#vpn_ecmp_support}
        */
        readonly vpnEcmpSupport?: boolean | cdktn.IResolvable;
        /**
        * edge_locations block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#edge_locations DataTfCoreNetworkPolicyDocument#edge_locations}
        */
        readonly edgeLocations: EdgeLocationsProperty[] | cdktn.IResolvable;
    }
    class CoreNetworkConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CoreNetworkConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CoreNetworkConfigurationProperty | cdktn.IResolvable | undefined);
        private _asnRanges?;
        get asnRanges(): string[];
        set asnRanges(value: string[]);
        get asnRangesInput(): string[] | undefined;
        private _dnsSupport?;
        get dnsSupport(): boolean | cdktn.IResolvable;
        set dnsSupport(value: boolean | cdktn.IResolvable);
        resetDnsSupport(): void;
        get dnsSupportInput(): boolean | cdktn.IResolvable | undefined;
        private _insideCidrBlocks?;
        get insideCidrBlocks(): string[];
        set insideCidrBlocks(value: string[]);
        resetInsideCidrBlocks(): void;
        get insideCidrBlocksInput(): string[] | undefined;
        private _securityGroupReferencingSupport?;
        get securityGroupReferencingSupport(): boolean | cdktn.IResolvable;
        set securityGroupReferencingSupport(value: boolean | cdktn.IResolvable);
        resetSecurityGroupReferencingSupport(): void;
        get securityGroupReferencingSupportInput(): boolean | cdktn.IResolvable | undefined;
        private _vpnEcmpSupport?;
        get vpnEcmpSupport(): boolean | cdktn.IResolvable;
        set vpnEcmpSupport(value: boolean | cdktn.IResolvable);
        resetVpnEcmpSupport(): void;
        get vpnEcmpSupportInput(): boolean | cdktn.IResolvable | undefined;
        private _edgeLocations;
        get edgeLocations(): EdgeLocationsPropertyList;
        putEdgeLocations(value: EdgeLocationsProperty[] | cdktn.IResolvable): void;
        get edgeLocationsInput(): cdktn.IResolvable | EdgeLocationsProperty[] | undefined;
    }
    class CoreNetworkConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: CoreNetworkConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CoreNetworkConfigurationPropertyOutputReference;
    }
    interface NetworkFunctionGroupsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#description DataTfCoreNetworkPolicyDocument#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#name DataTfCoreNetworkPolicyDocument#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#require_attachment_acceptance DataTfCoreNetworkPolicyDocument#require_attachment_acceptance}
        */
        readonly requireAttachmentAcceptance: boolean | cdktn.IResolvable;
    }
    class NetworkFunctionGroupsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkFunctionGroupsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NetworkFunctionGroupsProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _requireAttachmentAcceptance?;
        get requireAttachmentAcceptance(): boolean | cdktn.IResolvable;
        set requireAttachmentAcceptance(value: boolean | cdktn.IResolvable);
        get requireAttachmentAcceptanceInput(): boolean | cdktn.IResolvable | undefined;
    }
    class NetworkFunctionGroupsPropertyList extends cdktn.ComplexList {
        internalValue?: NetworkFunctionGroupsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkFunctionGroupsPropertyOutputReference;
    }
    interface RoutingPoliciesRoutingPolicyRulesRuleDefinitionActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#type DataTfCoreNetworkPolicyDocument#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#value DataTfCoreNetworkPolicyDocument#value}
        */
        readonly value?: string;
    }
    class RoutingPoliciesRoutingPolicyRulesRuleDefinitionActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RoutingPoliciesRoutingPolicyRulesRuleDefinitionActionProperty | undefined;
        set internalValue(value: RoutingPoliciesRoutingPolicyRulesRuleDefinitionActionProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
    interface MatchConditionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#type DataTfCoreNetworkPolicyDocument#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#value DataTfCoreNetworkPolicyDocument#value}
        */
        readonly value: string;
    }
    class MatchConditionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MatchConditionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MatchConditionsProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class MatchConditionsPropertyList extends cdktn.ComplexList {
        internalValue?: MatchConditionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MatchConditionsPropertyOutputReference;
    }
    interface RuleDefinitionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#condition_logic DataTfCoreNetworkPolicyDocument#condition_logic}
        */
        readonly conditionLogic?: string;
        /**
        * action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#action DataTfCoreNetworkPolicyDocument#action}
        */
        readonly action: RoutingPoliciesRoutingPolicyRulesRuleDefinitionActionProperty;
        /**
        * match_conditions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#match_conditions DataTfCoreNetworkPolicyDocument#match_conditions}
        */
        readonly matchConditions?: MatchConditionsProperty[] | cdktn.IResolvable;
    }
    class RuleDefinitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleDefinitionProperty | undefined;
        set internalValue(value: RuleDefinitionProperty | undefined);
        private _conditionLogic?;
        get conditionLogic(): string;
        set conditionLogic(value: string);
        resetConditionLogic(): void;
        get conditionLogicInput(): string | undefined;
        private _action;
        get action(): RoutingPoliciesRoutingPolicyRulesRuleDefinitionActionPropertyOutputReference;
        putAction(value: RoutingPoliciesRoutingPolicyRulesRuleDefinitionActionProperty): void;
        get actionInput(): RoutingPoliciesRoutingPolicyRulesRuleDefinitionActionProperty | undefined;
        private _matchConditions;
        get matchConditions(): MatchConditionsPropertyList;
        putMatchConditions(value: MatchConditionsProperty[] | cdktn.IResolvable): void;
        resetMatchConditions(): void;
        get matchConditionsInput(): cdktn.IResolvable | MatchConditionsProperty[] | undefined;
    }
    interface RoutingPolicyRulesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#rule_number DataTfCoreNetworkPolicyDocument#rule_number}
        */
        readonly ruleNumber: number;
        /**
        * rule_definition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#rule_definition DataTfCoreNetworkPolicyDocument#rule_definition}
        */
        readonly ruleDefinition: RuleDefinitionProperty;
    }
    class RoutingPolicyRulesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RoutingPolicyRulesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RoutingPolicyRulesProperty | cdktn.IResolvable | undefined);
        private _ruleNumber?;
        get ruleNumber(): number;
        set ruleNumber(value: number);
        get ruleNumberInput(): number | undefined;
        private _ruleDefinition;
        get ruleDefinition(): RuleDefinitionPropertyOutputReference;
        putRuleDefinition(value: RuleDefinitionProperty): void;
        get ruleDefinitionInput(): RuleDefinitionProperty | undefined;
    }
    class RoutingPolicyRulesPropertyList extends cdktn.ComplexList {
        internalValue?: RoutingPolicyRulesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RoutingPolicyRulesPropertyOutputReference;
    }
    interface RoutingPoliciesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#routing_policy_description DataTfCoreNetworkPolicyDocument#routing_policy_description}
        */
        readonly routingPolicyDescription?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#routing_policy_direction DataTfCoreNetworkPolicyDocument#routing_policy_direction}
        */
        readonly routingPolicyDirection: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#routing_policy_name DataTfCoreNetworkPolicyDocument#routing_policy_name}
        */
        readonly routingPolicyName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#routing_policy_number DataTfCoreNetworkPolicyDocument#routing_policy_number}
        */
        readonly routingPolicyNumber: number;
        /**
        * routing_policy_rules block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#routing_policy_rules DataTfCoreNetworkPolicyDocument#routing_policy_rules}
        */
        readonly routingPolicyRules: RoutingPolicyRulesProperty[] | cdktn.IResolvable;
    }
    class RoutingPoliciesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RoutingPoliciesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RoutingPoliciesProperty | cdktn.IResolvable | undefined);
        private _routingPolicyDescription?;
        get routingPolicyDescription(): string;
        set routingPolicyDescription(value: string);
        resetRoutingPolicyDescription(): void;
        get routingPolicyDescriptionInput(): string | undefined;
        private _routingPolicyDirection?;
        get routingPolicyDirection(): string;
        set routingPolicyDirection(value: string);
        get routingPolicyDirectionInput(): string | undefined;
        private _routingPolicyName?;
        get routingPolicyName(): string;
        set routingPolicyName(value: string);
        get routingPolicyNameInput(): string | undefined;
        private _routingPolicyNumber?;
        get routingPolicyNumber(): number;
        set routingPolicyNumber(value: number);
        get routingPolicyNumberInput(): number | undefined;
        private _routingPolicyRules;
        get routingPolicyRules(): RoutingPolicyRulesPropertyList;
        putRoutingPolicyRules(value: RoutingPolicyRulesProperty[] | cdktn.IResolvable): void;
        get routingPolicyRulesInput(): cdktn.IResolvable | RoutingPolicyRulesProperty[] | undefined;
    }
    class RoutingPoliciesPropertyList extends cdktn.ComplexList {
        internalValue?: RoutingPoliciesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RoutingPoliciesPropertyOutputReference;
    }
    interface EdgeLocationAssociationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#edge_location DataTfCoreNetworkPolicyDocument#edge_location}
        */
        readonly edgeLocation: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#peer_edge_location DataTfCoreNetworkPolicyDocument#peer_edge_location}
        */
        readonly peerEdgeLocation: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#routing_policy_names DataTfCoreNetworkPolicyDocument#routing_policy_names}
        */
        readonly routingPolicyNames: string[];
    }
    class EdgeLocationAssociationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EdgeLocationAssociationProperty | undefined;
        set internalValue(value: EdgeLocationAssociationProperty | undefined);
        private _edgeLocation?;
        get edgeLocation(): string;
        set edgeLocation(value: string);
        get edgeLocationInput(): string | undefined;
        private _peerEdgeLocation?;
        get peerEdgeLocation(): string;
        set peerEdgeLocation(value: string);
        get peerEdgeLocationInput(): string | undefined;
        private _routingPolicyNames?;
        get routingPolicyNames(): string[];
        set routingPolicyNames(value: string[]);
        get routingPolicyNamesInput(): string[] | undefined;
    }
    interface WithEdgeOverrideProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#edge_sets DataTfCoreNetworkPolicyDocument#edge_sets}
        */
        readonly edgeSets?: string[][] | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#use_edge DataTfCoreNetworkPolicyDocument#use_edge}
        */
        readonly useEdge?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#use_edge_location DataTfCoreNetworkPolicyDocument#use_edge_location}
        */
        readonly useEdgeLocation?: string;
    }
    class WithEdgeOverridePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WithEdgeOverrideProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WithEdgeOverrideProperty | cdktn.IResolvable | undefined);
        private _edgeSets?;
        get edgeSets(): string[][] | cdktn.IResolvable;
        set edgeSets(value: string[][] | cdktn.IResolvable);
        resetEdgeSets(): void;
        get edgeSetsInput(): cdktn.IResolvable | string[][] | undefined;
        private _useEdge?;
        get useEdge(): string;
        set useEdge(value: string);
        resetUseEdge(): void;
        get useEdgeInput(): string | undefined;
        private _useEdgeLocation?;
        get useEdgeLocation(): string;
        set useEdgeLocation(value: string);
        resetUseEdgeLocation(): void;
        get useEdgeLocationInput(): string | undefined;
    }
    class WithEdgeOverridePropertyList extends cdktn.ComplexList {
        internalValue?: WithEdgeOverrideProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WithEdgeOverridePropertyOutputReference;
    }
    interface ViaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#network_function_groups DataTfCoreNetworkPolicyDocument#network_function_groups}
        */
        readonly networkFunctionGroups?: string[];
        /**
        * with_edge_override block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#with_edge_override DataTfCoreNetworkPolicyDocument#with_edge_override}
        */
        readonly withEdgeOverride?: WithEdgeOverrideProperty[] | cdktn.IResolvable;
    }
    class ViaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ViaProperty | undefined;
        set internalValue(value: ViaProperty | undefined);
        private _networkFunctionGroups?;
        get networkFunctionGroups(): string[];
        set networkFunctionGroups(value: string[]);
        resetNetworkFunctionGroups(): void;
        get networkFunctionGroupsInput(): string[] | undefined;
        private _withEdgeOverride;
        get withEdgeOverride(): WithEdgeOverridePropertyList;
        putWithEdgeOverride(value: WithEdgeOverrideProperty[] | cdktn.IResolvable): void;
        resetWithEdgeOverride(): void;
        get withEdgeOverrideInput(): cdktn.IResolvable | WithEdgeOverrideProperty[] | undefined;
    }
    interface WhenSentToProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#segments DataTfCoreNetworkPolicyDocument#segments}
        */
        readonly segments?: string[];
    }
    class WhenSentToPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): WhenSentToProperty | undefined;
        set internalValue(value: WhenSentToProperty | undefined);
        private _segments?;
        get segments(): string[];
        set segments(value: string[]);
        resetSegments(): void;
        get segmentsInput(): string[] | undefined;
    }
    interface SegmentActionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#action DataTfCoreNetworkPolicyDocument#action}
        */
        readonly action: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#description DataTfCoreNetworkPolicyDocument#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#destination_cidr_blocks DataTfCoreNetworkPolicyDocument#destination_cidr_blocks}
        */
        readonly destinationCidrBlocks?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#destinations DataTfCoreNetworkPolicyDocument#destinations}
        */
        readonly destinations?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#mode DataTfCoreNetworkPolicyDocument#mode}
        */
        readonly mode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#routing_policy_names DataTfCoreNetworkPolicyDocument#routing_policy_names}
        */
        readonly routingPolicyNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#segment DataTfCoreNetworkPolicyDocument#segment}
        */
        readonly segment: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#share_with DataTfCoreNetworkPolicyDocument#share_with}
        */
        readonly shareWith?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#share_with_except DataTfCoreNetworkPolicyDocument#share_with_except}
        */
        readonly shareWithExcept?: string[];
        /**
        * edge_location_association block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#edge_location_association DataTfCoreNetworkPolicyDocument#edge_location_association}
        */
        readonly edgeLocationAssociation?: EdgeLocationAssociationProperty;
        /**
        * via block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#via DataTfCoreNetworkPolicyDocument#via}
        */
        readonly via?: ViaProperty;
        /**
        * when_sent_to block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#when_sent_to DataTfCoreNetworkPolicyDocument#when_sent_to}
        */
        readonly whenSentTo?: WhenSentToProperty;
    }
    class SegmentActionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SegmentActionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SegmentActionsProperty | cdktn.IResolvable | undefined);
        private _action?;
        get action(): string;
        set action(value: string);
        get actionInput(): string | undefined;
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _destinationCidrBlocks?;
        get destinationCidrBlocks(): string[];
        set destinationCidrBlocks(value: string[]);
        resetDestinationCidrBlocks(): void;
        get destinationCidrBlocksInput(): string[] | undefined;
        private _destinations?;
        get destinations(): string[];
        set destinations(value: string[]);
        resetDestinations(): void;
        get destinationsInput(): string[] | undefined;
        private _mode?;
        get mode(): string;
        set mode(value: string);
        resetMode(): void;
        get modeInput(): string | undefined;
        private _routingPolicyNames?;
        get routingPolicyNames(): string[];
        set routingPolicyNames(value: string[]);
        resetRoutingPolicyNames(): void;
        get routingPolicyNamesInput(): string[] | undefined;
        private _segment?;
        get segment(): string;
        set segment(value: string);
        get segmentInput(): string | undefined;
        private _shareWith?;
        get shareWith(): string[];
        set shareWith(value: string[]);
        resetShareWith(): void;
        get shareWithInput(): string[] | undefined;
        private _shareWithExcept?;
        get shareWithExcept(): string[];
        set shareWithExcept(value: string[]);
        resetShareWithExcept(): void;
        get shareWithExceptInput(): string[] | undefined;
        private _edgeLocationAssociation;
        get edgeLocationAssociation(): EdgeLocationAssociationPropertyOutputReference;
        putEdgeLocationAssociation(value: EdgeLocationAssociationProperty): void;
        resetEdgeLocationAssociation(): void;
        get edgeLocationAssociationInput(): EdgeLocationAssociationProperty | undefined;
        private _via;
        get via(): ViaPropertyOutputReference;
        putVia(value: ViaProperty): void;
        resetVia(): void;
        get viaInput(): ViaProperty | undefined;
        private _whenSentTo;
        get whenSentTo(): WhenSentToPropertyOutputReference;
        putWhenSentTo(value: WhenSentToProperty): void;
        resetWhenSentTo(): void;
        get whenSentToInput(): WhenSentToProperty | undefined;
    }
    class SegmentActionsPropertyList extends cdktn.ComplexList {
        internalValue?: SegmentActionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SegmentActionsPropertyOutputReference;
    }
    interface SegmentsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#allow_filter DataTfCoreNetworkPolicyDocument#allow_filter}
        */
        readonly allowFilter?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#deny_filter DataTfCoreNetworkPolicyDocument#deny_filter}
        */
        readonly denyFilter?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#description DataTfCoreNetworkPolicyDocument#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#edge_locations DataTfCoreNetworkPolicyDocument#edge_locations}
        */
        readonly edgeLocations?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#isolate_attachments DataTfCoreNetworkPolicyDocument#isolate_attachments}
        */
        readonly isolateAttachments?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#name DataTfCoreNetworkPolicyDocument#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network_policy_document#require_attachment_acceptance DataTfCoreNetworkPolicyDocument#require_attachment_acceptance}
        */
        readonly requireAttachmentAcceptance?: boolean | cdktn.IResolvable;
    }
    class SegmentsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SegmentsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SegmentsProperty | cdktn.IResolvable | undefined);
        private _allowFilter?;
        get allowFilter(): string[];
        set allowFilter(value: string[]);
        resetAllowFilter(): void;
        get allowFilterInput(): string[] | undefined;
        private _denyFilter?;
        get denyFilter(): string[];
        set denyFilter(value: string[]);
        resetDenyFilter(): void;
        get denyFilterInput(): string[] | undefined;
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _edgeLocations?;
        get edgeLocations(): string[];
        set edgeLocations(value: string[]);
        resetEdgeLocations(): void;
        get edgeLocationsInput(): string[] | undefined;
        private _isolateAttachments?;
        get isolateAttachments(): boolean | cdktn.IResolvable;
        set isolateAttachments(value: boolean | cdktn.IResolvable);
        resetIsolateAttachments(): void;
        get isolateAttachmentsInput(): boolean | cdktn.IResolvable | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _requireAttachmentAcceptance?;
        get requireAttachmentAcceptance(): boolean | cdktn.IResolvable;
        set requireAttachmentAcceptance(value: boolean | cdktn.IResolvable);
        resetRequireAttachmentAcceptance(): void;
        get requireAttachmentAcceptanceInput(): boolean | cdktn.IResolvable | undefined;
    }
    class SegmentsPropertyList extends cdktn.ComplexList {
        internalValue?: SegmentsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SegmentsPropertyOutputReference;
    }
}
