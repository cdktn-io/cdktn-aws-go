import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfTransitGatewayConnectPeerAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_transit_gateway_connect_peer_association#device_id TfTransitGatewayConnectPeerAssociation#device_id}
    */
    readonly deviceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_transit_gateway_connect_peer_association#global_network_id TfTransitGatewayConnectPeerAssociation#global_network_id}
    */
    readonly globalNetworkId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_transit_gateway_connect_peer_association#id TfTransitGatewayConnectPeerAssociation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_transit_gateway_connect_peer_association#link_id TfTransitGatewayConnectPeerAssociation#link_id}
    */
    readonly linkId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_transit_gateway_connect_peer_association#transit_gateway_connect_peer_arn TfTransitGatewayConnectPeerAssociation#transit_gateway_connect_peer_arn}
    */
    readonly transitGatewayConnectPeerArn: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_transit_gateway_connect_peer_association#timeouts TfTransitGatewayConnectPeerAssociation#timeouts}
    */
    readonly timeouts?: TfTransitGatewayConnectPeerAssociation.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_transit_gateway_connect_peer_association aws_networkmanager_transit_gateway_connect_peer_association}
*/
export declare class TfTransitGatewayConnectPeerAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_networkmanager_transit_gateway_connect_peer_association";
    /**
    * Generates CDKTN code for importing a TfTransitGatewayConnectPeerAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfTransitGatewayConnectPeerAssociation to import
    * @param importFromId The id of the existing TfTransitGatewayConnectPeerAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_transit_gateway_connect_peer_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfTransitGatewayConnectPeerAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_transit_gateway_connect_peer_association aws_networkmanager_transit_gateway_connect_peer_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfTransitGatewayConnectPeerAssociationConfig
    */
    constructor(scope: Construct, id: string, config: TfTransitGatewayConnectPeerAssociationConfig);
    private _deviceId?;
    get deviceId(): string;
    set deviceId(value: string);
    get deviceIdInput(): string | undefined;
    private _globalNetworkId?;
    get globalNetworkId(): string;
    set globalNetworkId(value: string);
    get globalNetworkIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _linkId?;
    get linkId(): string;
    set linkId(value: string);
    resetLinkId(): void;
    get linkIdInput(): string | undefined;
    private _transitGatewayConnectPeerArn?;
    get transitGatewayConnectPeerArn(): string;
    set transitGatewayConnectPeerArn(value: string);
    get transitGatewayConnectPeerArnInput(): string | undefined;
    private _timeouts;
    get timeouts(): TfTransitGatewayConnectPeerAssociation.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfTransitGatewayConnectPeerAssociation.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfTransitGatewayConnectPeerAssociation.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfTransitGatewayConnectPeerAssociationTimeoutsPropertyToTerraform(struct?: TfTransitGatewayConnectPeerAssociation.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfTransitGatewayConnectPeerAssociationTimeoutsPropertyToHclTerraform(struct?: TfTransitGatewayConnectPeerAssociation.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfTransitGatewayConnectPeerAssociation {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_transit_gateway_connect_peer_association#create TfTransitGatewayConnectPeerAssociation#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_transit_gateway_connect_peer_association#delete TfTransitGatewayConnectPeerAssociation#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
