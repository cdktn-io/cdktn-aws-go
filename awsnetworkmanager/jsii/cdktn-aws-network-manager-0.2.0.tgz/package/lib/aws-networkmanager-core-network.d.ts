import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfCoreNetworkConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_core_network#base_policy_document TfCoreNetwork#base_policy_document}
    */
    readonly basePolicyDocument?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_core_network#base_policy_regions TfCoreNetwork#base_policy_regions}
    */
    readonly basePolicyRegions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_core_network#create_base_policy TfCoreNetwork#create_base_policy}
    */
    readonly createBasePolicy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_core_network#description TfCoreNetwork#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_core_network#global_network_id TfCoreNetwork#global_network_id}
    */
    readonly globalNetworkId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_core_network#id TfCoreNetwork#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_core_network#tags TfCoreNetwork#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_core_network#tags_all TfCoreNetwork#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_core_network#timeouts TfCoreNetwork#timeouts}
    */
    readonly timeouts?: TfCoreNetwork.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_core_network aws_networkmanager_core_network}
*/
export declare class TfCoreNetwork extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_networkmanager_core_network";
    /**
    * Generates CDKTN code for importing a TfCoreNetwork resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfCoreNetwork to import
    * @param importFromId The id of the existing TfCoreNetwork that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_core_network#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfCoreNetwork to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_core_network aws_networkmanager_core_network} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfCoreNetworkConfig
    */
    constructor(scope: Construct, id: string, config: TfCoreNetworkConfig);
    get arn(): string;
    private _basePolicyDocument?;
    get basePolicyDocument(): string;
    set basePolicyDocument(value: string);
    resetBasePolicyDocument(): void;
    get basePolicyDocumentInput(): string | undefined;
    private _basePolicyRegions?;
    get basePolicyRegions(): string[];
    set basePolicyRegions(value: string[]);
    resetBasePolicyRegions(): void;
    get basePolicyRegionsInput(): string[] | undefined;
    private _createBasePolicy?;
    get createBasePolicy(): boolean | cdktn.IResolvable;
    set createBasePolicy(value: boolean | cdktn.IResolvable);
    resetCreateBasePolicy(): void;
    get createBasePolicyInput(): boolean | cdktn.IResolvable | undefined;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _edges;
    get edges(): TfCoreNetwork.EdgesPropertyList;
    private _globalNetworkId?;
    get globalNetworkId(): string;
    set globalNetworkId(value: string);
    get globalNetworkIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _segments;
    get segments(): TfCoreNetwork.SegmentsPropertyList;
    get state(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _timeouts;
    get timeouts(): TfCoreNetwork.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfCoreNetwork.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfCoreNetwork.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfCoreNetworkEdgesPropertyToTerraform(struct?: TfCoreNetwork.EdgesProperty): any;
export declare function tfCoreNetworkEdgesPropertyToHclTerraform(struct?: TfCoreNetwork.EdgesProperty): any;
export declare function tfCoreNetworkSegmentsPropertyToTerraform(struct?: TfCoreNetwork.SegmentsProperty): any;
export declare function tfCoreNetworkSegmentsPropertyToHclTerraform(struct?: TfCoreNetwork.SegmentsProperty): any;
export declare function tfCoreNetworkTimeoutsPropertyToTerraform(struct?: TfCoreNetwork.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfCoreNetworkTimeoutsPropertyToHclTerraform(struct?: TfCoreNetwork.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfCoreNetwork {
    interface EdgesProperty {
    }
    class EdgesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EdgesProperty | undefined;
        set internalValue(value: EdgesProperty | undefined);
        get asn(): number;
        get edgeLocation(): string;
        get insideCidrBlocks(): string[];
    }
    class EdgesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EdgesPropertyOutputReference;
    }
    interface SegmentsProperty {
    }
    class SegmentsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SegmentsProperty | undefined;
        set internalValue(value: SegmentsProperty | undefined);
        get edgeLocations(): string[];
        get name(): string;
        get sharedSegments(): string[];
    }
    class SegmentsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SegmentsPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_core_network#create TfCoreNetwork#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_core_network#delete TfCoreNetwork#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_core_network#update TfCoreNetwork#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
