import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfCoreNetworkConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network#core_network_id DataTfCoreNetwork#core_network_id}
    */
    readonly coreNetworkId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network aws_networkmanager_core_network}
*/
export declare class DataTfCoreNetwork extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_networkmanager_core_network";
    /**
    * Generates CDKTN code for importing a DataTfCoreNetwork resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfCoreNetwork to import
    * @param importFromId The id of the existing DataTfCoreNetwork that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfCoreNetwork to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkmanager_core_network aws_networkmanager_core_network} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfCoreNetworkConfig
    */
    constructor(scope: Construct, id: string, config: DataTfCoreNetworkConfig);
    get arn(): string;
    private _coreNetworkId?;
    get coreNetworkId(): string;
    set coreNetworkId(value: string);
    get coreNetworkIdInput(): string | undefined;
    get createdAt(): string;
    get description(): string;
    private _edges;
    get edges(): DataTfCoreNetwork.EdgesPropertyList;
    get globalNetworkId(): string;
    private _networkFunctionGroups;
    get networkFunctionGroups(): DataTfCoreNetwork.NetworkFunctionGroupsPropertyList;
    private _segments;
    get segments(): DataTfCoreNetwork.SegmentsPropertyList;
    get state(): string;
    private _tags;
    get tags(): cdktn.StringMap;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfCoreNetworkEdgesPropertyToTerraform(struct?: DataTfCoreNetwork.EdgesProperty): any;
export declare function dataTfCoreNetworkEdgesPropertyToHclTerraform(struct?: DataTfCoreNetwork.EdgesProperty): any;
export declare function dataTfCoreNetworkNetworkFunctionGroupsSegmentsPropertyToTerraform(struct?: DataTfCoreNetwork.NetworkFunctionGroupsSegmentsProperty): any;
export declare function dataTfCoreNetworkNetworkFunctionGroupsSegmentsPropertyToHclTerraform(struct?: DataTfCoreNetwork.NetworkFunctionGroupsSegmentsProperty): any;
export declare function dataTfCoreNetworkNetworkFunctionGroupsPropertyToTerraform(struct?: DataTfCoreNetwork.NetworkFunctionGroupsProperty): any;
export declare function dataTfCoreNetworkNetworkFunctionGroupsPropertyToHclTerraform(struct?: DataTfCoreNetwork.NetworkFunctionGroupsProperty): any;
export declare function dataTfCoreNetworkSegmentsPropertyToTerraform(struct?: DataTfCoreNetwork.SegmentsProperty): any;
export declare function dataTfCoreNetworkSegmentsPropertyToHclTerraform(struct?: DataTfCoreNetwork.SegmentsProperty): any;
export declare namespace DataTfCoreNetwork {
    interface EdgesProperty {
    }
    class EdgesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EdgesProperty | undefined;
        set internalValue(value: EdgesProperty | undefined);
        get asn(): number;
        get edgeLocation(): string;
        get insideCidrBlocks(): string[];
    }
    class EdgesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EdgesPropertyOutputReference;
    }
    interface NetworkFunctionGroupsSegmentsProperty {
    }
    class NetworkFunctionGroupsSegmentsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkFunctionGroupsSegmentsProperty | undefined;
        set internalValue(value: NetworkFunctionGroupsSegmentsProperty | undefined);
        get sendTo(): string[];
        get sendVia(): string[];
    }
    class NetworkFunctionGroupsSegmentsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkFunctionGroupsSegmentsPropertyOutputReference;
    }
    interface NetworkFunctionGroupsProperty {
    }
    class NetworkFunctionGroupsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NetworkFunctionGroupsProperty | undefined;
        set internalValue(value: NetworkFunctionGroupsProperty | undefined);
        get edgeLocations(): string[];
        get name(): string;
        private _segments;
        get segments(): NetworkFunctionGroupsSegmentsPropertyList;
    }
    class NetworkFunctionGroupsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NetworkFunctionGroupsPropertyOutputReference;
    }
    interface SegmentsProperty {
    }
    class SegmentsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SegmentsProperty | undefined;
        set internalValue(value: SegmentsProperty | undefined);
        get edgeLocations(): string[];
        get name(): string;
        get sharedSegments(): string[];
    }
    class SegmentsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SegmentsPropertyOutputReference;
    }
}
