import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfPrefixListAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_prefix_list_association#core_network_id TfPrefixListAssociation#core_network_id}
    */
    readonly coreNetworkId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_prefix_list_association#prefix_list_alias TfPrefixListAssociation#prefix_list_alias}
    */
    readonly prefixListAlias: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_prefix_list_association#prefix_list_arn TfPrefixListAssociation#prefix_list_arn}
    */
    readonly prefixListArn: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_prefix_list_association aws_networkmanager_prefix_list_association}
*/
export declare class TfPrefixListAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_networkmanager_prefix_list_association";
    /**
    * Generates CDKTN code for importing a TfPrefixListAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfPrefixListAssociation to import
    * @param importFromId The id of the existing TfPrefixListAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_prefix_list_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfPrefixListAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_prefix_list_association aws_networkmanager_prefix_list_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfPrefixListAssociationConfig
    */
    constructor(scope: Construct, id: string, config: TfPrefixListAssociationConfig);
    private _coreNetworkId?;
    get coreNetworkId(): string;
    set coreNetworkId(value: string);
    get coreNetworkIdInput(): string | undefined;
    private _prefixListAlias?;
    get prefixListAlias(): string;
    set prefixListAlias(value: string);
    get prefixListAliasInput(): string | undefined;
    private _prefixListArn?;
    get prefixListArn(): string;
    set prefixListArn(value: string);
    get prefixListArnInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
