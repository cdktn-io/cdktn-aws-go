import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsNetworkmanagerConnectPeerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_connect_peer#connect_attachment_id AwsNetworkmanagerConnectPeer#connect_attachment_id}
    */
    readonly connectAttachmentId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_connect_peer#core_network_address AwsNetworkmanagerConnectPeer#core_network_address}
    */
    readonly coreNetworkAddress?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_connect_peer#id AwsNetworkmanagerConnectPeer#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_connect_peer#inside_cidr_blocks AwsNetworkmanagerConnectPeer#inside_cidr_blocks}
    */
    readonly insideCidrBlocks?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_connect_peer#peer_address AwsNetworkmanagerConnectPeer#peer_address}
    */
    readonly peerAddress: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_connect_peer#subnet_arn AwsNetworkmanagerConnectPeer#subnet_arn}
    */
    readonly subnetArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_connect_peer#tags AwsNetworkmanagerConnectPeer#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_connect_peer#tags_all AwsNetworkmanagerConnectPeer#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * bgp_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_connect_peer#bgp_options AwsNetworkmanagerConnectPeer#bgp_options}
    */
    readonly bgpOptions?: AwsNetworkmanagerConnectPeer.BgpOptionsProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_connect_peer#timeouts AwsNetworkmanagerConnectPeer#timeouts}
    */
    readonly timeouts?: AwsNetworkmanagerConnectPeer.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_connect_peer aws_networkmanager_connect_peer}
*/
export declare class AwsNetworkmanagerConnectPeer extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_networkmanager_connect_peer";
    /**
    * Generates CDKTN code for importing a AwsNetworkmanagerConnectPeer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsNetworkmanagerConnectPeer to import
    * @param importFromId The id of the existing AwsNetworkmanagerConnectPeer that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_connect_peer#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsNetworkmanagerConnectPeer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_connect_peer aws_networkmanager_connect_peer} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsNetworkmanagerConnectPeerConfig
    */
    constructor(scope: Construct, id: string, config: AwsNetworkmanagerConnectPeerConfig);
    get arn(): string;
    private _configuration;
    get configuration(): AwsNetworkmanagerConnectPeer.ConfigurationPropertyList;
    private _connectAttachmentId?;
    get connectAttachmentId(): string;
    set connectAttachmentId(value: string);
    get connectAttachmentIdInput(): string | undefined;
    get connectPeerId(): string;
    private _coreNetworkAddress?;
    get coreNetworkAddress(): string;
    set coreNetworkAddress(value: string);
    resetCoreNetworkAddress(): void;
    get coreNetworkAddressInput(): string | undefined;
    get coreNetworkId(): string;
    get createdAt(): string;
    get edgeLocation(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _insideCidrBlocks?;
    get insideCidrBlocks(): string[];
    set insideCidrBlocks(value: string[]);
    resetInsideCidrBlocks(): void;
    get insideCidrBlocksInput(): string[] | undefined;
    private _peerAddress?;
    get peerAddress(): string;
    set peerAddress(value: string);
    get peerAddressInput(): string | undefined;
    get state(): string;
    private _subnetArn?;
    get subnetArn(): string;
    set subnetArn(value: string);
    resetSubnetArn(): void;
    get subnetArnInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _bgpOptions;
    get bgpOptions(): AwsNetworkmanagerConnectPeer.BgpOptionsPropertyOutputReference;
    putBgpOptions(value: AwsNetworkmanagerConnectPeer.BgpOptionsProperty): void;
    resetBgpOptions(): void;
    get bgpOptionsInput(): AwsNetworkmanagerConnectPeer.BgpOptionsProperty | undefined;
    private _timeouts;
    get timeouts(): AwsNetworkmanagerConnectPeer.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsNetworkmanagerConnectPeer.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsNetworkmanagerConnectPeer.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsNetworkmanagerConnectPeerBgpConfigurationsPropertyToTerraform(struct?: AwsNetworkmanagerConnectPeer.BgpConfigurationsProperty): any;
export declare function awsNetworkmanagerConnectPeerBgpConfigurationsPropertyToHclTerraform(struct?: AwsNetworkmanagerConnectPeer.BgpConfigurationsProperty): any;
export declare function awsNetworkmanagerConnectPeerConfigurationPropertyToTerraform(struct?: AwsNetworkmanagerConnectPeer.ConfigurationProperty): any;
export declare function awsNetworkmanagerConnectPeerConfigurationPropertyToHclTerraform(struct?: AwsNetworkmanagerConnectPeer.ConfigurationProperty): any;
export declare function awsNetworkmanagerConnectPeerBgpOptionsPropertyToTerraform(struct?: AwsNetworkmanagerConnectPeer.BgpOptionsPropertyOutputReference | AwsNetworkmanagerConnectPeer.BgpOptionsProperty): any;
export declare function awsNetworkmanagerConnectPeerBgpOptionsPropertyToHclTerraform(struct?: AwsNetworkmanagerConnectPeer.BgpOptionsPropertyOutputReference | AwsNetworkmanagerConnectPeer.BgpOptionsProperty): any;
export declare function awsNetworkmanagerConnectPeerTimeoutsPropertyToTerraform(struct?: AwsNetworkmanagerConnectPeer.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsNetworkmanagerConnectPeerTimeoutsPropertyToHclTerraform(struct?: AwsNetworkmanagerConnectPeer.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsNetworkmanagerConnectPeer {
    interface BgpConfigurationsProperty {
    }
    class BgpConfigurationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BgpConfigurationsProperty | undefined;
        set internalValue(value: BgpConfigurationsProperty | undefined);
        get coreNetworkAddress(): string;
        get coreNetworkAsn(): number;
        get peerAddress(): string;
        get peerAsn(): string;
    }
    class BgpConfigurationsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BgpConfigurationsPropertyOutputReference;
    }
    interface ConfigurationProperty {
    }
    class ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConfigurationProperty | undefined;
        set internalValue(value: ConfigurationProperty | undefined);
        private _bgpConfigurations;
        get bgpConfigurations(): BgpConfigurationsPropertyList;
        get coreNetworkAddress(): string;
        get insideCidrBlocks(): string[];
        get peerAddress(): string;
        get protocol(): string;
    }
    class ConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConfigurationPropertyOutputReference;
    }
    interface BgpOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_connect_peer#peer_asn AwsNetworkmanagerConnectPeer#peer_asn}
        */
        readonly peerAsn?: string;
    }
    class BgpOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BgpOptionsProperty | undefined;
        set internalValue(value: BgpOptionsProperty | undefined);
        private _peerAsn?;
        get peerAsn(): string;
        set peerAsn(value: string);
        resetPeerAsn(): void;
        get peerAsnInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_connect_peer#create AwsNetworkmanagerConnectPeer#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_connect_peer#delete AwsNetworkmanagerConnectPeer#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
