import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsNetworkmanagerSiteConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_site#description AwsNetworkmanagerSite#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_site#global_network_id AwsNetworkmanagerSite#global_network_id}
    */
    readonly globalNetworkId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_site#id AwsNetworkmanagerSite#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_site#tags AwsNetworkmanagerSite#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_site#tags_all AwsNetworkmanagerSite#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * location block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_site#location AwsNetworkmanagerSite#location}
    */
    readonly location?: AwsNetworkmanagerSite.LocationProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_site#timeouts AwsNetworkmanagerSite#timeouts}
    */
    readonly timeouts?: AwsNetworkmanagerSite.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_site aws_networkmanager_site}
*/
export declare class AwsNetworkmanagerSite extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_networkmanager_site";
    /**
    * Generates CDKTN code for importing a AwsNetworkmanagerSite resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsNetworkmanagerSite to import
    * @param importFromId The id of the existing AwsNetworkmanagerSite that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_site#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsNetworkmanagerSite to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_site aws_networkmanager_site} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsNetworkmanagerSiteConfig
    */
    constructor(scope: Construct, id: string, config: AwsNetworkmanagerSiteConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _globalNetworkId?;
    get globalNetworkId(): string;
    set globalNetworkId(value: string);
    get globalNetworkIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _location;
    get location(): AwsNetworkmanagerSite.LocationPropertyOutputReference;
    putLocation(value: AwsNetworkmanagerSite.LocationProperty): void;
    resetLocation(): void;
    get locationInput(): AwsNetworkmanagerSite.LocationProperty | undefined;
    private _timeouts;
    get timeouts(): AwsNetworkmanagerSite.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsNetworkmanagerSite.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsNetworkmanagerSite.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsNetworkmanagerSiteLocationPropertyToTerraform(struct?: AwsNetworkmanagerSite.LocationPropertyOutputReference | AwsNetworkmanagerSite.LocationProperty): any;
export declare function awsNetworkmanagerSiteLocationPropertyToHclTerraform(struct?: AwsNetworkmanagerSite.LocationPropertyOutputReference | AwsNetworkmanagerSite.LocationProperty): any;
export declare function awsNetworkmanagerSiteTimeoutsPropertyToTerraform(struct?: AwsNetworkmanagerSite.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsNetworkmanagerSiteTimeoutsPropertyToHclTerraform(struct?: AwsNetworkmanagerSite.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsNetworkmanagerSite {
    interface LocationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_site#address AwsNetworkmanagerSite#address}
        */
        readonly address?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_site#latitude AwsNetworkmanagerSite#latitude}
        */
        readonly latitude?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_site#longitude AwsNetworkmanagerSite#longitude}
        */
        readonly longitude?: string;
    }
    class LocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LocationProperty | undefined;
        set internalValue(value: LocationProperty | undefined);
        private _address?;
        get address(): string;
        set address(value: string);
        resetAddress(): void;
        get addressInput(): string | undefined;
        private _latitude?;
        get latitude(): string;
        set latitude(value: string);
        resetLatitude(): void;
        get latitudeInput(): string | undefined;
        private _longitude?;
        get longitude(): string;
        set longitude(value: string);
        resetLongitude(): void;
        get longitudeInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_site#create AwsNetworkmanagerSite#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_site#delete AwsNetworkmanagerSite#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_site#update AwsNetworkmanagerSite#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
