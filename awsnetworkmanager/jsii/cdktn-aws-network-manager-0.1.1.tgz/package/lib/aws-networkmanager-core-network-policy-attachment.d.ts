import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsNetworkmanagerCoreNetworkPolicyAttachmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_core_network_policy_attachment#core_network_id AwsNetworkmanagerCoreNetworkPolicyAttachment#core_network_id}
    */
    readonly coreNetworkId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_core_network_policy_attachment#id AwsNetworkmanagerCoreNetworkPolicyAttachment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_core_network_policy_attachment#policy_document AwsNetworkmanagerCoreNetworkPolicyAttachment#policy_document}
    */
    readonly policyDocument: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_core_network_policy_attachment#timeouts AwsNetworkmanagerCoreNetworkPolicyAttachment#timeouts}
    */
    readonly timeouts?: AwsNetworkmanagerCoreNetworkPolicyAttachment.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_core_network_policy_attachment aws_networkmanager_core_network_policy_attachment}
*/
export declare class AwsNetworkmanagerCoreNetworkPolicyAttachment extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_networkmanager_core_network_policy_attachment";
    /**
    * Generates CDKTN code for importing a AwsNetworkmanagerCoreNetworkPolicyAttachment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsNetworkmanagerCoreNetworkPolicyAttachment to import
    * @param importFromId The id of the existing AwsNetworkmanagerCoreNetworkPolicyAttachment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_core_network_policy_attachment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsNetworkmanagerCoreNetworkPolicyAttachment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_core_network_policy_attachment aws_networkmanager_core_network_policy_attachment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsNetworkmanagerCoreNetworkPolicyAttachmentConfig
    */
    constructor(scope: Construct, id: string, config: AwsNetworkmanagerCoreNetworkPolicyAttachmentConfig);
    private _coreNetworkId?;
    get coreNetworkId(): string;
    set coreNetworkId(value: string);
    get coreNetworkIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _policyDocument?;
    get policyDocument(): string;
    set policyDocument(value: string);
    get policyDocumentInput(): string | undefined;
    get state(): string;
    private _timeouts;
    get timeouts(): AwsNetworkmanagerCoreNetworkPolicyAttachment.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsNetworkmanagerCoreNetworkPolicyAttachment.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsNetworkmanagerCoreNetworkPolicyAttachment.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsNetworkmanagerCoreNetworkPolicyAttachmentTimeoutsPropertyToTerraform(struct?: AwsNetworkmanagerCoreNetworkPolicyAttachment.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsNetworkmanagerCoreNetworkPolicyAttachmentTimeoutsPropertyToHclTerraform(struct?: AwsNetworkmanagerCoreNetworkPolicyAttachment.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsNetworkmanagerCoreNetworkPolicyAttachment {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_core_network_policy_attachment#update AwsNetworkmanagerCoreNetworkPolicyAttachment#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
