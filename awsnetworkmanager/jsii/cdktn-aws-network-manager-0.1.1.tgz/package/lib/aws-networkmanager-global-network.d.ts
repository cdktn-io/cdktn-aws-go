import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsNetworkmanagerGlobalNetworkConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_global_network#description AwsNetworkmanagerGlobalNetwork#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_global_network#id AwsNetworkmanagerGlobalNetwork#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_global_network#tags AwsNetworkmanagerGlobalNetwork#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_global_network#tags_all AwsNetworkmanagerGlobalNetwork#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_global_network#timeouts AwsNetworkmanagerGlobalNetwork#timeouts}
    */
    readonly timeouts?: AwsNetworkmanagerGlobalNetwork.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_global_network aws_networkmanager_global_network}
*/
export declare class AwsNetworkmanagerGlobalNetwork extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_networkmanager_global_network";
    /**
    * Generates CDKTN code for importing a AwsNetworkmanagerGlobalNetwork resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsNetworkmanagerGlobalNetwork to import
    * @param importFromId The id of the existing AwsNetworkmanagerGlobalNetwork that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_global_network#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsNetworkmanagerGlobalNetwork to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_global_network aws_networkmanager_global_network} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsNetworkmanagerGlobalNetworkConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsNetworkmanagerGlobalNetworkConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _timeouts;
    get timeouts(): AwsNetworkmanagerGlobalNetwork.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsNetworkmanagerGlobalNetwork.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsNetworkmanagerGlobalNetwork.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsNetworkmanagerGlobalNetworkTimeoutsPropertyToTerraform(struct?: AwsNetworkmanagerGlobalNetwork.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsNetworkmanagerGlobalNetworkTimeoutsPropertyToHclTerraform(struct?: AwsNetworkmanagerGlobalNetwork.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsNetworkmanagerGlobalNetwork {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_global_network#create AwsNetworkmanagerGlobalNetwork#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_global_network#delete AwsNetworkmanagerGlobalNetwork#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_global_network#update AwsNetworkmanagerGlobalNetwork#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
