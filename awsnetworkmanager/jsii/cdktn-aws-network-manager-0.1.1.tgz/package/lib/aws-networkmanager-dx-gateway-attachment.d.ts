import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsNetworkmanagerDxGatewayAttachmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_dx_gateway_attachment#core_network_id AwsNetworkmanagerDxGatewayAttachment#core_network_id}
    */
    readonly coreNetworkId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_dx_gateway_attachment#direct_connect_gateway_arn AwsNetworkmanagerDxGatewayAttachment#direct_connect_gateway_arn}
    */
    readonly directConnectGatewayArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_dx_gateway_attachment#edge_locations AwsNetworkmanagerDxGatewayAttachment#edge_locations}
    */
    readonly edgeLocations: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_dx_gateway_attachment#routing_policy_label AwsNetworkmanagerDxGatewayAttachment#routing_policy_label}
    */
    readonly routingPolicyLabel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_dx_gateway_attachment#tags AwsNetworkmanagerDxGatewayAttachment#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_dx_gateway_attachment#timeouts AwsNetworkmanagerDxGatewayAttachment#timeouts}
    */
    readonly timeouts?: AwsNetworkmanagerDxGatewayAttachment.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_dx_gateway_attachment aws_networkmanager_dx_gateway_attachment}
*/
export declare class AwsNetworkmanagerDxGatewayAttachment extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_networkmanager_dx_gateway_attachment";
    /**
    * Generates CDKTN code for importing a AwsNetworkmanagerDxGatewayAttachment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsNetworkmanagerDxGatewayAttachment to import
    * @param importFromId The id of the existing AwsNetworkmanagerDxGatewayAttachment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_dx_gateway_attachment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsNetworkmanagerDxGatewayAttachment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_dx_gateway_attachment aws_networkmanager_dx_gateway_attachment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsNetworkmanagerDxGatewayAttachmentConfig
    */
    constructor(scope: Construct, id: string, config: AwsNetworkmanagerDxGatewayAttachmentConfig);
    get arn(): string;
    get attachmentPolicyRuleNumber(): number;
    get attachmentType(): string;
    get coreNetworkArn(): string;
    private _coreNetworkId?;
    get coreNetworkId(): string;
    set coreNetworkId(value: string);
    get coreNetworkIdInput(): string | undefined;
    private _directConnectGatewayArn?;
    get directConnectGatewayArn(): string;
    set directConnectGatewayArn(value: string);
    get directConnectGatewayArnInput(): string | undefined;
    private _edgeLocations?;
    get edgeLocations(): string[];
    set edgeLocations(value: string[]);
    get edgeLocationsInput(): string[] | undefined;
    get id(): string;
    get ownerAccountId(): string;
    private _routingPolicyLabel?;
    get routingPolicyLabel(): string;
    set routingPolicyLabel(value: string);
    resetRoutingPolicyLabel(): void;
    get routingPolicyLabelInput(): string | undefined;
    get segmentName(): string;
    get state(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _timeouts;
    get timeouts(): AwsNetworkmanagerDxGatewayAttachment.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsNetworkmanagerDxGatewayAttachment.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsNetworkmanagerDxGatewayAttachment.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsNetworkmanagerDxGatewayAttachmentTimeoutsPropertyToTerraform(struct?: AwsNetworkmanagerDxGatewayAttachment.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsNetworkmanagerDxGatewayAttachmentTimeoutsPropertyToHclTerraform(struct?: AwsNetworkmanagerDxGatewayAttachment.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsNetworkmanagerDxGatewayAttachment {
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_dx_gateway_attachment#create AwsNetworkmanagerDxGatewayAttachment#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_dx_gateway_attachment#delete AwsNetworkmanagerDxGatewayAttachment#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkmanager_dx_gateway_attachment#update AwsNetworkmanagerDxGatewayAttachment#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
