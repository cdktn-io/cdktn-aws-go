import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#dead_letter_queue_url AwsDomain#dead_letter_queue_url}
    */
    readonly deadLetterQueueUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#default_encryption_key AwsDomain#default_encryption_key}
    */
    readonly defaultEncryptionKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#default_expiration_days AwsDomain#default_expiration_days}
    */
    readonly defaultExpirationDays: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#domain_name AwsDomain#domain_name}
    */
    readonly domainName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#id AwsDomain#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#region AwsDomain#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#tags AwsDomain#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#tags_all AwsDomain#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * matching block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#matching AwsDomain#matching}
    */
    readonly matching?: AwsDomain.MatchingProperty;
    /**
    * rule_based_matching block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#rule_based_matching AwsDomain#rule_based_matching}
    */
    readonly ruleBasedMatching?: AwsDomain.RuleBasedMatchingProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain aws_customerprofiles_domain}
*/
export declare class AwsDomain extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_customerprofiles_domain";
    /**
    * Generates CDKTN code for importing a AwsDomain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDomain to import
    * @param importFromId The id of the existing AwsDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain aws_customerprofiles_domain} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDomainConfig
    */
    constructor(scope: Construct, id: string, config: AwsDomainConfig);
    get arn(): string;
    private _deadLetterQueueUrl?;
    get deadLetterQueueUrl(): string;
    set deadLetterQueueUrl(value: string);
    resetDeadLetterQueueUrl(): void;
    get deadLetterQueueUrlInput(): string | undefined;
    private _defaultEncryptionKey?;
    get defaultEncryptionKey(): string;
    set defaultEncryptionKey(value: string);
    resetDefaultEncryptionKey(): void;
    get defaultEncryptionKeyInput(): string | undefined;
    private _defaultExpirationDays?;
    get defaultExpirationDays(): number;
    set defaultExpirationDays(value: number);
    get defaultExpirationDaysInput(): number | undefined;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _matching;
    get matching(): AwsDomain.MatchingPropertyOutputReference;
    putMatching(value: AwsDomain.MatchingProperty): void;
    resetMatching(): void;
    get matchingInput(): AwsDomain.MatchingProperty | undefined;
    private _ruleBasedMatching;
    get ruleBasedMatching(): AwsDomain.RuleBasedMatchingPropertyOutputReference;
    putRuleBasedMatching(value: AwsDomain.RuleBasedMatchingProperty): void;
    resetRuleBasedMatching(): void;
    get ruleBasedMatchingInput(): AwsDomain.RuleBasedMatchingProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDomainMatchingAutoMergingConflictResolutionPropertyToTerraform(struct?: AwsDomain.MatchingAutoMergingConflictResolutionPropertyOutputReference | AwsDomain.MatchingAutoMergingConflictResolutionProperty): any;
export declare function awsDomainMatchingAutoMergingConflictResolutionPropertyToHclTerraform(struct?: AwsDomain.MatchingAutoMergingConflictResolutionPropertyOutputReference | AwsDomain.MatchingAutoMergingConflictResolutionProperty): any;
export declare function awsDomainConsolidationPropertyToTerraform(struct?: AwsDomain.ConsolidationPropertyOutputReference | AwsDomain.ConsolidationProperty): any;
export declare function awsDomainConsolidationPropertyToHclTerraform(struct?: AwsDomain.ConsolidationPropertyOutputReference | AwsDomain.ConsolidationProperty): any;
export declare function awsDomainAutoMergingPropertyToTerraform(struct?: AwsDomain.AutoMergingPropertyOutputReference | AwsDomain.AutoMergingProperty): any;
export declare function awsDomainAutoMergingPropertyToHclTerraform(struct?: AwsDomain.AutoMergingPropertyOutputReference | AwsDomain.AutoMergingProperty): any;
export declare function awsDomainMatchingExportingConfigS3ExportingPropertyToTerraform(struct?: AwsDomain.MatchingExportingConfigS3ExportingPropertyOutputReference | AwsDomain.MatchingExportingConfigS3ExportingProperty): any;
export declare function awsDomainMatchingExportingConfigS3ExportingPropertyToHclTerraform(struct?: AwsDomain.MatchingExportingConfigS3ExportingPropertyOutputReference | AwsDomain.MatchingExportingConfigS3ExportingProperty): any;
export declare function awsDomainMatchingExportingConfigPropertyToTerraform(struct?: AwsDomain.MatchingExportingConfigPropertyOutputReference | AwsDomain.MatchingExportingConfigProperty): any;
export declare function awsDomainMatchingExportingConfigPropertyToHclTerraform(struct?: AwsDomain.MatchingExportingConfigPropertyOutputReference | AwsDomain.MatchingExportingConfigProperty): any;
export declare function awsDomainJobSchedulePropertyToTerraform(struct?: AwsDomain.JobSchedulePropertyOutputReference | AwsDomain.JobScheduleProperty): any;
export declare function awsDomainJobSchedulePropertyToHclTerraform(struct?: AwsDomain.JobSchedulePropertyOutputReference | AwsDomain.JobScheduleProperty): any;
export declare function awsDomainMatchingPropertyToTerraform(struct?: AwsDomain.MatchingPropertyOutputReference | AwsDomain.MatchingProperty): any;
export declare function awsDomainMatchingPropertyToHclTerraform(struct?: AwsDomain.MatchingPropertyOutputReference | AwsDomain.MatchingProperty): any;
export declare function awsDomainAttributeTypesSelectorPropertyToTerraform(struct?: AwsDomain.AttributeTypesSelectorPropertyOutputReference | AwsDomain.AttributeTypesSelectorProperty): any;
export declare function awsDomainAttributeTypesSelectorPropertyToHclTerraform(struct?: AwsDomain.AttributeTypesSelectorPropertyOutputReference | AwsDomain.AttributeTypesSelectorProperty): any;
export declare function awsDomainRuleBasedMatchingConflictResolutionPropertyToTerraform(struct?: AwsDomain.RuleBasedMatchingConflictResolutionPropertyOutputReference | AwsDomain.RuleBasedMatchingConflictResolutionProperty): any;
export declare function awsDomainRuleBasedMatchingConflictResolutionPropertyToHclTerraform(struct?: AwsDomain.RuleBasedMatchingConflictResolutionPropertyOutputReference | AwsDomain.RuleBasedMatchingConflictResolutionProperty): any;
export declare function awsDomainRuleBasedMatchingExportingConfigS3ExportingPropertyToTerraform(struct?: AwsDomain.RuleBasedMatchingExportingConfigS3ExportingPropertyOutputReference | AwsDomain.RuleBasedMatchingExportingConfigS3ExportingProperty): any;
export declare function awsDomainRuleBasedMatchingExportingConfigS3ExportingPropertyToHclTerraform(struct?: AwsDomain.RuleBasedMatchingExportingConfigS3ExportingPropertyOutputReference | AwsDomain.RuleBasedMatchingExportingConfigS3ExportingProperty): any;
export declare function awsDomainRuleBasedMatchingExportingConfigPropertyToTerraform(struct?: AwsDomain.RuleBasedMatchingExportingConfigPropertyOutputReference | AwsDomain.RuleBasedMatchingExportingConfigProperty): any;
export declare function awsDomainRuleBasedMatchingExportingConfigPropertyToHclTerraform(struct?: AwsDomain.RuleBasedMatchingExportingConfigPropertyOutputReference | AwsDomain.RuleBasedMatchingExportingConfigProperty): any;
export declare function awsDomainMatchingRulesPropertyToTerraform(struct?: AwsDomain.MatchingRulesProperty | cdktn.IResolvable): any;
export declare function awsDomainMatchingRulesPropertyToHclTerraform(struct?: AwsDomain.MatchingRulesProperty | cdktn.IResolvable): any;
export declare function awsDomainRuleBasedMatchingPropertyToTerraform(struct?: AwsDomain.RuleBasedMatchingPropertyOutputReference | AwsDomain.RuleBasedMatchingProperty): any;
export declare function awsDomainRuleBasedMatchingPropertyToHclTerraform(struct?: AwsDomain.RuleBasedMatchingPropertyOutputReference | AwsDomain.RuleBasedMatchingProperty): any;
export declare namespace AwsDomain {
    interface MatchingAutoMergingConflictResolutionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#conflict_resolving_model AwsDomain#conflict_resolving_model}
        */
        readonly conflictResolvingModel: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#source_name AwsDomain#source_name}
        */
        readonly sourceName?: string;
    }
    class MatchingAutoMergingConflictResolutionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MatchingAutoMergingConflictResolutionProperty | undefined;
        set internalValue(value: MatchingAutoMergingConflictResolutionProperty | undefined);
        private _conflictResolvingModel?;
        get conflictResolvingModel(): string;
        set conflictResolvingModel(value: string);
        get conflictResolvingModelInput(): string | undefined;
        private _sourceName?;
        get sourceName(): string;
        set sourceName(value: string);
        resetSourceName(): void;
        get sourceNameInput(): string | undefined;
    }
    interface ConsolidationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#matching_attributes_list AwsDomain#matching_attributes_list}
        */
        readonly matchingAttributesList: string[][] | cdktn.IResolvable;
    }
    class ConsolidationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConsolidationProperty | undefined;
        set internalValue(value: ConsolidationProperty | undefined);
        private _matchingAttributesList?;
        get matchingAttributesList(): string[][] | cdktn.IResolvable;
        set matchingAttributesList(value: string[][] | cdktn.IResolvable);
        get matchingAttributesListInput(): cdktn.IResolvable | string[][] | undefined;
    }
    interface AutoMergingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#enabled AwsDomain#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#min_allowed_confidence_score_for_merging AwsDomain#min_allowed_confidence_score_for_merging}
        */
        readonly minAllowedConfidenceScoreForMerging?: number;
        /**
        * conflict_resolution block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#conflict_resolution AwsDomain#conflict_resolution}
        */
        readonly conflictResolution?: MatchingAutoMergingConflictResolutionProperty;
        /**
        * consolidation block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#consolidation AwsDomain#consolidation}
        */
        readonly consolidation?: ConsolidationProperty;
    }
    class AutoMergingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AutoMergingProperty | undefined;
        set internalValue(value: AutoMergingProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _minAllowedConfidenceScoreForMerging?;
        get minAllowedConfidenceScoreForMerging(): number;
        set minAllowedConfidenceScoreForMerging(value: number);
        resetMinAllowedConfidenceScoreForMerging(): void;
        get minAllowedConfidenceScoreForMergingInput(): number | undefined;
        private _conflictResolution;
        get conflictResolution(): MatchingAutoMergingConflictResolutionPropertyOutputReference;
        putConflictResolution(value: MatchingAutoMergingConflictResolutionProperty): void;
        resetConflictResolution(): void;
        get conflictResolutionInput(): MatchingAutoMergingConflictResolutionProperty | undefined;
        private _consolidation;
        get consolidation(): ConsolidationPropertyOutputReference;
        putConsolidation(value: ConsolidationProperty): void;
        resetConsolidation(): void;
        get consolidationInput(): ConsolidationProperty | undefined;
    }
    interface MatchingExportingConfigS3ExportingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#s3_bucket_name AwsDomain#s3_bucket_name}
        */
        readonly s3BucketName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#s3_key_name AwsDomain#s3_key_name}
        */
        readonly s3KeyName?: string;
    }
    class MatchingExportingConfigS3ExportingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MatchingExportingConfigS3ExportingProperty | undefined;
        set internalValue(value: MatchingExportingConfigS3ExportingProperty | undefined);
        private _s3BucketName?;
        get s3BucketName(): string;
        set s3BucketName(value: string);
        get s3BucketNameInput(): string | undefined;
        private _s3KeyName?;
        get s3KeyName(): string;
        set s3KeyName(value: string);
        resetS3KeyName(): void;
        get s3KeyNameInput(): string | undefined;
    }
    interface MatchingExportingConfigProperty {
        /**
        * s3_exporting block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#s3_exporting AwsDomain#s3_exporting}
        */
        readonly s3Exporting?: MatchingExportingConfigS3ExportingProperty;
    }
    class MatchingExportingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MatchingExportingConfigProperty | undefined;
        set internalValue(value: MatchingExportingConfigProperty | undefined);
        private _s3Exporting;
        get s3Exporting(): MatchingExportingConfigS3ExportingPropertyOutputReference;
        putS3Exporting(value: MatchingExportingConfigS3ExportingProperty): void;
        resetS3Exporting(): void;
        get s3ExportingInput(): MatchingExportingConfigS3ExportingProperty | undefined;
    }
    interface JobScheduleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#day_of_the_week AwsDomain#day_of_the_week}
        */
        readonly dayOfTheWeek: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#time AwsDomain#time}
        */
        readonly time: string;
    }
    class JobSchedulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): JobScheduleProperty | undefined;
        set internalValue(value: JobScheduleProperty | undefined);
        private _dayOfTheWeek?;
        get dayOfTheWeek(): string;
        set dayOfTheWeek(value: string);
        get dayOfTheWeekInput(): string | undefined;
        private _time?;
        get time(): string;
        set time(value: string);
        get timeInput(): string | undefined;
    }
    interface MatchingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#enabled AwsDomain#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * auto_merging block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#auto_merging AwsDomain#auto_merging}
        */
        readonly autoMerging?: AutoMergingProperty;
        /**
        * exporting_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#exporting_config AwsDomain#exporting_config}
        */
        readonly exportingConfig?: MatchingExportingConfigProperty;
        /**
        * job_schedule block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#job_schedule AwsDomain#job_schedule}
        */
        readonly jobSchedule?: JobScheduleProperty;
    }
    class MatchingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MatchingProperty | undefined;
        set internalValue(value: MatchingProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _autoMerging;
        get autoMerging(): AutoMergingPropertyOutputReference;
        putAutoMerging(value: AutoMergingProperty): void;
        resetAutoMerging(): void;
        get autoMergingInput(): AutoMergingProperty | undefined;
        private _exportingConfig;
        get exportingConfig(): MatchingExportingConfigPropertyOutputReference;
        putExportingConfig(value: MatchingExportingConfigProperty): void;
        resetExportingConfig(): void;
        get exportingConfigInput(): MatchingExportingConfigProperty | undefined;
        private _jobSchedule;
        get jobSchedule(): JobSchedulePropertyOutputReference;
        putJobSchedule(value: JobScheduleProperty): void;
        resetJobSchedule(): void;
        get jobScheduleInput(): JobScheduleProperty | undefined;
    }
    interface AttributeTypesSelectorProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#address AwsDomain#address}
        */
        readonly address?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#attribute_matching_model AwsDomain#attribute_matching_model}
        */
        readonly attributeMatchingModel: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#email_address AwsDomain#email_address}
        */
        readonly emailAddress?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#phone_number AwsDomain#phone_number}
        */
        readonly phoneNumber?: string[];
    }
    class AttributeTypesSelectorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AttributeTypesSelectorProperty | undefined;
        set internalValue(value: AttributeTypesSelectorProperty | undefined);
        private _address?;
        get address(): string[];
        set address(value: string[]);
        resetAddress(): void;
        get addressInput(): string[] | undefined;
        private _attributeMatchingModel?;
        get attributeMatchingModel(): string;
        set attributeMatchingModel(value: string);
        get attributeMatchingModelInput(): string | undefined;
        private _emailAddress?;
        get emailAddress(): string[];
        set emailAddress(value: string[]);
        resetEmailAddress(): void;
        get emailAddressInput(): string[] | undefined;
        private _phoneNumber?;
        get phoneNumber(): string[];
        set phoneNumber(value: string[]);
        resetPhoneNumber(): void;
        get phoneNumberInput(): string[] | undefined;
    }
    interface RuleBasedMatchingConflictResolutionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#conflict_resolving_model AwsDomain#conflict_resolving_model}
        */
        readonly conflictResolvingModel: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#source_name AwsDomain#source_name}
        */
        readonly sourceName?: string;
    }
    class RuleBasedMatchingConflictResolutionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleBasedMatchingConflictResolutionProperty | undefined;
        set internalValue(value: RuleBasedMatchingConflictResolutionProperty | undefined);
        private _conflictResolvingModel?;
        get conflictResolvingModel(): string;
        set conflictResolvingModel(value: string);
        get conflictResolvingModelInput(): string | undefined;
        private _sourceName?;
        get sourceName(): string;
        set sourceName(value: string);
        resetSourceName(): void;
        get sourceNameInput(): string | undefined;
    }
    interface RuleBasedMatchingExportingConfigS3ExportingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#s3_bucket_name AwsDomain#s3_bucket_name}
        */
        readonly s3BucketName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#s3_key_name AwsDomain#s3_key_name}
        */
        readonly s3KeyName?: string;
    }
    class RuleBasedMatchingExportingConfigS3ExportingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleBasedMatchingExportingConfigS3ExportingProperty | undefined;
        set internalValue(value: RuleBasedMatchingExportingConfigS3ExportingProperty | undefined);
        private _s3BucketName?;
        get s3BucketName(): string;
        set s3BucketName(value: string);
        get s3BucketNameInput(): string | undefined;
        private _s3KeyName?;
        get s3KeyName(): string;
        set s3KeyName(value: string);
        resetS3KeyName(): void;
        get s3KeyNameInput(): string | undefined;
    }
    interface RuleBasedMatchingExportingConfigProperty {
        /**
        * s3_exporting block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#s3_exporting AwsDomain#s3_exporting}
        */
        readonly s3Exporting?: RuleBasedMatchingExportingConfigS3ExportingProperty;
    }
    class RuleBasedMatchingExportingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleBasedMatchingExportingConfigProperty | undefined;
        set internalValue(value: RuleBasedMatchingExportingConfigProperty | undefined);
        private _s3Exporting;
        get s3Exporting(): RuleBasedMatchingExportingConfigS3ExportingPropertyOutputReference;
        putS3Exporting(value: RuleBasedMatchingExportingConfigS3ExportingProperty): void;
        resetS3Exporting(): void;
        get s3ExportingInput(): RuleBasedMatchingExportingConfigS3ExportingProperty | undefined;
    }
    interface MatchingRulesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#rule AwsDomain#rule}
        */
        readonly rule: string[];
    }
    class MatchingRulesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MatchingRulesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MatchingRulesProperty | cdktn.IResolvable | undefined);
        private _rule?;
        get rule(): string[];
        set rule(value: string[]);
        get ruleInput(): string[] | undefined;
    }
    class MatchingRulesPropertyList extends cdktn.ComplexList {
        internalValue?: MatchingRulesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MatchingRulesPropertyOutputReference;
    }
    interface RuleBasedMatchingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#enabled AwsDomain#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#max_allowed_rule_level_for_matching AwsDomain#max_allowed_rule_level_for_matching}
        */
        readonly maxAllowedRuleLevelForMatching?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#max_allowed_rule_level_for_merging AwsDomain#max_allowed_rule_level_for_merging}
        */
        readonly maxAllowedRuleLevelForMerging?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#status AwsDomain#status}
        */
        readonly status?: string;
        /**
        * attribute_types_selector block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#attribute_types_selector AwsDomain#attribute_types_selector}
        */
        readonly attributeTypesSelector?: AttributeTypesSelectorProperty;
        /**
        * conflict_resolution block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#conflict_resolution AwsDomain#conflict_resolution}
        */
        readonly conflictResolution?: RuleBasedMatchingConflictResolutionProperty;
        /**
        * exporting_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#exporting_config AwsDomain#exporting_config}
        */
        readonly exportingConfig?: RuleBasedMatchingExportingConfigProperty;
        /**
        * matching_rules block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/customerprofiles_domain#matching_rules AwsDomain#matching_rules}
        */
        readonly matchingRules?: MatchingRulesProperty[] | cdktn.IResolvable;
    }
    class RuleBasedMatchingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleBasedMatchingProperty | undefined;
        set internalValue(value: RuleBasedMatchingProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _maxAllowedRuleLevelForMatching?;
        get maxAllowedRuleLevelForMatching(): number;
        set maxAllowedRuleLevelForMatching(value: number);
        resetMaxAllowedRuleLevelForMatching(): void;
        get maxAllowedRuleLevelForMatchingInput(): number | undefined;
        private _maxAllowedRuleLevelForMerging?;
        get maxAllowedRuleLevelForMerging(): number;
        set maxAllowedRuleLevelForMerging(value: number);
        resetMaxAllowedRuleLevelForMerging(): void;
        get maxAllowedRuleLevelForMergingInput(): number | undefined;
        private _status?;
        get status(): string;
        set status(value: string);
        resetStatus(): void;
        get statusInput(): string | undefined;
        private _attributeTypesSelector;
        get attributeTypesSelector(): AttributeTypesSelectorPropertyOutputReference;
        putAttributeTypesSelector(value: AttributeTypesSelectorProperty): void;
        resetAttributeTypesSelector(): void;
        get attributeTypesSelectorInput(): AttributeTypesSelectorProperty | undefined;
        private _conflictResolution;
        get conflictResolution(): RuleBasedMatchingConflictResolutionPropertyOutputReference;
        putConflictResolution(value: RuleBasedMatchingConflictResolutionProperty): void;
        resetConflictResolution(): void;
        get conflictResolutionInput(): RuleBasedMatchingConflictResolutionProperty | undefined;
        private _exportingConfig;
        get exportingConfig(): RuleBasedMatchingExportingConfigPropertyOutputReference;
        putExportingConfig(value: RuleBasedMatchingExportingConfigProperty): void;
        resetExportingConfig(): void;
        get exportingConfigInput(): RuleBasedMatchingExportingConfigProperty | undefined;
        private _matchingRules;
        get matchingRules(): MatchingRulesPropertyList;
        putMatchingRules(value: MatchingRulesProperty[] | cdktn.IResolvable): void;
        resetMatchingRules(): void;
        get matchingRulesInput(): cdktn.IResolvable | MatchingRulesProperty[] | undefined;
    }
}
