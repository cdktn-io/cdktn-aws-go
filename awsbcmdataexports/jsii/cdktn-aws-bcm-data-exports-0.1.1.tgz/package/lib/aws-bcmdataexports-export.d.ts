import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsBcmdataexportsExportConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bcmdataexports_export#tags AwsBcmdataexportsExport#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * export block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bcmdataexports_export#export AwsBcmdataexportsExport#export}
    */
    readonly export?: AwsBcmdataexportsExport.ExportProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bcmdataexports_export#timeouts AwsBcmdataexportsExport#timeouts}
    */
    readonly timeouts?: AwsBcmdataexportsExport.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bcmdataexports_export aws_bcmdataexports_export}
*/
export declare class AwsBcmdataexportsExport extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bcmdataexports_export";
    /**
    * Generates CDKTN code for importing a AwsBcmdataexportsExport resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsBcmdataexportsExport to import
    * @param importFromId The id of the existing AwsBcmdataexportsExport that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bcmdataexports_export#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsBcmdataexportsExport to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bcmdataexports_export aws_bcmdataexports_export} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsBcmdataexportsExportConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsBcmdataexportsExportConfig);
    get arn(): string;
    get id(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _export;
    get export(): AwsBcmdataexportsExport.ExportPropertyList;
    putExport(value: AwsBcmdataexportsExport.ExportProperty[] | cdktn.IResolvable): void;
    resetExport(): void;
    get exportInput(): cdktn.IResolvable | AwsBcmdataexportsExport.ExportProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsBcmdataexportsExport.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsBcmdataexportsExport.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsBcmdataexportsExport.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsBcmdataexportsExportDataQueryPropertyToTerraform(struct?: AwsBcmdataexportsExport.DataQueryProperty | cdktn.IResolvable): any;
export declare function awsBcmdataexportsExportDataQueryPropertyToHclTerraform(struct?: AwsBcmdataexportsExport.DataQueryProperty | cdktn.IResolvable): any;
export declare function awsBcmdataexportsExportS3OutputConfigurationsPropertyToTerraform(struct?: AwsBcmdataexportsExport.S3OutputConfigurationsProperty | cdktn.IResolvable): any;
export declare function awsBcmdataexportsExportS3OutputConfigurationsPropertyToHclTerraform(struct?: AwsBcmdataexportsExport.S3OutputConfigurationsProperty | cdktn.IResolvable): any;
export declare function awsBcmdataexportsExportS3DestinationPropertyToTerraform(struct?: AwsBcmdataexportsExport.S3DestinationProperty | cdktn.IResolvable): any;
export declare function awsBcmdataexportsExportS3DestinationPropertyToHclTerraform(struct?: AwsBcmdataexportsExport.S3DestinationProperty | cdktn.IResolvable): any;
export declare function awsBcmdataexportsExportDestinationConfigurationsPropertyToTerraform(struct?: AwsBcmdataexportsExport.DestinationConfigurationsProperty | cdktn.IResolvable): any;
export declare function awsBcmdataexportsExportDestinationConfigurationsPropertyToHclTerraform(struct?: AwsBcmdataexportsExport.DestinationConfigurationsProperty | cdktn.IResolvable): any;
export declare function awsBcmdataexportsExportRefreshCadencePropertyToTerraform(struct?: AwsBcmdataexportsExport.RefreshCadenceProperty | cdktn.IResolvable): any;
export declare function awsBcmdataexportsExportRefreshCadencePropertyToHclTerraform(struct?: AwsBcmdataexportsExport.RefreshCadenceProperty | cdktn.IResolvable): any;
export declare function awsBcmdataexportsExportExportPropertyToTerraform(struct?: AwsBcmdataexportsExport.ExportProperty | cdktn.IResolvable): any;
export declare function awsBcmdataexportsExportExportPropertyToHclTerraform(struct?: AwsBcmdataexportsExport.ExportProperty | cdktn.IResolvable): any;
export declare function awsBcmdataexportsExportTimeoutsPropertyToTerraform(struct?: AwsBcmdataexportsExport.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsBcmdataexportsExportTimeoutsPropertyToHclTerraform(struct?: AwsBcmdataexportsExport.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsBcmdataexportsExport {
    interface DataQueryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bcmdataexports_export#query_statement AwsBcmdataexportsExport#query_statement}
        */
        readonly queryStatement: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bcmdataexports_export#table_configurations AwsBcmdataexportsExport#table_configurations}
        */
        readonly tableConfigurations?: {
            [key: string]: {
                [key: string]: string;
            };
        } | cdktn.IResolvable;
    }
    class DataQueryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataQueryProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataQueryProperty | cdktn.IResolvable | undefined);
        private _queryStatement?;
        get queryStatement(): string;
        set queryStatement(value: string);
        get queryStatementInput(): string | undefined;
        private _tableConfigurations?;
        get tableConfigurations(): {
            [key: string]: {
                [key: string]: string;
            };
        } | cdktn.IResolvable;
        set tableConfigurations(value: {
            [key: string]: {
                [key: string]: string;
            };
        } | cdktn.IResolvable);
        resetTableConfigurations(): void;
        get tableConfigurationsInput(): cdktn.IResolvable | {
            [key: string]: {
                [key: string]: string;
            };
        } | undefined;
    }
    class DataQueryPropertyList extends cdktn.ComplexList {
        internalValue?: DataQueryProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataQueryPropertyOutputReference;
    }
    interface S3OutputConfigurationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bcmdataexports_export#compression AwsBcmdataexportsExport#compression}
        */
        readonly compression: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bcmdataexports_export#format AwsBcmdataexportsExport#format}
        */
        readonly format: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bcmdataexports_export#output_type AwsBcmdataexportsExport#output_type}
        */
        readonly outputType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bcmdataexports_export#overwrite AwsBcmdataexportsExport#overwrite}
        */
        readonly overwrite: string;
    }
    class S3OutputConfigurationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3OutputConfigurationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3OutputConfigurationsProperty | cdktn.IResolvable | undefined);
        private _compression?;
        get compression(): string;
        set compression(value: string);
        get compressionInput(): string | undefined;
        private _format?;
        get format(): string;
        set format(value: string);
        get formatInput(): string | undefined;
        private _outputType?;
        get outputType(): string;
        set outputType(value: string);
        get outputTypeInput(): string | undefined;
        private _overwrite?;
        get overwrite(): string;
        set overwrite(value: string);
        get overwriteInput(): string | undefined;
    }
    class S3OutputConfigurationsPropertyList extends cdktn.ComplexList {
        internalValue?: S3OutputConfigurationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3OutputConfigurationsPropertyOutputReference;
    }
    interface S3DestinationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bcmdataexports_export#s3_bucket AwsBcmdataexportsExport#s3_bucket}
        */
        readonly s3Bucket: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bcmdataexports_export#s3_prefix AwsBcmdataexportsExport#s3_prefix}
        */
        readonly s3Prefix: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bcmdataexports_export#s3_region AwsBcmdataexportsExport#s3_region}
        */
        readonly s3Region: string;
        /**
        * s3_output_configurations block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bcmdataexports_export#s3_output_configurations AwsBcmdataexportsExport#s3_output_configurations}
        */
        readonly s3OutputConfigurations?: S3OutputConfigurationsProperty[] | cdktn.IResolvable;
    }
    class S3DestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3DestinationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3DestinationProperty | cdktn.IResolvable | undefined);
        private _s3Bucket?;
        get s3Bucket(): string;
        set s3Bucket(value: string);
        get s3BucketInput(): string | undefined;
        private _s3Prefix?;
        get s3Prefix(): string;
        set s3Prefix(value: string);
        get s3PrefixInput(): string | undefined;
        private _s3Region?;
        get s3Region(): string;
        set s3Region(value: string);
        get s3RegionInput(): string | undefined;
        private _s3OutputConfigurations;
        get s3OutputConfigurations(): S3OutputConfigurationsPropertyList;
        putS3OutputConfigurations(value: S3OutputConfigurationsProperty[] | cdktn.IResolvable): void;
        resetS3OutputConfigurations(): void;
        get s3OutputConfigurationsInput(): cdktn.IResolvable | S3OutputConfigurationsProperty[] | undefined;
    }
    class S3DestinationPropertyList extends cdktn.ComplexList {
        internalValue?: S3DestinationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3DestinationPropertyOutputReference;
    }
    interface DestinationConfigurationsProperty {
        /**
        * s3_destination block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bcmdataexports_export#s3_destination AwsBcmdataexportsExport#s3_destination}
        */
        readonly s3Destination?: S3DestinationProperty[] | cdktn.IResolvable;
    }
    class DestinationConfigurationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DestinationConfigurationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DestinationConfigurationsProperty | cdktn.IResolvable | undefined);
        private _s3Destination;
        get s3Destination(): S3DestinationPropertyList;
        putS3Destination(value: S3DestinationProperty[] | cdktn.IResolvable): void;
        resetS3Destination(): void;
        get s3DestinationInput(): cdktn.IResolvable | S3DestinationProperty[] | undefined;
    }
    class DestinationConfigurationsPropertyList extends cdktn.ComplexList {
        internalValue?: DestinationConfigurationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DestinationConfigurationsPropertyOutputReference;
    }
    interface RefreshCadenceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bcmdataexports_export#frequency AwsBcmdataexportsExport#frequency}
        */
        readonly frequency: string;
    }
    class RefreshCadencePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RefreshCadenceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RefreshCadenceProperty | cdktn.IResolvable | undefined);
        private _frequency?;
        get frequency(): string;
        set frequency(value: string);
        get frequencyInput(): string | undefined;
    }
    class RefreshCadencePropertyList extends cdktn.ComplexList {
        internalValue?: RefreshCadenceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RefreshCadencePropertyOutputReference;
    }
    interface ExportProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bcmdataexports_export#description AwsBcmdataexportsExport#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bcmdataexports_export#name AwsBcmdataexportsExport#name}
        */
        readonly name: string;
        /**
        * data_query block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bcmdataexports_export#data_query AwsBcmdataexportsExport#data_query}
        */
        readonly dataQuery?: DataQueryProperty[] | cdktn.IResolvable;
        /**
        * destination_configurations block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bcmdataexports_export#destination_configurations AwsBcmdataexportsExport#destination_configurations}
        */
        readonly destinationConfigurations?: DestinationConfigurationsProperty[] | cdktn.IResolvable;
        /**
        * refresh_cadence block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bcmdataexports_export#refresh_cadence AwsBcmdataexportsExport#refresh_cadence}
        */
        readonly refreshCadence?: RefreshCadenceProperty[] | cdktn.IResolvable;
    }
    class ExportPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExportProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ExportProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        get exportArn(): string;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _dataQuery;
        get dataQuery(): DataQueryPropertyList;
        putDataQuery(value: DataQueryProperty[] | cdktn.IResolvable): void;
        resetDataQuery(): void;
        get dataQueryInput(): cdktn.IResolvable | DataQueryProperty[] | undefined;
        private _destinationConfigurations;
        get destinationConfigurations(): DestinationConfigurationsPropertyList;
        putDestinationConfigurations(value: DestinationConfigurationsProperty[] | cdktn.IResolvable): void;
        resetDestinationConfigurations(): void;
        get destinationConfigurationsInput(): cdktn.IResolvable | DestinationConfigurationsProperty[] | undefined;
        private _refreshCadence;
        get refreshCadence(): RefreshCadencePropertyList;
        putRefreshCadence(value: RefreshCadenceProperty[] | cdktn.IResolvable): void;
        resetRefreshCadence(): void;
        get refreshCadenceInput(): cdktn.IResolvable | RefreshCadenceProperty[] | undefined;
    }
    class ExportPropertyList extends cdktn.ComplexList {
        internalValue?: ExportProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExportPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bcmdataexports_export#create AwsBcmdataexportsExport#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bcmdataexports_export#update AwsBcmdataexportsExport#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
