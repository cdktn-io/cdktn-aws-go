import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfModelInvocationLoggingConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_model_invocation_logging_configuration#region TfModelInvocationLoggingConfiguration#region}
    */
    readonly region?: string;
    /**
    * logging_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_model_invocation_logging_configuration#logging_config TfModelInvocationLoggingConfiguration#logging_config}
    */
    readonly loggingConfig?: TfModelInvocationLoggingConfiguration.LoggingConfigProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_model_invocation_logging_configuration aws_bedrock_model_invocation_logging_configuration}
*/
export declare class TfModelInvocationLoggingConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrock_model_invocation_logging_configuration";
    /**
    * Generates CDKTN code for importing a TfModelInvocationLoggingConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfModelInvocationLoggingConfiguration to import
    * @param importFromId The id of the existing TfModelInvocationLoggingConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_model_invocation_logging_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfModelInvocationLoggingConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_model_invocation_logging_configuration aws_bedrock_model_invocation_logging_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfModelInvocationLoggingConfigurationConfig = {}
    */
    constructor(scope: Construct, id: string, config?: TfModelInvocationLoggingConfigurationConfig);
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _loggingConfig;
    get loggingConfig(): TfModelInvocationLoggingConfiguration.LoggingConfigPropertyList;
    putLoggingConfig(value: TfModelInvocationLoggingConfiguration.LoggingConfigProperty[] | cdktn.IResolvable): void;
    resetLoggingConfig(): void;
    get loggingConfigInput(): cdktn.IResolvable | TfModelInvocationLoggingConfiguration.LoggingConfigProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfModelInvocationLoggingConfigurationLargeDataDeliveryS3ConfigPropertyToTerraform(struct?: TfModelInvocationLoggingConfiguration.LargeDataDeliveryS3ConfigProperty | cdktn.IResolvable): any;
export declare function tfModelInvocationLoggingConfigurationLargeDataDeliveryS3ConfigPropertyToHclTerraform(struct?: TfModelInvocationLoggingConfiguration.LargeDataDeliveryS3ConfigProperty | cdktn.IResolvable): any;
export declare function tfModelInvocationLoggingConfigurationCloudwatchConfigPropertyToTerraform(struct?: TfModelInvocationLoggingConfiguration.CloudwatchConfigProperty | cdktn.IResolvable): any;
export declare function tfModelInvocationLoggingConfigurationCloudwatchConfigPropertyToHclTerraform(struct?: TfModelInvocationLoggingConfiguration.CloudwatchConfigProperty | cdktn.IResolvable): any;
export declare function tfModelInvocationLoggingConfigurationS3ConfigPropertyToTerraform(struct?: TfModelInvocationLoggingConfiguration.S3ConfigProperty | cdktn.IResolvable): any;
export declare function tfModelInvocationLoggingConfigurationS3ConfigPropertyToHclTerraform(struct?: TfModelInvocationLoggingConfiguration.S3ConfigProperty | cdktn.IResolvable): any;
export declare function tfModelInvocationLoggingConfigurationLoggingConfigPropertyToTerraform(struct?: TfModelInvocationLoggingConfiguration.LoggingConfigProperty | cdktn.IResolvable): any;
export declare function tfModelInvocationLoggingConfigurationLoggingConfigPropertyToHclTerraform(struct?: TfModelInvocationLoggingConfiguration.LoggingConfigProperty | cdktn.IResolvable): any;
export declare namespace TfModelInvocationLoggingConfiguration {
    interface LargeDataDeliveryS3ConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_model_invocation_logging_configuration#bucket_name TfModelInvocationLoggingConfiguration#bucket_name}
        */
        readonly bucketName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_model_invocation_logging_configuration#key_prefix TfModelInvocationLoggingConfiguration#key_prefix}
        */
        readonly keyPrefix?: string;
    }
    class LargeDataDeliveryS3ConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LargeDataDeliveryS3ConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LargeDataDeliveryS3ConfigProperty | cdktn.IResolvable | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        get bucketNameInput(): string | undefined;
        private _keyPrefix?;
        get keyPrefix(): string;
        set keyPrefix(value: string);
        resetKeyPrefix(): void;
        get keyPrefixInput(): string | undefined;
    }
    class LargeDataDeliveryS3ConfigPropertyList extends cdktn.ComplexList {
        internalValue?: LargeDataDeliveryS3ConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LargeDataDeliveryS3ConfigPropertyOutputReference;
    }
    interface CloudwatchConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_model_invocation_logging_configuration#log_group_name TfModelInvocationLoggingConfiguration#log_group_name}
        */
        readonly logGroupName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_model_invocation_logging_configuration#role_arn TfModelInvocationLoggingConfiguration#role_arn}
        */
        readonly roleArn: string;
        /**
        * large_data_delivery_s3_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_model_invocation_logging_configuration#large_data_delivery_s3_config TfModelInvocationLoggingConfiguration#large_data_delivery_s3_config}
        */
        readonly largeDataDeliveryS3Config?: LargeDataDeliveryS3ConfigProperty[] | cdktn.IResolvable;
    }
    class CloudwatchConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CloudwatchConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CloudwatchConfigProperty | cdktn.IResolvable | undefined);
        private _logGroupName?;
        get logGroupName(): string;
        set logGroupName(value: string);
        get logGroupNameInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _largeDataDeliveryS3Config;
        get largeDataDeliveryS3Config(): LargeDataDeliveryS3ConfigPropertyList;
        putLargeDataDeliveryS3Config(value: LargeDataDeliveryS3ConfigProperty[] | cdktn.IResolvable): void;
        resetLargeDataDeliveryS3Config(): void;
        get largeDataDeliveryS3ConfigInput(): cdktn.IResolvable | LargeDataDeliveryS3ConfigProperty[] | undefined;
    }
    class CloudwatchConfigPropertyList extends cdktn.ComplexList {
        internalValue?: CloudwatchConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CloudwatchConfigPropertyOutputReference;
    }
    interface S3ConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_model_invocation_logging_configuration#bucket_name TfModelInvocationLoggingConfiguration#bucket_name}
        */
        readonly bucketName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_model_invocation_logging_configuration#key_prefix TfModelInvocationLoggingConfiguration#key_prefix}
        */
        readonly keyPrefix?: string;
    }
    class S3ConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3ConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3ConfigProperty | cdktn.IResolvable | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        get bucketNameInput(): string | undefined;
        private _keyPrefix?;
        get keyPrefix(): string;
        set keyPrefix(value: string);
        resetKeyPrefix(): void;
        get keyPrefixInput(): string | undefined;
    }
    class S3ConfigPropertyList extends cdktn.ComplexList {
        internalValue?: S3ConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3ConfigPropertyOutputReference;
    }
    interface LoggingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_model_invocation_logging_configuration#embedding_data_delivery_enabled TfModelInvocationLoggingConfiguration#embedding_data_delivery_enabled}
        */
        readonly embeddingDataDeliveryEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_model_invocation_logging_configuration#image_data_delivery_enabled TfModelInvocationLoggingConfiguration#image_data_delivery_enabled}
        */
        readonly imageDataDeliveryEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_model_invocation_logging_configuration#text_data_delivery_enabled TfModelInvocationLoggingConfiguration#text_data_delivery_enabled}
        */
        readonly textDataDeliveryEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_model_invocation_logging_configuration#video_data_delivery_enabled TfModelInvocationLoggingConfiguration#video_data_delivery_enabled}
        */
        readonly videoDataDeliveryEnabled?: boolean | cdktn.IResolvable;
        /**
        * cloudwatch_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_model_invocation_logging_configuration#cloudwatch_config TfModelInvocationLoggingConfiguration#cloudwatch_config}
        */
        readonly cloudwatchConfig?: CloudwatchConfigProperty[] | cdktn.IResolvable;
        /**
        * s3_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_model_invocation_logging_configuration#s3_config TfModelInvocationLoggingConfiguration#s3_config}
        */
        readonly s3Config?: S3ConfigProperty[] | cdktn.IResolvable;
    }
    class LoggingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LoggingConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LoggingConfigProperty | cdktn.IResolvable | undefined);
        private _embeddingDataDeliveryEnabled?;
        get embeddingDataDeliveryEnabled(): boolean | cdktn.IResolvable;
        set embeddingDataDeliveryEnabled(value: boolean | cdktn.IResolvable);
        resetEmbeddingDataDeliveryEnabled(): void;
        get embeddingDataDeliveryEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _imageDataDeliveryEnabled?;
        get imageDataDeliveryEnabled(): boolean | cdktn.IResolvable;
        set imageDataDeliveryEnabled(value: boolean | cdktn.IResolvable);
        resetImageDataDeliveryEnabled(): void;
        get imageDataDeliveryEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _textDataDeliveryEnabled?;
        get textDataDeliveryEnabled(): boolean | cdktn.IResolvable;
        set textDataDeliveryEnabled(value: boolean | cdktn.IResolvable);
        resetTextDataDeliveryEnabled(): void;
        get textDataDeliveryEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _videoDataDeliveryEnabled?;
        get videoDataDeliveryEnabled(): boolean | cdktn.IResolvable;
        set videoDataDeliveryEnabled(value: boolean | cdktn.IResolvable);
        resetVideoDataDeliveryEnabled(): void;
        get videoDataDeliveryEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _cloudwatchConfig;
        get cloudwatchConfig(): CloudwatchConfigPropertyList;
        putCloudwatchConfig(value: CloudwatchConfigProperty[] | cdktn.IResolvable): void;
        resetCloudwatchConfig(): void;
        get cloudwatchConfigInput(): cdktn.IResolvable | CloudwatchConfigProperty[] | undefined;
        private _s3Config;
        get s3Config(): S3ConfigPropertyList;
        putS3Config(value: S3ConfigProperty[] | cdktn.IResolvable): void;
        resetS3Config(): void;
        get s3ConfigInput(): cdktn.IResolvable | S3ConfigProperty[] | undefined;
    }
    class LoggingConfigPropertyList extends cdktn.ComplexList {
        internalValue?: LoggingConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LoggingConfigPropertyOutputReference;
    }
}
