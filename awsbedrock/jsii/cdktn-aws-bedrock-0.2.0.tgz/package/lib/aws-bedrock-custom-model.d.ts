import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfCustomModelConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#base_model_identifier TfCustomModel#base_model_identifier}
    */
    readonly baseModelIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#custom_model_kms_key_id TfCustomModel#custom_model_kms_key_id}
    */
    readonly customModelKmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#custom_model_name TfCustomModel#custom_model_name}
    */
    readonly customModelName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#customization_type TfCustomModel#customization_type}
    */
    readonly customizationType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#hyperparameters TfCustomModel#hyperparameters}
    */
    readonly hyperparameters: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#job_name TfCustomModel#job_name}
    */
    readonly jobName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#region TfCustomModel#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#role_arn TfCustomModel#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#tags TfCustomModel#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * output_data_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#output_data_config TfCustomModel#output_data_config}
    */
    readonly outputDataConfig?: TfCustomModel.OutputDataConfigProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#timeouts TfCustomModel#timeouts}
    */
    readonly timeouts?: TfCustomModel.TimeoutsProperty;
    /**
    * training_data_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#training_data_config TfCustomModel#training_data_config}
    */
    readonly trainingDataConfig?: TfCustomModel.TrainingDataConfigProperty[] | cdktn.IResolvable;
    /**
    * validation_data_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#validation_data_config TfCustomModel#validation_data_config}
    */
    readonly validationDataConfig?: TfCustomModel.ValidationDataConfigProperty[] | cdktn.IResolvable;
    /**
    * vpc_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#vpc_config TfCustomModel#vpc_config}
    */
    readonly vpcConfig?: TfCustomModel.VpcConfigProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model aws_bedrock_custom_model}
*/
export declare class TfCustomModel extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrock_custom_model";
    /**
    * Generates CDKTN code for importing a TfCustomModel resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfCustomModel to import
    * @param importFromId The id of the existing TfCustomModel that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfCustomModel to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model aws_bedrock_custom_model} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfCustomModelConfig
    */
    constructor(scope: Construct, id: string, config: TfCustomModelConfig);
    private _baseModelIdentifier?;
    get baseModelIdentifier(): string;
    set baseModelIdentifier(value: string);
    get baseModelIdentifierInput(): string | undefined;
    get customModelArn(): string;
    private _customModelKmsKeyId?;
    get customModelKmsKeyId(): string;
    set customModelKmsKeyId(value: string);
    resetCustomModelKmsKeyId(): void;
    get customModelKmsKeyIdInput(): string | undefined;
    private _customModelName?;
    get customModelName(): string;
    set customModelName(value: string);
    get customModelNameInput(): string | undefined;
    private _customizationType?;
    get customizationType(): string;
    set customizationType(value: string);
    resetCustomizationType(): void;
    get customizationTypeInput(): string | undefined;
    private _hyperparameters?;
    get hyperparameters(): {
        [key: string]: string;
    };
    set hyperparameters(value: {
        [key: string]: string;
    });
    get hyperparametersInput(): {
        [key: string]: string;
    } | undefined;
    get id(): string;
    get jobArn(): string;
    private _jobName?;
    get jobName(): string;
    set jobName(value: string);
    get jobNameInput(): string | undefined;
    get jobStatus(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _trainingMetrics;
    get trainingMetrics(): TfCustomModel.TrainingMetricsPropertyList;
    private _validationMetrics;
    get validationMetrics(): TfCustomModel.ValidationMetricsPropertyList;
    private _outputDataConfig;
    get outputDataConfig(): TfCustomModel.OutputDataConfigPropertyList;
    putOutputDataConfig(value: TfCustomModel.OutputDataConfigProperty[] | cdktn.IResolvable): void;
    resetOutputDataConfig(): void;
    get outputDataConfigInput(): cdktn.IResolvable | TfCustomModel.OutputDataConfigProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfCustomModel.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfCustomModel.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfCustomModel.TimeoutsProperty | undefined;
    private _trainingDataConfig;
    get trainingDataConfig(): TfCustomModel.TrainingDataConfigPropertyList;
    putTrainingDataConfig(value: TfCustomModel.TrainingDataConfigProperty[] | cdktn.IResolvable): void;
    resetTrainingDataConfig(): void;
    get trainingDataConfigInput(): cdktn.IResolvable | TfCustomModel.TrainingDataConfigProperty[] | undefined;
    private _validationDataConfig;
    get validationDataConfig(): TfCustomModel.ValidationDataConfigPropertyList;
    putValidationDataConfig(value: TfCustomModel.ValidationDataConfigProperty[] | cdktn.IResolvable): void;
    resetValidationDataConfig(): void;
    get validationDataConfigInput(): cdktn.IResolvable | TfCustomModel.ValidationDataConfigProperty[] | undefined;
    private _vpcConfig;
    get vpcConfig(): TfCustomModel.VpcConfigPropertyList;
    putVpcConfig(value: TfCustomModel.VpcConfigProperty[] | cdktn.IResolvable): void;
    resetVpcConfig(): void;
    get vpcConfigInput(): cdktn.IResolvable | TfCustomModel.VpcConfigProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfCustomModelTrainingMetricsPropertyToTerraform(struct?: TfCustomModel.TrainingMetricsProperty): any;
export declare function tfCustomModelTrainingMetricsPropertyToHclTerraform(struct?: TfCustomModel.TrainingMetricsProperty): any;
export declare function tfCustomModelValidationMetricsPropertyToTerraform(struct?: TfCustomModel.ValidationMetricsProperty): any;
export declare function tfCustomModelValidationMetricsPropertyToHclTerraform(struct?: TfCustomModel.ValidationMetricsProperty): any;
export declare function tfCustomModelOutputDataConfigPropertyToTerraform(struct?: TfCustomModel.OutputDataConfigProperty | cdktn.IResolvable): any;
export declare function tfCustomModelOutputDataConfigPropertyToHclTerraform(struct?: TfCustomModel.OutputDataConfigProperty | cdktn.IResolvable): any;
export declare function tfCustomModelTimeoutsPropertyToTerraform(struct?: TfCustomModel.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfCustomModelTimeoutsPropertyToHclTerraform(struct?: TfCustomModel.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfCustomModelTrainingDataConfigPropertyToTerraform(struct?: TfCustomModel.TrainingDataConfigProperty | cdktn.IResolvable): any;
export declare function tfCustomModelTrainingDataConfigPropertyToHclTerraform(struct?: TfCustomModel.TrainingDataConfigProperty | cdktn.IResolvable): any;
export declare function tfCustomModelValidatorPropertyToTerraform(struct?: TfCustomModel.ValidatorProperty | cdktn.IResolvable): any;
export declare function tfCustomModelValidatorPropertyToHclTerraform(struct?: TfCustomModel.ValidatorProperty | cdktn.IResolvable): any;
export declare function tfCustomModelValidationDataConfigPropertyToTerraform(struct?: TfCustomModel.ValidationDataConfigProperty | cdktn.IResolvable): any;
export declare function tfCustomModelValidationDataConfigPropertyToHclTerraform(struct?: TfCustomModel.ValidationDataConfigProperty | cdktn.IResolvable): any;
export declare function tfCustomModelVpcConfigPropertyToTerraform(struct?: TfCustomModel.VpcConfigProperty | cdktn.IResolvable): any;
export declare function tfCustomModelVpcConfigPropertyToHclTerraform(struct?: TfCustomModel.VpcConfigProperty | cdktn.IResolvable): any;
export declare namespace TfCustomModel {
    interface TrainingMetricsProperty {
    }
    class TrainingMetricsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingMetricsProperty | undefined;
        set internalValue(value: TrainingMetricsProperty | undefined);
        get trainingLoss(): number;
    }
    class TrainingMetricsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingMetricsPropertyOutputReference;
    }
    interface ValidationMetricsProperty {
    }
    class ValidationMetricsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ValidationMetricsProperty | undefined;
        set internalValue(value: ValidationMetricsProperty | undefined);
        get validationLoss(): number;
    }
    class ValidationMetricsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ValidationMetricsPropertyOutputReference;
    }
    interface OutputDataConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#s3_uri TfCustomModel#s3_uri}
        */
        readonly s3Uri: string;
    }
    class OutputDataConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OutputDataConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OutputDataConfigProperty | cdktn.IResolvable | undefined);
        private _s3Uri?;
        get s3Uri(): string;
        set s3Uri(value: string);
        get s3UriInput(): string | undefined;
    }
    class OutputDataConfigPropertyList extends cdktn.ComplexList {
        internalValue?: OutputDataConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OutputDataConfigPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#create TfCustomModel#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#delete TfCustomModel#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
    interface TrainingDataConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#s3_uri TfCustomModel#s3_uri}
        */
        readonly s3Uri: string;
    }
    class TrainingDataConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingDataConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingDataConfigProperty | cdktn.IResolvable | undefined);
        private _s3Uri?;
        get s3Uri(): string;
        set s3Uri(value: string);
        get s3UriInput(): string | undefined;
    }
    class TrainingDataConfigPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingDataConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingDataConfigPropertyOutputReference;
    }
    interface ValidatorProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#s3_uri TfCustomModel#s3_uri}
        */
        readonly s3Uri: string;
    }
    class ValidatorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ValidatorProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ValidatorProperty | cdktn.IResolvable | undefined);
        private _s3Uri?;
        get s3Uri(): string;
        set s3Uri(value: string);
        get s3UriInput(): string | undefined;
    }
    class ValidatorPropertyList extends cdktn.ComplexList {
        internalValue?: ValidatorProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ValidatorPropertyOutputReference;
    }
    interface ValidationDataConfigProperty {
        /**
        * validator block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#validator TfCustomModel#validator}
        */
        readonly validator?: ValidatorProperty[] | cdktn.IResolvable;
    }
    class ValidationDataConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ValidationDataConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ValidationDataConfigProperty | cdktn.IResolvable | undefined);
        private _validator;
        get validator(): ValidatorPropertyList;
        putValidator(value: ValidatorProperty[] | cdktn.IResolvable): void;
        resetValidator(): void;
        get validatorInput(): cdktn.IResolvable | ValidatorProperty[] | undefined;
    }
    class ValidationDataConfigPropertyList extends cdktn.ComplexList {
        internalValue?: ValidationDataConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ValidationDataConfigPropertyOutputReference;
    }
    interface VpcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#security_group_ids TfCustomModel#security_group_ids}
        */
        readonly securityGroupIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#subnet_ids TfCustomModel#subnet_ids}
        */
        readonly subnetIds: string[];
    }
    class VpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpcConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VpcConfigProperty | cdktn.IResolvable | undefined);
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
    }
    class VpcConfigPropertyList extends cdktn.ComplexList {
        internalValue?: VpcConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpcConfigPropertyOutputReference;
    }
}
