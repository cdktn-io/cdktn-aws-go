import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfCustomModelConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/bedrock_custom_model#model_id DataTfCustomModel#model_id}
    */
    readonly modelId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/bedrock_custom_model#region DataTfCustomModel#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/bedrock_custom_model aws_bedrock_custom_model}
*/
export declare class DataTfCustomModel extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_bedrock_custom_model";
    /**
    * Generates CDKTN code for importing a DataTfCustomModel resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfCustomModel to import
    * @param importFromId The id of the existing DataTfCustomModel that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/bedrock_custom_model#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfCustomModel to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/bedrock_custom_model aws_bedrock_custom_model} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfCustomModelConfig
    */
    constructor(scope: Construct, id: string, config: DataTfCustomModelConfig);
    get baseModelArn(): string;
    get creationTime(): string;
    private _hyperparameters;
    get hyperparameters(): cdktn.StringMap;
    get id(): string;
    get jobArn(): string;
    get jobName(): string;
    private _jobTags;
    get jobTags(): cdktn.StringMap;
    get modelArn(): string;
    private _modelId?;
    get modelId(): string;
    set modelId(value: string);
    get modelIdInput(): string | undefined;
    get modelKmsKeyArn(): string;
    get modelName(): string;
    private _modelTags;
    get modelTags(): cdktn.StringMap;
    private _outputDataConfig;
    get outputDataConfig(): DataTfCustomModel.OutputDataConfigPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _trainingDataConfig;
    get trainingDataConfig(): DataTfCustomModel.TrainingDataConfigPropertyList;
    private _trainingMetrics;
    get trainingMetrics(): DataTfCustomModel.TrainingMetricsPropertyList;
    private _validationDataConfig;
    get validationDataConfig(): DataTfCustomModel.ValidationDataConfigPropertyList;
    private _validationMetrics;
    get validationMetrics(): DataTfCustomModel.ValidationMetricsPropertyList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfCustomModelOutputDataConfigPropertyToTerraform(struct?: DataTfCustomModel.OutputDataConfigProperty): any;
export declare function dataTfCustomModelOutputDataConfigPropertyToHclTerraform(struct?: DataTfCustomModel.OutputDataConfigProperty): any;
export declare function dataTfCustomModelTrainingDataConfigPropertyToTerraform(struct?: DataTfCustomModel.TrainingDataConfigProperty): any;
export declare function dataTfCustomModelTrainingDataConfigPropertyToHclTerraform(struct?: DataTfCustomModel.TrainingDataConfigProperty): any;
export declare function dataTfCustomModelTrainingMetricsPropertyToTerraform(struct?: DataTfCustomModel.TrainingMetricsProperty): any;
export declare function dataTfCustomModelTrainingMetricsPropertyToHclTerraform(struct?: DataTfCustomModel.TrainingMetricsProperty): any;
export declare function dataTfCustomModelValidatorPropertyToTerraform(struct?: DataTfCustomModel.ValidatorProperty): any;
export declare function dataTfCustomModelValidatorPropertyToHclTerraform(struct?: DataTfCustomModel.ValidatorProperty): any;
export declare function dataTfCustomModelValidationDataConfigPropertyToTerraform(struct?: DataTfCustomModel.ValidationDataConfigProperty): any;
export declare function dataTfCustomModelValidationDataConfigPropertyToHclTerraform(struct?: DataTfCustomModel.ValidationDataConfigProperty): any;
export declare function dataTfCustomModelValidationMetricsPropertyToTerraform(struct?: DataTfCustomModel.ValidationMetricsProperty): any;
export declare function dataTfCustomModelValidationMetricsPropertyToHclTerraform(struct?: DataTfCustomModel.ValidationMetricsProperty): any;
export declare namespace DataTfCustomModel {
    interface OutputDataConfigProperty {
    }
    class OutputDataConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OutputDataConfigProperty | undefined;
        set internalValue(value: OutputDataConfigProperty | undefined);
        get s3Uri(): string;
    }
    class OutputDataConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OutputDataConfigPropertyOutputReference;
    }
    interface TrainingDataConfigProperty {
    }
    class TrainingDataConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingDataConfigProperty | undefined;
        set internalValue(value: TrainingDataConfigProperty | undefined);
        get s3Uri(): string;
    }
    class TrainingDataConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingDataConfigPropertyOutputReference;
    }
    interface TrainingMetricsProperty {
    }
    class TrainingMetricsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingMetricsProperty | undefined;
        set internalValue(value: TrainingMetricsProperty | undefined);
        get trainingLoss(): number;
    }
    class TrainingMetricsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingMetricsPropertyOutputReference;
    }
    interface ValidatorProperty {
    }
    class ValidatorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ValidatorProperty | undefined;
        set internalValue(value: ValidatorProperty | undefined);
        get s3Uri(): string;
    }
    class ValidatorPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ValidatorPropertyOutputReference;
    }
    interface ValidationDataConfigProperty {
    }
    class ValidationDataConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ValidationDataConfigProperty | undefined;
        set internalValue(value: ValidationDataConfigProperty | undefined);
        private _validator;
        get validator(): ValidatorPropertyList;
    }
    class ValidationDataConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ValidationDataConfigPropertyOutputReference;
    }
    interface ValidationMetricsProperty {
    }
    class ValidationMetricsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ValidationMetricsProperty | undefined;
        set internalValue(value: ValidationMetricsProperty | undefined);
        get validationLoss(): number;
    }
    class ValidationMetricsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ValidationMetricsPropertyOutputReference;
    }
}
