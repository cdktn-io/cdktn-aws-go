import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfInferenceProfilesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/bedrock_inference_profiles#region DataTfInferenceProfiles#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/bedrock_inference_profiles#type DataTfInferenceProfiles#type}
    */
    readonly type?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/bedrock_inference_profiles aws_bedrock_inference_profiles}
*/
export declare class DataTfInferenceProfiles extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_bedrock_inference_profiles";
    /**
    * Generates CDKTN code for importing a DataTfInferenceProfiles resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfInferenceProfiles to import
    * @param importFromId The id of the existing DataTfInferenceProfiles that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/bedrock_inference_profiles#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfInferenceProfiles to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/bedrock_inference_profiles aws_bedrock_inference_profiles} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfInferenceProfilesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataTfInferenceProfilesConfig);
    private _inferenceProfileSummaries;
    get inferenceProfileSummaries(): DataTfInferenceProfiles.InferenceProfileSummariesPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfInferenceProfilesModelsPropertyToTerraform(struct?: DataTfInferenceProfiles.ModelsProperty): any;
export declare function dataTfInferenceProfilesModelsPropertyToHclTerraform(struct?: DataTfInferenceProfiles.ModelsProperty): any;
export declare function dataTfInferenceProfilesInferenceProfileSummariesPropertyToTerraform(struct?: DataTfInferenceProfiles.InferenceProfileSummariesProperty): any;
export declare function dataTfInferenceProfilesInferenceProfileSummariesPropertyToHclTerraform(struct?: DataTfInferenceProfiles.InferenceProfileSummariesProperty): any;
export declare namespace DataTfInferenceProfiles {
    interface ModelsProperty {
    }
    class ModelsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ModelsProperty | undefined;
        set internalValue(value: ModelsProperty | undefined);
        get modelArn(): string;
    }
    class ModelsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ModelsPropertyOutputReference;
    }
    interface InferenceProfileSummariesProperty {
    }
    class InferenceProfileSummariesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InferenceProfileSummariesProperty | undefined;
        set internalValue(value: InferenceProfileSummariesProperty | undefined);
        get createdAt(): string;
        get description(): string;
        get inferenceProfileArn(): string;
        get inferenceProfileId(): string;
        get inferenceProfileName(): string;
        private _models;
        get models(): ModelsPropertyList;
        get status(): string;
        get type(): string;
        get updatedAt(): string;
    }
    class InferenceProfileSummariesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InferenceProfileSummariesPropertyOutputReference;
    }
}
