import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfUseCaseForModelAccessConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_use_case_for_model_access#form_data TfUseCaseForModelAccess#form_data}
    */
    readonly formData: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_use_case_for_model_access aws_bedrock_use_case_for_model_access}
*/
export declare class TfUseCaseForModelAccess extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrock_use_case_for_model_access";
    /**
    * Generates CDKTN code for importing a TfUseCaseForModelAccess resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfUseCaseForModelAccess to import
    * @param importFromId The id of the existing TfUseCaseForModelAccess that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_use_case_for_model_access#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfUseCaseForModelAccess to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_use_case_for_model_access aws_bedrock_use_case_for_model_access} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfUseCaseForModelAccessConfig
    */
    constructor(scope: Construct, id: string, config: TfUseCaseForModelAccessConfig);
    private _formData?;
    get formData(): string;
    set formData(value: string);
    get formDataInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
