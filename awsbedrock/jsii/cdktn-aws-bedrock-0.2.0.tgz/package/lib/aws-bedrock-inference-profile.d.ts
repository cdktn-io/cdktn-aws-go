import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfInferenceProfileConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_inference_profile#description TfInferenceProfile#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_inference_profile#name TfInferenceProfile#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_inference_profile#region TfInferenceProfile#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_inference_profile#tags TfInferenceProfile#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * model_source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_inference_profile#model_source TfInferenceProfile#model_source}
    */
    readonly modelSource?: TfInferenceProfile.ModelSourceProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_inference_profile#timeouts TfInferenceProfile#timeouts}
    */
    readonly timeouts?: TfInferenceProfile.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_inference_profile aws_bedrock_inference_profile}
*/
export declare class TfInferenceProfile extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrock_inference_profile";
    /**
    * Generates CDKTN code for importing a TfInferenceProfile resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfInferenceProfile to import
    * @param importFromId The id of the existing TfInferenceProfile that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_inference_profile#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfInferenceProfile to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_inference_profile aws_bedrock_inference_profile} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfInferenceProfileConfig
    */
    constructor(scope: Construct, id: string, config: TfInferenceProfileConfig);
    get arn(): string;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _models;
    get models(): TfInferenceProfile.ModelsPropertyList;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    get type(): string;
    get updatedAt(): string;
    private _modelSource;
    get modelSource(): TfInferenceProfile.ModelSourcePropertyList;
    putModelSource(value: TfInferenceProfile.ModelSourceProperty[] | cdktn.IResolvable): void;
    resetModelSource(): void;
    get modelSourceInput(): cdktn.IResolvable | TfInferenceProfile.ModelSourceProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfInferenceProfile.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfInferenceProfile.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfInferenceProfile.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfInferenceProfileModelsPropertyToTerraform(struct?: TfInferenceProfile.ModelsProperty): any;
export declare function tfInferenceProfileModelsPropertyToHclTerraform(struct?: TfInferenceProfile.ModelsProperty): any;
export declare function tfInferenceProfileModelSourcePropertyToTerraform(struct?: TfInferenceProfile.ModelSourceProperty | cdktn.IResolvable): any;
export declare function tfInferenceProfileModelSourcePropertyToHclTerraform(struct?: TfInferenceProfile.ModelSourceProperty | cdktn.IResolvable): any;
export declare function tfInferenceProfileTimeoutsPropertyToTerraform(struct?: TfInferenceProfile.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfInferenceProfileTimeoutsPropertyToHclTerraform(struct?: TfInferenceProfile.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfInferenceProfile {
    interface ModelsProperty {
    }
    class ModelsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ModelsProperty | undefined;
        set internalValue(value: ModelsProperty | undefined);
        get modelArn(): string;
    }
    class ModelsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ModelsPropertyOutputReference;
    }
    interface ModelSourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_inference_profile#copy_from TfInferenceProfile#copy_from}
        */
        readonly copyFrom: string;
    }
    class ModelSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ModelSourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ModelSourceProperty | cdktn.IResolvable | undefined);
        private _copyFrom?;
        get copyFrom(): string;
        set copyFrom(value: string);
        get copyFromInput(): string | undefined;
    }
    class ModelSourcePropertyList extends cdktn.ComplexList {
        internalValue?: ModelSourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ModelSourcePropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_inference_profile#create TfInferenceProfile#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_inference_profile#delete TfInferenceProfile#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_inference_profile#update TfInferenceProfile#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
