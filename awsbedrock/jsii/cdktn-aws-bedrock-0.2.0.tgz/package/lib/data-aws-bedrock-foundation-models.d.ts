import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfFoundationModelsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/bedrock_foundation_models#by_customization_type DataTfFoundationModels#by_customization_type}
    */
    readonly byCustomizationType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/bedrock_foundation_models#by_inference_type DataTfFoundationModels#by_inference_type}
    */
    readonly byInferenceType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/bedrock_foundation_models#by_output_modality DataTfFoundationModels#by_output_modality}
    */
    readonly byOutputModality?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/bedrock_foundation_models#by_provider DataTfFoundationModels#by_provider}
    */
    readonly byProvider?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/bedrock_foundation_models#region DataTfFoundationModels#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/bedrock_foundation_models aws_bedrock_foundation_models}
*/
export declare class DataTfFoundationModels extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_bedrock_foundation_models";
    /**
    * Generates CDKTN code for importing a DataTfFoundationModels resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfFoundationModels to import
    * @param importFromId The id of the existing DataTfFoundationModels that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/bedrock_foundation_models#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfFoundationModels to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/bedrock_foundation_models aws_bedrock_foundation_models} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfFoundationModelsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataTfFoundationModelsConfig);
    private _byCustomizationType?;
    get byCustomizationType(): string;
    set byCustomizationType(value: string);
    resetByCustomizationType(): void;
    get byCustomizationTypeInput(): string | undefined;
    private _byInferenceType?;
    get byInferenceType(): string;
    set byInferenceType(value: string);
    resetByInferenceType(): void;
    get byInferenceTypeInput(): string | undefined;
    private _byOutputModality?;
    get byOutputModality(): string;
    set byOutputModality(value: string);
    resetByOutputModality(): void;
    get byOutputModalityInput(): string | undefined;
    private _byProvider?;
    get byProvider(): string;
    set byProvider(value: string);
    resetByProvider(): void;
    get byProviderInput(): string | undefined;
    get id(): string;
    private _modelSummaries;
    get modelSummaries(): DataTfFoundationModels.ModelSummariesPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfFoundationModelsModelSummariesPropertyToTerraform(struct?: DataTfFoundationModels.ModelSummariesProperty): any;
export declare function dataTfFoundationModelsModelSummariesPropertyToHclTerraform(struct?: DataTfFoundationModels.ModelSummariesProperty): any;
export declare namespace DataTfFoundationModels {
    interface ModelSummariesProperty {
    }
    class ModelSummariesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ModelSummariesProperty | undefined;
        set internalValue(value: ModelSummariesProperty | undefined);
        get customizationsSupported(): string[];
        get inferenceTypesSupported(): string[];
        get inputModalities(): string[];
        get modelArn(): string;
        get modelId(): string;
        get modelName(): string;
        get outputModalities(): string[];
        get providerName(): string;
        get responseStreamingSupported(): cdktn.IResolvable;
    }
    class ModelSummariesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ModelSummariesPropertyOutputReference;
    }
}
