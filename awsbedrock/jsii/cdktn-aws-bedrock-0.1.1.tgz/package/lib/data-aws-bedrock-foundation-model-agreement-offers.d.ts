import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsBedrockFoundationModelAgreementOffersConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/bedrock_foundation_model_agreement_offers#model_id DataAwsBedrockFoundationModelAgreementOffers#model_id}
    */
    readonly modelId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/bedrock_foundation_model_agreement_offers#offer_type DataAwsBedrockFoundationModelAgreementOffers#offer_type}
    */
    readonly offerType?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/bedrock_foundation_model_agreement_offers#region DataAwsBedrockFoundationModelAgreementOffers#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/bedrock_foundation_model_agreement_offers aws_bedrock_foundation_model_agreement_offers}
*/
export declare class DataAwsBedrockFoundationModelAgreementOffers extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_bedrock_foundation_model_agreement_offers";
    /**
    * Generates CDKTN code for importing a DataAwsBedrockFoundationModelAgreementOffers resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsBedrockFoundationModelAgreementOffers to import
    * @param importFromId The id of the existing DataAwsBedrockFoundationModelAgreementOffers that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/bedrock_foundation_model_agreement_offers#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsBedrockFoundationModelAgreementOffers to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/bedrock_foundation_model_agreement_offers aws_bedrock_foundation_model_agreement_offers} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsBedrockFoundationModelAgreementOffersConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsBedrockFoundationModelAgreementOffersConfig);
    private _modelId?;
    get modelId(): string;
    set modelId(value: string);
    get modelIdInput(): string | undefined;
    private _offerType?;
    get offerType(): string;
    set offerType(value: string);
    resetOfferType(): void;
    get offerTypeInput(): string | undefined;
    private _offers;
    get offers(): DataAwsBedrockFoundationModelAgreementOffers.OffersPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsBedrockFoundationModelAgreementOffersLegalTermPropertyToTerraform(struct?: DataAwsBedrockFoundationModelAgreementOffers.LegalTermProperty): any;
export declare function dataAwsBedrockFoundationModelAgreementOffersLegalTermPropertyToHclTerraform(struct?: DataAwsBedrockFoundationModelAgreementOffers.LegalTermProperty): any;
export declare function dataAwsBedrockFoundationModelAgreementOffersSupportTermPropertyToTerraform(struct?: DataAwsBedrockFoundationModelAgreementOffers.SupportTermProperty): any;
export declare function dataAwsBedrockFoundationModelAgreementOffersSupportTermPropertyToHclTerraform(struct?: DataAwsBedrockFoundationModelAgreementOffers.SupportTermProperty): any;
export declare function dataAwsBedrockFoundationModelAgreementOffersRateCardPropertyToTerraform(struct?: DataAwsBedrockFoundationModelAgreementOffers.RateCardProperty): any;
export declare function dataAwsBedrockFoundationModelAgreementOffersRateCardPropertyToHclTerraform(struct?: DataAwsBedrockFoundationModelAgreementOffers.RateCardProperty): any;
export declare function dataAwsBedrockFoundationModelAgreementOffersUsageBasedPricingTermPropertyToTerraform(struct?: DataAwsBedrockFoundationModelAgreementOffers.UsageBasedPricingTermProperty): any;
export declare function dataAwsBedrockFoundationModelAgreementOffersUsageBasedPricingTermPropertyToHclTerraform(struct?: DataAwsBedrockFoundationModelAgreementOffers.UsageBasedPricingTermProperty): any;
export declare function dataAwsBedrockFoundationModelAgreementOffersValidityTermPropertyToTerraform(struct?: DataAwsBedrockFoundationModelAgreementOffers.ValidityTermProperty): any;
export declare function dataAwsBedrockFoundationModelAgreementOffersValidityTermPropertyToHclTerraform(struct?: DataAwsBedrockFoundationModelAgreementOffers.ValidityTermProperty): any;
export declare function dataAwsBedrockFoundationModelAgreementOffersTermDetailsPropertyToTerraform(struct?: DataAwsBedrockFoundationModelAgreementOffers.TermDetailsProperty): any;
export declare function dataAwsBedrockFoundationModelAgreementOffersTermDetailsPropertyToHclTerraform(struct?: DataAwsBedrockFoundationModelAgreementOffers.TermDetailsProperty): any;
export declare function dataAwsBedrockFoundationModelAgreementOffersOffersPropertyToTerraform(struct?: DataAwsBedrockFoundationModelAgreementOffers.OffersProperty): any;
export declare function dataAwsBedrockFoundationModelAgreementOffersOffersPropertyToHclTerraform(struct?: DataAwsBedrockFoundationModelAgreementOffers.OffersProperty): any;
export declare namespace DataAwsBedrockFoundationModelAgreementOffers {
    interface LegalTermProperty {
    }
    class LegalTermPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LegalTermProperty | undefined;
        set internalValue(value: LegalTermProperty | undefined);
        get url(): string;
    }
    class LegalTermPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LegalTermPropertyOutputReference;
    }
    interface SupportTermProperty {
    }
    class SupportTermPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SupportTermProperty | undefined;
        set internalValue(value: SupportTermProperty | undefined);
        get refundPolicyDescription(): string;
    }
    class SupportTermPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SupportTermPropertyOutputReference;
    }
    interface RateCardProperty {
    }
    class RateCardPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RateCardProperty | undefined;
        set internalValue(value: RateCardProperty | undefined);
        get description(): string;
        get dimension(): string;
        get price(): string;
        get unit(): string;
    }
    class RateCardPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RateCardPropertyOutputReference;
    }
    interface UsageBasedPricingTermProperty {
    }
    class UsageBasedPricingTermPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UsageBasedPricingTermProperty | undefined;
        set internalValue(value: UsageBasedPricingTermProperty | undefined);
        private _rateCard;
        get rateCard(): RateCardPropertyList;
    }
    class UsageBasedPricingTermPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UsageBasedPricingTermPropertyOutputReference;
    }
    interface ValidityTermProperty {
    }
    class ValidityTermPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ValidityTermProperty | undefined;
        set internalValue(value: ValidityTermProperty | undefined);
        get agreementDuration(): string;
    }
    class ValidityTermPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ValidityTermPropertyOutputReference;
    }
    interface TermDetailsProperty {
    }
    class TermDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TermDetailsProperty | undefined;
        set internalValue(value: TermDetailsProperty | undefined);
        private _legalTerm;
        get legalTerm(): LegalTermPropertyList;
        private _supportTerm;
        get supportTerm(): SupportTermPropertyList;
        private _usageBasedPricingTerm;
        get usageBasedPricingTerm(): UsageBasedPricingTermPropertyList;
        private _validityTerm;
        get validityTerm(): ValidityTermPropertyList;
    }
    class TermDetailsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TermDetailsPropertyOutputReference;
    }
    interface OffersProperty {
    }
    class OffersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OffersProperty | undefined;
        set internalValue(value: OffersProperty | undefined);
        get offerId(): string;
        get offerToken(): string;
        private _termDetails;
        get termDetails(): TermDetailsPropertyList;
    }
    class OffersPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OffersPropertyOutputReference;
    }
}
