import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsBedrockFoundationModelAgreementConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_foundation_model_agreement#model_id AwsBedrockFoundationModelAgreement#model_id}
    */
    readonly modelId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_foundation_model_agreement#offer_token AwsBedrockFoundationModelAgreement#offer_token}
    */
    readonly offerToken: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_foundation_model_agreement#region AwsBedrockFoundationModelAgreement#region}
    */
    readonly region?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_foundation_model_agreement#timeouts AwsBedrockFoundationModelAgreement#timeouts}
    */
    readonly timeouts?: AwsBedrockFoundationModelAgreement.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_foundation_model_agreement aws_bedrock_foundation_model_agreement}
*/
export declare class AwsBedrockFoundationModelAgreement extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrock_foundation_model_agreement";
    /**
    * Generates CDKTN code for importing a AwsBedrockFoundationModelAgreement resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsBedrockFoundationModelAgreement to import
    * @param importFromId The id of the existing AwsBedrockFoundationModelAgreement that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_foundation_model_agreement#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsBedrockFoundationModelAgreement to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_foundation_model_agreement aws_bedrock_foundation_model_agreement} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsBedrockFoundationModelAgreementConfig
    */
    constructor(scope: Construct, id: string, config: AwsBedrockFoundationModelAgreementConfig);
    private _modelId?;
    get modelId(): string;
    set modelId(value: string);
    get modelIdInput(): string | undefined;
    private _offerToken?;
    get offerToken(): string;
    set offerToken(value: string);
    get offerTokenInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _timeouts;
    get timeouts(): AwsBedrockFoundationModelAgreement.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsBedrockFoundationModelAgreement.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsBedrockFoundationModelAgreement.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsBedrockFoundationModelAgreementTimeoutsPropertyToTerraform(struct?: AwsBedrockFoundationModelAgreement.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsBedrockFoundationModelAgreementTimeoutsPropertyToHclTerraform(struct?: AwsBedrockFoundationModelAgreement.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsBedrockFoundationModelAgreement {
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_foundation_model_agreement#create AwsBedrockFoundationModelAgreement#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_foundation_model_agreement#delete AwsBedrockFoundationModelAgreement#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
