import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsBedrockGuardrailConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#blocked_input_messaging AwsBedrockGuardrail#blocked_input_messaging}
    */
    readonly blockedInputMessaging: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#blocked_outputs_messaging AwsBedrockGuardrail#blocked_outputs_messaging}
    */
    readonly blockedOutputsMessaging: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#description AwsBedrockGuardrail#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#kms_key_arn AwsBedrockGuardrail#kms_key_arn}
    */
    readonly kmsKeyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#name AwsBedrockGuardrail#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#region AwsBedrockGuardrail#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#tags AwsBedrockGuardrail#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * content_policy_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#content_policy_config AwsBedrockGuardrail#content_policy_config}
    */
    readonly contentPolicyConfig?: AwsBedrockGuardrail.ContentPolicyConfigProperty[] | cdktn.IResolvable;
    /**
    * contextual_grounding_policy_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#contextual_grounding_policy_config AwsBedrockGuardrail#contextual_grounding_policy_config}
    */
    readonly contextualGroundingPolicyConfig?: AwsBedrockGuardrail.ContextualGroundingPolicyConfigProperty[] | cdktn.IResolvable;
    /**
    * cross_region_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#cross_region_config AwsBedrockGuardrail#cross_region_config}
    */
    readonly crossRegionConfig?: AwsBedrockGuardrail.CrossRegionConfigProperty[] | cdktn.IResolvable;
    /**
    * sensitive_information_policy_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#sensitive_information_policy_config AwsBedrockGuardrail#sensitive_information_policy_config}
    */
    readonly sensitiveInformationPolicyConfig?: AwsBedrockGuardrail.SensitiveInformationPolicyConfigProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#timeouts AwsBedrockGuardrail#timeouts}
    */
    readonly timeouts?: AwsBedrockGuardrail.TimeoutsProperty;
    /**
    * topic_policy_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#topic_policy_config AwsBedrockGuardrail#topic_policy_config}
    */
    readonly topicPolicyConfig?: AwsBedrockGuardrail.TopicPolicyConfigProperty[] | cdktn.IResolvable;
    /**
    * word_policy_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#word_policy_config AwsBedrockGuardrail#word_policy_config}
    */
    readonly wordPolicyConfig?: AwsBedrockGuardrail.WordPolicyConfigProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail aws_bedrock_guardrail}
*/
export declare class AwsBedrockGuardrail extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrock_guardrail";
    /**
    * Generates CDKTN code for importing a AwsBedrockGuardrail resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsBedrockGuardrail to import
    * @param importFromId The id of the existing AwsBedrockGuardrail that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsBedrockGuardrail to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail aws_bedrock_guardrail} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsBedrockGuardrailConfig
    */
    constructor(scope: Construct, id: string, config: AwsBedrockGuardrailConfig);
    private _blockedInputMessaging?;
    get blockedInputMessaging(): string;
    set blockedInputMessaging(value: string);
    get blockedInputMessagingInput(): string | undefined;
    private _blockedOutputsMessaging?;
    get blockedOutputsMessaging(): string;
    set blockedOutputsMessaging(value: string);
    get blockedOutputsMessagingInput(): string | undefined;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get guardrailArn(): string;
    get guardrailId(): string;
    private _kmsKeyArn?;
    get kmsKeyArn(): string;
    set kmsKeyArn(value: string);
    resetKmsKeyArn(): void;
    get kmsKeyArnInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    get updatedAt(): string;
    get version(): string;
    private _contentPolicyConfig;
    get contentPolicyConfig(): AwsBedrockGuardrail.ContentPolicyConfigPropertyList;
    putContentPolicyConfig(value: AwsBedrockGuardrail.ContentPolicyConfigProperty[] | cdktn.IResolvable): void;
    resetContentPolicyConfig(): void;
    get contentPolicyConfigInput(): cdktn.IResolvable | AwsBedrockGuardrail.ContentPolicyConfigProperty[] | undefined;
    private _contextualGroundingPolicyConfig;
    get contextualGroundingPolicyConfig(): AwsBedrockGuardrail.ContextualGroundingPolicyConfigPropertyList;
    putContextualGroundingPolicyConfig(value: AwsBedrockGuardrail.ContextualGroundingPolicyConfigProperty[] | cdktn.IResolvable): void;
    resetContextualGroundingPolicyConfig(): void;
    get contextualGroundingPolicyConfigInput(): cdktn.IResolvable | AwsBedrockGuardrail.ContextualGroundingPolicyConfigProperty[] | undefined;
    private _crossRegionConfig;
    get crossRegionConfig(): AwsBedrockGuardrail.CrossRegionConfigPropertyList;
    putCrossRegionConfig(value: AwsBedrockGuardrail.CrossRegionConfigProperty[] | cdktn.IResolvable): void;
    resetCrossRegionConfig(): void;
    get crossRegionConfigInput(): cdktn.IResolvable | AwsBedrockGuardrail.CrossRegionConfigProperty[] | undefined;
    private _sensitiveInformationPolicyConfig;
    get sensitiveInformationPolicyConfig(): AwsBedrockGuardrail.SensitiveInformationPolicyConfigPropertyList;
    putSensitiveInformationPolicyConfig(value: AwsBedrockGuardrail.SensitiveInformationPolicyConfigProperty[] | cdktn.IResolvable): void;
    resetSensitiveInformationPolicyConfig(): void;
    get sensitiveInformationPolicyConfigInput(): cdktn.IResolvable | AwsBedrockGuardrail.SensitiveInformationPolicyConfigProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsBedrockGuardrail.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsBedrockGuardrail.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsBedrockGuardrail.TimeoutsProperty | undefined;
    private _topicPolicyConfig;
    get topicPolicyConfig(): AwsBedrockGuardrail.TopicPolicyConfigPropertyList;
    putTopicPolicyConfig(value: AwsBedrockGuardrail.TopicPolicyConfigProperty[] | cdktn.IResolvable): void;
    resetTopicPolicyConfig(): void;
    get topicPolicyConfigInput(): cdktn.IResolvable | AwsBedrockGuardrail.TopicPolicyConfigProperty[] | undefined;
    private _wordPolicyConfig;
    get wordPolicyConfig(): AwsBedrockGuardrail.WordPolicyConfigPropertyList;
    putWordPolicyConfig(value: AwsBedrockGuardrail.WordPolicyConfigProperty[] | cdktn.IResolvable): void;
    resetWordPolicyConfig(): void;
    get wordPolicyConfigInput(): cdktn.IResolvable | AwsBedrockGuardrail.WordPolicyConfigProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsBedrockGuardrailContentPolicyConfigTierConfigPropertyToTerraform(struct?: AwsBedrockGuardrail.ContentPolicyConfigTierConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockGuardrailContentPolicyConfigTierConfigPropertyToHclTerraform(struct?: AwsBedrockGuardrail.ContentPolicyConfigTierConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockGuardrailContentPolicyConfigFiltersConfigPropertyToTerraform(struct?: AwsBedrockGuardrail.ContentPolicyConfigFiltersConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockGuardrailContentPolicyConfigFiltersConfigPropertyToHclTerraform(struct?: AwsBedrockGuardrail.ContentPolicyConfigFiltersConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockGuardrailContentPolicyConfigPropertyToTerraform(struct?: AwsBedrockGuardrail.ContentPolicyConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockGuardrailContentPolicyConfigPropertyToHclTerraform(struct?: AwsBedrockGuardrail.ContentPolicyConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockGuardrailContextualGroundingPolicyConfigFiltersConfigPropertyToTerraform(struct?: AwsBedrockGuardrail.ContextualGroundingPolicyConfigFiltersConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockGuardrailContextualGroundingPolicyConfigFiltersConfigPropertyToHclTerraform(struct?: AwsBedrockGuardrail.ContextualGroundingPolicyConfigFiltersConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockGuardrailContextualGroundingPolicyConfigPropertyToTerraform(struct?: AwsBedrockGuardrail.ContextualGroundingPolicyConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockGuardrailContextualGroundingPolicyConfigPropertyToHclTerraform(struct?: AwsBedrockGuardrail.ContextualGroundingPolicyConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockGuardrailCrossRegionConfigPropertyToTerraform(struct?: AwsBedrockGuardrail.CrossRegionConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockGuardrailCrossRegionConfigPropertyToHclTerraform(struct?: AwsBedrockGuardrail.CrossRegionConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockGuardrailPiiEntitiesConfigPropertyToTerraform(struct?: AwsBedrockGuardrail.PiiEntitiesConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockGuardrailPiiEntitiesConfigPropertyToHclTerraform(struct?: AwsBedrockGuardrail.PiiEntitiesConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockGuardrailRegexesConfigPropertyToTerraform(struct?: AwsBedrockGuardrail.RegexesConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockGuardrailRegexesConfigPropertyToHclTerraform(struct?: AwsBedrockGuardrail.RegexesConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockGuardrailSensitiveInformationPolicyConfigPropertyToTerraform(struct?: AwsBedrockGuardrail.SensitiveInformationPolicyConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockGuardrailSensitiveInformationPolicyConfigPropertyToHclTerraform(struct?: AwsBedrockGuardrail.SensitiveInformationPolicyConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockGuardrailTimeoutsPropertyToTerraform(struct?: AwsBedrockGuardrail.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsBedrockGuardrailTimeoutsPropertyToHclTerraform(struct?: AwsBedrockGuardrail.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsBedrockGuardrailTopicPolicyConfigTierConfigPropertyToTerraform(struct?: AwsBedrockGuardrail.TopicPolicyConfigTierConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockGuardrailTopicPolicyConfigTierConfigPropertyToHclTerraform(struct?: AwsBedrockGuardrail.TopicPolicyConfigTierConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockGuardrailTopicsConfigPropertyToTerraform(struct?: AwsBedrockGuardrail.TopicsConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockGuardrailTopicsConfigPropertyToHclTerraform(struct?: AwsBedrockGuardrail.TopicsConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockGuardrailTopicPolicyConfigPropertyToTerraform(struct?: AwsBedrockGuardrail.TopicPolicyConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockGuardrailTopicPolicyConfigPropertyToHclTerraform(struct?: AwsBedrockGuardrail.TopicPolicyConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockGuardrailManagedWordListsConfigPropertyToTerraform(struct?: AwsBedrockGuardrail.ManagedWordListsConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockGuardrailManagedWordListsConfigPropertyToHclTerraform(struct?: AwsBedrockGuardrail.ManagedWordListsConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockGuardrailWordsConfigPropertyToTerraform(struct?: AwsBedrockGuardrail.WordsConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockGuardrailWordsConfigPropertyToHclTerraform(struct?: AwsBedrockGuardrail.WordsConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockGuardrailWordPolicyConfigPropertyToTerraform(struct?: AwsBedrockGuardrail.WordPolicyConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockGuardrailWordPolicyConfigPropertyToHclTerraform(struct?: AwsBedrockGuardrail.WordPolicyConfigProperty | cdktn.IResolvable): any;
export declare namespace AwsBedrockGuardrail {
    interface ContentPolicyConfigTierConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#tier_name AwsBedrockGuardrail#tier_name}
        */
        readonly tierName?: string;
    }
    class ContentPolicyConfigTierConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ContentPolicyConfigTierConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ContentPolicyConfigTierConfigProperty | cdktn.IResolvable | undefined);
        private _tierName?;
        get tierName(): string;
        set tierName(value: string);
        resetTierName(): void;
        get tierNameInput(): string | undefined;
    }
    class ContentPolicyConfigTierConfigPropertyList extends cdktn.ComplexList {
        internalValue?: ContentPolicyConfigTierConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ContentPolicyConfigTierConfigPropertyOutputReference;
    }
    interface ContentPolicyConfigFiltersConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#input_action AwsBedrockGuardrail#input_action}
        */
        readonly inputAction?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#input_enabled AwsBedrockGuardrail#input_enabled}
        */
        readonly inputEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#input_modalities AwsBedrockGuardrail#input_modalities}
        */
        readonly inputModalities?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#input_strength AwsBedrockGuardrail#input_strength}
        */
        readonly inputStrength: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#output_action AwsBedrockGuardrail#output_action}
        */
        readonly outputAction?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#output_enabled AwsBedrockGuardrail#output_enabled}
        */
        readonly outputEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#output_modalities AwsBedrockGuardrail#output_modalities}
        */
        readonly outputModalities?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#output_strength AwsBedrockGuardrail#output_strength}
        */
        readonly outputStrength: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#type AwsBedrockGuardrail#type}
        */
        readonly type: string;
    }
    class ContentPolicyConfigFiltersConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ContentPolicyConfigFiltersConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ContentPolicyConfigFiltersConfigProperty | cdktn.IResolvable | undefined);
        private _inputAction?;
        get inputAction(): string;
        set inputAction(value: string);
        resetInputAction(): void;
        get inputActionInput(): string | undefined;
        private _inputEnabled?;
        get inputEnabled(): boolean | cdktn.IResolvable;
        set inputEnabled(value: boolean | cdktn.IResolvable);
        resetInputEnabled(): void;
        get inputEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _inputModalities?;
        get inputModalities(): string[];
        set inputModalities(value: string[]);
        resetInputModalities(): void;
        get inputModalitiesInput(): string[] | undefined;
        private _inputStrength?;
        get inputStrength(): string;
        set inputStrength(value: string);
        get inputStrengthInput(): string | undefined;
        private _outputAction?;
        get outputAction(): string;
        set outputAction(value: string);
        resetOutputAction(): void;
        get outputActionInput(): string | undefined;
        private _outputEnabled?;
        get outputEnabled(): boolean | cdktn.IResolvable;
        set outputEnabled(value: boolean | cdktn.IResolvable);
        resetOutputEnabled(): void;
        get outputEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _outputModalities?;
        get outputModalities(): string[];
        set outputModalities(value: string[]);
        resetOutputModalities(): void;
        get outputModalitiesInput(): string[] | undefined;
        private _outputStrength?;
        get outputStrength(): string;
        set outputStrength(value: string);
        get outputStrengthInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class ContentPolicyConfigFiltersConfigPropertyList extends cdktn.ComplexList {
        internalValue?: ContentPolicyConfigFiltersConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ContentPolicyConfigFiltersConfigPropertyOutputReference;
    }
    interface ContentPolicyConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#tier_config AwsBedrockGuardrail#tier_config}
        */
        readonly tierConfig?: ContentPolicyConfigTierConfigProperty[] | cdktn.IResolvable;
        /**
        * filters_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#filters_config AwsBedrockGuardrail#filters_config}
        */
        readonly filtersConfig?: ContentPolicyConfigFiltersConfigProperty[] | cdktn.IResolvable;
    }
    class ContentPolicyConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ContentPolicyConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ContentPolicyConfigProperty | cdktn.IResolvable | undefined);
        private _tierConfig;
        get tierConfig(): ContentPolicyConfigTierConfigPropertyList;
        putTierConfig(value: ContentPolicyConfigTierConfigProperty[] | cdktn.IResolvable): void;
        resetTierConfig(): void;
        get tierConfigInput(): cdktn.IResolvable | ContentPolicyConfigTierConfigProperty[] | undefined;
        private _filtersConfig;
        get filtersConfig(): ContentPolicyConfigFiltersConfigPropertyList;
        putFiltersConfig(value: ContentPolicyConfigFiltersConfigProperty[] | cdktn.IResolvable): void;
        resetFiltersConfig(): void;
        get filtersConfigInput(): cdktn.IResolvable | ContentPolicyConfigFiltersConfigProperty[] | undefined;
    }
    class ContentPolicyConfigPropertyList extends cdktn.ComplexList {
        internalValue?: ContentPolicyConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ContentPolicyConfigPropertyOutputReference;
    }
    interface ContextualGroundingPolicyConfigFiltersConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#threshold AwsBedrockGuardrail#threshold}
        */
        readonly threshold: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#type AwsBedrockGuardrail#type}
        */
        readonly type: string;
    }
    class ContextualGroundingPolicyConfigFiltersConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ContextualGroundingPolicyConfigFiltersConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ContextualGroundingPolicyConfigFiltersConfigProperty | cdktn.IResolvable | undefined);
        private _threshold?;
        get threshold(): number;
        set threshold(value: number);
        get thresholdInput(): number | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class ContextualGroundingPolicyConfigFiltersConfigPropertyList extends cdktn.ComplexList {
        internalValue?: ContextualGroundingPolicyConfigFiltersConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ContextualGroundingPolicyConfigFiltersConfigPropertyOutputReference;
    }
    interface ContextualGroundingPolicyConfigProperty {
        /**
        * filters_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#filters_config AwsBedrockGuardrail#filters_config}
        */
        readonly filtersConfig?: ContextualGroundingPolicyConfigFiltersConfigProperty[] | cdktn.IResolvable;
    }
    class ContextualGroundingPolicyConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ContextualGroundingPolicyConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ContextualGroundingPolicyConfigProperty | cdktn.IResolvable | undefined);
        private _filtersConfig;
        get filtersConfig(): ContextualGroundingPolicyConfigFiltersConfigPropertyList;
        putFiltersConfig(value: ContextualGroundingPolicyConfigFiltersConfigProperty[] | cdktn.IResolvable): void;
        resetFiltersConfig(): void;
        get filtersConfigInput(): cdktn.IResolvable | ContextualGroundingPolicyConfigFiltersConfigProperty[] | undefined;
    }
    class ContextualGroundingPolicyConfigPropertyList extends cdktn.ComplexList {
        internalValue?: ContextualGroundingPolicyConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ContextualGroundingPolicyConfigPropertyOutputReference;
    }
    interface CrossRegionConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#guardrail_profile_identifier AwsBedrockGuardrail#guardrail_profile_identifier}
        */
        readonly guardrailProfileIdentifier: string;
    }
    class CrossRegionConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CrossRegionConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CrossRegionConfigProperty | cdktn.IResolvable | undefined);
        private _guardrailProfileIdentifier?;
        get guardrailProfileIdentifier(): string;
        set guardrailProfileIdentifier(value: string);
        get guardrailProfileIdentifierInput(): string | undefined;
    }
    class CrossRegionConfigPropertyList extends cdktn.ComplexList {
        internalValue?: CrossRegionConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CrossRegionConfigPropertyOutputReference;
    }
    interface PiiEntitiesConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#action AwsBedrockGuardrail#action}
        */
        readonly action: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#input_action AwsBedrockGuardrail#input_action}
        */
        readonly inputAction?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#input_enabled AwsBedrockGuardrail#input_enabled}
        */
        readonly inputEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#output_action AwsBedrockGuardrail#output_action}
        */
        readonly outputAction?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#output_enabled AwsBedrockGuardrail#output_enabled}
        */
        readonly outputEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#type AwsBedrockGuardrail#type}
        */
        readonly type: string;
    }
    class PiiEntitiesConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PiiEntitiesConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PiiEntitiesConfigProperty | cdktn.IResolvable | undefined);
        private _action?;
        get action(): string;
        set action(value: string);
        get actionInput(): string | undefined;
        private _inputAction?;
        get inputAction(): string;
        set inputAction(value: string);
        resetInputAction(): void;
        get inputActionInput(): string | undefined;
        private _inputEnabled?;
        get inputEnabled(): boolean | cdktn.IResolvable;
        set inputEnabled(value: boolean | cdktn.IResolvable);
        resetInputEnabled(): void;
        get inputEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _outputAction?;
        get outputAction(): string;
        set outputAction(value: string);
        resetOutputAction(): void;
        get outputActionInput(): string | undefined;
        private _outputEnabled?;
        get outputEnabled(): boolean | cdktn.IResolvable;
        set outputEnabled(value: boolean | cdktn.IResolvable);
        resetOutputEnabled(): void;
        get outputEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class PiiEntitiesConfigPropertyList extends cdktn.ComplexList {
        internalValue?: PiiEntitiesConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PiiEntitiesConfigPropertyOutputReference;
    }
    interface RegexesConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#action AwsBedrockGuardrail#action}
        */
        readonly action: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#description AwsBedrockGuardrail#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#input_action AwsBedrockGuardrail#input_action}
        */
        readonly inputAction?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#input_enabled AwsBedrockGuardrail#input_enabled}
        */
        readonly inputEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#name AwsBedrockGuardrail#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#output_action AwsBedrockGuardrail#output_action}
        */
        readonly outputAction?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#output_enabled AwsBedrockGuardrail#output_enabled}
        */
        readonly outputEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#pattern AwsBedrockGuardrail#pattern}
        */
        readonly pattern: string;
    }
    class RegexesConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RegexesConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RegexesConfigProperty | cdktn.IResolvable | undefined);
        private _action?;
        get action(): string;
        set action(value: string);
        get actionInput(): string | undefined;
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _inputAction?;
        get inputAction(): string;
        set inputAction(value: string);
        resetInputAction(): void;
        get inputActionInput(): string | undefined;
        private _inputEnabled?;
        get inputEnabled(): boolean | cdktn.IResolvable;
        set inputEnabled(value: boolean | cdktn.IResolvable);
        resetInputEnabled(): void;
        get inputEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _outputAction?;
        get outputAction(): string;
        set outputAction(value: string);
        resetOutputAction(): void;
        get outputActionInput(): string | undefined;
        private _outputEnabled?;
        get outputEnabled(): boolean | cdktn.IResolvable;
        set outputEnabled(value: boolean | cdktn.IResolvable);
        resetOutputEnabled(): void;
        get outputEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _pattern?;
        get pattern(): string;
        set pattern(value: string);
        get patternInput(): string | undefined;
    }
    class RegexesConfigPropertyList extends cdktn.ComplexList {
        internalValue?: RegexesConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RegexesConfigPropertyOutputReference;
    }
    interface SensitiveInformationPolicyConfigProperty {
        /**
        * pii_entities_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#pii_entities_config AwsBedrockGuardrail#pii_entities_config}
        */
        readonly piiEntitiesConfig?: PiiEntitiesConfigProperty[] | cdktn.IResolvable;
        /**
        * regexes_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#regexes_config AwsBedrockGuardrail#regexes_config}
        */
        readonly regexesConfig?: RegexesConfigProperty[] | cdktn.IResolvable;
    }
    class SensitiveInformationPolicyConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SensitiveInformationPolicyConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SensitiveInformationPolicyConfigProperty | cdktn.IResolvable | undefined);
        private _piiEntitiesConfig;
        get piiEntitiesConfig(): PiiEntitiesConfigPropertyList;
        putPiiEntitiesConfig(value: PiiEntitiesConfigProperty[] | cdktn.IResolvable): void;
        resetPiiEntitiesConfig(): void;
        get piiEntitiesConfigInput(): cdktn.IResolvable | PiiEntitiesConfigProperty[] | undefined;
        private _regexesConfig;
        get regexesConfig(): RegexesConfigPropertyList;
        putRegexesConfig(value: RegexesConfigProperty[] | cdktn.IResolvable): void;
        resetRegexesConfig(): void;
        get regexesConfigInput(): cdktn.IResolvable | RegexesConfigProperty[] | undefined;
    }
    class SensitiveInformationPolicyConfigPropertyList extends cdktn.ComplexList {
        internalValue?: SensitiveInformationPolicyConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SensitiveInformationPolicyConfigPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#create AwsBedrockGuardrail#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#delete AwsBedrockGuardrail#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#update AwsBedrockGuardrail#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface TopicPolicyConfigTierConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#tier_name AwsBedrockGuardrail#tier_name}
        */
        readonly tierName?: string;
    }
    class TopicPolicyConfigTierConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TopicPolicyConfigTierConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TopicPolicyConfigTierConfigProperty | cdktn.IResolvable | undefined);
        private _tierName?;
        get tierName(): string;
        set tierName(value: string);
        resetTierName(): void;
        get tierNameInput(): string | undefined;
    }
    class TopicPolicyConfigTierConfigPropertyList extends cdktn.ComplexList {
        internalValue?: TopicPolicyConfigTierConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TopicPolicyConfigTierConfigPropertyOutputReference;
    }
    interface TopicsConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#definition AwsBedrockGuardrail#definition}
        */
        readonly definition: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#examples AwsBedrockGuardrail#examples}
        */
        readonly examples?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#name AwsBedrockGuardrail#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#type AwsBedrockGuardrail#type}
        */
        readonly type: string;
    }
    class TopicsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TopicsConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TopicsConfigProperty | cdktn.IResolvable | undefined);
        private _definition?;
        get definition(): string;
        set definition(value: string);
        get definitionInput(): string | undefined;
        private _examples?;
        get examples(): string[];
        set examples(value: string[]);
        resetExamples(): void;
        get examplesInput(): string[] | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class TopicsConfigPropertyList extends cdktn.ComplexList {
        internalValue?: TopicsConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TopicsConfigPropertyOutputReference;
    }
    interface TopicPolicyConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#tier_config AwsBedrockGuardrail#tier_config}
        */
        readonly tierConfig?: TopicPolicyConfigTierConfigProperty[] | cdktn.IResolvable;
        /**
        * topics_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#topics_config AwsBedrockGuardrail#topics_config}
        */
        readonly topicsConfig?: TopicsConfigProperty[] | cdktn.IResolvable;
    }
    class TopicPolicyConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TopicPolicyConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TopicPolicyConfigProperty | cdktn.IResolvable | undefined);
        private _tierConfig;
        get tierConfig(): TopicPolicyConfigTierConfigPropertyList;
        putTierConfig(value: TopicPolicyConfigTierConfigProperty[] | cdktn.IResolvable): void;
        resetTierConfig(): void;
        get tierConfigInput(): cdktn.IResolvable | TopicPolicyConfigTierConfigProperty[] | undefined;
        private _topicsConfig;
        get topicsConfig(): TopicsConfigPropertyList;
        putTopicsConfig(value: TopicsConfigProperty[] | cdktn.IResolvable): void;
        resetTopicsConfig(): void;
        get topicsConfigInput(): cdktn.IResolvable | TopicsConfigProperty[] | undefined;
    }
    class TopicPolicyConfigPropertyList extends cdktn.ComplexList {
        internalValue?: TopicPolicyConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TopicPolicyConfigPropertyOutputReference;
    }
    interface ManagedWordListsConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#input_action AwsBedrockGuardrail#input_action}
        */
        readonly inputAction?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#input_enabled AwsBedrockGuardrail#input_enabled}
        */
        readonly inputEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#output_action AwsBedrockGuardrail#output_action}
        */
        readonly outputAction?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#output_enabled AwsBedrockGuardrail#output_enabled}
        */
        readonly outputEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#type AwsBedrockGuardrail#type}
        */
        readonly type: string;
    }
    class ManagedWordListsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ManagedWordListsConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ManagedWordListsConfigProperty | cdktn.IResolvable | undefined);
        private _inputAction?;
        get inputAction(): string;
        set inputAction(value: string);
        resetInputAction(): void;
        get inputActionInput(): string | undefined;
        private _inputEnabled?;
        get inputEnabled(): boolean | cdktn.IResolvable;
        set inputEnabled(value: boolean | cdktn.IResolvable);
        resetInputEnabled(): void;
        get inputEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _outputAction?;
        get outputAction(): string;
        set outputAction(value: string);
        resetOutputAction(): void;
        get outputActionInput(): string | undefined;
        private _outputEnabled?;
        get outputEnabled(): boolean | cdktn.IResolvable;
        set outputEnabled(value: boolean | cdktn.IResolvable);
        resetOutputEnabled(): void;
        get outputEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class ManagedWordListsConfigPropertyList extends cdktn.ComplexList {
        internalValue?: ManagedWordListsConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ManagedWordListsConfigPropertyOutputReference;
    }
    interface WordsConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#input_action AwsBedrockGuardrail#input_action}
        */
        readonly inputAction?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#input_enabled AwsBedrockGuardrail#input_enabled}
        */
        readonly inputEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#output_action AwsBedrockGuardrail#output_action}
        */
        readonly outputAction?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#output_enabled AwsBedrockGuardrail#output_enabled}
        */
        readonly outputEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#text AwsBedrockGuardrail#text}
        */
        readonly text: string;
    }
    class WordsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WordsConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WordsConfigProperty | cdktn.IResolvable | undefined);
        private _inputAction?;
        get inputAction(): string;
        set inputAction(value: string);
        resetInputAction(): void;
        get inputActionInput(): string | undefined;
        private _inputEnabled?;
        get inputEnabled(): boolean | cdktn.IResolvable;
        set inputEnabled(value: boolean | cdktn.IResolvable);
        resetInputEnabled(): void;
        get inputEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _outputAction?;
        get outputAction(): string;
        set outputAction(value: string);
        resetOutputAction(): void;
        get outputActionInput(): string | undefined;
        private _outputEnabled?;
        get outputEnabled(): boolean | cdktn.IResolvable;
        set outputEnabled(value: boolean | cdktn.IResolvable);
        resetOutputEnabled(): void;
        get outputEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _text?;
        get text(): string;
        set text(value: string);
        get textInput(): string | undefined;
    }
    class WordsConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WordsConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WordsConfigPropertyOutputReference;
    }
    interface WordPolicyConfigProperty {
        /**
        * managed_word_lists_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#managed_word_lists_config AwsBedrockGuardrail#managed_word_lists_config}
        */
        readonly managedWordListsConfig?: ManagedWordListsConfigProperty[] | cdktn.IResolvable;
        /**
        * words_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_guardrail#words_config AwsBedrockGuardrail#words_config}
        */
        readonly wordsConfig?: WordsConfigProperty[] | cdktn.IResolvable;
    }
    class WordPolicyConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WordPolicyConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WordPolicyConfigProperty | cdktn.IResolvable | undefined);
        private _managedWordListsConfig;
        get managedWordListsConfig(): ManagedWordListsConfigPropertyList;
        putManagedWordListsConfig(value: ManagedWordListsConfigProperty[] | cdktn.IResolvable): void;
        resetManagedWordListsConfig(): void;
        get managedWordListsConfigInput(): cdktn.IResolvable | ManagedWordListsConfigProperty[] | undefined;
        private _wordsConfig;
        get wordsConfig(): WordsConfigPropertyList;
        putWordsConfig(value: WordsConfigProperty[] | cdktn.IResolvable): void;
        resetWordsConfig(): void;
        get wordsConfigInput(): cdktn.IResolvable | WordsConfigProperty[] | undefined;
    }
    class WordPolicyConfigPropertyList extends cdktn.ComplexList {
        internalValue?: WordPolicyConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WordPolicyConfigPropertyOutputReference;
    }
}
