import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsBedrockCustomModelConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#base_model_identifier AwsBedrockCustomModel#base_model_identifier}
    */
    readonly baseModelIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#custom_model_kms_key_id AwsBedrockCustomModel#custom_model_kms_key_id}
    */
    readonly customModelKmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#custom_model_name AwsBedrockCustomModel#custom_model_name}
    */
    readonly customModelName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#customization_type AwsBedrockCustomModel#customization_type}
    */
    readonly customizationType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#hyperparameters AwsBedrockCustomModel#hyperparameters}
    */
    readonly hyperparameters: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#job_name AwsBedrockCustomModel#job_name}
    */
    readonly jobName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#region AwsBedrockCustomModel#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#role_arn AwsBedrockCustomModel#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#tags AwsBedrockCustomModel#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * output_data_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#output_data_config AwsBedrockCustomModel#output_data_config}
    */
    readonly outputDataConfig?: AwsBedrockCustomModel.OutputDataConfigProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#timeouts AwsBedrockCustomModel#timeouts}
    */
    readonly timeouts?: AwsBedrockCustomModel.TimeoutsProperty;
    /**
    * training_data_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#training_data_config AwsBedrockCustomModel#training_data_config}
    */
    readonly trainingDataConfig?: AwsBedrockCustomModel.TrainingDataConfigProperty[] | cdktn.IResolvable;
    /**
    * validation_data_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#validation_data_config AwsBedrockCustomModel#validation_data_config}
    */
    readonly validationDataConfig?: AwsBedrockCustomModel.ValidationDataConfigProperty[] | cdktn.IResolvable;
    /**
    * vpc_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#vpc_config AwsBedrockCustomModel#vpc_config}
    */
    readonly vpcConfig?: AwsBedrockCustomModel.VpcConfigProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model aws_bedrock_custom_model}
*/
export declare class AwsBedrockCustomModel extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrock_custom_model";
    /**
    * Generates CDKTN code for importing a AwsBedrockCustomModel resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsBedrockCustomModel to import
    * @param importFromId The id of the existing AwsBedrockCustomModel that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsBedrockCustomModel to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model aws_bedrock_custom_model} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsBedrockCustomModelConfig
    */
    constructor(scope: Construct, id: string, config: AwsBedrockCustomModelConfig);
    private _baseModelIdentifier?;
    get baseModelIdentifier(): string;
    set baseModelIdentifier(value: string);
    get baseModelIdentifierInput(): string | undefined;
    get customModelArn(): string;
    private _customModelKmsKeyId?;
    get customModelKmsKeyId(): string;
    set customModelKmsKeyId(value: string);
    resetCustomModelKmsKeyId(): void;
    get customModelKmsKeyIdInput(): string | undefined;
    private _customModelName?;
    get customModelName(): string;
    set customModelName(value: string);
    get customModelNameInput(): string | undefined;
    private _customizationType?;
    get customizationType(): string;
    set customizationType(value: string);
    resetCustomizationType(): void;
    get customizationTypeInput(): string | undefined;
    private _hyperparameters?;
    get hyperparameters(): {
        [key: string]: string;
    };
    set hyperparameters(value: {
        [key: string]: string;
    });
    get hyperparametersInput(): {
        [key: string]: string;
    } | undefined;
    get id(): string;
    get jobArn(): string;
    private _jobName?;
    get jobName(): string;
    set jobName(value: string);
    get jobNameInput(): string | undefined;
    get jobStatus(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _trainingMetrics;
    get trainingMetrics(): AwsBedrockCustomModel.TrainingMetricsPropertyList;
    private _validationMetrics;
    get validationMetrics(): AwsBedrockCustomModel.ValidationMetricsPropertyList;
    private _outputDataConfig;
    get outputDataConfig(): AwsBedrockCustomModel.OutputDataConfigPropertyList;
    putOutputDataConfig(value: AwsBedrockCustomModel.OutputDataConfigProperty[] | cdktn.IResolvable): void;
    resetOutputDataConfig(): void;
    get outputDataConfigInput(): cdktn.IResolvable | AwsBedrockCustomModel.OutputDataConfigProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsBedrockCustomModel.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsBedrockCustomModel.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsBedrockCustomModel.TimeoutsProperty | undefined;
    private _trainingDataConfig;
    get trainingDataConfig(): AwsBedrockCustomModel.TrainingDataConfigPropertyList;
    putTrainingDataConfig(value: AwsBedrockCustomModel.TrainingDataConfigProperty[] | cdktn.IResolvable): void;
    resetTrainingDataConfig(): void;
    get trainingDataConfigInput(): cdktn.IResolvable | AwsBedrockCustomModel.TrainingDataConfigProperty[] | undefined;
    private _validationDataConfig;
    get validationDataConfig(): AwsBedrockCustomModel.ValidationDataConfigPropertyList;
    putValidationDataConfig(value: AwsBedrockCustomModel.ValidationDataConfigProperty[] | cdktn.IResolvable): void;
    resetValidationDataConfig(): void;
    get validationDataConfigInput(): cdktn.IResolvable | AwsBedrockCustomModel.ValidationDataConfigProperty[] | undefined;
    private _vpcConfig;
    get vpcConfig(): AwsBedrockCustomModel.VpcConfigPropertyList;
    putVpcConfig(value: AwsBedrockCustomModel.VpcConfigProperty[] | cdktn.IResolvable): void;
    resetVpcConfig(): void;
    get vpcConfigInput(): cdktn.IResolvable | AwsBedrockCustomModel.VpcConfigProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsBedrockCustomModelTrainingMetricsPropertyToTerraform(struct?: AwsBedrockCustomModel.TrainingMetricsProperty): any;
export declare function awsBedrockCustomModelTrainingMetricsPropertyToHclTerraform(struct?: AwsBedrockCustomModel.TrainingMetricsProperty): any;
export declare function awsBedrockCustomModelValidationMetricsPropertyToTerraform(struct?: AwsBedrockCustomModel.ValidationMetricsProperty): any;
export declare function awsBedrockCustomModelValidationMetricsPropertyToHclTerraform(struct?: AwsBedrockCustomModel.ValidationMetricsProperty): any;
export declare function awsBedrockCustomModelOutputDataConfigPropertyToTerraform(struct?: AwsBedrockCustomModel.OutputDataConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockCustomModelOutputDataConfigPropertyToHclTerraform(struct?: AwsBedrockCustomModel.OutputDataConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockCustomModelTimeoutsPropertyToTerraform(struct?: AwsBedrockCustomModel.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsBedrockCustomModelTimeoutsPropertyToHclTerraform(struct?: AwsBedrockCustomModel.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsBedrockCustomModelTrainingDataConfigPropertyToTerraform(struct?: AwsBedrockCustomModel.TrainingDataConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockCustomModelTrainingDataConfigPropertyToHclTerraform(struct?: AwsBedrockCustomModel.TrainingDataConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockCustomModelValidatorPropertyToTerraform(struct?: AwsBedrockCustomModel.ValidatorProperty | cdktn.IResolvable): any;
export declare function awsBedrockCustomModelValidatorPropertyToHclTerraform(struct?: AwsBedrockCustomModel.ValidatorProperty | cdktn.IResolvable): any;
export declare function awsBedrockCustomModelValidationDataConfigPropertyToTerraform(struct?: AwsBedrockCustomModel.ValidationDataConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockCustomModelValidationDataConfigPropertyToHclTerraform(struct?: AwsBedrockCustomModel.ValidationDataConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockCustomModelVpcConfigPropertyToTerraform(struct?: AwsBedrockCustomModel.VpcConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockCustomModelVpcConfigPropertyToHclTerraform(struct?: AwsBedrockCustomModel.VpcConfigProperty | cdktn.IResolvable): any;
export declare namespace AwsBedrockCustomModel {
    interface TrainingMetricsProperty {
    }
    class TrainingMetricsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingMetricsProperty | undefined;
        set internalValue(value: TrainingMetricsProperty | undefined);
        get trainingLoss(): number;
    }
    class TrainingMetricsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingMetricsPropertyOutputReference;
    }
    interface ValidationMetricsProperty {
    }
    class ValidationMetricsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ValidationMetricsProperty | undefined;
        set internalValue(value: ValidationMetricsProperty | undefined);
        get validationLoss(): number;
    }
    class ValidationMetricsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ValidationMetricsPropertyOutputReference;
    }
    interface OutputDataConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#s3_uri AwsBedrockCustomModel#s3_uri}
        */
        readonly s3Uri: string;
    }
    class OutputDataConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OutputDataConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OutputDataConfigProperty | cdktn.IResolvable | undefined);
        private _s3Uri?;
        get s3Uri(): string;
        set s3Uri(value: string);
        get s3UriInput(): string | undefined;
    }
    class OutputDataConfigPropertyList extends cdktn.ComplexList {
        internalValue?: OutputDataConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OutputDataConfigPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#create AwsBedrockCustomModel#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#delete AwsBedrockCustomModel#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
    interface TrainingDataConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#s3_uri AwsBedrockCustomModel#s3_uri}
        */
        readonly s3Uri: string;
    }
    class TrainingDataConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingDataConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingDataConfigProperty | cdktn.IResolvable | undefined);
        private _s3Uri?;
        get s3Uri(): string;
        set s3Uri(value: string);
        get s3UriInput(): string | undefined;
    }
    class TrainingDataConfigPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingDataConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingDataConfigPropertyOutputReference;
    }
    interface ValidatorProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#s3_uri AwsBedrockCustomModel#s3_uri}
        */
        readonly s3Uri: string;
    }
    class ValidatorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ValidatorProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ValidatorProperty | cdktn.IResolvable | undefined);
        private _s3Uri?;
        get s3Uri(): string;
        set s3Uri(value: string);
        get s3UriInput(): string | undefined;
    }
    class ValidatorPropertyList extends cdktn.ComplexList {
        internalValue?: ValidatorProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ValidatorPropertyOutputReference;
    }
    interface ValidationDataConfigProperty {
        /**
        * validator block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#validator AwsBedrockCustomModel#validator}
        */
        readonly validator?: ValidatorProperty[] | cdktn.IResolvable;
    }
    class ValidationDataConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ValidationDataConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ValidationDataConfigProperty | cdktn.IResolvable | undefined);
        private _validator;
        get validator(): ValidatorPropertyList;
        putValidator(value: ValidatorProperty[] | cdktn.IResolvable): void;
        resetValidator(): void;
        get validatorInput(): cdktn.IResolvable | ValidatorProperty[] | undefined;
    }
    class ValidationDataConfigPropertyList extends cdktn.ComplexList {
        internalValue?: ValidationDataConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ValidationDataConfigPropertyOutputReference;
    }
    interface VpcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#security_group_ids AwsBedrockCustomModel#security_group_ids}
        */
        readonly securityGroupIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#subnet_ids AwsBedrockCustomModel#subnet_ids}
        */
        readonly subnetIds: string[];
    }
    class VpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpcConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VpcConfigProperty | cdktn.IResolvable | undefined);
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
    }
    class VpcConfigPropertyList extends cdktn.ComplexList {
        internalValue?: VpcConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpcConfigPropertyOutputReference;
    }
}
