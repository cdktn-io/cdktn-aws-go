import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsBedrockEvaluationJobConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#application_type AwsBedrockEvaluationJob#application_type}
    */
    readonly applicationType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#customer_encryption_key_id AwsBedrockEvaluationJob#customer_encryption_key_id}
    */
    readonly customerEncryptionKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#job_description AwsBedrockEvaluationJob#job_description}
    */
    readonly jobDescription?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#job_name AwsBedrockEvaluationJob#job_name}
    */
    readonly jobName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#region AwsBedrockEvaluationJob#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#role_arn AwsBedrockEvaluationJob#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#skip_destroy AwsBedrockEvaluationJob#skip_destroy}
    */
    readonly skipDestroy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#tags AwsBedrockEvaluationJob#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * evaluation_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#evaluation_config AwsBedrockEvaluationJob#evaluation_config}
    */
    readonly evaluationConfig?: AwsBedrockEvaluationJob.EvaluationConfigProperty[] | cdktn.IResolvable;
    /**
    * inference_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#inference_config AwsBedrockEvaluationJob#inference_config}
    */
    readonly inferenceConfig?: AwsBedrockEvaluationJob.InferenceConfigProperty[] | cdktn.IResolvable;
    /**
    * output_data_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#output_data_config AwsBedrockEvaluationJob#output_data_config}
    */
    readonly outputDataConfig?: AwsBedrockEvaluationJob.OutputDataConfigProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#timeouts AwsBedrockEvaluationJob#timeouts}
    */
    readonly timeouts?: AwsBedrockEvaluationJob.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job aws_bedrock_evaluation_job}
*/
export declare class AwsBedrockEvaluationJob extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrock_evaluation_job";
    /**
    * Generates CDKTN code for importing a AwsBedrockEvaluationJob resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsBedrockEvaluationJob to import
    * @param importFromId The id of the existing AwsBedrockEvaluationJob that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsBedrockEvaluationJob to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job aws_bedrock_evaluation_job} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsBedrockEvaluationJobConfig
    */
    constructor(scope: Construct, id: string, config: AwsBedrockEvaluationJobConfig);
    private _applicationType?;
    get applicationType(): string;
    set applicationType(value: string);
    resetApplicationType(): void;
    get applicationTypeInput(): string | undefined;
    get createdAt(): string;
    private _customerEncryptionKeyId?;
    get customerEncryptionKeyId(): string;
    set customerEncryptionKeyId(value: string);
    resetCustomerEncryptionKeyId(): void;
    get customerEncryptionKeyIdInput(): string | undefined;
    get failureMessages(): string[];
    get jobArn(): string;
    private _jobDescription?;
    get jobDescription(): string;
    set jobDescription(value: string);
    resetJobDescription(): void;
    get jobDescriptionInput(): string | undefined;
    private _jobName?;
    get jobName(): string;
    set jobName(value: string);
    get jobNameInput(): string | undefined;
    get jobType(): string;
    get lastModifiedTime(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _skipDestroy?;
    get skipDestroy(): boolean | cdktn.IResolvable;
    set skipDestroy(value: boolean | cdktn.IResolvable);
    resetSkipDestroy(): void;
    get skipDestroyInput(): boolean | cdktn.IResolvable | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _evaluationConfig;
    get evaluationConfig(): AwsBedrockEvaluationJob.EvaluationConfigPropertyList;
    putEvaluationConfig(value: AwsBedrockEvaluationJob.EvaluationConfigProperty[] | cdktn.IResolvable): void;
    resetEvaluationConfig(): void;
    get evaluationConfigInput(): cdktn.IResolvable | AwsBedrockEvaluationJob.EvaluationConfigProperty[] | undefined;
    private _inferenceConfig;
    get inferenceConfig(): AwsBedrockEvaluationJob.InferenceConfigPropertyList;
    putInferenceConfig(value: AwsBedrockEvaluationJob.InferenceConfigProperty[] | cdktn.IResolvable): void;
    resetInferenceConfig(): void;
    get inferenceConfigInput(): cdktn.IResolvable | AwsBedrockEvaluationJob.InferenceConfigProperty[] | undefined;
    private _outputDataConfig;
    get outputDataConfig(): AwsBedrockEvaluationJob.OutputDataConfigPropertyList;
    putOutputDataConfig(value: AwsBedrockEvaluationJob.OutputDataConfigProperty[] | cdktn.IResolvable): void;
    resetOutputDataConfig(): void;
    get outputDataConfigInput(): cdktn.IResolvable | AwsBedrockEvaluationJob.OutputDataConfigProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsBedrockEvaluationJob.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsBedrockEvaluationJob.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsBedrockEvaluationJob.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsBedrockEvaluationJobValuePropertyToTerraform(struct?: AwsBedrockEvaluationJob.ValueProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobValuePropertyToHclTerraform(struct?: AwsBedrockEvaluationJob.ValueProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobRatingScalePropertyToTerraform(struct?: AwsBedrockEvaluationJob.RatingScaleProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobRatingScalePropertyToHclTerraform(struct?: AwsBedrockEvaluationJob.RatingScaleProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobCustomMetricDefinitionPropertyToTerraform(struct?: AwsBedrockEvaluationJob.CustomMetricDefinitionProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobCustomMetricDefinitionPropertyToHclTerraform(struct?: AwsBedrockEvaluationJob.CustomMetricDefinitionProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricPropertyToTerraform(struct?: AwsBedrockEvaluationJob.EvaluationConfigAutomatedCustomMetricConfigCustomMetricProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigCustomMetricPropertyToHclTerraform(struct?: AwsBedrockEvaluationJob.EvaluationConfigAutomatedCustomMetricConfigCustomMetricProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigBedrockEvaluatorModelPropertyToTerraform(struct?: AwsBedrockEvaluationJob.EvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigBedrockEvaluatorModelProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigBedrockEvaluatorModelPropertyToHclTerraform(struct?: AwsBedrockEvaluationJob.EvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigBedrockEvaluatorModelProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigPropertyToTerraform(struct?: AwsBedrockEvaluationJob.EvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobEvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigPropertyToHclTerraform(struct?: AwsBedrockEvaluationJob.EvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobCustomMetricConfigPropertyToTerraform(struct?: AwsBedrockEvaluationJob.CustomMetricConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobCustomMetricConfigPropertyToHclTerraform(struct?: AwsBedrockEvaluationJob.CustomMetricConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfigDatasetDatasetLocationPropertyToTerraform(struct?: AwsBedrockEvaluationJob.EvaluationConfigAutomatedDatasetMetricConfigDatasetDatasetLocationProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfigDatasetDatasetLocationPropertyToHclTerraform(struct?: AwsBedrockEvaluationJob.EvaluationConfigAutomatedDatasetMetricConfigDatasetDatasetLocationProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfigDatasetPropertyToTerraform(struct?: AwsBedrockEvaluationJob.EvaluationConfigAutomatedDatasetMetricConfigDatasetProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfigDatasetPropertyToHclTerraform(struct?: AwsBedrockEvaluationJob.EvaluationConfigAutomatedDatasetMetricConfigDatasetProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfigPropertyToTerraform(struct?: AwsBedrockEvaluationJob.EvaluationConfigAutomatedDatasetMetricConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobEvaluationConfigAutomatedDatasetMetricConfigPropertyToHclTerraform(struct?: AwsBedrockEvaluationJob.EvaluationConfigAutomatedDatasetMetricConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobEvaluationConfigAutomatedEvaluatorModelConfigBedrockEvaluatorModelPropertyToTerraform(struct?: AwsBedrockEvaluationJob.EvaluationConfigAutomatedEvaluatorModelConfigBedrockEvaluatorModelProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobEvaluationConfigAutomatedEvaluatorModelConfigBedrockEvaluatorModelPropertyToHclTerraform(struct?: AwsBedrockEvaluationJob.EvaluationConfigAutomatedEvaluatorModelConfigBedrockEvaluatorModelProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobEvaluationConfigAutomatedEvaluatorModelConfigPropertyToTerraform(struct?: AwsBedrockEvaluationJob.EvaluationConfigAutomatedEvaluatorModelConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobEvaluationConfigAutomatedEvaluatorModelConfigPropertyToHclTerraform(struct?: AwsBedrockEvaluationJob.EvaluationConfigAutomatedEvaluatorModelConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobAutomatedPropertyToTerraform(struct?: AwsBedrockEvaluationJob.AutomatedProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobAutomatedPropertyToHclTerraform(struct?: AwsBedrockEvaluationJob.AutomatedProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobEvaluationConfigHumanCustomMetricPropertyToTerraform(struct?: AwsBedrockEvaluationJob.EvaluationConfigHumanCustomMetricProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobEvaluationConfigHumanCustomMetricPropertyToHclTerraform(struct?: AwsBedrockEvaluationJob.EvaluationConfigHumanCustomMetricProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfigDatasetDatasetLocationPropertyToTerraform(struct?: AwsBedrockEvaluationJob.EvaluationConfigHumanDatasetMetricConfigDatasetDatasetLocationProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfigDatasetDatasetLocationPropertyToHclTerraform(struct?: AwsBedrockEvaluationJob.EvaluationConfigHumanDatasetMetricConfigDatasetDatasetLocationProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfigDatasetPropertyToTerraform(struct?: AwsBedrockEvaluationJob.EvaluationConfigHumanDatasetMetricConfigDatasetProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfigDatasetPropertyToHclTerraform(struct?: AwsBedrockEvaluationJob.EvaluationConfigHumanDatasetMetricConfigDatasetProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfigPropertyToTerraform(struct?: AwsBedrockEvaluationJob.EvaluationConfigHumanDatasetMetricConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobEvaluationConfigHumanDatasetMetricConfigPropertyToHclTerraform(struct?: AwsBedrockEvaluationJob.EvaluationConfigHumanDatasetMetricConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobHumanWorkflowConfigPropertyToTerraform(struct?: AwsBedrockEvaluationJob.HumanWorkflowConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobHumanWorkflowConfigPropertyToHclTerraform(struct?: AwsBedrockEvaluationJob.HumanWorkflowConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobHumanPropertyToTerraform(struct?: AwsBedrockEvaluationJob.HumanProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobHumanPropertyToHclTerraform(struct?: AwsBedrockEvaluationJob.HumanProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobEvaluationConfigPropertyToTerraform(struct?: AwsBedrockEvaluationJob.EvaluationConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobEvaluationConfigPropertyToHclTerraform(struct?: AwsBedrockEvaluationJob.EvaluationConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobPerformanceConfigPropertyToTerraform(struct?: AwsBedrockEvaluationJob.PerformanceConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobPerformanceConfigPropertyToHclTerraform(struct?: AwsBedrockEvaluationJob.PerformanceConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobBedrockModelPropertyToTerraform(struct?: AwsBedrockEvaluationJob.BedrockModelProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobBedrockModelPropertyToHclTerraform(struct?: AwsBedrockEvaluationJob.BedrockModelProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobPrecomputedInferenceSourcePropertyToTerraform(struct?: AwsBedrockEvaluationJob.PrecomputedInferenceSourceProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobPrecomputedInferenceSourcePropertyToHclTerraform(struct?: AwsBedrockEvaluationJob.PrecomputedInferenceSourceProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobModelPropertyToTerraform(struct?: AwsBedrockEvaluationJob.ModelProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobModelPropertyToHclTerraform(struct?: AwsBedrockEvaluationJob.ModelProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfigurationVectorSearchConfigurationPropertyToTerraform(struct?: AwsBedrockEvaluationJob.InferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfigurationVectorSearchConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfigurationVectorSearchConfigurationPropertyToHclTerraform(struct?: AwsBedrockEvaluationJob.InferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfigurationVectorSearchConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobRetrievalConfigurationPropertyToTerraform(struct?: AwsBedrockEvaluationJob.RetrievalConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobRetrievalConfigurationPropertyToHclTerraform(struct?: AwsBedrockEvaluationJob.RetrievalConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobRetrieveAndGenerateConfigPropertyToTerraform(struct?: AwsBedrockEvaluationJob.RetrieveAndGenerateConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobRetrieveAndGenerateConfigPropertyToHclTerraform(struct?: AwsBedrockEvaluationJob.RetrieveAndGenerateConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfigurationVectorSearchConfigurationPropertyToTerraform(struct?: AwsBedrockEvaluationJob.InferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfigurationVectorSearchConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobInferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfigurationVectorSearchConfigurationPropertyToHclTerraform(struct?: AwsBedrockEvaluationJob.InferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfigurationVectorSearchConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobKnowledgeBaseRetrievalConfigurationPropertyToTerraform(struct?: AwsBedrockEvaluationJob.KnowledgeBaseRetrievalConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobKnowledgeBaseRetrievalConfigurationPropertyToHclTerraform(struct?: AwsBedrockEvaluationJob.KnowledgeBaseRetrievalConfigurationProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobRetrieveConfigPropertyToTerraform(struct?: AwsBedrockEvaluationJob.RetrieveConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobRetrieveConfigPropertyToHclTerraform(struct?: AwsBedrockEvaluationJob.RetrieveConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobKnowledgeBaseConfigPropertyToTerraform(struct?: AwsBedrockEvaluationJob.KnowledgeBaseConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobKnowledgeBaseConfigPropertyToHclTerraform(struct?: AwsBedrockEvaluationJob.KnowledgeBaseConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobRetrieveAndGenerateSourceConfigPropertyToTerraform(struct?: AwsBedrockEvaluationJob.RetrieveAndGenerateSourceConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobRetrieveAndGenerateSourceConfigPropertyToHclTerraform(struct?: AwsBedrockEvaluationJob.RetrieveAndGenerateSourceConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobRetrieveSourceConfigPropertyToTerraform(struct?: AwsBedrockEvaluationJob.RetrieveSourceConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobRetrieveSourceConfigPropertyToHclTerraform(struct?: AwsBedrockEvaluationJob.RetrieveSourceConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobPrecomputedRagSourceConfigPropertyToTerraform(struct?: AwsBedrockEvaluationJob.PrecomputedRagSourceConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobPrecomputedRagSourceConfigPropertyToHclTerraform(struct?: AwsBedrockEvaluationJob.PrecomputedRagSourceConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobRagConfigPropertyToTerraform(struct?: AwsBedrockEvaluationJob.RagConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobRagConfigPropertyToHclTerraform(struct?: AwsBedrockEvaluationJob.RagConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobInferenceConfigPropertyToTerraform(struct?: AwsBedrockEvaluationJob.InferenceConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobInferenceConfigPropertyToHclTerraform(struct?: AwsBedrockEvaluationJob.InferenceConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobOutputDataConfigPropertyToTerraform(struct?: AwsBedrockEvaluationJob.OutputDataConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobOutputDataConfigPropertyToHclTerraform(struct?: AwsBedrockEvaluationJob.OutputDataConfigProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobTimeoutsPropertyToTerraform(struct?: AwsBedrockEvaluationJob.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsBedrockEvaluationJobTimeoutsPropertyToHclTerraform(struct?: AwsBedrockEvaluationJob.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsBedrockEvaluationJob {
    interface ValueProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#float_value AwsBedrockEvaluationJob#float_value}
        */
        readonly floatValue?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#string_value AwsBedrockEvaluationJob#string_value}
        */
        readonly stringValue?: string;
    }
    class ValuePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ValueProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ValueProperty | cdktn.IResolvable | undefined);
        private _floatValue?;
        get floatValue(): number;
        set floatValue(value: number);
        resetFloatValue(): void;
        get floatValueInput(): number | undefined;
        private _stringValue?;
        get stringValue(): string;
        set stringValue(value: string);
        resetStringValue(): void;
        get stringValueInput(): string | undefined;
    }
    class ValuePropertyList extends cdktn.ComplexList {
        internalValue?: ValueProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ValuePropertyOutputReference;
    }
    interface RatingScaleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#definition AwsBedrockEvaluationJob#definition}
        */
        readonly definition: string;
        /**
        * value block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#value AwsBedrockEvaluationJob#value}
        */
        readonly value?: ValueProperty[] | cdktn.IResolvable;
    }
    class RatingScalePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RatingScaleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RatingScaleProperty | cdktn.IResolvable | undefined);
        private _definition?;
        get definition(): string;
        set definition(value: string);
        get definitionInput(): string | undefined;
        private _value;
        get value(): ValuePropertyList;
        putValue(value: ValueProperty[] | cdktn.IResolvable): void;
        resetValue(): void;
        get valueInput(): cdktn.IResolvable | ValueProperty[] | undefined;
    }
    class RatingScalePropertyList extends cdktn.ComplexList {
        internalValue?: RatingScaleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RatingScalePropertyOutputReference;
    }
    interface CustomMetricDefinitionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#instructions AwsBedrockEvaluationJob#instructions}
        */
        readonly instructions: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#name AwsBedrockEvaluationJob#name}
        */
        readonly name: string;
        /**
        * rating_scale block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#rating_scale AwsBedrockEvaluationJob#rating_scale}
        */
        readonly ratingScale?: RatingScaleProperty[] | cdktn.IResolvable;
    }
    class CustomMetricDefinitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomMetricDefinitionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CustomMetricDefinitionProperty | cdktn.IResolvable | undefined);
        private _instructions?;
        get instructions(): string;
        set instructions(value: string);
        get instructionsInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _ratingScale;
        get ratingScale(): RatingScalePropertyList;
        putRatingScale(value: RatingScaleProperty[] | cdktn.IResolvable): void;
        resetRatingScale(): void;
        get ratingScaleInput(): cdktn.IResolvable | RatingScaleProperty[] | undefined;
    }
    class CustomMetricDefinitionPropertyList extends cdktn.ComplexList {
        internalValue?: CustomMetricDefinitionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomMetricDefinitionPropertyOutputReference;
    }
    interface EvaluationConfigAutomatedCustomMetricConfigCustomMetricProperty {
        /**
        * custom_metric_definition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#custom_metric_definition AwsBedrockEvaluationJob#custom_metric_definition}
        */
        readonly customMetricDefinition?: CustomMetricDefinitionProperty[] | cdktn.IResolvable;
    }
    class EvaluationConfigAutomatedCustomMetricConfigCustomMetricPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EvaluationConfigAutomatedCustomMetricConfigCustomMetricProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EvaluationConfigAutomatedCustomMetricConfigCustomMetricProperty | cdktn.IResolvable | undefined);
        private _customMetricDefinition;
        get customMetricDefinition(): CustomMetricDefinitionPropertyList;
        putCustomMetricDefinition(value: CustomMetricDefinitionProperty[] | cdktn.IResolvable): void;
        resetCustomMetricDefinition(): void;
        get customMetricDefinitionInput(): cdktn.IResolvable | CustomMetricDefinitionProperty[] | undefined;
    }
    class EvaluationConfigAutomatedCustomMetricConfigCustomMetricPropertyList extends cdktn.ComplexList {
        internalValue?: EvaluationConfigAutomatedCustomMetricConfigCustomMetricProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EvaluationConfigAutomatedCustomMetricConfigCustomMetricPropertyOutputReference;
    }
    interface EvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigBedrockEvaluatorModelProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#model_identifier AwsBedrockEvaluationJob#model_identifier}
        */
        readonly modelIdentifier: string;
    }
    class EvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigBedrockEvaluatorModelPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigBedrockEvaluatorModelProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigBedrockEvaluatorModelProperty | cdktn.IResolvable | undefined);
        private _modelIdentifier?;
        get modelIdentifier(): string;
        set modelIdentifier(value: string);
        get modelIdentifierInput(): string | undefined;
    }
    class EvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigBedrockEvaluatorModelPropertyList extends cdktn.ComplexList {
        internalValue?: EvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigBedrockEvaluatorModelProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigBedrockEvaluatorModelPropertyOutputReference;
    }
    interface EvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigProperty {
        /**
        * bedrock_evaluator_model block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#bedrock_evaluator_model AwsBedrockEvaluationJob#bedrock_evaluator_model}
        */
        readonly bedrockEvaluatorModel?: EvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigBedrockEvaluatorModelProperty[] | cdktn.IResolvable;
    }
    class EvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigProperty | cdktn.IResolvable | undefined);
        private _bedrockEvaluatorModel;
        get bedrockEvaluatorModel(): EvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigBedrockEvaluatorModelPropertyList;
        putBedrockEvaluatorModel(value: EvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigBedrockEvaluatorModelProperty[] | cdktn.IResolvable): void;
        resetBedrockEvaluatorModel(): void;
        get bedrockEvaluatorModelInput(): cdktn.IResolvable | EvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigBedrockEvaluatorModelProperty[] | undefined;
    }
    class EvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigPropertyList extends cdktn.ComplexList {
        internalValue?: EvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigPropertyOutputReference;
    }
    interface CustomMetricConfigProperty {
        /**
        * custom_metric block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#custom_metric AwsBedrockEvaluationJob#custom_metric}
        */
        readonly customMetric?: EvaluationConfigAutomatedCustomMetricConfigCustomMetricProperty[] | cdktn.IResolvable;
        /**
        * evaluator_model_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#evaluator_model_config AwsBedrockEvaluationJob#evaluator_model_config}
        */
        readonly evaluatorModelConfig?: EvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigProperty[] | cdktn.IResolvable;
    }
    class CustomMetricConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomMetricConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CustomMetricConfigProperty | cdktn.IResolvable | undefined);
        private _customMetric;
        get customMetric(): EvaluationConfigAutomatedCustomMetricConfigCustomMetricPropertyList;
        putCustomMetric(value: EvaluationConfigAutomatedCustomMetricConfigCustomMetricProperty[] | cdktn.IResolvable): void;
        resetCustomMetric(): void;
        get customMetricInput(): cdktn.IResolvable | EvaluationConfigAutomatedCustomMetricConfigCustomMetricProperty[] | undefined;
        private _evaluatorModelConfig;
        get evaluatorModelConfig(): EvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigPropertyList;
        putEvaluatorModelConfig(value: EvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigProperty[] | cdktn.IResolvable): void;
        resetEvaluatorModelConfig(): void;
        get evaluatorModelConfigInput(): cdktn.IResolvable | EvaluationConfigAutomatedCustomMetricConfigEvaluatorModelConfigProperty[] | undefined;
    }
    class CustomMetricConfigPropertyList extends cdktn.ComplexList {
        internalValue?: CustomMetricConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomMetricConfigPropertyOutputReference;
    }
    interface EvaluationConfigAutomatedDatasetMetricConfigDatasetDatasetLocationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#s3_uri AwsBedrockEvaluationJob#s3_uri}
        */
        readonly s3Uri: string;
    }
    class EvaluationConfigAutomatedDatasetMetricConfigDatasetDatasetLocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EvaluationConfigAutomatedDatasetMetricConfigDatasetDatasetLocationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EvaluationConfigAutomatedDatasetMetricConfigDatasetDatasetLocationProperty | cdktn.IResolvable | undefined);
        private _s3Uri?;
        get s3Uri(): string;
        set s3Uri(value: string);
        get s3UriInput(): string | undefined;
    }
    class EvaluationConfigAutomatedDatasetMetricConfigDatasetDatasetLocationPropertyList extends cdktn.ComplexList {
        internalValue?: EvaluationConfigAutomatedDatasetMetricConfigDatasetDatasetLocationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EvaluationConfigAutomatedDatasetMetricConfigDatasetDatasetLocationPropertyOutputReference;
    }
    interface EvaluationConfigAutomatedDatasetMetricConfigDatasetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#name AwsBedrockEvaluationJob#name}
        */
        readonly name: string;
        /**
        * dataset_location block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#dataset_location AwsBedrockEvaluationJob#dataset_location}
        */
        readonly datasetLocation?: EvaluationConfigAutomatedDatasetMetricConfigDatasetDatasetLocationProperty[] | cdktn.IResolvable;
    }
    class EvaluationConfigAutomatedDatasetMetricConfigDatasetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EvaluationConfigAutomatedDatasetMetricConfigDatasetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EvaluationConfigAutomatedDatasetMetricConfigDatasetProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _datasetLocation;
        get datasetLocation(): EvaluationConfigAutomatedDatasetMetricConfigDatasetDatasetLocationPropertyList;
        putDatasetLocation(value: EvaluationConfigAutomatedDatasetMetricConfigDatasetDatasetLocationProperty[] | cdktn.IResolvable): void;
        resetDatasetLocation(): void;
        get datasetLocationInput(): cdktn.IResolvable | EvaluationConfigAutomatedDatasetMetricConfigDatasetDatasetLocationProperty[] | undefined;
    }
    class EvaluationConfigAutomatedDatasetMetricConfigDatasetPropertyList extends cdktn.ComplexList {
        internalValue?: EvaluationConfigAutomatedDatasetMetricConfigDatasetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EvaluationConfigAutomatedDatasetMetricConfigDatasetPropertyOutputReference;
    }
    interface EvaluationConfigAutomatedDatasetMetricConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#metric_names AwsBedrockEvaluationJob#metric_names}
        */
        readonly metricNames: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#task_type AwsBedrockEvaluationJob#task_type}
        */
        readonly taskType: string;
        /**
        * dataset block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#dataset AwsBedrockEvaluationJob#dataset}
        */
        readonly dataset?: EvaluationConfigAutomatedDatasetMetricConfigDatasetProperty[] | cdktn.IResolvable;
    }
    class EvaluationConfigAutomatedDatasetMetricConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EvaluationConfigAutomatedDatasetMetricConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EvaluationConfigAutomatedDatasetMetricConfigProperty | cdktn.IResolvable | undefined);
        private _metricNames?;
        get metricNames(): string[];
        set metricNames(value: string[]);
        get metricNamesInput(): string[] | undefined;
        private _taskType?;
        get taskType(): string;
        set taskType(value: string);
        get taskTypeInput(): string | undefined;
        private _dataset;
        get dataset(): EvaluationConfigAutomatedDatasetMetricConfigDatasetPropertyList;
        putDataset(value: EvaluationConfigAutomatedDatasetMetricConfigDatasetProperty[] | cdktn.IResolvable): void;
        resetDataset(): void;
        get datasetInput(): cdktn.IResolvable | EvaluationConfigAutomatedDatasetMetricConfigDatasetProperty[] | undefined;
    }
    class EvaluationConfigAutomatedDatasetMetricConfigPropertyList extends cdktn.ComplexList {
        internalValue?: EvaluationConfigAutomatedDatasetMetricConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EvaluationConfigAutomatedDatasetMetricConfigPropertyOutputReference;
    }
    interface EvaluationConfigAutomatedEvaluatorModelConfigBedrockEvaluatorModelProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#model_identifier AwsBedrockEvaluationJob#model_identifier}
        */
        readonly modelIdentifier: string;
    }
    class EvaluationConfigAutomatedEvaluatorModelConfigBedrockEvaluatorModelPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EvaluationConfigAutomatedEvaluatorModelConfigBedrockEvaluatorModelProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EvaluationConfigAutomatedEvaluatorModelConfigBedrockEvaluatorModelProperty | cdktn.IResolvable | undefined);
        private _modelIdentifier?;
        get modelIdentifier(): string;
        set modelIdentifier(value: string);
        get modelIdentifierInput(): string | undefined;
    }
    class EvaluationConfigAutomatedEvaluatorModelConfigBedrockEvaluatorModelPropertyList extends cdktn.ComplexList {
        internalValue?: EvaluationConfigAutomatedEvaluatorModelConfigBedrockEvaluatorModelProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EvaluationConfigAutomatedEvaluatorModelConfigBedrockEvaluatorModelPropertyOutputReference;
    }
    interface EvaluationConfigAutomatedEvaluatorModelConfigProperty {
        /**
        * bedrock_evaluator_model block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#bedrock_evaluator_model AwsBedrockEvaluationJob#bedrock_evaluator_model}
        */
        readonly bedrockEvaluatorModel?: EvaluationConfigAutomatedEvaluatorModelConfigBedrockEvaluatorModelProperty[] | cdktn.IResolvable;
    }
    class EvaluationConfigAutomatedEvaluatorModelConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EvaluationConfigAutomatedEvaluatorModelConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EvaluationConfigAutomatedEvaluatorModelConfigProperty | cdktn.IResolvable | undefined);
        private _bedrockEvaluatorModel;
        get bedrockEvaluatorModel(): EvaluationConfigAutomatedEvaluatorModelConfigBedrockEvaluatorModelPropertyList;
        putBedrockEvaluatorModel(value: EvaluationConfigAutomatedEvaluatorModelConfigBedrockEvaluatorModelProperty[] | cdktn.IResolvable): void;
        resetBedrockEvaluatorModel(): void;
        get bedrockEvaluatorModelInput(): cdktn.IResolvable | EvaluationConfigAutomatedEvaluatorModelConfigBedrockEvaluatorModelProperty[] | undefined;
    }
    class EvaluationConfigAutomatedEvaluatorModelConfigPropertyList extends cdktn.ComplexList {
        internalValue?: EvaluationConfigAutomatedEvaluatorModelConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EvaluationConfigAutomatedEvaluatorModelConfigPropertyOutputReference;
    }
    interface AutomatedProperty {
        /**
        * custom_metric_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#custom_metric_config AwsBedrockEvaluationJob#custom_metric_config}
        */
        readonly customMetricConfig?: CustomMetricConfigProperty[] | cdktn.IResolvable;
        /**
        * dataset_metric_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#dataset_metric_config AwsBedrockEvaluationJob#dataset_metric_config}
        */
        readonly datasetMetricConfig?: EvaluationConfigAutomatedDatasetMetricConfigProperty[] | cdktn.IResolvable;
        /**
        * evaluator_model_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#evaluator_model_config AwsBedrockEvaluationJob#evaluator_model_config}
        */
        readonly evaluatorModelConfig?: EvaluationConfigAutomatedEvaluatorModelConfigProperty[] | cdktn.IResolvable;
    }
    class AutomatedPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AutomatedProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AutomatedProperty | cdktn.IResolvable | undefined);
        private _customMetricConfig;
        get customMetricConfig(): CustomMetricConfigPropertyList;
        putCustomMetricConfig(value: CustomMetricConfigProperty[] | cdktn.IResolvable): void;
        resetCustomMetricConfig(): void;
        get customMetricConfigInput(): cdktn.IResolvable | CustomMetricConfigProperty[] | undefined;
        private _datasetMetricConfig;
        get datasetMetricConfig(): EvaluationConfigAutomatedDatasetMetricConfigPropertyList;
        putDatasetMetricConfig(value: EvaluationConfigAutomatedDatasetMetricConfigProperty[] | cdktn.IResolvable): void;
        resetDatasetMetricConfig(): void;
        get datasetMetricConfigInput(): cdktn.IResolvable | EvaluationConfigAutomatedDatasetMetricConfigProperty[] | undefined;
        private _evaluatorModelConfig;
        get evaluatorModelConfig(): EvaluationConfigAutomatedEvaluatorModelConfigPropertyList;
        putEvaluatorModelConfig(value: EvaluationConfigAutomatedEvaluatorModelConfigProperty[] | cdktn.IResolvable): void;
        resetEvaluatorModelConfig(): void;
        get evaluatorModelConfigInput(): cdktn.IResolvable | EvaluationConfigAutomatedEvaluatorModelConfigProperty[] | undefined;
    }
    class AutomatedPropertyList extends cdktn.ComplexList {
        internalValue?: AutomatedProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AutomatedPropertyOutputReference;
    }
    interface EvaluationConfigHumanCustomMetricProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#description AwsBedrockEvaluationJob#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#name AwsBedrockEvaluationJob#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#rating_method AwsBedrockEvaluationJob#rating_method}
        */
        readonly ratingMethod: string;
    }
    class EvaluationConfigHumanCustomMetricPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EvaluationConfigHumanCustomMetricProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EvaluationConfigHumanCustomMetricProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _ratingMethod?;
        get ratingMethod(): string;
        set ratingMethod(value: string);
        get ratingMethodInput(): string | undefined;
    }
    class EvaluationConfigHumanCustomMetricPropertyList extends cdktn.ComplexList {
        internalValue?: EvaluationConfigHumanCustomMetricProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EvaluationConfigHumanCustomMetricPropertyOutputReference;
    }
    interface EvaluationConfigHumanDatasetMetricConfigDatasetDatasetLocationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#s3_uri AwsBedrockEvaluationJob#s3_uri}
        */
        readonly s3Uri: string;
    }
    class EvaluationConfigHumanDatasetMetricConfigDatasetDatasetLocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EvaluationConfigHumanDatasetMetricConfigDatasetDatasetLocationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EvaluationConfigHumanDatasetMetricConfigDatasetDatasetLocationProperty | cdktn.IResolvable | undefined);
        private _s3Uri?;
        get s3Uri(): string;
        set s3Uri(value: string);
        get s3UriInput(): string | undefined;
    }
    class EvaluationConfigHumanDatasetMetricConfigDatasetDatasetLocationPropertyList extends cdktn.ComplexList {
        internalValue?: EvaluationConfigHumanDatasetMetricConfigDatasetDatasetLocationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EvaluationConfigHumanDatasetMetricConfigDatasetDatasetLocationPropertyOutputReference;
    }
    interface EvaluationConfigHumanDatasetMetricConfigDatasetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#name AwsBedrockEvaluationJob#name}
        */
        readonly name: string;
        /**
        * dataset_location block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#dataset_location AwsBedrockEvaluationJob#dataset_location}
        */
        readonly datasetLocation?: EvaluationConfigHumanDatasetMetricConfigDatasetDatasetLocationProperty[] | cdktn.IResolvable;
    }
    class EvaluationConfigHumanDatasetMetricConfigDatasetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EvaluationConfigHumanDatasetMetricConfigDatasetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EvaluationConfigHumanDatasetMetricConfigDatasetProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _datasetLocation;
        get datasetLocation(): EvaluationConfigHumanDatasetMetricConfigDatasetDatasetLocationPropertyList;
        putDatasetLocation(value: EvaluationConfigHumanDatasetMetricConfigDatasetDatasetLocationProperty[] | cdktn.IResolvable): void;
        resetDatasetLocation(): void;
        get datasetLocationInput(): cdktn.IResolvable | EvaluationConfigHumanDatasetMetricConfigDatasetDatasetLocationProperty[] | undefined;
    }
    class EvaluationConfigHumanDatasetMetricConfigDatasetPropertyList extends cdktn.ComplexList {
        internalValue?: EvaluationConfigHumanDatasetMetricConfigDatasetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EvaluationConfigHumanDatasetMetricConfigDatasetPropertyOutputReference;
    }
    interface EvaluationConfigHumanDatasetMetricConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#metric_names AwsBedrockEvaluationJob#metric_names}
        */
        readonly metricNames: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#task_type AwsBedrockEvaluationJob#task_type}
        */
        readonly taskType: string;
        /**
        * dataset block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#dataset AwsBedrockEvaluationJob#dataset}
        */
        readonly dataset?: EvaluationConfigHumanDatasetMetricConfigDatasetProperty[] | cdktn.IResolvable;
    }
    class EvaluationConfigHumanDatasetMetricConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EvaluationConfigHumanDatasetMetricConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EvaluationConfigHumanDatasetMetricConfigProperty | cdktn.IResolvable | undefined);
        private _metricNames?;
        get metricNames(): string[];
        set metricNames(value: string[]);
        get metricNamesInput(): string[] | undefined;
        private _taskType?;
        get taskType(): string;
        set taskType(value: string);
        get taskTypeInput(): string | undefined;
        private _dataset;
        get dataset(): EvaluationConfigHumanDatasetMetricConfigDatasetPropertyList;
        putDataset(value: EvaluationConfigHumanDatasetMetricConfigDatasetProperty[] | cdktn.IResolvable): void;
        resetDataset(): void;
        get datasetInput(): cdktn.IResolvable | EvaluationConfigHumanDatasetMetricConfigDatasetProperty[] | undefined;
    }
    class EvaluationConfigHumanDatasetMetricConfigPropertyList extends cdktn.ComplexList {
        internalValue?: EvaluationConfigHumanDatasetMetricConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EvaluationConfigHumanDatasetMetricConfigPropertyOutputReference;
    }
    interface HumanWorkflowConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#flow_definition_arn AwsBedrockEvaluationJob#flow_definition_arn}
        */
        readonly flowDefinitionArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#instructions AwsBedrockEvaluationJob#instructions}
        */
        readonly instructions?: string;
    }
    class HumanWorkflowConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HumanWorkflowConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HumanWorkflowConfigProperty | cdktn.IResolvable | undefined);
        private _flowDefinitionArn?;
        get flowDefinitionArn(): string;
        set flowDefinitionArn(value: string);
        get flowDefinitionArnInput(): string | undefined;
        private _instructions?;
        get instructions(): string;
        set instructions(value: string);
        resetInstructions(): void;
        get instructionsInput(): string | undefined;
    }
    class HumanWorkflowConfigPropertyList extends cdktn.ComplexList {
        internalValue?: HumanWorkflowConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HumanWorkflowConfigPropertyOutputReference;
    }
    interface HumanProperty {
        /**
        * custom_metric block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#custom_metric AwsBedrockEvaluationJob#custom_metric}
        */
        readonly customMetric?: EvaluationConfigHumanCustomMetricProperty[] | cdktn.IResolvable;
        /**
        * dataset_metric_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#dataset_metric_config AwsBedrockEvaluationJob#dataset_metric_config}
        */
        readonly datasetMetricConfig?: EvaluationConfigHumanDatasetMetricConfigProperty[] | cdktn.IResolvable;
        /**
        * human_workflow_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#human_workflow_config AwsBedrockEvaluationJob#human_workflow_config}
        */
        readonly humanWorkflowConfig?: HumanWorkflowConfigProperty[] | cdktn.IResolvable;
    }
    class HumanPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HumanProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HumanProperty | cdktn.IResolvable | undefined);
        private _customMetric;
        get customMetric(): EvaluationConfigHumanCustomMetricPropertyList;
        putCustomMetric(value: EvaluationConfigHumanCustomMetricProperty[] | cdktn.IResolvable): void;
        resetCustomMetric(): void;
        get customMetricInput(): cdktn.IResolvable | EvaluationConfigHumanCustomMetricProperty[] | undefined;
        private _datasetMetricConfig;
        get datasetMetricConfig(): EvaluationConfigHumanDatasetMetricConfigPropertyList;
        putDatasetMetricConfig(value: EvaluationConfigHumanDatasetMetricConfigProperty[] | cdktn.IResolvable): void;
        resetDatasetMetricConfig(): void;
        get datasetMetricConfigInput(): cdktn.IResolvable | EvaluationConfigHumanDatasetMetricConfigProperty[] | undefined;
        private _humanWorkflowConfig;
        get humanWorkflowConfig(): HumanWorkflowConfigPropertyList;
        putHumanWorkflowConfig(value: HumanWorkflowConfigProperty[] | cdktn.IResolvable): void;
        resetHumanWorkflowConfig(): void;
        get humanWorkflowConfigInput(): cdktn.IResolvable | HumanWorkflowConfigProperty[] | undefined;
    }
    class HumanPropertyList extends cdktn.ComplexList {
        internalValue?: HumanProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HumanPropertyOutputReference;
    }
    interface EvaluationConfigProperty {
        /**
        * automated block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#automated AwsBedrockEvaluationJob#automated}
        */
        readonly automated?: AutomatedProperty[] | cdktn.IResolvable;
        /**
        * human block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#human AwsBedrockEvaluationJob#human}
        */
        readonly human?: HumanProperty[] | cdktn.IResolvable;
    }
    class EvaluationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EvaluationConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EvaluationConfigProperty | cdktn.IResolvable | undefined);
        private _automated;
        get automated(): AutomatedPropertyList;
        putAutomated(value: AutomatedProperty[] | cdktn.IResolvable): void;
        resetAutomated(): void;
        get automatedInput(): cdktn.IResolvable | AutomatedProperty[] | undefined;
        private _human;
        get human(): HumanPropertyList;
        putHuman(value: HumanProperty[] | cdktn.IResolvable): void;
        resetHuman(): void;
        get humanInput(): cdktn.IResolvable | HumanProperty[] | undefined;
    }
    class EvaluationConfigPropertyList extends cdktn.ComplexList {
        internalValue?: EvaluationConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EvaluationConfigPropertyOutputReference;
    }
    interface PerformanceConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#latency AwsBedrockEvaluationJob#latency}
        */
        readonly latency?: string;
    }
    class PerformanceConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PerformanceConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PerformanceConfigProperty | cdktn.IResolvable | undefined);
        private _latency?;
        get latency(): string;
        set latency(value: string);
        resetLatency(): void;
        get latencyInput(): string | undefined;
    }
    class PerformanceConfigPropertyList extends cdktn.ComplexList {
        internalValue?: PerformanceConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PerformanceConfigPropertyOutputReference;
    }
    interface BedrockModelProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#inference_params AwsBedrockEvaluationJob#inference_params}
        */
        readonly inferenceParams?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#model_identifier AwsBedrockEvaluationJob#model_identifier}
        */
        readonly modelIdentifier: string;
        /**
        * performance_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#performance_config AwsBedrockEvaluationJob#performance_config}
        */
        readonly performanceConfig?: PerformanceConfigProperty[] | cdktn.IResolvable;
    }
    class BedrockModelPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BedrockModelProperty | cdktn.IResolvable | undefined;
        set internalValue(value: BedrockModelProperty | cdktn.IResolvable | undefined);
        private _inferenceParams?;
        get inferenceParams(): string;
        set inferenceParams(value: string);
        resetInferenceParams(): void;
        get inferenceParamsInput(): string | undefined;
        private _modelIdentifier?;
        get modelIdentifier(): string;
        set modelIdentifier(value: string);
        get modelIdentifierInput(): string | undefined;
        private _performanceConfig;
        get performanceConfig(): PerformanceConfigPropertyList;
        putPerformanceConfig(value: PerformanceConfigProperty[] | cdktn.IResolvable): void;
        resetPerformanceConfig(): void;
        get performanceConfigInput(): cdktn.IResolvable | PerformanceConfigProperty[] | undefined;
    }
    class BedrockModelPropertyList extends cdktn.ComplexList {
        internalValue?: BedrockModelProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BedrockModelPropertyOutputReference;
    }
    interface PrecomputedInferenceSourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#inference_source_identifier AwsBedrockEvaluationJob#inference_source_identifier}
        */
        readonly inferenceSourceIdentifier: string;
    }
    class PrecomputedInferenceSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PrecomputedInferenceSourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PrecomputedInferenceSourceProperty | cdktn.IResolvable | undefined);
        private _inferenceSourceIdentifier?;
        get inferenceSourceIdentifier(): string;
        set inferenceSourceIdentifier(value: string);
        get inferenceSourceIdentifierInput(): string | undefined;
    }
    class PrecomputedInferenceSourcePropertyList extends cdktn.ComplexList {
        internalValue?: PrecomputedInferenceSourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PrecomputedInferenceSourcePropertyOutputReference;
    }
    interface ModelProperty {
        /**
        * bedrock_model block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#bedrock_model AwsBedrockEvaluationJob#bedrock_model}
        */
        readonly bedrockModel?: BedrockModelProperty[] | cdktn.IResolvable;
        /**
        * precomputed_inference_source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#precomputed_inference_source AwsBedrockEvaluationJob#precomputed_inference_source}
        */
        readonly precomputedInferenceSource?: PrecomputedInferenceSourceProperty[] | cdktn.IResolvable;
    }
    class ModelPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ModelProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ModelProperty | cdktn.IResolvable | undefined);
        private _bedrockModel;
        get bedrockModel(): BedrockModelPropertyList;
        putBedrockModel(value: BedrockModelProperty[] | cdktn.IResolvable): void;
        resetBedrockModel(): void;
        get bedrockModelInput(): cdktn.IResolvable | BedrockModelProperty[] | undefined;
        private _precomputedInferenceSource;
        get precomputedInferenceSource(): PrecomputedInferenceSourcePropertyList;
        putPrecomputedInferenceSource(value: PrecomputedInferenceSourceProperty[] | cdktn.IResolvable): void;
        resetPrecomputedInferenceSource(): void;
        get precomputedInferenceSourceInput(): cdktn.IResolvable | PrecomputedInferenceSourceProperty[] | undefined;
    }
    class ModelPropertyList extends cdktn.ComplexList {
        internalValue?: ModelProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ModelPropertyOutputReference;
    }
    interface InferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfigurationVectorSearchConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#number_of_results AwsBedrockEvaluationJob#number_of_results}
        */
        readonly numberOfResults?: number;
    }
    class InferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfigurationVectorSearchConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfigurationVectorSearchConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfigurationVectorSearchConfigurationProperty | cdktn.IResolvable | undefined);
        private _numberOfResults?;
        get numberOfResults(): number;
        set numberOfResults(value: number);
        resetNumberOfResults(): void;
        get numberOfResultsInput(): number | undefined;
    }
    class InferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfigurationVectorSearchConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: InferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfigurationVectorSearchConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfigurationVectorSearchConfigurationPropertyOutputReference;
    }
    interface RetrievalConfigurationProperty {
        /**
        * vector_search_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#vector_search_configuration AwsBedrockEvaluationJob#vector_search_configuration}
        */
        readonly vectorSearchConfiguration?: InferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfigurationVectorSearchConfigurationProperty[] | cdktn.IResolvable;
    }
    class RetrievalConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RetrievalConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RetrievalConfigurationProperty | cdktn.IResolvable | undefined);
        private _vectorSearchConfiguration;
        get vectorSearchConfiguration(): InferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfigurationVectorSearchConfigurationPropertyList;
        putVectorSearchConfiguration(value: InferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfigurationVectorSearchConfigurationProperty[] | cdktn.IResolvable): void;
        resetVectorSearchConfiguration(): void;
        get vectorSearchConfigurationInput(): cdktn.IResolvable | InferenceConfigRagConfigKnowledgeBaseConfigRetrieveAndGenerateConfigRetrievalConfigurationVectorSearchConfigurationProperty[] | undefined;
    }
    class RetrievalConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: RetrievalConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RetrievalConfigurationPropertyOutputReference;
    }
    interface RetrieveAndGenerateConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#knowledge_base_id AwsBedrockEvaluationJob#knowledge_base_id}
        */
        readonly knowledgeBaseId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#model_arn AwsBedrockEvaluationJob#model_arn}
        */
        readonly modelArn: string;
        /**
        * retrieval_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#retrieval_configuration AwsBedrockEvaluationJob#retrieval_configuration}
        */
        readonly retrievalConfiguration?: RetrievalConfigurationProperty[] | cdktn.IResolvable;
    }
    class RetrieveAndGenerateConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RetrieveAndGenerateConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RetrieveAndGenerateConfigProperty | cdktn.IResolvable | undefined);
        private _knowledgeBaseId?;
        get knowledgeBaseId(): string;
        set knowledgeBaseId(value: string);
        get knowledgeBaseIdInput(): string | undefined;
        private _modelArn?;
        get modelArn(): string;
        set modelArn(value: string);
        get modelArnInput(): string | undefined;
        private _retrievalConfiguration;
        get retrievalConfiguration(): RetrievalConfigurationPropertyList;
        putRetrievalConfiguration(value: RetrievalConfigurationProperty[] | cdktn.IResolvable): void;
        resetRetrievalConfiguration(): void;
        get retrievalConfigurationInput(): cdktn.IResolvable | RetrievalConfigurationProperty[] | undefined;
    }
    class RetrieveAndGenerateConfigPropertyList extends cdktn.ComplexList {
        internalValue?: RetrieveAndGenerateConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RetrieveAndGenerateConfigPropertyOutputReference;
    }
    interface InferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfigurationVectorSearchConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#number_of_results AwsBedrockEvaluationJob#number_of_results}
        */
        readonly numberOfResults?: number;
    }
    class InferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfigurationVectorSearchConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfigurationVectorSearchConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfigurationVectorSearchConfigurationProperty | cdktn.IResolvable | undefined);
        private _numberOfResults?;
        get numberOfResults(): number;
        set numberOfResults(value: number);
        resetNumberOfResults(): void;
        get numberOfResultsInput(): number | undefined;
    }
    class InferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfigurationVectorSearchConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: InferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfigurationVectorSearchConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfigurationVectorSearchConfigurationPropertyOutputReference;
    }
    interface KnowledgeBaseRetrievalConfigurationProperty {
        /**
        * vector_search_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#vector_search_configuration AwsBedrockEvaluationJob#vector_search_configuration}
        */
        readonly vectorSearchConfiguration?: InferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfigurationVectorSearchConfigurationProperty[] | cdktn.IResolvable;
    }
    class KnowledgeBaseRetrievalConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KnowledgeBaseRetrievalConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KnowledgeBaseRetrievalConfigurationProperty | cdktn.IResolvable | undefined);
        private _vectorSearchConfiguration;
        get vectorSearchConfiguration(): InferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfigurationVectorSearchConfigurationPropertyList;
        putVectorSearchConfiguration(value: InferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfigurationVectorSearchConfigurationProperty[] | cdktn.IResolvable): void;
        resetVectorSearchConfiguration(): void;
        get vectorSearchConfigurationInput(): cdktn.IResolvable | InferenceConfigRagConfigKnowledgeBaseConfigRetrieveConfigKnowledgeBaseRetrievalConfigurationVectorSearchConfigurationProperty[] | undefined;
    }
    class KnowledgeBaseRetrievalConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: KnowledgeBaseRetrievalConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KnowledgeBaseRetrievalConfigurationPropertyOutputReference;
    }
    interface RetrieveConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#knowledge_base_id AwsBedrockEvaluationJob#knowledge_base_id}
        */
        readonly knowledgeBaseId: string;
        /**
        * knowledge_base_retrieval_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#knowledge_base_retrieval_configuration AwsBedrockEvaluationJob#knowledge_base_retrieval_configuration}
        */
        readonly knowledgeBaseRetrievalConfiguration?: KnowledgeBaseRetrievalConfigurationProperty[] | cdktn.IResolvable;
    }
    class RetrieveConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RetrieveConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RetrieveConfigProperty | cdktn.IResolvable | undefined);
        private _knowledgeBaseId?;
        get knowledgeBaseId(): string;
        set knowledgeBaseId(value: string);
        get knowledgeBaseIdInput(): string | undefined;
        private _knowledgeBaseRetrievalConfiguration;
        get knowledgeBaseRetrievalConfiguration(): KnowledgeBaseRetrievalConfigurationPropertyList;
        putKnowledgeBaseRetrievalConfiguration(value: KnowledgeBaseRetrievalConfigurationProperty[] | cdktn.IResolvable): void;
        resetKnowledgeBaseRetrievalConfiguration(): void;
        get knowledgeBaseRetrievalConfigurationInput(): cdktn.IResolvable | KnowledgeBaseRetrievalConfigurationProperty[] | undefined;
    }
    class RetrieveConfigPropertyList extends cdktn.ComplexList {
        internalValue?: RetrieveConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RetrieveConfigPropertyOutputReference;
    }
    interface KnowledgeBaseConfigProperty {
        /**
        * retrieve_and_generate_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#retrieve_and_generate_config AwsBedrockEvaluationJob#retrieve_and_generate_config}
        */
        readonly retrieveAndGenerateConfig?: RetrieveAndGenerateConfigProperty[] | cdktn.IResolvable;
        /**
        * retrieve_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#retrieve_config AwsBedrockEvaluationJob#retrieve_config}
        */
        readonly retrieveConfig?: RetrieveConfigProperty[] | cdktn.IResolvable;
    }
    class KnowledgeBaseConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KnowledgeBaseConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KnowledgeBaseConfigProperty | cdktn.IResolvable | undefined);
        private _retrieveAndGenerateConfig;
        get retrieveAndGenerateConfig(): RetrieveAndGenerateConfigPropertyList;
        putRetrieveAndGenerateConfig(value: RetrieveAndGenerateConfigProperty[] | cdktn.IResolvable): void;
        resetRetrieveAndGenerateConfig(): void;
        get retrieveAndGenerateConfigInput(): cdktn.IResolvable | RetrieveAndGenerateConfigProperty[] | undefined;
        private _retrieveConfig;
        get retrieveConfig(): RetrieveConfigPropertyList;
        putRetrieveConfig(value: RetrieveConfigProperty[] | cdktn.IResolvable): void;
        resetRetrieveConfig(): void;
        get retrieveConfigInput(): cdktn.IResolvable | RetrieveConfigProperty[] | undefined;
    }
    class KnowledgeBaseConfigPropertyList extends cdktn.ComplexList {
        internalValue?: KnowledgeBaseConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KnowledgeBaseConfigPropertyOutputReference;
    }
    interface RetrieveAndGenerateSourceConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#rag_source_identifier AwsBedrockEvaluationJob#rag_source_identifier}
        */
        readonly ragSourceIdentifier: string;
    }
    class RetrieveAndGenerateSourceConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RetrieveAndGenerateSourceConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RetrieveAndGenerateSourceConfigProperty | cdktn.IResolvable | undefined);
        private _ragSourceIdentifier?;
        get ragSourceIdentifier(): string;
        set ragSourceIdentifier(value: string);
        get ragSourceIdentifierInput(): string | undefined;
    }
    class RetrieveAndGenerateSourceConfigPropertyList extends cdktn.ComplexList {
        internalValue?: RetrieveAndGenerateSourceConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RetrieveAndGenerateSourceConfigPropertyOutputReference;
    }
    interface RetrieveSourceConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#rag_source_identifier AwsBedrockEvaluationJob#rag_source_identifier}
        */
        readonly ragSourceIdentifier: string;
    }
    class RetrieveSourceConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RetrieveSourceConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RetrieveSourceConfigProperty | cdktn.IResolvable | undefined);
        private _ragSourceIdentifier?;
        get ragSourceIdentifier(): string;
        set ragSourceIdentifier(value: string);
        get ragSourceIdentifierInput(): string | undefined;
    }
    class RetrieveSourceConfigPropertyList extends cdktn.ComplexList {
        internalValue?: RetrieveSourceConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RetrieveSourceConfigPropertyOutputReference;
    }
    interface PrecomputedRagSourceConfigProperty {
        /**
        * retrieve_and_generate_source_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#retrieve_and_generate_source_config AwsBedrockEvaluationJob#retrieve_and_generate_source_config}
        */
        readonly retrieveAndGenerateSourceConfig?: RetrieveAndGenerateSourceConfigProperty[] | cdktn.IResolvable;
        /**
        * retrieve_source_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#retrieve_source_config AwsBedrockEvaluationJob#retrieve_source_config}
        */
        readonly retrieveSourceConfig?: RetrieveSourceConfigProperty[] | cdktn.IResolvable;
    }
    class PrecomputedRagSourceConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PrecomputedRagSourceConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PrecomputedRagSourceConfigProperty | cdktn.IResolvable | undefined);
        private _retrieveAndGenerateSourceConfig;
        get retrieveAndGenerateSourceConfig(): RetrieveAndGenerateSourceConfigPropertyList;
        putRetrieveAndGenerateSourceConfig(value: RetrieveAndGenerateSourceConfigProperty[] | cdktn.IResolvable): void;
        resetRetrieveAndGenerateSourceConfig(): void;
        get retrieveAndGenerateSourceConfigInput(): cdktn.IResolvable | RetrieveAndGenerateSourceConfigProperty[] | undefined;
        private _retrieveSourceConfig;
        get retrieveSourceConfig(): RetrieveSourceConfigPropertyList;
        putRetrieveSourceConfig(value: RetrieveSourceConfigProperty[] | cdktn.IResolvable): void;
        resetRetrieveSourceConfig(): void;
        get retrieveSourceConfigInput(): cdktn.IResolvable | RetrieveSourceConfigProperty[] | undefined;
    }
    class PrecomputedRagSourceConfigPropertyList extends cdktn.ComplexList {
        internalValue?: PrecomputedRagSourceConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PrecomputedRagSourceConfigPropertyOutputReference;
    }
    interface RagConfigProperty {
        /**
        * knowledge_base_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#knowledge_base_config AwsBedrockEvaluationJob#knowledge_base_config}
        */
        readonly knowledgeBaseConfig?: KnowledgeBaseConfigProperty[] | cdktn.IResolvable;
        /**
        * precomputed_rag_source_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#precomputed_rag_source_config AwsBedrockEvaluationJob#precomputed_rag_source_config}
        */
        readonly precomputedRagSourceConfig?: PrecomputedRagSourceConfigProperty[] | cdktn.IResolvable;
    }
    class RagConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RagConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RagConfigProperty | cdktn.IResolvable | undefined);
        private _knowledgeBaseConfig;
        get knowledgeBaseConfig(): KnowledgeBaseConfigPropertyList;
        putKnowledgeBaseConfig(value: KnowledgeBaseConfigProperty[] | cdktn.IResolvable): void;
        resetKnowledgeBaseConfig(): void;
        get knowledgeBaseConfigInput(): cdktn.IResolvable | KnowledgeBaseConfigProperty[] | undefined;
        private _precomputedRagSourceConfig;
        get precomputedRagSourceConfig(): PrecomputedRagSourceConfigPropertyList;
        putPrecomputedRagSourceConfig(value: PrecomputedRagSourceConfigProperty[] | cdktn.IResolvable): void;
        resetPrecomputedRagSourceConfig(): void;
        get precomputedRagSourceConfigInput(): cdktn.IResolvable | PrecomputedRagSourceConfigProperty[] | undefined;
    }
    class RagConfigPropertyList extends cdktn.ComplexList {
        internalValue?: RagConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RagConfigPropertyOutputReference;
    }
    interface InferenceConfigProperty {
        /**
        * model block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#model AwsBedrockEvaluationJob#model}
        */
        readonly model?: ModelProperty[] | cdktn.IResolvable;
        /**
        * rag_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#rag_config AwsBedrockEvaluationJob#rag_config}
        */
        readonly ragConfig?: RagConfigProperty[] | cdktn.IResolvable;
    }
    class InferenceConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InferenceConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InferenceConfigProperty | cdktn.IResolvable | undefined);
        private _model;
        get model(): ModelPropertyList;
        putModel(value: ModelProperty[] | cdktn.IResolvable): void;
        resetModel(): void;
        get modelInput(): cdktn.IResolvable | ModelProperty[] | undefined;
        private _ragConfig;
        get ragConfig(): RagConfigPropertyList;
        putRagConfig(value: RagConfigProperty[] | cdktn.IResolvable): void;
        resetRagConfig(): void;
        get ragConfigInput(): cdktn.IResolvable | RagConfigProperty[] | undefined;
    }
    class InferenceConfigPropertyList extends cdktn.ComplexList {
        internalValue?: InferenceConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InferenceConfigPropertyOutputReference;
    }
    interface OutputDataConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#s3_uri AwsBedrockEvaluationJob#s3_uri}
        */
        readonly s3Uri: string;
    }
    class OutputDataConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OutputDataConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OutputDataConfigProperty | cdktn.IResolvable | undefined);
        private _s3Uri?;
        get s3Uri(): string;
        set s3Uri(value: string);
        get s3UriInput(): string | undefined;
    }
    class OutputDataConfigPropertyList extends cdktn.ComplexList {
        internalValue?: OutputDataConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OutputDataConfigPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#create AwsBedrockEvaluationJob#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_evaluation_job#delete AwsBedrockEvaluationJob#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
