import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsRoute53RecoverycontrolconfigSafetyRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoverycontrolconfig_safety_rule#asserted_controls AwsRoute53RecoverycontrolconfigSafetyRule#asserted_controls}
    */
    readonly assertedControls?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoverycontrolconfig_safety_rule#control_panel_arn AwsRoute53RecoverycontrolconfigSafetyRule#control_panel_arn}
    */
    readonly controlPanelArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoverycontrolconfig_safety_rule#gating_controls AwsRoute53RecoverycontrolconfigSafetyRule#gating_controls}
    */
    readonly gatingControls?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoverycontrolconfig_safety_rule#id AwsRoute53RecoverycontrolconfigSafetyRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoverycontrolconfig_safety_rule#name AwsRoute53RecoverycontrolconfigSafetyRule#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoverycontrolconfig_safety_rule#tags AwsRoute53RecoverycontrolconfigSafetyRule#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoverycontrolconfig_safety_rule#tags_all AwsRoute53RecoverycontrolconfigSafetyRule#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoverycontrolconfig_safety_rule#target_controls AwsRoute53RecoverycontrolconfigSafetyRule#target_controls}
    */
    readonly targetControls?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoverycontrolconfig_safety_rule#wait_period_ms AwsRoute53RecoverycontrolconfigSafetyRule#wait_period_ms}
    */
    readonly waitPeriodMs: number;
    /**
    * rule_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoverycontrolconfig_safety_rule#rule_config AwsRoute53RecoverycontrolconfigSafetyRule#rule_config}
    */
    readonly ruleConfig: AwsRoute53RecoverycontrolconfigSafetyRule.RuleConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoverycontrolconfig_safety_rule aws_route53recoverycontrolconfig_safety_rule}
*/
export declare class AwsRoute53RecoverycontrolconfigSafetyRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_route53recoverycontrolconfig_safety_rule";
    /**
    * Generates CDKTN code for importing a AwsRoute53RecoverycontrolconfigSafetyRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsRoute53RecoverycontrolconfigSafetyRule to import
    * @param importFromId The id of the existing AwsRoute53RecoverycontrolconfigSafetyRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoverycontrolconfig_safety_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsRoute53RecoverycontrolconfigSafetyRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoverycontrolconfig_safety_rule aws_route53recoverycontrolconfig_safety_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsRoute53RecoverycontrolconfigSafetyRuleConfig
    */
    constructor(scope: Construct, id: string, config: AwsRoute53RecoverycontrolconfigSafetyRuleConfig);
    get arn(): string;
    private _assertedControls?;
    get assertedControls(): string[];
    set assertedControls(value: string[]);
    resetAssertedControls(): void;
    get assertedControlsInput(): string[] | undefined;
    private _controlPanelArn?;
    get controlPanelArn(): string;
    set controlPanelArn(value: string);
    get controlPanelArnInput(): string | undefined;
    private _gatingControls?;
    get gatingControls(): string[];
    set gatingControls(value: string[]);
    resetGatingControls(): void;
    get gatingControlsInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _targetControls?;
    get targetControls(): string[];
    set targetControls(value: string[]);
    resetTargetControls(): void;
    get targetControlsInput(): string[] | undefined;
    private _waitPeriodMs?;
    get waitPeriodMs(): number;
    set waitPeriodMs(value: number);
    get waitPeriodMsInput(): number | undefined;
    private _ruleConfig;
    get ruleConfig(): AwsRoute53RecoverycontrolconfigSafetyRule.RuleConfigPropertyOutputReference;
    putRuleConfig(value: AwsRoute53RecoverycontrolconfigSafetyRule.RuleConfigProperty): void;
    get ruleConfigInput(): AwsRoute53RecoverycontrolconfigSafetyRule.RuleConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsRoute53RecoverycontrolconfigSafetyRuleRuleConfigPropertyToTerraform(struct?: AwsRoute53RecoverycontrolconfigSafetyRule.RuleConfigPropertyOutputReference | AwsRoute53RecoverycontrolconfigSafetyRule.RuleConfigProperty): any;
export declare function awsRoute53RecoverycontrolconfigSafetyRuleRuleConfigPropertyToHclTerraform(struct?: AwsRoute53RecoverycontrolconfigSafetyRule.RuleConfigPropertyOutputReference | AwsRoute53RecoverycontrolconfigSafetyRule.RuleConfigProperty): any;
export declare namespace AwsRoute53RecoverycontrolconfigSafetyRule {
    interface RuleConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoverycontrolconfig_safety_rule#inverted AwsRoute53RecoverycontrolconfigSafetyRule#inverted}
        */
        readonly inverted: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoverycontrolconfig_safety_rule#threshold AwsRoute53RecoverycontrolconfigSafetyRule#threshold}
        */
        readonly threshold: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoverycontrolconfig_safety_rule#type AwsRoute53RecoverycontrolconfigSafetyRule#type}
        */
        readonly type: string;
    }
    class RuleConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleConfigProperty | undefined;
        set internalValue(value: RuleConfigProperty | undefined);
        private _inverted?;
        get inverted(): boolean | cdktn.IResolvable;
        set inverted(value: boolean | cdktn.IResolvable);
        get invertedInput(): boolean | cdktn.IResolvable | undefined;
        private _threshold?;
        get threshold(): number;
        set threshold(value: number);
        get thresholdInput(): number | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
}
