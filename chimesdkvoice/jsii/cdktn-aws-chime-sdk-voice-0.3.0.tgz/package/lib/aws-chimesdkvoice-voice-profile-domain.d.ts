import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsVoiceProfileDomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_voice_profile_domain#description AwsVoiceProfileDomain#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_voice_profile_domain#name AwsVoiceProfileDomain#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_voice_profile_domain#region AwsVoiceProfileDomain#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_voice_profile_domain#tags AwsVoiceProfileDomain#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_voice_profile_domain#tags_all AwsVoiceProfileDomain#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * server_side_encryption_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_voice_profile_domain#server_side_encryption_configuration AwsVoiceProfileDomain#server_side_encryption_configuration}
    */
    readonly serverSideEncryptionConfiguration: AwsVoiceProfileDomain.ServerSideEncryptionConfigurationProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_voice_profile_domain#timeouts AwsVoiceProfileDomain#timeouts}
    */
    readonly timeouts?: AwsVoiceProfileDomain.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_voice_profile_domain aws_chimesdkvoice_voice_profile_domain}
*/
export declare class AwsVoiceProfileDomain extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_chimesdkvoice_voice_profile_domain";
    /**
    * Generates CDKTN code for importing a AwsVoiceProfileDomain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsVoiceProfileDomain to import
    * @param importFromId The id of the existing AwsVoiceProfileDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_voice_profile_domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsVoiceProfileDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_voice_profile_domain aws_chimesdkvoice_voice_profile_domain} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsVoiceProfileDomainConfig
    */
    constructor(scope: Construct, id: string, config: AwsVoiceProfileDomainConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _serverSideEncryptionConfiguration;
    get serverSideEncryptionConfiguration(): AwsVoiceProfileDomain.ServerSideEncryptionConfigurationPropertyOutputReference;
    putServerSideEncryptionConfiguration(value: AwsVoiceProfileDomain.ServerSideEncryptionConfigurationProperty): void;
    get serverSideEncryptionConfigurationInput(): AwsVoiceProfileDomain.ServerSideEncryptionConfigurationProperty | undefined;
    private _timeouts;
    get timeouts(): AwsVoiceProfileDomain.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsVoiceProfileDomain.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsVoiceProfileDomain.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsVoiceProfileDomainServerSideEncryptionConfigurationPropertyToTerraform(struct?: AwsVoiceProfileDomain.ServerSideEncryptionConfigurationPropertyOutputReference | AwsVoiceProfileDomain.ServerSideEncryptionConfigurationProperty): any;
export declare function awsVoiceProfileDomainServerSideEncryptionConfigurationPropertyToHclTerraform(struct?: AwsVoiceProfileDomain.ServerSideEncryptionConfigurationPropertyOutputReference | AwsVoiceProfileDomain.ServerSideEncryptionConfigurationProperty): any;
export declare function awsVoiceProfileDomainTimeoutsPropertyToTerraform(struct?: AwsVoiceProfileDomain.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsVoiceProfileDomainTimeoutsPropertyToHclTerraform(struct?: AwsVoiceProfileDomain.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsVoiceProfileDomain {
    interface ServerSideEncryptionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_voice_profile_domain#kms_key_arn AwsVoiceProfileDomain#kms_key_arn}
        */
        readonly kmsKeyArn: string;
    }
    class ServerSideEncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ServerSideEncryptionConfigurationProperty | undefined;
        set internalValue(value: ServerSideEncryptionConfigurationProperty | undefined);
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        get kmsKeyArnInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_voice_profile_domain#create AwsVoiceProfileDomain#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_voice_profile_domain#delete AwsVoiceProfileDomain#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_voice_profile_domain#update AwsVoiceProfileDomain#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
