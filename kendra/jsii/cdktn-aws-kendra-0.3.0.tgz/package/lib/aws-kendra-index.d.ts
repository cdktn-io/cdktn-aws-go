import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsIndexConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#description AwsIndex#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#edition AwsIndex#edition}
    */
    readonly edition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#id AwsIndex#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#name AwsIndex#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#region AwsIndex#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#role_arn AwsIndex#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#tags AwsIndex#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#tags_all AwsIndex#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#user_context_policy AwsIndex#user_context_policy}
    */
    readonly userContextPolicy?: string;
    /**
    * capacity_units block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#capacity_units AwsIndex#capacity_units}
    */
    readonly capacityUnits?: AwsIndex.CapacityUnitsProperty;
    /**
    * document_metadata_configuration_updates block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#document_metadata_configuration_updates AwsIndex#document_metadata_configuration_updates}
    */
    readonly documentMetadataConfigurationUpdates?: AwsIndex.DocumentMetadataConfigurationUpdatesProperty[] | cdktn.IResolvable;
    /**
    * server_side_encryption_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#server_side_encryption_configuration AwsIndex#server_side_encryption_configuration}
    */
    readonly serverSideEncryptionConfiguration?: AwsIndex.ServerSideEncryptionConfigurationProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#timeouts AwsIndex#timeouts}
    */
    readonly timeouts?: AwsIndex.TimeoutsProperty;
    /**
    * user_group_resolution_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#user_group_resolution_configuration AwsIndex#user_group_resolution_configuration}
    */
    readonly userGroupResolutionConfiguration?: AwsIndex.UserGroupResolutionConfigurationProperty;
    /**
    * user_token_configurations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#user_token_configurations AwsIndex#user_token_configurations}
    */
    readonly userTokenConfigurations?: AwsIndex.UserTokenConfigurationsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index aws_kendra_index}
*/
export declare class AwsIndex extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_kendra_index";
    /**
    * Generates CDKTN code for importing a AwsIndex resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsIndex to import
    * @param importFromId The id of the existing AwsIndex that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsIndex to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index aws_kendra_index} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsIndexConfig
    */
    constructor(scope: Construct, id: string, config: AwsIndexConfig);
    get arn(): string;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _edition?;
    get edition(): string;
    set edition(value: string);
    resetEdition(): void;
    get editionInput(): string | undefined;
    get errorMessage(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _indexStatistics;
    get indexStatistics(): AwsIndex.IndexStatisticsPropertyList;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get updatedAt(): string;
    private _userContextPolicy?;
    get userContextPolicy(): string;
    set userContextPolicy(value: string);
    resetUserContextPolicy(): void;
    get userContextPolicyInput(): string | undefined;
    private _capacityUnits;
    get capacityUnits(): AwsIndex.CapacityUnitsPropertyOutputReference;
    putCapacityUnits(value: AwsIndex.CapacityUnitsProperty): void;
    resetCapacityUnits(): void;
    get capacityUnitsInput(): AwsIndex.CapacityUnitsProperty | undefined;
    private _documentMetadataConfigurationUpdates;
    get documentMetadataConfigurationUpdates(): AwsIndex.DocumentMetadataConfigurationUpdatesPropertyList;
    putDocumentMetadataConfigurationUpdates(value: AwsIndex.DocumentMetadataConfigurationUpdatesProperty[] | cdktn.IResolvable): void;
    resetDocumentMetadataConfigurationUpdates(): void;
    get documentMetadataConfigurationUpdatesInput(): cdktn.IResolvable | AwsIndex.DocumentMetadataConfigurationUpdatesProperty[] | undefined;
    private _serverSideEncryptionConfiguration;
    get serverSideEncryptionConfiguration(): AwsIndex.ServerSideEncryptionConfigurationPropertyOutputReference;
    putServerSideEncryptionConfiguration(value: AwsIndex.ServerSideEncryptionConfigurationProperty): void;
    resetServerSideEncryptionConfiguration(): void;
    get serverSideEncryptionConfigurationInput(): AwsIndex.ServerSideEncryptionConfigurationProperty | undefined;
    private _timeouts;
    get timeouts(): AwsIndex.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsIndex.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsIndex.TimeoutsProperty | undefined;
    private _userGroupResolutionConfiguration;
    get userGroupResolutionConfiguration(): AwsIndex.UserGroupResolutionConfigurationPropertyOutputReference;
    putUserGroupResolutionConfiguration(value: AwsIndex.UserGroupResolutionConfigurationProperty): void;
    resetUserGroupResolutionConfiguration(): void;
    get userGroupResolutionConfigurationInput(): AwsIndex.UserGroupResolutionConfigurationProperty | undefined;
    private _userTokenConfigurations;
    get userTokenConfigurations(): AwsIndex.UserTokenConfigurationsPropertyOutputReference;
    putUserTokenConfigurations(value: AwsIndex.UserTokenConfigurationsProperty): void;
    resetUserTokenConfigurations(): void;
    get userTokenConfigurationsInput(): AwsIndex.UserTokenConfigurationsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsIndexFaqStatisticsPropertyToTerraform(struct?: AwsIndex.FaqStatisticsProperty): any;
export declare function awsIndexFaqStatisticsPropertyToHclTerraform(struct?: AwsIndex.FaqStatisticsProperty): any;
export declare function awsIndexTextDocumentStatisticsPropertyToTerraform(struct?: AwsIndex.TextDocumentStatisticsProperty): any;
export declare function awsIndexTextDocumentStatisticsPropertyToHclTerraform(struct?: AwsIndex.TextDocumentStatisticsProperty): any;
export declare function awsIndexIndexStatisticsPropertyToTerraform(struct?: AwsIndex.IndexStatisticsProperty): any;
export declare function awsIndexIndexStatisticsPropertyToHclTerraform(struct?: AwsIndex.IndexStatisticsProperty): any;
export declare function awsIndexCapacityUnitsPropertyToTerraform(struct?: AwsIndex.CapacityUnitsPropertyOutputReference | AwsIndex.CapacityUnitsProperty): any;
export declare function awsIndexCapacityUnitsPropertyToHclTerraform(struct?: AwsIndex.CapacityUnitsPropertyOutputReference | AwsIndex.CapacityUnitsProperty): any;
export declare function awsIndexRelevancePropertyToTerraform(struct?: AwsIndex.RelevancePropertyOutputReference | AwsIndex.RelevanceProperty): any;
export declare function awsIndexRelevancePropertyToHclTerraform(struct?: AwsIndex.RelevancePropertyOutputReference | AwsIndex.RelevanceProperty): any;
export declare function awsIndexSearchPropertyToTerraform(struct?: AwsIndex.SearchPropertyOutputReference | AwsIndex.SearchProperty): any;
export declare function awsIndexSearchPropertyToHclTerraform(struct?: AwsIndex.SearchPropertyOutputReference | AwsIndex.SearchProperty): any;
export declare function awsIndexDocumentMetadataConfigurationUpdatesPropertyToTerraform(struct?: AwsIndex.DocumentMetadataConfigurationUpdatesProperty | cdktn.IResolvable): any;
export declare function awsIndexDocumentMetadataConfigurationUpdatesPropertyToHclTerraform(struct?: AwsIndex.DocumentMetadataConfigurationUpdatesProperty | cdktn.IResolvable): any;
export declare function awsIndexServerSideEncryptionConfigurationPropertyToTerraform(struct?: AwsIndex.ServerSideEncryptionConfigurationPropertyOutputReference | AwsIndex.ServerSideEncryptionConfigurationProperty): any;
export declare function awsIndexServerSideEncryptionConfigurationPropertyToHclTerraform(struct?: AwsIndex.ServerSideEncryptionConfigurationPropertyOutputReference | AwsIndex.ServerSideEncryptionConfigurationProperty): any;
export declare function awsIndexTimeoutsPropertyToTerraform(struct?: AwsIndex.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsIndexTimeoutsPropertyToHclTerraform(struct?: AwsIndex.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsIndexUserGroupResolutionConfigurationPropertyToTerraform(struct?: AwsIndex.UserGroupResolutionConfigurationPropertyOutputReference | AwsIndex.UserGroupResolutionConfigurationProperty): any;
export declare function awsIndexUserGroupResolutionConfigurationPropertyToHclTerraform(struct?: AwsIndex.UserGroupResolutionConfigurationPropertyOutputReference | AwsIndex.UserGroupResolutionConfigurationProperty): any;
export declare function awsIndexJsonTokenTypeConfigurationPropertyToTerraform(struct?: AwsIndex.JsonTokenTypeConfigurationPropertyOutputReference | AwsIndex.JsonTokenTypeConfigurationProperty): any;
export declare function awsIndexJsonTokenTypeConfigurationPropertyToHclTerraform(struct?: AwsIndex.JsonTokenTypeConfigurationPropertyOutputReference | AwsIndex.JsonTokenTypeConfigurationProperty): any;
export declare function awsIndexJwtTokenTypeConfigurationPropertyToTerraform(struct?: AwsIndex.JwtTokenTypeConfigurationPropertyOutputReference | AwsIndex.JwtTokenTypeConfigurationProperty): any;
export declare function awsIndexJwtTokenTypeConfigurationPropertyToHclTerraform(struct?: AwsIndex.JwtTokenTypeConfigurationPropertyOutputReference | AwsIndex.JwtTokenTypeConfigurationProperty): any;
export declare function awsIndexUserTokenConfigurationsPropertyToTerraform(struct?: AwsIndex.UserTokenConfigurationsPropertyOutputReference | AwsIndex.UserTokenConfigurationsProperty): any;
export declare function awsIndexUserTokenConfigurationsPropertyToHclTerraform(struct?: AwsIndex.UserTokenConfigurationsPropertyOutputReference | AwsIndex.UserTokenConfigurationsProperty): any;
export declare namespace AwsIndex {
    interface FaqStatisticsProperty {
    }
    class FaqStatisticsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FaqStatisticsProperty | undefined;
        set internalValue(value: FaqStatisticsProperty | undefined);
        get indexedQuestionAnswersCount(): number;
    }
    class FaqStatisticsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FaqStatisticsPropertyOutputReference;
    }
    interface TextDocumentStatisticsProperty {
    }
    class TextDocumentStatisticsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TextDocumentStatisticsProperty | undefined;
        set internalValue(value: TextDocumentStatisticsProperty | undefined);
        get indexedTextBytes(): number;
        get indexedTextDocumentsCount(): number;
    }
    class TextDocumentStatisticsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TextDocumentStatisticsPropertyOutputReference;
    }
    interface IndexStatisticsProperty {
    }
    class IndexStatisticsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IndexStatisticsProperty | undefined;
        set internalValue(value: IndexStatisticsProperty | undefined);
        private _faqStatistics;
        get faqStatistics(): FaqStatisticsPropertyList;
        private _textDocumentStatistics;
        get textDocumentStatistics(): TextDocumentStatisticsPropertyList;
    }
    class IndexStatisticsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IndexStatisticsPropertyOutputReference;
    }
    interface CapacityUnitsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#query_capacity_units AwsIndex#query_capacity_units}
        */
        readonly queryCapacityUnits?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#storage_capacity_units AwsIndex#storage_capacity_units}
        */
        readonly storageCapacityUnits?: number;
    }
    class CapacityUnitsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CapacityUnitsProperty | undefined;
        set internalValue(value: CapacityUnitsProperty | undefined);
        private _queryCapacityUnits?;
        get queryCapacityUnits(): number;
        set queryCapacityUnits(value: number);
        resetQueryCapacityUnits(): void;
        get queryCapacityUnitsInput(): number | undefined;
        private _storageCapacityUnits?;
        get storageCapacityUnits(): number;
        set storageCapacityUnits(value: number);
        resetStorageCapacityUnits(): void;
        get storageCapacityUnitsInput(): number | undefined;
    }
    interface RelevanceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#duration AwsIndex#duration}
        */
        readonly duration?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#freshness AwsIndex#freshness}
        */
        readonly freshness?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#importance AwsIndex#importance}
        */
        readonly importance?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#rank_order AwsIndex#rank_order}
        */
        readonly rankOrder?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#values_importance_map AwsIndex#values_importance_map}
        */
        readonly valuesImportanceMap?: {
            [key: string]: number;
        };
    }
    class RelevancePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RelevanceProperty | undefined;
        set internalValue(value: RelevanceProperty | undefined);
        private _duration?;
        get duration(): string;
        set duration(value: string);
        resetDuration(): void;
        get durationInput(): string | undefined;
        private _freshness?;
        get freshness(): boolean | cdktn.IResolvable;
        set freshness(value: boolean | cdktn.IResolvable);
        resetFreshness(): void;
        get freshnessInput(): boolean | cdktn.IResolvable | undefined;
        private _importance?;
        get importance(): number;
        set importance(value: number);
        resetImportance(): void;
        get importanceInput(): number | undefined;
        private _rankOrder?;
        get rankOrder(): string;
        set rankOrder(value: string);
        resetRankOrder(): void;
        get rankOrderInput(): string | undefined;
        private _valuesImportanceMap?;
        get valuesImportanceMap(): {
            [key: string]: number;
        };
        set valuesImportanceMap(value: {
            [key: string]: number;
        });
        resetValuesImportanceMap(): void;
        get valuesImportanceMapInput(): {
            [key: string]: number;
        } | undefined;
    }
    interface SearchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#displayable AwsIndex#displayable}
        */
        readonly displayable?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#facetable AwsIndex#facetable}
        */
        readonly facetable?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#searchable AwsIndex#searchable}
        */
        readonly searchable?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#sortable AwsIndex#sortable}
        */
        readonly sortable?: boolean | cdktn.IResolvable;
    }
    class SearchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SearchProperty | undefined;
        set internalValue(value: SearchProperty | undefined);
        private _displayable?;
        get displayable(): boolean | cdktn.IResolvable;
        set displayable(value: boolean | cdktn.IResolvable);
        resetDisplayable(): void;
        get displayableInput(): boolean | cdktn.IResolvable | undefined;
        private _facetable?;
        get facetable(): boolean | cdktn.IResolvable;
        set facetable(value: boolean | cdktn.IResolvable);
        resetFacetable(): void;
        get facetableInput(): boolean | cdktn.IResolvable | undefined;
        private _searchable?;
        get searchable(): boolean | cdktn.IResolvable;
        set searchable(value: boolean | cdktn.IResolvable);
        resetSearchable(): void;
        get searchableInput(): boolean | cdktn.IResolvable | undefined;
        private _sortable?;
        get sortable(): boolean | cdktn.IResolvable;
        set sortable(value: boolean | cdktn.IResolvable);
        resetSortable(): void;
        get sortableInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface DocumentMetadataConfigurationUpdatesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#name AwsIndex#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#type AwsIndex#type}
        */
        readonly type: string;
        /**
        * relevance block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#relevance AwsIndex#relevance}
        */
        readonly relevance?: RelevanceProperty;
        /**
        * search block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#search AwsIndex#search}
        */
        readonly search?: SearchProperty;
    }
    class DocumentMetadataConfigurationUpdatesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DocumentMetadataConfigurationUpdatesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DocumentMetadataConfigurationUpdatesProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _relevance;
        get relevance(): RelevancePropertyOutputReference;
        putRelevance(value: RelevanceProperty): void;
        resetRelevance(): void;
        get relevanceInput(): RelevanceProperty | undefined;
        private _search;
        get search(): SearchPropertyOutputReference;
        putSearch(value: SearchProperty): void;
        resetSearch(): void;
        get searchInput(): SearchProperty | undefined;
    }
    class DocumentMetadataConfigurationUpdatesPropertyList extends cdktn.ComplexList {
        internalValue?: DocumentMetadataConfigurationUpdatesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DocumentMetadataConfigurationUpdatesPropertyOutputReference;
    }
    interface ServerSideEncryptionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#kms_key_id AwsIndex#kms_key_id}
        */
        readonly kmsKeyId?: string;
    }
    class ServerSideEncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ServerSideEncryptionConfigurationProperty | undefined;
        set internalValue(value: ServerSideEncryptionConfigurationProperty | undefined);
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#create AwsIndex#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#delete AwsIndex#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#update AwsIndex#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface UserGroupResolutionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#user_group_resolution_mode AwsIndex#user_group_resolution_mode}
        */
        readonly userGroupResolutionMode: string;
    }
    class UserGroupResolutionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UserGroupResolutionConfigurationProperty | undefined;
        set internalValue(value: UserGroupResolutionConfigurationProperty | undefined);
        private _userGroupResolutionMode?;
        get userGroupResolutionMode(): string;
        set userGroupResolutionMode(value: string);
        get userGroupResolutionModeInput(): string | undefined;
    }
    interface JsonTokenTypeConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#group_attribute_field AwsIndex#group_attribute_field}
        */
        readonly groupAttributeField: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#user_name_attribute_field AwsIndex#user_name_attribute_field}
        */
        readonly userNameAttributeField: string;
    }
    class JsonTokenTypeConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): JsonTokenTypeConfigurationProperty | undefined;
        set internalValue(value: JsonTokenTypeConfigurationProperty | undefined);
        private _groupAttributeField?;
        get groupAttributeField(): string;
        set groupAttributeField(value: string);
        get groupAttributeFieldInput(): string | undefined;
        private _userNameAttributeField?;
        get userNameAttributeField(): string;
        set userNameAttributeField(value: string);
        get userNameAttributeFieldInput(): string | undefined;
    }
    interface JwtTokenTypeConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#claim_regex AwsIndex#claim_regex}
        */
        readonly claimRegex?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#group_attribute_field AwsIndex#group_attribute_field}
        */
        readonly groupAttributeField?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#issuer AwsIndex#issuer}
        */
        readonly issuer?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#key_location AwsIndex#key_location}
        */
        readonly keyLocation: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#secrets_manager_arn AwsIndex#secrets_manager_arn}
        */
        readonly secretsManagerArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#url AwsIndex#url}
        */
        readonly url?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#user_name_attribute_field AwsIndex#user_name_attribute_field}
        */
        readonly userNameAttributeField?: string;
    }
    class JwtTokenTypeConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): JwtTokenTypeConfigurationProperty | undefined;
        set internalValue(value: JwtTokenTypeConfigurationProperty | undefined);
        private _claimRegex?;
        get claimRegex(): string;
        set claimRegex(value: string);
        resetClaimRegex(): void;
        get claimRegexInput(): string | undefined;
        private _groupAttributeField?;
        get groupAttributeField(): string;
        set groupAttributeField(value: string);
        resetGroupAttributeField(): void;
        get groupAttributeFieldInput(): string | undefined;
        private _issuer?;
        get issuer(): string;
        set issuer(value: string);
        resetIssuer(): void;
        get issuerInput(): string | undefined;
        private _keyLocation?;
        get keyLocation(): string;
        set keyLocation(value: string);
        get keyLocationInput(): string | undefined;
        private _secretsManagerArn?;
        get secretsManagerArn(): string;
        set secretsManagerArn(value: string);
        resetSecretsManagerArn(): void;
        get secretsManagerArnInput(): string | undefined;
        private _url?;
        get url(): string;
        set url(value: string);
        resetUrl(): void;
        get urlInput(): string | undefined;
        private _userNameAttributeField?;
        get userNameAttributeField(): string;
        set userNameAttributeField(value: string);
        resetUserNameAttributeField(): void;
        get userNameAttributeFieldInput(): string | undefined;
    }
    interface UserTokenConfigurationsProperty {
        /**
        * json_token_type_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#json_token_type_configuration AwsIndex#json_token_type_configuration}
        */
        readonly jsonTokenTypeConfiguration?: JsonTokenTypeConfigurationProperty;
        /**
        * jwt_token_type_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_index#jwt_token_type_configuration AwsIndex#jwt_token_type_configuration}
        */
        readonly jwtTokenTypeConfiguration?: JwtTokenTypeConfigurationProperty;
    }
    class UserTokenConfigurationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UserTokenConfigurationsProperty | undefined;
        set internalValue(value: UserTokenConfigurationsProperty | undefined);
        private _jsonTokenTypeConfiguration;
        get jsonTokenTypeConfiguration(): JsonTokenTypeConfigurationPropertyOutputReference;
        putJsonTokenTypeConfiguration(value: JsonTokenTypeConfigurationProperty): void;
        resetJsonTokenTypeConfiguration(): void;
        get jsonTokenTypeConfigurationInput(): JsonTokenTypeConfigurationProperty | undefined;
        private _jwtTokenTypeConfiguration;
        get jwtTokenTypeConfiguration(): JwtTokenTypeConfigurationPropertyOutputReference;
        putJwtTokenTypeConfiguration(value: JwtTokenTypeConfigurationProperty): void;
        resetJwtTokenTypeConfiguration(): void;
        get jwtTokenTypeConfigurationInput(): JwtTokenTypeConfigurationProperty | undefined;
    }
}
