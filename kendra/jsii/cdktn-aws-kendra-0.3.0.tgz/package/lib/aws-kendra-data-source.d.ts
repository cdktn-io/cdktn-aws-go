import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDataSourceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#description AwsDataSource#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#id AwsDataSource#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#index_id AwsDataSource#index_id}
    */
    readonly indexId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#language_code AwsDataSource#language_code}
    */
    readonly languageCode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#name AwsDataSource#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#region AwsDataSource#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#role_arn AwsDataSource#role_arn}
    */
    readonly roleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#schedule AwsDataSource#schedule}
    */
    readonly schedule?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#tags AwsDataSource#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#tags_all AwsDataSource#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#type AwsDataSource#type}
    */
    readonly type: string;
    /**
    * configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#configuration AwsDataSource#configuration}
    */
    readonly configuration?: AwsDataSource.ConfigurationProperty;
    /**
    * custom_document_enrichment_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#custom_document_enrichment_configuration AwsDataSource#custom_document_enrichment_configuration}
    */
    readonly customDocumentEnrichmentConfiguration?: AwsDataSource.CustomDocumentEnrichmentConfigurationProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#timeouts AwsDataSource#timeouts}
    */
    readonly timeouts?: AwsDataSource.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source aws_kendra_data_source}
*/
export declare class AwsDataSource extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_kendra_data_source";
    /**
    * Generates CDKTN code for importing a AwsDataSource resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDataSource to import
    * @param importFromId The id of the existing AwsDataSource that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDataSource to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source aws_kendra_data_source} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDataSourceConfig
    */
    constructor(scope: Construct, id: string, config: AwsDataSourceConfig);
    get arn(): string;
    get createdAt(): string;
    get dataSourceId(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get errorMessage(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _indexId?;
    get indexId(): string;
    set indexId(value: string);
    get indexIdInput(): string | undefined;
    private _languageCode?;
    get languageCode(): string;
    set languageCode(value: string);
    resetLanguageCode(): void;
    get languageCodeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
    private _schedule?;
    get schedule(): string;
    set schedule(value: string);
    resetSchedule(): void;
    get scheduleInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    get updatedAt(): string;
    private _configuration;
    get configuration(): AwsDataSource.ConfigurationPropertyOutputReference;
    putConfiguration(value: AwsDataSource.ConfigurationProperty): void;
    resetConfiguration(): void;
    get configurationInput(): AwsDataSource.ConfigurationProperty | undefined;
    private _customDocumentEnrichmentConfiguration;
    get customDocumentEnrichmentConfiguration(): AwsDataSource.CustomDocumentEnrichmentConfigurationPropertyOutputReference;
    putCustomDocumentEnrichmentConfiguration(value: AwsDataSource.CustomDocumentEnrichmentConfigurationProperty): void;
    resetCustomDocumentEnrichmentConfiguration(): void;
    get customDocumentEnrichmentConfigurationInput(): AwsDataSource.CustomDocumentEnrichmentConfigurationProperty | undefined;
    private _timeouts;
    get timeouts(): AwsDataSource.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsDataSource.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): AwsDataSource.TimeoutsProperty | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDataSourceAccessControlListConfigurationPropertyToTerraform(struct?: AwsDataSource.AccessControlListConfigurationPropertyOutputReference | AwsDataSource.AccessControlListConfigurationProperty): any;
export declare function awsDataSourceAccessControlListConfigurationPropertyToHclTerraform(struct?: AwsDataSource.AccessControlListConfigurationPropertyOutputReference | AwsDataSource.AccessControlListConfigurationProperty): any;
export declare function awsDataSourceDocumentsMetadataConfigurationPropertyToTerraform(struct?: AwsDataSource.DocumentsMetadataConfigurationPropertyOutputReference | AwsDataSource.DocumentsMetadataConfigurationProperty): any;
export declare function awsDataSourceDocumentsMetadataConfigurationPropertyToHclTerraform(struct?: AwsDataSource.DocumentsMetadataConfigurationPropertyOutputReference | AwsDataSource.DocumentsMetadataConfigurationProperty): any;
export declare function awsDataSourceS3ConfigurationPropertyToTerraform(struct?: AwsDataSource.S3ConfigurationPropertyOutputReference | AwsDataSource.S3ConfigurationProperty): any;
export declare function awsDataSourceS3ConfigurationPropertyToHclTerraform(struct?: AwsDataSource.S3ConfigurationPropertyOutputReference | AwsDataSource.S3ConfigurationProperty): any;
export declare function awsDataSourceTemplateConfigurationPropertyToTerraform(struct?: AwsDataSource.TemplateConfigurationPropertyOutputReference | AwsDataSource.TemplateConfigurationProperty): any;
export declare function awsDataSourceTemplateConfigurationPropertyToHclTerraform(struct?: AwsDataSource.TemplateConfigurationPropertyOutputReference | AwsDataSource.TemplateConfigurationProperty): any;
export declare function awsDataSourceBasicAuthenticationPropertyToTerraform(struct?: AwsDataSource.BasicAuthenticationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceBasicAuthenticationPropertyToHclTerraform(struct?: AwsDataSource.BasicAuthenticationProperty | cdktn.IResolvable): any;
export declare function awsDataSourceAuthenticationConfigurationPropertyToTerraform(struct?: AwsDataSource.AuthenticationConfigurationPropertyOutputReference | AwsDataSource.AuthenticationConfigurationProperty): any;
export declare function awsDataSourceAuthenticationConfigurationPropertyToHclTerraform(struct?: AwsDataSource.AuthenticationConfigurationPropertyOutputReference | AwsDataSource.AuthenticationConfigurationProperty): any;
export declare function awsDataSourceProxyConfigurationPropertyToTerraform(struct?: AwsDataSource.ProxyConfigurationPropertyOutputReference | AwsDataSource.ProxyConfigurationProperty): any;
export declare function awsDataSourceProxyConfigurationPropertyToHclTerraform(struct?: AwsDataSource.ProxyConfigurationPropertyOutputReference | AwsDataSource.ProxyConfigurationProperty): any;
export declare function awsDataSourceSeedUrlConfigurationPropertyToTerraform(struct?: AwsDataSource.SeedUrlConfigurationPropertyOutputReference | AwsDataSource.SeedUrlConfigurationProperty): any;
export declare function awsDataSourceSeedUrlConfigurationPropertyToHclTerraform(struct?: AwsDataSource.SeedUrlConfigurationPropertyOutputReference | AwsDataSource.SeedUrlConfigurationProperty): any;
export declare function awsDataSourceSiteMapsConfigurationPropertyToTerraform(struct?: AwsDataSource.SiteMapsConfigurationPropertyOutputReference | AwsDataSource.SiteMapsConfigurationProperty): any;
export declare function awsDataSourceSiteMapsConfigurationPropertyToHclTerraform(struct?: AwsDataSource.SiteMapsConfigurationPropertyOutputReference | AwsDataSource.SiteMapsConfigurationProperty): any;
export declare function awsDataSourceUrlsPropertyToTerraform(struct?: AwsDataSource.UrlsPropertyOutputReference | AwsDataSource.UrlsProperty): any;
export declare function awsDataSourceUrlsPropertyToHclTerraform(struct?: AwsDataSource.UrlsPropertyOutputReference | AwsDataSource.UrlsProperty): any;
export declare function awsDataSourceWebCrawlerConfigurationPropertyToTerraform(struct?: AwsDataSource.WebCrawlerConfigurationPropertyOutputReference | AwsDataSource.WebCrawlerConfigurationProperty): any;
export declare function awsDataSourceWebCrawlerConfigurationPropertyToHclTerraform(struct?: AwsDataSource.WebCrawlerConfigurationPropertyOutputReference | AwsDataSource.WebCrawlerConfigurationProperty): any;
export declare function awsDataSourceConfigurationPropertyToTerraform(struct?: AwsDataSource.ConfigurationPropertyOutputReference | AwsDataSource.ConfigurationProperty): any;
export declare function awsDataSourceConfigurationPropertyToHclTerraform(struct?: AwsDataSource.ConfigurationPropertyOutputReference | AwsDataSource.ConfigurationProperty): any;
export declare function awsDataSourceCustomDocumentEnrichmentConfigurationInlineConfigurationsConditionConditionOnValuePropertyToTerraform(struct?: AwsDataSource.CustomDocumentEnrichmentConfigurationInlineConfigurationsConditionConditionOnValuePropertyOutputReference | AwsDataSource.CustomDocumentEnrichmentConfigurationInlineConfigurationsConditionConditionOnValueProperty): any;
export declare function awsDataSourceCustomDocumentEnrichmentConfigurationInlineConfigurationsConditionConditionOnValuePropertyToHclTerraform(struct?: AwsDataSource.CustomDocumentEnrichmentConfigurationInlineConfigurationsConditionConditionOnValuePropertyOutputReference | AwsDataSource.CustomDocumentEnrichmentConfigurationInlineConfigurationsConditionConditionOnValueProperty): any;
export declare function awsDataSourceConditionPropertyToTerraform(struct?: AwsDataSource.ConditionPropertyOutputReference | AwsDataSource.ConditionProperty): any;
export declare function awsDataSourceConditionPropertyToHclTerraform(struct?: AwsDataSource.ConditionPropertyOutputReference | AwsDataSource.ConditionProperty): any;
export declare function awsDataSourceTargetDocumentAttributeValuePropertyToTerraform(struct?: AwsDataSource.TargetDocumentAttributeValuePropertyOutputReference | AwsDataSource.TargetDocumentAttributeValueProperty): any;
export declare function awsDataSourceTargetDocumentAttributeValuePropertyToHclTerraform(struct?: AwsDataSource.TargetDocumentAttributeValuePropertyOutputReference | AwsDataSource.TargetDocumentAttributeValueProperty): any;
export declare function awsDataSourceTargetPropertyToTerraform(struct?: AwsDataSource.TargetPropertyOutputReference | AwsDataSource.TargetProperty): any;
export declare function awsDataSourceTargetPropertyToHclTerraform(struct?: AwsDataSource.TargetPropertyOutputReference | AwsDataSource.TargetProperty): any;
export declare function awsDataSourceInlineConfigurationsPropertyToTerraform(struct?: AwsDataSource.InlineConfigurationsProperty | cdktn.IResolvable): any;
export declare function awsDataSourceInlineConfigurationsPropertyToHclTerraform(struct?: AwsDataSource.InlineConfigurationsProperty | cdktn.IResolvable): any;
export declare function awsDataSourceCustomDocumentEnrichmentConfigurationPostExtractionHookConfigurationInvocationConditionConditionOnValuePropertyToTerraform(struct?: AwsDataSource.CustomDocumentEnrichmentConfigurationPostExtractionHookConfigurationInvocationConditionConditionOnValuePropertyOutputReference | AwsDataSource.CustomDocumentEnrichmentConfigurationPostExtractionHookConfigurationInvocationConditionConditionOnValueProperty): any;
export declare function awsDataSourceCustomDocumentEnrichmentConfigurationPostExtractionHookConfigurationInvocationConditionConditionOnValuePropertyToHclTerraform(struct?: AwsDataSource.CustomDocumentEnrichmentConfigurationPostExtractionHookConfigurationInvocationConditionConditionOnValuePropertyOutputReference | AwsDataSource.CustomDocumentEnrichmentConfigurationPostExtractionHookConfigurationInvocationConditionConditionOnValueProperty): any;
export declare function awsDataSourceCustomDocumentEnrichmentConfigurationPostExtractionHookConfigurationInvocationConditionPropertyToTerraform(struct?: AwsDataSource.CustomDocumentEnrichmentConfigurationPostExtractionHookConfigurationInvocationConditionPropertyOutputReference | AwsDataSource.CustomDocumentEnrichmentConfigurationPostExtractionHookConfigurationInvocationConditionProperty): any;
export declare function awsDataSourceCustomDocumentEnrichmentConfigurationPostExtractionHookConfigurationInvocationConditionPropertyToHclTerraform(struct?: AwsDataSource.CustomDocumentEnrichmentConfigurationPostExtractionHookConfigurationInvocationConditionPropertyOutputReference | AwsDataSource.CustomDocumentEnrichmentConfigurationPostExtractionHookConfigurationInvocationConditionProperty): any;
export declare function awsDataSourcePostExtractionHookConfigurationPropertyToTerraform(struct?: AwsDataSource.PostExtractionHookConfigurationPropertyOutputReference | AwsDataSource.PostExtractionHookConfigurationProperty): any;
export declare function awsDataSourcePostExtractionHookConfigurationPropertyToHclTerraform(struct?: AwsDataSource.PostExtractionHookConfigurationPropertyOutputReference | AwsDataSource.PostExtractionHookConfigurationProperty): any;
export declare function awsDataSourceCustomDocumentEnrichmentConfigurationPreExtractionHookConfigurationInvocationConditionConditionOnValuePropertyToTerraform(struct?: AwsDataSource.CustomDocumentEnrichmentConfigurationPreExtractionHookConfigurationInvocationConditionConditionOnValuePropertyOutputReference | AwsDataSource.CustomDocumentEnrichmentConfigurationPreExtractionHookConfigurationInvocationConditionConditionOnValueProperty): any;
export declare function awsDataSourceCustomDocumentEnrichmentConfigurationPreExtractionHookConfigurationInvocationConditionConditionOnValuePropertyToHclTerraform(struct?: AwsDataSource.CustomDocumentEnrichmentConfigurationPreExtractionHookConfigurationInvocationConditionConditionOnValuePropertyOutputReference | AwsDataSource.CustomDocumentEnrichmentConfigurationPreExtractionHookConfigurationInvocationConditionConditionOnValueProperty): any;
export declare function awsDataSourceCustomDocumentEnrichmentConfigurationPreExtractionHookConfigurationInvocationConditionPropertyToTerraform(struct?: AwsDataSource.CustomDocumentEnrichmentConfigurationPreExtractionHookConfigurationInvocationConditionPropertyOutputReference | AwsDataSource.CustomDocumentEnrichmentConfigurationPreExtractionHookConfigurationInvocationConditionProperty): any;
export declare function awsDataSourceCustomDocumentEnrichmentConfigurationPreExtractionHookConfigurationInvocationConditionPropertyToHclTerraform(struct?: AwsDataSource.CustomDocumentEnrichmentConfigurationPreExtractionHookConfigurationInvocationConditionPropertyOutputReference | AwsDataSource.CustomDocumentEnrichmentConfigurationPreExtractionHookConfigurationInvocationConditionProperty): any;
export declare function awsDataSourcePreExtractionHookConfigurationPropertyToTerraform(struct?: AwsDataSource.PreExtractionHookConfigurationPropertyOutputReference | AwsDataSource.PreExtractionHookConfigurationProperty): any;
export declare function awsDataSourcePreExtractionHookConfigurationPropertyToHclTerraform(struct?: AwsDataSource.PreExtractionHookConfigurationPropertyOutputReference | AwsDataSource.PreExtractionHookConfigurationProperty): any;
export declare function awsDataSourceCustomDocumentEnrichmentConfigurationPropertyToTerraform(struct?: AwsDataSource.CustomDocumentEnrichmentConfigurationPropertyOutputReference | AwsDataSource.CustomDocumentEnrichmentConfigurationProperty): any;
export declare function awsDataSourceCustomDocumentEnrichmentConfigurationPropertyToHclTerraform(struct?: AwsDataSource.CustomDocumentEnrichmentConfigurationPropertyOutputReference | AwsDataSource.CustomDocumentEnrichmentConfigurationProperty): any;
export declare function awsDataSourceTimeoutsPropertyToTerraform(struct?: AwsDataSource.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsDataSourceTimeoutsPropertyToHclTerraform(struct?: AwsDataSource.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsDataSource {
    interface AccessControlListConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#key_path AwsDataSource#key_path}
        */
        readonly keyPath?: string;
    }
    class AccessControlListConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AccessControlListConfigurationProperty | undefined;
        set internalValue(value: AccessControlListConfigurationProperty | undefined);
        private _keyPath?;
        get keyPath(): string;
        set keyPath(value: string);
        resetKeyPath(): void;
        get keyPathInput(): string | undefined;
    }
    interface DocumentsMetadataConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#s3_prefix AwsDataSource#s3_prefix}
        */
        readonly s3Prefix?: string;
    }
    class DocumentsMetadataConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DocumentsMetadataConfigurationProperty | undefined;
        set internalValue(value: DocumentsMetadataConfigurationProperty | undefined);
        private _s3Prefix?;
        get s3Prefix(): string;
        set s3Prefix(value: string);
        resetS3Prefix(): void;
        get s3PrefixInput(): string | undefined;
    }
    interface S3ConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#bucket_name AwsDataSource#bucket_name}
        */
        readonly bucketName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#exclusion_patterns AwsDataSource#exclusion_patterns}
        */
        readonly exclusionPatterns?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#inclusion_patterns AwsDataSource#inclusion_patterns}
        */
        readonly inclusionPatterns?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#inclusion_prefixes AwsDataSource#inclusion_prefixes}
        */
        readonly inclusionPrefixes?: string[];
        /**
        * access_control_list_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#access_control_list_configuration AwsDataSource#access_control_list_configuration}
        */
        readonly accessControlListConfiguration?: AccessControlListConfigurationProperty;
        /**
        * documents_metadata_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#documents_metadata_configuration AwsDataSource#documents_metadata_configuration}
        */
        readonly documentsMetadataConfiguration?: DocumentsMetadataConfigurationProperty;
    }
    class S3ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3ConfigurationProperty | undefined;
        set internalValue(value: S3ConfigurationProperty | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        get bucketNameInput(): string | undefined;
        private _exclusionPatterns?;
        get exclusionPatterns(): string[];
        set exclusionPatterns(value: string[]);
        resetExclusionPatterns(): void;
        get exclusionPatternsInput(): string[] | undefined;
        private _inclusionPatterns?;
        get inclusionPatterns(): string[];
        set inclusionPatterns(value: string[]);
        resetInclusionPatterns(): void;
        get inclusionPatternsInput(): string[] | undefined;
        private _inclusionPrefixes?;
        get inclusionPrefixes(): string[];
        set inclusionPrefixes(value: string[]);
        resetInclusionPrefixes(): void;
        get inclusionPrefixesInput(): string[] | undefined;
        private _accessControlListConfiguration;
        get accessControlListConfiguration(): AccessControlListConfigurationPropertyOutputReference;
        putAccessControlListConfiguration(value: AccessControlListConfigurationProperty): void;
        resetAccessControlListConfiguration(): void;
        get accessControlListConfigurationInput(): AccessControlListConfigurationProperty | undefined;
        private _documentsMetadataConfiguration;
        get documentsMetadataConfiguration(): DocumentsMetadataConfigurationPropertyOutputReference;
        putDocumentsMetadataConfiguration(value: DocumentsMetadataConfigurationProperty): void;
        resetDocumentsMetadataConfiguration(): void;
        get documentsMetadataConfigurationInput(): DocumentsMetadataConfigurationProperty | undefined;
    }
    interface TemplateConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#template AwsDataSource#template}
        */
        readonly template: string;
    }
    class TemplateConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TemplateConfigurationProperty | undefined;
        set internalValue(value: TemplateConfigurationProperty | undefined);
        private _template?;
        get template(): string;
        set template(value: string);
        get templateInput(): string | undefined;
    }
    interface BasicAuthenticationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#credentials AwsDataSource#credentials}
        */
        readonly credentials: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#host AwsDataSource#host}
        */
        readonly host: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#port AwsDataSource#port}
        */
        readonly port: number;
    }
    class BasicAuthenticationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BasicAuthenticationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: BasicAuthenticationProperty | cdktn.IResolvable | undefined);
        private _credentials?;
        get credentials(): string;
        set credentials(value: string);
        get credentialsInput(): string | undefined;
        private _host?;
        get host(): string;
        set host(value: string);
        get hostInput(): string | undefined;
        private _port?;
        get port(): number;
        set port(value: number);
        get portInput(): number | undefined;
    }
    class BasicAuthenticationPropertyList extends cdktn.ComplexList {
        internalValue?: BasicAuthenticationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BasicAuthenticationPropertyOutputReference;
    }
    interface AuthenticationConfigurationProperty {
        /**
        * basic_authentication block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#basic_authentication AwsDataSource#basic_authentication}
        */
        readonly basicAuthentication?: BasicAuthenticationProperty[] | cdktn.IResolvable;
    }
    class AuthenticationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AuthenticationConfigurationProperty | undefined;
        set internalValue(value: AuthenticationConfigurationProperty | undefined);
        private _basicAuthentication;
        get basicAuthentication(): BasicAuthenticationPropertyList;
        putBasicAuthentication(value: BasicAuthenticationProperty[] | cdktn.IResolvable): void;
        resetBasicAuthentication(): void;
        get basicAuthenticationInput(): cdktn.IResolvable | BasicAuthenticationProperty[] | undefined;
    }
    interface ProxyConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#credentials AwsDataSource#credentials}
        */
        readonly credentials?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#host AwsDataSource#host}
        */
        readonly host: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#port AwsDataSource#port}
        */
        readonly port: number;
    }
    class ProxyConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ProxyConfigurationProperty | undefined;
        set internalValue(value: ProxyConfigurationProperty | undefined);
        private _credentials?;
        get credentials(): string;
        set credentials(value: string);
        resetCredentials(): void;
        get credentialsInput(): string | undefined;
        private _host?;
        get host(): string;
        set host(value: string);
        get hostInput(): string | undefined;
        private _port?;
        get port(): number;
        set port(value: number);
        get portInput(): number | undefined;
    }
    interface SeedUrlConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#seed_urls AwsDataSource#seed_urls}
        */
        readonly seedUrls: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#web_crawler_mode AwsDataSource#web_crawler_mode}
        */
        readonly webCrawlerMode?: string;
    }
    class SeedUrlConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SeedUrlConfigurationProperty | undefined;
        set internalValue(value: SeedUrlConfigurationProperty | undefined);
        private _seedUrls?;
        get seedUrls(): string[];
        set seedUrls(value: string[]);
        get seedUrlsInput(): string[] | undefined;
        private _webCrawlerMode?;
        get webCrawlerMode(): string;
        set webCrawlerMode(value: string);
        resetWebCrawlerMode(): void;
        get webCrawlerModeInput(): string | undefined;
    }
    interface SiteMapsConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#site_maps AwsDataSource#site_maps}
        */
        readonly siteMaps: string[];
    }
    class SiteMapsConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SiteMapsConfigurationProperty | undefined;
        set internalValue(value: SiteMapsConfigurationProperty | undefined);
        private _siteMaps?;
        get siteMaps(): string[];
        set siteMaps(value: string[]);
        get siteMapsInput(): string[] | undefined;
    }
    interface UrlsProperty {
        /**
        * seed_url_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#seed_url_configuration AwsDataSource#seed_url_configuration}
        */
        readonly seedUrlConfiguration?: SeedUrlConfigurationProperty;
        /**
        * site_maps_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#site_maps_configuration AwsDataSource#site_maps_configuration}
        */
        readonly siteMapsConfiguration?: SiteMapsConfigurationProperty;
    }
    class UrlsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UrlsProperty | undefined;
        set internalValue(value: UrlsProperty | undefined);
        private _seedUrlConfiguration;
        get seedUrlConfiguration(): SeedUrlConfigurationPropertyOutputReference;
        putSeedUrlConfiguration(value: SeedUrlConfigurationProperty): void;
        resetSeedUrlConfiguration(): void;
        get seedUrlConfigurationInput(): SeedUrlConfigurationProperty | undefined;
        private _siteMapsConfiguration;
        get siteMapsConfiguration(): SiteMapsConfigurationPropertyOutputReference;
        putSiteMapsConfiguration(value: SiteMapsConfigurationProperty): void;
        resetSiteMapsConfiguration(): void;
        get siteMapsConfigurationInput(): SiteMapsConfigurationProperty | undefined;
    }
    interface WebCrawlerConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#crawl_depth AwsDataSource#crawl_depth}
        */
        readonly crawlDepth?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#max_content_size_per_page_in_mega_bytes AwsDataSource#max_content_size_per_page_in_mega_bytes}
        */
        readonly maxContentSizePerPageInMegaBytes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#max_links_per_page AwsDataSource#max_links_per_page}
        */
        readonly maxLinksPerPage?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#max_urls_per_minute_crawl_rate AwsDataSource#max_urls_per_minute_crawl_rate}
        */
        readonly maxUrlsPerMinuteCrawlRate?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#url_exclusion_patterns AwsDataSource#url_exclusion_patterns}
        */
        readonly urlExclusionPatterns?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#url_inclusion_patterns AwsDataSource#url_inclusion_patterns}
        */
        readonly urlInclusionPatterns?: string[];
        /**
        * authentication_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#authentication_configuration AwsDataSource#authentication_configuration}
        */
        readonly authenticationConfiguration?: AuthenticationConfigurationProperty;
        /**
        * proxy_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#proxy_configuration AwsDataSource#proxy_configuration}
        */
        readonly proxyConfiguration?: ProxyConfigurationProperty;
        /**
        * urls block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#urls AwsDataSource#urls}
        */
        readonly urls: UrlsProperty;
    }
    class WebCrawlerConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): WebCrawlerConfigurationProperty | undefined;
        set internalValue(value: WebCrawlerConfigurationProperty | undefined);
        private _crawlDepth?;
        get crawlDepth(): number;
        set crawlDepth(value: number);
        resetCrawlDepth(): void;
        get crawlDepthInput(): number | undefined;
        private _maxContentSizePerPageInMegaBytes?;
        get maxContentSizePerPageInMegaBytes(): number;
        set maxContentSizePerPageInMegaBytes(value: number);
        resetMaxContentSizePerPageInMegaBytes(): void;
        get maxContentSizePerPageInMegaBytesInput(): number | undefined;
        private _maxLinksPerPage?;
        get maxLinksPerPage(): number;
        set maxLinksPerPage(value: number);
        resetMaxLinksPerPage(): void;
        get maxLinksPerPageInput(): number | undefined;
        private _maxUrlsPerMinuteCrawlRate?;
        get maxUrlsPerMinuteCrawlRate(): number;
        set maxUrlsPerMinuteCrawlRate(value: number);
        resetMaxUrlsPerMinuteCrawlRate(): void;
        get maxUrlsPerMinuteCrawlRateInput(): number | undefined;
        private _urlExclusionPatterns?;
        get urlExclusionPatterns(): string[];
        set urlExclusionPatterns(value: string[]);
        resetUrlExclusionPatterns(): void;
        get urlExclusionPatternsInput(): string[] | undefined;
        private _urlInclusionPatterns?;
        get urlInclusionPatterns(): string[];
        set urlInclusionPatterns(value: string[]);
        resetUrlInclusionPatterns(): void;
        get urlInclusionPatternsInput(): string[] | undefined;
        private _authenticationConfiguration;
        get authenticationConfiguration(): AuthenticationConfigurationPropertyOutputReference;
        putAuthenticationConfiguration(value: AuthenticationConfigurationProperty): void;
        resetAuthenticationConfiguration(): void;
        get authenticationConfigurationInput(): AuthenticationConfigurationProperty | undefined;
        private _proxyConfiguration;
        get proxyConfiguration(): ProxyConfigurationPropertyOutputReference;
        putProxyConfiguration(value: ProxyConfigurationProperty): void;
        resetProxyConfiguration(): void;
        get proxyConfigurationInput(): ProxyConfigurationProperty | undefined;
        private _urls;
        get urls(): UrlsPropertyOutputReference;
        putUrls(value: UrlsProperty): void;
        get urlsInput(): UrlsProperty | undefined;
    }
    interface ConfigurationProperty {
        /**
        * s3_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#s3_configuration AwsDataSource#s3_configuration}
        */
        readonly s3Configuration?: S3ConfigurationProperty;
        /**
        * template_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#template_configuration AwsDataSource#template_configuration}
        */
        readonly templateConfiguration?: TemplateConfigurationProperty;
        /**
        * web_crawler_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#web_crawler_configuration AwsDataSource#web_crawler_configuration}
        */
        readonly webCrawlerConfiguration?: WebCrawlerConfigurationProperty;
    }
    class ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConfigurationProperty | undefined;
        set internalValue(value: ConfigurationProperty | undefined);
        private _s3Configuration;
        get s3Configuration(): S3ConfigurationPropertyOutputReference;
        putS3Configuration(value: S3ConfigurationProperty): void;
        resetS3Configuration(): void;
        get s3ConfigurationInput(): S3ConfigurationProperty | undefined;
        private _templateConfiguration;
        get templateConfiguration(): TemplateConfigurationPropertyOutputReference;
        putTemplateConfiguration(value: TemplateConfigurationProperty): void;
        resetTemplateConfiguration(): void;
        get templateConfigurationInput(): TemplateConfigurationProperty | undefined;
        private _webCrawlerConfiguration;
        get webCrawlerConfiguration(): WebCrawlerConfigurationPropertyOutputReference;
        putWebCrawlerConfiguration(value: WebCrawlerConfigurationProperty): void;
        resetWebCrawlerConfiguration(): void;
        get webCrawlerConfigurationInput(): WebCrawlerConfigurationProperty | undefined;
    }
    interface CustomDocumentEnrichmentConfigurationInlineConfigurationsConditionConditionOnValueProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#date_value AwsDataSource#date_value}
        */
        readonly dateValue?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#long_value AwsDataSource#long_value}
        */
        readonly longValue?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#string_list_value AwsDataSource#string_list_value}
        */
        readonly stringListValue?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#string_value AwsDataSource#string_value}
        */
        readonly stringValue?: string;
    }
    class CustomDocumentEnrichmentConfigurationInlineConfigurationsConditionConditionOnValuePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CustomDocumentEnrichmentConfigurationInlineConfigurationsConditionConditionOnValueProperty | undefined;
        set internalValue(value: CustomDocumentEnrichmentConfigurationInlineConfigurationsConditionConditionOnValueProperty | undefined);
        private _dateValue?;
        get dateValue(): string;
        set dateValue(value: string);
        resetDateValue(): void;
        get dateValueInput(): string | undefined;
        private _longValue?;
        get longValue(): number;
        set longValue(value: number);
        resetLongValue(): void;
        get longValueInput(): number | undefined;
        private _stringListValue?;
        get stringListValue(): string[];
        set stringListValue(value: string[]);
        resetStringListValue(): void;
        get stringListValueInput(): string[] | undefined;
        private _stringValue?;
        get stringValue(): string;
        set stringValue(value: string);
        resetStringValue(): void;
        get stringValueInput(): string | undefined;
    }
    interface ConditionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#condition_document_attribute_key AwsDataSource#condition_document_attribute_key}
        */
        readonly conditionDocumentAttributeKey: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#operator AwsDataSource#operator}
        */
        readonly operator: string;
        /**
        * condition_on_value block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#condition_on_value AwsDataSource#condition_on_value}
        */
        readonly conditionOnValue?: CustomDocumentEnrichmentConfigurationInlineConfigurationsConditionConditionOnValueProperty;
    }
    class ConditionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConditionProperty | undefined;
        set internalValue(value: ConditionProperty | undefined);
        private _conditionDocumentAttributeKey?;
        get conditionDocumentAttributeKey(): string;
        set conditionDocumentAttributeKey(value: string);
        get conditionDocumentAttributeKeyInput(): string | undefined;
        private _operator?;
        get operator(): string;
        set operator(value: string);
        get operatorInput(): string | undefined;
        private _conditionOnValue;
        get conditionOnValue(): CustomDocumentEnrichmentConfigurationInlineConfigurationsConditionConditionOnValuePropertyOutputReference;
        putConditionOnValue(value: CustomDocumentEnrichmentConfigurationInlineConfigurationsConditionConditionOnValueProperty): void;
        resetConditionOnValue(): void;
        get conditionOnValueInput(): CustomDocumentEnrichmentConfigurationInlineConfigurationsConditionConditionOnValueProperty | undefined;
    }
    interface TargetDocumentAttributeValueProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#date_value AwsDataSource#date_value}
        */
        readonly dateValue?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#long_value AwsDataSource#long_value}
        */
        readonly longValue?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#string_list_value AwsDataSource#string_list_value}
        */
        readonly stringListValue?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#string_value AwsDataSource#string_value}
        */
        readonly stringValue?: string;
    }
    class TargetDocumentAttributeValuePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TargetDocumentAttributeValueProperty | undefined;
        set internalValue(value: TargetDocumentAttributeValueProperty | undefined);
        private _dateValue?;
        get dateValue(): string;
        set dateValue(value: string);
        resetDateValue(): void;
        get dateValueInput(): string | undefined;
        private _longValue?;
        get longValue(): number;
        set longValue(value: number);
        resetLongValue(): void;
        get longValueInput(): number | undefined;
        private _stringListValue?;
        get stringListValue(): string[];
        set stringListValue(value: string[]);
        resetStringListValue(): void;
        get stringListValueInput(): string[] | undefined;
        private _stringValue?;
        get stringValue(): string;
        set stringValue(value: string);
        resetStringValue(): void;
        get stringValueInput(): string | undefined;
    }
    interface TargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#target_document_attribute_key AwsDataSource#target_document_attribute_key}
        */
        readonly targetDocumentAttributeKey?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#target_document_attribute_value_deletion AwsDataSource#target_document_attribute_value_deletion}
        */
        readonly targetDocumentAttributeValueDeletion?: boolean | cdktn.IResolvable;
        /**
        * target_document_attribute_value block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#target_document_attribute_value AwsDataSource#target_document_attribute_value}
        */
        readonly targetDocumentAttributeValue?: TargetDocumentAttributeValueProperty;
    }
    class TargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TargetProperty | undefined;
        set internalValue(value: TargetProperty | undefined);
        private _targetDocumentAttributeKey?;
        get targetDocumentAttributeKey(): string;
        set targetDocumentAttributeKey(value: string);
        resetTargetDocumentAttributeKey(): void;
        get targetDocumentAttributeKeyInput(): string | undefined;
        private _targetDocumentAttributeValueDeletion?;
        get targetDocumentAttributeValueDeletion(): boolean | cdktn.IResolvable;
        set targetDocumentAttributeValueDeletion(value: boolean | cdktn.IResolvable);
        resetTargetDocumentAttributeValueDeletion(): void;
        get targetDocumentAttributeValueDeletionInput(): boolean | cdktn.IResolvable | undefined;
        private _targetDocumentAttributeValue;
        get targetDocumentAttributeValue(): TargetDocumentAttributeValuePropertyOutputReference;
        putTargetDocumentAttributeValue(value: TargetDocumentAttributeValueProperty): void;
        resetTargetDocumentAttributeValue(): void;
        get targetDocumentAttributeValueInput(): TargetDocumentAttributeValueProperty | undefined;
    }
    interface InlineConfigurationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#document_content_deletion AwsDataSource#document_content_deletion}
        */
        readonly documentContentDeletion?: boolean | cdktn.IResolvable;
        /**
        * condition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#condition AwsDataSource#condition}
        */
        readonly condition?: ConditionProperty;
        /**
        * target block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#target AwsDataSource#target}
        */
        readonly target?: TargetProperty;
    }
    class InlineConfigurationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InlineConfigurationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InlineConfigurationsProperty | cdktn.IResolvable | undefined);
        private _documentContentDeletion?;
        get documentContentDeletion(): boolean | cdktn.IResolvable;
        set documentContentDeletion(value: boolean | cdktn.IResolvable);
        resetDocumentContentDeletion(): void;
        get documentContentDeletionInput(): boolean | cdktn.IResolvable | undefined;
        private _condition;
        get condition(): ConditionPropertyOutputReference;
        putCondition(value: ConditionProperty): void;
        resetCondition(): void;
        get conditionInput(): ConditionProperty | undefined;
        private _target;
        get target(): TargetPropertyOutputReference;
        putTarget(value: TargetProperty): void;
        resetTarget(): void;
        get targetInput(): TargetProperty | undefined;
    }
    class InlineConfigurationsPropertyList extends cdktn.ComplexList {
        internalValue?: InlineConfigurationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InlineConfigurationsPropertyOutputReference;
    }
    interface CustomDocumentEnrichmentConfigurationPostExtractionHookConfigurationInvocationConditionConditionOnValueProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#date_value AwsDataSource#date_value}
        */
        readonly dateValue?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#long_value AwsDataSource#long_value}
        */
        readonly longValue?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#string_list_value AwsDataSource#string_list_value}
        */
        readonly stringListValue?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#string_value AwsDataSource#string_value}
        */
        readonly stringValue?: string;
    }
    class CustomDocumentEnrichmentConfigurationPostExtractionHookConfigurationInvocationConditionConditionOnValuePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CustomDocumentEnrichmentConfigurationPostExtractionHookConfigurationInvocationConditionConditionOnValueProperty | undefined;
        set internalValue(value: CustomDocumentEnrichmentConfigurationPostExtractionHookConfigurationInvocationConditionConditionOnValueProperty | undefined);
        private _dateValue?;
        get dateValue(): string;
        set dateValue(value: string);
        resetDateValue(): void;
        get dateValueInput(): string | undefined;
        private _longValue?;
        get longValue(): number;
        set longValue(value: number);
        resetLongValue(): void;
        get longValueInput(): number | undefined;
        private _stringListValue?;
        get stringListValue(): string[];
        set stringListValue(value: string[]);
        resetStringListValue(): void;
        get stringListValueInput(): string[] | undefined;
        private _stringValue?;
        get stringValue(): string;
        set stringValue(value: string);
        resetStringValue(): void;
        get stringValueInput(): string | undefined;
    }
    interface CustomDocumentEnrichmentConfigurationPostExtractionHookConfigurationInvocationConditionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#condition_document_attribute_key AwsDataSource#condition_document_attribute_key}
        */
        readonly conditionDocumentAttributeKey: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#operator AwsDataSource#operator}
        */
        readonly operator: string;
        /**
        * condition_on_value block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#condition_on_value AwsDataSource#condition_on_value}
        */
        readonly conditionOnValue?: CustomDocumentEnrichmentConfigurationPostExtractionHookConfigurationInvocationConditionConditionOnValueProperty;
    }
    class CustomDocumentEnrichmentConfigurationPostExtractionHookConfigurationInvocationConditionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CustomDocumentEnrichmentConfigurationPostExtractionHookConfigurationInvocationConditionProperty | undefined;
        set internalValue(value: CustomDocumentEnrichmentConfigurationPostExtractionHookConfigurationInvocationConditionProperty | undefined);
        private _conditionDocumentAttributeKey?;
        get conditionDocumentAttributeKey(): string;
        set conditionDocumentAttributeKey(value: string);
        get conditionDocumentAttributeKeyInput(): string | undefined;
        private _operator?;
        get operator(): string;
        set operator(value: string);
        get operatorInput(): string | undefined;
        private _conditionOnValue;
        get conditionOnValue(): CustomDocumentEnrichmentConfigurationPostExtractionHookConfigurationInvocationConditionConditionOnValuePropertyOutputReference;
        putConditionOnValue(value: CustomDocumentEnrichmentConfigurationPostExtractionHookConfigurationInvocationConditionConditionOnValueProperty): void;
        resetConditionOnValue(): void;
        get conditionOnValueInput(): CustomDocumentEnrichmentConfigurationPostExtractionHookConfigurationInvocationConditionConditionOnValueProperty | undefined;
    }
    interface PostExtractionHookConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#lambda_arn AwsDataSource#lambda_arn}
        */
        readonly lambdaArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#s3_bucket AwsDataSource#s3_bucket}
        */
        readonly s3Bucket: string;
        /**
        * invocation_condition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#invocation_condition AwsDataSource#invocation_condition}
        */
        readonly invocationCondition?: CustomDocumentEnrichmentConfigurationPostExtractionHookConfigurationInvocationConditionProperty;
    }
    class PostExtractionHookConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PostExtractionHookConfigurationProperty | undefined;
        set internalValue(value: PostExtractionHookConfigurationProperty | undefined);
        private _lambdaArn?;
        get lambdaArn(): string;
        set lambdaArn(value: string);
        get lambdaArnInput(): string | undefined;
        private _s3Bucket?;
        get s3Bucket(): string;
        set s3Bucket(value: string);
        get s3BucketInput(): string | undefined;
        private _invocationCondition;
        get invocationCondition(): CustomDocumentEnrichmentConfigurationPostExtractionHookConfigurationInvocationConditionPropertyOutputReference;
        putInvocationCondition(value: CustomDocumentEnrichmentConfigurationPostExtractionHookConfigurationInvocationConditionProperty): void;
        resetInvocationCondition(): void;
        get invocationConditionInput(): CustomDocumentEnrichmentConfigurationPostExtractionHookConfigurationInvocationConditionProperty | undefined;
    }
    interface CustomDocumentEnrichmentConfigurationPreExtractionHookConfigurationInvocationConditionConditionOnValueProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#date_value AwsDataSource#date_value}
        */
        readonly dateValue?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#long_value AwsDataSource#long_value}
        */
        readonly longValue?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#string_list_value AwsDataSource#string_list_value}
        */
        readonly stringListValue?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#string_value AwsDataSource#string_value}
        */
        readonly stringValue?: string;
    }
    class CustomDocumentEnrichmentConfigurationPreExtractionHookConfigurationInvocationConditionConditionOnValuePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CustomDocumentEnrichmentConfigurationPreExtractionHookConfigurationInvocationConditionConditionOnValueProperty | undefined;
        set internalValue(value: CustomDocumentEnrichmentConfigurationPreExtractionHookConfigurationInvocationConditionConditionOnValueProperty | undefined);
        private _dateValue?;
        get dateValue(): string;
        set dateValue(value: string);
        resetDateValue(): void;
        get dateValueInput(): string | undefined;
        private _longValue?;
        get longValue(): number;
        set longValue(value: number);
        resetLongValue(): void;
        get longValueInput(): number | undefined;
        private _stringListValue?;
        get stringListValue(): string[];
        set stringListValue(value: string[]);
        resetStringListValue(): void;
        get stringListValueInput(): string[] | undefined;
        private _stringValue?;
        get stringValue(): string;
        set stringValue(value: string);
        resetStringValue(): void;
        get stringValueInput(): string | undefined;
    }
    interface CustomDocumentEnrichmentConfigurationPreExtractionHookConfigurationInvocationConditionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#condition_document_attribute_key AwsDataSource#condition_document_attribute_key}
        */
        readonly conditionDocumentAttributeKey: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#operator AwsDataSource#operator}
        */
        readonly operator: string;
        /**
        * condition_on_value block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#condition_on_value AwsDataSource#condition_on_value}
        */
        readonly conditionOnValue?: CustomDocumentEnrichmentConfigurationPreExtractionHookConfigurationInvocationConditionConditionOnValueProperty;
    }
    class CustomDocumentEnrichmentConfigurationPreExtractionHookConfigurationInvocationConditionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CustomDocumentEnrichmentConfigurationPreExtractionHookConfigurationInvocationConditionProperty | undefined;
        set internalValue(value: CustomDocumentEnrichmentConfigurationPreExtractionHookConfigurationInvocationConditionProperty | undefined);
        private _conditionDocumentAttributeKey?;
        get conditionDocumentAttributeKey(): string;
        set conditionDocumentAttributeKey(value: string);
        get conditionDocumentAttributeKeyInput(): string | undefined;
        private _operator?;
        get operator(): string;
        set operator(value: string);
        get operatorInput(): string | undefined;
        private _conditionOnValue;
        get conditionOnValue(): CustomDocumentEnrichmentConfigurationPreExtractionHookConfigurationInvocationConditionConditionOnValuePropertyOutputReference;
        putConditionOnValue(value: CustomDocumentEnrichmentConfigurationPreExtractionHookConfigurationInvocationConditionConditionOnValueProperty): void;
        resetConditionOnValue(): void;
        get conditionOnValueInput(): CustomDocumentEnrichmentConfigurationPreExtractionHookConfigurationInvocationConditionConditionOnValueProperty | undefined;
    }
    interface PreExtractionHookConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#lambda_arn AwsDataSource#lambda_arn}
        */
        readonly lambdaArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#s3_bucket AwsDataSource#s3_bucket}
        */
        readonly s3Bucket: string;
        /**
        * invocation_condition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#invocation_condition AwsDataSource#invocation_condition}
        */
        readonly invocationCondition?: CustomDocumentEnrichmentConfigurationPreExtractionHookConfigurationInvocationConditionProperty;
    }
    class PreExtractionHookConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PreExtractionHookConfigurationProperty | undefined;
        set internalValue(value: PreExtractionHookConfigurationProperty | undefined);
        private _lambdaArn?;
        get lambdaArn(): string;
        set lambdaArn(value: string);
        get lambdaArnInput(): string | undefined;
        private _s3Bucket?;
        get s3Bucket(): string;
        set s3Bucket(value: string);
        get s3BucketInput(): string | undefined;
        private _invocationCondition;
        get invocationCondition(): CustomDocumentEnrichmentConfigurationPreExtractionHookConfigurationInvocationConditionPropertyOutputReference;
        putInvocationCondition(value: CustomDocumentEnrichmentConfigurationPreExtractionHookConfigurationInvocationConditionProperty): void;
        resetInvocationCondition(): void;
        get invocationConditionInput(): CustomDocumentEnrichmentConfigurationPreExtractionHookConfigurationInvocationConditionProperty | undefined;
    }
    interface CustomDocumentEnrichmentConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#role_arn AwsDataSource#role_arn}
        */
        readonly roleArn?: string;
        /**
        * inline_configurations block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#inline_configurations AwsDataSource#inline_configurations}
        */
        readonly inlineConfigurations?: InlineConfigurationsProperty[] | cdktn.IResolvable;
        /**
        * post_extraction_hook_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#post_extraction_hook_configuration AwsDataSource#post_extraction_hook_configuration}
        */
        readonly postExtractionHookConfiguration?: PostExtractionHookConfigurationProperty;
        /**
        * pre_extraction_hook_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#pre_extraction_hook_configuration AwsDataSource#pre_extraction_hook_configuration}
        */
        readonly preExtractionHookConfiguration?: PreExtractionHookConfigurationProperty;
    }
    class CustomDocumentEnrichmentConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CustomDocumentEnrichmentConfigurationProperty | undefined;
        set internalValue(value: CustomDocumentEnrichmentConfigurationProperty | undefined);
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        resetRoleArn(): void;
        get roleArnInput(): string | undefined;
        private _inlineConfigurations;
        get inlineConfigurations(): InlineConfigurationsPropertyList;
        putInlineConfigurations(value: InlineConfigurationsProperty[] | cdktn.IResolvable): void;
        resetInlineConfigurations(): void;
        get inlineConfigurationsInput(): cdktn.IResolvable | InlineConfigurationsProperty[] | undefined;
        private _postExtractionHookConfiguration;
        get postExtractionHookConfiguration(): PostExtractionHookConfigurationPropertyOutputReference;
        putPostExtractionHookConfiguration(value: PostExtractionHookConfigurationProperty): void;
        resetPostExtractionHookConfiguration(): void;
        get postExtractionHookConfigurationInput(): PostExtractionHookConfigurationProperty | undefined;
        private _preExtractionHookConfiguration;
        get preExtractionHookConfiguration(): PreExtractionHookConfigurationPropertyOutputReference;
        putPreExtractionHookConfiguration(value: PreExtractionHookConfigurationProperty): void;
        resetPreExtractionHookConfiguration(): void;
        get preExtractionHookConfigurationInput(): PreExtractionHookConfigurationProperty | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#create AwsDataSource#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#delete AwsDataSource#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kendra_data_source#update AwsDataSource#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
