import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsProjectConfig extends cdktn.TerraformMetaArguments {
    /**
    * Maximum number of additional automatic retries after a failed build. The default value is 0.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#auto_retry_limit AwsProject#auto_retry_limit}
    */
    readonly autoRetryLimit?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#badge_enabled AwsProject#badge_enabled}
    */
    readonly badgeEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#build_timeout AwsProject#build_timeout}
    */
    readonly buildTimeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#concurrent_build_limit AwsProject#concurrent_build_limit}
    */
    readonly concurrentBuildLimit?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#description AwsProject#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#encryption_key AwsProject#encryption_key}
    */
    readonly encryptionKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#id AwsProject#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#name AwsProject#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#project_visibility AwsProject#project_visibility}
    */
    readonly projectVisibility?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#queued_timeout AwsProject#queued_timeout}
    */
    readonly queuedTimeout?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#region AwsProject#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#resource_access_role AwsProject#resource_access_role}
    */
    readonly resourceAccessRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#service_role AwsProject#service_role}
    */
    readonly serviceRole: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#source_version AwsProject#source_version}
    */
    readonly sourceVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#tags AwsProject#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#tags_all AwsProject#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * artifacts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#artifacts AwsProject#artifacts}
    */
    readonly artifacts: AwsProject.ArtifactsProperty;
    /**
    * build_batch_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#build_batch_config AwsProject#build_batch_config}
    */
    readonly buildBatchConfig?: AwsProject.BuildBatchConfigProperty;
    /**
    * cache block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#cache AwsProject#cache}
    */
    readonly cache?: AwsProject.CacheProperty;
    /**
    * environment block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#environment AwsProject#environment}
    */
    readonly environment: AwsProject.EnvironmentProperty;
    /**
    * file_system_locations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#file_system_locations AwsProject#file_system_locations}
    */
    readonly fileSystemLocations?: AwsProject.FileSystemLocationsProperty[] | cdktn.IResolvable;
    /**
    * logs_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#logs_config AwsProject#logs_config}
    */
    readonly logsConfig?: AwsProject.LogsConfigProperty;
    /**
    * secondary_artifacts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#secondary_artifacts AwsProject#secondary_artifacts}
    */
    readonly secondaryArtifacts?: AwsProject.SecondaryArtifactsProperty[] | cdktn.IResolvable;
    /**
    * secondary_source_version block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#secondary_source_version AwsProject#secondary_source_version}
    */
    readonly secondarySourceVersion?: AwsProject.SecondarySourceVersionProperty[] | cdktn.IResolvable;
    /**
    * secondary_sources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#secondary_sources AwsProject#secondary_sources}
    */
    readonly secondarySources?: AwsProject.SecondarySourcesProperty[] | cdktn.IResolvable;
    /**
    * source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#source AwsProject#source}
    */
    readonly source: AwsProject.SourceProperty;
    /**
    * vpc_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#vpc_config AwsProject#vpc_config}
    */
    readonly vpcConfig?: AwsProject.VpcConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project aws_codebuild_project}
*/
export declare class AwsProject extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_codebuild_project";
    /**
    * Generates CDKTN code for importing a AwsProject resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsProject to import
    * @param importFromId The id of the existing AwsProject that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsProject to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project aws_codebuild_project} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsProjectConfig
    */
    constructor(scope: Construct, id: string, config: AwsProjectConfig);
    get arn(): string;
    private _autoRetryLimit?;
    get autoRetryLimit(): number;
    set autoRetryLimit(value: number);
    resetAutoRetryLimit(): void;
    get autoRetryLimitInput(): number | undefined;
    private _badgeEnabled?;
    get badgeEnabled(): boolean | cdktn.IResolvable;
    set badgeEnabled(value: boolean | cdktn.IResolvable);
    resetBadgeEnabled(): void;
    get badgeEnabledInput(): boolean | cdktn.IResolvable | undefined;
    get badgeUrl(): string;
    private _buildTimeout?;
    get buildTimeout(): number;
    set buildTimeout(value: number);
    resetBuildTimeout(): void;
    get buildTimeoutInput(): number | undefined;
    private _concurrentBuildLimit?;
    get concurrentBuildLimit(): number;
    set concurrentBuildLimit(value: number);
    resetConcurrentBuildLimit(): void;
    get concurrentBuildLimitInput(): number | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _encryptionKey?;
    get encryptionKey(): string;
    set encryptionKey(value: string);
    resetEncryptionKey(): void;
    get encryptionKeyInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectVisibility?;
    get projectVisibility(): string;
    set projectVisibility(value: string);
    resetProjectVisibility(): void;
    get projectVisibilityInput(): string | undefined;
    get publicProjectAlias(): string;
    private _queuedTimeout?;
    get queuedTimeout(): number;
    set queuedTimeout(value: number);
    resetQueuedTimeout(): void;
    get queuedTimeoutInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourceAccessRole?;
    get resourceAccessRole(): string;
    set resourceAccessRole(value: string);
    resetResourceAccessRole(): void;
    get resourceAccessRoleInput(): string | undefined;
    private _serviceRole?;
    get serviceRole(): string;
    set serviceRole(value: string);
    get serviceRoleInput(): string | undefined;
    private _sourceVersion?;
    get sourceVersion(): string;
    set sourceVersion(value: string);
    resetSourceVersion(): void;
    get sourceVersionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _artifacts;
    get artifacts(): AwsProject.ArtifactsPropertyOutputReference;
    putArtifacts(value: AwsProject.ArtifactsProperty): void;
    get artifactsInput(): AwsProject.ArtifactsProperty | undefined;
    private _buildBatchConfig;
    get buildBatchConfig(): AwsProject.BuildBatchConfigPropertyOutputReference;
    putBuildBatchConfig(value: AwsProject.BuildBatchConfigProperty): void;
    resetBuildBatchConfig(): void;
    get buildBatchConfigInput(): AwsProject.BuildBatchConfigProperty | undefined;
    private _cache;
    get cache(): AwsProject.CachePropertyOutputReference;
    putCache(value: AwsProject.CacheProperty): void;
    resetCache(): void;
    get cacheInput(): AwsProject.CacheProperty | undefined;
    private _environment;
    get environment(): AwsProject.EnvironmentPropertyOutputReference;
    putEnvironment(value: AwsProject.EnvironmentProperty): void;
    get environmentInput(): AwsProject.EnvironmentProperty | undefined;
    private _fileSystemLocations;
    get fileSystemLocations(): AwsProject.FileSystemLocationsPropertyList;
    putFileSystemLocations(value: AwsProject.FileSystemLocationsProperty[] | cdktn.IResolvable): void;
    resetFileSystemLocations(): void;
    get fileSystemLocationsInput(): cdktn.IResolvable | AwsProject.FileSystemLocationsProperty[] | undefined;
    private _logsConfig;
    get logsConfig(): AwsProject.LogsConfigPropertyOutputReference;
    putLogsConfig(value: AwsProject.LogsConfigProperty): void;
    resetLogsConfig(): void;
    get logsConfigInput(): AwsProject.LogsConfigProperty | undefined;
    private _secondaryArtifacts;
    get secondaryArtifacts(): AwsProject.SecondaryArtifactsPropertyList;
    putSecondaryArtifacts(value: AwsProject.SecondaryArtifactsProperty[] | cdktn.IResolvable): void;
    resetSecondaryArtifacts(): void;
    get secondaryArtifactsInput(): cdktn.IResolvable | AwsProject.SecondaryArtifactsProperty[] | undefined;
    private _secondarySourceVersion;
    get secondarySourceVersion(): AwsProject.SecondarySourceVersionPropertyList;
    putSecondarySourceVersion(value: AwsProject.SecondarySourceVersionProperty[] | cdktn.IResolvable): void;
    resetSecondarySourceVersion(): void;
    get secondarySourceVersionInput(): cdktn.IResolvable | AwsProject.SecondarySourceVersionProperty[] | undefined;
    private _secondarySources;
    get secondarySources(): AwsProject.SecondarySourcesPropertyList;
    putSecondarySources(value: AwsProject.SecondarySourcesProperty[] | cdktn.IResolvable): void;
    resetSecondarySources(): void;
    get secondarySourcesInput(): cdktn.IResolvable | AwsProject.SecondarySourcesProperty[] | undefined;
    private _source;
    get source(): AwsProject.SourcePropertyOutputReference;
    putSource(value: AwsProject.SourceProperty): void;
    get sourceInput(): AwsProject.SourceProperty | undefined;
    private _vpcConfig;
    get vpcConfig(): AwsProject.VpcConfigPropertyOutputReference;
    putVpcConfig(value: AwsProject.VpcConfigProperty): void;
    resetVpcConfig(): void;
    get vpcConfigInput(): AwsProject.VpcConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsProjectArtifactsPropertyToTerraform(struct?: AwsProject.ArtifactsPropertyOutputReference | AwsProject.ArtifactsProperty): any;
export declare function awsProjectArtifactsPropertyToHclTerraform(struct?: AwsProject.ArtifactsPropertyOutputReference | AwsProject.ArtifactsProperty): any;
export declare function awsProjectRestrictionsPropertyToTerraform(struct?: AwsProject.RestrictionsPropertyOutputReference | AwsProject.RestrictionsProperty): any;
export declare function awsProjectRestrictionsPropertyToHclTerraform(struct?: AwsProject.RestrictionsPropertyOutputReference | AwsProject.RestrictionsProperty): any;
export declare function awsProjectBuildBatchConfigPropertyToTerraform(struct?: AwsProject.BuildBatchConfigPropertyOutputReference | AwsProject.BuildBatchConfigProperty): any;
export declare function awsProjectBuildBatchConfigPropertyToHclTerraform(struct?: AwsProject.BuildBatchConfigPropertyOutputReference | AwsProject.BuildBatchConfigProperty): any;
export declare function awsProjectCachePropertyToTerraform(struct?: AwsProject.CachePropertyOutputReference | AwsProject.CacheProperty): any;
export declare function awsProjectCachePropertyToHclTerraform(struct?: AwsProject.CachePropertyOutputReference | AwsProject.CacheProperty): any;
export declare function awsProjectDockerServerPropertyToTerraform(struct?: AwsProject.DockerServerPropertyOutputReference | AwsProject.DockerServerProperty): any;
export declare function awsProjectDockerServerPropertyToHclTerraform(struct?: AwsProject.DockerServerPropertyOutputReference | AwsProject.DockerServerProperty): any;
export declare function awsProjectEnvironmentVariablePropertyToTerraform(struct?: AwsProject.EnvironmentVariableProperty | cdktn.IResolvable): any;
export declare function awsProjectEnvironmentVariablePropertyToHclTerraform(struct?: AwsProject.EnvironmentVariableProperty | cdktn.IResolvable): any;
export declare function awsProjectFleetPropertyToTerraform(struct?: AwsProject.FleetPropertyOutputReference | AwsProject.FleetProperty): any;
export declare function awsProjectFleetPropertyToHclTerraform(struct?: AwsProject.FleetPropertyOutputReference | AwsProject.FleetProperty): any;
export declare function awsProjectRegistryCredentialPropertyToTerraform(struct?: AwsProject.RegistryCredentialPropertyOutputReference | AwsProject.RegistryCredentialProperty): any;
export declare function awsProjectRegistryCredentialPropertyToHclTerraform(struct?: AwsProject.RegistryCredentialPropertyOutputReference | AwsProject.RegistryCredentialProperty): any;
export declare function awsProjectEnvironmentPropertyToTerraform(struct?: AwsProject.EnvironmentPropertyOutputReference | AwsProject.EnvironmentProperty): any;
export declare function awsProjectEnvironmentPropertyToHclTerraform(struct?: AwsProject.EnvironmentPropertyOutputReference | AwsProject.EnvironmentProperty): any;
export declare function awsProjectFileSystemLocationsPropertyToTerraform(struct?: AwsProject.FileSystemLocationsProperty | cdktn.IResolvable): any;
export declare function awsProjectFileSystemLocationsPropertyToHclTerraform(struct?: AwsProject.FileSystemLocationsProperty | cdktn.IResolvable): any;
export declare function awsProjectCloudwatchLogsPropertyToTerraform(struct?: AwsProject.CloudwatchLogsPropertyOutputReference | AwsProject.CloudwatchLogsProperty): any;
export declare function awsProjectCloudwatchLogsPropertyToHclTerraform(struct?: AwsProject.CloudwatchLogsPropertyOutputReference | AwsProject.CloudwatchLogsProperty): any;
export declare function awsProjectS3LogsPropertyToTerraform(struct?: AwsProject.S3LogsPropertyOutputReference | AwsProject.S3LogsProperty): any;
export declare function awsProjectS3LogsPropertyToHclTerraform(struct?: AwsProject.S3LogsPropertyOutputReference | AwsProject.S3LogsProperty): any;
export declare function awsProjectLogsConfigPropertyToTerraform(struct?: AwsProject.LogsConfigPropertyOutputReference | AwsProject.LogsConfigProperty): any;
export declare function awsProjectLogsConfigPropertyToHclTerraform(struct?: AwsProject.LogsConfigPropertyOutputReference | AwsProject.LogsConfigProperty): any;
export declare function awsProjectSecondaryArtifactsPropertyToTerraform(struct?: AwsProject.SecondaryArtifactsProperty | cdktn.IResolvable): any;
export declare function awsProjectSecondaryArtifactsPropertyToHclTerraform(struct?: AwsProject.SecondaryArtifactsProperty | cdktn.IResolvable): any;
export declare function awsProjectSecondarySourceVersionPropertyToTerraform(struct?: AwsProject.SecondarySourceVersionProperty | cdktn.IResolvable): any;
export declare function awsProjectSecondarySourceVersionPropertyToHclTerraform(struct?: AwsProject.SecondarySourceVersionProperty | cdktn.IResolvable): any;
export declare function awsProjectSecondarySourcesAuthPropertyToTerraform(struct?: AwsProject.SecondarySourcesAuthPropertyOutputReference | AwsProject.SecondarySourcesAuthProperty): any;
export declare function awsProjectSecondarySourcesAuthPropertyToHclTerraform(struct?: AwsProject.SecondarySourcesAuthPropertyOutputReference | AwsProject.SecondarySourcesAuthProperty): any;
export declare function awsProjectSecondarySourcesBuildStatusConfigPropertyToTerraform(struct?: AwsProject.SecondarySourcesBuildStatusConfigPropertyOutputReference | AwsProject.SecondarySourcesBuildStatusConfigProperty): any;
export declare function awsProjectSecondarySourcesBuildStatusConfigPropertyToHclTerraform(struct?: AwsProject.SecondarySourcesBuildStatusConfigPropertyOutputReference | AwsProject.SecondarySourcesBuildStatusConfigProperty): any;
export declare function awsProjectSecondarySourcesGitSubmodulesConfigPropertyToTerraform(struct?: AwsProject.SecondarySourcesGitSubmodulesConfigPropertyOutputReference | AwsProject.SecondarySourcesGitSubmodulesConfigProperty): any;
export declare function awsProjectSecondarySourcesGitSubmodulesConfigPropertyToHclTerraform(struct?: AwsProject.SecondarySourcesGitSubmodulesConfigPropertyOutputReference | AwsProject.SecondarySourcesGitSubmodulesConfigProperty): any;
export declare function awsProjectSecondarySourcesPropertyToTerraform(struct?: AwsProject.SecondarySourcesProperty | cdktn.IResolvable): any;
export declare function awsProjectSecondarySourcesPropertyToHclTerraform(struct?: AwsProject.SecondarySourcesProperty | cdktn.IResolvable): any;
export declare function awsProjectSourceAuthPropertyToTerraform(struct?: AwsProject.SourceAuthPropertyOutputReference | AwsProject.SourceAuthProperty): any;
export declare function awsProjectSourceAuthPropertyToHclTerraform(struct?: AwsProject.SourceAuthPropertyOutputReference | AwsProject.SourceAuthProperty): any;
export declare function awsProjectSourceBuildStatusConfigPropertyToTerraform(struct?: AwsProject.SourceBuildStatusConfigPropertyOutputReference | AwsProject.SourceBuildStatusConfigProperty): any;
export declare function awsProjectSourceBuildStatusConfigPropertyToHclTerraform(struct?: AwsProject.SourceBuildStatusConfigPropertyOutputReference | AwsProject.SourceBuildStatusConfigProperty): any;
export declare function awsProjectSourceGitSubmodulesConfigPropertyToTerraform(struct?: AwsProject.SourceGitSubmodulesConfigPropertyOutputReference | AwsProject.SourceGitSubmodulesConfigProperty): any;
export declare function awsProjectSourceGitSubmodulesConfigPropertyToHclTerraform(struct?: AwsProject.SourceGitSubmodulesConfigPropertyOutputReference | AwsProject.SourceGitSubmodulesConfigProperty): any;
export declare function awsProjectSourcePropertyToTerraform(struct?: AwsProject.SourcePropertyOutputReference | AwsProject.SourceProperty): any;
export declare function awsProjectSourcePropertyToHclTerraform(struct?: AwsProject.SourcePropertyOutputReference | AwsProject.SourceProperty): any;
export declare function awsProjectVpcConfigPropertyToTerraform(struct?: AwsProject.VpcConfigPropertyOutputReference | AwsProject.VpcConfigProperty): any;
export declare function awsProjectVpcConfigPropertyToHclTerraform(struct?: AwsProject.VpcConfigPropertyOutputReference | AwsProject.VpcConfigProperty): any;
export declare namespace AwsProject {
    interface ArtifactsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#artifact_identifier AwsProject#artifact_identifier}
        */
        readonly artifactIdentifier?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#bucket_owner_access AwsProject#bucket_owner_access}
        */
        readonly bucketOwnerAccess?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#encryption_disabled AwsProject#encryption_disabled}
        */
        readonly encryptionDisabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#location AwsProject#location}
        */
        readonly location?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#name AwsProject#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#namespace_type AwsProject#namespace_type}
        */
        readonly namespaceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#override_artifact_name AwsProject#override_artifact_name}
        */
        readonly overrideArtifactName?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#packaging AwsProject#packaging}
        */
        readonly packaging?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#path AwsProject#path}
        */
        readonly path?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#type AwsProject#type}
        */
        readonly type: string;
    }
    class ArtifactsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ArtifactsProperty | undefined;
        set internalValue(value: ArtifactsProperty | undefined);
        private _artifactIdentifier?;
        get artifactIdentifier(): string;
        set artifactIdentifier(value: string);
        resetArtifactIdentifier(): void;
        get artifactIdentifierInput(): string | undefined;
        private _bucketOwnerAccess?;
        get bucketOwnerAccess(): string;
        set bucketOwnerAccess(value: string);
        resetBucketOwnerAccess(): void;
        get bucketOwnerAccessInput(): string | undefined;
        private _encryptionDisabled?;
        get encryptionDisabled(): boolean | cdktn.IResolvable;
        set encryptionDisabled(value: boolean | cdktn.IResolvable);
        resetEncryptionDisabled(): void;
        get encryptionDisabledInput(): boolean | cdktn.IResolvable | undefined;
        private _location?;
        get location(): string;
        set location(value: string);
        resetLocation(): void;
        get locationInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _namespaceType?;
        get namespaceType(): string;
        set namespaceType(value: string);
        resetNamespaceType(): void;
        get namespaceTypeInput(): string | undefined;
        private _overrideArtifactName?;
        get overrideArtifactName(): boolean | cdktn.IResolvable;
        set overrideArtifactName(value: boolean | cdktn.IResolvable);
        resetOverrideArtifactName(): void;
        get overrideArtifactNameInput(): boolean | cdktn.IResolvable | undefined;
        private _packaging?;
        get packaging(): string;
        set packaging(value: string);
        resetPackaging(): void;
        get packagingInput(): string | undefined;
        private _path?;
        get path(): string;
        set path(value: string);
        resetPath(): void;
        get pathInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    interface RestrictionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#compute_types_allowed AwsProject#compute_types_allowed}
        */
        readonly computeTypesAllowed?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#maximum_builds_allowed AwsProject#maximum_builds_allowed}
        */
        readonly maximumBuildsAllowed?: number;
    }
    class RestrictionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RestrictionsProperty | undefined;
        set internalValue(value: RestrictionsProperty | undefined);
        private _computeTypesAllowed?;
        get computeTypesAllowed(): string[];
        set computeTypesAllowed(value: string[]);
        resetComputeTypesAllowed(): void;
        get computeTypesAllowedInput(): string[] | undefined;
        private _maximumBuildsAllowed?;
        get maximumBuildsAllowed(): number;
        set maximumBuildsAllowed(value: number);
        resetMaximumBuildsAllowed(): void;
        get maximumBuildsAllowedInput(): number | undefined;
    }
    interface BuildBatchConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#combine_artifacts AwsProject#combine_artifacts}
        */
        readonly combineArtifacts?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#service_role AwsProject#service_role}
        */
        readonly serviceRole: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#timeout_in_mins AwsProject#timeout_in_mins}
        */
        readonly timeoutInMins?: number;
        /**
        * restrictions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#restrictions AwsProject#restrictions}
        */
        readonly restrictions?: RestrictionsProperty;
    }
    class BuildBatchConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BuildBatchConfigProperty | undefined;
        set internalValue(value: BuildBatchConfigProperty | undefined);
        private _combineArtifacts?;
        get combineArtifacts(): boolean | cdktn.IResolvable;
        set combineArtifacts(value: boolean | cdktn.IResolvable);
        resetCombineArtifacts(): void;
        get combineArtifactsInput(): boolean | cdktn.IResolvable | undefined;
        private _serviceRole?;
        get serviceRole(): string;
        set serviceRole(value: string);
        get serviceRoleInput(): string | undefined;
        private _timeoutInMins?;
        get timeoutInMins(): number;
        set timeoutInMins(value: number);
        resetTimeoutInMins(): void;
        get timeoutInMinsInput(): number | undefined;
        private _restrictions;
        get restrictions(): RestrictionsPropertyOutputReference;
        putRestrictions(value: RestrictionsProperty): void;
        resetRestrictions(): void;
        get restrictionsInput(): RestrictionsProperty | undefined;
    }
    interface CacheProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#cache_namespace AwsProject#cache_namespace}
        */
        readonly cacheNamespace?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#location AwsProject#location}
        */
        readonly location?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#modes AwsProject#modes}
        */
        readonly modes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#type AwsProject#type}
        */
        readonly type?: string;
    }
    class CachePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CacheProperty | undefined;
        set internalValue(value: CacheProperty | undefined);
        private _cacheNamespace?;
        get cacheNamespace(): string;
        set cacheNamespace(value: string);
        resetCacheNamespace(): void;
        get cacheNamespaceInput(): string | undefined;
        private _location?;
        get location(): string;
        set location(value: string);
        resetLocation(): void;
        get locationInput(): string | undefined;
        private _modes?;
        get modes(): string[];
        set modes(value: string[]);
        resetModes(): void;
        get modesInput(): string[] | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
    }
    interface DockerServerProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#compute_type AwsProject#compute_type}
        */
        readonly computeType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#security_group_ids AwsProject#security_group_ids}
        */
        readonly securityGroupIds?: string[];
    }
    class DockerServerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DockerServerProperty | undefined;
        set internalValue(value: DockerServerProperty | undefined);
        private _computeType?;
        get computeType(): string;
        set computeType(value: string);
        get computeTypeInput(): string | undefined;
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        resetSecurityGroupIds(): void;
        get securityGroupIdsInput(): string[] | undefined;
    }
    interface EnvironmentVariableProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#name AwsProject#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#type AwsProject#type}
        */
        readonly type?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#value AwsProject#value}
        */
        readonly value: string;
    }
    class EnvironmentVariablePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EnvironmentVariableProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EnvironmentVariableProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class EnvironmentVariablePropertyList extends cdktn.ComplexList {
        internalValue?: EnvironmentVariableProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EnvironmentVariablePropertyOutputReference;
    }
    interface FleetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#fleet_arn AwsProject#fleet_arn}
        */
        readonly fleetArn?: string;
    }
    class FleetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FleetProperty | undefined;
        set internalValue(value: FleetProperty | undefined);
        private _fleetArn?;
        get fleetArn(): string;
        set fleetArn(value: string);
        resetFleetArn(): void;
        get fleetArnInput(): string | undefined;
    }
    interface RegistryCredentialProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#credential AwsProject#credential}
        */
        readonly credential: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#credential_provider AwsProject#credential_provider}
        */
        readonly credentialProvider: string;
    }
    class RegistryCredentialPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RegistryCredentialProperty | undefined;
        set internalValue(value: RegistryCredentialProperty | undefined);
        private _credential?;
        get credential(): string;
        set credential(value: string);
        get credentialInput(): string | undefined;
        private _credentialProvider?;
        get credentialProvider(): string;
        set credentialProvider(value: string);
        get credentialProviderInput(): string | undefined;
    }
    interface EnvironmentProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#certificate AwsProject#certificate}
        */
        readonly certificate?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#compute_type AwsProject#compute_type}
        */
        readonly computeType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#host_kernel AwsProject#host_kernel}
        */
        readonly hostKernel?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#image AwsProject#image}
        */
        readonly image: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#image_pull_credentials_type AwsProject#image_pull_credentials_type}
        */
        readonly imagePullCredentialsType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#privileged_mode AwsProject#privileged_mode}
        */
        readonly privilegedMode?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#type AwsProject#type}
        */
        readonly type: string;
        /**
        * docker_server block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#docker_server AwsProject#docker_server}
        */
        readonly dockerServer?: DockerServerProperty;
        /**
        * environment_variable block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#environment_variable AwsProject#environment_variable}
        */
        readonly environmentVariable?: EnvironmentVariableProperty[] | cdktn.IResolvable;
        /**
        * fleet block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#fleet AwsProject#fleet}
        */
        readonly fleet?: FleetProperty;
        /**
        * registry_credential block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#registry_credential AwsProject#registry_credential}
        */
        readonly registryCredential?: RegistryCredentialProperty;
    }
    class EnvironmentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EnvironmentProperty | undefined;
        set internalValue(value: EnvironmentProperty | undefined);
        private _certificate?;
        get certificate(): string;
        set certificate(value: string);
        resetCertificate(): void;
        get certificateInput(): string | undefined;
        private _computeType?;
        get computeType(): string;
        set computeType(value: string);
        get computeTypeInput(): string | undefined;
        private _hostKernel?;
        get hostKernel(): string;
        set hostKernel(value: string);
        resetHostKernel(): void;
        get hostKernelInput(): string | undefined;
        private _image?;
        get image(): string;
        set image(value: string);
        get imageInput(): string | undefined;
        private _imagePullCredentialsType?;
        get imagePullCredentialsType(): string;
        set imagePullCredentialsType(value: string);
        resetImagePullCredentialsType(): void;
        get imagePullCredentialsTypeInput(): string | undefined;
        private _privilegedMode?;
        get privilegedMode(): boolean | cdktn.IResolvable;
        set privilegedMode(value: boolean | cdktn.IResolvable);
        resetPrivilegedMode(): void;
        get privilegedModeInput(): boolean | cdktn.IResolvable | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _dockerServer;
        get dockerServer(): DockerServerPropertyOutputReference;
        putDockerServer(value: DockerServerProperty): void;
        resetDockerServer(): void;
        get dockerServerInput(): DockerServerProperty | undefined;
        private _environmentVariable;
        get environmentVariable(): EnvironmentVariablePropertyList;
        putEnvironmentVariable(value: EnvironmentVariableProperty[] | cdktn.IResolvable): void;
        resetEnvironmentVariable(): void;
        get environmentVariableInput(): cdktn.IResolvable | EnvironmentVariableProperty[] | undefined;
        private _fleet;
        get fleet(): FleetPropertyOutputReference;
        putFleet(value: FleetProperty): void;
        resetFleet(): void;
        get fleetInput(): FleetProperty | undefined;
        private _registryCredential;
        get registryCredential(): RegistryCredentialPropertyOutputReference;
        putRegistryCredential(value: RegistryCredentialProperty): void;
        resetRegistryCredential(): void;
        get registryCredentialInput(): RegistryCredentialProperty | undefined;
    }
    interface FileSystemLocationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#identifier AwsProject#identifier}
        */
        readonly identifier?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#location AwsProject#location}
        */
        readonly location?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#mount_options AwsProject#mount_options}
        */
        readonly mountOptions?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#mount_point AwsProject#mount_point}
        */
        readonly mountPoint?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#type AwsProject#type}
        */
        readonly type?: string;
    }
    class FileSystemLocationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FileSystemLocationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FileSystemLocationsProperty | cdktn.IResolvable | undefined);
        private _identifier?;
        get identifier(): string;
        set identifier(value: string);
        resetIdentifier(): void;
        get identifierInput(): string | undefined;
        private _location?;
        get location(): string;
        set location(value: string);
        resetLocation(): void;
        get locationInput(): string | undefined;
        private _mountOptions?;
        get mountOptions(): string;
        set mountOptions(value: string);
        resetMountOptions(): void;
        get mountOptionsInput(): string | undefined;
        private _mountPoint?;
        get mountPoint(): string;
        set mountPoint(value: string);
        resetMountPoint(): void;
        get mountPointInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
    }
    class FileSystemLocationsPropertyList extends cdktn.ComplexList {
        internalValue?: FileSystemLocationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FileSystemLocationsPropertyOutputReference;
    }
    interface CloudwatchLogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#group_name AwsProject#group_name}
        */
        readonly groupName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#status AwsProject#status}
        */
        readonly status?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#stream_name AwsProject#stream_name}
        */
        readonly streamName?: string;
    }
    class CloudwatchLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CloudwatchLogsProperty | undefined;
        set internalValue(value: CloudwatchLogsProperty | undefined);
        private _groupName?;
        get groupName(): string;
        set groupName(value: string);
        resetGroupName(): void;
        get groupNameInput(): string | undefined;
        private _status?;
        get status(): string;
        set status(value: string);
        resetStatus(): void;
        get statusInput(): string | undefined;
        private _streamName?;
        get streamName(): string;
        set streamName(value: string);
        resetStreamName(): void;
        get streamNameInput(): string | undefined;
    }
    interface S3LogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#bucket_owner_access AwsProject#bucket_owner_access}
        */
        readonly bucketOwnerAccess?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#encryption_disabled AwsProject#encryption_disabled}
        */
        readonly encryptionDisabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#location AwsProject#location}
        */
        readonly location?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#status AwsProject#status}
        */
        readonly status?: string;
    }
    class S3LogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3LogsProperty | undefined;
        set internalValue(value: S3LogsProperty | undefined);
        private _bucketOwnerAccess?;
        get bucketOwnerAccess(): string;
        set bucketOwnerAccess(value: string);
        resetBucketOwnerAccess(): void;
        get bucketOwnerAccessInput(): string | undefined;
        private _encryptionDisabled?;
        get encryptionDisabled(): boolean | cdktn.IResolvable;
        set encryptionDisabled(value: boolean | cdktn.IResolvable);
        resetEncryptionDisabled(): void;
        get encryptionDisabledInput(): boolean | cdktn.IResolvable | undefined;
        private _location?;
        get location(): string;
        set location(value: string);
        resetLocation(): void;
        get locationInput(): string | undefined;
        private _status?;
        get status(): string;
        set status(value: string);
        resetStatus(): void;
        get statusInput(): string | undefined;
    }
    interface LogsConfigProperty {
        /**
        * cloudwatch_logs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#cloudwatch_logs AwsProject#cloudwatch_logs}
        */
        readonly cloudwatchLogs?: CloudwatchLogsProperty;
        /**
        * s3_logs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#s3_logs AwsProject#s3_logs}
        */
        readonly s3Logs?: S3LogsProperty;
    }
    class LogsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LogsConfigProperty | undefined;
        set internalValue(value: LogsConfigProperty | undefined);
        private _cloudwatchLogs;
        get cloudwatchLogs(): CloudwatchLogsPropertyOutputReference;
        putCloudwatchLogs(value: CloudwatchLogsProperty): void;
        resetCloudwatchLogs(): void;
        get cloudwatchLogsInput(): CloudwatchLogsProperty | undefined;
        private _s3Logs;
        get s3Logs(): S3LogsPropertyOutputReference;
        putS3Logs(value: S3LogsProperty): void;
        resetS3Logs(): void;
        get s3LogsInput(): S3LogsProperty | undefined;
    }
    interface SecondaryArtifactsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#artifact_identifier AwsProject#artifact_identifier}
        */
        readonly artifactIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#bucket_owner_access AwsProject#bucket_owner_access}
        */
        readonly bucketOwnerAccess?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#encryption_disabled AwsProject#encryption_disabled}
        */
        readonly encryptionDisabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#location AwsProject#location}
        */
        readonly location?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#name AwsProject#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#namespace_type AwsProject#namespace_type}
        */
        readonly namespaceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#override_artifact_name AwsProject#override_artifact_name}
        */
        readonly overrideArtifactName?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#packaging AwsProject#packaging}
        */
        readonly packaging?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#path AwsProject#path}
        */
        readonly path?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#type AwsProject#type}
        */
        readonly type: string;
    }
    class SecondaryArtifactsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SecondaryArtifactsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SecondaryArtifactsProperty | cdktn.IResolvable | undefined);
        private _artifactIdentifier?;
        get artifactIdentifier(): string;
        set artifactIdentifier(value: string);
        get artifactIdentifierInput(): string | undefined;
        private _bucketOwnerAccess?;
        get bucketOwnerAccess(): string;
        set bucketOwnerAccess(value: string);
        resetBucketOwnerAccess(): void;
        get bucketOwnerAccessInput(): string | undefined;
        private _encryptionDisabled?;
        get encryptionDisabled(): boolean | cdktn.IResolvable;
        set encryptionDisabled(value: boolean | cdktn.IResolvable);
        resetEncryptionDisabled(): void;
        get encryptionDisabledInput(): boolean | cdktn.IResolvable | undefined;
        private _location?;
        get location(): string;
        set location(value: string);
        resetLocation(): void;
        get locationInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _namespaceType?;
        get namespaceType(): string;
        set namespaceType(value: string);
        resetNamespaceType(): void;
        get namespaceTypeInput(): string | undefined;
        private _overrideArtifactName?;
        get overrideArtifactName(): boolean | cdktn.IResolvable;
        set overrideArtifactName(value: boolean | cdktn.IResolvable);
        resetOverrideArtifactName(): void;
        get overrideArtifactNameInput(): boolean | cdktn.IResolvable | undefined;
        private _packaging?;
        get packaging(): string;
        set packaging(value: string);
        resetPackaging(): void;
        get packagingInput(): string | undefined;
        private _path?;
        get path(): string;
        set path(value: string);
        resetPath(): void;
        get pathInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class SecondaryArtifactsPropertyList extends cdktn.ComplexList {
        internalValue?: SecondaryArtifactsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SecondaryArtifactsPropertyOutputReference;
    }
    interface SecondarySourceVersionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#source_identifier AwsProject#source_identifier}
        */
        readonly sourceIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#source_version AwsProject#source_version}
        */
        readonly sourceVersion: string;
    }
    class SecondarySourceVersionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SecondarySourceVersionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SecondarySourceVersionProperty | cdktn.IResolvable | undefined);
        private _sourceIdentifier?;
        get sourceIdentifier(): string;
        set sourceIdentifier(value: string);
        get sourceIdentifierInput(): string | undefined;
        private _sourceVersion?;
        get sourceVersion(): string;
        set sourceVersion(value: string);
        get sourceVersionInput(): string | undefined;
    }
    class SecondarySourceVersionPropertyList extends cdktn.ComplexList {
        internalValue?: SecondarySourceVersionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SecondarySourceVersionPropertyOutputReference;
    }
    interface SecondarySourcesAuthProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#resource AwsProject#resource}
        */
        readonly resource: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#type AwsProject#type}
        */
        readonly type: string;
    }
    class SecondarySourcesAuthPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SecondarySourcesAuthProperty | undefined;
        set internalValue(value: SecondarySourcesAuthProperty | undefined);
        private _resource?;
        get resource(): string;
        set resource(value: string);
        get resourceInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    interface SecondarySourcesBuildStatusConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#context AwsProject#context}
        */
        readonly context?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#target_url AwsProject#target_url}
        */
        readonly targetUrl?: string;
    }
    class SecondarySourcesBuildStatusConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SecondarySourcesBuildStatusConfigProperty | undefined;
        set internalValue(value: SecondarySourcesBuildStatusConfigProperty | undefined);
        private _context?;
        get context(): string;
        set context(value: string);
        resetContext(): void;
        get contextInput(): string | undefined;
        private _targetUrl?;
        get targetUrl(): string;
        set targetUrl(value: string);
        resetTargetUrl(): void;
        get targetUrlInput(): string | undefined;
    }
    interface SecondarySourcesGitSubmodulesConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#fetch_submodules AwsProject#fetch_submodules}
        */
        readonly fetchSubmodules: boolean | cdktn.IResolvable;
    }
    class SecondarySourcesGitSubmodulesConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SecondarySourcesGitSubmodulesConfigProperty | undefined;
        set internalValue(value: SecondarySourcesGitSubmodulesConfigProperty | undefined);
        private _fetchSubmodules?;
        get fetchSubmodules(): boolean | cdktn.IResolvable;
        set fetchSubmodules(value: boolean | cdktn.IResolvable);
        get fetchSubmodulesInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface SecondarySourcesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#buildspec AwsProject#buildspec}
        */
        readonly buildspec?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#git_clone_depth AwsProject#git_clone_depth}
        */
        readonly gitCloneDepth?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#insecure_ssl AwsProject#insecure_ssl}
        */
        readonly insecureSsl?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#location AwsProject#location}
        */
        readonly location?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#report_build_status AwsProject#report_build_status}
        */
        readonly reportBuildStatus?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#source_identifier AwsProject#source_identifier}
        */
        readonly sourceIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#type AwsProject#type}
        */
        readonly type: string;
        /**
        * auth block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#auth AwsProject#auth}
        */
        readonly auth?: SecondarySourcesAuthProperty;
        /**
        * build_status_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#build_status_config AwsProject#build_status_config}
        */
        readonly buildStatusConfig?: SecondarySourcesBuildStatusConfigProperty;
        /**
        * git_submodules_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#git_submodules_config AwsProject#git_submodules_config}
        */
        readonly gitSubmodulesConfig?: SecondarySourcesGitSubmodulesConfigProperty;
    }
    class SecondarySourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SecondarySourcesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SecondarySourcesProperty | cdktn.IResolvable | undefined);
        private _buildspec?;
        get buildspec(): string;
        set buildspec(value: string);
        resetBuildspec(): void;
        get buildspecInput(): string | undefined;
        private _gitCloneDepth?;
        get gitCloneDepth(): number;
        set gitCloneDepth(value: number);
        resetGitCloneDepth(): void;
        get gitCloneDepthInput(): number | undefined;
        private _insecureSsl?;
        get insecureSsl(): boolean | cdktn.IResolvable;
        set insecureSsl(value: boolean | cdktn.IResolvable);
        resetInsecureSsl(): void;
        get insecureSslInput(): boolean | cdktn.IResolvable | undefined;
        private _location?;
        get location(): string;
        set location(value: string);
        resetLocation(): void;
        get locationInput(): string | undefined;
        private _reportBuildStatus?;
        get reportBuildStatus(): boolean | cdktn.IResolvable;
        set reportBuildStatus(value: boolean | cdktn.IResolvable);
        resetReportBuildStatus(): void;
        get reportBuildStatusInput(): boolean | cdktn.IResolvable | undefined;
        private _sourceIdentifier?;
        get sourceIdentifier(): string;
        set sourceIdentifier(value: string);
        get sourceIdentifierInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _auth;
        get auth(): SecondarySourcesAuthPropertyOutputReference;
        putAuth(value: SecondarySourcesAuthProperty): void;
        resetAuth(): void;
        get authInput(): SecondarySourcesAuthProperty | undefined;
        private _buildStatusConfig;
        get buildStatusConfig(): SecondarySourcesBuildStatusConfigPropertyOutputReference;
        putBuildStatusConfig(value: SecondarySourcesBuildStatusConfigProperty): void;
        resetBuildStatusConfig(): void;
        get buildStatusConfigInput(): SecondarySourcesBuildStatusConfigProperty | undefined;
        private _gitSubmodulesConfig;
        get gitSubmodulesConfig(): SecondarySourcesGitSubmodulesConfigPropertyOutputReference;
        putGitSubmodulesConfig(value: SecondarySourcesGitSubmodulesConfigProperty): void;
        resetGitSubmodulesConfig(): void;
        get gitSubmodulesConfigInput(): SecondarySourcesGitSubmodulesConfigProperty | undefined;
    }
    class SecondarySourcesPropertyList extends cdktn.ComplexList {
        internalValue?: SecondarySourcesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SecondarySourcesPropertyOutputReference;
    }
    interface SourceAuthProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#resource AwsProject#resource}
        */
        readonly resource: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#type AwsProject#type}
        */
        readonly type: string;
    }
    class SourceAuthPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceAuthProperty | undefined;
        set internalValue(value: SourceAuthProperty | undefined);
        private _resource?;
        get resource(): string;
        set resource(value: string);
        get resourceInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    interface SourceBuildStatusConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#context AwsProject#context}
        */
        readonly context?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#target_url AwsProject#target_url}
        */
        readonly targetUrl?: string;
    }
    class SourceBuildStatusConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceBuildStatusConfigProperty | undefined;
        set internalValue(value: SourceBuildStatusConfigProperty | undefined);
        private _context?;
        get context(): string;
        set context(value: string);
        resetContext(): void;
        get contextInput(): string | undefined;
        private _targetUrl?;
        get targetUrl(): string;
        set targetUrl(value: string);
        resetTargetUrl(): void;
        get targetUrlInput(): string | undefined;
    }
    interface SourceGitSubmodulesConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#fetch_submodules AwsProject#fetch_submodules}
        */
        readonly fetchSubmodules: boolean | cdktn.IResolvable;
    }
    class SourceGitSubmodulesConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceGitSubmodulesConfigProperty | undefined;
        set internalValue(value: SourceGitSubmodulesConfigProperty | undefined);
        private _fetchSubmodules?;
        get fetchSubmodules(): boolean | cdktn.IResolvable;
        set fetchSubmodules(value: boolean | cdktn.IResolvable);
        get fetchSubmodulesInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface SourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#buildspec AwsProject#buildspec}
        */
        readonly buildspec?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#git_clone_depth AwsProject#git_clone_depth}
        */
        readonly gitCloneDepth?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#insecure_ssl AwsProject#insecure_ssl}
        */
        readonly insecureSsl?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#location AwsProject#location}
        */
        readonly location?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#report_build_status AwsProject#report_build_status}
        */
        readonly reportBuildStatus?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#type AwsProject#type}
        */
        readonly type: string;
        /**
        * auth block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#auth AwsProject#auth}
        */
        readonly auth?: SourceAuthProperty;
        /**
        * build_status_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#build_status_config AwsProject#build_status_config}
        */
        readonly buildStatusConfig?: SourceBuildStatusConfigProperty;
        /**
        * git_submodules_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#git_submodules_config AwsProject#git_submodules_config}
        */
        readonly gitSubmodulesConfig?: SourceGitSubmodulesConfigProperty;
    }
    class SourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceProperty | undefined;
        set internalValue(value: SourceProperty | undefined);
        private _buildspec?;
        get buildspec(): string;
        set buildspec(value: string);
        resetBuildspec(): void;
        get buildspecInput(): string | undefined;
        private _gitCloneDepth?;
        get gitCloneDepth(): number;
        set gitCloneDepth(value: number);
        resetGitCloneDepth(): void;
        get gitCloneDepthInput(): number | undefined;
        private _insecureSsl?;
        get insecureSsl(): boolean | cdktn.IResolvable;
        set insecureSsl(value: boolean | cdktn.IResolvable);
        resetInsecureSsl(): void;
        get insecureSslInput(): boolean | cdktn.IResolvable | undefined;
        private _location?;
        get location(): string;
        set location(value: string);
        resetLocation(): void;
        get locationInput(): string | undefined;
        private _reportBuildStatus?;
        get reportBuildStatus(): boolean | cdktn.IResolvable;
        set reportBuildStatus(value: boolean | cdktn.IResolvable);
        resetReportBuildStatus(): void;
        get reportBuildStatusInput(): boolean | cdktn.IResolvable | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _auth;
        get auth(): SourceAuthPropertyOutputReference;
        putAuth(value: SourceAuthProperty): void;
        resetAuth(): void;
        get authInput(): SourceAuthProperty | undefined;
        private _buildStatusConfig;
        get buildStatusConfig(): SourceBuildStatusConfigPropertyOutputReference;
        putBuildStatusConfig(value: SourceBuildStatusConfigProperty): void;
        resetBuildStatusConfig(): void;
        get buildStatusConfigInput(): SourceBuildStatusConfigProperty | undefined;
        private _gitSubmodulesConfig;
        get gitSubmodulesConfig(): SourceGitSubmodulesConfigPropertyOutputReference;
        putGitSubmodulesConfig(value: SourceGitSubmodulesConfigProperty): void;
        resetGitSubmodulesConfig(): void;
        get gitSubmodulesConfigInput(): SourceGitSubmodulesConfigProperty | undefined;
    }
    interface VpcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#security_group_ids AwsProject#security_group_ids}
        */
        readonly securityGroupIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#subnets AwsProject#subnets}
        */
        readonly subnets: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codebuild_project#vpc_id AwsProject#vpc_id}
        */
        readonly vpcId: string;
    }
    class VpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcConfigProperty | undefined;
        set internalValue(value: VpcConfigProperty | undefined);
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        get securityGroupIdsInput(): string[] | undefined;
        private _subnets?;
        get subnets(): string[];
        set subnets(value: string[]);
        get subnetsInput(): string[] | undefined;
        private _vpcId?;
        get vpcId(): string;
        set vpcId(value: string);
        get vpcIdInput(): string | undefined;
    }
}
