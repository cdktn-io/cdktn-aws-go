import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfAuthenticationProfileConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_authentication_profile#authentication_profile_content TfAuthenticationProfile#authentication_profile_content}
    */
    readonly authenticationProfileContent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_authentication_profile#authentication_profile_name TfAuthenticationProfile#authentication_profile_name}
    */
    readonly authenticationProfileName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_authentication_profile#id TfAuthenticationProfile#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_authentication_profile#region TfAuthenticationProfile#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_authentication_profile aws_redshift_authentication_profile}
*/
export declare class TfAuthenticationProfile extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_redshift_authentication_profile";
    /**
    * Generates CDKTN code for importing a TfAuthenticationProfile resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfAuthenticationProfile to import
    * @param importFromId The id of the existing TfAuthenticationProfile that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_authentication_profile#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfAuthenticationProfile to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_authentication_profile aws_redshift_authentication_profile} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfAuthenticationProfileConfig
    */
    constructor(scope: Construct, id: string, config: TfAuthenticationProfileConfig);
    private _authenticationProfileContent?;
    get authenticationProfileContent(): string;
    set authenticationProfileContent(value: string);
    get authenticationProfileContentInput(): string | undefined;
    private _authenticationProfileName?;
    get authenticationProfileName(): string;
    set authenticationProfileName(value: string);
    get authenticationProfileNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
