import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfDataShareAuthorizationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_data_share_authorization#allow_writes TfDataShareAuthorization#allow_writes}
    */
    readonly allowWrites?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_data_share_authorization#consumer_identifier TfDataShareAuthorization#consumer_identifier}
    */
    readonly consumerIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_data_share_authorization#data_share_arn TfDataShareAuthorization#data_share_arn}
    */
    readonly dataShareArn: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_data_share_authorization#region TfDataShareAuthorization#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_data_share_authorization aws_redshift_data_share_authorization}
*/
export declare class TfDataShareAuthorization extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_redshift_data_share_authorization";
    /**
    * Generates CDKTN code for importing a TfDataShareAuthorization resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfDataShareAuthorization to import
    * @param importFromId The id of the existing TfDataShareAuthorization that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_data_share_authorization#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfDataShareAuthorization to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_data_share_authorization aws_redshift_data_share_authorization} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfDataShareAuthorizationConfig
    */
    constructor(scope: Construct, id: string, config: TfDataShareAuthorizationConfig);
    private _allowWrites?;
    get allowWrites(): boolean | cdktn.IResolvable;
    set allowWrites(value: boolean | cdktn.IResolvable);
    resetAllowWrites(): void;
    get allowWritesInput(): boolean | cdktn.IResolvable | undefined;
    private _consumerIdentifier?;
    get consumerIdentifier(): string;
    set consumerIdentifier(value: string);
    get consumerIdentifierInput(): string | undefined;
    private _dataShareArn?;
    get dataShareArn(): string;
    set dataShareArn(value: string);
    get dataShareArnInput(): string | undefined;
    get id(): string;
    get managedBy(): string;
    get producerArn(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
