import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsRedshiftDataShareConsumerAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_data_share_consumer_association#allow_writes AwsRedshiftDataShareConsumerAssociation#allow_writes}
    */
    readonly allowWrites?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_data_share_consumer_association#associate_entire_account AwsRedshiftDataShareConsumerAssociation#associate_entire_account}
    */
    readonly associateEntireAccount?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_data_share_consumer_association#consumer_arn AwsRedshiftDataShareConsumerAssociation#consumer_arn}
    */
    readonly consumerArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_data_share_consumer_association#consumer_region AwsRedshiftDataShareConsumerAssociation#consumer_region}
    */
    readonly consumerRegion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_data_share_consumer_association#data_share_arn AwsRedshiftDataShareConsumerAssociation#data_share_arn}
    */
    readonly dataShareArn: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_data_share_consumer_association#region AwsRedshiftDataShareConsumerAssociation#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_data_share_consumer_association aws_redshift_data_share_consumer_association}
*/
export declare class AwsRedshiftDataShareConsumerAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_redshift_data_share_consumer_association";
    /**
    * Generates CDKTN code for importing a AwsRedshiftDataShareConsumerAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsRedshiftDataShareConsumerAssociation to import
    * @param importFromId The id of the existing AwsRedshiftDataShareConsumerAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_data_share_consumer_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsRedshiftDataShareConsumerAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_data_share_consumer_association aws_redshift_data_share_consumer_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsRedshiftDataShareConsumerAssociationConfig
    */
    constructor(scope: Construct, id: string, config: AwsRedshiftDataShareConsumerAssociationConfig);
    private _allowWrites?;
    get allowWrites(): boolean | cdktn.IResolvable;
    set allowWrites(value: boolean | cdktn.IResolvable);
    resetAllowWrites(): void;
    get allowWritesInput(): boolean | cdktn.IResolvable | undefined;
    private _associateEntireAccount?;
    get associateEntireAccount(): boolean | cdktn.IResolvable;
    set associateEntireAccount(value: boolean | cdktn.IResolvable);
    resetAssociateEntireAccount(): void;
    get associateEntireAccountInput(): boolean | cdktn.IResolvable | undefined;
    private _consumerArn?;
    get consumerArn(): string;
    set consumerArn(value: string);
    resetConsumerArn(): void;
    get consumerArnInput(): string | undefined;
    private _consumerRegion?;
    get consumerRegion(): string;
    set consumerRegion(value: string);
    resetConsumerRegion(): void;
    get consumerRegionInput(): string | undefined;
    private _dataShareArn?;
    get dataShareArn(): string;
    set dataShareArn(value: string);
    get dataShareArnInput(): string | undefined;
    get id(): string;
    get managedBy(): string;
    get producerArn(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
