import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsRedshiftHsmConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_hsm_configuration#description AwsRedshiftHsmConfiguration#description}
    */
    readonly description: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_hsm_configuration#hsm_configuration_identifier AwsRedshiftHsmConfiguration#hsm_configuration_identifier}
    */
    readonly hsmConfigurationIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_hsm_configuration#hsm_ip_address AwsRedshiftHsmConfiguration#hsm_ip_address}
    */
    readonly hsmIpAddress: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_hsm_configuration#hsm_partition_name AwsRedshiftHsmConfiguration#hsm_partition_name}
    */
    readonly hsmPartitionName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_hsm_configuration#hsm_partition_password AwsRedshiftHsmConfiguration#hsm_partition_password}
    */
    readonly hsmPartitionPassword: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_hsm_configuration#hsm_server_public_certificate AwsRedshiftHsmConfiguration#hsm_server_public_certificate}
    */
    readonly hsmServerPublicCertificate: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_hsm_configuration#id AwsRedshiftHsmConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_hsm_configuration#region AwsRedshiftHsmConfiguration#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_hsm_configuration#tags AwsRedshiftHsmConfiguration#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_hsm_configuration#tags_all AwsRedshiftHsmConfiguration#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_hsm_configuration aws_redshift_hsm_configuration}
*/
export declare class AwsRedshiftHsmConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_redshift_hsm_configuration";
    /**
    * Generates CDKTN code for importing a AwsRedshiftHsmConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsRedshiftHsmConfiguration to import
    * @param importFromId The id of the existing AwsRedshiftHsmConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_hsm_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsRedshiftHsmConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_hsm_configuration aws_redshift_hsm_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsRedshiftHsmConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsRedshiftHsmConfigurationConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    private _hsmConfigurationIdentifier?;
    get hsmConfigurationIdentifier(): string;
    set hsmConfigurationIdentifier(value: string);
    get hsmConfigurationIdentifierInput(): string | undefined;
    private _hsmIpAddress?;
    get hsmIpAddress(): string;
    set hsmIpAddress(value: string);
    get hsmIpAddressInput(): string | undefined;
    private _hsmPartitionName?;
    get hsmPartitionName(): string;
    set hsmPartitionName(value: string);
    get hsmPartitionNameInput(): string | undefined;
    private _hsmPartitionPassword?;
    get hsmPartitionPassword(): string;
    set hsmPartitionPassword(value: string);
    get hsmPartitionPasswordInput(): string | undefined;
    private _hsmServerPublicCertificate?;
    get hsmServerPublicCertificate(): string;
    set hsmServerPublicCertificate(value: string);
    get hsmServerPublicCertificateInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
