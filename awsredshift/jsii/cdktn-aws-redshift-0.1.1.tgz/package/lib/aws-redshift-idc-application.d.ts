import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsRedshiftIdcApplicationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_idc_application#application_type AwsRedshiftIdcApplication#application_type}
    */
    readonly applicationType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_idc_application#iam_role_arn AwsRedshiftIdcApplication#iam_role_arn}
    */
    readonly iamRoleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_idc_application#idc_display_name AwsRedshiftIdcApplication#idc_display_name}
    */
    readonly idcDisplayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_idc_application#idc_instance_arn AwsRedshiftIdcApplication#idc_instance_arn}
    */
    readonly idcInstanceArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_idc_application#identity_namespace AwsRedshiftIdcApplication#identity_namespace}
    */
    readonly identityNamespace?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_idc_application#redshift_idc_application_name AwsRedshiftIdcApplication#redshift_idc_application_name}
    */
    readonly redshiftIdcApplicationName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_idc_application#region AwsRedshiftIdcApplication#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_idc_application#tags AwsRedshiftIdcApplication#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * authorized_token_issuer block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_idc_application#authorized_token_issuer AwsRedshiftIdcApplication#authorized_token_issuer}
    */
    readonly authorizedTokenIssuer?: AwsRedshiftIdcApplication.AuthorizedTokenIssuerProperty[] | cdktn.IResolvable;
    /**
    * service_integration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_idc_application#service_integration AwsRedshiftIdcApplication#service_integration}
    */
    readonly serviceIntegration?: AwsRedshiftIdcApplication.ServiceIntegrationProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_idc_application aws_redshift_idc_application}
*/
export declare class AwsRedshiftIdcApplication extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_redshift_idc_application";
    /**
    * Generates CDKTN code for importing a AwsRedshiftIdcApplication resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsRedshiftIdcApplication to import
    * @param importFromId The id of the existing AwsRedshiftIdcApplication that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_idc_application#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsRedshiftIdcApplication to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_idc_application aws_redshift_idc_application} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsRedshiftIdcApplicationConfig
    */
    constructor(scope: Construct, id: string, config: AwsRedshiftIdcApplicationConfig);
    private _applicationType?;
    get applicationType(): string;
    set applicationType(value: string);
    resetApplicationType(): void;
    get applicationTypeInput(): string | undefined;
    private _iamRoleArn?;
    get iamRoleArn(): string;
    set iamRoleArn(value: string);
    get iamRoleArnInput(): string | undefined;
    private _idcDisplayName?;
    get idcDisplayName(): string;
    set idcDisplayName(value: string);
    get idcDisplayNameInput(): string | undefined;
    private _idcInstanceArn?;
    get idcInstanceArn(): string;
    set idcInstanceArn(value: string);
    get idcInstanceArnInput(): string | undefined;
    get idcManagedApplicationArn(): string;
    private _identityNamespace?;
    get identityNamespace(): string;
    set identityNamespace(value: string);
    resetIdentityNamespace(): void;
    get identityNamespaceInput(): string | undefined;
    get redshiftIdcApplicationArn(): string;
    private _redshiftIdcApplicationName?;
    get redshiftIdcApplicationName(): string;
    set redshiftIdcApplicationName(value: string);
    get redshiftIdcApplicationNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _authorizedTokenIssuer;
    get authorizedTokenIssuer(): AwsRedshiftIdcApplication.AuthorizedTokenIssuerPropertyList;
    putAuthorizedTokenIssuer(value: AwsRedshiftIdcApplication.AuthorizedTokenIssuerProperty[] | cdktn.IResolvable): void;
    resetAuthorizedTokenIssuer(): void;
    get authorizedTokenIssuerInput(): cdktn.IResolvable | AwsRedshiftIdcApplication.AuthorizedTokenIssuerProperty[] | undefined;
    private _serviceIntegration;
    get serviceIntegration(): AwsRedshiftIdcApplication.ServiceIntegrationPropertyList;
    putServiceIntegration(value: AwsRedshiftIdcApplication.ServiceIntegrationProperty[] | cdktn.IResolvable): void;
    resetServiceIntegration(): void;
    get serviceIntegrationInput(): cdktn.IResolvable | AwsRedshiftIdcApplication.ServiceIntegrationProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsRedshiftIdcApplicationAuthorizedTokenIssuerPropertyToTerraform(struct?: AwsRedshiftIdcApplication.AuthorizedTokenIssuerProperty | cdktn.IResolvable): any;
export declare function awsRedshiftIdcApplicationAuthorizedTokenIssuerPropertyToHclTerraform(struct?: AwsRedshiftIdcApplication.AuthorizedTokenIssuerProperty | cdktn.IResolvable): any;
export declare function awsRedshiftIdcApplicationLakeFormationQueryPropertyToTerraform(struct?: AwsRedshiftIdcApplication.LakeFormationQueryProperty | cdktn.IResolvable): any;
export declare function awsRedshiftIdcApplicationLakeFormationQueryPropertyToHclTerraform(struct?: AwsRedshiftIdcApplication.LakeFormationQueryProperty | cdktn.IResolvable): any;
export declare function awsRedshiftIdcApplicationLakeFormationPropertyToTerraform(struct?: AwsRedshiftIdcApplication.LakeFormationProperty | cdktn.IResolvable): any;
export declare function awsRedshiftIdcApplicationLakeFormationPropertyToHclTerraform(struct?: AwsRedshiftIdcApplication.LakeFormationProperty | cdktn.IResolvable): any;
export declare function awsRedshiftIdcApplicationConnectPropertyToTerraform(struct?: AwsRedshiftIdcApplication.ConnectProperty | cdktn.IResolvable): any;
export declare function awsRedshiftIdcApplicationConnectPropertyToHclTerraform(struct?: AwsRedshiftIdcApplication.ConnectProperty | cdktn.IResolvable): any;
export declare function awsRedshiftIdcApplicationRedshiftPropertyToTerraform(struct?: AwsRedshiftIdcApplication.RedshiftProperty | cdktn.IResolvable): any;
export declare function awsRedshiftIdcApplicationRedshiftPropertyToHclTerraform(struct?: AwsRedshiftIdcApplication.RedshiftProperty | cdktn.IResolvable): any;
export declare function awsRedshiftIdcApplicationReadWriteAccessPropertyToTerraform(struct?: AwsRedshiftIdcApplication.ReadWriteAccessProperty | cdktn.IResolvable): any;
export declare function awsRedshiftIdcApplicationReadWriteAccessPropertyToHclTerraform(struct?: AwsRedshiftIdcApplication.ReadWriteAccessProperty | cdktn.IResolvable): any;
export declare function awsRedshiftIdcApplicationS3AccessGrantsPropertyToTerraform(struct?: AwsRedshiftIdcApplication.S3AccessGrantsProperty | cdktn.IResolvable): any;
export declare function awsRedshiftIdcApplicationS3AccessGrantsPropertyToHclTerraform(struct?: AwsRedshiftIdcApplication.S3AccessGrantsProperty | cdktn.IResolvable): any;
export declare function awsRedshiftIdcApplicationServiceIntegrationPropertyToTerraform(struct?: AwsRedshiftIdcApplication.ServiceIntegrationProperty | cdktn.IResolvable): any;
export declare function awsRedshiftIdcApplicationServiceIntegrationPropertyToHclTerraform(struct?: AwsRedshiftIdcApplication.ServiceIntegrationProperty | cdktn.IResolvable): any;
export declare namespace AwsRedshiftIdcApplication {
    interface AuthorizedTokenIssuerProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_idc_application#authorized_audiences_list AwsRedshiftIdcApplication#authorized_audiences_list}
        */
        readonly authorizedAudiencesList?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_idc_application#trusted_token_issuer_arn AwsRedshiftIdcApplication#trusted_token_issuer_arn}
        */
        readonly trustedTokenIssuerArn?: string;
    }
    class AuthorizedTokenIssuerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthorizedTokenIssuerProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthorizedTokenIssuerProperty | cdktn.IResolvable | undefined);
        private _authorizedAudiencesList?;
        get authorizedAudiencesList(): string[];
        set authorizedAudiencesList(value: string[]);
        resetAuthorizedAudiencesList(): void;
        get authorizedAudiencesListInput(): string[] | undefined;
        private _trustedTokenIssuerArn?;
        get trustedTokenIssuerArn(): string;
        set trustedTokenIssuerArn(value: string);
        resetTrustedTokenIssuerArn(): void;
        get trustedTokenIssuerArnInput(): string | undefined;
    }
    class AuthorizedTokenIssuerPropertyList extends cdktn.ComplexList {
        internalValue?: AuthorizedTokenIssuerProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthorizedTokenIssuerPropertyOutputReference;
    }
    interface LakeFormationQueryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_idc_application#authorization AwsRedshiftIdcApplication#authorization}
        */
        readonly authorization: string;
    }
    class LakeFormationQueryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LakeFormationQueryProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LakeFormationQueryProperty | cdktn.IResolvable | undefined);
        private _authorization?;
        get authorization(): string;
        set authorization(value: string);
        get authorizationInput(): string | undefined;
    }
    class LakeFormationQueryPropertyList extends cdktn.ComplexList {
        internalValue?: LakeFormationQueryProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LakeFormationQueryPropertyOutputReference;
    }
    interface LakeFormationProperty {
        /**
        * lake_formation_query block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_idc_application#lake_formation_query AwsRedshiftIdcApplication#lake_formation_query}
        */
        readonly lakeFormationQuery?: LakeFormationQueryProperty[] | cdktn.IResolvable;
    }
    class LakeFormationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LakeFormationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LakeFormationProperty | cdktn.IResolvable | undefined);
        private _lakeFormationQuery;
        get lakeFormationQuery(): LakeFormationQueryPropertyList;
        putLakeFormationQuery(value: LakeFormationQueryProperty[] | cdktn.IResolvable): void;
        resetLakeFormationQuery(): void;
        get lakeFormationQueryInput(): cdktn.IResolvable | LakeFormationQueryProperty[] | undefined;
    }
    class LakeFormationPropertyList extends cdktn.ComplexList {
        internalValue?: LakeFormationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LakeFormationPropertyOutputReference;
    }
    interface ConnectProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_idc_application#authorization AwsRedshiftIdcApplication#authorization}
        */
        readonly authorization: string;
    }
    class ConnectPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConnectProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConnectProperty | cdktn.IResolvable | undefined);
        private _authorization?;
        get authorization(): string;
        set authorization(value: string);
        get authorizationInput(): string | undefined;
    }
    class ConnectPropertyList extends cdktn.ComplexList {
        internalValue?: ConnectProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConnectPropertyOutputReference;
    }
    interface RedshiftProperty {
        /**
        * connect block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_idc_application#connect AwsRedshiftIdcApplication#connect}
        */
        readonly connect?: ConnectProperty[] | cdktn.IResolvable;
    }
    class RedshiftPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RedshiftProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RedshiftProperty | cdktn.IResolvable | undefined);
        private _connect;
        get connect(): ConnectPropertyList;
        putConnect(value: ConnectProperty[] | cdktn.IResolvable): void;
        resetConnect(): void;
        get connectInput(): cdktn.IResolvable | ConnectProperty[] | undefined;
    }
    class RedshiftPropertyList extends cdktn.ComplexList {
        internalValue?: RedshiftProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RedshiftPropertyOutputReference;
    }
    interface ReadWriteAccessProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_idc_application#authorization AwsRedshiftIdcApplication#authorization}
        */
        readonly authorization: string;
    }
    class ReadWriteAccessPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReadWriteAccessProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ReadWriteAccessProperty | cdktn.IResolvable | undefined);
        private _authorization?;
        get authorization(): string;
        set authorization(value: string);
        get authorizationInput(): string | undefined;
    }
    class ReadWriteAccessPropertyList extends cdktn.ComplexList {
        internalValue?: ReadWriteAccessProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReadWriteAccessPropertyOutputReference;
    }
    interface S3AccessGrantsProperty {
        /**
        * read_write_access block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_idc_application#read_write_access AwsRedshiftIdcApplication#read_write_access}
        */
        readonly readWriteAccess?: ReadWriteAccessProperty[] | cdktn.IResolvable;
    }
    class S3AccessGrantsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3AccessGrantsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3AccessGrantsProperty | cdktn.IResolvable | undefined);
        private _readWriteAccess;
        get readWriteAccess(): ReadWriteAccessPropertyList;
        putReadWriteAccess(value: ReadWriteAccessProperty[] | cdktn.IResolvable): void;
        resetReadWriteAccess(): void;
        get readWriteAccessInput(): cdktn.IResolvable | ReadWriteAccessProperty[] | undefined;
    }
    class S3AccessGrantsPropertyList extends cdktn.ComplexList {
        internalValue?: S3AccessGrantsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3AccessGrantsPropertyOutputReference;
    }
    interface ServiceIntegrationProperty {
        /**
        * lake_formation block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_idc_application#lake_formation AwsRedshiftIdcApplication#lake_formation}
        */
        readonly lakeFormation?: LakeFormationProperty[] | cdktn.IResolvable;
        /**
        * redshift block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_idc_application#redshift AwsRedshiftIdcApplication#redshift}
        */
        readonly redshift?: RedshiftProperty[] | cdktn.IResolvable;
        /**
        * s3_access_grants block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_idc_application#s3_access_grants AwsRedshiftIdcApplication#s3_access_grants}
        */
        readonly s3AccessGrants?: S3AccessGrantsProperty[] | cdktn.IResolvable;
    }
    class ServiceIntegrationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ServiceIntegrationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ServiceIntegrationProperty | cdktn.IResolvable | undefined);
        private _lakeFormation;
        get lakeFormation(): LakeFormationPropertyList;
        putLakeFormation(value: LakeFormationProperty[] | cdktn.IResolvable): void;
        resetLakeFormation(): void;
        get lakeFormationInput(): cdktn.IResolvable | LakeFormationProperty[] | undefined;
        private _redshift;
        get redshift(): RedshiftPropertyList;
        putRedshift(value: RedshiftProperty[] | cdktn.IResolvable): void;
        resetRedshift(): void;
        get redshiftInput(): cdktn.IResolvable | RedshiftProperty[] | undefined;
        private _s3AccessGrants;
        get s3AccessGrants(): S3AccessGrantsPropertyList;
        putS3AccessGrants(value: S3AccessGrantsProperty[] | cdktn.IResolvable): void;
        resetS3AccessGrants(): void;
        get s3AccessGrantsInput(): cdktn.IResolvable | S3AccessGrantsProperty[] | undefined;
    }
    class ServiceIntegrationPropertyList extends cdktn.ComplexList {
        internalValue?: ServiceIntegrationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ServiceIntegrationPropertyOutputReference;
    }
}
