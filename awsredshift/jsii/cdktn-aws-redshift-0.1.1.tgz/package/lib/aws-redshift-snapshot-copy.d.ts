import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsRedshiftSnapshotCopyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_snapshot_copy#cluster_identifier AwsRedshiftSnapshotCopy#cluster_identifier}
    */
    readonly clusterIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_snapshot_copy#destination_region AwsRedshiftSnapshotCopy#destination_region}
    */
    readonly destinationRegion: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_snapshot_copy#manual_snapshot_retention_period AwsRedshiftSnapshotCopy#manual_snapshot_retention_period}
    */
    readonly manualSnapshotRetentionPeriod?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_snapshot_copy#region AwsRedshiftSnapshotCopy#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_snapshot_copy#retention_period AwsRedshiftSnapshotCopy#retention_period}
    */
    readonly retentionPeriod?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_snapshot_copy#snapshot_copy_grant_name AwsRedshiftSnapshotCopy#snapshot_copy_grant_name}
    */
    readonly snapshotCopyGrantName?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_snapshot_copy aws_redshift_snapshot_copy}
*/
export declare class AwsRedshiftSnapshotCopy extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_redshift_snapshot_copy";
    /**
    * Generates CDKTN code for importing a AwsRedshiftSnapshotCopy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsRedshiftSnapshotCopy to import
    * @param importFromId The id of the existing AwsRedshiftSnapshotCopy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_snapshot_copy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsRedshiftSnapshotCopy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/redshift_snapshot_copy aws_redshift_snapshot_copy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsRedshiftSnapshotCopyConfig
    */
    constructor(scope: Construct, id: string, config: AwsRedshiftSnapshotCopyConfig);
    private _clusterIdentifier?;
    get clusterIdentifier(): string;
    set clusterIdentifier(value: string);
    get clusterIdentifierInput(): string | undefined;
    private _destinationRegion?;
    get destinationRegion(): string;
    set destinationRegion(value: string);
    get destinationRegionInput(): string | undefined;
    get id(): string;
    private _manualSnapshotRetentionPeriod?;
    get manualSnapshotRetentionPeriod(): number;
    set manualSnapshotRetentionPeriod(value: number);
    resetManualSnapshotRetentionPeriod(): void;
    get manualSnapshotRetentionPeriodInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _retentionPeriod?;
    get retentionPeriod(): number;
    set retentionPeriod(value: number);
    resetRetentionPeriod(): void;
    get retentionPeriodInput(): number | undefined;
    private _snapshotCopyGrantName?;
    get snapshotCopyGrantName(): string;
    set snapshotCopyGrantName(value: string);
    resetSnapshotCopyGrantName(): void;
    get snapshotCopyGrantNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
