import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsCustomPluginConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_custom_plugin#content_type AwsCustomPlugin#content_type}
    */
    readonly contentType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_custom_plugin#description AwsCustomPlugin#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_custom_plugin#id AwsCustomPlugin#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_custom_plugin#name AwsCustomPlugin#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_custom_plugin#region AwsCustomPlugin#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_custom_plugin#tags AwsCustomPlugin#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_custom_plugin#tags_all AwsCustomPlugin#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * location block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_custom_plugin#location AwsCustomPlugin#location}
    */
    readonly location: AwsCustomPlugin.LocationProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_custom_plugin#timeouts AwsCustomPlugin#timeouts}
    */
    readonly timeouts?: AwsCustomPlugin.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_custom_plugin aws_mskconnect_custom_plugin}
*/
export declare class AwsCustomPlugin extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_mskconnect_custom_plugin";
    /**
    * Generates CDKTN code for importing a AwsCustomPlugin resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCustomPlugin to import
    * @param importFromId The id of the existing AwsCustomPlugin that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_custom_plugin#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCustomPlugin to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_custom_plugin aws_mskconnect_custom_plugin} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsCustomPluginConfig
    */
    constructor(scope: Construct, id: string, config: AwsCustomPluginConfig);
    get arn(): string;
    private _contentType?;
    get contentType(): string;
    set contentType(value: string);
    get contentTypeInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get latestRevision(): number;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get state(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _location;
    get location(): AwsCustomPlugin.LocationPropertyOutputReference;
    putLocation(value: AwsCustomPlugin.LocationProperty): void;
    get locationInput(): AwsCustomPlugin.LocationProperty | undefined;
    private _timeouts;
    get timeouts(): AwsCustomPlugin.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsCustomPlugin.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsCustomPlugin.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsCustomPluginS3PropertyToTerraform(struct?: AwsCustomPlugin.S3PropertyOutputReference | AwsCustomPlugin.S3Property): any;
export declare function awsCustomPluginS3PropertyToHclTerraform(struct?: AwsCustomPlugin.S3PropertyOutputReference | AwsCustomPlugin.S3Property): any;
export declare function awsCustomPluginLocationPropertyToTerraform(struct?: AwsCustomPlugin.LocationPropertyOutputReference | AwsCustomPlugin.LocationProperty): any;
export declare function awsCustomPluginLocationPropertyToHclTerraform(struct?: AwsCustomPlugin.LocationPropertyOutputReference | AwsCustomPlugin.LocationProperty): any;
export declare function awsCustomPluginTimeoutsPropertyToTerraform(struct?: AwsCustomPlugin.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsCustomPluginTimeoutsPropertyToHclTerraform(struct?: AwsCustomPlugin.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsCustomPlugin {
    interface S3Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_custom_plugin#bucket_arn AwsCustomPlugin#bucket_arn}
        */
        readonly bucketArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_custom_plugin#file_key AwsCustomPlugin#file_key}
        */
        readonly fileKey: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_custom_plugin#object_version AwsCustomPlugin#object_version}
        */
        readonly objectVersion?: string;
    }
    class S3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3Property | undefined;
        set internalValue(value: S3Property | undefined);
        private _bucketArn?;
        get bucketArn(): string;
        set bucketArn(value: string);
        get bucketArnInput(): string | undefined;
        private _fileKey?;
        get fileKey(): string;
        set fileKey(value: string);
        get fileKeyInput(): string | undefined;
        private _objectVersion?;
        get objectVersion(): string;
        set objectVersion(value: string);
        resetObjectVersion(): void;
        get objectVersionInput(): string | undefined;
    }
    interface LocationProperty {
        /**
        * s3 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_custom_plugin#s3 AwsCustomPlugin#s3}
        */
        readonly s3: S3Property;
    }
    class LocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LocationProperty | undefined;
        set internalValue(value: LocationProperty | undefined);
        private _s3;
        get s3(): S3PropertyOutputReference;
        putS3(value: S3Property): void;
        get s3Input(): S3Property | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_custom_plugin#create AwsCustomPlugin#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_custom_plugin#delete AwsCustomPlugin#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
