import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDevicefarmNetworkProfileConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_network_profile#description AwsDevicefarmNetworkProfile#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_network_profile#downlink_bandwidth_bits AwsDevicefarmNetworkProfile#downlink_bandwidth_bits}
    */
    readonly downlinkBandwidthBits?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_network_profile#downlink_delay_ms AwsDevicefarmNetworkProfile#downlink_delay_ms}
    */
    readonly downlinkDelayMs?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_network_profile#downlink_jitter_ms AwsDevicefarmNetworkProfile#downlink_jitter_ms}
    */
    readonly downlinkJitterMs?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_network_profile#downlink_loss_percent AwsDevicefarmNetworkProfile#downlink_loss_percent}
    */
    readonly downlinkLossPercent?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_network_profile#id AwsDevicefarmNetworkProfile#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_network_profile#name AwsDevicefarmNetworkProfile#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_network_profile#project_arn AwsDevicefarmNetworkProfile#project_arn}
    */
    readonly projectArn: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_network_profile#region AwsDevicefarmNetworkProfile#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_network_profile#tags AwsDevicefarmNetworkProfile#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_network_profile#tags_all AwsDevicefarmNetworkProfile#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_network_profile#type AwsDevicefarmNetworkProfile#type}
    */
    readonly type?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_network_profile#uplink_bandwidth_bits AwsDevicefarmNetworkProfile#uplink_bandwidth_bits}
    */
    readonly uplinkBandwidthBits?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_network_profile#uplink_delay_ms AwsDevicefarmNetworkProfile#uplink_delay_ms}
    */
    readonly uplinkDelayMs?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_network_profile#uplink_jitter_ms AwsDevicefarmNetworkProfile#uplink_jitter_ms}
    */
    readonly uplinkJitterMs?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_network_profile#uplink_loss_percent AwsDevicefarmNetworkProfile#uplink_loss_percent}
    */
    readonly uplinkLossPercent?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_network_profile aws_devicefarm_network_profile}
*/
export declare class AwsDevicefarmNetworkProfile extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_devicefarm_network_profile";
    /**
    * Generates CDKTN code for importing a AwsDevicefarmNetworkProfile resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDevicefarmNetworkProfile to import
    * @param importFromId The id of the existing AwsDevicefarmNetworkProfile that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_network_profile#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDevicefarmNetworkProfile to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_network_profile aws_devicefarm_network_profile} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDevicefarmNetworkProfileConfig
    */
    constructor(scope: Construct, id: string, config: AwsDevicefarmNetworkProfileConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _downlinkBandwidthBits?;
    get downlinkBandwidthBits(): number;
    set downlinkBandwidthBits(value: number);
    resetDownlinkBandwidthBits(): void;
    get downlinkBandwidthBitsInput(): number | undefined;
    private _downlinkDelayMs?;
    get downlinkDelayMs(): number;
    set downlinkDelayMs(value: number);
    resetDownlinkDelayMs(): void;
    get downlinkDelayMsInput(): number | undefined;
    private _downlinkJitterMs?;
    get downlinkJitterMs(): number;
    set downlinkJitterMs(value: number);
    resetDownlinkJitterMs(): void;
    get downlinkJitterMsInput(): number | undefined;
    private _downlinkLossPercent?;
    get downlinkLossPercent(): number;
    set downlinkLossPercent(value: number);
    resetDownlinkLossPercent(): void;
    get downlinkLossPercentInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectArn?;
    get projectArn(): string;
    set projectArn(value: string);
    get projectArnInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _uplinkBandwidthBits?;
    get uplinkBandwidthBits(): number;
    set uplinkBandwidthBits(value: number);
    resetUplinkBandwidthBits(): void;
    get uplinkBandwidthBitsInput(): number | undefined;
    private _uplinkDelayMs?;
    get uplinkDelayMs(): number;
    set uplinkDelayMs(value: number);
    resetUplinkDelayMs(): void;
    get uplinkDelayMsInput(): number | undefined;
    private _uplinkJitterMs?;
    get uplinkJitterMs(): number;
    set uplinkJitterMs(value: number);
    resetUplinkJitterMs(): void;
    get uplinkJitterMsInput(): number | undefined;
    private _uplinkLossPercent?;
    get uplinkLossPercent(): number;
    set uplinkLossPercent(value: number);
    resetUplinkLossPercent(): void;
    get uplinkLossPercentInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
