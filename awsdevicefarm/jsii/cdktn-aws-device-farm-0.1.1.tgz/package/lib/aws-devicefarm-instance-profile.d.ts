import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDevicefarmInstanceProfileConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_instance_profile#description AwsDevicefarmInstanceProfile#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_instance_profile#exclude_app_packages_from_cleanup AwsDevicefarmInstanceProfile#exclude_app_packages_from_cleanup}
    */
    readonly excludeAppPackagesFromCleanup?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_instance_profile#id AwsDevicefarmInstanceProfile#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_instance_profile#name AwsDevicefarmInstanceProfile#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_instance_profile#package_cleanup AwsDevicefarmInstanceProfile#package_cleanup}
    */
    readonly packageCleanup?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_instance_profile#reboot_after_use AwsDevicefarmInstanceProfile#reboot_after_use}
    */
    readonly rebootAfterUse?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_instance_profile#region AwsDevicefarmInstanceProfile#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_instance_profile#tags AwsDevicefarmInstanceProfile#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_instance_profile#tags_all AwsDevicefarmInstanceProfile#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_instance_profile aws_devicefarm_instance_profile}
*/
export declare class AwsDevicefarmInstanceProfile extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_devicefarm_instance_profile";
    /**
    * Generates CDKTN code for importing a AwsDevicefarmInstanceProfile resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDevicefarmInstanceProfile to import
    * @param importFromId The id of the existing AwsDevicefarmInstanceProfile that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_instance_profile#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDevicefarmInstanceProfile to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_instance_profile aws_devicefarm_instance_profile} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDevicefarmInstanceProfileConfig
    */
    constructor(scope: Construct, id: string, config: AwsDevicefarmInstanceProfileConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _excludeAppPackagesFromCleanup?;
    get excludeAppPackagesFromCleanup(): string[];
    set excludeAppPackagesFromCleanup(value: string[]);
    resetExcludeAppPackagesFromCleanup(): void;
    get excludeAppPackagesFromCleanupInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _packageCleanup?;
    get packageCleanup(): boolean | cdktn.IResolvable;
    set packageCleanup(value: boolean | cdktn.IResolvable);
    resetPackageCleanup(): void;
    get packageCleanupInput(): boolean | cdktn.IResolvable | undefined;
    private _rebootAfterUse?;
    get rebootAfterUse(): boolean | cdktn.IResolvable;
    set rebootAfterUse(value: boolean | cdktn.IResolvable);
    resetRebootAfterUse(): void;
    get rebootAfterUseInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
