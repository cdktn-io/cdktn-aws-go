import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDevicefarmTestGridProjectConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_test_grid_project#description AwsDevicefarmTestGridProject#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_test_grid_project#id AwsDevicefarmTestGridProject#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_test_grid_project#name AwsDevicefarmTestGridProject#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_test_grid_project#region AwsDevicefarmTestGridProject#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_test_grid_project#tags AwsDevicefarmTestGridProject#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_test_grid_project#tags_all AwsDevicefarmTestGridProject#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * vpc_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_test_grid_project#vpc_config AwsDevicefarmTestGridProject#vpc_config}
    */
    readonly vpcConfig?: AwsDevicefarmTestGridProject.VpcConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_test_grid_project aws_devicefarm_test_grid_project}
*/
export declare class AwsDevicefarmTestGridProject extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_devicefarm_test_grid_project";
    /**
    * Generates CDKTN code for importing a AwsDevicefarmTestGridProject resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDevicefarmTestGridProject to import
    * @param importFromId The id of the existing AwsDevicefarmTestGridProject that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_test_grid_project#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDevicefarmTestGridProject to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_test_grid_project aws_devicefarm_test_grid_project} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDevicefarmTestGridProjectConfig
    */
    constructor(scope: Construct, id: string, config: AwsDevicefarmTestGridProjectConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _vpcConfig;
    get vpcConfig(): AwsDevicefarmTestGridProject.VpcConfigPropertyOutputReference;
    putVpcConfig(value: AwsDevicefarmTestGridProject.VpcConfigProperty): void;
    resetVpcConfig(): void;
    get vpcConfigInput(): AwsDevicefarmTestGridProject.VpcConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDevicefarmTestGridProjectVpcConfigPropertyToTerraform(struct?: AwsDevicefarmTestGridProject.VpcConfigPropertyOutputReference | AwsDevicefarmTestGridProject.VpcConfigProperty): any;
export declare function awsDevicefarmTestGridProjectVpcConfigPropertyToHclTerraform(struct?: AwsDevicefarmTestGridProject.VpcConfigPropertyOutputReference | AwsDevicefarmTestGridProject.VpcConfigProperty): any;
export declare namespace AwsDevicefarmTestGridProject {
    interface VpcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_test_grid_project#security_group_ids AwsDevicefarmTestGridProject#security_group_ids}
        */
        readonly securityGroupIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_test_grid_project#subnet_ids AwsDevicefarmTestGridProject#subnet_ids}
        */
        readonly subnetIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_test_grid_project#vpc_id AwsDevicefarmTestGridProject#vpc_id}
        */
        readonly vpcId: string;
    }
    class VpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcConfigProperty | undefined;
        set internalValue(value: VpcConfigProperty | undefined);
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
        private _vpcId?;
        get vpcId(): string;
        set vpcId(value: string);
        get vpcIdInput(): string | undefined;
    }
}
