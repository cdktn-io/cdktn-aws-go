import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDbClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * The amount of storage to allocate for your DB storage type in GiB (gibibytes).
    * 					This field is forbidden for InfluxDB V3 clusters (when using an InfluxDB V3 db parameter group).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_cluster#allocated_storage AwsDbCluster#allocated_storage}
    */
    readonly allocatedStorage?: number;
    /**
    * Name of the initial InfluxDB bucket. All InfluxDB data is stored in a bucket.
    * 					A bucket combines the concept of a database and a retention period (the duration of time
    * 					that each data point persists). A bucket belongs to an organization. Along with organization,
    * 					username, and password, this argument will be stored in the secret referred to by the
    * 					influx_auth_parameters_secret_arn attribute. This field is forbidden for InfluxDB V3 clusters
    * 					(when using an InfluxDB V3 db parameter group).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_cluster#bucket AwsDbCluster#bucket}
    */
    readonly bucket?: string;
    /**
    * The Timestream for InfluxDB DB instance type to run InfluxDB on.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_cluster#db_instance_type AwsDbCluster#db_instance_type}
    */
    readonly dbInstanceType: string;
    /**
    * The ID of the DB parameter group to assign to your DB cluster.
    * 					DB parameter groups specify how the database is configured. For example, DB parameter groups
    * 					can specify the limit for query concurrency.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_cluster#db_parameter_group_identifier AwsDbCluster#db_parameter_group_identifier}
    */
    readonly dbParameterGroupIdentifier?: string;
    /**
    * The Timestream for InfluxDB DB storage type to read and write InfluxDB data.
    * 					You can choose between 3 different types of provisioned Influx IOPS included storage according
    * 					to your workloads requirements: Influx IO Included 3000 IOPS, Influx IO Included 12000 IOPS,
    * 					Influx IO Included 16000 IOPS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_cluster#db_storage_type AwsDbCluster#db_storage_type}
    */
    readonly dbStorageType?: string;
    /**
    * Specifies the type of cluster to create. This field is forbidden for InfluxDB V3 clusters
    * 					(when using an InfluxDB V3 db parameter group).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_cluster#deployment_type AwsDbCluster#deployment_type}
    */
    readonly deploymentType?: string;
    /**
    * Specifies the behavior of failure recovery when the primary node of the cluster
    * 					fails.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_cluster#failover_mode AwsDbCluster#failover_mode}
    */
    readonly failoverMode?: string;
    /**
    * The name that uniquely identifies the DB cluster when interacting with the
    * 					Amazon Timestream for InfluxDB API and CLI commands. This name will also be a
    * 					prefix included in the endpoint. DB cluster names must be unique per customer
    * 					and per region.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_cluster#name AwsDbCluster#name}
    */
    readonly name: string;
    /**
    * Specifies whether the networkType of the Timestream for InfluxDB cluster is
    * 					IPV4, which can communicate over IPv4 protocol only, or DUAL, which can communicate
    * 					over both IPv4 and IPv6 protocols.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_cluster#network_type AwsDbCluster#network_type}
    */
    readonly networkType?: string;
    /**
    * Name of the initial organization for the initial admin user in InfluxDB. An
    * 					InfluxDB organization is a workspace for a group of users. Along with bucket, username,
    * 					and password, this argument will be stored in the secret referred to by the
    * 					influx_auth_parameters_secret_arn attribute. This field is forbidden for InfluxDB V3 clusters
    * 					(when using an InfluxDB V3 db parameter group).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_cluster#organization AwsDbCluster#organization}
    */
    readonly organization?: string;
    /**
    * Password of the initial admin user created in InfluxDB. This password will
    * 					allow you to access the InfluxDB UI to perform various administrative tasks and
    * 					also use the InfluxDB CLI to create an operator token. Along with bucket, username,
    * 					and organization, this argument will be stored in the secret referred to by the
    * 					influx_auth_parameters_secret_arn attribute. This field is forbidden for InfluxDB V3 clusters
    * 					(when using an InfluxDB V3 db parameter group) as the AWS API rejects it.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_cluster#password AwsDbCluster#password}
    */
    readonly password?: string;
    /**
    * The port number on which InfluxDB accepts connections.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_cluster#port AwsDbCluster#port}
    */
    readonly port?: number;
    /**
    * Configures the Timestream for InfluxDB cluster with a public IP to facilitate access.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_cluster#publicly_accessible AwsDbCluster#publicly_accessible}
    */
    readonly publiclyAccessible?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_cluster#region AwsDbCluster#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_cluster#tags AwsDbCluster#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Username of the initial admin user created in InfluxDB. Must start with a letter
    * 					and can't end with a hyphen or contain two consecutive hyphens. This username will allow
    * 					you to access the InfluxDB UI to perform various administrative tasks and also use the
    * 					InfluxDB CLI to create an operator token. Along with bucket, organization, and password,
    * 					this argument will be stored in the secret referred to by the influx_auth_parameters_secret_arn
    * 					attribute. This field is forbidden for InfluxDB V3 clusters (when using an InfluxDB V3 db parameter group).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_cluster#username AwsDbCluster#username}
    */
    readonly username?: string;
    /**
    * A list of VPC security group IDs to associate with the Timestream for InfluxDB cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_cluster#vpc_security_group_ids AwsDbCluster#vpc_security_group_ids}
    */
    readonly vpcSecurityGroupIds: string[];
    /**
    * A list of VPC subnet IDs to associate with the DB cluster. Provide at least
    * 					two VPC subnet IDs in different availability zones when deploying with a Multi-AZ standby.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_cluster#vpc_subnet_ids AwsDbCluster#vpc_subnet_ids}
    */
    readonly vpcSubnetIds: string[];
    /**
    * log_delivery_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_cluster#log_delivery_configuration AwsDbCluster#log_delivery_configuration}
    */
    readonly logDeliveryConfiguration?: AwsDbCluster.LogDeliveryConfigurationProperty[] | cdktn.IResolvable;
    /**
    * maintenance_schedule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_cluster#maintenance_schedule AwsDbCluster#maintenance_schedule}
    */
    readonly maintenanceSchedule?: AwsDbCluster.MaintenanceScheduleProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_cluster#timeouts AwsDbCluster#timeouts}
    */
    readonly timeouts?: AwsDbCluster.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_cluster aws_timestreaminfluxdb_db_cluster}
*/
export declare class AwsDbCluster extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_timestreaminfluxdb_db_cluster";
    /**
    * Generates CDKTN code for importing a AwsDbCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDbCluster to import
    * @param importFromId The id of the existing AwsDbCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDbCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_cluster aws_timestreaminfluxdb_db_cluster} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDbClusterConfig
    */
    constructor(scope: Construct, id: string, config: AwsDbClusterConfig);
    private _allocatedStorage?;
    get allocatedStorage(): number;
    set allocatedStorage(value: number);
    resetAllocatedStorage(): void;
    get allocatedStorageInput(): number | undefined;
    get arn(): string;
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    resetBucket(): void;
    get bucketInput(): string | undefined;
    private _dbInstanceType?;
    get dbInstanceType(): string;
    set dbInstanceType(value: string);
    get dbInstanceTypeInput(): string | undefined;
    private _dbParameterGroupIdentifier?;
    get dbParameterGroupIdentifier(): string;
    set dbParameterGroupIdentifier(value: string);
    resetDbParameterGroupIdentifier(): void;
    get dbParameterGroupIdentifierInput(): string | undefined;
    private _dbStorageType?;
    get dbStorageType(): string;
    set dbStorageType(value: string);
    resetDbStorageType(): void;
    get dbStorageTypeInput(): string | undefined;
    private _deploymentType?;
    get deploymentType(): string;
    set deploymentType(value: string);
    resetDeploymentType(): void;
    get deploymentTypeInput(): string | undefined;
    get endpoint(): string;
    get engineType(): string;
    private _failoverMode?;
    get failoverMode(): string;
    set failoverMode(value: string);
    resetFailoverMode(): void;
    get failoverModeInput(): string | undefined;
    get id(): string;
    get influxAuthParametersSecretArn(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _networkType?;
    get networkType(): string;
    set networkType(value: string);
    resetNetworkType(): void;
    get networkTypeInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    resetOrganization(): void;
    get organizationInput(): string | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
    private _publiclyAccessible?;
    get publiclyAccessible(): boolean | cdktn.IResolvable;
    set publiclyAccessible(value: boolean | cdktn.IResolvable);
    resetPubliclyAccessible(): void;
    get publiclyAccessibleInput(): boolean | cdktn.IResolvable | undefined;
    get readerEndpoint(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
    private _vpcSecurityGroupIds?;
    get vpcSecurityGroupIds(): string[];
    set vpcSecurityGroupIds(value: string[]);
    get vpcSecurityGroupIdsInput(): string[] | undefined;
    private _vpcSubnetIds?;
    get vpcSubnetIds(): string[];
    set vpcSubnetIds(value: string[]);
    get vpcSubnetIdsInput(): string[] | undefined;
    private _logDeliveryConfiguration;
    get logDeliveryConfiguration(): AwsDbCluster.LogDeliveryConfigurationPropertyList;
    putLogDeliveryConfiguration(value: AwsDbCluster.LogDeliveryConfigurationProperty[] | cdktn.IResolvable): void;
    resetLogDeliveryConfiguration(): void;
    get logDeliveryConfigurationInput(): cdktn.IResolvable | AwsDbCluster.LogDeliveryConfigurationProperty[] | undefined;
    private _maintenanceSchedule;
    get maintenanceSchedule(): AwsDbCluster.MaintenanceSchedulePropertyList;
    putMaintenanceSchedule(value: AwsDbCluster.MaintenanceScheduleProperty[] | cdktn.IResolvable): void;
    resetMaintenanceSchedule(): void;
    get maintenanceScheduleInput(): cdktn.IResolvable | AwsDbCluster.MaintenanceScheduleProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsDbCluster.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsDbCluster.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsDbCluster.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDbClusterS3ConfigurationPropertyToTerraform(struct?: AwsDbCluster.S3ConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDbClusterS3ConfigurationPropertyToHclTerraform(struct?: AwsDbCluster.S3ConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDbClusterLogDeliveryConfigurationPropertyToTerraform(struct?: AwsDbCluster.LogDeliveryConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDbClusterLogDeliveryConfigurationPropertyToHclTerraform(struct?: AwsDbCluster.LogDeliveryConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDbClusterMaintenanceSchedulePropertyToTerraform(struct?: AwsDbCluster.MaintenanceScheduleProperty | cdktn.IResolvable): any;
export declare function awsDbClusterMaintenanceSchedulePropertyToHclTerraform(struct?: AwsDbCluster.MaintenanceScheduleProperty | cdktn.IResolvable): any;
export declare function awsDbClusterTimeoutsPropertyToTerraform(struct?: AwsDbCluster.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsDbClusterTimeoutsPropertyToHclTerraform(struct?: AwsDbCluster.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsDbCluster {
    interface S3ConfigurationProperty {
        /**
        * The name of the S3 bucket to deliver logs to.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_cluster#bucket_name AwsDbCluster#bucket_name}
        */
        readonly bucketName: string;
        /**
        * Indicates whether log delivery to the S3 bucket is enabled.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_cluster#enabled AwsDbCluster#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
    }
    class S3ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3ConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3ConfigurationProperty | cdktn.IResolvable | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        get bucketNameInput(): string | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    class S3ConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: S3ConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3ConfigurationPropertyOutputReference;
    }
    interface LogDeliveryConfigurationProperty {
        /**
        * s3_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_cluster#s3_configuration AwsDbCluster#s3_configuration}
        */
        readonly s3Configuration?: S3ConfigurationProperty[] | cdktn.IResolvable;
    }
    class LogDeliveryConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LogDeliveryConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LogDeliveryConfigurationProperty | cdktn.IResolvable | undefined);
        private _s3Configuration;
        get s3Configuration(): S3ConfigurationPropertyList;
        putS3Configuration(value: S3ConfigurationProperty[] | cdktn.IResolvable): void;
        resetS3Configuration(): void;
        get s3ConfigurationInput(): cdktn.IResolvable | S3ConfigurationProperty[] | undefined;
    }
    class LogDeliveryConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: LogDeliveryConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LogDeliveryConfigurationPropertyOutputReference;
    }
    interface MaintenanceScheduleProperty {
        /**
        * The preferred maintenance window in the format ddd:HH:MM-ddd:HH:MM.
        * 								Day must be one of Mon, Tue, Wed, Thu, Fri, Sat, or Sun. Provide an empty
        * 								string to let the system choose a window.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_cluster#preferred_maintenance_window AwsDbCluster#preferred_maintenance_window}
        */
        readonly preferredMaintenanceWindow: string;
        /**
        * The IANA timezone identifier for the maintenance window. For
        * 								example, America/New_York or UTC.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_cluster#timezone AwsDbCluster#timezone}
        */
        readonly timezone: string;
    }
    class MaintenanceSchedulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MaintenanceScheduleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MaintenanceScheduleProperty | cdktn.IResolvable | undefined);
        private _preferredMaintenanceWindow?;
        get preferredMaintenanceWindow(): string;
        set preferredMaintenanceWindow(value: string);
        get preferredMaintenanceWindowInput(): string | undefined;
        private _timezone?;
        get timezone(): string;
        set timezone(value: string);
        get timezoneInput(): string | undefined;
    }
    class MaintenanceSchedulePropertyList extends cdktn.ComplexList {
        internalValue?: MaintenanceScheduleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MaintenanceSchedulePropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_cluster#create AwsDbCluster#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_cluster#delete AwsDbCluster#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/timestreaminfluxdb_db_cluster#update AwsDbCluster#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
