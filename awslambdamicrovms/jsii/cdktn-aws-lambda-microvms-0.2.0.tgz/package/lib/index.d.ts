export * from './aws-lambdamicrovms-image';
