import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsLambdamicrovmsImageConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambdamicrovms_image#additional_os_capabilities AwsLambdamicrovmsImage#additional_os_capabilities}
    */
    readonly additionalOsCapabilities?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambdamicrovms_image#base_image_arn AwsLambdamicrovmsImage#base_image_arn}
    */
    readonly baseImageArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambdamicrovms_image#base_image_version AwsLambdamicrovmsImage#base_image_version}
    */
    readonly baseImageVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambdamicrovms_image#build_role_arn AwsLambdamicrovmsImage#build_role_arn}
    */
    readonly buildRoleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambdamicrovms_image#description AwsLambdamicrovmsImage#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambdamicrovms_image#egress_network_connectors AwsLambdamicrovmsImage#egress_network_connectors}
    */
    readonly egressNetworkConnectors?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambdamicrovms_image#environment_variables AwsLambdamicrovmsImage#environment_variables}
    */
    readonly environmentVariables?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambdamicrovms_image#name AwsLambdamicrovmsImage#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambdamicrovms_image#region AwsLambdamicrovmsImage#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambdamicrovms_image#tags AwsLambdamicrovmsImage#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * code_artifact block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambdamicrovms_image#code_artifact AwsLambdamicrovmsImage#code_artifact}
    */
    readonly codeArtifact?: AwsLambdamicrovmsImage.CodeArtifactProperty[] | cdktn.IResolvable;
    /**
    * cpu_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambdamicrovms_image#cpu_configuration AwsLambdamicrovmsImage#cpu_configuration}
    */
    readonly cpuConfiguration?: AwsLambdamicrovmsImage.CpuConfigurationProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambdamicrovms_image#timeouts AwsLambdamicrovmsImage#timeouts}
    */
    readonly timeouts?: AwsLambdamicrovmsImage.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambdamicrovms_image aws_lambdamicrovms_image}
*/
export declare class AwsLambdamicrovmsImage extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lambdamicrovms_image";
    /**
    * Generates CDKTN code for importing a AwsLambdamicrovmsImage resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsLambdamicrovmsImage to import
    * @param importFromId The id of the existing AwsLambdamicrovmsImage that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambdamicrovms_image#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsLambdamicrovmsImage to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambdamicrovms_image aws_lambdamicrovms_image} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsLambdamicrovmsImageConfig
    */
    constructor(scope: Construct, id: string, config: AwsLambdamicrovmsImageConfig);
    private _additionalOsCapabilities?;
    get additionalOsCapabilities(): string[];
    set additionalOsCapabilities(value: string[]);
    resetAdditionalOsCapabilities(): void;
    get additionalOsCapabilitiesInput(): string[] | undefined;
    get arn(): string;
    private _baseImageArn?;
    get baseImageArn(): string;
    set baseImageArn(value: string);
    get baseImageArnInput(): string | undefined;
    private _baseImageVersion?;
    get baseImageVersion(): string;
    set baseImageVersion(value: string);
    resetBaseImageVersion(): void;
    get baseImageVersionInput(): string | undefined;
    private _buildRoleArn?;
    get buildRoleArn(): string;
    set buildRoleArn(value: string);
    get buildRoleArnInput(): string | undefined;
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _egressNetworkConnectors?;
    get egressNetworkConnectors(): string[];
    set egressNetworkConnectors(value: string[]);
    resetEgressNetworkConnectors(): void;
    get egressNetworkConnectorsInput(): string[] | undefined;
    private _environmentVariables?;
    get environmentVariables(): {
        [key: string]: string;
    };
    set environmentVariables(value: {
        [key: string]: string;
    });
    resetEnvironmentVariables(): void;
    get environmentVariablesInput(): {
        [key: string]: string;
    } | undefined;
    get imageVersion(): string;
    get latestActiveImageVersion(): string;
    get latestFailedImageVersion(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get state(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    get updatedAt(): string;
    private _codeArtifact;
    get codeArtifact(): AwsLambdamicrovmsImage.CodeArtifactPropertyList;
    putCodeArtifact(value: AwsLambdamicrovmsImage.CodeArtifactProperty[] | cdktn.IResolvable): void;
    resetCodeArtifact(): void;
    get codeArtifactInput(): cdktn.IResolvable | AwsLambdamicrovmsImage.CodeArtifactProperty[] | undefined;
    private _cpuConfiguration;
    get cpuConfiguration(): AwsLambdamicrovmsImage.CpuConfigurationPropertyList;
    putCpuConfiguration(value: AwsLambdamicrovmsImage.CpuConfigurationProperty[] | cdktn.IResolvable): void;
    resetCpuConfiguration(): void;
    get cpuConfigurationInput(): cdktn.IResolvable | AwsLambdamicrovmsImage.CpuConfigurationProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsLambdamicrovmsImage.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsLambdamicrovmsImage.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsLambdamicrovmsImage.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsLambdamicrovmsImageCodeArtifactPropertyToTerraform(struct?: AwsLambdamicrovmsImage.CodeArtifactProperty | cdktn.IResolvable): any;
export declare function awsLambdamicrovmsImageCodeArtifactPropertyToHclTerraform(struct?: AwsLambdamicrovmsImage.CodeArtifactProperty | cdktn.IResolvable): any;
export declare function awsLambdamicrovmsImageCpuConfigurationPropertyToTerraform(struct?: AwsLambdamicrovmsImage.CpuConfigurationProperty | cdktn.IResolvable): any;
export declare function awsLambdamicrovmsImageCpuConfigurationPropertyToHclTerraform(struct?: AwsLambdamicrovmsImage.CpuConfigurationProperty | cdktn.IResolvable): any;
export declare function awsLambdamicrovmsImageTimeoutsPropertyToTerraform(struct?: AwsLambdamicrovmsImage.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsLambdamicrovmsImageTimeoutsPropertyToHclTerraform(struct?: AwsLambdamicrovmsImage.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsLambdamicrovmsImage {
    interface CodeArtifactProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambdamicrovms_image#uri AwsLambdamicrovmsImage#uri}
        */
        readonly uri: string;
    }
    class CodeArtifactPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CodeArtifactProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CodeArtifactProperty | cdktn.IResolvable | undefined);
        private _uri?;
        get uri(): string;
        set uri(value: string);
        get uriInput(): string | undefined;
    }
    class CodeArtifactPropertyList extends cdktn.ComplexList {
        internalValue?: CodeArtifactProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CodeArtifactPropertyOutputReference;
    }
    interface CpuConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambdamicrovms_image#architecture AwsLambdamicrovmsImage#architecture}
        */
        readonly architecture: string;
    }
    class CpuConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CpuConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CpuConfigurationProperty | cdktn.IResolvable | undefined);
        private _architecture?;
        get architecture(): string;
        set architecture(value: string);
        get architectureInput(): string | undefined;
    }
    class CpuConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: CpuConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CpuConfigurationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambdamicrovms_image#create AwsLambdamicrovmsImage#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambdamicrovms_image#delete AwsLambdamicrovmsImage#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambdamicrovms_image#update AwsLambdamicrovmsImage#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
