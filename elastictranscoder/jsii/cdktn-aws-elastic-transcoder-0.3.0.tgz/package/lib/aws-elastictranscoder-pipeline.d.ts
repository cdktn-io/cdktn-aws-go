import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsPipelineConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#aws_kms_key_arn AwsPipeline#aws_kms_key_arn}
    */
    readonly awsKmsKeyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#id AwsPipeline#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#input_bucket AwsPipeline#input_bucket}
    */
    readonly inputBucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#name AwsPipeline#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#output_bucket AwsPipeline#output_bucket}
    */
    readonly outputBucket?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#region AwsPipeline#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#role AwsPipeline#role}
    */
    readonly role: string;
    /**
    * content_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#content_config AwsPipeline#content_config}
    */
    readonly contentConfig?: AwsPipeline.ContentConfigProperty;
    /**
    * content_config_permissions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#content_config_permissions AwsPipeline#content_config_permissions}
    */
    readonly contentConfigPermissions?: AwsPipeline.ContentConfigPermissionsProperty[] | cdktn.IResolvable;
    /**
    * notifications block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#notifications AwsPipeline#notifications}
    */
    readonly notifications?: AwsPipeline.NotificationsProperty;
    /**
    * thumbnail_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#thumbnail_config AwsPipeline#thumbnail_config}
    */
    readonly thumbnailConfig?: AwsPipeline.ThumbnailConfigProperty;
    /**
    * thumbnail_config_permissions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#thumbnail_config_permissions AwsPipeline#thumbnail_config_permissions}
    */
    readonly thumbnailConfigPermissions?: AwsPipeline.ThumbnailConfigPermissionsProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline aws_elastictranscoder_pipeline}
*/
export declare class AwsPipeline extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_elastictranscoder_pipeline";
    /**
    * Generates CDKTN code for importing a AwsPipeline resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsPipeline to import
    * @param importFromId The id of the existing AwsPipeline that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsPipeline to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline aws_elastictranscoder_pipeline} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsPipelineConfig
    */
    constructor(scope: Construct, id: string, config: AwsPipelineConfig);
    get arn(): string;
    private _awsKmsKeyArn?;
    get awsKmsKeyArn(): string;
    set awsKmsKeyArn(value: string);
    resetAwsKmsKeyArn(): void;
    get awsKmsKeyArnInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _inputBucket?;
    get inputBucket(): string;
    set inputBucket(value: string);
    get inputBucketInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _outputBucket?;
    get outputBucket(): string;
    set outputBucket(value: string);
    resetOutputBucket(): void;
    get outputBucketInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _role?;
    get role(): string;
    set role(value: string);
    get roleInput(): string | undefined;
    private _contentConfig;
    get contentConfig(): AwsPipeline.ContentConfigPropertyOutputReference;
    putContentConfig(value: AwsPipeline.ContentConfigProperty): void;
    resetContentConfig(): void;
    get contentConfigInput(): AwsPipeline.ContentConfigProperty | undefined;
    private _contentConfigPermissions;
    get contentConfigPermissions(): AwsPipeline.ContentConfigPermissionsPropertyList;
    putContentConfigPermissions(value: AwsPipeline.ContentConfigPermissionsProperty[] | cdktn.IResolvable): void;
    resetContentConfigPermissions(): void;
    get contentConfigPermissionsInput(): cdktn.IResolvable | AwsPipeline.ContentConfigPermissionsProperty[] | undefined;
    private _notifications;
    get notifications(): AwsPipeline.NotificationsPropertyOutputReference;
    putNotifications(value: AwsPipeline.NotificationsProperty): void;
    resetNotifications(): void;
    get notificationsInput(): AwsPipeline.NotificationsProperty | undefined;
    private _thumbnailConfig;
    get thumbnailConfig(): AwsPipeline.ThumbnailConfigPropertyOutputReference;
    putThumbnailConfig(value: AwsPipeline.ThumbnailConfigProperty): void;
    resetThumbnailConfig(): void;
    get thumbnailConfigInput(): AwsPipeline.ThumbnailConfigProperty | undefined;
    private _thumbnailConfigPermissions;
    get thumbnailConfigPermissions(): AwsPipeline.ThumbnailConfigPermissionsPropertyList;
    putThumbnailConfigPermissions(value: AwsPipeline.ThumbnailConfigPermissionsProperty[] | cdktn.IResolvable): void;
    resetThumbnailConfigPermissions(): void;
    get thumbnailConfigPermissionsInput(): cdktn.IResolvable | AwsPipeline.ThumbnailConfigPermissionsProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsPipelineContentConfigPropertyToTerraform(struct?: AwsPipeline.ContentConfigPropertyOutputReference | AwsPipeline.ContentConfigProperty): any;
export declare function awsPipelineContentConfigPropertyToHclTerraform(struct?: AwsPipeline.ContentConfigPropertyOutputReference | AwsPipeline.ContentConfigProperty): any;
export declare function awsPipelineContentConfigPermissionsPropertyToTerraform(struct?: AwsPipeline.ContentConfigPermissionsProperty | cdktn.IResolvable): any;
export declare function awsPipelineContentConfigPermissionsPropertyToHclTerraform(struct?: AwsPipeline.ContentConfigPermissionsProperty | cdktn.IResolvable): any;
export declare function awsPipelineNotificationsPropertyToTerraform(struct?: AwsPipeline.NotificationsPropertyOutputReference | AwsPipeline.NotificationsProperty): any;
export declare function awsPipelineNotificationsPropertyToHclTerraform(struct?: AwsPipeline.NotificationsPropertyOutputReference | AwsPipeline.NotificationsProperty): any;
export declare function awsPipelineThumbnailConfigPropertyToTerraform(struct?: AwsPipeline.ThumbnailConfigPropertyOutputReference | AwsPipeline.ThumbnailConfigProperty): any;
export declare function awsPipelineThumbnailConfigPropertyToHclTerraform(struct?: AwsPipeline.ThumbnailConfigPropertyOutputReference | AwsPipeline.ThumbnailConfigProperty): any;
export declare function awsPipelineThumbnailConfigPermissionsPropertyToTerraform(struct?: AwsPipeline.ThumbnailConfigPermissionsProperty | cdktn.IResolvable): any;
export declare function awsPipelineThumbnailConfigPermissionsPropertyToHclTerraform(struct?: AwsPipeline.ThumbnailConfigPermissionsProperty | cdktn.IResolvable): any;
export declare namespace AwsPipeline {
    interface ContentConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#bucket AwsPipeline#bucket}
        */
        readonly bucket?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#storage_class AwsPipeline#storage_class}
        */
        readonly storageClass?: string;
    }
    class ContentConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ContentConfigProperty | undefined;
        set internalValue(value: ContentConfigProperty | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        resetBucket(): void;
        get bucketInput(): string | undefined;
        private _storageClass?;
        get storageClass(): string;
        set storageClass(value: string);
        resetStorageClass(): void;
        get storageClassInput(): string | undefined;
    }
    interface ContentConfigPermissionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#access AwsPipeline#access}
        */
        readonly access?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#grantee AwsPipeline#grantee}
        */
        readonly grantee?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#grantee_type AwsPipeline#grantee_type}
        */
        readonly granteeType?: string;
    }
    class ContentConfigPermissionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ContentConfigPermissionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ContentConfigPermissionsProperty | cdktn.IResolvable | undefined);
        private _access?;
        get access(): string[];
        set access(value: string[]);
        resetAccess(): void;
        get accessInput(): string[] | undefined;
        private _grantee?;
        get grantee(): string;
        set grantee(value: string);
        resetGrantee(): void;
        get granteeInput(): string | undefined;
        private _granteeType?;
        get granteeType(): string;
        set granteeType(value: string);
        resetGranteeType(): void;
        get granteeTypeInput(): string | undefined;
    }
    class ContentConfigPermissionsPropertyList extends cdktn.ComplexList {
        internalValue?: ContentConfigPermissionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ContentConfigPermissionsPropertyOutputReference;
    }
    interface NotificationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#completed AwsPipeline#completed}
        */
        readonly completed?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#error AwsPipeline#error}
        */
        readonly error?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#progressing AwsPipeline#progressing}
        */
        readonly progressing?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#warning AwsPipeline#warning}
        */
        readonly warning?: string;
    }
    class NotificationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NotificationsProperty | undefined;
        set internalValue(value: NotificationsProperty | undefined);
        private _completed?;
        get completed(): string;
        set completed(value: string);
        resetCompleted(): void;
        get completedInput(): string | undefined;
        private _error?;
        get error(): string;
        set error(value: string);
        resetError(): void;
        get errorInput(): string | undefined;
        private _progressing?;
        get progressing(): string;
        set progressing(value: string);
        resetProgressing(): void;
        get progressingInput(): string | undefined;
        private _warning?;
        get warning(): string;
        set warning(value: string);
        resetWarning(): void;
        get warningInput(): string | undefined;
    }
    interface ThumbnailConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#bucket AwsPipeline#bucket}
        */
        readonly bucket?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#storage_class AwsPipeline#storage_class}
        */
        readonly storageClass?: string;
    }
    class ThumbnailConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ThumbnailConfigProperty | undefined;
        set internalValue(value: ThumbnailConfigProperty | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        resetBucket(): void;
        get bucketInput(): string | undefined;
        private _storageClass?;
        get storageClass(): string;
        set storageClass(value: string);
        resetStorageClass(): void;
        get storageClassInput(): string | undefined;
    }
    interface ThumbnailConfigPermissionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#access AwsPipeline#access}
        */
        readonly access?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#grantee AwsPipeline#grantee}
        */
        readonly grantee?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastictranscoder_pipeline#grantee_type AwsPipeline#grantee_type}
        */
        readonly granteeType?: string;
    }
    class ThumbnailConfigPermissionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ThumbnailConfigPermissionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ThumbnailConfigPermissionsProperty | cdktn.IResolvable | undefined);
        private _access?;
        get access(): string[];
        set access(value: string[]);
        resetAccess(): void;
        get accessInput(): string[] | undefined;
        private _grantee?;
        get grantee(): string;
        set grantee(value: string);
        resetGrantee(): void;
        get granteeInput(): string | undefined;
        private _granteeType?;
        get granteeType(): string;
        set granteeType(value: string);
        resetGranteeType(): void;
        get granteeTypeInput(): string | undefined;
    }
    class ThumbnailConfigPermissionsPropertyList extends cdktn.ComplexList {
        internalValue?: ThumbnailConfigPermissionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ThumbnailConfigPermissionsPropertyOutputReference;
    }
}
