import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAppconfigExtensionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appconfig_extension#description AwsAppconfigExtension#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appconfig_extension#id AwsAppconfigExtension#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appconfig_extension#name AwsAppconfigExtension#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appconfig_extension#region AwsAppconfigExtension#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appconfig_extension#tags AwsAppconfigExtension#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appconfig_extension#tags_all AwsAppconfigExtension#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * action_point block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appconfig_extension#action_point AwsAppconfigExtension#action_point}
    */
    readonly actionPoint: AwsAppconfigExtension.ActionPointProperty[] | cdktn.IResolvable;
    /**
    * parameter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appconfig_extension#parameter AwsAppconfigExtension#parameter}
    */
    readonly parameter?: AwsAppconfigExtension.ParameterProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appconfig_extension aws_appconfig_extension}
*/
export declare class AwsAppconfigExtension extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_appconfig_extension";
    /**
    * Generates CDKTN code for importing a AwsAppconfigExtension resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAppconfigExtension to import
    * @param importFromId The id of the existing AwsAppconfigExtension that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appconfig_extension#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAppconfigExtension to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appconfig_extension aws_appconfig_extension} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAppconfigExtensionConfig
    */
    constructor(scope: Construct, id: string, config: AwsAppconfigExtensionConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get version(): number;
    private _actionPoint;
    get actionPoint(): AwsAppconfigExtension.ActionPointPropertyList;
    putActionPoint(value: AwsAppconfigExtension.ActionPointProperty[] | cdktn.IResolvable): void;
    get actionPointInput(): cdktn.IResolvable | AwsAppconfigExtension.ActionPointProperty[] | undefined;
    private _parameter;
    get parameter(): AwsAppconfigExtension.ParameterPropertyList;
    putParameter(value: AwsAppconfigExtension.ParameterProperty[] | cdktn.IResolvable): void;
    resetParameter(): void;
    get parameterInput(): cdktn.IResolvable | AwsAppconfigExtension.ParameterProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsAppconfigExtensionActionPropertyToTerraform(struct?: AwsAppconfigExtension.ActionProperty | cdktn.IResolvable): any;
export declare function awsAppconfigExtensionActionPropertyToHclTerraform(struct?: AwsAppconfigExtension.ActionProperty | cdktn.IResolvable): any;
export declare function awsAppconfigExtensionActionPointPropertyToTerraform(struct?: AwsAppconfigExtension.ActionPointProperty | cdktn.IResolvable): any;
export declare function awsAppconfigExtensionActionPointPropertyToHclTerraform(struct?: AwsAppconfigExtension.ActionPointProperty | cdktn.IResolvable): any;
export declare function awsAppconfigExtensionParameterPropertyToTerraform(struct?: AwsAppconfigExtension.ParameterProperty | cdktn.IResolvable): any;
export declare function awsAppconfigExtensionParameterPropertyToHclTerraform(struct?: AwsAppconfigExtension.ParameterProperty | cdktn.IResolvable): any;
export declare namespace AwsAppconfigExtension {
    interface ActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appconfig_extension#description AwsAppconfigExtension#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appconfig_extension#name AwsAppconfigExtension#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appconfig_extension#role_arn AwsAppconfigExtension#role_arn}
        */
        readonly roleArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appconfig_extension#uri AwsAppconfigExtension#uri}
        */
        readonly uri: string;
    }
    class ActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ActionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ActionProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        resetRoleArn(): void;
        get roleArnInput(): string | undefined;
        private _uri?;
        get uri(): string;
        set uri(value: string);
        get uriInput(): string | undefined;
    }
    class ActionPropertyList extends cdktn.ComplexList {
        internalValue?: ActionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ActionPropertyOutputReference;
    }
    interface ActionPointProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appconfig_extension#point AwsAppconfigExtension#point}
        */
        readonly point: string;
        /**
        * action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appconfig_extension#action AwsAppconfigExtension#action}
        */
        readonly action: ActionProperty[] | cdktn.IResolvable;
    }
    class ActionPointPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ActionPointProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ActionPointProperty | cdktn.IResolvable | undefined);
        private _point?;
        get point(): string;
        set point(value: string);
        get pointInput(): string | undefined;
        private _action;
        get action(): ActionPropertyList;
        putAction(value: ActionProperty[] | cdktn.IResolvable): void;
        get actionInput(): cdktn.IResolvable | ActionProperty[] | undefined;
    }
    class ActionPointPropertyList extends cdktn.ComplexList {
        internalValue?: ActionPointProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ActionPointPropertyOutputReference;
    }
    interface ParameterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appconfig_extension#description AwsAppconfigExtension#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appconfig_extension#name AwsAppconfigExtension#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appconfig_extension#required AwsAppconfigExtension#required}
        */
        readonly required?: boolean | cdktn.IResolvable;
    }
    class ParameterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ParameterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ParameterProperty | cdktn.IResolvable | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _required?;
        get required(): boolean | cdktn.IResolvable;
        set required(value: boolean | cdktn.IResolvable);
        resetRequired(): void;
        get requiredInput(): boolean | cdktn.IResolvable | undefined;
    }
    class ParameterPropertyList extends cdktn.ComplexList {
        internalValue?: ParameterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ParameterPropertyOutputReference;
    }
}
