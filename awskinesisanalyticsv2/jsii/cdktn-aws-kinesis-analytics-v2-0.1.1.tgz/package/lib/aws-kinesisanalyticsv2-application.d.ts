import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsKinesisanalyticsv2ApplicationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#application_mode AwsKinesisanalyticsv2Application#application_mode}
    */
    readonly applicationMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#description AwsKinesisanalyticsv2Application#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#force_stop AwsKinesisanalyticsv2Application#force_stop}
    */
    readonly forceStop?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#id AwsKinesisanalyticsv2Application#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#name AwsKinesisanalyticsv2Application#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#region AwsKinesisanalyticsv2Application#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#runtime_environment AwsKinesisanalyticsv2Application#runtime_environment}
    */
    readonly runtimeEnvironment: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#service_execution_role AwsKinesisanalyticsv2Application#service_execution_role}
    */
    readonly serviceExecutionRole: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#start_application AwsKinesisanalyticsv2Application#start_application}
    */
    readonly startApplication?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#tags AwsKinesisanalyticsv2Application#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#tags_all AwsKinesisanalyticsv2Application#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * application_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#application_configuration AwsKinesisanalyticsv2Application#application_configuration}
    */
    readonly applicationConfiguration?: AwsKinesisanalyticsv2Application.ApplicationConfigurationProperty;
    /**
    * cloudwatch_logging_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#cloudwatch_logging_options AwsKinesisanalyticsv2Application#cloudwatch_logging_options}
    */
    readonly cloudwatchLoggingOptions?: AwsKinesisanalyticsv2Application.CloudwatchLoggingOptionsProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#timeouts AwsKinesisanalyticsv2Application#timeouts}
    */
    readonly timeouts?: AwsKinesisanalyticsv2Application.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application aws_kinesisanalyticsv2_application}
*/
export declare class AwsKinesisanalyticsv2Application extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_kinesisanalyticsv2_application";
    /**
    * Generates CDKTN code for importing a AwsKinesisanalyticsv2Application resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsKinesisanalyticsv2Application to import
    * @param importFromId The id of the existing AwsKinesisanalyticsv2Application that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsKinesisanalyticsv2Application to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application aws_kinesisanalyticsv2_application} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsKinesisanalyticsv2ApplicationConfig
    */
    constructor(scope: Construct, id: string, config: AwsKinesisanalyticsv2ApplicationConfig);
    private _applicationMode?;
    get applicationMode(): string;
    set applicationMode(value: string);
    resetApplicationMode(): void;
    get applicationModeInput(): string | undefined;
    get arn(): string;
    get createTimestamp(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _forceStop?;
    get forceStop(): boolean | cdktn.IResolvable;
    set forceStop(value: boolean | cdktn.IResolvable);
    resetForceStop(): void;
    get forceStopInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastUpdateTimestamp(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _runtimeEnvironment?;
    get runtimeEnvironment(): string;
    set runtimeEnvironment(value: string);
    get runtimeEnvironmentInput(): string | undefined;
    private _serviceExecutionRole?;
    get serviceExecutionRole(): string;
    set serviceExecutionRole(value: string);
    get serviceExecutionRoleInput(): string | undefined;
    private _startApplication?;
    get startApplication(): boolean | cdktn.IResolvable;
    set startApplication(value: boolean | cdktn.IResolvable);
    resetStartApplication(): void;
    get startApplicationInput(): boolean | cdktn.IResolvable | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get versionId(): number;
    private _applicationConfiguration;
    get applicationConfiguration(): AwsKinesisanalyticsv2Application.ApplicationConfigurationPropertyOutputReference;
    putApplicationConfiguration(value: AwsKinesisanalyticsv2Application.ApplicationConfigurationProperty): void;
    resetApplicationConfiguration(): void;
    get applicationConfigurationInput(): AwsKinesisanalyticsv2Application.ApplicationConfigurationProperty | undefined;
    private _cloudwatchLoggingOptions;
    get cloudwatchLoggingOptions(): AwsKinesisanalyticsv2Application.CloudwatchLoggingOptionsPropertyOutputReference;
    putCloudwatchLoggingOptions(value: AwsKinesisanalyticsv2Application.CloudwatchLoggingOptionsProperty): void;
    resetCloudwatchLoggingOptions(): void;
    get cloudwatchLoggingOptionsInput(): AwsKinesisanalyticsv2Application.CloudwatchLoggingOptionsProperty | undefined;
    private _timeouts;
    get timeouts(): AwsKinesisanalyticsv2Application.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsKinesisanalyticsv2Application.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsKinesisanalyticsv2Application.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsKinesisanalyticsv2ApplicationS3ContentLocationPropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.S3ContentLocationPropertyOutputReference | AwsKinesisanalyticsv2Application.S3ContentLocationProperty): any;
export declare function awsKinesisanalyticsv2ApplicationS3ContentLocationPropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.S3ContentLocationPropertyOutputReference | AwsKinesisanalyticsv2Application.S3ContentLocationProperty): any;
export declare function awsKinesisanalyticsv2ApplicationCodeContentPropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.CodeContentPropertyOutputReference | AwsKinesisanalyticsv2Application.CodeContentProperty): any;
export declare function awsKinesisanalyticsv2ApplicationCodeContentPropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.CodeContentPropertyOutputReference | AwsKinesisanalyticsv2Application.CodeContentProperty): any;
export declare function awsKinesisanalyticsv2ApplicationApplicationCodeConfigurationPropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.ApplicationCodeConfigurationPropertyOutputReference | AwsKinesisanalyticsv2Application.ApplicationCodeConfigurationProperty): any;
export declare function awsKinesisanalyticsv2ApplicationApplicationCodeConfigurationPropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.ApplicationCodeConfigurationPropertyOutputReference | AwsKinesisanalyticsv2Application.ApplicationCodeConfigurationProperty): any;
export declare function awsKinesisanalyticsv2ApplicationApplicationEncryptionConfigurationPropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.ApplicationEncryptionConfigurationPropertyOutputReference | AwsKinesisanalyticsv2Application.ApplicationEncryptionConfigurationProperty): any;
export declare function awsKinesisanalyticsv2ApplicationApplicationEncryptionConfigurationPropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.ApplicationEncryptionConfigurationPropertyOutputReference | AwsKinesisanalyticsv2Application.ApplicationEncryptionConfigurationProperty): any;
export declare function awsKinesisanalyticsv2ApplicationApplicationSnapshotConfigurationPropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.ApplicationSnapshotConfigurationPropertyOutputReference | AwsKinesisanalyticsv2Application.ApplicationSnapshotConfigurationProperty): any;
export declare function awsKinesisanalyticsv2ApplicationApplicationSnapshotConfigurationPropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.ApplicationSnapshotConfigurationPropertyOutputReference | AwsKinesisanalyticsv2Application.ApplicationSnapshotConfigurationProperty): any;
export declare function awsKinesisanalyticsv2ApplicationPropertyGroupPropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.PropertyGroupProperty | cdktn.IResolvable): any;
export declare function awsKinesisanalyticsv2ApplicationPropertyGroupPropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.PropertyGroupProperty | cdktn.IResolvable): any;
export declare function awsKinesisanalyticsv2ApplicationEnvironmentPropertiesPropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.EnvironmentPropertiesPropertyOutputReference | AwsKinesisanalyticsv2Application.EnvironmentPropertiesProperty): any;
export declare function awsKinesisanalyticsv2ApplicationEnvironmentPropertiesPropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.EnvironmentPropertiesPropertyOutputReference | AwsKinesisanalyticsv2Application.EnvironmentPropertiesProperty): any;
export declare function awsKinesisanalyticsv2ApplicationCheckpointConfigurationPropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.CheckpointConfigurationPropertyOutputReference | AwsKinesisanalyticsv2Application.CheckpointConfigurationProperty): any;
export declare function awsKinesisanalyticsv2ApplicationCheckpointConfigurationPropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.CheckpointConfigurationPropertyOutputReference | AwsKinesisanalyticsv2Application.CheckpointConfigurationProperty): any;
export declare function awsKinesisanalyticsv2ApplicationMonitoringConfigurationPropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.MonitoringConfigurationPropertyOutputReference | AwsKinesisanalyticsv2Application.MonitoringConfigurationProperty): any;
export declare function awsKinesisanalyticsv2ApplicationMonitoringConfigurationPropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.MonitoringConfigurationPropertyOutputReference | AwsKinesisanalyticsv2Application.MonitoringConfigurationProperty): any;
export declare function awsKinesisanalyticsv2ApplicationParallelismConfigurationPropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.ParallelismConfigurationPropertyOutputReference | AwsKinesisanalyticsv2Application.ParallelismConfigurationProperty): any;
export declare function awsKinesisanalyticsv2ApplicationParallelismConfigurationPropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.ParallelismConfigurationPropertyOutputReference | AwsKinesisanalyticsv2Application.ParallelismConfigurationProperty): any;
export declare function awsKinesisanalyticsv2ApplicationFlinkApplicationConfigurationPropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.FlinkApplicationConfigurationPropertyOutputReference | AwsKinesisanalyticsv2Application.FlinkApplicationConfigurationProperty): any;
export declare function awsKinesisanalyticsv2ApplicationFlinkApplicationConfigurationPropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.FlinkApplicationConfigurationPropertyOutputReference | AwsKinesisanalyticsv2Application.FlinkApplicationConfigurationProperty): any;
export declare function awsKinesisanalyticsv2ApplicationApplicationRestoreConfigurationPropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.ApplicationRestoreConfigurationPropertyOutputReference | AwsKinesisanalyticsv2Application.ApplicationRestoreConfigurationProperty): any;
export declare function awsKinesisanalyticsv2ApplicationApplicationRestoreConfigurationPropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.ApplicationRestoreConfigurationPropertyOutputReference | AwsKinesisanalyticsv2Application.ApplicationRestoreConfigurationProperty): any;
export declare function awsKinesisanalyticsv2ApplicationFlinkRunConfigurationPropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.FlinkRunConfigurationPropertyOutputReference | AwsKinesisanalyticsv2Application.FlinkRunConfigurationProperty): any;
export declare function awsKinesisanalyticsv2ApplicationFlinkRunConfigurationPropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.FlinkRunConfigurationPropertyOutputReference | AwsKinesisanalyticsv2Application.FlinkRunConfigurationProperty): any;
export declare function awsKinesisanalyticsv2ApplicationRunConfigurationPropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.RunConfigurationPropertyOutputReference | AwsKinesisanalyticsv2Application.RunConfigurationProperty): any;
export declare function awsKinesisanalyticsv2ApplicationRunConfigurationPropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.RunConfigurationPropertyOutputReference | AwsKinesisanalyticsv2Application.RunConfigurationProperty): any;
export declare function awsKinesisanalyticsv2ApplicationInputParallelismPropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.InputParallelismPropertyOutputReference | AwsKinesisanalyticsv2Application.InputParallelismProperty): any;
export declare function awsKinesisanalyticsv2ApplicationInputParallelismPropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.InputParallelismPropertyOutputReference | AwsKinesisanalyticsv2Application.InputParallelismProperty): any;
export declare function awsKinesisanalyticsv2ApplicationInputLambdaProcessorPropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.InputLambdaProcessorPropertyOutputReference | AwsKinesisanalyticsv2Application.InputLambdaProcessorProperty): any;
export declare function awsKinesisanalyticsv2ApplicationInputLambdaProcessorPropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.InputLambdaProcessorPropertyOutputReference | AwsKinesisanalyticsv2Application.InputLambdaProcessorProperty): any;
export declare function awsKinesisanalyticsv2ApplicationInputProcessingConfigurationPropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.InputProcessingConfigurationPropertyOutputReference | AwsKinesisanalyticsv2Application.InputProcessingConfigurationProperty): any;
export declare function awsKinesisanalyticsv2ApplicationInputProcessingConfigurationPropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.InputProcessingConfigurationPropertyOutputReference | AwsKinesisanalyticsv2Application.InputProcessingConfigurationProperty): any;
export declare function awsKinesisanalyticsv2ApplicationApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordColumnPropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordColumnProperty | cdktn.IResolvable): any;
export declare function awsKinesisanalyticsv2ApplicationApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordColumnPropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordColumnProperty | cdktn.IResolvable): any;
export declare function awsKinesisanalyticsv2ApplicationApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatMappingParametersCsvMappingParametersPropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatMappingParametersCsvMappingParametersPropertyOutputReference | AwsKinesisanalyticsv2Application.ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatMappingParametersCsvMappingParametersProperty): any;
export declare function awsKinesisanalyticsv2ApplicationApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatMappingParametersCsvMappingParametersPropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatMappingParametersCsvMappingParametersPropertyOutputReference | AwsKinesisanalyticsv2Application.ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatMappingParametersCsvMappingParametersProperty): any;
export declare function awsKinesisanalyticsv2ApplicationApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatMappingParametersJsonMappingParametersPropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatMappingParametersJsonMappingParametersPropertyOutputReference | AwsKinesisanalyticsv2Application.ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatMappingParametersJsonMappingParametersProperty): any;
export declare function awsKinesisanalyticsv2ApplicationApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatMappingParametersJsonMappingParametersPropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatMappingParametersJsonMappingParametersPropertyOutputReference | AwsKinesisanalyticsv2Application.ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatMappingParametersJsonMappingParametersProperty): any;
export declare function awsKinesisanalyticsv2ApplicationApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatMappingParametersPropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatMappingParametersPropertyOutputReference | AwsKinesisanalyticsv2Application.ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatMappingParametersProperty): any;
export declare function awsKinesisanalyticsv2ApplicationApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatMappingParametersPropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatMappingParametersPropertyOutputReference | AwsKinesisanalyticsv2Application.ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatMappingParametersProperty): any;
export declare function awsKinesisanalyticsv2ApplicationApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatPropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatPropertyOutputReference | AwsKinesisanalyticsv2Application.ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatProperty): any;
export declare function awsKinesisanalyticsv2ApplicationApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatPropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatPropertyOutputReference | AwsKinesisanalyticsv2Application.ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatProperty): any;
export declare function awsKinesisanalyticsv2ApplicationInputSchemaPropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.InputSchemaPropertyOutputReference | AwsKinesisanalyticsv2Application.InputSchemaProperty): any;
export declare function awsKinesisanalyticsv2ApplicationInputSchemaPropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.InputSchemaPropertyOutputReference | AwsKinesisanalyticsv2Application.InputSchemaProperty): any;
export declare function awsKinesisanalyticsv2ApplicationInputStartingPositionConfigurationPropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.InputStartingPositionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsKinesisanalyticsv2ApplicationInputStartingPositionConfigurationPropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.InputStartingPositionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsKinesisanalyticsv2ApplicationKinesisFirehoseInputPropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.KinesisFirehoseInputPropertyOutputReference | AwsKinesisanalyticsv2Application.KinesisFirehoseInputProperty): any;
export declare function awsKinesisanalyticsv2ApplicationKinesisFirehoseInputPropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.KinesisFirehoseInputPropertyOutputReference | AwsKinesisanalyticsv2Application.KinesisFirehoseInputProperty): any;
export declare function awsKinesisanalyticsv2ApplicationKinesisStreamsInputPropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.KinesisStreamsInputPropertyOutputReference | AwsKinesisanalyticsv2Application.KinesisStreamsInputProperty): any;
export declare function awsKinesisanalyticsv2ApplicationKinesisStreamsInputPropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.KinesisStreamsInputPropertyOutputReference | AwsKinesisanalyticsv2Application.KinesisStreamsInputProperty): any;
export declare function awsKinesisanalyticsv2ApplicationInputPropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.InputPropertyOutputReference | AwsKinesisanalyticsv2Application.InputProperty): any;
export declare function awsKinesisanalyticsv2ApplicationInputPropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.InputPropertyOutputReference | AwsKinesisanalyticsv2Application.InputProperty): any;
export declare function awsKinesisanalyticsv2ApplicationDestinationSchemaPropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.DestinationSchemaPropertyOutputReference | AwsKinesisanalyticsv2Application.DestinationSchemaProperty): any;
export declare function awsKinesisanalyticsv2ApplicationDestinationSchemaPropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.DestinationSchemaPropertyOutputReference | AwsKinesisanalyticsv2Application.DestinationSchemaProperty): any;
export declare function awsKinesisanalyticsv2ApplicationKinesisFirehoseOutputPropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.KinesisFirehoseOutputPropertyOutputReference | AwsKinesisanalyticsv2Application.KinesisFirehoseOutputProperty): any;
export declare function awsKinesisanalyticsv2ApplicationKinesisFirehoseOutputPropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.KinesisFirehoseOutputPropertyOutputReference | AwsKinesisanalyticsv2Application.KinesisFirehoseOutputProperty): any;
export declare function awsKinesisanalyticsv2ApplicationKinesisStreamsOutputPropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.KinesisStreamsOutputPropertyOutputReference | AwsKinesisanalyticsv2Application.KinesisStreamsOutputProperty): any;
export declare function awsKinesisanalyticsv2ApplicationKinesisStreamsOutputPropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.KinesisStreamsOutputPropertyOutputReference | AwsKinesisanalyticsv2Application.KinesisStreamsOutputProperty): any;
export declare function awsKinesisanalyticsv2ApplicationLambdaOutputPropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.LambdaOutputPropertyOutputReference | AwsKinesisanalyticsv2Application.LambdaOutputProperty): any;
export declare function awsKinesisanalyticsv2ApplicationLambdaOutputPropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.LambdaOutputPropertyOutputReference | AwsKinesisanalyticsv2Application.LambdaOutputProperty): any;
export declare function awsKinesisanalyticsv2ApplicationOutputPropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.OutputProperty | cdktn.IResolvable): any;
export declare function awsKinesisanalyticsv2ApplicationOutputPropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.OutputProperty | cdktn.IResolvable): any;
export declare function awsKinesisanalyticsv2ApplicationApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordColumnPropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordColumnProperty | cdktn.IResolvable): any;
export declare function awsKinesisanalyticsv2ApplicationApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordColumnPropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordColumnProperty | cdktn.IResolvable): any;
export declare function awsKinesisanalyticsv2ApplicationApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatMappingParametersCsvMappingParametersPropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatMappingParametersCsvMappingParametersPropertyOutputReference | AwsKinesisanalyticsv2Application.ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatMappingParametersCsvMappingParametersProperty): any;
export declare function awsKinesisanalyticsv2ApplicationApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatMappingParametersCsvMappingParametersPropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatMappingParametersCsvMappingParametersPropertyOutputReference | AwsKinesisanalyticsv2Application.ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatMappingParametersCsvMappingParametersProperty): any;
export declare function awsKinesisanalyticsv2ApplicationApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatMappingParametersJsonMappingParametersPropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatMappingParametersJsonMappingParametersPropertyOutputReference | AwsKinesisanalyticsv2Application.ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatMappingParametersJsonMappingParametersProperty): any;
export declare function awsKinesisanalyticsv2ApplicationApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatMappingParametersJsonMappingParametersPropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatMappingParametersJsonMappingParametersPropertyOutputReference | AwsKinesisanalyticsv2Application.ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatMappingParametersJsonMappingParametersProperty): any;
export declare function awsKinesisanalyticsv2ApplicationApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatMappingParametersPropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatMappingParametersPropertyOutputReference | AwsKinesisanalyticsv2Application.ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatMappingParametersProperty): any;
export declare function awsKinesisanalyticsv2ApplicationApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatMappingParametersPropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatMappingParametersPropertyOutputReference | AwsKinesisanalyticsv2Application.ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatMappingParametersProperty): any;
export declare function awsKinesisanalyticsv2ApplicationApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatPropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatPropertyOutputReference | AwsKinesisanalyticsv2Application.ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatProperty): any;
export declare function awsKinesisanalyticsv2ApplicationApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatPropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatPropertyOutputReference | AwsKinesisanalyticsv2Application.ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatProperty): any;
export declare function awsKinesisanalyticsv2ApplicationReferenceSchemaPropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.ReferenceSchemaPropertyOutputReference | AwsKinesisanalyticsv2Application.ReferenceSchemaProperty): any;
export declare function awsKinesisanalyticsv2ApplicationReferenceSchemaPropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.ReferenceSchemaPropertyOutputReference | AwsKinesisanalyticsv2Application.ReferenceSchemaProperty): any;
export declare function awsKinesisanalyticsv2ApplicationS3ReferenceDataSourcePropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.S3ReferenceDataSourcePropertyOutputReference | AwsKinesisanalyticsv2Application.S3ReferenceDataSourceProperty): any;
export declare function awsKinesisanalyticsv2ApplicationS3ReferenceDataSourcePropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.S3ReferenceDataSourcePropertyOutputReference | AwsKinesisanalyticsv2Application.S3ReferenceDataSourceProperty): any;
export declare function awsKinesisanalyticsv2ApplicationReferenceDataSourcePropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.ReferenceDataSourcePropertyOutputReference | AwsKinesisanalyticsv2Application.ReferenceDataSourceProperty): any;
export declare function awsKinesisanalyticsv2ApplicationReferenceDataSourcePropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.ReferenceDataSourcePropertyOutputReference | AwsKinesisanalyticsv2Application.ReferenceDataSourceProperty): any;
export declare function awsKinesisanalyticsv2ApplicationSqlApplicationConfigurationPropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.SqlApplicationConfigurationPropertyOutputReference | AwsKinesisanalyticsv2Application.SqlApplicationConfigurationProperty): any;
export declare function awsKinesisanalyticsv2ApplicationSqlApplicationConfigurationPropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.SqlApplicationConfigurationPropertyOutputReference | AwsKinesisanalyticsv2Application.SqlApplicationConfigurationProperty): any;
export declare function awsKinesisanalyticsv2ApplicationVpcConfigurationPropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.VpcConfigurationPropertyOutputReference | AwsKinesisanalyticsv2Application.VpcConfigurationProperty): any;
export declare function awsKinesisanalyticsv2ApplicationVpcConfigurationPropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.VpcConfigurationPropertyOutputReference | AwsKinesisanalyticsv2Application.VpcConfigurationProperty): any;
export declare function awsKinesisanalyticsv2ApplicationApplicationConfigurationPropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.ApplicationConfigurationPropertyOutputReference | AwsKinesisanalyticsv2Application.ApplicationConfigurationProperty): any;
export declare function awsKinesisanalyticsv2ApplicationApplicationConfigurationPropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.ApplicationConfigurationPropertyOutputReference | AwsKinesisanalyticsv2Application.ApplicationConfigurationProperty): any;
export declare function awsKinesisanalyticsv2ApplicationCloudwatchLoggingOptionsPropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.CloudwatchLoggingOptionsPropertyOutputReference | AwsKinesisanalyticsv2Application.CloudwatchLoggingOptionsProperty): any;
export declare function awsKinesisanalyticsv2ApplicationCloudwatchLoggingOptionsPropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.CloudwatchLoggingOptionsPropertyOutputReference | AwsKinesisanalyticsv2Application.CloudwatchLoggingOptionsProperty): any;
export declare function awsKinesisanalyticsv2ApplicationTimeoutsPropertyToTerraform(struct?: AwsKinesisanalyticsv2Application.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsKinesisanalyticsv2ApplicationTimeoutsPropertyToHclTerraform(struct?: AwsKinesisanalyticsv2Application.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsKinesisanalyticsv2Application {
    interface S3ContentLocationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#bucket_arn AwsKinesisanalyticsv2Application#bucket_arn}
        */
        readonly bucketArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#file_key AwsKinesisanalyticsv2Application#file_key}
        */
        readonly fileKey: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#object_version AwsKinesisanalyticsv2Application#object_version}
        */
        readonly objectVersion?: string;
    }
    class S3ContentLocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3ContentLocationProperty | undefined;
        set internalValue(value: S3ContentLocationProperty | undefined);
        private _bucketArn?;
        get bucketArn(): string;
        set bucketArn(value: string);
        get bucketArnInput(): string | undefined;
        private _fileKey?;
        get fileKey(): string;
        set fileKey(value: string);
        get fileKeyInput(): string | undefined;
        private _objectVersion?;
        get objectVersion(): string;
        set objectVersion(value: string);
        resetObjectVersion(): void;
        get objectVersionInput(): string | undefined;
    }
    interface CodeContentProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#text_content AwsKinesisanalyticsv2Application#text_content}
        */
        readonly textContent?: string;
        /**
        * s3_content_location block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#s3_content_location AwsKinesisanalyticsv2Application#s3_content_location}
        */
        readonly s3ContentLocation?: S3ContentLocationProperty;
    }
    class CodeContentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CodeContentProperty | undefined;
        set internalValue(value: CodeContentProperty | undefined);
        private _textContent?;
        get textContent(): string;
        set textContent(value: string);
        resetTextContent(): void;
        get textContentInput(): string | undefined;
        private _s3ContentLocation;
        get s3ContentLocation(): S3ContentLocationPropertyOutputReference;
        putS3ContentLocation(value: S3ContentLocationProperty): void;
        resetS3ContentLocation(): void;
        get s3ContentLocationInput(): S3ContentLocationProperty | undefined;
    }
    interface ApplicationCodeConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#code_content_type AwsKinesisanalyticsv2Application#code_content_type}
        */
        readonly codeContentType: string;
        /**
        * code_content block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#code_content AwsKinesisanalyticsv2Application#code_content}
        */
        readonly codeContent?: CodeContentProperty;
    }
    class ApplicationCodeConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ApplicationCodeConfigurationProperty | undefined;
        set internalValue(value: ApplicationCodeConfigurationProperty | undefined);
        private _codeContentType?;
        get codeContentType(): string;
        set codeContentType(value: string);
        get codeContentTypeInput(): string | undefined;
        private _codeContent;
        get codeContent(): CodeContentPropertyOutputReference;
        putCodeContent(value: CodeContentProperty): void;
        resetCodeContent(): void;
        get codeContentInput(): CodeContentProperty | undefined;
    }
    interface ApplicationEncryptionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#key_id AwsKinesisanalyticsv2Application#key_id}
        */
        readonly keyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#key_type AwsKinesisanalyticsv2Application#key_type}
        */
        readonly keyType: string;
    }
    class ApplicationEncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ApplicationEncryptionConfigurationProperty | undefined;
        set internalValue(value: ApplicationEncryptionConfigurationProperty | undefined);
        private _keyId?;
        get keyId(): string;
        set keyId(value: string);
        resetKeyId(): void;
        get keyIdInput(): string | undefined;
        private _keyType?;
        get keyType(): string;
        set keyType(value: string);
        get keyTypeInput(): string | undefined;
    }
    interface ApplicationSnapshotConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#snapshots_enabled AwsKinesisanalyticsv2Application#snapshots_enabled}
        */
        readonly snapshotsEnabled: boolean | cdktn.IResolvable;
    }
    class ApplicationSnapshotConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ApplicationSnapshotConfigurationProperty | undefined;
        set internalValue(value: ApplicationSnapshotConfigurationProperty | undefined);
        private _snapshotsEnabled?;
        get snapshotsEnabled(): boolean | cdktn.IResolvable;
        set snapshotsEnabled(value: boolean | cdktn.IResolvable);
        get snapshotsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface PropertyGroupProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#property_group_id AwsKinesisanalyticsv2Application#property_group_id}
        */
        readonly propertyGroupId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#property_map AwsKinesisanalyticsv2Application#property_map}
        */
        readonly propertyMap: {
            [key: string]: string;
        };
    }
    class PropertyGroupPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PropertyGroupProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PropertyGroupProperty | cdktn.IResolvable | undefined);
        private _propertyGroupId?;
        get propertyGroupId(): string;
        set propertyGroupId(value: string);
        get propertyGroupIdInput(): string | undefined;
        private _propertyMap?;
        get propertyMap(): {
            [key: string]: string;
        };
        set propertyMap(value: {
            [key: string]: string;
        });
        get propertyMapInput(): {
            [key: string]: string;
        } | undefined;
    }
    class PropertyGroupPropertyList extends cdktn.ComplexList {
        internalValue?: PropertyGroupProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PropertyGroupPropertyOutputReference;
    }
    interface EnvironmentPropertiesProperty {
        /**
        * property_group block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#property_group AwsKinesisanalyticsv2Application#property_group}
        */
        readonly propertyGroup: PropertyGroupProperty[] | cdktn.IResolvable;
    }
    class EnvironmentPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EnvironmentPropertiesProperty | undefined;
        set internalValue(value: EnvironmentPropertiesProperty | undefined);
        private _propertyGroup;
        get propertyGroup(): PropertyGroupPropertyList;
        putPropertyGroup(value: PropertyGroupProperty[] | cdktn.IResolvable): void;
        get propertyGroupInput(): cdktn.IResolvable | PropertyGroupProperty[] | undefined;
    }
    interface CheckpointConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#checkpoint_interval AwsKinesisanalyticsv2Application#checkpoint_interval}
        */
        readonly checkpointInterval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#checkpointing_enabled AwsKinesisanalyticsv2Application#checkpointing_enabled}
        */
        readonly checkpointingEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#configuration_type AwsKinesisanalyticsv2Application#configuration_type}
        */
        readonly configurationType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#min_pause_between_checkpoints AwsKinesisanalyticsv2Application#min_pause_between_checkpoints}
        */
        readonly minPauseBetweenCheckpoints?: number;
    }
    class CheckpointConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CheckpointConfigurationProperty | undefined;
        set internalValue(value: CheckpointConfigurationProperty | undefined);
        private _checkpointInterval?;
        get checkpointInterval(): number;
        set checkpointInterval(value: number);
        resetCheckpointInterval(): void;
        get checkpointIntervalInput(): number | undefined;
        private _checkpointingEnabled?;
        get checkpointingEnabled(): boolean | cdktn.IResolvable;
        set checkpointingEnabled(value: boolean | cdktn.IResolvable);
        resetCheckpointingEnabled(): void;
        get checkpointingEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _configurationType?;
        get configurationType(): string;
        set configurationType(value: string);
        get configurationTypeInput(): string | undefined;
        private _minPauseBetweenCheckpoints?;
        get minPauseBetweenCheckpoints(): number;
        set minPauseBetweenCheckpoints(value: number);
        resetMinPauseBetweenCheckpoints(): void;
        get minPauseBetweenCheckpointsInput(): number | undefined;
    }
    interface MonitoringConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#configuration_type AwsKinesisanalyticsv2Application#configuration_type}
        */
        readonly configurationType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#log_level AwsKinesisanalyticsv2Application#log_level}
        */
        readonly logLevel?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#metrics_level AwsKinesisanalyticsv2Application#metrics_level}
        */
        readonly metricsLevel?: string;
    }
    class MonitoringConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MonitoringConfigurationProperty | undefined;
        set internalValue(value: MonitoringConfigurationProperty | undefined);
        private _configurationType?;
        get configurationType(): string;
        set configurationType(value: string);
        get configurationTypeInput(): string | undefined;
        private _logLevel?;
        get logLevel(): string;
        set logLevel(value: string);
        resetLogLevel(): void;
        get logLevelInput(): string | undefined;
        private _metricsLevel?;
        get metricsLevel(): string;
        set metricsLevel(value: string);
        resetMetricsLevel(): void;
        get metricsLevelInput(): string | undefined;
    }
    interface ParallelismConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#auto_scaling_enabled AwsKinesisanalyticsv2Application#auto_scaling_enabled}
        */
        readonly autoScalingEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#configuration_type AwsKinesisanalyticsv2Application#configuration_type}
        */
        readonly configurationType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#parallelism AwsKinesisanalyticsv2Application#parallelism}
        */
        readonly parallelism?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#parallelism_per_kpu AwsKinesisanalyticsv2Application#parallelism_per_kpu}
        */
        readonly parallelismPerKpu?: number;
    }
    class ParallelismConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ParallelismConfigurationProperty | undefined;
        set internalValue(value: ParallelismConfigurationProperty | undefined);
        private _autoScalingEnabled?;
        get autoScalingEnabled(): boolean | cdktn.IResolvable;
        set autoScalingEnabled(value: boolean | cdktn.IResolvable);
        resetAutoScalingEnabled(): void;
        get autoScalingEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _configurationType?;
        get configurationType(): string;
        set configurationType(value: string);
        get configurationTypeInput(): string | undefined;
        private _parallelism?;
        get parallelism(): number;
        set parallelism(value: number);
        resetParallelism(): void;
        get parallelismInput(): number | undefined;
        private _parallelismPerKpu?;
        get parallelismPerKpu(): number;
        set parallelismPerKpu(value: number);
        resetParallelismPerKpu(): void;
        get parallelismPerKpuInput(): number | undefined;
    }
    interface FlinkApplicationConfigurationProperty {
        /**
        * checkpoint_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#checkpoint_configuration AwsKinesisanalyticsv2Application#checkpoint_configuration}
        */
        readonly checkpointConfiguration?: CheckpointConfigurationProperty;
        /**
        * monitoring_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#monitoring_configuration AwsKinesisanalyticsv2Application#monitoring_configuration}
        */
        readonly monitoringConfiguration?: MonitoringConfigurationProperty;
        /**
        * parallelism_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#parallelism_configuration AwsKinesisanalyticsv2Application#parallelism_configuration}
        */
        readonly parallelismConfiguration?: ParallelismConfigurationProperty;
    }
    class FlinkApplicationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FlinkApplicationConfigurationProperty | undefined;
        set internalValue(value: FlinkApplicationConfigurationProperty | undefined);
        private _checkpointConfiguration;
        get checkpointConfiguration(): CheckpointConfigurationPropertyOutputReference;
        putCheckpointConfiguration(value: CheckpointConfigurationProperty): void;
        resetCheckpointConfiguration(): void;
        get checkpointConfigurationInput(): CheckpointConfigurationProperty | undefined;
        private _monitoringConfiguration;
        get monitoringConfiguration(): MonitoringConfigurationPropertyOutputReference;
        putMonitoringConfiguration(value: MonitoringConfigurationProperty): void;
        resetMonitoringConfiguration(): void;
        get monitoringConfigurationInput(): MonitoringConfigurationProperty | undefined;
        private _parallelismConfiguration;
        get parallelismConfiguration(): ParallelismConfigurationPropertyOutputReference;
        putParallelismConfiguration(value: ParallelismConfigurationProperty): void;
        resetParallelismConfiguration(): void;
        get parallelismConfigurationInput(): ParallelismConfigurationProperty | undefined;
    }
    interface ApplicationRestoreConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#application_restore_type AwsKinesisanalyticsv2Application#application_restore_type}
        */
        readonly applicationRestoreType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#snapshot_name AwsKinesisanalyticsv2Application#snapshot_name}
        */
        readonly snapshotName?: string;
    }
    class ApplicationRestoreConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ApplicationRestoreConfigurationProperty | undefined;
        set internalValue(value: ApplicationRestoreConfigurationProperty | undefined);
        private _applicationRestoreType?;
        get applicationRestoreType(): string;
        set applicationRestoreType(value: string);
        resetApplicationRestoreType(): void;
        get applicationRestoreTypeInput(): string | undefined;
        private _snapshotName?;
        get snapshotName(): string;
        set snapshotName(value: string);
        resetSnapshotName(): void;
        get snapshotNameInput(): string | undefined;
    }
    interface FlinkRunConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#allow_non_restored_state AwsKinesisanalyticsv2Application#allow_non_restored_state}
        */
        readonly allowNonRestoredState?: boolean | cdktn.IResolvable;
    }
    class FlinkRunConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FlinkRunConfigurationProperty | undefined;
        set internalValue(value: FlinkRunConfigurationProperty | undefined);
        private _allowNonRestoredState?;
        get allowNonRestoredState(): boolean | cdktn.IResolvable;
        set allowNonRestoredState(value: boolean | cdktn.IResolvable);
        resetAllowNonRestoredState(): void;
        get allowNonRestoredStateInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface RunConfigurationProperty {
        /**
        * application_restore_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#application_restore_configuration AwsKinesisanalyticsv2Application#application_restore_configuration}
        */
        readonly applicationRestoreConfiguration?: ApplicationRestoreConfigurationProperty;
        /**
        * flink_run_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#flink_run_configuration AwsKinesisanalyticsv2Application#flink_run_configuration}
        */
        readonly flinkRunConfiguration?: FlinkRunConfigurationProperty;
    }
    class RunConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RunConfigurationProperty | undefined;
        set internalValue(value: RunConfigurationProperty | undefined);
        private _applicationRestoreConfiguration;
        get applicationRestoreConfiguration(): ApplicationRestoreConfigurationPropertyOutputReference;
        putApplicationRestoreConfiguration(value: ApplicationRestoreConfigurationProperty): void;
        resetApplicationRestoreConfiguration(): void;
        get applicationRestoreConfigurationInput(): ApplicationRestoreConfigurationProperty | undefined;
        private _flinkRunConfiguration;
        get flinkRunConfiguration(): FlinkRunConfigurationPropertyOutputReference;
        putFlinkRunConfiguration(value: FlinkRunConfigurationProperty): void;
        resetFlinkRunConfiguration(): void;
        get flinkRunConfigurationInput(): FlinkRunConfigurationProperty | undefined;
    }
    interface InputParallelismProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#count AwsKinesisanalyticsv2Application#count}
        */
        readonly count?: number;
    }
    class InputParallelismPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InputParallelismProperty | undefined;
        set internalValue(value: InputParallelismProperty | undefined);
        private _count?;
        get count(): number;
        set count(value: number);
        resetCount(): void;
        get countInput(): number | undefined;
    }
    interface InputLambdaProcessorProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#resource_arn AwsKinesisanalyticsv2Application#resource_arn}
        */
        readonly resourceArn: string;
    }
    class InputLambdaProcessorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InputLambdaProcessorProperty | undefined;
        set internalValue(value: InputLambdaProcessorProperty | undefined);
        private _resourceArn?;
        get resourceArn(): string;
        set resourceArn(value: string);
        get resourceArnInput(): string | undefined;
    }
    interface InputProcessingConfigurationProperty {
        /**
        * input_lambda_processor block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#input_lambda_processor AwsKinesisanalyticsv2Application#input_lambda_processor}
        */
        readonly inputLambdaProcessor: InputLambdaProcessorProperty;
    }
    class InputProcessingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InputProcessingConfigurationProperty | undefined;
        set internalValue(value: InputProcessingConfigurationProperty | undefined);
        private _inputLambdaProcessor;
        get inputLambdaProcessor(): InputLambdaProcessorPropertyOutputReference;
        putInputLambdaProcessor(value: InputLambdaProcessorProperty): void;
        get inputLambdaProcessorInput(): InputLambdaProcessorProperty | undefined;
    }
    interface ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordColumnProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#mapping AwsKinesisanalyticsv2Application#mapping}
        */
        readonly mapping?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#name AwsKinesisanalyticsv2Application#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#sql_type AwsKinesisanalyticsv2Application#sql_type}
        */
        readonly sqlType: string;
    }
    class ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordColumnPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordColumnProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordColumnProperty | cdktn.IResolvable | undefined);
        private _mapping?;
        get mapping(): string;
        set mapping(value: string);
        resetMapping(): void;
        get mappingInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _sqlType?;
        get sqlType(): string;
        set sqlType(value: string);
        get sqlTypeInput(): string | undefined;
    }
    class ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordColumnPropertyList extends cdktn.ComplexList {
        internalValue?: ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordColumnProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordColumnPropertyOutputReference;
    }
    interface ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatMappingParametersCsvMappingParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#record_column_delimiter AwsKinesisanalyticsv2Application#record_column_delimiter}
        */
        readonly recordColumnDelimiter: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#record_row_delimiter AwsKinesisanalyticsv2Application#record_row_delimiter}
        */
        readonly recordRowDelimiter: string;
    }
    class ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatMappingParametersCsvMappingParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatMappingParametersCsvMappingParametersProperty | undefined;
        set internalValue(value: ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatMappingParametersCsvMappingParametersProperty | undefined);
        private _recordColumnDelimiter?;
        get recordColumnDelimiter(): string;
        set recordColumnDelimiter(value: string);
        get recordColumnDelimiterInput(): string | undefined;
        private _recordRowDelimiter?;
        get recordRowDelimiter(): string;
        set recordRowDelimiter(value: string);
        get recordRowDelimiterInput(): string | undefined;
    }
    interface ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatMappingParametersJsonMappingParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#record_row_path AwsKinesisanalyticsv2Application#record_row_path}
        */
        readonly recordRowPath: string;
    }
    class ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatMappingParametersJsonMappingParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatMappingParametersJsonMappingParametersProperty | undefined;
        set internalValue(value: ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatMappingParametersJsonMappingParametersProperty | undefined);
        private _recordRowPath?;
        get recordRowPath(): string;
        set recordRowPath(value: string);
        get recordRowPathInput(): string | undefined;
    }
    interface ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatMappingParametersProperty {
        /**
        * csv_mapping_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#csv_mapping_parameters AwsKinesisanalyticsv2Application#csv_mapping_parameters}
        */
        readonly csvMappingParameters?: ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatMappingParametersCsvMappingParametersProperty;
        /**
        * json_mapping_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#json_mapping_parameters AwsKinesisanalyticsv2Application#json_mapping_parameters}
        */
        readonly jsonMappingParameters?: ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatMappingParametersJsonMappingParametersProperty;
    }
    class ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatMappingParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatMappingParametersProperty | undefined;
        set internalValue(value: ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatMappingParametersProperty | undefined);
        private _csvMappingParameters;
        get csvMappingParameters(): ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatMappingParametersCsvMappingParametersPropertyOutputReference;
        putCsvMappingParameters(value: ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatMappingParametersCsvMappingParametersProperty): void;
        resetCsvMappingParameters(): void;
        get csvMappingParametersInput(): ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatMappingParametersCsvMappingParametersProperty | undefined;
        private _jsonMappingParameters;
        get jsonMappingParameters(): ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatMappingParametersJsonMappingParametersPropertyOutputReference;
        putJsonMappingParameters(value: ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatMappingParametersJsonMappingParametersProperty): void;
        resetJsonMappingParameters(): void;
        get jsonMappingParametersInput(): ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatMappingParametersJsonMappingParametersProperty | undefined;
    }
    interface ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#record_format_type AwsKinesisanalyticsv2Application#record_format_type}
        */
        readonly recordFormatType: string;
        /**
        * mapping_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#mapping_parameters AwsKinesisanalyticsv2Application#mapping_parameters}
        */
        readonly mappingParameters: ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatMappingParametersProperty;
    }
    class ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatProperty | undefined;
        set internalValue(value: ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatProperty | undefined);
        private _recordFormatType?;
        get recordFormatType(): string;
        set recordFormatType(value: string);
        get recordFormatTypeInput(): string | undefined;
        private _mappingParameters;
        get mappingParameters(): ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatMappingParametersPropertyOutputReference;
        putMappingParameters(value: ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatMappingParametersProperty): void;
        get mappingParametersInput(): ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatMappingParametersProperty | undefined;
    }
    interface InputSchemaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#record_encoding AwsKinesisanalyticsv2Application#record_encoding}
        */
        readonly recordEncoding?: string;
        /**
        * record_column block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#record_column AwsKinesisanalyticsv2Application#record_column}
        */
        readonly recordColumn: ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordColumnProperty[] | cdktn.IResolvable;
        /**
        * record_format block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#record_format AwsKinesisanalyticsv2Application#record_format}
        */
        readonly recordFormat: ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatProperty;
    }
    class InputSchemaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InputSchemaProperty | undefined;
        set internalValue(value: InputSchemaProperty | undefined);
        private _recordEncoding?;
        get recordEncoding(): string;
        set recordEncoding(value: string);
        resetRecordEncoding(): void;
        get recordEncodingInput(): string | undefined;
        private _recordColumn;
        get recordColumn(): ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordColumnPropertyList;
        putRecordColumn(value: ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordColumnProperty[] | cdktn.IResolvable): void;
        get recordColumnInput(): cdktn.IResolvable | ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordColumnProperty[] | undefined;
        private _recordFormat;
        get recordFormat(): ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatPropertyOutputReference;
        putRecordFormat(value: ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatProperty): void;
        get recordFormatInput(): ApplicationConfigurationSqlApplicationConfigurationInputInputSchemaRecordFormatProperty | undefined;
    }
    interface InputStartingPositionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#input_starting_position AwsKinesisanalyticsv2Application#input_starting_position}
        */
        readonly inputStartingPosition?: string;
    }
    class InputStartingPositionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InputStartingPositionConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InputStartingPositionConfigurationProperty | cdktn.IResolvable | undefined);
        private _inputStartingPosition?;
        get inputStartingPosition(): string;
        set inputStartingPosition(value: string);
        resetInputStartingPosition(): void;
        get inputStartingPositionInput(): string | undefined;
    }
    class InputStartingPositionConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: InputStartingPositionConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InputStartingPositionConfigurationPropertyOutputReference;
    }
    interface KinesisFirehoseInputProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#resource_arn AwsKinesisanalyticsv2Application#resource_arn}
        */
        readonly resourceArn: string;
    }
    class KinesisFirehoseInputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KinesisFirehoseInputProperty | undefined;
        set internalValue(value: KinesisFirehoseInputProperty | undefined);
        private _resourceArn?;
        get resourceArn(): string;
        set resourceArn(value: string);
        get resourceArnInput(): string | undefined;
    }
    interface KinesisStreamsInputProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#resource_arn AwsKinesisanalyticsv2Application#resource_arn}
        */
        readonly resourceArn: string;
    }
    class KinesisStreamsInputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KinesisStreamsInputProperty | undefined;
        set internalValue(value: KinesisStreamsInputProperty | undefined);
        private _resourceArn?;
        get resourceArn(): string;
        set resourceArn(value: string);
        get resourceArnInput(): string | undefined;
    }
    interface InputProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#name_prefix AwsKinesisanalyticsv2Application#name_prefix}
        */
        readonly namePrefix: string;
        /**
        * input_parallelism block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#input_parallelism AwsKinesisanalyticsv2Application#input_parallelism}
        */
        readonly inputParallelism?: InputParallelismProperty;
        /**
        * input_processing_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#input_processing_configuration AwsKinesisanalyticsv2Application#input_processing_configuration}
        */
        readonly inputProcessingConfiguration?: InputProcessingConfigurationProperty;
        /**
        * input_schema block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#input_schema AwsKinesisanalyticsv2Application#input_schema}
        */
        readonly inputSchema: InputSchemaProperty;
        /**
        * input_starting_position_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#input_starting_position_configuration AwsKinesisanalyticsv2Application#input_starting_position_configuration}
        */
        readonly inputStartingPositionConfiguration?: InputStartingPositionConfigurationProperty[] | cdktn.IResolvable;
        /**
        * kinesis_firehose_input block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#kinesis_firehose_input AwsKinesisanalyticsv2Application#kinesis_firehose_input}
        */
        readonly kinesisFirehoseInput?: KinesisFirehoseInputProperty;
        /**
        * kinesis_streams_input block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#kinesis_streams_input AwsKinesisanalyticsv2Application#kinesis_streams_input}
        */
        readonly kinesisStreamsInput?: KinesisStreamsInputProperty;
    }
    class InputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InputProperty | undefined;
        set internalValue(value: InputProperty | undefined);
        get inAppStreamNames(): string[];
        get inputId(): string;
        private _namePrefix?;
        get namePrefix(): string;
        set namePrefix(value: string);
        get namePrefixInput(): string | undefined;
        private _inputParallelism;
        get inputParallelism(): InputParallelismPropertyOutputReference;
        putInputParallelism(value: InputParallelismProperty): void;
        resetInputParallelism(): void;
        get inputParallelismInput(): InputParallelismProperty | undefined;
        private _inputProcessingConfiguration;
        get inputProcessingConfiguration(): InputProcessingConfigurationPropertyOutputReference;
        putInputProcessingConfiguration(value: InputProcessingConfigurationProperty): void;
        resetInputProcessingConfiguration(): void;
        get inputProcessingConfigurationInput(): InputProcessingConfigurationProperty | undefined;
        private _inputSchema;
        get inputSchema(): InputSchemaPropertyOutputReference;
        putInputSchema(value: InputSchemaProperty): void;
        get inputSchemaInput(): InputSchemaProperty | undefined;
        private _inputStartingPositionConfiguration;
        get inputStartingPositionConfiguration(): InputStartingPositionConfigurationPropertyList;
        putInputStartingPositionConfiguration(value: InputStartingPositionConfigurationProperty[] | cdktn.IResolvable): void;
        resetInputStartingPositionConfiguration(): void;
        get inputStartingPositionConfigurationInput(): cdktn.IResolvable | InputStartingPositionConfigurationProperty[] | undefined;
        private _kinesisFirehoseInput;
        get kinesisFirehoseInput(): KinesisFirehoseInputPropertyOutputReference;
        putKinesisFirehoseInput(value: KinesisFirehoseInputProperty): void;
        resetKinesisFirehoseInput(): void;
        get kinesisFirehoseInputInput(): KinesisFirehoseInputProperty | undefined;
        private _kinesisStreamsInput;
        get kinesisStreamsInput(): KinesisStreamsInputPropertyOutputReference;
        putKinesisStreamsInput(value: KinesisStreamsInputProperty): void;
        resetKinesisStreamsInput(): void;
        get kinesisStreamsInputInput(): KinesisStreamsInputProperty | undefined;
    }
    interface DestinationSchemaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#record_format_type AwsKinesisanalyticsv2Application#record_format_type}
        */
        readonly recordFormatType: string;
    }
    class DestinationSchemaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationSchemaProperty | undefined;
        set internalValue(value: DestinationSchemaProperty | undefined);
        private _recordFormatType?;
        get recordFormatType(): string;
        set recordFormatType(value: string);
        get recordFormatTypeInput(): string | undefined;
    }
    interface KinesisFirehoseOutputProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#resource_arn AwsKinesisanalyticsv2Application#resource_arn}
        */
        readonly resourceArn: string;
    }
    class KinesisFirehoseOutputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KinesisFirehoseOutputProperty | undefined;
        set internalValue(value: KinesisFirehoseOutputProperty | undefined);
        private _resourceArn?;
        get resourceArn(): string;
        set resourceArn(value: string);
        get resourceArnInput(): string | undefined;
    }
    interface KinesisStreamsOutputProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#resource_arn AwsKinesisanalyticsv2Application#resource_arn}
        */
        readonly resourceArn: string;
    }
    class KinesisStreamsOutputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KinesisStreamsOutputProperty | undefined;
        set internalValue(value: KinesisStreamsOutputProperty | undefined);
        private _resourceArn?;
        get resourceArn(): string;
        set resourceArn(value: string);
        get resourceArnInput(): string | undefined;
    }
    interface LambdaOutputProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#resource_arn AwsKinesisanalyticsv2Application#resource_arn}
        */
        readonly resourceArn: string;
    }
    class LambdaOutputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LambdaOutputProperty | undefined;
        set internalValue(value: LambdaOutputProperty | undefined);
        private _resourceArn?;
        get resourceArn(): string;
        set resourceArn(value: string);
        get resourceArnInput(): string | undefined;
    }
    interface OutputProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#name AwsKinesisanalyticsv2Application#name}
        */
        readonly name: string;
        /**
        * destination_schema block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#destination_schema AwsKinesisanalyticsv2Application#destination_schema}
        */
        readonly destinationSchema: DestinationSchemaProperty;
        /**
        * kinesis_firehose_output block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#kinesis_firehose_output AwsKinesisanalyticsv2Application#kinesis_firehose_output}
        */
        readonly kinesisFirehoseOutput?: KinesisFirehoseOutputProperty;
        /**
        * kinesis_streams_output block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#kinesis_streams_output AwsKinesisanalyticsv2Application#kinesis_streams_output}
        */
        readonly kinesisStreamsOutput?: KinesisStreamsOutputProperty;
        /**
        * lambda_output block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#lambda_output AwsKinesisanalyticsv2Application#lambda_output}
        */
        readonly lambdaOutput?: LambdaOutputProperty;
    }
    class OutputPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OutputProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OutputProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        get outputId(): string;
        private _destinationSchema;
        get destinationSchema(): DestinationSchemaPropertyOutputReference;
        putDestinationSchema(value: DestinationSchemaProperty): void;
        get destinationSchemaInput(): DestinationSchemaProperty | undefined;
        private _kinesisFirehoseOutput;
        get kinesisFirehoseOutput(): KinesisFirehoseOutputPropertyOutputReference;
        putKinesisFirehoseOutput(value: KinesisFirehoseOutputProperty): void;
        resetKinesisFirehoseOutput(): void;
        get kinesisFirehoseOutputInput(): KinesisFirehoseOutputProperty | undefined;
        private _kinesisStreamsOutput;
        get kinesisStreamsOutput(): KinesisStreamsOutputPropertyOutputReference;
        putKinesisStreamsOutput(value: KinesisStreamsOutputProperty): void;
        resetKinesisStreamsOutput(): void;
        get kinesisStreamsOutputInput(): KinesisStreamsOutputProperty | undefined;
        private _lambdaOutput;
        get lambdaOutput(): LambdaOutputPropertyOutputReference;
        putLambdaOutput(value: LambdaOutputProperty): void;
        resetLambdaOutput(): void;
        get lambdaOutputInput(): LambdaOutputProperty | undefined;
    }
    class OutputPropertyList extends cdktn.ComplexList {
        internalValue?: OutputProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OutputPropertyOutputReference;
    }
    interface ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordColumnProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#mapping AwsKinesisanalyticsv2Application#mapping}
        */
        readonly mapping?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#name AwsKinesisanalyticsv2Application#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#sql_type AwsKinesisanalyticsv2Application#sql_type}
        */
        readonly sqlType: string;
    }
    class ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordColumnPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordColumnProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordColumnProperty | cdktn.IResolvable | undefined);
        private _mapping?;
        get mapping(): string;
        set mapping(value: string);
        resetMapping(): void;
        get mappingInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _sqlType?;
        get sqlType(): string;
        set sqlType(value: string);
        get sqlTypeInput(): string | undefined;
    }
    class ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordColumnPropertyList extends cdktn.ComplexList {
        internalValue?: ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordColumnProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordColumnPropertyOutputReference;
    }
    interface ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatMappingParametersCsvMappingParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#record_column_delimiter AwsKinesisanalyticsv2Application#record_column_delimiter}
        */
        readonly recordColumnDelimiter: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#record_row_delimiter AwsKinesisanalyticsv2Application#record_row_delimiter}
        */
        readonly recordRowDelimiter: string;
    }
    class ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatMappingParametersCsvMappingParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatMappingParametersCsvMappingParametersProperty | undefined;
        set internalValue(value: ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatMappingParametersCsvMappingParametersProperty | undefined);
        private _recordColumnDelimiter?;
        get recordColumnDelimiter(): string;
        set recordColumnDelimiter(value: string);
        get recordColumnDelimiterInput(): string | undefined;
        private _recordRowDelimiter?;
        get recordRowDelimiter(): string;
        set recordRowDelimiter(value: string);
        get recordRowDelimiterInput(): string | undefined;
    }
    interface ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatMappingParametersJsonMappingParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#record_row_path AwsKinesisanalyticsv2Application#record_row_path}
        */
        readonly recordRowPath: string;
    }
    class ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatMappingParametersJsonMappingParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatMappingParametersJsonMappingParametersProperty | undefined;
        set internalValue(value: ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatMappingParametersJsonMappingParametersProperty | undefined);
        private _recordRowPath?;
        get recordRowPath(): string;
        set recordRowPath(value: string);
        get recordRowPathInput(): string | undefined;
    }
    interface ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatMappingParametersProperty {
        /**
        * csv_mapping_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#csv_mapping_parameters AwsKinesisanalyticsv2Application#csv_mapping_parameters}
        */
        readonly csvMappingParameters?: ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatMappingParametersCsvMappingParametersProperty;
        /**
        * json_mapping_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#json_mapping_parameters AwsKinesisanalyticsv2Application#json_mapping_parameters}
        */
        readonly jsonMappingParameters?: ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatMappingParametersJsonMappingParametersProperty;
    }
    class ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatMappingParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatMappingParametersProperty | undefined;
        set internalValue(value: ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatMappingParametersProperty | undefined);
        private _csvMappingParameters;
        get csvMappingParameters(): ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatMappingParametersCsvMappingParametersPropertyOutputReference;
        putCsvMappingParameters(value: ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatMappingParametersCsvMappingParametersProperty): void;
        resetCsvMappingParameters(): void;
        get csvMappingParametersInput(): ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatMappingParametersCsvMappingParametersProperty | undefined;
        private _jsonMappingParameters;
        get jsonMappingParameters(): ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatMappingParametersJsonMappingParametersPropertyOutputReference;
        putJsonMappingParameters(value: ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatMappingParametersJsonMappingParametersProperty): void;
        resetJsonMappingParameters(): void;
        get jsonMappingParametersInput(): ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatMappingParametersJsonMappingParametersProperty | undefined;
    }
    interface ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#record_format_type AwsKinesisanalyticsv2Application#record_format_type}
        */
        readonly recordFormatType: string;
        /**
        * mapping_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#mapping_parameters AwsKinesisanalyticsv2Application#mapping_parameters}
        */
        readonly mappingParameters: ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatMappingParametersProperty;
    }
    class ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatProperty | undefined;
        set internalValue(value: ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatProperty | undefined);
        private _recordFormatType?;
        get recordFormatType(): string;
        set recordFormatType(value: string);
        get recordFormatTypeInput(): string | undefined;
        private _mappingParameters;
        get mappingParameters(): ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatMappingParametersPropertyOutputReference;
        putMappingParameters(value: ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatMappingParametersProperty): void;
        get mappingParametersInput(): ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatMappingParametersProperty | undefined;
    }
    interface ReferenceSchemaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#record_encoding AwsKinesisanalyticsv2Application#record_encoding}
        */
        readonly recordEncoding?: string;
        /**
        * record_column block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#record_column AwsKinesisanalyticsv2Application#record_column}
        */
        readonly recordColumn: ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordColumnProperty[] | cdktn.IResolvable;
        /**
        * record_format block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#record_format AwsKinesisanalyticsv2Application#record_format}
        */
        readonly recordFormat: ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatProperty;
    }
    class ReferenceSchemaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ReferenceSchemaProperty | undefined;
        set internalValue(value: ReferenceSchemaProperty | undefined);
        private _recordEncoding?;
        get recordEncoding(): string;
        set recordEncoding(value: string);
        resetRecordEncoding(): void;
        get recordEncodingInput(): string | undefined;
        private _recordColumn;
        get recordColumn(): ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordColumnPropertyList;
        putRecordColumn(value: ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordColumnProperty[] | cdktn.IResolvable): void;
        get recordColumnInput(): cdktn.IResolvable | ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordColumnProperty[] | undefined;
        private _recordFormat;
        get recordFormat(): ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatPropertyOutputReference;
        putRecordFormat(value: ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatProperty): void;
        get recordFormatInput(): ApplicationConfigurationSqlApplicationConfigurationReferenceDataSourceReferenceSchemaRecordFormatProperty | undefined;
    }
    interface S3ReferenceDataSourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#bucket_arn AwsKinesisanalyticsv2Application#bucket_arn}
        */
        readonly bucketArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#file_key AwsKinesisanalyticsv2Application#file_key}
        */
        readonly fileKey: string;
    }
    class S3ReferenceDataSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3ReferenceDataSourceProperty | undefined;
        set internalValue(value: S3ReferenceDataSourceProperty | undefined);
        private _bucketArn?;
        get bucketArn(): string;
        set bucketArn(value: string);
        get bucketArnInput(): string | undefined;
        private _fileKey?;
        get fileKey(): string;
        set fileKey(value: string);
        get fileKeyInput(): string | undefined;
    }
    interface ReferenceDataSourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#table_name AwsKinesisanalyticsv2Application#table_name}
        */
        readonly tableName: string;
        /**
        * reference_schema block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#reference_schema AwsKinesisanalyticsv2Application#reference_schema}
        */
        readonly referenceSchema: ReferenceSchemaProperty;
        /**
        * s3_reference_data_source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#s3_reference_data_source AwsKinesisanalyticsv2Application#s3_reference_data_source}
        */
        readonly s3ReferenceDataSource: S3ReferenceDataSourceProperty;
    }
    class ReferenceDataSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ReferenceDataSourceProperty | undefined;
        set internalValue(value: ReferenceDataSourceProperty | undefined);
        get referenceId(): string;
        private _tableName?;
        get tableName(): string;
        set tableName(value: string);
        get tableNameInput(): string | undefined;
        private _referenceSchema;
        get referenceSchema(): ReferenceSchemaPropertyOutputReference;
        putReferenceSchema(value: ReferenceSchemaProperty): void;
        get referenceSchemaInput(): ReferenceSchemaProperty | undefined;
        private _s3ReferenceDataSource;
        get s3ReferenceDataSource(): S3ReferenceDataSourcePropertyOutputReference;
        putS3ReferenceDataSource(value: S3ReferenceDataSourceProperty): void;
        get s3ReferenceDataSourceInput(): S3ReferenceDataSourceProperty | undefined;
    }
    interface SqlApplicationConfigurationProperty {
        /**
        * input block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#input AwsKinesisanalyticsv2Application#input}
        */
        readonly input?: InputProperty;
        /**
        * output block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#output AwsKinesisanalyticsv2Application#output}
        */
        readonly output?: OutputProperty[] | cdktn.IResolvable;
        /**
        * reference_data_source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#reference_data_source AwsKinesisanalyticsv2Application#reference_data_source}
        */
        readonly referenceDataSource?: ReferenceDataSourceProperty;
    }
    class SqlApplicationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SqlApplicationConfigurationProperty | undefined;
        set internalValue(value: SqlApplicationConfigurationProperty | undefined);
        private _input;
        get input(): InputPropertyOutputReference;
        putInput(value: InputProperty): void;
        resetInput(): void;
        get inputInput(): InputProperty | undefined;
        private _output;
        get output(): OutputPropertyList;
        putOutput(value: OutputProperty[] | cdktn.IResolvable): void;
        resetOutput(): void;
        get outputInput(): cdktn.IResolvable | OutputProperty[] | undefined;
        private _referenceDataSource;
        get referenceDataSource(): ReferenceDataSourcePropertyOutputReference;
        putReferenceDataSource(value: ReferenceDataSourceProperty): void;
        resetReferenceDataSource(): void;
        get referenceDataSourceInput(): ReferenceDataSourceProperty | undefined;
    }
    interface VpcConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#security_group_ids AwsKinesisanalyticsv2Application#security_group_ids}
        */
        readonly securityGroupIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#subnet_ids AwsKinesisanalyticsv2Application#subnet_ids}
        */
        readonly subnetIds: string[];
    }
    class VpcConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcConfigurationProperty | undefined;
        set internalValue(value: VpcConfigurationProperty | undefined);
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
        get vpcConfigurationId(): string;
        get vpcId(): string;
    }
    interface ApplicationConfigurationProperty {
        /**
        * application_code_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#application_code_configuration AwsKinesisanalyticsv2Application#application_code_configuration}
        */
        readonly applicationCodeConfiguration: ApplicationCodeConfigurationProperty;
        /**
        * application_encryption_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#application_encryption_configuration AwsKinesisanalyticsv2Application#application_encryption_configuration}
        */
        readonly applicationEncryptionConfiguration?: ApplicationEncryptionConfigurationProperty;
        /**
        * application_snapshot_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#application_snapshot_configuration AwsKinesisanalyticsv2Application#application_snapshot_configuration}
        */
        readonly applicationSnapshotConfiguration?: ApplicationSnapshotConfigurationProperty;
        /**
        * environment_properties block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#environment_properties AwsKinesisanalyticsv2Application#environment_properties}
        */
        readonly environmentProperties?: EnvironmentPropertiesProperty;
        /**
        * flink_application_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#flink_application_configuration AwsKinesisanalyticsv2Application#flink_application_configuration}
        */
        readonly flinkApplicationConfiguration?: FlinkApplicationConfigurationProperty;
        /**
        * run_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#run_configuration AwsKinesisanalyticsv2Application#run_configuration}
        */
        readonly runConfiguration?: RunConfigurationProperty;
        /**
        * sql_application_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#sql_application_configuration AwsKinesisanalyticsv2Application#sql_application_configuration}
        */
        readonly sqlApplicationConfiguration?: SqlApplicationConfigurationProperty;
        /**
        * vpc_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#vpc_configuration AwsKinesisanalyticsv2Application#vpc_configuration}
        */
        readonly vpcConfiguration?: VpcConfigurationProperty;
    }
    class ApplicationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ApplicationConfigurationProperty | undefined;
        set internalValue(value: ApplicationConfigurationProperty | undefined);
        private _applicationCodeConfiguration;
        get applicationCodeConfiguration(): ApplicationCodeConfigurationPropertyOutputReference;
        putApplicationCodeConfiguration(value: ApplicationCodeConfigurationProperty): void;
        get applicationCodeConfigurationInput(): ApplicationCodeConfigurationProperty | undefined;
        private _applicationEncryptionConfiguration;
        get applicationEncryptionConfiguration(): ApplicationEncryptionConfigurationPropertyOutputReference;
        putApplicationEncryptionConfiguration(value: ApplicationEncryptionConfigurationProperty): void;
        resetApplicationEncryptionConfiguration(): void;
        get applicationEncryptionConfigurationInput(): ApplicationEncryptionConfigurationProperty | undefined;
        private _applicationSnapshotConfiguration;
        get applicationSnapshotConfiguration(): ApplicationSnapshotConfigurationPropertyOutputReference;
        putApplicationSnapshotConfiguration(value: ApplicationSnapshotConfigurationProperty): void;
        resetApplicationSnapshotConfiguration(): void;
        get applicationSnapshotConfigurationInput(): ApplicationSnapshotConfigurationProperty | undefined;
        private _environmentProperties;
        get environmentProperties(): EnvironmentPropertiesPropertyOutputReference;
        putEnvironmentProperties(value: EnvironmentPropertiesProperty): void;
        resetEnvironmentProperties(): void;
        get environmentPropertiesInput(): EnvironmentPropertiesProperty | undefined;
        private _flinkApplicationConfiguration;
        get flinkApplicationConfiguration(): FlinkApplicationConfigurationPropertyOutputReference;
        putFlinkApplicationConfiguration(value: FlinkApplicationConfigurationProperty): void;
        resetFlinkApplicationConfiguration(): void;
        get flinkApplicationConfigurationInput(): FlinkApplicationConfigurationProperty | undefined;
        private _runConfiguration;
        get runConfiguration(): RunConfigurationPropertyOutputReference;
        putRunConfiguration(value: RunConfigurationProperty): void;
        resetRunConfiguration(): void;
        get runConfigurationInput(): RunConfigurationProperty | undefined;
        private _sqlApplicationConfiguration;
        get sqlApplicationConfiguration(): SqlApplicationConfigurationPropertyOutputReference;
        putSqlApplicationConfiguration(value: SqlApplicationConfigurationProperty): void;
        resetSqlApplicationConfiguration(): void;
        get sqlApplicationConfigurationInput(): SqlApplicationConfigurationProperty | undefined;
        private _vpcConfiguration;
        get vpcConfiguration(): VpcConfigurationPropertyOutputReference;
        putVpcConfiguration(value: VpcConfigurationProperty): void;
        resetVpcConfiguration(): void;
        get vpcConfigurationInput(): VpcConfigurationProperty | undefined;
    }
    interface CloudwatchLoggingOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#log_stream_arn AwsKinesisanalyticsv2Application#log_stream_arn}
        */
        readonly logStreamArn: string;
    }
    class CloudwatchLoggingOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CloudwatchLoggingOptionsProperty | undefined;
        set internalValue(value: CloudwatchLoggingOptionsProperty | undefined);
        get cloudwatchLoggingOptionId(): string;
        private _logStreamArn?;
        get logStreamArn(): string;
        set logStreamArn(value: string);
        get logStreamArnInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#create AwsKinesisanalyticsv2Application#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#delete AwsKinesisanalyticsv2Application#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application#update AwsKinesisanalyticsv2Application#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
