import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsKinesisanalyticsv2ApplicationSnapshotConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application_snapshot#application_name AwsKinesisanalyticsv2ApplicationSnapshot#application_name}
    */
    readonly applicationName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application_snapshot#id AwsKinesisanalyticsv2ApplicationSnapshot#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application_snapshot#region AwsKinesisanalyticsv2ApplicationSnapshot#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application_snapshot#snapshot_name AwsKinesisanalyticsv2ApplicationSnapshot#snapshot_name}
    */
    readonly snapshotName: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application_snapshot#timeouts AwsKinesisanalyticsv2ApplicationSnapshot#timeouts}
    */
    readonly timeouts?: AwsKinesisanalyticsv2ApplicationSnapshot.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application_snapshot aws_kinesisanalyticsv2_application_snapshot}
*/
export declare class AwsKinesisanalyticsv2ApplicationSnapshot extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_kinesisanalyticsv2_application_snapshot";
    /**
    * Generates CDKTN code for importing a AwsKinesisanalyticsv2ApplicationSnapshot resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsKinesisanalyticsv2ApplicationSnapshot to import
    * @param importFromId The id of the existing AwsKinesisanalyticsv2ApplicationSnapshot that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application_snapshot#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsKinesisanalyticsv2ApplicationSnapshot to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application_snapshot aws_kinesisanalyticsv2_application_snapshot} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsKinesisanalyticsv2ApplicationSnapshotConfig
    */
    constructor(scope: Construct, id: string, config: AwsKinesisanalyticsv2ApplicationSnapshotConfig);
    private _applicationName?;
    get applicationName(): string;
    set applicationName(value: string);
    get applicationNameInput(): string | undefined;
    get applicationVersionId(): number;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get snapshotCreationTimestamp(): string;
    private _snapshotName?;
    get snapshotName(): string;
    set snapshotName(value: string);
    get snapshotNameInput(): string | undefined;
    private _timeouts;
    get timeouts(): AwsKinesisanalyticsv2ApplicationSnapshot.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsKinesisanalyticsv2ApplicationSnapshot.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): AwsKinesisanalyticsv2ApplicationSnapshot.TimeoutsProperty | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsKinesisanalyticsv2ApplicationSnapshotTimeoutsPropertyToTerraform(struct?: AwsKinesisanalyticsv2ApplicationSnapshot.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsKinesisanalyticsv2ApplicationSnapshotTimeoutsPropertyToHclTerraform(struct?: AwsKinesisanalyticsv2ApplicationSnapshot.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsKinesisanalyticsv2ApplicationSnapshot {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application_snapshot#create AwsKinesisanalyticsv2ApplicationSnapshot#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesisanalyticsv2_application_snapshot#delete AwsKinesisanalyticsv2ApplicationSnapshot#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
