import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsRegisteredDomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#admin_privacy AwsRegisteredDomain#admin_privacy}
    */
    readonly adminPrivacy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#auto_renew AwsRegisteredDomain#auto_renew}
    */
    readonly autoRenew?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#billing_privacy AwsRegisteredDomain#billing_privacy}
    */
    readonly billingPrivacy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#domain_name AwsRegisteredDomain#domain_name}
    */
    readonly domainName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#id AwsRegisteredDomain#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#registrant_privacy AwsRegisteredDomain#registrant_privacy}
    */
    readonly registrantPrivacy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#tags AwsRegisteredDomain#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#tags_all AwsRegisteredDomain#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#tech_privacy AwsRegisteredDomain#tech_privacy}
    */
    readonly techPrivacy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#transfer_lock AwsRegisteredDomain#transfer_lock}
    */
    readonly transferLock?: boolean | cdktn.IResolvable;
    /**
    * admin_contact block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#admin_contact AwsRegisteredDomain#admin_contact}
    */
    readonly adminContact?: AwsRegisteredDomain.AdminContactProperty;
    /**
    * billing_contact block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#billing_contact AwsRegisteredDomain#billing_contact}
    */
    readonly billingContact?: AwsRegisteredDomain.BillingContactProperty;
    /**
    * name_server block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#name_server AwsRegisteredDomain#name_server}
    */
    readonly nameServer?: AwsRegisteredDomain.NameServerProperty[] | cdktn.IResolvable;
    /**
    * registrant_contact block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#registrant_contact AwsRegisteredDomain#registrant_contact}
    */
    readonly registrantContact?: AwsRegisteredDomain.RegistrantContactProperty;
    /**
    * tech_contact block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#tech_contact AwsRegisteredDomain#tech_contact}
    */
    readonly techContact?: AwsRegisteredDomain.TechContactProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#timeouts AwsRegisteredDomain#timeouts}
    */
    readonly timeouts?: AwsRegisteredDomain.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain aws_route53domains_registered_domain}
*/
export declare class AwsRegisteredDomain extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_route53domains_registered_domain";
    /**
    * Generates CDKTN code for importing a AwsRegisteredDomain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsRegisteredDomain to import
    * @param importFromId The id of the existing AwsRegisteredDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsRegisteredDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain aws_route53domains_registered_domain} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsRegisteredDomainConfig
    */
    constructor(scope: Construct, id: string, config: AwsRegisteredDomainConfig);
    get abuseContactEmail(): string;
    get abuseContactPhone(): string;
    private _adminPrivacy?;
    get adminPrivacy(): boolean | cdktn.IResolvable;
    set adminPrivacy(value: boolean | cdktn.IResolvable);
    resetAdminPrivacy(): void;
    get adminPrivacyInput(): boolean | cdktn.IResolvable | undefined;
    private _autoRenew?;
    get autoRenew(): boolean | cdktn.IResolvable;
    set autoRenew(value: boolean | cdktn.IResolvable);
    resetAutoRenew(): void;
    get autoRenewInput(): boolean | cdktn.IResolvable | undefined;
    private _billingPrivacy?;
    get billingPrivacy(): boolean | cdktn.IResolvable;
    set billingPrivacy(value: boolean | cdktn.IResolvable);
    resetBillingPrivacy(): void;
    get billingPrivacyInput(): boolean | cdktn.IResolvable | undefined;
    get creationDate(): string;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    get expirationDate(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _registrantPrivacy?;
    get registrantPrivacy(): boolean | cdktn.IResolvable;
    set registrantPrivacy(value: boolean | cdktn.IResolvable);
    resetRegistrantPrivacy(): void;
    get registrantPrivacyInput(): boolean | cdktn.IResolvable | undefined;
    get registrarName(): string;
    get registrarUrl(): string;
    get reseller(): string;
    get statusList(): string[];
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _techPrivacy?;
    get techPrivacy(): boolean | cdktn.IResolvable;
    set techPrivacy(value: boolean | cdktn.IResolvable);
    resetTechPrivacy(): void;
    get techPrivacyInput(): boolean | cdktn.IResolvable | undefined;
    private _transferLock?;
    get transferLock(): boolean | cdktn.IResolvable;
    set transferLock(value: boolean | cdktn.IResolvable);
    resetTransferLock(): void;
    get transferLockInput(): boolean | cdktn.IResolvable | undefined;
    get updatedDate(): string;
    get whoisServer(): string;
    private _adminContact;
    get adminContact(): AwsRegisteredDomain.AdminContactPropertyOutputReference;
    putAdminContact(value: AwsRegisteredDomain.AdminContactProperty): void;
    resetAdminContact(): void;
    get adminContactInput(): AwsRegisteredDomain.AdminContactProperty | undefined;
    private _billingContact;
    get billingContact(): AwsRegisteredDomain.BillingContactPropertyOutputReference;
    putBillingContact(value: AwsRegisteredDomain.BillingContactProperty): void;
    resetBillingContact(): void;
    get billingContactInput(): AwsRegisteredDomain.BillingContactProperty | undefined;
    private _nameServer;
    get nameServer(): AwsRegisteredDomain.NameServerPropertyList;
    putNameServer(value: AwsRegisteredDomain.NameServerProperty[] | cdktn.IResolvable): void;
    resetNameServer(): void;
    get nameServerInput(): cdktn.IResolvable | AwsRegisteredDomain.NameServerProperty[] | undefined;
    private _registrantContact;
    get registrantContact(): AwsRegisteredDomain.RegistrantContactPropertyOutputReference;
    putRegistrantContact(value: AwsRegisteredDomain.RegistrantContactProperty): void;
    resetRegistrantContact(): void;
    get registrantContactInput(): AwsRegisteredDomain.RegistrantContactProperty | undefined;
    private _techContact;
    get techContact(): AwsRegisteredDomain.TechContactPropertyOutputReference;
    putTechContact(value: AwsRegisteredDomain.TechContactProperty): void;
    resetTechContact(): void;
    get techContactInput(): AwsRegisteredDomain.TechContactProperty | undefined;
    private _timeouts;
    get timeouts(): AwsRegisteredDomain.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsRegisteredDomain.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsRegisteredDomain.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsRegisteredDomainAdminContactPropertyToTerraform(struct?: AwsRegisteredDomain.AdminContactPropertyOutputReference | AwsRegisteredDomain.AdminContactProperty): any;
export declare function awsRegisteredDomainAdminContactPropertyToHclTerraform(struct?: AwsRegisteredDomain.AdminContactPropertyOutputReference | AwsRegisteredDomain.AdminContactProperty): any;
export declare function awsRegisteredDomainBillingContactPropertyToTerraform(struct?: AwsRegisteredDomain.BillingContactPropertyOutputReference | AwsRegisteredDomain.BillingContactProperty): any;
export declare function awsRegisteredDomainBillingContactPropertyToHclTerraform(struct?: AwsRegisteredDomain.BillingContactPropertyOutputReference | AwsRegisteredDomain.BillingContactProperty): any;
export declare function awsRegisteredDomainNameServerPropertyToTerraform(struct?: AwsRegisteredDomain.NameServerProperty | cdktn.IResolvable): any;
export declare function awsRegisteredDomainNameServerPropertyToHclTerraform(struct?: AwsRegisteredDomain.NameServerProperty | cdktn.IResolvable): any;
export declare function awsRegisteredDomainRegistrantContactPropertyToTerraform(struct?: AwsRegisteredDomain.RegistrantContactPropertyOutputReference | AwsRegisteredDomain.RegistrantContactProperty): any;
export declare function awsRegisteredDomainRegistrantContactPropertyToHclTerraform(struct?: AwsRegisteredDomain.RegistrantContactPropertyOutputReference | AwsRegisteredDomain.RegistrantContactProperty): any;
export declare function awsRegisteredDomainTechContactPropertyToTerraform(struct?: AwsRegisteredDomain.TechContactPropertyOutputReference | AwsRegisteredDomain.TechContactProperty): any;
export declare function awsRegisteredDomainTechContactPropertyToHclTerraform(struct?: AwsRegisteredDomain.TechContactPropertyOutputReference | AwsRegisteredDomain.TechContactProperty): any;
export declare function awsRegisteredDomainTimeoutsPropertyToTerraform(struct?: AwsRegisteredDomain.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsRegisteredDomainTimeoutsPropertyToHclTerraform(struct?: AwsRegisteredDomain.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsRegisteredDomain {
    interface AdminContactProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#address_line_1 AwsRegisteredDomain#address_line_1}
        */
        readonly addressLine1?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#address_line_2 AwsRegisteredDomain#address_line_2}
        */
        readonly addressLine2?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#city AwsRegisteredDomain#city}
        */
        readonly city?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#contact_type AwsRegisteredDomain#contact_type}
        */
        readonly contactType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#country_code AwsRegisteredDomain#country_code}
        */
        readonly countryCode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#email AwsRegisteredDomain#email}
        */
        readonly email?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#extra_params AwsRegisteredDomain#extra_params}
        */
        readonly extraParams?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#fax AwsRegisteredDomain#fax}
        */
        readonly fax?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#first_name AwsRegisteredDomain#first_name}
        */
        readonly firstName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#last_name AwsRegisteredDomain#last_name}
        */
        readonly lastName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#organization_name AwsRegisteredDomain#organization_name}
        */
        readonly organizationName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#phone_number AwsRegisteredDomain#phone_number}
        */
        readonly phoneNumber?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#state AwsRegisteredDomain#state}
        */
        readonly state?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#zip_code AwsRegisteredDomain#zip_code}
        */
        readonly zipCode?: string;
    }
    class AdminContactPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AdminContactProperty | undefined;
        set internalValue(value: AdminContactProperty | undefined);
        private _addressLine1?;
        get addressLine1(): string;
        set addressLine1(value: string);
        resetAddressLine1(): void;
        get addressLine1Input(): string | undefined;
        private _addressLine2?;
        get addressLine2(): string;
        set addressLine2(value: string);
        resetAddressLine2(): void;
        get addressLine2Input(): string | undefined;
        private _city?;
        get city(): string;
        set city(value: string);
        resetCity(): void;
        get cityInput(): string | undefined;
        private _contactType?;
        get contactType(): string;
        set contactType(value: string);
        resetContactType(): void;
        get contactTypeInput(): string | undefined;
        private _countryCode?;
        get countryCode(): string;
        set countryCode(value: string);
        resetCountryCode(): void;
        get countryCodeInput(): string | undefined;
        private _email?;
        get email(): string;
        set email(value: string);
        resetEmail(): void;
        get emailInput(): string | undefined;
        private _extraParams?;
        get extraParams(): {
            [key: string]: string;
        };
        set extraParams(value: {
            [key: string]: string;
        });
        resetExtraParams(): void;
        get extraParamsInput(): {
            [key: string]: string;
        } | undefined;
        private _fax?;
        get fax(): string;
        set fax(value: string);
        resetFax(): void;
        get faxInput(): string | undefined;
        private _firstName?;
        get firstName(): string;
        set firstName(value: string);
        resetFirstName(): void;
        get firstNameInput(): string | undefined;
        private _lastName?;
        get lastName(): string;
        set lastName(value: string);
        resetLastName(): void;
        get lastNameInput(): string | undefined;
        private _organizationName?;
        get organizationName(): string;
        set organizationName(value: string);
        resetOrganizationName(): void;
        get organizationNameInput(): string | undefined;
        private _phoneNumber?;
        get phoneNumber(): string;
        set phoneNumber(value: string);
        resetPhoneNumber(): void;
        get phoneNumberInput(): string | undefined;
        private _state?;
        get state(): string;
        set state(value: string);
        resetState(): void;
        get stateInput(): string | undefined;
        private _zipCode?;
        get zipCode(): string;
        set zipCode(value: string);
        resetZipCode(): void;
        get zipCodeInput(): string | undefined;
    }
    interface BillingContactProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#address_line_1 AwsRegisteredDomain#address_line_1}
        */
        readonly addressLine1?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#address_line_2 AwsRegisteredDomain#address_line_2}
        */
        readonly addressLine2?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#city AwsRegisteredDomain#city}
        */
        readonly city?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#contact_type AwsRegisteredDomain#contact_type}
        */
        readonly contactType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#country_code AwsRegisteredDomain#country_code}
        */
        readonly countryCode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#email AwsRegisteredDomain#email}
        */
        readonly email?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#extra_params AwsRegisteredDomain#extra_params}
        */
        readonly extraParams?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#fax AwsRegisteredDomain#fax}
        */
        readonly fax?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#first_name AwsRegisteredDomain#first_name}
        */
        readonly firstName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#last_name AwsRegisteredDomain#last_name}
        */
        readonly lastName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#organization_name AwsRegisteredDomain#organization_name}
        */
        readonly organizationName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#phone_number AwsRegisteredDomain#phone_number}
        */
        readonly phoneNumber?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#state AwsRegisteredDomain#state}
        */
        readonly state?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#zip_code AwsRegisteredDomain#zip_code}
        */
        readonly zipCode?: string;
    }
    class BillingContactPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BillingContactProperty | undefined;
        set internalValue(value: BillingContactProperty | undefined);
        private _addressLine1?;
        get addressLine1(): string;
        set addressLine1(value: string);
        resetAddressLine1(): void;
        get addressLine1Input(): string | undefined;
        private _addressLine2?;
        get addressLine2(): string;
        set addressLine2(value: string);
        resetAddressLine2(): void;
        get addressLine2Input(): string | undefined;
        private _city?;
        get city(): string;
        set city(value: string);
        resetCity(): void;
        get cityInput(): string | undefined;
        private _contactType?;
        get contactType(): string;
        set contactType(value: string);
        resetContactType(): void;
        get contactTypeInput(): string | undefined;
        private _countryCode?;
        get countryCode(): string;
        set countryCode(value: string);
        resetCountryCode(): void;
        get countryCodeInput(): string | undefined;
        private _email?;
        get email(): string;
        set email(value: string);
        resetEmail(): void;
        get emailInput(): string | undefined;
        private _extraParams?;
        get extraParams(): {
            [key: string]: string;
        };
        set extraParams(value: {
            [key: string]: string;
        });
        resetExtraParams(): void;
        get extraParamsInput(): {
            [key: string]: string;
        } | undefined;
        private _fax?;
        get fax(): string;
        set fax(value: string);
        resetFax(): void;
        get faxInput(): string | undefined;
        private _firstName?;
        get firstName(): string;
        set firstName(value: string);
        resetFirstName(): void;
        get firstNameInput(): string | undefined;
        private _lastName?;
        get lastName(): string;
        set lastName(value: string);
        resetLastName(): void;
        get lastNameInput(): string | undefined;
        private _organizationName?;
        get organizationName(): string;
        set organizationName(value: string);
        resetOrganizationName(): void;
        get organizationNameInput(): string | undefined;
        private _phoneNumber?;
        get phoneNumber(): string;
        set phoneNumber(value: string);
        resetPhoneNumber(): void;
        get phoneNumberInput(): string | undefined;
        private _state?;
        get state(): string;
        set state(value: string);
        resetState(): void;
        get stateInput(): string | undefined;
        private _zipCode?;
        get zipCode(): string;
        set zipCode(value: string);
        resetZipCode(): void;
        get zipCodeInput(): string | undefined;
    }
    interface NameServerProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#glue_ips AwsRegisteredDomain#glue_ips}
        */
        readonly glueIps?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#name AwsRegisteredDomain#name}
        */
        readonly name: string;
    }
    class NameServerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NameServerProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NameServerProperty | cdktn.IResolvable | undefined);
        private _glueIps?;
        get glueIps(): string[];
        set glueIps(value: string[]);
        resetGlueIps(): void;
        get glueIpsInput(): string[] | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    class NameServerPropertyList extends cdktn.ComplexList {
        internalValue?: NameServerProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NameServerPropertyOutputReference;
    }
    interface RegistrantContactProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#address_line_1 AwsRegisteredDomain#address_line_1}
        */
        readonly addressLine1?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#address_line_2 AwsRegisteredDomain#address_line_2}
        */
        readonly addressLine2?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#city AwsRegisteredDomain#city}
        */
        readonly city?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#contact_type AwsRegisteredDomain#contact_type}
        */
        readonly contactType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#country_code AwsRegisteredDomain#country_code}
        */
        readonly countryCode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#email AwsRegisteredDomain#email}
        */
        readonly email?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#extra_params AwsRegisteredDomain#extra_params}
        */
        readonly extraParams?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#fax AwsRegisteredDomain#fax}
        */
        readonly fax?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#first_name AwsRegisteredDomain#first_name}
        */
        readonly firstName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#last_name AwsRegisteredDomain#last_name}
        */
        readonly lastName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#organization_name AwsRegisteredDomain#organization_name}
        */
        readonly organizationName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#phone_number AwsRegisteredDomain#phone_number}
        */
        readonly phoneNumber?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#state AwsRegisteredDomain#state}
        */
        readonly state?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#zip_code AwsRegisteredDomain#zip_code}
        */
        readonly zipCode?: string;
    }
    class RegistrantContactPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RegistrantContactProperty | undefined;
        set internalValue(value: RegistrantContactProperty | undefined);
        private _addressLine1?;
        get addressLine1(): string;
        set addressLine1(value: string);
        resetAddressLine1(): void;
        get addressLine1Input(): string | undefined;
        private _addressLine2?;
        get addressLine2(): string;
        set addressLine2(value: string);
        resetAddressLine2(): void;
        get addressLine2Input(): string | undefined;
        private _city?;
        get city(): string;
        set city(value: string);
        resetCity(): void;
        get cityInput(): string | undefined;
        private _contactType?;
        get contactType(): string;
        set contactType(value: string);
        resetContactType(): void;
        get contactTypeInput(): string | undefined;
        private _countryCode?;
        get countryCode(): string;
        set countryCode(value: string);
        resetCountryCode(): void;
        get countryCodeInput(): string | undefined;
        private _email?;
        get email(): string;
        set email(value: string);
        resetEmail(): void;
        get emailInput(): string | undefined;
        private _extraParams?;
        get extraParams(): {
            [key: string]: string;
        };
        set extraParams(value: {
            [key: string]: string;
        });
        resetExtraParams(): void;
        get extraParamsInput(): {
            [key: string]: string;
        } | undefined;
        private _fax?;
        get fax(): string;
        set fax(value: string);
        resetFax(): void;
        get faxInput(): string | undefined;
        private _firstName?;
        get firstName(): string;
        set firstName(value: string);
        resetFirstName(): void;
        get firstNameInput(): string | undefined;
        private _lastName?;
        get lastName(): string;
        set lastName(value: string);
        resetLastName(): void;
        get lastNameInput(): string | undefined;
        private _organizationName?;
        get organizationName(): string;
        set organizationName(value: string);
        resetOrganizationName(): void;
        get organizationNameInput(): string | undefined;
        private _phoneNumber?;
        get phoneNumber(): string;
        set phoneNumber(value: string);
        resetPhoneNumber(): void;
        get phoneNumberInput(): string | undefined;
        private _state?;
        get state(): string;
        set state(value: string);
        resetState(): void;
        get stateInput(): string | undefined;
        private _zipCode?;
        get zipCode(): string;
        set zipCode(value: string);
        resetZipCode(): void;
        get zipCodeInput(): string | undefined;
    }
    interface TechContactProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#address_line_1 AwsRegisteredDomain#address_line_1}
        */
        readonly addressLine1?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#address_line_2 AwsRegisteredDomain#address_line_2}
        */
        readonly addressLine2?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#city AwsRegisteredDomain#city}
        */
        readonly city?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#contact_type AwsRegisteredDomain#contact_type}
        */
        readonly contactType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#country_code AwsRegisteredDomain#country_code}
        */
        readonly countryCode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#email AwsRegisteredDomain#email}
        */
        readonly email?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#extra_params AwsRegisteredDomain#extra_params}
        */
        readonly extraParams?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#fax AwsRegisteredDomain#fax}
        */
        readonly fax?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#first_name AwsRegisteredDomain#first_name}
        */
        readonly firstName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#last_name AwsRegisteredDomain#last_name}
        */
        readonly lastName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#organization_name AwsRegisteredDomain#organization_name}
        */
        readonly organizationName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#phone_number AwsRegisteredDomain#phone_number}
        */
        readonly phoneNumber?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#state AwsRegisteredDomain#state}
        */
        readonly state?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#zip_code AwsRegisteredDomain#zip_code}
        */
        readonly zipCode?: string;
    }
    class TechContactPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TechContactProperty | undefined;
        set internalValue(value: TechContactProperty | undefined);
        private _addressLine1?;
        get addressLine1(): string;
        set addressLine1(value: string);
        resetAddressLine1(): void;
        get addressLine1Input(): string | undefined;
        private _addressLine2?;
        get addressLine2(): string;
        set addressLine2(value: string);
        resetAddressLine2(): void;
        get addressLine2Input(): string | undefined;
        private _city?;
        get city(): string;
        set city(value: string);
        resetCity(): void;
        get cityInput(): string | undefined;
        private _contactType?;
        get contactType(): string;
        set contactType(value: string);
        resetContactType(): void;
        get contactTypeInput(): string | undefined;
        private _countryCode?;
        get countryCode(): string;
        set countryCode(value: string);
        resetCountryCode(): void;
        get countryCodeInput(): string | undefined;
        private _email?;
        get email(): string;
        set email(value: string);
        resetEmail(): void;
        get emailInput(): string | undefined;
        private _extraParams?;
        get extraParams(): {
            [key: string]: string;
        };
        set extraParams(value: {
            [key: string]: string;
        });
        resetExtraParams(): void;
        get extraParamsInput(): {
            [key: string]: string;
        } | undefined;
        private _fax?;
        get fax(): string;
        set fax(value: string);
        resetFax(): void;
        get faxInput(): string | undefined;
        private _firstName?;
        get firstName(): string;
        set firstName(value: string);
        resetFirstName(): void;
        get firstNameInput(): string | undefined;
        private _lastName?;
        get lastName(): string;
        set lastName(value: string);
        resetLastName(): void;
        get lastNameInput(): string | undefined;
        private _organizationName?;
        get organizationName(): string;
        set organizationName(value: string);
        resetOrganizationName(): void;
        get organizationNameInput(): string | undefined;
        private _phoneNumber?;
        get phoneNumber(): string;
        set phoneNumber(value: string);
        resetPhoneNumber(): void;
        get phoneNumberInput(): string | undefined;
        private _state?;
        get state(): string;
        set state(value: string);
        resetState(): void;
        get stateInput(): string | undefined;
        private _zipCode?;
        get zipCode(): string;
        set zipCode(value: string);
        resetZipCode(): void;
        get zipCodeInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#create AwsRegisteredDomain#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_registered_domain#update AwsRegisteredDomain#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
