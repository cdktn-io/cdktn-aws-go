import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#admin_privacy AwsDomain#admin_privacy}
    */
    readonly adminPrivacy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#auto_renew AwsDomain#auto_renew}
    */
    readonly autoRenew?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#billing_contact AwsDomain#billing_contact}
    */
    readonly billingContact?: AwsDomain.BillingContactProperty[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#billing_privacy AwsDomain#billing_privacy}
    */
    readonly billingPrivacy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#domain_name AwsDomain#domain_name}
    */
    readonly domainName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#duration_in_years AwsDomain#duration_in_years}
    */
    readonly durationInYears?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#name_server AwsDomain#name_server}
    */
    readonly nameServer?: AwsDomain.NameServerProperty[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#registrant_privacy AwsDomain#registrant_privacy}
    */
    readonly registrantPrivacy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#tags AwsDomain#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#tech_privacy AwsDomain#tech_privacy}
    */
    readonly techPrivacy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#transfer_lock AwsDomain#transfer_lock}
    */
    readonly transferLock?: boolean | cdktn.IResolvable;
    /**
    * admin_contact block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#admin_contact AwsDomain#admin_contact}
    */
    readonly adminContact?: AwsDomain.AdminContactProperty[] | cdktn.IResolvable;
    /**
    * registrant_contact block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#registrant_contact AwsDomain#registrant_contact}
    */
    readonly registrantContact?: AwsDomain.RegistrantContactProperty[] | cdktn.IResolvable;
    /**
    * tech_contact block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#tech_contact AwsDomain#tech_contact}
    */
    readonly techContact?: AwsDomain.TechContactProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#timeouts AwsDomain#timeouts}
    */
    readonly timeouts?: AwsDomain.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain aws_route53domains_domain}
*/
export declare class AwsDomain extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_route53domains_domain";
    /**
    * Generates CDKTN code for importing a AwsDomain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDomain to import
    * @param importFromId The id of the existing AwsDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain aws_route53domains_domain} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDomainConfig
    */
    constructor(scope: Construct, id: string, config: AwsDomainConfig);
    get abuseContactEmail(): string;
    get abuseContactPhone(): string;
    private _adminPrivacy?;
    get adminPrivacy(): boolean | cdktn.IResolvable;
    set adminPrivacy(value: boolean | cdktn.IResolvable);
    resetAdminPrivacy(): void;
    get adminPrivacyInput(): boolean | cdktn.IResolvable | undefined;
    private _autoRenew?;
    get autoRenew(): boolean | cdktn.IResolvable;
    set autoRenew(value: boolean | cdktn.IResolvable);
    resetAutoRenew(): void;
    get autoRenewInput(): boolean | cdktn.IResolvable | undefined;
    private _billingContact;
    get billingContact(): AwsDomain.BillingContactPropertyList;
    putBillingContact(value: AwsDomain.BillingContactProperty[] | cdktn.IResolvable): void;
    resetBillingContact(): void;
    get billingContactInput(): cdktn.IResolvable | AwsDomain.BillingContactProperty[] | undefined;
    private _billingPrivacy?;
    get billingPrivacy(): boolean | cdktn.IResolvable;
    set billingPrivacy(value: boolean | cdktn.IResolvable);
    resetBillingPrivacy(): void;
    get billingPrivacyInput(): boolean | cdktn.IResolvable | undefined;
    get creationDate(): string;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    private _durationInYears?;
    get durationInYears(): number;
    set durationInYears(value: number);
    resetDurationInYears(): void;
    get durationInYearsInput(): number | undefined;
    get expirationDate(): string;
    get hostedZoneId(): string;
    private _nameServer;
    get nameServer(): AwsDomain.NameServerPropertyList;
    putNameServer(value: AwsDomain.NameServerProperty[] | cdktn.IResolvable): void;
    resetNameServer(): void;
    get nameServerInput(): cdktn.IResolvable | AwsDomain.NameServerProperty[] | undefined;
    private _registrantPrivacy?;
    get registrantPrivacy(): boolean | cdktn.IResolvable;
    set registrantPrivacy(value: boolean | cdktn.IResolvable);
    resetRegistrantPrivacy(): void;
    get registrantPrivacyInput(): boolean | cdktn.IResolvable | undefined;
    get registrarName(): string;
    get registrarUrl(): string;
    get statusList(): string[];
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _techPrivacy?;
    get techPrivacy(): boolean | cdktn.IResolvable;
    set techPrivacy(value: boolean | cdktn.IResolvable);
    resetTechPrivacy(): void;
    get techPrivacyInput(): boolean | cdktn.IResolvable | undefined;
    private _transferLock?;
    get transferLock(): boolean | cdktn.IResolvable;
    set transferLock(value: boolean | cdktn.IResolvable);
    resetTransferLock(): void;
    get transferLockInput(): boolean | cdktn.IResolvable | undefined;
    get updatedDate(): string;
    get whoisServer(): string;
    private _adminContact;
    get adminContact(): AwsDomain.AdminContactPropertyList;
    putAdminContact(value: AwsDomain.AdminContactProperty[] | cdktn.IResolvable): void;
    resetAdminContact(): void;
    get adminContactInput(): cdktn.IResolvable | AwsDomain.AdminContactProperty[] | undefined;
    private _registrantContact;
    get registrantContact(): AwsDomain.RegistrantContactPropertyList;
    putRegistrantContact(value: AwsDomain.RegistrantContactProperty[] | cdktn.IResolvable): void;
    resetRegistrantContact(): void;
    get registrantContactInput(): cdktn.IResolvable | AwsDomain.RegistrantContactProperty[] | undefined;
    private _techContact;
    get techContact(): AwsDomain.TechContactPropertyList;
    putTechContact(value: AwsDomain.TechContactProperty[] | cdktn.IResolvable): void;
    resetTechContact(): void;
    get techContactInput(): cdktn.IResolvable | AwsDomain.TechContactProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsDomain.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsDomain.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsDomain.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDomainBillingContactExtraParamPropertyToTerraform(struct?: AwsDomain.BillingContactExtraParamProperty | cdktn.IResolvable): any;
export declare function awsDomainBillingContactExtraParamPropertyToHclTerraform(struct?: AwsDomain.BillingContactExtraParamProperty | cdktn.IResolvable): any;
export declare function awsDomainBillingContactPropertyToTerraform(struct?: AwsDomain.BillingContactProperty | cdktn.IResolvable): any;
export declare function awsDomainBillingContactPropertyToHclTerraform(struct?: AwsDomain.BillingContactProperty | cdktn.IResolvable): any;
export declare function awsDomainNameServerPropertyToTerraform(struct?: AwsDomain.NameServerProperty | cdktn.IResolvable): any;
export declare function awsDomainNameServerPropertyToHclTerraform(struct?: AwsDomain.NameServerProperty | cdktn.IResolvable): any;
export declare function awsDomainAdminContactExtraParamPropertyToTerraform(struct?: AwsDomain.AdminContactExtraParamProperty | cdktn.IResolvable): any;
export declare function awsDomainAdminContactExtraParamPropertyToHclTerraform(struct?: AwsDomain.AdminContactExtraParamProperty | cdktn.IResolvable): any;
export declare function awsDomainAdminContactPropertyToTerraform(struct?: AwsDomain.AdminContactProperty | cdktn.IResolvable): any;
export declare function awsDomainAdminContactPropertyToHclTerraform(struct?: AwsDomain.AdminContactProperty | cdktn.IResolvable): any;
export declare function awsDomainRegistrantContactExtraParamPropertyToTerraform(struct?: AwsDomain.RegistrantContactExtraParamProperty | cdktn.IResolvable): any;
export declare function awsDomainRegistrantContactExtraParamPropertyToHclTerraform(struct?: AwsDomain.RegistrantContactExtraParamProperty | cdktn.IResolvable): any;
export declare function awsDomainRegistrantContactPropertyToTerraform(struct?: AwsDomain.RegistrantContactProperty | cdktn.IResolvable): any;
export declare function awsDomainRegistrantContactPropertyToHclTerraform(struct?: AwsDomain.RegistrantContactProperty | cdktn.IResolvable): any;
export declare function awsDomainTechContactExtraParamPropertyToTerraform(struct?: AwsDomain.TechContactExtraParamProperty | cdktn.IResolvable): any;
export declare function awsDomainTechContactExtraParamPropertyToHclTerraform(struct?: AwsDomain.TechContactExtraParamProperty | cdktn.IResolvable): any;
export declare function awsDomainTechContactPropertyToTerraform(struct?: AwsDomain.TechContactProperty | cdktn.IResolvable): any;
export declare function awsDomainTechContactPropertyToHclTerraform(struct?: AwsDomain.TechContactProperty | cdktn.IResolvable): any;
export declare function awsDomainTimeoutsPropertyToTerraform(struct?: AwsDomain.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsDomainTimeoutsPropertyToHclTerraform(struct?: AwsDomain.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsDomain {
    interface BillingContactExtraParamProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#name AwsDomain#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#value AwsDomain#value}
        */
        readonly value?: string;
    }
    class BillingContactExtraParamPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BillingContactExtraParamProperty | cdktn.IResolvable | undefined;
        set internalValue(value: BillingContactExtraParamProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
    class BillingContactExtraParamPropertyList extends cdktn.ComplexList {
        internalValue?: BillingContactExtraParamProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BillingContactExtraParamPropertyOutputReference;
    }
    interface BillingContactProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#address_line_1 AwsDomain#address_line_1}
        */
        readonly addressLine1?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#address_line_2 AwsDomain#address_line_2}
        */
        readonly addressLine2?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#city AwsDomain#city}
        */
        readonly city?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#contact_type AwsDomain#contact_type}
        */
        readonly contactType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#country_code AwsDomain#country_code}
        */
        readonly countryCode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#email AwsDomain#email}
        */
        readonly email?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#extra_param AwsDomain#extra_param}
        */
        readonly extraParam?: BillingContactExtraParamProperty[] | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#fax AwsDomain#fax}
        */
        readonly fax?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#first_name AwsDomain#first_name}
        */
        readonly firstName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#last_name AwsDomain#last_name}
        */
        readonly lastName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#organization_name AwsDomain#organization_name}
        */
        readonly organizationName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#phone_number AwsDomain#phone_number}
        */
        readonly phoneNumber?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#state AwsDomain#state}
        */
        readonly state?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#zip_code AwsDomain#zip_code}
        */
        readonly zipCode?: string;
    }
    class BillingContactPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BillingContactProperty | cdktn.IResolvable | undefined;
        set internalValue(value: BillingContactProperty | cdktn.IResolvable | undefined);
        private _addressLine1?;
        get addressLine1(): string;
        set addressLine1(value: string);
        resetAddressLine1(): void;
        get addressLine1Input(): string | undefined;
        private _addressLine2?;
        get addressLine2(): string;
        set addressLine2(value: string);
        resetAddressLine2(): void;
        get addressLine2Input(): string | undefined;
        private _city?;
        get city(): string;
        set city(value: string);
        resetCity(): void;
        get cityInput(): string | undefined;
        private _contactType?;
        get contactType(): string;
        set contactType(value: string);
        resetContactType(): void;
        get contactTypeInput(): string | undefined;
        private _countryCode?;
        get countryCode(): string;
        set countryCode(value: string);
        resetCountryCode(): void;
        get countryCodeInput(): string | undefined;
        private _email?;
        get email(): string;
        set email(value: string);
        resetEmail(): void;
        get emailInput(): string | undefined;
        private _extraParam;
        get extraParam(): BillingContactExtraParamPropertyList;
        putExtraParam(value: BillingContactExtraParamProperty[] | cdktn.IResolvable): void;
        resetExtraParam(): void;
        get extraParamInput(): cdktn.IResolvable | BillingContactExtraParamProperty[] | undefined;
        private _fax?;
        get fax(): string;
        set fax(value: string);
        resetFax(): void;
        get faxInput(): string | undefined;
        private _firstName?;
        get firstName(): string;
        set firstName(value: string);
        resetFirstName(): void;
        get firstNameInput(): string | undefined;
        private _lastName?;
        get lastName(): string;
        set lastName(value: string);
        resetLastName(): void;
        get lastNameInput(): string | undefined;
        private _organizationName?;
        get organizationName(): string;
        set organizationName(value: string);
        resetOrganizationName(): void;
        get organizationNameInput(): string | undefined;
        private _phoneNumber?;
        get phoneNumber(): string;
        set phoneNumber(value: string);
        resetPhoneNumber(): void;
        get phoneNumberInput(): string | undefined;
        private _state?;
        get state(): string;
        set state(value: string);
        resetState(): void;
        get stateInput(): string | undefined;
        private _zipCode?;
        get zipCode(): string;
        set zipCode(value: string);
        resetZipCode(): void;
        get zipCodeInput(): string | undefined;
    }
    class BillingContactPropertyList extends cdktn.ComplexList {
        internalValue?: BillingContactProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BillingContactPropertyOutputReference;
    }
    interface NameServerProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#glue_ips AwsDomain#glue_ips}
        */
        readonly glueIps?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#name AwsDomain#name}
        */
        readonly name?: string;
    }
    class NameServerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NameServerProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NameServerProperty | cdktn.IResolvable | undefined);
        private _glueIps?;
        get glueIps(): string[];
        set glueIps(value: string[]);
        resetGlueIps(): void;
        get glueIpsInput(): string[] | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
    }
    class NameServerPropertyList extends cdktn.ComplexList {
        internalValue?: NameServerProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NameServerPropertyOutputReference;
    }
    interface AdminContactExtraParamProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#name AwsDomain#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#value AwsDomain#value}
        */
        readonly value: string;
    }
    class AdminContactExtraParamPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AdminContactExtraParamProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AdminContactExtraParamProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class AdminContactExtraParamPropertyList extends cdktn.ComplexList {
        internalValue?: AdminContactExtraParamProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AdminContactExtraParamPropertyOutputReference;
    }
    interface AdminContactProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#address_line_1 AwsDomain#address_line_1}
        */
        readonly addressLine1?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#address_line_2 AwsDomain#address_line_2}
        */
        readonly addressLine2?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#city AwsDomain#city}
        */
        readonly city?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#contact_type AwsDomain#contact_type}
        */
        readonly contactType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#country_code AwsDomain#country_code}
        */
        readonly countryCode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#email AwsDomain#email}
        */
        readonly email?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#fax AwsDomain#fax}
        */
        readonly fax?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#first_name AwsDomain#first_name}
        */
        readonly firstName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#last_name AwsDomain#last_name}
        */
        readonly lastName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#organization_name AwsDomain#organization_name}
        */
        readonly organizationName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#phone_number AwsDomain#phone_number}
        */
        readonly phoneNumber?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#state AwsDomain#state}
        */
        readonly state?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#zip_code AwsDomain#zip_code}
        */
        readonly zipCode?: string;
        /**
        * extra_param block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#extra_param AwsDomain#extra_param}
        */
        readonly extraParam?: AdminContactExtraParamProperty[] | cdktn.IResolvable;
    }
    class AdminContactPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AdminContactProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AdminContactProperty | cdktn.IResolvable | undefined);
        private _addressLine1?;
        get addressLine1(): string;
        set addressLine1(value: string);
        resetAddressLine1(): void;
        get addressLine1Input(): string | undefined;
        private _addressLine2?;
        get addressLine2(): string;
        set addressLine2(value: string);
        resetAddressLine2(): void;
        get addressLine2Input(): string | undefined;
        private _city?;
        get city(): string;
        set city(value: string);
        resetCity(): void;
        get cityInput(): string | undefined;
        private _contactType?;
        get contactType(): string;
        set contactType(value: string);
        resetContactType(): void;
        get contactTypeInput(): string | undefined;
        private _countryCode?;
        get countryCode(): string;
        set countryCode(value: string);
        resetCountryCode(): void;
        get countryCodeInput(): string | undefined;
        private _email?;
        get email(): string;
        set email(value: string);
        resetEmail(): void;
        get emailInput(): string | undefined;
        private _fax?;
        get fax(): string;
        set fax(value: string);
        resetFax(): void;
        get faxInput(): string | undefined;
        private _firstName?;
        get firstName(): string;
        set firstName(value: string);
        resetFirstName(): void;
        get firstNameInput(): string | undefined;
        private _lastName?;
        get lastName(): string;
        set lastName(value: string);
        resetLastName(): void;
        get lastNameInput(): string | undefined;
        private _organizationName?;
        get organizationName(): string;
        set organizationName(value: string);
        resetOrganizationName(): void;
        get organizationNameInput(): string | undefined;
        private _phoneNumber?;
        get phoneNumber(): string;
        set phoneNumber(value: string);
        resetPhoneNumber(): void;
        get phoneNumberInput(): string | undefined;
        private _state?;
        get state(): string;
        set state(value: string);
        resetState(): void;
        get stateInput(): string | undefined;
        private _zipCode?;
        get zipCode(): string;
        set zipCode(value: string);
        resetZipCode(): void;
        get zipCodeInput(): string | undefined;
        private _extraParam;
        get extraParam(): AdminContactExtraParamPropertyList;
        putExtraParam(value: AdminContactExtraParamProperty[] | cdktn.IResolvable): void;
        resetExtraParam(): void;
        get extraParamInput(): cdktn.IResolvable | AdminContactExtraParamProperty[] | undefined;
    }
    class AdminContactPropertyList extends cdktn.ComplexList {
        internalValue?: AdminContactProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AdminContactPropertyOutputReference;
    }
    interface RegistrantContactExtraParamProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#name AwsDomain#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#value AwsDomain#value}
        */
        readonly value: string;
    }
    class RegistrantContactExtraParamPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RegistrantContactExtraParamProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RegistrantContactExtraParamProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class RegistrantContactExtraParamPropertyList extends cdktn.ComplexList {
        internalValue?: RegistrantContactExtraParamProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RegistrantContactExtraParamPropertyOutputReference;
    }
    interface RegistrantContactProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#address_line_1 AwsDomain#address_line_1}
        */
        readonly addressLine1?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#address_line_2 AwsDomain#address_line_2}
        */
        readonly addressLine2?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#city AwsDomain#city}
        */
        readonly city?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#contact_type AwsDomain#contact_type}
        */
        readonly contactType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#country_code AwsDomain#country_code}
        */
        readonly countryCode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#email AwsDomain#email}
        */
        readonly email?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#fax AwsDomain#fax}
        */
        readonly fax?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#first_name AwsDomain#first_name}
        */
        readonly firstName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#last_name AwsDomain#last_name}
        */
        readonly lastName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#organization_name AwsDomain#organization_name}
        */
        readonly organizationName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#phone_number AwsDomain#phone_number}
        */
        readonly phoneNumber?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#state AwsDomain#state}
        */
        readonly state?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#zip_code AwsDomain#zip_code}
        */
        readonly zipCode?: string;
        /**
        * extra_param block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#extra_param AwsDomain#extra_param}
        */
        readonly extraParam?: RegistrantContactExtraParamProperty[] | cdktn.IResolvable;
    }
    class RegistrantContactPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RegistrantContactProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RegistrantContactProperty | cdktn.IResolvable | undefined);
        private _addressLine1?;
        get addressLine1(): string;
        set addressLine1(value: string);
        resetAddressLine1(): void;
        get addressLine1Input(): string | undefined;
        private _addressLine2?;
        get addressLine2(): string;
        set addressLine2(value: string);
        resetAddressLine2(): void;
        get addressLine2Input(): string | undefined;
        private _city?;
        get city(): string;
        set city(value: string);
        resetCity(): void;
        get cityInput(): string | undefined;
        private _contactType?;
        get contactType(): string;
        set contactType(value: string);
        resetContactType(): void;
        get contactTypeInput(): string | undefined;
        private _countryCode?;
        get countryCode(): string;
        set countryCode(value: string);
        resetCountryCode(): void;
        get countryCodeInput(): string | undefined;
        private _email?;
        get email(): string;
        set email(value: string);
        resetEmail(): void;
        get emailInput(): string | undefined;
        private _fax?;
        get fax(): string;
        set fax(value: string);
        resetFax(): void;
        get faxInput(): string | undefined;
        private _firstName?;
        get firstName(): string;
        set firstName(value: string);
        resetFirstName(): void;
        get firstNameInput(): string | undefined;
        private _lastName?;
        get lastName(): string;
        set lastName(value: string);
        resetLastName(): void;
        get lastNameInput(): string | undefined;
        private _organizationName?;
        get organizationName(): string;
        set organizationName(value: string);
        resetOrganizationName(): void;
        get organizationNameInput(): string | undefined;
        private _phoneNumber?;
        get phoneNumber(): string;
        set phoneNumber(value: string);
        resetPhoneNumber(): void;
        get phoneNumberInput(): string | undefined;
        private _state?;
        get state(): string;
        set state(value: string);
        resetState(): void;
        get stateInput(): string | undefined;
        private _zipCode?;
        get zipCode(): string;
        set zipCode(value: string);
        resetZipCode(): void;
        get zipCodeInput(): string | undefined;
        private _extraParam;
        get extraParam(): RegistrantContactExtraParamPropertyList;
        putExtraParam(value: RegistrantContactExtraParamProperty[] | cdktn.IResolvable): void;
        resetExtraParam(): void;
        get extraParamInput(): cdktn.IResolvable | RegistrantContactExtraParamProperty[] | undefined;
    }
    class RegistrantContactPropertyList extends cdktn.ComplexList {
        internalValue?: RegistrantContactProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RegistrantContactPropertyOutputReference;
    }
    interface TechContactExtraParamProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#name AwsDomain#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#value AwsDomain#value}
        */
        readonly value: string;
    }
    class TechContactExtraParamPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TechContactExtraParamProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TechContactExtraParamProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class TechContactExtraParamPropertyList extends cdktn.ComplexList {
        internalValue?: TechContactExtraParamProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TechContactExtraParamPropertyOutputReference;
    }
    interface TechContactProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#address_line_1 AwsDomain#address_line_1}
        */
        readonly addressLine1?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#address_line_2 AwsDomain#address_line_2}
        */
        readonly addressLine2?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#city AwsDomain#city}
        */
        readonly city?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#contact_type AwsDomain#contact_type}
        */
        readonly contactType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#country_code AwsDomain#country_code}
        */
        readonly countryCode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#email AwsDomain#email}
        */
        readonly email?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#fax AwsDomain#fax}
        */
        readonly fax?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#first_name AwsDomain#first_name}
        */
        readonly firstName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#last_name AwsDomain#last_name}
        */
        readonly lastName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#organization_name AwsDomain#organization_name}
        */
        readonly organizationName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#phone_number AwsDomain#phone_number}
        */
        readonly phoneNumber?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#state AwsDomain#state}
        */
        readonly state?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#zip_code AwsDomain#zip_code}
        */
        readonly zipCode?: string;
        /**
        * extra_param block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#extra_param AwsDomain#extra_param}
        */
        readonly extraParam?: TechContactExtraParamProperty[] | cdktn.IResolvable;
    }
    class TechContactPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TechContactProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TechContactProperty | cdktn.IResolvable | undefined);
        private _addressLine1?;
        get addressLine1(): string;
        set addressLine1(value: string);
        resetAddressLine1(): void;
        get addressLine1Input(): string | undefined;
        private _addressLine2?;
        get addressLine2(): string;
        set addressLine2(value: string);
        resetAddressLine2(): void;
        get addressLine2Input(): string | undefined;
        private _city?;
        get city(): string;
        set city(value: string);
        resetCity(): void;
        get cityInput(): string | undefined;
        private _contactType?;
        get contactType(): string;
        set contactType(value: string);
        resetContactType(): void;
        get contactTypeInput(): string | undefined;
        private _countryCode?;
        get countryCode(): string;
        set countryCode(value: string);
        resetCountryCode(): void;
        get countryCodeInput(): string | undefined;
        private _email?;
        get email(): string;
        set email(value: string);
        resetEmail(): void;
        get emailInput(): string | undefined;
        private _fax?;
        get fax(): string;
        set fax(value: string);
        resetFax(): void;
        get faxInput(): string | undefined;
        private _firstName?;
        get firstName(): string;
        set firstName(value: string);
        resetFirstName(): void;
        get firstNameInput(): string | undefined;
        private _lastName?;
        get lastName(): string;
        set lastName(value: string);
        resetLastName(): void;
        get lastNameInput(): string | undefined;
        private _organizationName?;
        get organizationName(): string;
        set organizationName(value: string);
        resetOrganizationName(): void;
        get organizationNameInput(): string | undefined;
        private _phoneNumber?;
        get phoneNumber(): string;
        set phoneNumber(value: string);
        resetPhoneNumber(): void;
        get phoneNumberInput(): string | undefined;
        private _state?;
        get state(): string;
        set state(value: string);
        resetState(): void;
        get stateInput(): string | undefined;
        private _zipCode?;
        get zipCode(): string;
        set zipCode(value: string);
        resetZipCode(): void;
        get zipCodeInput(): string | undefined;
        private _extraParam;
        get extraParam(): TechContactExtraParamPropertyList;
        putExtraParam(value: TechContactExtraParamProperty[] | cdktn.IResolvable): void;
        resetExtraParam(): void;
        get extraParamInput(): cdktn.IResolvable | TechContactExtraParamProperty[] | undefined;
    }
    class TechContactPropertyList extends cdktn.ComplexList {
        internalValue?: TechContactProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TechContactPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#create AwsDomain#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#delete AwsDomain#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_domain#update AwsDomain#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
