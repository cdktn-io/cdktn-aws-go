import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDelegationSignerRecordConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_delegation_signer_record#domain_name AwsDelegationSignerRecord#domain_name}
    */
    readonly domainName: string;
    /**
    * signing_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_delegation_signer_record#signing_attributes AwsDelegationSignerRecord#signing_attributes}
    */
    readonly signingAttributes?: AwsDelegationSignerRecord.SigningAttributesProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_delegation_signer_record#timeouts AwsDelegationSignerRecord#timeouts}
    */
    readonly timeouts?: AwsDelegationSignerRecord.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_delegation_signer_record aws_route53domains_delegation_signer_record}
*/
export declare class AwsDelegationSignerRecord extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_route53domains_delegation_signer_record";
    /**
    * Generates CDKTN code for importing a AwsDelegationSignerRecord resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDelegationSignerRecord to import
    * @param importFromId The id of the existing AwsDelegationSignerRecord that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_delegation_signer_record#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDelegationSignerRecord to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_delegation_signer_record aws_route53domains_delegation_signer_record} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDelegationSignerRecordConfig
    */
    constructor(scope: Construct, id: string, config: AwsDelegationSignerRecordConfig);
    get dnssecKeyId(): string;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    get id(): string;
    private _signingAttributes;
    get signingAttributes(): AwsDelegationSignerRecord.SigningAttributesPropertyList;
    putSigningAttributes(value: AwsDelegationSignerRecord.SigningAttributesProperty[] | cdktn.IResolvable): void;
    resetSigningAttributes(): void;
    get signingAttributesInput(): cdktn.IResolvable | AwsDelegationSignerRecord.SigningAttributesProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsDelegationSignerRecord.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsDelegationSignerRecord.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsDelegationSignerRecord.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDelegationSignerRecordSigningAttributesPropertyToTerraform(struct?: AwsDelegationSignerRecord.SigningAttributesProperty | cdktn.IResolvable): any;
export declare function awsDelegationSignerRecordSigningAttributesPropertyToHclTerraform(struct?: AwsDelegationSignerRecord.SigningAttributesProperty | cdktn.IResolvable): any;
export declare function awsDelegationSignerRecordTimeoutsPropertyToTerraform(struct?: AwsDelegationSignerRecord.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsDelegationSignerRecordTimeoutsPropertyToHclTerraform(struct?: AwsDelegationSignerRecord.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsDelegationSignerRecord {
    interface SigningAttributesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_delegation_signer_record#algorithm AwsDelegationSignerRecord#algorithm}
        */
        readonly algorithm: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_delegation_signer_record#flags AwsDelegationSignerRecord#flags}
        */
        readonly flags: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_delegation_signer_record#public_key AwsDelegationSignerRecord#public_key}
        */
        readonly publicKey: string;
    }
    class SigningAttributesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SigningAttributesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SigningAttributesProperty | cdktn.IResolvable | undefined);
        private _algorithm?;
        get algorithm(): number;
        set algorithm(value: number);
        get algorithmInput(): number | undefined;
        private _flags?;
        get flags(): number;
        set flags(value: number);
        get flagsInput(): number | undefined;
        private _publicKey?;
        get publicKey(): string;
        set publicKey(value: string);
        get publicKeyInput(): string | undefined;
    }
    class SigningAttributesPropertyList extends cdktn.ComplexList {
        internalValue?: SigningAttributesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SigningAttributesPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_delegation_signer_record#create AwsDelegationSignerRecord#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53domains_delegation_signer_record#delete AwsDelegationSignerRecord#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
