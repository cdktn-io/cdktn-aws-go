import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsChimesdkvoiceGlobalSettingsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_global_settings#id AwsChimesdkvoiceGlobalSettings#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * voice_connector block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_global_settings#voice_connector AwsChimesdkvoiceGlobalSettings#voice_connector}
    */
    readonly voiceConnector: AwsChimesdkvoiceGlobalSettings.VoiceConnectorProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_global_settings aws_chimesdkvoice_global_settings}
*/
export declare class AwsChimesdkvoiceGlobalSettings extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_chimesdkvoice_global_settings";
    /**
    * Generates CDKTN code for importing a AwsChimesdkvoiceGlobalSettings resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsChimesdkvoiceGlobalSettings to import
    * @param importFromId The id of the existing AwsChimesdkvoiceGlobalSettings that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_global_settings#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsChimesdkvoiceGlobalSettings to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_global_settings aws_chimesdkvoice_global_settings} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsChimesdkvoiceGlobalSettingsConfig
    */
    constructor(scope: Construct, id: string, config: AwsChimesdkvoiceGlobalSettingsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _voiceConnector;
    get voiceConnector(): AwsChimesdkvoiceGlobalSettings.VoiceConnectorPropertyOutputReference;
    putVoiceConnector(value: AwsChimesdkvoiceGlobalSettings.VoiceConnectorProperty): void;
    get voiceConnectorInput(): AwsChimesdkvoiceGlobalSettings.VoiceConnectorProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsChimesdkvoiceGlobalSettingsVoiceConnectorPropertyToTerraform(struct?: AwsChimesdkvoiceGlobalSettings.VoiceConnectorPropertyOutputReference | AwsChimesdkvoiceGlobalSettings.VoiceConnectorProperty): any;
export declare function awsChimesdkvoiceGlobalSettingsVoiceConnectorPropertyToHclTerraform(struct?: AwsChimesdkvoiceGlobalSettings.VoiceConnectorPropertyOutputReference | AwsChimesdkvoiceGlobalSettings.VoiceConnectorProperty): any;
export declare namespace AwsChimesdkvoiceGlobalSettings {
    interface VoiceConnectorProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_global_settings#cdr_bucket AwsChimesdkvoiceGlobalSettings#cdr_bucket}
        */
        readonly cdrBucket?: string;
    }
    class VoiceConnectorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VoiceConnectorProperty | undefined;
        set internalValue(value: VoiceConnectorProperty | undefined);
        private _cdrBucket?;
        get cdrBucket(): string;
        set cdrBucket(value: string);
        resetCdrBucket(): void;
        get cdrBucketInput(): string | undefined;
    }
}
