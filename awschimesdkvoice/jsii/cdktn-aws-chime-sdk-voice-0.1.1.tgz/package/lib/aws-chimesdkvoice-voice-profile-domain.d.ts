import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsChimesdkvoiceVoiceProfileDomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_voice_profile_domain#description AwsChimesdkvoiceVoiceProfileDomain#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_voice_profile_domain#name AwsChimesdkvoiceVoiceProfileDomain#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_voice_profile_domain#region AwsChimesdkvoiceVoiceProfileDomain#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_voice_profile_domain#tags AwsChimesdkvoiceVoiceProfileDomain#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_voice_profile_domain#tags_all AwsChimesdkvoiceVoiceProfileDomain#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * server_side_encryption_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_voice_profile_domain#server_side_encryption_configuration AwsChimesdkvoiceVoiceProfileDomain#server_side_encryption_configuration}
    */
    readonly serverSideEncryptionConfiguration: AwsChimesdkvoiceVoiceProfileDomain.ServerSideEncryptionConfigurationProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_voice_profile_domain#timeouts AwsChimesdkvoiceVoiceProfileDomain#timeouts}
    */
    readonly timeouts?: AwsChimesdkvoiceVoiceProfileDomain.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_voice_profile_domain aws_chimesdkvoice_voice_profile_domain}
*/
export declare class AwsChimesdkvoiceVoiceProfileDomain extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_chimesdkvoice_voice_profile_domain";
    /**
    * Generates CDKTN code for importing a AwsChimesdkvoiceVoiceProfileDomain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsChimesdkvoiceVoiceProfileDomain to import
    * @param importFromId The id of the existing AwsChimesdkvoiceVoiceProfileDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_voice_profile_domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsChimesdkvoiceVoiceProfileDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_voice_profile_domain aws_chimesdkvoice_voice_profile_domain} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsChimesdkvoiceVoiceProfileDomainConfig
    */
    constructor(scope: Construct, id: string, config: AwsChimesdkvoiceVoiceProfileDomainConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _serverSideEncryptionConfiguration;
    get serverSideEncryptionConfiguration(): AwsChimesdkvoiceVoiceProfileDomain.ServerSideEncryptionConfigurationPropertyOutputReference;
    putServerSideEncryptionConfiguration(value: AwsChimesdkvoiceVoiceProfileDomain.ServerSideEncryptionConfigurationProperty): void;
    get serverSideEncryptionConfigurationInput(): AwsChimesdkvoiceVoiceProfileDomain.ServerSideEncryptionConfigurationProperty | undefined;
    private _timeouts;
    get timeouts(): AwsChimesdkvoiceVoiceProfileDomain.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsChimesdkvoiceVoiceProfileDomain.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsChimesdkvoiceVoiceProfileDomain.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsChimesdkvoiceVoiceProfileDomainServerSideEncryptionConfigurationPropertyToTerraform(struct?: AwsChimesdkvoiceVoiceProfileDomain.ServerSideEncryptionConfigurationPropertyOutputReference | AwsChimesdkvoiceVoiceProfileDomain.ServerSideEncryptionConfigurationProperty): any;
export declare function awsChimesdkvoiceVoiceProfileDomainServerSideEncryptionConfigurationPropertyToHclTerraform(struct?: AwsChimesdkvoiceVoiceProfileDomain.ServerSideEncryptionConfigurationPropertyOutputReference | AwsChimesdkvoiceVoiceProfileDomain.ServerSideEncryptionConfigurationProperty): any;
export declare function awsChimesdkvoiceVoiceProfileDomainTimeoutsPropertyToTerraform(struct?: AwsChimesdkvoiceVoiceProfileDomain.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsChimesdkvoiceVoiceProfileDomainTimeoutsPropertyToHclTerraform(struct?: AwsChimesdkvoiceVoiceProfileDomain.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsChimesdkvoiceVoiceProfileDomain {
    interface ServerSideEncryptionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_voice_profile_domain#kms_key_arn AwsChimesdkvoiceVoiceProfileDomain#kms_key_arn}
        */
        readonly kmsKeyArn: string;
    }
    class ServerSideEncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ServerSideEncryptionConfigurationProperty | undefined;
        set internalValue(value: ServerSideEncryptionConfigurationProperty | undefined);
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        get kmsKeyArnInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_voice_profile_domain#create AwsChimesdkvoiceVoiceProfileDomain#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_voice_profile_domain#delete AwsChimesdkvoiceVoiceProfileDomain#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_voice_profile_domain#update AwsChimesdkvoiceVoiceProfileDomain#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
