import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfVoiceProfileDomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_voice_profile_domain#description TfVoiceProfileDomain#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_voice_profile_domain#name TfVoiceProfileDomain#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_voice_profile_domain#region TfVoiceProfileDomain#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_voice_profile_domain#tags TfVoiceProfileDomain#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_voice_profile_domain#tags_all TfVoiceProfileDomain#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * server_side_encryption_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_voice_profile_domain#server_side_encryption_configuration TfVoiceProfileDomain#server_side_encryption_configuration}
    */
    readonly serverSideEncryptionConfiguration: TfVoiceProfileDomain.ServerSideEncryptionConfigurationProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_voice_profile_domain#timeouts TfVoiceProfileDomain#timeouts}
    */
    readonly timeouts?: TfVoiceProfileDomain.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_voice_profile_domain aws_chimesdkvoice_voice_profile_domain}
*/
export declare class TfVoiceProfileDomain extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_chimesdkvoice_voice_profile_domain";
    /**
    * Generates CDKTN code for importing a TfVoiceProfileDomain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfVoiceProfileDomain to import
    * @param importFromId The id of the existing TfVoiceProfileDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_voice_profile_domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfVoiceProfileDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_voice_profile_domain aws_chimesdkvoice_voice_profile_domain} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfVoiceProfileDomainConfig
    */
    constructor(scope: Construct, id: string, config: TfVoiceProfileDomainConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _serverSideEncryptionConfiguration;
    get serverSideEncryptionConfiguration(): TfVoiceProfileDomain.ServerSideEncryptionConfigurationPropertyOutputReference;
    putServerSideEncryptionConfiguration(value: TfVoiceProfileDomain.ServerSideEncryptionConfigurationProperty): void;
    get serverSideEncryptionConfigurationInput(): TfVoiceProfileDomain.ServerSideEncryptionConfigurationProperty | undefined;
    private _timeouts;
    get timeouts(): TfVoiceProfileDomain.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfVoiceProfileDomain.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfVoiceProfileDomain.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfVoiceProfileDomainServerSideEncryptionConfigurationPropertyToTerraform(struct?: TfVoiceProfileDomain.ServerSideEncryptionConfigurationPropertyOutputReference | TfVoiceProfileDomain.ServerSideEncryptionConfigurationProperty): any;
export declare function tfVoiceProfileDomainServerSideEncryptionConfigurationPropertyToHclTerraform(struct?: TfVoiceProfileDomain.ServerSideEncryptionConfigurationPropertyOutputReference | TfVoiceProfileDomain.ServerSideEncryptionConfigurationProperty): any;
export declare function tfVoiceProfileDomainTimeoutsPropertyToTerraform(struct?: TfVoiceProfileDomain.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfVoiceProfileDomainTimeoutsPropertyToHclTerraform(struct?: TfVoiceProfileDomain.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfVoiceProfileDomain {
    interface ServerSideEncryptionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_voice_profile_domain#kms_key_arn TfVoiceProfileDomain#kms_key_arn}
        */
        readonly kmsKeyArn: string;
    }
    class ServerSideEncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ServerSideEncryptionConfigurationProperty | undefined;
        set internalValue(value: ServerSideEncryptionConfigurationProperty | undefined);
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        get kmsKeyArnInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_voice_profile_domain#create TfVoiceProfileDomain#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_voice_profile_domain#delete TfVoiceProfileDomain#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_voice_profile_domain#update TfVoiceProfileDomain#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
