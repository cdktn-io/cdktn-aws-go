import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfSipRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_sip_rule#disabled TfSipRule#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_sip_rule#id TfSipRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_sip_rule#name TfSipRule#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_sip_rule#region TfSipRule#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_sip_rule#trigger_type TfSipRule#trigger_type}
    */
    readonly triggerType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_sip_rule#trigger_value TfSipRule#trigger_value}
    */
    readonly triggerValue: string;
    /**
    * target_applications block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_sip_rule#target_applications TfSipRule#target_applications}
    */
    readonly targetApplications: TfSipRule.TargetApplicationsProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_sip_rule aws_chimesdkvoice_sip_rule}
*/
export declare class TfSipRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_chimesdkvoice_sip_rule";
    /**
    * Generates CDKTN code for importing a TfSipRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfSipRule to import
    * @param importFromId The id of the existing TfSipRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_sip_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfSipRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_sip_rule aws_chimesdkvoice_sip_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfSipRuleConfig
    */
    constructor(scope: Construct, id: string, config: TfSipRuleConfig);
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _triggerType?;
    get triggerType(): string;
    set triggerType(value: string);
    get triggerTypeInput(): string | undefined;
    private _triggerValue?;
    get triggerValue(): string;
    set triggerValue(value: string);
    get triggerValueInput(): string | undefined;
    private _targetApplications;
    get targetApplications(): TfSipRule.TargetApplicationsPropertyList;
    putTargetApplications(value: TfSipRule.TargetApplicationsProperty[] | cdktn.IResolvable): void;
    get targetApplicationsInput(): cdktn.IResolvable | TfSipRule.TargetApplicationsProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfSipRuleTargetApplicationsPropertyToTerraform(struct?: TfSipRule.TargetApplicationsProperty | cdktn.IResolvable): any;
export declare function tfSipRuleTargetApplicationsPropertyToHclTerraform(struct?: TfSipRule.TargetApplicationsProperty | cdktn.IResolvable): any;
export declare namespace TfSipRule {
    interface TargetApplicationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_sip_rule#aws_region TfSipRule#aws_region}
        */
        readonly awsRegion: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_sip_rule#priority TfSipRule#priority}
        */
        readonly priority: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkvoice_sip_rule#sip_media_application_id TfSipRule#sip_media_application_id}
        */
        readonly sipMediaApplicationId: string;
    }
    class TargetApplicationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetApplicationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetApplicationsProperty | cdktn.IResolvable | undefined);
        private _awsRegion?;
        get awsRegion(): string;
        set awsRegion(value: string);
        get awsRegionInput(): string | undefined;
        private _priority?;
        get priority(): number;
        set priority(value: number);
        get priorityInput(): number | undefined;
        private _sipMediaApplicationId?;
        get sipMediaApplicationId(): string;
        set sipMediaApplicationId(value: string);
        get sipMediaApplicationIdInput(): string | undefined;
    }
    class TargetApplicationsPropertyList extends cdktn.ComplexList {
        internalValue?: TargetApplicationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetApplicationsPropertyOutputReference;
    }
}
