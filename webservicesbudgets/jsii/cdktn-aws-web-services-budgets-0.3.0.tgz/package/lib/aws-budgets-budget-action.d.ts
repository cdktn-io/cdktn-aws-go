import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsBudgetActionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget_action#account_id AwsBudgetAction#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget_action#action_type AwsBudgetAction#action_type}
    */
    readonly actionType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget_action#approval_model AwsBudgetAction#approval_model}
    */
    readonly approvalModel: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget_action#budget_name AwsBudgetAction#budget_name}
    */
    readonly budgetName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget_action#execution_role_arn AwsBudgetAction#execution_role_arn}
    */
    readonly executionRoleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget_action#id AwsBudgetAction#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget_action#notification_type AwsBudgetAction#notification_type}
    */
    readonly notificationType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget_action#tags AwsBudgetAction#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget_action#tags_all AwsBudgetAction#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * action_threshold block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget_action#action_threshold AwsBudgetAction#action_threshold}
    */
    readonly actionThreshold: AwsBudgetAction.ActionThresholdProperty;
    /**
    * definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget_action#definition AwsBudgetAction#definition}
    */
    readonly definition: AwsBudgetAction.DefinitionProperty;
    /**
    * subscriber block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget_action#subscriber AwsBudgetAction#subscriber}
    */
    readonly subscriber: AwsBudgetAction.SubscriberProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget_action#timeouts AwsBudgetAction#timeouts}
    */
    readonly timeouts?: AwsBudgetAction.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget_action aws_budgets_budget_action}
*/
export declare class AwsBudgetAction extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_budgets_budget_action";
    /**
    * Generates CDKTN code for importing a AwsBudgetAction resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsBudgetAction to import
    * @param importFromId The id of the existing AwsBudgetAction that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget_action#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsBudgetAction to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget_action aws_budgets_budget_action} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsBudgetActionConfig
    */
    constructor(scope: Construct, id: string, config: AwsBudgetActionConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get actionId(): string;
    private _actionType?;
    get actionType(): string;
    set actionType(value: string);
    get actionTypeInput(): string | undefined;
    private _approvalModel?;
    get approvalModel(): string;
    set approvalModel(value: string);
    get approvalModelInput(): string | undefined;
    get arn(): string;
    private _budgetName?;
    get budgetName(): string;
    set budgetName(value: string);
    get budgetNameInput(): string | undefined;
    private _executionRoleArn?;
    get executionRoleArn(): string;
    set executionRoleArn(value: string);
    get executionRoleArnInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _notificationType?;
    get notificationType(): string;
    set notificationType(value: string);
    get notificationTypeInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _actionThreshold;
    get actionThreshold(): AwsBudgetAction.ActionThresholdPropertyOutputReference;
    putActionThreshold(value: AwsBudgetAction.ActionThresholdProperty): void;
    get actionThresholdInput(): AwsBudgetAction.ActionThresholdProperty | undefined;
    private _definition;
    get definition(): AwsBudgetAction.DefinitionPropertyOutputReference;
    putDefinition(value: AwsBudgetAction.DefinitionProperty): void;
    get definitionInput(): AwsBudgetAction.DefinitionProperty | undefined;
    private _subscriber;
    get subscriber(): AwsBudgetAction.SubscriberPropertyList;
    putSubscriber(value: AwsBudgetAction.SubscriberProperty[] | cdktn.IResolvable): void;
    get subscriberInput(): cdktn.IResolvable | AwsBudgetAction.SubscriberProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsBudgetAction.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsBudgetAction.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsBudgetAction.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsBudgetActionActionThresholdPropertyToTerraform(struct?: AwsBudgetAction.ActionThresholdPropertyOutputReference | AwsBudgetAction.ActionThresholdProperty): any;
export declare function awsBudgetActionActionThresholdPropertyToHclTerraform(struct?: AwsBudgetAction.ActionThresholdPropertyOutputReference | AwsBudgetAction.ActionThresholdProperty): any;
export declare function awsBudgetActionIamActionDefinitionPropertyToTerraform(struct?: AwsBudgetAction.IamActionDefinitionPropertyOutputReference | AwsBudgetAction.IamActionDefinitionProperty): any;
export declare function awsBudgetActionIamActionDefinitionPropertyToHclTerraform(struct?: AwsBudgetAction.IamActionDefinitionPropertyOutputReference | AwsBudgetAction.IamActionDefinitionProperty): any;
export declare function awsBudgetActionScpActionDefinitionPropertyToTerraform(struct?: AwsBudgetAction.ScpActionDefinitionPropertyOutputReference | AwsBudgetAction.ScpActionDefinitionProperty): any;
export declare function awsBudgetActionScpActionDefinitionPropertyToHclTerraform(struct?: AwsBudgetAction.ScpActionDefinitionPropertyOutputReference | AwsBudgetAction.ScpActionDefinitionProperty): any;
export declare function awsBudgetActionSsmActionDefinitionPropertyToTerraform(struct?: AwsBudgetAction.SsmActionDefinitionPropertyOutputReference | AwsBudgetAction.SsmActionDefinitionProperty): any;
export declare function awsBudgetActionSsmActionDefinitionPropertyToHclTerraform(struct?: AwsBudgetAction.SsmActionDefinitionPropertyOutputReference | AwsBudgetAction.SsmActionDefinitionProperty): any;
export declare function awsBudgetActionDefinitionPropertyToTerraform(struct?: AwsBudgetAction.DefinitionPropertyOutputReference | AwsBudgetAction.DefinitionProperty): any;
export declare function awsBudgetActionDefinitionPropertyToHclTerraform(struct?: AwsBudgetAction.DefinitionPropertyOutputReference | AwsBudgetAction.DefinitionProperty): any;
export declare function awsBudgetActionSubscriberPropertyToTerraform(struct?: AwsBudgetAction.SubscriberProperty | cdktn.IResolvable): any;
export declare function awsBudgetActionSubscriberPropertyToHclTerraform(struct?: AwsBudgetAction.SubscriberProperty | cdktn.IResolvable): any;
export declare function awsBudgetActionTimeoutsPropertyToTerraform(struct?: AwsBudgetAction.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsBudgetActionTimeoutsPropertyToHclTerraform(struct?: AwsBudgetAction.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsBudgetAction {
    interface ActionThresholdProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget_action#action_threshold_type AwsBudgetAction#action_threshold_type}
        */
        readonly actionThresholdType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget_action#action_threshold_value AwsBudgetAction#action_threshold_value}
        */
        readonly actionThresholdValue: number;
    }
    class ActionThresholdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ActionThresholdProperty | undefined;
        set internalValue(value: ActionThresholdProperty | undefined);
        private _actionThresholdType?;
        get actionThresholdType(): string;
        set actionThresholdType(value: string);
        get actionThresholdTypeInput(): string | undefined;
        private _actionThresholdValue?;
        get actionThresholdValue(): number;
        set actionThresholdValue(value: number);
        get actionThresholdValueInput(): number | undefined;
    }
    interface IamActionDefinitionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget_action#groups AwsBudgetAction#groups}
        */
        readonly groups?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget_action#policy_arn AwsBudgetAction#policy_arn}
        */
        readonly policyArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget_action#roles AwsBudgetAction#roles}
        */
        readonly roles?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget_action#users AwsBudgetAction#users}
        */
        readonly users?: string[];
    }
    class IamActionDefinitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IamActionDefinitionProperty | undefined;
        set internalValue(value: IamActionDefinitionProperty | undefined);
        private _groups?;
        get groups(): string[];
        set groups(value: string[]);
        resetGroups(): void;
        get groupsInput(): string[] | undefined;
        private _policyArn?;
        get policyArn(): string;
        set policyArn(value: string);
        get policyArnInput(): string | undefined;
        private _roles?;
        get roles(): string[];
        set roles(value: string[]);
        resetRoles(): void;
        get rolesInput(): string[] | undefined;
        private _users?;
        get users(): string[];
        set users(value: string[]);
        resetUsers(): void;
        get usersInput(): string[] | undefined;
    }
    interface ScpActionDefinitionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget_action#policy_id AwsBudgetAction#policy_id}
        */
        readonly policyId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget_action#target_ids AwsBudgetAction#target_ids}
        */
        readonly targetIds: string[];
    }
    class ScpActionDefinitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ScpActionDefinitionProperty | undefined;
        set internalValue(value: ScpActionDefinitionProperty | undefined);
        private _policyId?;
        get policyId(): string;
        set policyId(value: string);
        get policyIdInput(): string | undefined;
        private _targetIds?;
        get targetIds(): string[];
        set targetIds(value: string[]);
        get targetIdsInput(): string[] | undefined;
    }
    interface SsmActionDefinitionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget_action#action_sub_type AwsBudgetAction#action_sub_type}
        */
        readonly actionSubType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget_action#instance_ids AwsBudgetAction#instance_ids}
        */
        readonly instanceIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget_action#region AwsBudgetAction#region}
        */
        readonly region: string;
    }
    class SsmActionDefinitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SsmActionDefinitionProperty | undefined;
        set internalValue(value: SsmActionDefinitionProperty | undefined);
        private _actionSubType?;
        get actionSubType(): string;
        set actionSubType(value: string);
        get actionSubTypeInput(): string | undefined;
        private _instanceIds?;
        get instanceIds(): string[];
        set instanceIds(value: string[]);
        get instanceIdsInput(): string[] | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        get regionInput(): string | undefined;
    }
    interface DefinitionProperty {
        /**
        * iam_action_definition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget_action#iam_action_definition AwsBudgetAction#iam_action_definition}
        */
        readonly iamActionDefinition?: IamActionDefinitionProperty;
        /**
        * scp_action_definition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget_action#scp_action_definition AwsBudgetAction#scp_action_definition}
        */
        readonly scpActionDefinition?: ScpActionDefinitionProperty;
        /**
        * ssm_action_definition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget_action#ssm_action_definition AwsBudgetAction#ssm_action_definition}
        */
        readonly ssmActionDefinition?: SsmActionDefinitionProperty;
    }
    class DefinitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefinitionProperty | undefined;
        set internalValue(value: DefinitionProperty | undefined);
        private _iamActionDefinition;
        get iamActionDefinition(): IamActionDefinitionPropertyOutputReference;
        putIamActionDefinition(value: IamActionDefinitionProperty): void;
        resetIamActionDefinition(): void;
        get iamActionDefinitionInput(): IamActionDefinitionProperty | undefined;
        private _scpActionDefinition;
        get scpActionDefinition(): ScpActionDefinitionPropertyOutputReference;
        putScpActionDefinition(value: ScpActionDefinitionProperty): void;
        resetScpActionDefinition(): void;
        get scpActionDefinitionInput(): ScpActionDefinitionProperty | undefined;
        private _ssmActionDefinition;
        get ssmActionDefinition(): SsmActionDefinitionPropertyOutputReference;
        putSsmActionDefinition(value: SsmActionDefinitionProperty): void;
        resetSsmActionDefinition(): void;
        get ssmActionDefinitionInput(): SsmActionDefinitionProperty | undefined;
    }
    interface SubscriberProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget_action#address AwsBudgetAction#address}
        */
        readonly address: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget_action#subscription_type AwsBudgetAction#subscription_type}
        */
        readonly subscriptionType: string;
    }
    class SubscriberPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SubscriberProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SubscriberProperty | cdktn.IResolvable | undefined);
        private _address?;
        get address(): string;
        set address(value: string);
        get addressInput(): string | undefined;
        private _subscriptionType?;
        get subscriptionType(): string;
        set subscriptionType(value: string);
        get subscriptionTypeInput(): string | undefined;
    }
    class SubscriberPropertyList extends cdktn.ComplexList {
        internalValue?: SubscriberProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SubscriberPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget_action#create AwsBudgetAction#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget_action#delete AwsBudgetAction#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget_action#update AwsBudgetAction#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
