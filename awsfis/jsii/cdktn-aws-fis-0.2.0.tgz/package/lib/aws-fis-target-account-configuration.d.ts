import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfTargetAccountConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_target_account_configuration#account_id TfTargetAccountConfiguration#account_id}
    */
    readonly accountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_target_account_configuration#description TfTargetAccountConfiguration#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_target_account_configuration#experiment_template_id TfTargetAccountConfiguration#experiment_template_id}
    */
    readonly experimentTemplateId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_target_account_configuration#region TfTargetAccountConfiguration#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_target_account_configuration#role_arn TfTargetAccountConfiguration#role_arn}
    */
    readonly roleArn?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_target_account_configuration aws_fis_target_account_configuration}
*/
export declare class TfTargetAccountConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_fis_target_account_configuration";
    /**
    * Generates CDKTN code for importing a TfTargetAccountConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfTargetAccountConfiguration to import
    * @param importFromId The id of the existing TfTargetAccountConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_target_account_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfTargetAccountConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/fis_target_account_configuration aws_fis_target_account_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfTargetAccountConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: TfTargetAccountConfigurationConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _experimentTemplateId?;
    get experimentTemplateId(): string;
    set experimentTemplateId(value: string);
    get experimentTemplateIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
