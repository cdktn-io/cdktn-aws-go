import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsRoute53RecoveryreadinessCellConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoveryreadiness_cell#cell_name AwsRoute53RecoveryreadinessCell#cell_name}
    */
    readonly cellName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoveryreadiness_cell#cells AwsRoute53RecoveryreadinessCell#cells}
    */
    readonly cells?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoveryreadiness_cell#id AwsRoute53RecoveryreadinessCell#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoveryreadiness_cell#tags AwsRoute53RecoveryreadinessCell#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoveryreadiness_cell#tags_all AwsRoute53RecoveryreadinessCell#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoveryreadiness_cell#timeouts AwsRoute53RecoveryreadinessCell#timeouts}
    */
    readonly timeouts?: AwsRoute53RecoveryreadinessCell.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoveryreadiness_cell aws_route53recoveryreadiness_cell}
*/
export declare class AwsRoute53RecoveryreadinessCell extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_route53recoveryreadiness_cell";
    /**
    * Generates CDKTN code for importing a AwsRoute53RecoveryreadinessCell resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsRoute53RecoveryreadinessCell to import
    * @param importFromId The id of the existing AwsRoute53RecoveryreadinessCell that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoveryreadiness_cell#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsRoute53RecoveryreadinessCell to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoveryreadiness_cell aws_route53recoveryreadiness_cell} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsRoute53RecoveryreadinessCellConfig
    */
    constructor(scope: Construct, id: string, config: AwsRoute53RecoveryreadinessCellConfig);
    get arn(): string;
    private _cellName?;
    get cellName(): string;
    set cellName(value: string);
    get cellNameInput(): string | undefined;
    private _cells?;
    get cells(): string[];
    set cells(value: string[]);
    resetCells(): void;
    get cellsInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get parentReadinessScopes(): string[];
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _timeouts;
    get timeouts(): AwsRoute53RecoveryreadinessCell.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsRoute53RecoveryreadinessCell.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): AwsRoute53RecoveryreadinessCell.TimeoutsProperty | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsRoute53RecoveryreadinessCellTimeoutsPropertyToTerraform(struct?: AwsRoute53RecoveryreadinessCell.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsRoute53RecoveryreadinessCellTimeoutsPropertyToHclTerraform(struct?: AwsRoute53RecoveryreadinessCell.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsRoute53RecoveryreadinessCell {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoveryreadiness_cell#delete AwsRoute53RecoveryreadinessCell#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
