import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsRoute53RecoveryreadinessRecoveryGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoveryreadiness_recovery_group#cells AwsRoute53RecoveryreadinessRecoveryGroup#cells}
    */
    readonly cells?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoveryreadiness_recovery_group#id AwsRoute53RecoveryreadinessRecoveryGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoveryreadiness_recovery_group#recovery_group_name AwsRoute53RecoveryreadinessRecoveryGroup#recovery_group_name}
    */
    readonly recoveryGroupName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoveryreadiness_recovery_group#tags AwsRoute53RecoveryreadinessRecoveryGroup#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoveryreadiness_recovery_group#tags_all AwsRoute53RecoveryreadinessRecoveryGroup#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoveryreadiness_recovery_group#timeouts AwsRoute53RecoveryreadinessRecoveryGroup#timeouts}
    */
    readonly timeouts?: AwsRoute53RecoveryreadinessRecoveryGroup.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoveryreadiness_recovery_group aws_route53recoveryreadiness_recovery_group}
*/
export declare class AwsRoute53RecoveryreadinessRecoveryGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_route53recoveryreadiness_recovery_group";
    /**
    * Generates CDKTN code for importing a AwsRoute53RecoveryreadinessRecoveryGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsRoute53RecoveryreadinessRecoveryGroup to import
    * @param importFromId The id of the existing AwsRoute53RecoveryreadinessRecoveryGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoveryreadiness_recovery_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsRoute53RecoveryreadinessRecoveryGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoveryreadiness_recovery_group aws_route53recoveryreadiness_recovery_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsRoute53RecoveryreadinessRecoveryGroupConfig
    */
    constructor(scope: Construct, id: string, config: AwsRoute53RecoveryreadinessRecoveryGroupConfig);
    get arn(): string;
    private _cells?;
    get cells(): string[];
    set cells(value: string[]);
    resetCells(): void;
    get cellsInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _recoveryGroupName?;
    get recoveryGroupName(): string;
    set recoveryGroupName(value: string);
    get recoveryGroupNameInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _timeouts;
    get timeouts(): AwsRoute53RecoveryreadinessRecoveryGroup.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsRoute53RecoveryreadinessRecoveryGroup.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsRoute53RecoveryreadinessRecoveryGroup.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsRoute53RecoveryreadinessRecoveryGroupTimeoutsPropertyToTerraform(struct?: AwsRoute53RecoveryreadinessRecoveryGroup.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsRoute53RecoveryreadinessRecoveryGroupTimeoutsPropertyToHclTerraform(struct?: AwsRoute53RecoveryreadinessRecoveryGroup.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsRoute53RecoveryreadinessRecoveryGroup {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoveryreadiness_recovery_group#delete AwsRoute53RecoveryreadinessRecoveryGroup#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
