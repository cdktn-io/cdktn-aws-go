import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsResourceSetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoveryreadiness_resource_set#id AwsResourceSet#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoveryreadiness_resource_set#resource_set_name AwsResourceSet#resource_set_name}
    */
    readonly resourceSetName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoveryreadiness_resource_set#resource_set_type AwsResourceSet#resource_set_type}
    */
    readonly resourceSetType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoveryreadiness_resource_set#tags AwsResourceSet#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoveryreadiness_resource_set#tags_all AwsResourceSet#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * resources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoveryreadiness_resource_set#resources AwsResourceSet#resources}
    */
    readonly resources: AwsResourceSet.ResourcesProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoveryreadiness_resource_set#timeouts AwsResourceSet#timeouts}
    */
    readonly timeouts?: AwsResourceSet.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoveryreadiness_resource_set aws_route53recoveryreadiness_resource_set}
*/
export declare class AwsResourceSet extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_route53recoveryreadiness_resource_set";
    /**
    * Generates CDKTN code for importing a AwsResourceSet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsResourceSet to import
    * @param importFromId The id of the existing AwsResourceSet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoveryreadiness_resource_set#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsResourceSet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoveryreadiness_resource_set aws_route53recoveryreadiness_resource_set} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsResourceSetConfig
    */
    constructor(scope: Construct, id: string, config: AwsResourceSetConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _resourceSetName?;
    get resourceSetName(): string;
    set resourceSetName(value: string);
    get resourceSetNameInput(): string | undefined;
    private _resourceSetType?;
    get resourceSetType(): string;
    set resourceSetType(value: string);
    get resourceSetTypeInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _resources;
    get resources(): AwsResourceSet.ResourcesPropertyList;
    putResources(value: AwsResourceSet.ResourcesProperty[] | cdktn.IResolvable): void;
    get resourcesInput(): cdktn.IResolvable | AwsResourceSet.ResourcesProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsResourceSet.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsResourceSet.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsResourceSet.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsResourceSetNlbResourcePropertyToTerraform(struct?: AwsResourceSet.NlbResourcePropertyOutputReference | AwsResourceSet.NlbResourceProperty): any;
export declare function awsResourceSetNlbResourcePropertyToHclTerraform(struct?: AwsResourceSet.NlbResourcePropertyOutputReference | AwsResourceSet.NlbResourceProperty): any;
export declare function awsResourceSetR53ResourcePropertyToTerraform(struct?: AwsResourceSet.R53ResourcePropertyOutputReference | AwsResourceSet.R53ResourceProperty): any;
export declare function awsResourceSetR53ResourcePropertyToHclTerraform(struct?: AwsResourceSet.R53ResourcePropertyOutputReference | AwsResourceSet.R53ResourceProperty): any;
export declare function awsResourceSetTargetResourcePropertyToTerraform(struct?: AwsResourceSet.TargetResourcePropertyOutputReference | AwsResourceSet.TargetResourceProperty): any;
export declare function awsResourceSetTargetResourcePropertyToHclTerraform(struct?: AwsResourceSet.TargetResourcePropertyOutputReference | AwsResourceSet.TargetResourceProperty): any;
export declare function awsResourceSetDnsTargetResourcePropertyToTerraform(struct?: AwsResourceSet.DnsTargetResourcePropertyOutputReference | AwsResourceSet.DnsTargetResourceProperty): any;
export declare function awsResourceSetDnsTargetResourcePropertyToHclTerraform(struct?: AwsResourceSet.DnsTargetResourcePropertyOutputReference | AwsResourceSet.DnsTargetResourceProperty): any;
export declare function awsResourceSetResourcesPropertyToTerraform(struct?: AwsResourceSet.ResourcesProperty | cdktn.IResolvable): any;
export declare function awsResourceSetResourcesPropertyToHclTerraform(struct?: AwsResourceSet.ResourcesProperty | cdktn.IResolvable): any;
export declare function awsResourceSetTimeoutsPropertyToTerraform(struct?: AwsResourceSet.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsResourceSetTimeoutsPropertyToHclTerraform(struct?: AwsResourceSet.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsResourceSet {
    interface NlbResourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoveryreadiness_resource_set#arn AwsResourceSet#arn}
        */
        readonly arn?: string;
    }
    class NlbResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NlbResourceProperty | undefined;
        set internalValue(value: NlbResourceProperty | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        resetArn(): void;
        get arnInput(): string | undefined;
    }
    interface R53ResourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoveryreadiness_resource_set#domain_name AwsResourceSet#domain_name}
        */
        readonly domainName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoveryreadiness_resource_set#record_set_id AwsResourceSet#record_set_id}
        */
        readonly recordSetId?: string;
    }
    class R53ResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): R53ResourceProperty | undefined;
        set internalValue(value: R53ResourceProperty | undefined);
        private _domainName?;
        get domainName(): string;
        set domainName(value: string);
        resetDomainName(): void;
        get domainNameInput(): string | undefined;
        private _recordSetId?;
        get recordSetId(): string;
        set recordSetId(value: string);
        resetRecordSetId(): void;
        get recordSetIdInput(): string | undefined;
    }
    interface TargetResourceProperty {
        /**
        * nlb_resource block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoveryreadiness_resource_set#nlb_resource AwsResourceSet#nlb_resource}
        */
        readonly nlbResource?: NlbResourceProperty;
        /**
        * r53_resource block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoveryreadiness_resource_set#r53_resource AwsResourceSet#r53_resource}
        */
        readonly r53Resource?: R53ResourceProperty;
    }
    class TargetResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TargetResourceProperty | undefined;
        set internalValue(value: TargetResourceProperty | undefined);
        private _nlbResource;
        get nlbResource(): NlbResourcePropertyOutputReference;
        putNlbResource(value: NlbResourceProperty): void;
        resetNlbResource(): void;
        get nlbResourceInput(): NlbResourceProperty | undefined;
        private _r53Resource;
        get r53Resource(): R53ResourcePropertyOutputReference;
        putR53Resource(value: R53ResourceProperty): void;
        resetR53Resource(): void;
        get r53ResourceInput(): R53ResourceProperty | undefined;
    }
    interface DnsTargetResourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoveryreadiness_resource_set#domain_name AwsResourceSet#domain_name}
        */
        readonly domainName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoveryreadiness_resource_set#hosted_zone_arn AwsResourceSet#hosted_zone_arn}
        */
        readonly hostedZoneArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoveryreadiness_resource_set#record_set_id AwsResourceSet#record_set_id}
        */
        readonly recordSetId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoveryreadiness_resource_set#record_type AwsResourceSet#record_type}
        */
        readonly recordType?: string;
        /**
        * target_resource block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoveryreadiness_resource_set#target_resource AwsResourceSet#target_resource}
        */
        readonly targetResource?: TargetResourceProperty;
    }
    class DnsTargetResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DnsTargetResourceProperty | undefined;
        set internalValue(value: DnsTargetResourceProperty | undefined);
        private _domainName?;
        get domainName(): string;
        set domainName(value: string);
        get domainNameInput(): string | undefined;
        private _hostedZoneArn?;
        get hostedZoneArn(): string;
        set hostedZoneArn(value: string);
        resetHostedZoneArn(): void;
        get hostedZoneArnInput(): string | undefined;
        private _recordSetId?;
        get recordSetId(): string;
        set recordSetId(value: string);
        resetRecordSetId(): void;
        get recordSetIdInput(): string | undefined;
        private _recordType?;
        get recordType(): string;
        set recordType(value: string);
        resetRecordType(): void;
        get recordTypeInput(): string | undefined;
        private _targetResource;
        get targetResource(): TargetResourcePropertyOutputReference;
        putTargetResource(value: TargetResourceProperty): void;
        resetTargetResource(): void;
        get targetResourceInput(): TargetResourceProperty | undefined;
    }
    interface ResourcesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoveryreadiness_resource_set#readiness_scopes AwsResourceSet#readiness_scopes}
        */
        readonly readinessScopes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoveryreadiness_resource_set#resource_arn AwsResourceSet#resource_arn}
        */
        readonly resourceArn?: string;
        /**
        * dns_target_resource block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoveryreadiness_resource_set#dns_target_resource AwsResourceSet#dns_target_resource}
        */
        readonly dnsTargetResource?: DnsTargetResourceProperty;
    }
    class ResourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourcesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourcesProperty | cdktn.IResolvable | undefined);
        get componentId(): string;
        private _readinessScopes?;
        get readinessScopes(): string[];
        set readinessScopes(value: string[]);
        resetReadinessScopes(): void;
        get readinessScopesInput(): string[] | undefined;
        private _resourceArn?;
        get resourceArn(): string;
        set resourceArn(value: string);
        resetResourceArn(): void;
        get resourceArnInput(): string | undefined;
        private _dnsTargetResource;
        get dnsTargetResource(): DnsTargetResourcePropertyOutputReference;
        putDnsTargetResource(value: DnsTargetResourceProperty): void;
        resetDnsTargetResource(): void;
        get dnsTargetResourceInput(): DnsTargetResourceProperty | undefined;
    }
    class ResourcesPropertyList extends cdktn.ComplexList {
        internalValue?: ResourcesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourcesPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53recoveryreadiness_resource_set#delete AwsResourceSet#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
