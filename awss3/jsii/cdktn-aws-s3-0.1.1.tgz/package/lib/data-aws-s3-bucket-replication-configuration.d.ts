import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsS3BucketReplicationConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3_bucket_replication_configuration#bucket DataAwsS3BucketReplicationConfiguration#bucket}
    */
    readonly bucket: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3_bucket_replication_configuration#region DataAwsS3BucketReplicationConfiguration#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3_bucket_replication_configuration aws_s3_bucket_replication_configuration}
*/
export declare class DataAwsS3BucketReplicationConfiguration extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_s3_bucket_replication_configuration";
    /**
    * Generates CDKTN code for importing a DataAwsS3BucketReplicationConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsS3BucketReplicationConfiguration to import
    * @param importFromId The id of the existing DataAwsS3BucketReplicationConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3_bucket_replication_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsS3BucketReplicationConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3_bucket_replication_configuration aws_s3_bucket_replication_configuration} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsS3BucketReplicationConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsS3BucketReplicationConfigurationConfig);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get role(): string;
    private _rule;
    get rule(): DataAwsS3BucketReplicationConfiguration.RulePropertyList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsS3BucketReplicationConfigurationDeleteMarkerReplicationPropertyToTerraform(struct?: DataAwsS3BucketReplicationConfiguration.DeleteMarkerReplicationProperty): any;
export declare function dataAwsS3BucketReplicationConfigurationDeleteMarkerReplicationPropertyToHclTerraform(struct?: DataAwsS3BucketReplicationConfiguration.DeleteMarkerReplicationProperty): any;
export declare function dataAwsS3BucketReplicationConfigurationAccessControlTranslationPropertyToTerraform(struct?: DataAwsS3BucketReplicationConfiguration.AccessControlTranslationProperty): any;
export declare function dataAwsS3BucketReplicationConfigurationAccessControlTranslationPropertyToHclTerraform(struct?: DataAwsS3BucketReplicationConfiguration.AccessControlTranslationProperty): any;
export declare function dataAwsS3BucketReplicationConfigurationEncryptionConfigurationPropertyToTerraform(struct?: DataAwsS3BucketReplicationConfiguration.EncryptionConfigurationProperty): any;
export declare function dataAwsS3BucketReplicationConfigurationEncryptionConfigurationPropertyToHclTerraform(struct?: DataAwsS3BucketReplicationConfiguration.EncryptionConfigurationProperty): any;
export declare function dataAwsS3BucketReplicationConfigurationEventThresholdPropertyToTerraform(struct?: DataAwsS3BucketReplicationConfiguration.EventThresholdProperty): any;
export declare function dataAwsS3BucketReplicationConfigurationEventThresholdPropertyToHclTerraform(struct?: DataAwsS3BucketReplicationConfiguration.EventThresholdProperty): any;
export declare function dataAwsS3BucketReplicationConfigurationMetricsPropertyToTerraform(struct?: DataAwsS3BucketReplicationConfiguration.MetricsProperty): any;
export declare function dataAwsS3BucketReplicationConfigurationMetricsPropertyToHclTerraform(struct?: DataAwsS3BucketReplicationConfiguration.MetricsProperty): any;
export declare function dataAwsS3BucketReplicationConfigurationTimePropertyToTerraform(struct?: DataAwsS3BucketReplicationConfiguration.TimeProperty): any;
export declare function dataAwsS3BucketReplicationConfigurationTimePropertyToHclTerraform(struct?: DataAwsS3BucketReplicationConfiguration.TimeProperty): any;
export declare function dataAwsS3BucketReplicationConfigurationReplicationTimePropertyToTerraform(struct?: DataAwsS3BucketReplicationConfiguration.ReplicationTimeProperty): any;
export declare function dataAwsS3BucketReplicationConfigurationReplicationTimePropertyToHclTerraform(struct?: DataAwsS3BucketReplicationConfiguration.ReplicationTimeProperty): any;
export declare function dataAwsS3BucketReplicationConfigurationDestinationPropertyToTerraform(struct?: DataAwsS3BucketReplicationConfiguration.DestinationProperty): any;
export declare function dataAwsS3BucketReplicationConfigurationDestinationPropertyToHclTerraform(struct?: DataAwsS3BucketReplicationConfiguration.DestinationProperty): any;
export declare function dataAwsS3BucketReplicationConfigurationExistingObjectReplicationPropertyToTerraform(struct?: DataAwsS3BucketReplicationConfiguration.ExistingObjectReplicationProperty): any;
export declare function dataAwsS3BucketReplicationConfigurationExistingObjectReplicationPropertyToHclTerraform(struct?: DataAwsS3BucketReplicationConfiguration.ExistingObjectReplicationProperty): any;
export declare function dataAwsS3BucketReplicationConfigurationRuleFilterAndTagPropertyToTerraform(struct?: DataAwsS3BucketReplicationConfiguration.RuleFilterAndTagProperty): any;
export declare function dataAwsS3BucketReplicationConfigurationRuleFilterAndTagPropertyToHclTerraform(struct?: DataAwsS3BucketReplicationConfiguration.RuleFilterAndTagProperty): any;
export declare function dataAwsS3BucketReplicationConfigurationAndPropertyToTerraform(struct?: DataAwsS3BucketReplicationConfiguration.AndProperty): any;
export declare function dataAwsS3BucketReplicationConfigurationAndPropertyToHclTerraform(struct?: DataAwsS3BucketReplicationConfiguration.AndProperty): any;
export declare function dataAwsS3BucketReplicationConfigurationRuleFilterTagPropertyToTerraform(struct?: DataAwsS3BucketReplicationConfiguration.RuleFilterTagProperty): any;
export declare function dataAwsS3BucketReplicationConfigurationRuleFilterTagPropertyToHclTerraform(struct?: DataAwsS3BucketReplicationConfiguration.RuleFilterTagProperty): any;
export declare function dataAwsS3BucketReplicationConfigurationFilterPropertyToTerraform(struct?: DataAwsS3BucketReplicationConfiguration.FilterProperty): any;
export declare function dataAwsS3BucketReplicationConfigurationFilterPropertyToHclTerraform(struct?: DataAwsS3BucketReplicationConfiguration.FilterProperty): any;
export declare function dataAwsS3BucketReplicationConfigurationReplicaModificationsPropertyToTerraform(struct?: DataAwsS3BucketReplicationConfiguration.ReplicaModificationsProperty): any;
export declare function dataAwsS3BucketReplicationConfigurationReplicaModificationsPropertyToHclTerraform(struct?: DataAwsS3BucketReplicationConfiguration.ReplicaModificationsProperty): any;
export declare function dataAwsS3BucketReplicationConfigurationSseKmsEncryptedObjectsPropertyToTerraform(struct?: DataAwsS3BucketReplicationConfiguration.SseKmsEncryptedObjectsProperty): any;
export declare function dataAwsS3BucketReplicationConfigurationSseKmsEncryptedObjectsPropertyToHclTerraform(struct?: DataAwsS3BucketReplicationConfiguration.SseKmsEncryptedObjectsProperty): any;
export declare function dataAwsS3BucketReplicationConfigurationSourceSelectionCriteriaPropertyToTerraform(struct?: DataAwsS3BucketReplicationConfiguration.SourceSelectionCriteriaProperty): any;
export declare function dataAwsS3BucketReplicationConfigurationSourceSelectionCriteriaPropertyToHclTerraform(struct?: DataAwsS3BucketReplicationConfiguration.SourceSelectionCriteriaProperty): any;
export declare function dataAwsS3BucketReplicationConfigurationRulePropertyToTerraform(struct?: DataAwsS3BucketReplicationConfiguration.RuleProperty): any;
export declare function dataAwsS3BucketReplicationConfigurationRulePropertyToHclTerraform(struct?: DataAwsS3BucketReplicationConfiguration.RuleProperty): any;
export declare namespace DataAwsS3BucketReplicationConfiguration {
    interface DeleteMarkerReplicationProperty {
    }
    class DeleteMarkerReplicationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DeleteMarkerReplicationProperty | undefined;
        set internalValue(value: DeleteMarkerReplicationProperty | undefined);
        get status(): string;
    }
    class DeleteMarkerReplicationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DeleteMarkerReplicationPropertyOutputReference;
    }
    interface AccessControlTranslationProperty {
    }
    class AccessControlTranslationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AccessControlTranslationProperty | undefined;
        set internalValue(value: AccessControlTranslationProperty | undefined);
        get owner(): string;
    }
    class AccessControlTranslationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AccessControlTranslationPropertyOutputReference;
    }
    interface EncryptionConfigurationProperty {
    }
    class EncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EncryptionConfigurationProperty | undefined;
        set internalValue(value: EncryptionConfigurationProperty | undefined);
        get replicaKmsKeyId(): string;
    }
    class EncryptionConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EncryptionConfigurationPropertyOutputReference;
    }
    interface EventThresholdProperty {
    }
    class EventThresholdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EventThresholdProperty | undefined;
        set internalValue(value: EventThresholdProperty | undefined);
        get minutes(): number;
    }
    class EventThresholdPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EventThresholdPropertyOutputReference;
    }
    interface MetricsProperty {
    }
    class MetricsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MetricsProperty | undefined;
        set internalValue(value: MetricsProperty | undefined);
        private _eventThreshold;
        get eventThreshold(): EventThresholdPropertyList;
        get status(): string;
    }
    class MetricsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MetricsPropertyOutputReference;
    }
    interface TimeProperty {
    }
    class TimePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TimeProperty | undefined;
        set internalValue(value: TimeProperty | undefined);
        get minutes(): number;
    }
    class TimePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TimePropertyOutputReference;
    }
    interface ReplicationTimeProperty {
    }
    class ReplicationTimePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReplicationTimeProperty | undefined;
        set internalValue(value: ReplicationTimeProperty | undefined);
        get status(): string;
        private _time;
        get time(): TimePropertyList;
    }
    class ReplicationTimePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReplicationTimePropertyOutputReference;
    }
    interface DestinationProperty {
    }
    class DestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DestinationProperty | undefined;
        set internalValue(value: DestinationProperty | undefined);
        private _accessControlTranslation;
        get accessControlTranslation(): AccessControlTranslationPropertyList;
        get account(): string;
        get bucket(): string;
        private _encryptionConfiguration;
        get encryptionConfiguration(): EncryptionConfigurationPropertyList;
        private _metrics;
        get metrics(): MetricsPropertyList;
        private _replicationTime;
        get replicationTime(): ReplicationTimePropertyList;
        get storageClass(): string;
    }
    class DestinationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DestinationPropertyOutputReference;
    }
    interface ExistingObjectReplicationProperty {
    }
    class ExistingObjectReplicationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExistingObjectReplicationProperty | undefined;
        set internalValue(value: ExistingObjectReplicationProperty | undefined);
        get status(): string;
    }
    class ExistingObjectReplicationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExistingObjectReplicationPropertyOutputReference;
    }
    interface RuleFilterAndTagProperty {
    }
    class RuleFilterAndTagPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleFilterAndTagProperty | undefined;
        set internalValue(value: RuleFilterAndTagProperty | undefined);
        get key(): string;
        get value(): string;
    }
    class RuleFilterAndTagPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleFilterAndTagPropertyOutputReference;
    }
    interface AndProperty {
    }
    class AndPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AndProperty | undefined;
        set internalValue(value: AndProperty | undefined);
        get prefix(): string;
        private _tag;
        get tag(): RuleFilterAndTagPropertyList;
    }
    class AndPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AndPropertyOutputReference;
    }
    interface RuleFilterTagProperty {
    }
    class RuleFilterTagPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleFilterTagProperty | undefined;
        set internalValue(value: RuleFilterTagProperty | undefined);
        get key(): string;
        get value(): string;
    }
    class RuleFilterTagPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleFilterTagPropertyOutputReference;
    }
    interface FilterProperty {
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterProperty | undefined;
        set internalValue(value: FilterProperty | undefined);
        private _and;
        get and(): AndPropertyList;
        get prefix(): string;
        private _tag;
        get tag(): RuleFilterTagPropertyList;
    }
    class FilterPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterPropertyOutputReference;
    }
    interface ReplicaModificationsProperty {
    }
    class ReplicaModificationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReplicaModificationsProperty | undefined;
        set internalValue(value: ReplicaModificationsProperty | undefined);
        get status(): string;
    }
    class ReplicaModificationsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReplicaModificationsPropertyOutputReference;
    }
    interface SseKmsEncryptedObjectsProperty {
    }
    class SseKmsEncryptedObjectsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SseKmsEncryptedObjectsProperty | undefined;
        set internalValue(value: SseKmsEncryptedObjectsProperty | undefined);
        get status(): string;
    }
    class SseKmsEncryptedObjectsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SseKmsEncryptedObjectsPropertyOutputReference;
    }
    interface SourceSelectionCriteriaProperty {
    }
    class SourceSelectionCriteriaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SourceSelectionCriteriaProperty | undefined;
        set internalValue(value: SourceSelectionCriteriaProperty | undefined);
        private _replicaModifications;
        get replicaModifications(): ReplicaModificationsPropertyList;
        private _sseKmsEncryptedObjects;
        get sseKmsEncryptedObjects(): SseKmsEncryptedObjectsPropertyList;
    }
    class SourceSelectionCriteriaPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SourceSelectionCriteriaPropertyOutputReference;
    }
    interface RuleProperty {
    }
    class RulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleProperty | undefined;
        set internalValue(value: RuleProperty | undefined);
        private _deleteMarkerReplication;
        get deleteMarkerReplication(): DeleteMarkerReplicationPropertyList;
        private _destination;
        get destination(): DestinationPropertyList;
        private _existingObjectReplication;
        get existingObjectReplication(): ExistingObjectReplicationPropertyList;
        private _filter;
        get filter(): FilterPropertyList;
        get id(): string;
        get prefix(): string;
        get priority(): number;
        private _sourceSelectionCriteria;
        get sourceSelectionCriteria(): SourceSelectionCriteriaPropertyList;
        get status(): string;
    }
    class RulePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulePropertyOutputReference;
    }
}
