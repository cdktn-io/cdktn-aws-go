import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsS3BucketLifecycleConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_lifecycle_configuration#bucket AwsS3BucketLifecycleConfiguration#bucket}
    */
    readonly bucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_lifecycle_configuration#expected_bucket_owner AwsS3BucketLifecycleConfiguration#expected_bucket_owner}
    */
    readonly expectedBucketOwner?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_lifecycle_configuration#region AwsS3BucketLifecycleConfiguration#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_lifecycle_configuration#transition_default_minimum_object_size AwsS3BucketLifecycleConfiguration#transition_default_minimum_object_size}
    */
    readonly transitionDefaultMinimumObjectSize?: string;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_lifecycle_configuration#rule AwsS3BucketLifecycleConfiguration#rule}
    */
    readonly rule?: AwsS3BucketLifecycleConfiguration.RuleProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_lifecycle_configuration#timeouts AwsS3BucketLifecycleConfiguration#timeouts}
    */
    readonly timeouts?: AwsS3BucketLifecycleConfiguration.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_lifecycle_configuration aws_s3_bucket_lifecycle_configuration}
*/
export declare class AwsS3BucketLifecycleConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3_bucket_lifecycle_configuration";
    /**
    * Generates CDKTN code for importing a AwsS3BucketLifecycleConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsS3BucketLifecycleConfiguration to import
    * @param importFromId The id of the existing AwsS3BucketLifecycleConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_lifecycle_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsS3BucketLifecycleConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_lifecycle_configuration aws_s3_bucket_lifecycle_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsS3BucketLifecycleConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsS3BucketLifecycleConfigurationConfig);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _expectedBucketOwner?;
    get expectedBucketOwner(): string;
    set expectedBucketOwner(value: string);
    resetExpectedBucketOwner(): void;
    get expectedBucketOwnerInput(): string | undefined;
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _transitionDefaultMinimumObjectSize?;
    get transitionDefaultMinimumObjectSize(): string;
    set transitionDefaultMinimumObjectSize(value: string);
    resetTransitionDefaultMinimumObjectSize(): void;
    get transitionDefaultMinimumObjectSizeInput(): string | undefined;
    private _rule;
    get rule(): AwsS3BucketLifecycleConfiguration.RulePropertyList;
    putRule(value: AwsS3BucketLifecycleConfiguration.RuleProperty[] | cdktn.IResolvable): void;
    resetRule(): void;
    get ruleInput(): cdktn.IResolvable | AwsS3BucketLifecycleConfiguration.RuleProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsS3BucketLifecycleConfiguration.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsS3BucketLifecycleConfiguration.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsS3BucketLifecycleConfiguration.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsS3BucketLifecycleConfigurationAbortIncompleteMultipartUploadPropertyToTerraform(struct?: AwsS3BucketLifecycleConfiguration.AbortIncompleteMultipartUploadProperty | cdktn.IResolvable): any;
export declare function awsS3BucketLifecycleConfigurationAbortIncompleteMultipartUploadPropertyToHclTerraform(struct?: AwsS3BucketLifecycleConfiguration.AbortIncompleteMultipartUploadProperty | cdktn.IResolvable): any;
export declare function awsS3BucketLifecycleConfigurationExpirationPropertyToTerraform(struct?: AwsS3BucketLifecycleConfiguration.ExpirationProperty | cdktn.IResolvable): any;
export declare function awsS3BucketLifecycleConfigurationExpirationPropertyToHclTerraform(struct?: AwsS3BucketLifecycleConfiguration.ExpirationProperty | cdktn.IResolvable): any;
export declare function awsS3BucketLifecycleConfigurationAndPropertyToTerraform(struct?: AwsS3BucketLifecycleConfiguration.AndProperty | cdktn.IResolvable): any;
export declare function awsS3BucketLifecycleConfigurationAndPropertyToHclTerraform(struct?: AwsS3BucketLifecycleConfiguration.AndProperty | cdktn.IResolvable): any;
export declare function awsS3BucketLifecycleConfigurationTagPropertyToTerraform(struct?: AwsS3BucketLifecycleConfiguration.TagProperty | cdktn.IResolvable): any;
export declare function awsS3BucketLifecycleConfigurationTagPropertyToHclTerraform(struct?: AwsS3BucketLifecycleConfiguration.TagProperty | cdktn.IResolvable): any;
export declare function awsS3BucketLifecycleConfigurationFilterPropertyToTerraform(struct?: AwsS3BucketLifecycleConfiguration.FilterProperty | cdktn.IResolvable): any;
export declare function awsS3BucketLifecycleConfigurationFilterPropertyToHclTerraform(struct?: AwsS3BucketLifecycleConfiguration.FilterProperty | cdktn.IResolvable): any;
export declare function awsS3BucketLifecycleConfigurationNoncurrentVersionExpirationPropertyToTerraform(struct?: AwsS3BucketLifecycleConfiguration.NoncurrentVersionExpirationProperty | cdktn.IResolvable): any;
export declare function awsS3BucketLifecycleConfigurationNoncurrentVersionExpirationPropertyToHclTerraform(struct?: AwsS3BucketLifecycleConfiguration.NoncurrentVersionExpirationProperty | cdktn.IResolvable): any;
export declare function awsS3BucketLifecycleConfigurationNoncurrentVersionTransitionPropertyToTerraform(struct?: AwsS3BucketLifecycleConfiguration.NoncurrentVersionTransitionProperty | cdktn.IResolvable): any;
export declare function awsS3BucketLifecycleConfigurationNoncurrentVersionTransitionPropertyToHclTerraform(struct?: AwsS3BucketLifecycleConfiguration.NoncurrentVersionTransitionProperty | cdktn.IResolvable): any;
export declare function awsS3BucketLifecycleConfigurationTransitionPropertyToTerraform(struct?: AwsS3BucketLifecycleConfiguration.TransitionProperty | cdktn.IResolvable): any;
export declare function awsS3BucketLifecycleConfigurationTransitionPropertyToHclTerraform(struct?: AwsS3BucketLifecycleConfiguration.TransitionProperty | cdktn.IResolvable): any;
export declare function awsS3BucketLifecycleConfigurationRulePropertyToTerraform(struct?: AwsS3BucketLifecycleConfiguration.RuleProperty | cdktn.IResolvable): any;
export declare function awsS3BucketLifecycleConfigurationRulePropertyToHclTerraform(struct?: AwsS3BucketLifecycleConfiguration.RuleProperty | cdktn.IResolvable): any;
export declare function awsS3BucketLifecycleConfigurationTimeoutsPropertyToTerraform(struct?: AwsS3BucketLifecycleConfiguration.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsS3BucketLifecycleConfigurationTimeoutsPropertyToHclTerraform(struct?: AwsS3BucketLifecycleConfiguration.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsS3BucketLifecycleConfiguration {
    interface AbortIncompleteMultipartUploadProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_lifecycle_configuration#days_after_initiation AwsS3BucketLifecycleConfiguration#days_after_initiation}
        */
        readonly daysAfterInitiation?: number;
    }
    class AbortIncompleteMultipartUploadPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AbortIncompleteMultipartUploadProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AbortIncompleteMultipartUploadProperty | cdktn.IResolvable | undefined);
        private _daysAfterInitiation?;
        get daysAfterInitiation(): number;
        set daysAfterInitiation(value: number);
        resetDaysAfterInitiation(): void;
        get daysAfterInitiationInput(): number | undefined;
    }
    class AbortIncompleteMultipartUploadPropertyList extends cdktn.ComplexList {
        internalValue?: AbortIncompleteMultipartUploadProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AbortIncompleteMultipartUploadPropertyOutputReference;
    }
    interface ExpirationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_lifecycle_configuration#date AwsS3BucketLifecycleConfiguration#date}
        */
        readonly date?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_lifecycle_configuration#days AwsS3BucketLifecycleConfiguration#days}
        */
        readonly days?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_lifecycle_configuration#expired_object_delete_marker AwsS3BucketLifecycleConfiguration#expired_object_delete_marker}
        */
        readonly expiredObjectDeleteMarker?: boolean | cdktn.IResolvable;
    }
    class ExpirationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExpirationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ExpirationProperty | cdktn.IResolvable | undefined);
        private _date?;
        get date(): string;
        set date(value: string);
        resetDate(): void;
        get dateInput(): string | undefined;
        private _days?;
        get days(): number;
        set days(value: number);
        resetDays(): void;
        get daysInput(): number | undefined;
        private _expiredObjectDeleteMarker?;
        get expiredObjectDeleteMarker(): boolean | cdktn.IResolvable;
        set expiredObjectDeleteMarker(value: boolean | cdktn.IResolvable);
        resetExpiredObjectDeleteMarker(): void;
        get expiredObjectDeleteMarkerInput(): boolean | cdktn.IResolvable | undefined;
    }
    class ExpirationPropertyList extends cdktn.ComplexList {
        internalValue?: ExpirationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExpirationPropertyOutputReference;
    }
    interface AndProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_lifecycle_configuration#object_size_greater_than AwsS3BucketLifecycleConfiguration#object_size_greater_than}
        */
        readonly objectSizeGreaterThan?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_lifecycle_configuration#object_size_less_than AwsS3BucketLifecycleConfiguration#object_size_less_than}
        */
        readonly objectSizeLessThan?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_lifecycle_configuration#prefix AwsS3BucketLifecycleConfiguration#prefix}
        */
        readonly prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_lifecycle_configuration#tags AwsS3BucketLifecycleConfiguration#tags}
        */
        readonly tags?: {
            [key: string]: string;
        };
    }
    class AndPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AndProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AndProperty | cdktn.IResolvable | undefined);
        private _objectSizeGreaterThan?;
        get objectSizeGreaterThan(): number;
        set objectSizeGreaterThan(value: number);
        resetObjectSizeGreaterThan(): void;
        get objectSizeGreaterThanInput(): number | undefined;
        private _objectSizeLessThan?;
        get objectSizeLessThan(): number;
        set objectSizeLessThan(value: number);
        resetObjectSizeLessThan(): void;
        get objectSizeLessThanInput(): number | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _tags?;
        get tags(): {
            [key: string]: string;
        };
        set tags(value: {
            [key: string]: string;
        });
        resetTags(): void;
        get tagsInput(): {
            [key: string]: string;
        } | undefined;
    }
    class AndPropertyList extends cdktn.ComplexList {
        internalValue?: AndProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AndPropertyOutputReference;
    }
    interface TagProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_lifecycle_configuration#key AwsS3BucketLifecycleConfiguration#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_lifecycle_configuration#value AwsS3BucketLifecycleConfiguration#value}
        */
        readonly value: string;
    }
    class TagPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TagProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TagProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class TagPropertyList extends cdktn.ComplexList {
        internalValue?: TagProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TagPropertyOutputReference;
    }
    interface FilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_lifecycle_configuration#object_size_greater_than AwsS3BucketLifecycleConfiguration#object_size_greater_than}
        */
        readonly objectSizeGreaterThan?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_lifecycle_configuration#object_size_less_than AwsS3BucketLifecycleConfiguration#object_size_less_than}
        */
        readonly objectSizeLessThan?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_lifecycle_configuration#prefix AwsS3BucketLifecycleConfiguration#prefix}
        */
        readonly prefix?: string;
        /**
        * and block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_lifecycle_configuration#and AwsS3BucketLifecycleConfiguration#and}
        */
        readonly and?: AndProperty[] | cdktn.IResolvable;
        /**
        * tag block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_lifecycle_configuration#tag AwsS3BucketLifecycleConfiguration#tag}
        */
        readonly tag?: TagProperty[] | cdktn.IResolvable;
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilterProperty | cdktn.IResolvable | undefined);
        private _objectSizeGreaterThan?;
        get objectSizeGreaterThan(): number;
        set objectSizeGreaterThan(value: number);
        resetObjectSizeGreaterThan(): void;
        get objectSizeGreaterThanInput(): number | undefined;
        private _objectSizeLessThan?;
        get objectSizeLessThan(): number;
        set objectSizeLessThan(value: number);
        resetObjectSizeLessThan(): void;
        get objectSizeLessThanInput(): number | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _and;
        get and(): AndPropertyList;
        putAnd(value: AndProperty[] | cdktn.IResolvable): void;
        resetAnd(): void;
        get andInput(): cdktn.IResolvable | AndProperty[] | undefined;
        private _tag;
        get tag(): TagPropertyList;
        putTag(value: TagProperty[] | cdktn.IResolvable): void;
        resetTag(): void;
        get tagInput(): cdktn.IResolvable | TagProperty[] | undefined;
    }
    class FilterPropertyList extends cdktn.ComplexList {
        internalValue?: FilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterPropertyOutputReference;
    }
    interface NoncurrentVersionExpirationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_lifecycle_configuration#newer_noncurrent_versions AwsS3BucketLifecycleConfiguration#newer_noncurrent_versions}
        */
        readonly newerNoncurrentVersions?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_lifecycle_configuration#noncurrent_days AwsS3BucketLifecycleConfiguration#noncurrent_days}
        */
        readonly noncurrentDays: number;
    }
    class NoncurrentVersionExpirationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NoncurrentVersionExpirationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NoncurrentVersionExpirationProperty | cdktn.IResolvable | undefined);
        private _newerNoncurrentVersions?;
        get newerNoncurrentVersions(): number;
        set newerNoncurrentVersions(value: number);
        resetNewerNoncurrentVersions(): void;
        get newerNoncurrentVersionsInput(): number | undefined;
        private _noncurrentDays?;
        get noncurrentDays(): number;
        set noncurrentDays(value: number);
        get noncurrentDaysInput(): number | undefined;
    }
    class NoncurrentVersionExpirationPropertyList extends cdktn.ComplexList {
        internalValue?: NoncurrentVersionExpirationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NoncurrentVersionExpirationPropertyOutputReference;
    }
    interface NoncurrentVersionTransitionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_lifecycle_configuration#newer_noncurrent_versions AwsS3BucketLifecycleConfiguration#newer_noncurrent_versions}
        */
        readonly newerNoncurrentVersions?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_lifecycle_configuration#noncurrent_days AwsS3BucketLifecycleConfiguration#noncurrent_days}
        */
        readonly noncurrentDays: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_lifecycle_configuration#storage_class AwsS3BucketLifecycleConfiguration#storage_class}
        */
        readonly storageClass: string;
    }
    class NoncurrentVersionTransitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NoncurrentVersionTransitionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NoncurrentVersionTransitionProperty | cdktn.IResolvable | undefined);
        private _newerNoncurrentVersions?;
        get newerNoncurrentVersions(): number;
        set newerNoncurrentVersions(value: number);
        resetNewerNoncurrentVersions(): void;
        get newerNoncurrentVersionsInput(): number | undefined;
        private _noncurrentDays?;
        get noncurrentDays(): number;
        set noncurrentDays(value: number);
        get noncurrentDaysInput(): number | undefined;
        private _storageClass?;
        get storageClass(): string;
        set storageClass(value: string);
        get storageClassInput(): string | undefined;
    }
    class NoncurrentVersionTransitionPropertyList extends cdktn.ComplexList {
        internalValue?: NoncurrentVersionTransitionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NoncurrentVersionTransitionPropertyOutputReference;
    }
    interface TransitionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_lifecycle_configuration#date AwsS3BucketLifecycleConfiguration#date}
        */
        readonly date?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_lifecycle_configuration#days AwsS3BucketLifecycleConfiguration#days}
        */
        readonly days?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_lifecycle_configuration#storage_class AwsS3BucketLifecycleConfiguration#storage_class}
        */
        readonly storageClass: string;
    }
    class TransitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TransitionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TransitionProperty | cdktn.IResolvable | undefined);
        private _date?;
        get date(): string;
        set date(value: string);
        resetDate(): void;
        get dateInput(): string | undefined;
        private _days?;
        get days(): number;
        set days(value: number);
        resetDays(): void;
        get daysInput(): number | undefined;
        private _storageClass?;
        get storageClass(): string;
        set storageClass(value: string);
        get storageClassInput(): string | undefined;
    }
    class TransitionPropertyList extends cdktn.ComplexList {
        internalValue?: TransitionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TransitionPropertyOutputReference;
    }
    interface RuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_lifecycle_configuration#id AwsS3BucketLifecycleConfiguration#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_lifecycle_configuration#prefix AwsS3BucketLifecycleConfiguration#prefix}
        */
        readonly prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_lifecycle_configuration#status AwsS3BucketLifecycleConfiguration#status}
        */
        readonly status: string;
        /**
        * abort_incomplete_multipart_upload block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_lifecycle_configuration#abort_incomplete_multipart_upload AwsS3BucketLifecycleConfiguration#abort_incomplete_multipart_upload}
        */
        readonly abortIncompleteMultipartUpload?: AbortIncompleteMultipartUploadProperty[] | cdktn.IResolvable;
        /**
        * expiration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_lifecycle_configuration#expiration AwsS3BucketLifecycleConfiguration#expiration}
        */
        readonly expiration?: ExpirationProperty[] | cdktn.IResolvable;
        /**
        * filter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_lifecycle_configuration#filter AwsS3BucketLifecycleConfiguration#filter}
        */
        readonly filter?: FilterProperty[] | cdktn.IResolvable;
        /**
        * noncurrent_version_expiration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_lifecycle_configuration#noncurrent_version_expiration AwsS3BucketLifecycleConfiguration#noncurrent_version_expiration}
        */
        readonly noncurrentVersionExpiration?: NoncurrentVersionExpirationProperty[] | cdktn.IResolvable;
        /**
        * noncurrent_version_transition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_lifecycle_configuration#noncurrent_version_transition AwsS3BucketLifecycleConfiguration#noncurrent_version_transition}
        */
        readonly noncurrentVersionTransition?: NoncurrentVersionTransitionProperty[] | cdktn.IResolvable;
        /**
        * transition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_lifecycle_configuration#transition AwsS3BucketLifecycleConfiguration#transition}
        */
        readonly transition?: TransitionProperty[] | cdktn.IResolvable;
    }
    class RulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleProperty | cdktn.IResolvable | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _status?;
        get status(): string;
        set status(value: string);
        get statusInput(): string | undefined;
        private _abortIncompleteMultipartUpload;
        get abortIncompleteMultipartUpload(): AbortIncompleteMultipartUploadPropertyList;
        putAbortIncompleteMultipartUpload(value: AbortIncompleteMultipartUploadProperty[] | cdktn.IResolvable): void;
        resetAbortIncompleteMultipartUpload(): void;
        get abortIncompleteMultipartUploadInput(): cdktn.IResolvable | AbortIncompleteMultipartUploadProperty[] | undefined;
        private _expiration;
        get expiration(): ExpirationPropertyList;
        putExpiration(value: ExpirationProperty[] | cdktn.IResolvable): void;
        resetExpiration(): void;
        get expirationInput(): cdktn.IResolvable | ExpirationProperty[] | undefined;
        private _filter;
        get filter(): FilterPropertyList;
        putFilter(value: FilterProperty[] | cdktn.IResolvable): void;
        resetFilter(): void;
        get filterInput(): cdktn.IResolvable | FilterProperty[] | undefined;
        private _noncurrentVersionExpiration;
        get noncurrentVersionExpiration(): NoncurrentVersionExpirationPropertyList;
        putNoncurrentVersionExpiration(value: NoncurrentVersionExpirationProperty[] | cdktn.IResolvable): void;
        resetNoncurrentVersionExpiration(): void;
        get noncurrentVersionExpirationInput(): cdktn.IResolvable | NoncurrentVersionExpirationProperty[] | undefined;
        private _noncurrentVersionTransition;
        get noncurrentVersionTransition(): NoncurrentVersionTransitionPropertyList;
        putNoncurrentVersionTransition(value: NoncurrentVersionTransitionProperty[] | cdktn.IResolvable): void;
        resetNoncurrentVersionTransition(): void;
        get noncurrentVersionTransitionInput(): cdktn.IResolvable | NoncurrentVersionTransitionProperty[] | undefined;
        private _transition;
        get transition(): TransitionPropertyList;
        putTransition(value: TransitionProperty[] | cdktn.IResolvable): void;
        resetTransition(): void;
        get transitionInput(): cdktn.IResolvable | TransitionProperty[] | undefined;
    }
    class RulePropertyList extends cdktn.ComplexList {
        internalValue?: RuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulePropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_lifecycle_configuration#create AwsS3BucketLifecycleConfiguration#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_lifecycle_configuration#update AwsS3BucketLifecycleConfiguration#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
