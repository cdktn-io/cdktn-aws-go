import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsS3BucketAnalyticsConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_analytics_configuration#bucket AwsS3BucketAnalyticsConfiguration#bucket}
    */
    readonly bucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_analytics_configuration#id AwsS3BucketAnalyticsConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_analytics_configuration#name AwsS3BucketAnalyticsConfiguration#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_analytics_configuration#region AwsS3BucketAnalyticsConfiguration#region}
    */
    readonly region?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_analytics_configuration#filter AwsS3BucketAnalyticsConfiguration#filter}
    */
    readonly filter?: AwsS3BucketAnalyticsConfiguration.FilterProperty;
    /**
    * storage_class_analysis block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_analytics_configuration#storage_class_analysis AwsS3BucketAnalyticsConfiguration#storage_class_analysis}
    */
    readonly storageClassAnalysis?: AwsS3BucketAnalyticsConfiguration.StorageClassAnalysisProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_analytics_configuration aws_s3_bucket_analytics_configuration}
*/
export declare class AwsS3BucketAnalyticsConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3_bucket_analytics_configuration";
    /**
    * Generates CDKTN code for importing a AwsS3BucketAnalyticsConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsS3BucketAnalyticsConfiguration to import
    * @param importFromId The id of the existing AwsS3BucketAnalyticsConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_analytics_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsS3BucketAnalyticsConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_analytics_configuration aws_s3_bucket_analytics_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsS3BucketAnalyticsConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsS3BucketAnalyticsConfigurationConfig);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _filter;
    get filter(): AwsS3BucketAnalyticsConfiguration.FilterPropertyOutputReference;
    putFilter(value: AwsS3BucketAnalyticsConfiguration.FilterProperty): void;
    resetFilter(): void;
    get filterInput(): AwsS3BucketAnalyticsConfiguration.FilterProperty | undefined;
    private _storageClassAnalysis;
    get storageClassAnalysis(): AwsS3BucketAnalyticsConfiguration.StorageClassAnalysisPropertyOutputReference;
    putStorageClassAnalysis(value: AwsS3BucketAnalyticsConfiguration.StorageClassAnalysisProperty): void;
    resetStorageClassAnalysis(): void;
    get storageClassAnalysisInput(): AwsS3BucketAnalyticsConfiguration.StorageClassAnalysisProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsS3BucketAnalyticsConfigurationFilterPropertyToTerraform(struct?: AwsS3BucketAnalyticsConfiguration.FilterPropertyOutputReference | AwsS3BucketAnalyticsConfiguration.FilterProperty): any;
export declare function awsS3BucketAnalyticsConfigurationFilterPropertyToHclTerraform(struct?: AwsS3BucketAnalyticsConfiguration.FilterPropertyOutputReference | AwsS3BucketAnalyticsConfiguration.FilterProperty): any;
export declare function awsS3BucketAnalyticsConfigurationS3BucketDestinationPropertyToTerraform(struct?: AwsS3BucketAnalyticsConfiguration.S3BucketDestinationPropertyOutputReference | AwsS3BucketAnalyticsConfiguration.S3BucketDestinationProperty): any;
export declare function awsS3BucketAnalyticsConfigurationS3BucketDestinationPropertyToHclTerraform(struct?: AwsS3BucketAnalyticsConfiguration.S3BucketDestinationPropertyOutputReference | AwsS3BucketAnalyticsConfiguration.S3BucketDestinationProperty): any;
export declare function awsS3BucketAnalyticsConfigurationDestinationPropertyToTerraform(struct?: AwsS3BucketAnalyticsConfiguration.DestinationPropertyOutputReference | AwsS3BucketAnalyticsConfiguration.DestinationProperty): any;
export declare function awsS3BucketAnalyticsConfigurationDestinationPropertyToHclTerraform(struct?: AwsS3BucketAnalyticsConfiguration.DestinationPropertyOutputReference | AwsS3BucketAnalyticsConfiguration.DestinationProperty): any;
export declare function awsS3BucketAnalyticsConfigurationDataExportPropertyToTerraform(struct?: AwsS3BucketAnalyticsConfiguration.DataExportPropertyOutputReference | AwsS3BucketAnalyticsConfiguration.DataExportProperty): any;
export declare function awsS3BucketAnalyticsConfigurationDataExportPropertyToHclTerraform(struct?: AwsS3BucketAnalyticsConfiguration.DataExportPropertyOutputReference | AwsS3BucketAnalyticsConfiguration.DataExportProperty): any;
export declare function awsS3BucketAnalyticsConfigurationStorageClassAnalysisPropertyToTerraform(struct?: AwsS3BucketAnalyticsConfiguration.StorageClassAnalysisPropertyOutputReference | AwsS3BucketAnalyticsConfiguration.StorageClassAnalysisProperty): any;
export declare function awsS3BucketAnalyticsConfigurationStorageClassAnalysisPropertyToHclTerraform(struct?: AwsS3BucketAnalyticsConfiguration.StorageClassAnalysisPropertyOutputReference | AwsS3BucketAnalyticsConfiguration.StorageClassAnalysisProperty): any;
export declare namespace AwsS3BucketAnalyticsConfiguration {
    interface FilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_analytics_configuration#prefix AwsS3BucketAnalyticsConfiguration#prefix}
        */
        readonly prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_analytics_configuration#tags AwsS3BucketAnalyticsConfiguration#tags}
        */
        readonly tags?: {
            [key: string]: string;
        };
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterProperty | undefined;
        set internalValue(value: FilterProperty | undefined);
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _tags?;
        get tags(): {
            [key: string]: string;
        };
        set tags(value: {
            [key: string]: string;
        });
        resetTags(): void;
        get tagsInput(): {
            [key: string]: string;
        } | undefined;
    }
    interface S3BucketDestinationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_analytics_configuration#bucket_account_id AwsS3BucketAnalyticsConfiguration#bucket_account_id}
        */
        readonly bucketAccountId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_analytics_configuration#bucket_arn AwsS3BucketAnalyticsConfiguration#bucket_arn}
        */
        readonly bucketArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_analytics_configuration#format AwsS3BucketAnalyticsConfiguration#format}
        */
        readonly format?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_analytics_configuration#prefix AwsS3BucketAnalyticsConfiguration#prefix}
        */
        readonly prefix?: string;
    }
    class S3BucketDestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3BucketDestinationProperty | undefined;
        set internalValue(value: S3BucketDestinationProperty | undefined);
        private _bucketAccountId?;
        get bucketAccountId(): string;
        set bucketAccountId(value: string);
        resetBucketAccountId(): void;
        get bucketAccountIdInput(): string | undefined;
        private _bucketArn?;
        get bucketArn(): string;
        set bucketArn(value: string);
        get bucketArnInput(): string | undefined;
        private _format?;
        get format(): string;
        set format(value: string);
        resetFormat(): void;
        get formatInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
    }
    interface DestinationProperty {
        /**
        * s3_bucket_destination block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_analytics_configuration#s3_bucket_destination AwsS3BucketAnalyticsConfiguration#s3_bucket_destination}
        */
        readonly s3BucketDestination: S3BucketDestinationProperty;
    }
    class DestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationProperty | undefined;
        set internalValue(value: DestinationProperty | undefined);
        private _s3BucketDestination;
        get s3BucketDestination(): S3BucketDestinationPropertyOutputReference;
        putS3BucketDestination(value: S3BucketDestinationProperty): void;
        get s3BucketDestinationInput(): S3BucketDestinationProperty | undefined;
    }
    interface DataExportProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_analytics_configuration#output_schema_version AwsS3BucketAnalyticsConfiguration#output_schema_version}
        */
        readonly outputSchemaVersion?: string;
        /**
        * destination block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_analytics_configuration#destination AwsS3BucketAnalyticsConfiguration#destination}
        */
        readonly destination: DestinationProperty;
    }
    class DataExportPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DataExportProperty | undefined;
        set internalValue(value: DataExportProperty | undefined);
        private _outputSchemaVersion?;
        get outputSchemaVersion(): string;
        set outputSchemaVersion(value: string);
        resetOutputSchemaVersion(): void;
        get outputSchemaVersionInput(): string | undefined;
        private _destination;
        get destination(): DestinationPropertyOutputReference;
        putDestination(value: DestinationProperty): void;
        get destinationInput(): DestinationProperty | undefined;
    }
    interface StorageClassAnalysisProperty {
        /**
        * data_export block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_analytics_configuration#data_export AwsS3BucketAnalyticsConfiguration#data_export}
        */
        readonly dataExport: DataExportProperty;
    }
    class StorageClassAnalysisPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StorageClassAnalysisProperty | undefined;
        set internalValue(value: StorageClassAnalysisProperty | undefined);
        private _dataExport;
        get dataExport(): DataExportPropertyOutputReference;
        putDataExport(value: DataExportProperty): void;
        get dataExportInput(): DataExportProperty | undefined;
    }
}
