import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsS3BucketMetadataConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_metadata_configuration#bucket AwsS3BucketMetadataConfiguration#bucket}
    */
    readonly bucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_metadata_configuration#expected_bucket_owner AwsS3BucketMetadataConfiguration#expected_bucket_owner}
    */
    readonly expectedBucketOwner?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_metadata_configuration#region AwsS3BucketMetadataConfiguration#region}
    */
    readonly region?: string;
    /**
    * metadata_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_metadata_configuration#metadata_configuration AwsS3BucketMetadataConfiguration#metadata_configuration}
    */
    readonly metadataConfiguration?: AwsS3BucketMetadataConfiguration.MetadataConfigurationProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_metadata_configuration#timeouts AwsS3BucketMetadataConfiguration#timeouts}
    */
    readonly timeouts?: AwsS3BucketMetadataConfiguration.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_metadata_configuration aws_s3_bucket_metadata_configuration}
*/
export declare class AwsS3BucketMetadataConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3_bucket_metadata_configuration";
    /**
    * Generates CDKTN code for importing a AwsS3BucketMetadataConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsS3BucketMetadataConfiguration to import
    * @param importFromId The id of the existing AwsS3BucketMetadataConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_metadata_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsS3BucketMetadataConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_metadata_configuration aws_s3_bucket_metadata_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsS3BucketMetadataConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsS3BucketMetadataConfigurationConfig);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _expectedBucketOwner?;
    get expectedBucketOwner(): string;
    set expectedBucketOwner(value: string);
    resetExpectedBucketOwner(): void;
    get expectedBucketOwnerInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _metadataConfiguration;
    get metadataConfiguration(): AwsS3BucketMetadataConfiguration.MetadataConfigurationPropertyList;
    putMetadataConfiguration(value: AwsS3BucketMetadataConfiguration.MetadataConfigurationProperty[] | cdktn.IResolvable): void;
    resetMetadataConfiguration(): void;
    get metadataConfigurationInput(): cdktn.IResolvable | AwsS3BucketMetadataConfiguration.MetadataConfigurationProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsS3BucketMetadataConfiguration.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsS3BucketMetadataConfiguration.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsS3BucketMetadataConfiguration.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsS3BucketMetadataConfigurationDestinationPropertyToTerraform(struct?: AwsS3BucketMetadataConfiguration.DestinationProperty): any;
export declare function awsS3BucketMetadataConfigurationDestinationPropertyToHclTerraform(struct?: AwsS3BucketMetadataConfiguration.DestinationProperty): any;
export declare function awsS3BucketMetadataConfigurationMetadataConfigurationInventoryTableConfigurationEncryptionConfigurationPropertyToTerraform(struct?: AwsS3BucketMetadataConfiguration.MetadataConfigurationInventoryTableConfigurationEncryptionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsS3BucketMetadataConfigurationMetadataConfigurationInventoryTableConfigurationEncryptionConfigurationPropertyToHclTerraform(struct?: AwsS3BucketMetadataConfiguration.MetadataConfigurationInventoryTableConfigurationEncryptionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsS3BucketMetadataConfigurationInventoryTableConfigurationPropertyToTerraform(struct?: AwsS3BucketMetadataConfiguration.InventoryTableConfigurationProperty | cdktn.IResolvable): any;
export declare function awsS3BucketMetadataConfigurationInventoryTableConfigurationPropertyToHclTerraform(struct?: AwsS3BucketMetadataConfiguration.InventoryTableConfigurationProperty | cdktn.IResolvable): any;
export declare function awsS3BucketMetadataConfigurationMetadataConfigurationJournalTableConfigurationEncryptionConfigurationPropertyToTerraform(struct?: AwsS3BucketMetadataConfiguration.MetadataConfigurationJournalTableConfigurationEncryptionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsS3BucketMetadataConfigurationMetadataConfigurationJournalTableConfigurationEncryptionConfigurationPropertyToHclTerraform(struct?: AwsS3BucketMetadataConfiguration.MetadataConfigurationJournalTableConfigurationEncryptionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsS3BucketMetadataConfigurationRecordExpirationPropertyToTerraform(struct?: AwsS3BucketMetadataConfiguration.RecordExpirationProperty | cdktn.IResolvable): any;
export declare function awsS3BucketMetadataConfigurationRecordExpirationPropertyToHclTerraform(struct?: AwsS3BucketMetadataConfiguration.RecordExpirationProperty | cdktn.IResolvable): any;
export declare function awsS3BucketMetadataConfigurationJournalTableConfigurationPropertyToTerraform(struct?: AwsS3BucketMetadataConfiguration.JournalTableConfigurationProperty | cdktn.IResolvable): any;
export declare function awsS3BucketMetadataConfigurationJournalTableConfigurationPropertyToHclTerraform(struct?: AwsS3BucketMetadataConfiguration.JournalTableConfigurationProperty | cdktn.IResolvable): any;
export declare function awsS3BucketMetadataConfigurationMetadataConfigurationPropertyToTerraform(struct?: AwsS3BucketMetadataConfiguration.MetadataConfigurationProperty | cdktn.IResolvable): any;
export declare function awsS3BucketMetadataConfigurationMetadataConfigurationPropertyToHclTerraform(struct?: AwsS3BucketMetadataConfiguration.MetadataConfigurationProperty | cdktn.IResolvable): any;
export declare function awsS3BucketMetadataConfigurationTimeoutsPropertyToTerraform(struct?: AwsS3BucketMetadataConfiguration.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsS3BucketMetadataConfigurationTimeoutsPropertyToHclTerraform(struct?: AwsS3BucketMetadataConfiguration.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsS3BucketMetadataConfiguration {
    interface DestinationProperty {
    }
    class DestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DestinationProperty | undefined;
        set internalValue(value: DestinationProperty | undefined);
        get tableBucketArn(): string;
        get tableBucketType(): string;
        get tableNamespace(): string;
    }
    class DestinationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DestinationPropertyOutputReference;
    }
    interface MetadataConfigurationInventoryTableConfigurationEncryptionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_metadata_configuration#kms_key_arn AwsS3BucketMetadataConfiguration#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_metadata_configuration#sse_algorithm AwsS3BucketMetadataConfiguration#sse_algorithm}
        */
        readonly sseAlgorithm: string;
    }
    class MetadataConfigurationInventoryTableConfigurationEncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MetadataConfigurationInventoryTableConfigurationEncryptionConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MetadataConfigurationInventoryTableConfigurationEncryptionConfigurationProperty | cdktn.IResolvable | undefined);
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
        private _sseAlgorithm?;
        get sseAlgorithm(): string;
        set sseAlgorithm(value: string);
        get sseAlgorithmInput(): string | undefined;
    }
    class MetadataConfigurationInventoryTableConfigurationEncryptionConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: MetadataConfigurationInventoryTableConfigurationEncryptionConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MetadataConfigurationInventoryTableConfigurationEncryptionConfigurationPropertyOutputReference;
    }
    interface InventoryTableConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_metadata_configuration#configuration_state AwsS3BucketMetadataConfiguration#configuration_state}
        */
        readonly configurationState: string;
        /**
        * encryption_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_metadata_configuration#encryption_configuration AwsS3BucketMetadataConfiguration#encryption_configuration}
        */
        readonly encryptionConfiguration?: MetadataConfigurationInventoryTableConfigurationEncryptionConfigurationProperty[] | cdktn.IResolvable;
    }
    class InventoryTableConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InventoryTableConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InventoryTableConfigurationProperty | cdktn.IResolvable | undefined);
        private _configurationState?;
        get configurationState(): string;
        set configurationState(value: string);
        get configurationStateInput(): string | undefined;
        get tableArn(): string;
        get tableName(): string;
        private _encryptionConfiguration;
        get encryptionConfiguration(): MetadataConfigurationInventoryTableConfigurationEncryptionConfigurationPropertyList;
        putEncryptionConfiguration(value: MetadataConfigurationInventoryTableConfigurationEncryptionConfigurationProperty[] | cdktn.IResolvable): void;
        resetEncryptionConfiguration(): void;
        get encryptionConfigurationInput(): cdktn.IResolvable | MetadataConfigurationInventoryTableConfigurationEncryptionConfigurationProperty[] | undefined;
    }
    class InventoryTableConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: InventoryTableConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InventoryTableConfigurationPropertyOutputReference;
    }
    interface MetadataConfigurationJournalTableConfigurationEncryptionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_metadata_configuration#kms_key_arn AwsS3BucketMetadataConfiguration#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_metadata_configuration#sse_algorithm AwsS3BucketMetadataConfiguration#sse_algorithm}
        */
        readonly sseAlgorithm: string;
    }
    class MetadataConfigurationJournalTableConfigurationEncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MetadataConfigurationJournalTableConfigurationEncryptionConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MetadataConfigurationJournalTableConfigurationEncryptionConfigurationProperty | cdktn.IResolvable | undefined);
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
        private _sseAlgorithm?;
        get sseAlgorithm(): string;
        set sseAlgorithm(value: string);
        get sseAlgorithmInput(): string | undefined;
    }
    class MetadataConfigurationJournalTableConfigurationEncryptionConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: MetadataConfigurationJournalTableConfigurationEncryptionConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MetadataConfigurationJournalTableConfigurationEncryptionConfigurationPropertyOutputReference;
    }
    interface RecordExpirationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_metadata_configuration#days AwsS3BucketMetadataConfiguration#days}
        */
        readonly days?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_metadata_configuration#expiration AwsS3BucketMetadataConfiguration#expiration}
        */
        readonly expiration: string;
    }
    class RecordExpirationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RecordExpirationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RecordExpirationProperty | cdktn.IResolvable | undefined);
        private _days?;
        get days(): number;
        set days(value: number);
        resetDays(): void;
        get daysInput(): number | undefined;
        private _expiration?;
        get expiration(): string;
        set expiration(value: string);
        get expirationInput(): string | undefined;
    }
    class RecordExpirationPropertyList extends cdktn.ComplexList {
        internalValue?: RecordExpirationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RecordExpirationPropertyOutputReference;
    }
    interface JournalTableConfigurationProperty {
        /**
        * encryption_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_metadata_configuration#encryption_configuration AwsS3BucketMetadataConfiguration#encryption_configuration}
        */
        readonly encryptionConfiguration?: MetadataConfigurationJournalTableConfigurationEncryptionConfigurationProperty[] | cdktn.IResolvable;
        /**
        * record_expiration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_metadata_configuration#record_expiration AwsS3BucketMetadataConfiguration#record_expiration}
        */
        readonly recordExpiration?: RecordExpirationProperty[] | cdktn.IResolvable;
    }
    class JournalTableConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): JournalTableConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: JournalTableConfigurationProperty | cdktn.IResolvable | undefined);
        get tableArn(): string;
        get tableName(): string;
        private _encryptionConfiguration;
        get encryptionConfiguration(): MetadataConfigurationJournalTableConfigurationEncryptionConfigurationPropertyList;
        putEncryptionConfiguration(value: MetadataConfigurationJournalTableConfigurationEncryptionConfigurationProperty[] | cdktn.IResolvable): void;
        resetEncryptionConfiguration(): void;
        get encryptionConfigurationInput(): cdktn.IResolvable | MetadataConfigurationJournalTableConfigurationEncryptionConfigurationProperty[] | undefined;
        private _recordExpiration;
        get recordExpiration(): RecordExpirationPropertyList;
        putRecordExpiration(value: RecordExpirationProperty[] | cdktn.IResolvable): void;
        resetRecordExpiration(): void;
        get recordExpirationInput(): cdktn.IResolvable | RecordExpirationProperty[] | undefined;
    }
    class JournalTableConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: JournalTableConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): JournalTableConfigurationPropertyOutputReference;
    }
    interface MetadataConfigurationProperty {
        /**
        * inventory_table_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_metadata_configuration#inventory_table_configuration AwsS3BucketMetadataConfiguration#inventory_table_configuration}
        */
        readonly inventoryTableConfiguration?: InventoryTableConfigurationProperty[] | cdktn.IResolvable;
        /**
        * journal_table_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_metadata_configuration#journal_table_configuration AwsS3BucketMetadataConfiguration#journal_table_configuration}
        */
        readonly journalTableConfiguration?: JournalTableConfigurationProperty[] | cdktn.IResolvable;
    }
    class MetadataConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MetadataConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MetadataConfigurationProperty | cdktn.IResolvable | undefined);
        private _destination;
        get destination(): DestinationPropertyList;
        private _inventoryTableConfiguration;
        get inventoryTableConfiguration(): InventoryTableConfigurationPropertyList;
        putInventoryTableConfiguration(value: InventoryTableConfigurationProperty[] | cdktn.IResolvable): void;
        resetInventoryTableConfiguration(): void;
        get inventoryTableConfigurationInput(): cdktn.IResolvable | InventoryTableConfigurationProperty[] | undefined;
        private _journalTableConfiguration;
        get journalTableConfiguration(): JournalTableConfigurationPropertyList;
        putJournalTableConfiguration(value: JournalTableConfigurationProperty[] | cdktn.IResolvable): void;
        resetJournalTableConfiguration(): void;
        get journalTableConfigurationInput(): cdktn.IResolvable | JournalTableConfigurationProperty[] | undefined;
    }
    class MetadataConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: MetadataConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MetadataConfigurationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_metadata_configuration#create AwsS3BucketMetadataConfiguration#create}
        */
        readonly create?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
    }
}
