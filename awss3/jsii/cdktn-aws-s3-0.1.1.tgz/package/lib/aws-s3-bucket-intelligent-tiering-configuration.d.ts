import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsS3BucketIntelligentTieringConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_intelligent_tiering_configuration#bucket AwsS3BucketIntelligentTieringConfiguration#bucket}
    */
    readonly bucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_intelligent_tiering_configuration#id AwsS3BucketIntelligentTieringConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_intelligent_tiering_configuration#name AwsS3BucketIntelligentTieringConfiguration#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_intelligent_tiering_configuration#region AwsS3BucketIntelligentTieringConfiguration#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_intelligent_tiering_configuration#status AwsS3BucketIntelligentTieringConfiguration#status}
    */
    readonly status?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_intelligent_tiering_configuration#filter AwsS3BucketIntelligentTieringConfiguration#filter}
    */
    readonly filter?: AwsS3BucketIntelligentTieringConfiguration.FilterProperty;
    /**
    * tiering block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_intelligent_tiering_configuration#tiering AwsS3BucketIntelligentTieringConfiguration#tiering}
    */
    readonly tiering: AwsS3BucketIntelligentTieringConfiguration.TieringProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_intelligent_tiering_configuration aws_s3_bucket_intelligent_tiering_configuration}
*/
export declare class AwsS3BucketIntelligentTieringConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3_bucket_intelligent_tiering_configuration";
    /**
    * Generates CDKTN code for importing a AwsS3BucketIntelligentTieringConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsS3BucketIntelligentTieringConfiguration to import
    * @param importFromId The id of the existing AwsS3BucketIntelligentTieringConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_intelligent_tiering_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsS3BucketIntelligentTieringConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_intelligent_tiering_configuration aws_s3_bucket_intelligent_tiering_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsS3BucketIntelligentTieringConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsS3BucketIntelligentTieringConfigurationConfig);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _filter;
    get filter(): AwsS3BucketIntelligentTieringConfiguration.FilterPropertyOutputReference;
    putFilter(value: AwsS3BucketIntelligentTieringConfiguration.FilterProperty): void;
    resetFilter(): void;
    get filterInput(): AwsS3BucketIntelligentTieringConfiguration.FilterProperty | undefined;
    private _tiering;
    get tiering(): AwsS3BucketIntelligentTieringConfiguration.TieringPropertyList;
    putTiering(value: AwsS3BucketIntelligentTieringConfiguration.TieringProperty[] | cdktn.IResolvable): void;
    get tieringInput(): cdktn.IResolvable | AwsS3BucketIntelligentTieringConfiguration.TieringProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsS3BucketIntelligentTieringConfigurationFilterPropertyToTerraform(struct?: AwsS3BucketIntelligentTieringConfiguration.FilterPropertyOutputReference | AwsS3BucketIntelligentTieringConfiguration.FilterProperty): any;
export declare function awsS3BucketIntelligentTieringConfigurationFilterPropertyToHclTerraform(struct?: AwsS3BucketIntelligentTieringConfiguration.FilterPropertyOutputReference | AwsS3BucketIntelligentTieringConfiguration.FilterProperty): any;
export declare function awsS3BucketIntelligentTieringConfigurationTieringPropertyToTerraform(struct?: AwsS3BucketIntelligentTieringConfiguration.TieringProperty | cdktn.IResolvable): any;
export declare function awsS3BucketIntelligentTieringConfigurationTieringPropertyToHclTerraform(struct?: AwsS3BucketIntelligentTieringConfiguration.TieringProperty | cdktn.IResolvable): any;
export declare namespace AwsS3BucketIntelligentTieringConfiguration {
    interface FilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_intelligent_tiering_configuration#prefix AwsS3BucketIntelligentTieringConfiguration#prefix}
        */
        readonly prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_intelligent_tiering_configuration#tags AwsS3BucketIntelligentTieringConfiguration#tags}
        */
        readonly tags?: {
            [key: string]: string;
        };
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterProperty | undefined;
        set internalValue(value: FilterProperty | undefined);
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _tags?;
        get tags(): {
            [key: string]: string;
        };
        set tags(value: {
            [key: string]: string;
        });
        resetTags(): void;
        get tagsInput(): {
            [key: string]: string;
        } | undefined;
    }
    interface TieringProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_intelligent_tiering_configuration#access_tier AwsS3BucketIntelligentTieringConfiguration#access_tier}
        */
        readonly accessTier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_intelligent_tiering_configuration#days AwsS3BucketIntelligentTieringConfiguration#days}
        */
        readonly days: number;
    }
    class TieringPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TieringProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TieringProperty | cdktn.IResolvable | undefined);
        private _accessTier?;
        get accessTier(): string;
        set accessTier(value: string);
        get accessTierInput(): string | undefined;
        private _days?;
        get days(): number;
        set days(value: number);
        get daysInput(): number | undefined;
    }
    class TieringPropertyList extends cdktn.ComplexList {
        internalValue?: TieringProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TieringPropertyOutputReference;
    }
}
