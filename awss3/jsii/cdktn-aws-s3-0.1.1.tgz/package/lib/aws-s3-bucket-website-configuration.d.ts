import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsS3BucketWebsiteConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_website_configuration#bucket AwsS3BucketWebsiteConfiguration#bucket}
    */
    readonly bucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_website_configuration#expected_bucket_owner AwsS3BucketWebsiteConfiguration#expected_bucket_owner}
    */
    readonly expectedBucketOwner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_website_configuration#id AwsS3BucketWebsiteConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_website_configuration#region AwsS3BucketWebsiteConfiguration#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_website_configuration#routing_rules AwsS3BucketWebsiteConfiguration#routing_rules}
    */
    readonly routingRules?: string;
    /**
    * error_document block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_website_configuration#error_document AwsS3BucketWebsiteConfiguration#error_document}
    */
    readonly errorDocument?: AwsS3BucketWebsiteConfiguration.ErrorDocumentProperty;
    /**
    * index_document block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_website_configuration#index_document AwsS3BucketWebsiteConfiguration#index_document}
    */
    readonly indexDocument?: AwsS3BucketWebsiteConfiguration.IndexDocumentProperty;
    /**
    * redirect_all_requests_to block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_website_configuration#redirect_all_requests_to AwsS3BucketWebsiteConfiguration#redirect_all_requests_to}
    */
    readonly redirectAllRequestsTo?: AwsS3BucketWebsiteConfiguration.RedirectAllRequestsToProperty;
    /**
    * routing_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_website_configuration#routing_rule AwsS3BucketWebsiteConfiguration#routing_rule}
    */
    readonly routingRule?: AwsS3BucketWebsiteConfiguration.RoutingRuleProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_website_configuration aws_s3_bucket_website_configuration}
*/
export declare class AwsS3BucketWebsiteConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3_bucket_website_configuration";
    /**
    * Generates CDKTN code for importing a AwsS3BucketWebsiteConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsS3BucketWebsiteConfiguration to import
    * @param importFromId The id of the existing AwsS3BucketWebsiteConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_website_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsS3BucketWebsiteConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_website_configuration aws_s3_bucket_website_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsS3BucketWebsiteConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsS3BucketWebsiteConfigurationConfig);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _expectedBucketOwner?;
    get expectedBucketOwner(): string;
    set expectedBucketOwner(value: string);
    resetExpectedBucketOwner(): void;
    get expectedBucketOwnerInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _routingRules?;
    get routingRules(): string;
    set routingRules(value: string);
    resetRoutingRules(): void;
    get routingRulesInput(): string | undefined;
    get websiteDomain(): string;
    get websiteEndpoint(): string;
    private _errorDocument;
    get errorDocument(): AwsS3BucketWebsiteConfiguration.ErrorDocumentPropertyOutputReference;
    putErrorDocument(value: AwsS3BucketWebsiteConfiguration.ErrorDocumentProperty): void;
    resetErrorDocument(): void;
    get errorDocumentInput(): AwsS3BucketWebsiteConfiguration.ErrorDocumentProperty | undefined;
    private _indexDocument;
    get indexDocument(): AwsS3BucketWebsiteConfiguration.IndexDocumentPropertyOutputReference;
    putIndexDocument(value: AwsS3BucketWebsiteConfiguration.IndexDocumentProperty): void;
    resetIndexDocument(): void;
    get indexDocumentInput(): AwsS3BucketWebsiteConfiguration.IndexDocumentProperty | undefined;
    private _redirectAllRequestsTo;
    get redirectAllRequestsTo(): AwsS3BucketWebsiteConfiguration.RedirectAllRequestsToPropertyOutputReference;
    putRedirectAllRequestsTo(value: AwsS3BucketWebsiteConfiguration.RedirectAllRequestsToProperty): void;
    resetRedirectAllRequestsTo(): void;
    get redirectAllRequestsToInput(): AwsS3BucketWebsiteConfiguration.RedirectAllRequestsToProperty | undefined;
    private _routingRule;
    get routingRule(): AwsS3BucketWebsiteConfiguration.RoutingRulePropertyList;
    putRoutingRule(value: AwsS3BucketWebsiteConfiguration.RoutingRuleProperty[] | cdktn.IResolvable): void;
    resetRoutingRule(): void;
    get routingRuleInput(): cdktn.IResolvable | AwsS3BucketWebsiteConfiguration.RoutingRuleProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsS3BucketWebsiteConfigurationErrorDocumentPropertyToTerraform(struct?: AwsS3BucketWebsiteConfiguration.ErrorDocumentPropertyOutputReference | AwsS3BucketWebsiteConfiguration.ErrorDocumentProperty): any;
export declare function awsS3BucketWebsiteConfigurationErrorDocumentPropertyToHclTerraform(struct?: AwsS3BucketWebsiteConfiguration.ErrorDocumentPropertyOutputReference | AwsS3BucketWebsiteConfiguration.ErrorDocumentProperty): any;
export declare function awsS3BucketWebsiteConfigurationIndexDocumentPropertyToTerraform(struct?: AwsS3BucketWebsiteConfiguration.IndexDocumentPropertyOutputReference | AwsS3BucketWebsiteConfiguration.IndexDocumentProperty): any;
export declare function awsS3BucketWebsiteConfigurationIndexDocumentPropertyToHclTerraform(struct?: AwsS3BucketWebsiteConfiguration.IndexDocumentPropertyOutputReference | AwsS3BucketWebsiteConfiguration.IndexDocumentProperty): any;
export declare function awsS3BucketWebsiteConfigurationRedirectAllRequestsToPropertyToTerraform(struct?: AwsS3BucketWebsiteConfiguration.RedirectAllRequestsToPropertyOutputReference | AwsS3BucketWebsiteConfiguration.RedirectAllRequestsToProperty): any;
export declare function awsS3BucketWebsiteConfigurationRedirectAllRequestsToPropertyToHclTerraform(struct?: AwsS3BucketWebsiteConfiguration.RedirectAllRequestsToPropertyOutputReference | AwsS3BucketWebsiteConfiguration.RedirectAllRequestsToProperty): any;
export declare function awsS3BucketWebsiteConfigurationConditionPropertyToTerraform(struct?: AwsS3BucketWebsiteConfiguration.ConditionPropertyOutputReference | AwsS3BucketWebsiteConfiguration.ConditionProperty): any;
export declare function awsS3BucketWebsiteConfigurationConditionPropertyToHclTerraform(struct?: AwsS3BucketWebsiteConfiguration.ConditionPropertyOutputReference | AwsS3BucketWebsiteConfiguration.ConditionProperty): any;
export declare function awsS3BucketWebsiteConfigurationRedirectPropertyToTerraform(struct?: AwsS3BucketWebsiteConfiguration.RedirectPropertyOutputReference | AwsS3BucketWebsiteConfiguration.RedirectProperty): any;
export declare function awsS3BucketWebsiteConfigurationRedirectPropertyToHclTerraform(struct?: AwsS3BucketWebsiteConfiguration.RedirectPropertyOutputReference | AwsS3BucketWebsiteConfiguration.RedirectProperty): any;
export declare function awsS3BucketWebsiteConfigurationRoutingRulePropertyToTerraform(struct?: AwsS3BucketWebsiteConfiguration.RoutingRuleProperty | cdktn.IResolvable): any;
export declare function awsS3BucketWebsiteConfigurationRoutingRulePropertyToHclTerraform(struct?: AwsS3BucketWebsiteConfiguration.RoutingRuleProperty | cdktn.IResolvable): any;
export declare namespace AwsS3BucketWebsiteConfiguration {
    interface ErrorDocumentProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_website_configuration#key AwsS3BucketWebsiteConfiguration#key}
        */
        readonly key: string;
    }
    class ErrorDocumentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorDocumentProperty | undefined;
        set internalValue(value: ErrorDocumentProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
    }
    interface IndexDocumentProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_website_configuration#suffix AwsS3BucketWebsiteConfiguration#suffix}
        */
        readonly suffix: string;
    }
    class IndexDocumentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IndexDocumentProperty | undefined;
        set internalValue(value: IndexDocumentProperty | undefined);
        private _suffix?;
        get suffix(): string;
        set suffix(value: string);
        get suffixInput(): string | undefined;
    }
    interface RedirectAllRequestsToProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_website_configuration#host_name AwsS3BucketWebsiteConfiguration#host_name}
        */
        readonly hostName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_website_configuration#protocol AwsS3BucketWebsiteConfiguration#protocol}
        */
        readonly protocol?: string;
    }
    class RedirectAllRequestsToPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RedirectAllRequestsToProperty | undefined;
        set internalValue(value: RedirectAllRequestsToProperty | undefined);
        private _hostName?;
        get hostName(): string;
        set hostName(value: string);
        get hostNameInput(): string | undefined;
        private _protocol?;
        get protocol(): string;
        set protocol(value: string);
        resetProtocol(): void;
        get protocolInput(): string | undefined;
    }
    interface ConditionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_website_configuration#http_error_code_returned_equals AwsS3BucketWebsiteConfiguration#http_error_code_returned_equals}
        */
        readonly httpErrorCodeReturnedEquals?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_website_configuration#key_prefix_equals AwsS3BucketWebsiteConfiguration#key_prefix_equals}
        */
        readonly keyPrefixEquals?: string;
    }
    class ConditionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConditionProperty | undefined;
        set internalValue(value: ConditionProperty | undefined);
        private _httpErrorCodeReturnedEquals?;
        get httpErrorCodeReturnedEquals(): string;
        set httpErrorCodeReturnedEquals(value: string);
        resetHttpErrorCodeReturnedEquals(): void;
        get httpErrorCodeReturnedEqualsInput(): string | undefined;
        private _keyPrefixEquals?;
        get keyPrefixEquals(): string;
        set keyPrefixEquals(value: string);
        resetKeyPrefixEquals(): void;
        get keyPrefixEqualsInput(): string | undefined;
    }
    interface RedirectProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_website_configuration#host_name AwsS3BucketWebsiteConfiguration#host_name}
        */
        readonly hostName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_website_configuration#http_redirect_code AwsS3BucketWebsiteConfiguration#http_redirect_code}
        */
        readonly httpRedirectCode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_website_configuration#protocol AwsS3BucketWebsiteConfiguration#protocol}
        */
        readonly protocol?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_website_configuration#replace_key_prefix_with AwsS3BucketWebsiteConfiguration#replace_key_prefix_with}
        */
        readonly replaceKeyPrefixWith?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_website_configuration#replace_key_with AwsS3BucketWebsiteConfiguration#replace_key_with}
        */
        readonly replaceKeyWith?: string;
    }
    class RedirectPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RedirectProperty | undefined;
        set internalValue(value: RedirectProperty | undefined);
        private _hostName?;
        get hostName(): string;
        set hostName(value: string);
        resetHostName(): void;
        get hostNameInput(): string | undefined;
        private _httpRedirectCode?;
        get httpRedirectCode(): string;
        set httpRedirectCode(value: string);
        resetHttpRedirectCode(): void;
        get httpRedirectCodeInput(): string | undefined;
        private _protocol?;
        get protocol(): string;
        set protocol(value: string);
        resetProtocol(): void;
        get protocolInput(): string | undefined;
        private _replaceKeyPrefixWith?;
        get replaceKeyPrefixWith(): string;
        set replaceKeyPrefixWith(value: string);
        resetReplaceKeyPrefixWith(): void;
        get replaceKeyPrefixWithInput(): string | undefined;
        private _replaceKeyWith?;
        get replaceKeyWith(): string;
        set replaceKeyWith(value: string);
        resetReplaceKeyWith(): void;
        get replaceKeyWithInput(): string | undefined;
    }
    interface RoutingRuleProperty {
        /**
        * condition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_website_configuration#condition AwsS3BucketWebsiteConfiguration#condition}
        */
        readonly condition?: ConditionProperty;
        /**
        * redirect block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_website_configuration#redirect AwsS3BucketWebsiteConfiguration#redirect}
        */
        readonly redirect: RedirectProperty;
    }
    class RoutingRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RoutingRuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RoutingRuleProperty | cdktn.IResolvable | undefined);
        private _condition;
        get condition(): ConditionPropertyOutputReference;
        putCondition(value: ConditionProperty): void;
        resetCondition(): void;
        get conditionInput(): ConditionProperty | undefined;
        private _redirect;
        get redirect(): RedirectPropertyOutputReference;
        putRedirect(value: RedirectProperty): void;
        get redirectInput(): RedirectProperty | undefined;
    }
    class RoutingRulePropertyList extends cdktn.ComplexList {
        internalValue?: RoutingRuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RoutingRulePropertyOutputReference;
    }
}
