import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsS3BucketCorsConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_cors_configuration#bucket AwsS3BucketCorsConfiguration#bucket}
    */
    readonly bucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_cors_configuration#expected_bucket_owner AwsS3BucketCorsConfiguration#expected_bucket_owner}
    */
    readonly expectedBucketOwner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_cors_configuration#id AwsS3BucketCorsConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_cors_configuration#region AwsS3BucketCorsConfiguration#region}
    */
    readonly region?: string;
    /**
    * cors_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_cors_configuration#cors_rule AwsS3BucketCorsConfiguration#cors_rule}
    */
    readonly corsRule: AwsS3BucketCorsConfiguration.CorsRuleProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_cors_configuration aws_s3_bucket_cors_configuration}
*/
export declare class AwsS3BucketCorsConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3_bucket_cors_configuration";
    /**
    * Generates CDKTN code for importing a AwsS3BucketCorsConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsS3BucketCorsConfiguration to import
    * @param importFromId The id of the existing AwsS3BucketCorsConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_cors_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsS3BucketCorsConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_cors_configuration aws_s3_bucket_cors_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsS3BucketCorsConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsS3BucketCorsConfigurationConfig);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _expectedBucketOwner?;
    get expectedBucketOwner(): string;
    set expectedBucketOwner(value: string);
    resetExpectedBucketOwner(): void;
    get expectedBucketOwnerInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _corsRule;
    get corsRule(): AwsS3BucketCorsConfiguration.CorsRulePropertyList;
    putCorsRule(value: AwsS3BucketCorsConfiguration.CorsRuleProperty[] | cdktn.IResolvable): void;
    get corsRuleInput(): cdktn.IResolvable | AwsS3BucketCorsConfiguration.CorsRuleProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsS3BucketCorsConfigurationCorsRulePropertyToTerraform(struct?: AwsS3BucketCorsConfiguration.CorsRuleProperty | cdktn.IResolvable): any;
export declare function awsS3BucketCorsConfigurationCorsRulePropertyToHclTerraform(struct?: AwsS3BucketCorsConfiguration.CorsRuleProperty | cdktn.IResolvable): any;
export declare namespace AwsS3BucketCorsConfiguration {
    interface CorsRuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_cors_configuration#allowed_headers AwsS3BucketCorsConfiguration#allowed_headers}
        */
        readonly allowedHeaders?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_cors_configuration#allowed_methods AwsS3BucketCorsConfiguration#allowed_methods}
        */
        readonly allowedMethods: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_cors_configuration#allowed_origins AwsS3BucketCorsConfiguration#allowed_origins}
        */
        readonly allowedOrigins: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_cors_configuration#expose_headers AwsS3BucketCorsConfiguration#expose_headers}
        */
        readonly exposeHeaders?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_cors_configuration#id AwsS3BucketCorsConfiguration#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_cors_configuration#max_age_seconds AwsS3BucketCorsConfiguration#max_age_seconds}
        */
        readonly maxAgeSeconds?: number;
    }
    class CorsRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CorsRuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CorsRuleProperty | cdktn.IResolvable | undefined);
        private _allowedHeaders?;
        get allowedHeaders(): string[];
        set allowedHeaders(value: string[]);
        resetAllowedHeaders(): void;
        get allowedHeadersInput(): string[] | undefined;
        private _allowedMethods?;
        get allowedMethods(): string[];
        set allowedMethods(value: string[]);
        get allowedMethodsInput(): string[] | undefined;
        private _allowedOrigins?;
        get allowedOrigins(): string[];
        set allowedOrigins(value: string[]);
        get allowedOriginsInput(): string[] | undefined;
        private _exposeHeaders?;
        get exposeHeaders(): string[];
        set exposeHeaders(value: string[]);
        resetExposeHeaders(): void;
        get exposeHeadersInput(): string[] | undefined;
        private _id?;
        get id(): string;
        set id(value: string);
        resetId(): void;
        get idInput(): string | undefined;
        private _maxAgeSeconds?;
        get maxAgeSeconds(): number;
        set maxAgeSeconds(value: number);
        resetMaxAgeSeconds(): void;
        get maxAgeSecondsInput(): number | undefined;
    }
    class CorsRulePropertyList extends cdktn.ComplexList {
        internalValue?: CorsRuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CorsRulePropertyOutputReference;
    }
}
