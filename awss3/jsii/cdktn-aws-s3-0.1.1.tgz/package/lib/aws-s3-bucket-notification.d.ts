import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsS3BucketNotificationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_notification#bucket AwsS3BucketNotification#bucket}
    */
    readonly bucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_notification#eventbridge AwsS3BucketNotification#eventbridge}
    */
    readonly eventbridge?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_notification#id AwsS3BucketNotification#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_notification#region AwsS3BucketNotification#region}
    */
    readonly region?: string;
    /**
    * lambda_function block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_notification#lambda_function AwsS3BucketNotification#lambda_function}
    */
    readonly lambdaFunction?: AwsS3BucketNotification.LambdaFunctionProperty[] | cdktn.IResolvable;
    /**
    * queue block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_notification#queue AwsS3BucketNotification#queue}
    */
    readonly queue?: AwsS3BucketNotification.QueueProperty[] | cdktn.IResolvable;
    /**
    * topic block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_notification#topic AwsS3BucketNotification#topic}
    */
    readonly topic?: AwsS3BucketNotification.TopicProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_notification aws_s3_bucket_notification}
*/
export declare class AwsS3BucketNotification extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3_bucket_notification";
    /**
    * Generates CDKTN code for importing a AwsS3BucketNotification resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsS3BucketNotification to import
    * @param importFromId The id of the existing AwsS3BucketNotification that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_notification#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsS3BucketNotification to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_notification aws_s3_bucket_notification} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsS3BucketNotificationConfig
    */
    constructor(scope: Construct, id: string, config: AwsS3BucketNotificationConfig);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _eventbridge?;
    get eventbridge(): boolean | cdktn.IResolvable;
    set eventbridge(value: boolean | cdktn.IResolvable);
    resetEventbridge(): void;
    get eventbridgeInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _lambdaFunction;
    get lambdaFunction(): AwsS3BucketNotification.LambdaFunctionPropertyList;
    putLambdaFunction(value: AwsS3BucketNotification.LambdaFunctionProperty[] | cdktn.IResolvable): void;
    resetLambdaFunction(): void;
    get lambdaFunctionInput(): cdktn.IResolvable | AwsS3BucketNotification.LambdaFunctionProperty[] | undefined;
    private _queue;
    get queue(): AwsS3BucketNotification.QueuePropertyList;
    putQueue(value: AwsS3BucketNotification.QueueProperty[] | cdktn.IResolvable): void;
    resetQueue(): void;
    get queueInput(): cdktn.IResolvable | AwsS3BucketNotification.QueueProperty[] | undefined;
    private _topic;
    get topic(): AwsS3BucketNotification.TopicPropertyList;
    putTopic(value: AwsS3BucketNotification.TopicProperty[] | cdktn.IResolvable): void;
    resetTopic(): void;
    get topicInput(): cdktn.IResolvable | AwsS3BucketNotification.TopicProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsS3BucketNotificationLambdaFunctionPropertyToTerraform(struct?: AwsS3BucketNotification.LambdaFunctionProperty | cdktn.IResolvable): any;
export declare function awsS3BucketNotificationLambdaFunctionPropertyToHclTerraform(struct?: AwsS3BucketNotification.LambdaFunctionProperty | cdktn.IResolvable): any;
export declare function awsS3BucketNotificationQueuePropertyToTerraform(struct?: AwsS3BucketNotification.QueueProperty | cdktn.IResolvable): any;
export declare function awsS3BucketNotificationQueuePropertyToHclTerraform(struct?: AwsS3BucketNotification.QueueProperty | cdktn.IResolvable): any;
export declare function awsS3BucketNotificationTopicPropertyToTerraform(struct?: AwsS3BucketNotification.TopicProperty | cdktn.IResolvable): any;
export declare function awsS3BucketNotificationTopicPropertyToHclTerraform(struct?: AwsS3BucketNotification.TopicProperty | cdktn.IResolvable): any;
export declare namespace AwsS3BucketNotification {
    interface LambdaFunctionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_notification#events AwsS3BucketNotification#events}
        */
        readonly events: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_notification#filter_prefix AwsS3BucketNotification#filter_prefix}
        */
        readonly filterPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_notification#filter_suffix AwsS3BucketNotification#filter_suffix}
        */
        readonly filterSuffix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_notification#id AwsS3BucketNotification#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_notification#lambda_function_arn AwsS3BucketNotification#lambda_function_arn}
        */
        readonly lambdaFunctionArn?: string;
    }
    class LambdaFunctionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LambdaFunctionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LambdaFunctionProperty | cdktn.IResolvable | undefined);
        private _events?;
        get events(): string[];
        set events(value: string[]);
        get eventsInput(): string[] | undefined;
        private _filterPrefix?;
        get filterPrefix(): string;
        set filterPrefix(value: string);
        resetFilterPrefix(): void;
        get filterPrefixInput(): string | undefined;
        private _filterSuffix?;
        get filterSuffix(): string;
        set filterSuffix(value: string);
        resetFilterSuffix(): void;
        get filterSuffixInput(): string | undefined;
        private _id?;
        get id(): string;
        set id(value: string);
        resetId(): void;
        get idInput(): string | undefined;
        private _lambdaFunctionArn?;
        get lambdaFunctionArn(): string;
        set lambdaFunctionArn(value: string);
        resetLambdaFunctionArn(): void;
        get lambdaFunctionArnInput(): string | undefined;
    }
    class LambdaFunctionPropertyList extends cdktn.ComplexList {
        internalValue?: LambdaFunctionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LambdaFunctionPropertyOutputReference;
    }
    interface QueueProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_notification#events AwsS3BucketNotification#events}
        */
        readonly events: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_notification#filter_prefix AwsS3BucketNotification#filter_prefix}
        */
        readonly filterPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_notification#filter_suffix AwsS3BucketNotification#filter_suffix}
        */
        readonly filterSuffix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_notification#id AwsS3BucketNotification#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_notification#queue_arn AwsS3BucketNotification#queue_arn}
        */
        readonly queueArn: string;
    }
    class QueuePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): QueueProperty | cdktn.IResolvable | undefined;
        set internalValue(value: QueueProperty | cdktn.IResolvable | undefined);
        private _events?;
        get events(): string[];
        set events(value: string[]);
        get eventsInput(): string[] | undefined;
        private _filterPrefix?;
        get filterPrefix(): string;
        set filterPrefix(value: string);
        resetFilterPrefix(): void;
        get filterPrefixInput(): string | undefined;
        private _filterSuffix?;
        get filterSuffix(): string;
        set filterSuffix(value: string);
        resetFilterSuffix(): void;
        get filterSuffixInput(): string | undefined;
        private _id?;
        get id(): string;
        set id(value: string);
        resetId(): void;
        get idInput(): string | undefined;
        private _queueArn?;
        get queueArn(): string;
        set queueArn(value: string);
        get queueArnInput(): string | undefined;
    }
    class QueuePropertyList extends cdktn.ComplexList {
        internalValue?: QueueProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): QueuePropertyOutputReference;
    }
    interface TopicProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_notification#events AwsS3BucketNotification#events}
        */
        readonly events: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_notification#filter_prefix AwsS3BucketNotification#filter_prefix}
        */
        readonly filterPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_notification#filter_suffix AwsS3BucketNotification#filter_suffix}
        */
        readonly filterSuffix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_notification#id AwsS3BucketNotification#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_notification#topic_arn AwsS3BucketNotification#topic_arn}
        */
        readonly topicArn: string;
    }
    class TopicPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TopicProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TopicProperty | cdktn.IResolvable | undefined);
        private _events?;
        get events(): string[];
        set events(value: string[]);
        get eventsInput(): string[] | undefined;
        private _filterPrefix?;
        get filterPrefix(): string;
        set filterPrefix(value: string);
        resetFilterPrefix(): void;
        get filterPrefixInput(): string | undefined;
        private _filterSuffix?;
        get filterSuffix(): string;
        set filterSuffix(value: string);
        resetFilterSuffix(): void;
        get filterSuffixInput(): string | undefined;
        private _id?;
        get id(): string;
        set id(value: string);
        resetId(): void;
        get idInput(): string | undefined;
        private _topicArn?;
        get topicArn(): string;
        set topicArn(value: string);
        get topicArnInput(): string | undefined;
    }
    class TopicPropertyList extends cdktn.ComplexList {
        internalValue?: TopicProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TopicPropertyOutputReference;
    }
}
