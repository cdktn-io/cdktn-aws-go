import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsS3BucketOwnershipControlsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_ownership_controls#bucket AwsS3BucketOwnershipControls#bucket}
    */
    readonly bucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_ownership_controls#id AwsS3BucketOwnershipControls#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_ownership_controls#region AwsS3BucketOwnershipControls#region}
    */
    readonly region?: string;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_ownership_controls#rule AwsS3BucketOwnershipControls#rule}
    */
    readonly rule: AwsS3BucketOwnershipControls.RuleProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_ownership_controls aws_s3_bucket_ownership_controls}
*/
export declare class AwsS3BucketOwnershipControls extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3_bucket_ownership_controls";
    /**
    * Generates CDKTN code for importing a AwsS3BucketOwnershipControls resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsS3BucketOwnershipControls to import
    * @param importFromId The id of the existing AwsS3BucketOwnershipControls that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_ownership_controls#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsS3BucketOwnershipControls to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_ownership_controls aws_s3_bucket_ownership_controls} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsS3BucketOwnershipControlsConfig
    */
    constructor(scope: Construct, id: string, config: AwsS3BucketOwnershipControlsConfig);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _rule;
    get rule(): AwsS3BucketOwnershipControls.RulePropertyOutputReference;
    putRule(value: AwsS3BucketOwnershipControls.RuleProperty): void;
    get ruleInput(): AwsS3BucketOwnershipControls.RuleProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsS3BucketOwnershipControlsRulePropertyToTerraform(struct?: AwsS3BucketOwnershipControls.RulePropertyOutputReference | AwsS3BucketOwnershipControls.RuleProperty): any;
export declare function awsS3BucketOwnershipControlsRulePropertyToHclTerraform(struct?: AwsS3BucketOwnershipControls.RulePropertyOutputReference | AwsS3BucketOwnershipControls.RuleProperty): any;
export declare namespace AwsS3BucketOwnershipControls {
    interface RuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_ownership_controls#object_ownership AwsS3BucketOwnershipControls#object_ownership}
        */
        readonly objectOwnership: string;
    }
    class RulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleProperty | undefined;
        set internalValue(value: RuleProperty | undefined);
        private _objectOwnership?;
        get objectOwnership(): string;
        set objectOwnership(value: string);
        get objectOwnershipInput(): string | undefined;
    }
}
