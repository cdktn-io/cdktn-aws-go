import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsS3BucketConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#acceleration_status AwsS3Bucket#acceleration_status}
    */
    readonly accelerationStatus?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#acl AwsS3Bucket#acl}
    */
    readonly acl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#bucket AwsS3Bucket#bucket}
    */
    readonly bucket?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#bucket_namespace AwsS3Bucket#bucket_namespace}
    */
    readonly bucketNamespace?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#bucket_prefix AwsS3Bucket#bucket_prefix}
    */
    readonly bucketPrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#force_destroy AwsS3Bucket#force_destroy}
    */
    readonly forceDestroy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#id AwsS3Bucket#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#object_lock_enabled AwsS3Bucket#object_lock_enabled}
    */
    readonly objectLockEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#policy AwsS3Bucket#policy}
    */
    readonly policy?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#region AwsS3Bucket#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#request_payer AwsS3Bucket#request_payer}
    */
    readonly requestPayer?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#tags AwsS3Bucket#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#tags_all AwsS3Bucket#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * cors_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#cors_rule AwsS3Bucket#cors_rule}
    */
    readonly corsRule?: AwsS3Bucket.CorsRuleProperty[] | cdktn.IResolvable;
    /**
    * grant block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#grant AwsS3Bucket#grant}
    */
    readonly grant?: AwsS3Bucket.GrantProperty[] | cdktn.IResolvable;
    /**
    * lifecycle_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#lifecycle_rule AwsS3Bucket#lifecycle_rule}
    */
    readonly lifecycleRule?: AwsS3Bucket.LifecycleRuleProperty[] | cdktn.IResolvable;
    /**
    * logging block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#logging AwsS3Bucket#logging}
    */
    readonly logging?: AwsS3Bucket.LoggingProperty;
    /**
    * object_lock_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#object_lock_configuration AwsS3Bucket#object_lock_configuration}
    */
    readonly objectLockConfiguration?: AwsS3Bucket.ObjectLockConfigurationProperty;
    /**
    * replication_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#replication_configuration AwsS3Bucket#replication_configuration}
    */
    readonly replicationConfiguration?: AwsS3Bucket.ReplicationConfigurationProperty;
    /**
    * server_side_encryption_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#server_side_encryption_configuration AwsS3Bucket#server_side_encryption_configuration}
    */
    readonly serverSideEncryptionConfiguration?: AwsS3Bucket.ServerSideEncryptionConfigurationProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#timeouts AwsS3Bucket#timeouts}
    */
    readonly timeouts?: AwsS3Bucket.TimeoutsProperty;
    /**
    * versioning block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#versioning AwsS3Bucket#versioning}
    */
    readonly versioning?: AwsS3Bucket.VersioningProperty;
    /**
    * website block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#website AwsS3Bucket#website}
    */
    readonly website?: AwsS3Bucket.WebsiteProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket aws_s3_bucket}
*/
export declare class AwsS3Bucket extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3_bucket";
    /**
    * Generates CDKTN code for importing a AwsS3Bucket resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsS3Bucket to import
    * @param importFromId The id of the existing AwsS3Bucket that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsS3Bucket to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket aws_s3_bucket} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsS3BucketConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsS3BucketConfig);
    private _accelerationStatus?;
    get accelerationStatus(): string;
    set accelerationStatus(value: string);
    resetAccelerationStatus(): void;
    get accelerationStatusInput(): string | undefined;
    private _acl?;
    get acl(): string;
    set acl(value: string);
    resetAcl(): void;
    get aclInput(): string | undefined;
    get arn(): string;
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    resetBucket(): void;
    get bucketInput(): string | undefined;
    get bucketDomainName(): string;
    private _bucketNamespace?;
    get bucketNamespace(): string;
    set bucketNamespace(value: string);
    resetBucketNamespace(): void;
    get bucketNamespaceInput(): string | undefined;
    private _bucketPrefix?;
    get bucketPrefix(): string;
    set bucketPrefix(value: string);
    resetBucketPrefix(): void;
    get bucketPrefixInput(): string | undefined;
    get bucketRegion(): string;
    get bucketRegionalDomainName(): string;
    private _forceDestroy?;
    get forceDestroy(): boolean | cdktn.IResolvable;
    set forceDestroy(value: boolean | cdktn.IResolvable);
    resetForceDestroy(): void;
    get forceDestroyInput(): boolean | cdktn.IResolvable | undefined;
    get hostedZoneId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _objectLockEnabled?;
    get objectLockEnabled(): boolean | cdktn.IResolvable;
    set objectLockEnabled(value: boolean | cdktn.IResolvable);
    resetObjectLockEnabled(): void;
    get objectLockEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _policy?;
    get policy(): string;
    set policy(value: string);
    resetPolicy(): void;
    get policyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _requestPayer?;
    get requestPayer(): string;
    set requestPayer(value: string);
    resetRequestPayer(): void;
    get requestPayerInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get websiteDomain(): string;
    get websiteEndpoint(): string;
    private _corsRule;
    get corsRule(): AwsS3Bucket.CorsRulePropertyList;
    putCorsRule(value: AwsS3Bucket.CorsRuleProperty[] | cdktn.IResolvable): void;
    resetCorsRule(): void;
    get corsRuleInput(): cdktn.IResolvable | AwsS3Bucket.CorsRuleProperty[] | undefined;
    private _grant;
    get grant(): AwsS3Bucket.GrantPropertyList;
    putGrant(value: AwsS3Bucket.GrantProperty[] | cdktn.IResolvable): void;
    resetGrant(): void;
    get grantInput(): cdktn.IResolvable | AwsS3Bucket.GrantProperty[] | undefined;
    private _lifecycleRule;
    get lifecycleRule(): AwsS3Bucket.LifecycleRulePropertyList;
    putLifecycleRule(value: AwsS3Bucket.LifecycleRuleProperty[] | cdktn.IResolvable): void;
    resetLifecycleRule(): void;
    get lifecycleRuleInput(): cdktn.IResolvable | AwsS3Bucket.LifecycleRuleProperty[] | undefined;
    private _logging;
    get logging(): AwsS3Bucket.LoggingPropertyOutputReference;
    putLogging(value: AwsS3Bucket.LoggingProperty): void;
    resetLogging(): void;
    get loggingInput(): AwsS3Bucket.LoggingProperty | undefined;
    private _objectLockConfiguration;
    get objectLockConfiguration(): AwsS3Bucket.ObjectLockConfigurationPropertyOutputReference;
    putObjectLockConfiguration(value: AwsS3Bucket.ObjectLockConfigurationProperty): void;
    resetObjectLockConfiguration(): void;
    get objectLockConfigurationInput(): AwsS3Bucket.ObjectLockConfigurationProperty | undefined;
    private _replicationConfiguration;
    get replicationConfiguration(): AwsS3Bucket.ReplicationConfigurationPropertyOutputReference;
    putReplicationConfiguration(value: AwsS3Bucket.ReplicationConfigurationProperty): void;
    resetReplicationConfiguration(): void;
    get replicationConfigurationInput(): AwsS3Bucket.ReplicationConfigurationProperty | undefined;
    private _serverSideEncryptionConfiguration;
    get serverSideEncryptionConfiguration(): AwsS3Bucket.ServerSideEncryptionConfigurationPropertyOutputReference;
    putServerSideEncryptionConfiguration(value: AwsS3Bucket.ServerSideEncryptionConfigurationProperty): void;
    resetServerSideEncryptionConfiguration(): void;
    get serverSideEncryptionConfigurationInput(): AwsS3Bucket.ServerSideEncryptionConfigurationProperty | undefined;
    private _timeouts;
    get timeouts(): AwsS3Bucket.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsS3Bucket.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsS3Bucket.TimeoutsProperty | undefined;
    private _versioning;
    get versioning(): AwsS3Bucket.VersioningPropertyOutputReference;
    putVersioning(value: AwsS3Bucket.VersioningProperty): void;
    resetVersioning(): void;
    get versioningInput(): AwsS3Bucket.VersioningProperty | undefined;
    private _website;
    get website(): AwsS3Bucket.WebsitePropertyOutputReference;
    putWebsite(value: AwsS3Bucket.WebsiteProperty): void;
    resetWebsite(): void;
    get websiteInput(): AwsS3Bucket.WebsiteProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsS3BucketMapperCorsRulePropertyToTerraform(struct?: AwsS3Bucket.CorsRuleProperty | cdktn.IResolvable): any;
export declare function awsS3BucketMapperCorsRulePropertyToHclTerraform(struct?: AwsS3Bucket.CorsRuleProperty | cdktn.IResolvable): any;
export declare function awsS3BucketMapperGrantPropertyToTerraform(struct?: AwsS3Bucket.GrantProperty | cdktn.IResolvable): any;
export declare function awsS3BucketMapperGrantPropertyToHclTerraform(struct?: AwsS3Bucket.GrantProperty | cdktn.IResolvable): any;
export declare function awsS3BucketMapperExpirationPropertyToTerraform(struct?: AwsS3Bucket.ExpirationPropertyOutputReference | AwsS3Bucket.ExpirationProperty): any;
export declare function awsS3BucketMapperExpirationPropertyToHclTerraform(struct?: AwsS3Bucket.ExpirationPropertyOutputReference | AwsS3Bucket.ExpirationProperty): any;
export declare function awsS3BucketMapperNoncurrentVersionExpirationPropertyToTerraform(struct?: AwsS3Bucket.NoncurrentVersionExpirationPropertyOutputReference | AwsS3Bucket.NoncurrentVersionExpirationProperty): any;
export declare function awsS3BucketMapperNoncurrentVersionExpirationPropertyToHclTerraform(struct?: AwsS3Bucket.NoncurrentVersionExpirationPropertyOutputReference | AwsS3Bucket.NoncurrentVersionExpirationProperty): any;
export declare function awsS3BucketMapperNoncurrentVersionTransitionPropertyToTerraform(struct?: AwsS3Bucket.NoncurrentVersionTransitionProperty | cdktn.IResolvable): any;
export declare function awsS3BucketMapperNoncurrentVersionTransitionPropertyToHclTerraform(struct?: AwsS3Bucket.NoncurrentVersionTransitionProperty | cdktn.IResolvable): any;
export declare function awsS3BucketMapperTransitionPropertyToTerraform(struct?: AwsS3Bucket.TransitionProperty | cdktn.IResolvable): any;
export declare function awsS3BucketMapperTransitionPropertyToHclTerraform(struct?: AwsS3Bucket.TransitionProperty | cdktn.IResolvable): any;
export declare function awsS3BucketMapperLifecycleRulePropertyToTerraform(struct?: AwsS3Bucket.LifecycleRuleProperty | cdktn.IResolvable): any;
export declare function awsS3BucketMapperLifecycleRulePropertyToHclTerraform(struct?: AwsS3Bucket.LifecycleRuleProperty | cdktn.IResolvable): any;
export declare function awsS3BucketMapperLoggingPropertyToTerraform(struct?: AwsS3Bucket.LoggingPropertyOutputReference | AwsS3Bucket.LoggingProperty): any;
export declare function awsS3BucketMapperLoggingPropertyToHclTerraform(struct?: AwsS3Bucket.LoggingPropertyOutputReference | AwsS3Bucket.LoggingProperty): any;
export declare function awsS3BucketMapperDefaultRetentionPropertyToTerraform(struct?: AwsS3Bucket.DefaultRetentionPropertyOutputReference | AwsS3Bucket.DefaultRetentionProperty): any;
export declare function awsS3BucketMapperDefaultRetentionPropertyToHclTerraform(struct?: AwsS3Bucket.DefaultRetentionPropertyOutputReference | AwsS3Bucket.DefaultRetentionProperty): any;
export declare function awsS3BucketMapperObjectLockConfigurationRulePropertyToTerraform(struct?: AwsS3Bucket.ObjectLockConfigurationRulePropertyOutputReference | AwsS3Bucket.ObjectLockConfigurationRuleProperty): any;
export declare function awsS3BucketMapperObjectLockConfigurationRulePropertyToHclTerraform(struct?: AwsS3Bucket.ObjectLockConfigurationRulePropertyOutputReference | AwsS3Bucket.ObjectLockConfigurationRuleProperty): any;
export declare function awsS3BucketMapperObjectLockConfigurationPropertyToTerraform(struct?: AwsS3Bucket.ObjectLockConfigurationPropertyOutputReference | AwsS3Bucket.ObjectLockConfigurationProperty): any;
export declare function awsS3BucketMapperObjectLockConfigurationPropertyToHclTerraform(struct?: AwsS3Bucket.ObjectLockConfigurationPropertyOutputReference | AwsS3Bucket.ObjectLockConfigurationProperty): any;
export declare function awsS3BucketMapperAccessControlTranslationPropertyToTerraform(struct?: AwsS3Bucket.AccessControlTranslationPropertyOutputReference | AwsS3Bucket.AccessControlTranslationProperty): any;
export declare function awsS3BucketMapperAccessControlTranslationPropertyToHclTerraform(struct?: AwsS3Bucket.AccessControlTranslationPropertyOutputReference | AwsS3Bucket.AccessControlTranslationProperty): any;
export declare function awsS3BucketMapperMetricsPropertyToTerraform(struct?: AwsS3Bucket.MetricsPropertyOutputReference | AwsS3Bucket.MetricsProperty): any;
export declare function awsS3BucketMapperMetricsPropertyToHclTerraform(struct?: AwsS3Bucket.MetricsPropertyOutputReference | AwsS3Bucket.MetricsProperty): any;
export declare function awsS3BucketMapperReplicationTimePropertyToTerraform(struct?: AwsS3Bucket.ReplicationTimePropertyOutputReference | AwsS3Bucket.ReplicationTimeProperty): any;
export declare function awsS3BucketMapperReplicationTimePropertyToHclTerraform(struct?: AwsS3Bucket.ReplicationTimePropertyOutputReference | AwsS3Bucket.ReplicationTimeProperty): any;
export declare function awsS3BucketMapperDestinationPropertyToTerraform(struct?: AwsS3Bucket.DestinationPropertyOutputReference | AwsS3Bucket.DestinationProperty): any;
export declare function awsS3BucketMapperDestinationPropertyToHclTerraform(struct?: AwsS3Bucket.DestinationPropertyOutputReference | AwsS3Bucket.DestinationProperty): any;
export declare function awsS3BucketMapperFilterPropertyToTerraform(struct?: AwsS3Bucket.FilterPropertyOutputReference | AwsS3Bucket.FilterProperty): any;
export declare function awsS3BucketMapperFilterPropertyToHclTerraform(struct?: AwsS3Bucket.FilterPropertyOutputReference | AwsS3Bucket.FilterProperty): any;
export declare function awsS3BucketMapperSseKmsEncryptedObjectsPropertyToTerraform(struct?: AwsS3Bucket.SseKmsEncryptedObjectsPropertyOutputReference | AwsS3Bucket.SseKmsEncryptedObjectsProperty): any;
export declare function awsS3BucketMapperSseKmsEncryptedObjectsPropertyToHclTerraform(struct?: AwsS3Bucket.SseKmsEncryptedObjectsPropertyOutputReference | AwsS3Bucket.SseKmsEncryptedObjectsProperty): any;
export declare function awsS3BucketMapperSourceSelectionCriteriaPropertyToTerraform(struct?: AwsS3Bucket.SourceSelectionCriteriaPropertyOutputReference | AwsS3Bucket.SourceSelectionCriteriaProperty): any;
export declare function awsS3BucketMapperSourceSelectionCriteriaPropertyToHclTerraform(struct?: AwsS3Bucket.SourceSelectionCriteriaPropertyOutputReference | AwsS3Bucket.SourceSelectionCriteriaProperty): any;
export declare function awsS3BucketMapperRulesPropertyToTerraform(struct?: AwsS3Bucket.RulesProperty | cdktn.IResolvable): any;
export declare function awsS3BucketMapperRulesPropertyToHclTerraform(struct?: AwsS3Bucket.RulesProperty | cdktn.IResolvable): any;
export declare function awsS3BucketMapperReplicationConfigurationPropertyToTerraform(struct?: AwsS3Bucket.ReplicationConfigurationPropertyOutputReference | AwsS3Bucket.ReplicationConfigurationProperty): any;
export declare function awsS3BucketMapperReplicationConfigurationPropertyToHclTerraform(struct?: AwsS3Bucket.ReplicationConfigurationPropertyOutputReference | AwsS3Bucket.ReplicationConfigurationProperty): any;
export declare function awsS3BucketMapperApplyServerSideEncryptionByDefaultPropertyToTerraform(struct?: AwsS3Bucket.ApplyServerSideEncryptionByDefaultPropertyOutputReference | AwsS3Bucket.ApplyServerSideEncryptionByDefaultProperty): any;
export declare function awsS3BucketMapperApplyServerSideEncryptionByDefaultPropertyToHclTerraform(struct?: AwsS3Bucket.ApplyServerSideEncryptionByDefaultPropertyOutputReference | AwsS3Bucket.ApplyServerSideEncryptionByDefaultProperty): any;
export declare function awsS3BucketMapperServerSideEncryptionConfigurationRulePropertyToTerraform(struct?: AwsS3Bucket.ServerSideEncryptionConfigurationRulePropertyOutputReference | AwsS3Bucket.ServerSideEncryptionConfigurationRuleProperty): any;
export declare function awsS3BucketMapperServerSideEncryptionConfigurationRulePropertyToHclTerraform(struct?: AwsS3Bucket.ServerSideEncryptionConfigurationRulePropertyOutputReference | AwsS3Bucket.ServerSideEncryptionConfigurationRuleProperty): any;
export declare function awsS3BucketMapperServerSideEncryptionConfigurationPropertyToTerraform(struct?: AwsS3Bucket.ServerSideEncryptionConfigurationPropertyOutputReference | AwsS3Bucket.ServerSideEncryptionConfigurationProperty): any;
export declare function awsS3BucketMapperServerSideEncryptionConfigurationPropertyToHclTerraform(struct?: AwsS3Bucket.ServerSideEncryptionConfigurationPropertyOutputReference | AwsS3Bucket.ServerSideEncryptionConfigurationProperty): any;
export declare function awsS3BucketMapperTimeoutsPropertyToTerraform(struct?: AwsS3Bucket.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsS3BucketMapperTimeoutsPropertyToHclTerraform(struct?: AwsS3Bucket.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsS3BucketMapperVersioningPropertyToTerraform(struct?: AwsS3Bucket.VersioningPropertyOutputReference | AwsS3Bucket.VersioningProperty): any;
export declare function awsS3BucketMapperVersioningPropertyToHclTerraform(struct?: AwsS3Bucket.VersioningPropertyOutputReference | AwsS3Bucket.VersioningProperty): any;
export declare function awsS3BucketMapperWebsitePropertyToTerraform(struct?: AwsS3Bucket.WebsitePropertyOutputReference | AwsS3Bucket.WebsiteProperty): any;
export declare function awsS3BucketMapperWebsitePropertyToHclTerraform(struct?: AwsS3Bucket.WebsitePropertyOutputReference | AwsS3Bucket.WebsiteProperty): any;
export declare namespace AwsS3Bucket {
    interface CorsRuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#allowed_headers AwsS3Bucket#allowed_headers}
        */
        readonly allowedHeaders?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#allowed_methods AwsS3Bucket#allowed_methods}
        */
        readonly allowedMethods: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#allowed_origins AwsS3Bucket#allowed_origins}
        */
        readonly allowedOrigins: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#expose_headers AwsS3Bucket#expose_headers}
        */
        readonly exposeHeaders?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#max_age_seconds AwsS3Bucket#max_age_seconds}
        */
        readonly maxAgeSeconds?: number;
    }
    class CorsRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CorsRuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CorsRuleProperty | cdktn.IResolvable | undefined);
        private _allowedHeaders?;
        get allowedHeaders(): string[];
        set allowedHeaders(value: string[]);
        resetAllowedHeaders(): void;
        get allowedHeadersInput(): string[] | undefined;
        private _allowedMethods?;
        get allowedMethods(): string[];
        set allowedMethods(value: string[]);
        get allowedMethodsInput(): string[] | undefined;
        private _allowedOrigins?;
        get allowedOrigins(): string[];
        set allowedOrigins(value: string[]);
        get allowedOriginsInput(): string[] | undefined;
        private _exposeHeaders?;
        get exposeHeaders(): string[];
        set exposeHeaders(value: string[]);
        resetExposeHeaders(): void;
        get exposeHeadersInput(): string[] | undefined;
        private _maxAgeSeconds?;
        get maxAgeSeconds(): number;
        set maxAgeSeconds(value: number);
        resetMaxAgeSeconds(): void;
        get maxAgeSecondsInput(): number | undefined;
    }
    class CorsRulePropertyList extends cdktn.ComplexList {
        internalValue?: CorsRuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CorsRulePropertyOutputReference;
    }
    interface GrantProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#id AwsS3Bucket#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#permissions AwsS3Bucket#permissions}
        */
        readonly permissions: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#type AwsS3Bucket#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#uri AwsS3Bucket#uri}
        */
        readonly uri?: string;
    }
    class GrantPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GrantProperty | cdktn.IResolvable | undefined;
        set internalValue(value: GrantProperty | cdktn.IResolvable | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        resetId(): void;
        get idInput(): string | undefined;
        private _permissions?;
        get permissions(): string[];
        set permissions(value: string[]);
        get permissionsInput(): string[] | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _uri?;
        get uri(): string;
        set uri(value: string);
        resetUri(): void;
        get uriInput(): string | undefined;
    }
    class GrantPropertyList extends cdktn.ComplexList {
        internalValue?: GrantProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GrantPropertyOutputReference;
    }
    interface ExpirationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#date AwsS3Bucket#date}
        */
        readonly date?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#days AwsS3Bucket#days}
        */
        readonly days?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#expired_object_delete_marker AwsS3Bucket#expired_object_delete_marker}
        */
        readonly expiredObjectDeleteMarker?: boolean | cdktn.IResolvable;
    }
    class ExpirationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ExpirationProperty | undefined;
        set internalValue(value: ExpirationProperty | undefined);
        private _date?;
        get date(): string;
        set date(value: string);
        resetDate(): void;
        get dateInput(): string | undefined;
        private _days?;
        get days(): number;
        set days(value: number);
        resetDays(): void;
        get daysInput(): number | undefined;
        private _expiredObjectDeleteMarker?;
        get expiredObjectDeleteMarker(): boolean | cdktn.IResolvable;
        set expiredObjectDeleteMarker(value: boolean | cdktn.IResolvable);
        resetExpiredObjectDeleteMarker(): void;
        get expiredObjectDeleteMarkerInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface NoncurrentVersionExpirationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#days AwsS3Bucket#days}
        */
        readonly days?: number;
    }
    class NoncurrentVersionExpirationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NoncurrentVersionExpirationProperty | undefined;
        set internalValue(value: NoncurrentVersionExpirationProperty | undefined);
        private _days?;
        get days(): number;
        set days(value: number);
        resetDays(): void;
        get daysInput(): number | undefined;
    }
    interface NoncurrentVersionTransitionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#days AwsS3Bucket#days}
        */
        readonly days?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#storage_class AwsS3Bucket#storage_class}
        */
        readonly storageClass: string;
    }
    class NoncurrentVersionTransitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NoncurrentVersionTransitionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NoncurrentVersionTransitionProperty | cdktn.IResolvable | undefined);
        private _days?;
        get days(): number;
        set days(value: number);
        resetDays(): void;
        get daysInput(): number | undefined;
        private _storageClass?;
        get storageClass(): string;
        set storageClass(value: string);
        get storageClassInput(): string | undefined;
    }
    class NoncurrentVersionTransitionPropertyList extends cdktn.ComplexList {
        internalValue?: NoncurrentVersionTransitionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NoncurrentVersionTransitionPropertyOutputReference;
    }
    interface TransitionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#date AwsS3Bucket#date}
        */
        readonly date?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#days AwsS3Bucket#days}
        */
        readonly days?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#storage_class AwsS3Bucket#storage_class}
        */
        readonly storageClass: string;
    }
    class TransitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TransitionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TransitionProperty | cdktn.IResolvable | undefined);
        private _date?;
        get date(): string;
        set date(value: string);
        resetDate(): void;
        get dateInput(): string | undefined;
        private _days?;
        get days(): number;
        set days(value: number);
        resetDays(): void;
        get daysInput(): number | undefined;
        private _storageClass?;
        get storageClass(): string;
        set storageClass(value: string);
        get storageClassInput(): string | undefined;
    }
    class TransitionPropertyList extends cdktn.ComplexList {
        internalValue?: TransitionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TransitionPropertyOutputReference;
    }
    interface LifecycleRuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#abort_incomplete_multipart_upload_days AwsS3Bucket#abort_incomplete_multipart_upload_days}
        */
        readonly abortIncompleteMultipartUploadDays?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#enabled AwsS3Bucket#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#id AwsS3Bucket#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#prefix AwsS3Bucket#prefix}
        */
        readonly prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#tags AwsS3Bucket#tags}
        */
        readonly tags?: {
            [key: string]: string;
        };
        /**
        * expiration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#expiration AwsS3Bucket#expiration}
        */
        readonly expiration?: ExpirationProperty;
        /**
        * noncurrent_version_expiration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#noncurrent_version_expiration AwsS3Bucket#noncurrent_version_expiration}
        */
        readonly noncurrentVersionExpiration?: NoncurrentVersionExpirationProperty;
        /**
        * noncurrent_version_transition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#noncurrent_version_transition AwsS3Bucket#noncurrent_version_transition}
        */
        readonly noncurrentVersionTransition?: NoncurrentVersionTransitionProperty[] | cdktn.IResolvable;
        /**
        * transition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#transition AwsS3Bucket#transition}
        */
        readonly transition?: TransitionProperty[] | cdktn.IResolvable;
    }
    class LifecycleRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LifecycleRuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LifecycleRuleProperty | cdktn.IResolvable | undefined);
        private _abortIncompleteMultipartUploadDays?;
        get abortIncompleteMultipartUploadDays(): number;
        set abortIncompleteMultipartUploadDays(value: number);
        resetAbortIncompleteMultipartUploadDays(): void;
        get abortIncompleteMultipartUploadDaysInput(): number | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _id?;
        get id(): string;
        set id(value: string);
        resetId(): void;
        get idInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _tags?;
        get tags(): {
            [key: string]: string;
        };
        set tags(value: {
            [key: string]: string;
        });
        resetTags(): void;
        get tagsInput(): {
            [key: string]: string;
        } | undefined;
        private _expiration;
        get expiration(): ExpirationPropertyOutputReference;
        putExpiration(value: ExpirationProperty): void;
        resetExpiration(): void;
        get expirationInput(): ExpirationProperty | undefined;
        private _noncurrentVersionExpiration;
        get noncurrentVersionExpiration(): NoncurrentVersionExpirationPropertyOutputReference;
        putNoncurrentVersionExpiration(value: NoncurrentVersionExpirationProperty): void;
        resetNoncurrentVersionExpiration(): void;
        get noncurrentVersionExpirationInput(): NoncurrentVersionExpirationProperty | undefined;
        private _noncurrentVersionTransition;
        get noncurrentVersionTransition(): NoncurrentVersionTransitionPropertyList;
        putNoncurrentVersionTransition(value: NoncurrentVersionTransitionProperty[] | cdktn.IResolvable): void;
        resetNoncurrentVersionTransition(): void;
        get noncurrentVersionTransitionInput(): cdktn.IResolvable | NoncurrentVersionTransitionProperty[] | undefined;
        private _transition;
        get transition(): TransitionPropertyList;
        putTransition(value: TransitionProperty[] | cdktn.IResolvable): void;
        resetTransition(): void;
        get transitionInput(): cdktn.IResolvable | TransitionProperty[] | undefined;
    }
    class LifecycleRulePropertyList extends cdktn.ComplexList {
        internalValue?: LifecycleRuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LifecycleRulePropertyOutputReference;
    }
    interface LoggingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#target_bucket AwsS3Bucket#target_bucket}
        */
        readonly targetBucket: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#target_prefix AwsS3Bucket#target_prefix}
        */
        readonly targetPrefix?: string;
    }
    class LoggingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LoggingProperty | undefined;
        set internalValue(value: LoggingProperty | undefined);
        private _targetBucket?;
        get targetBucket(): string;
        set targetBucket(value: string);
        get targetBucketInput(): string | undefined;
        private _targetPrefix?;
        get targetPrefix(): string;
        set targetPrefix(value: string);
        resetTargetPrefix(): void;
        get targetPrefixInput(): string | undefined;
    }
    interface DefaultRetentionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#days AwsS3Bucket#days}
        */
        readonly days?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#mode AwsS3Bucket#mode}
        */
        readonly mode: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#years AwsS3Bucket#years}
        */
        readonly years?: number;
    }
    class DefaultRetentionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultRetentionProperty | undefined;
        set internalValue(value: DefaultRetentionProperty | undefined);
        private _days?;
        get days(): number;
        set days(value: number);
        resetDays(): void;
        get daysInput(): number | undefined;
        private _mode?;
        get mode(): string;
        set mode(value: string);
        get modeInput(): string | undefined;
        private _years?;
        get years(): number;
        set years(value: number);
        resetYears(): void;
        get yearsInput(): number | undefined;
    }
    interface ObjectLockConfigurationRuleProperty {
        /**
        * default_retention block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#default_retention AwsS3Bucket#default_retention}
        */
        readonly defaultRetention: DefaultRetentionProperty;
    }
    class ObjectLockConfigurationRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ObjectLockConfigurationRuleProperty | undefined;
        set internalValue(value: ObjectLockConfigurationRuleProperty | undefined);
        private _defaultRetention;
        get defaultRetention(): DefaultRetentionPropertyOutputReference;
        putDefaultRetention(value: DefaultRetentionProperty): void;
        get defaultRetentionInput(): DefaultRetentionProperty | undefined;
    }
    interface ObjectLockConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#object_lock_enabled AwsS3Bucket#object_lock_enabled}
        */
        readonly objectLockEnabled?: string;
        /**
        * rule block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#rule AwsS3Bucket#rule}
        */
        readonly rule?: ObjectLockConfigurationRuleProperty;
    }
    class ObjectLockConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ObjectLockConfigurationProperty | undefined;
        set internalValue(value: ObjectLockConfigurationProperty | undefined);
        private _objectLockEnabled?;
        get objectLockEnabled(): string;
        set objectLockEnabled(value: string);
        resetObjectLockEnabled(): void;
        get objectLockEnabledInput(): string | undefined;
        private _rule;
        get rule(): ObjectLockConfigurationRulePropertyOutputReference;
        putRule(value: ObjectLockConfigurationRuleProperty): void;
        resetRule(): void;
        get ruleInput(): ObjectLockConfigurationRuleProperty | undefined;
    }
    interface AccessControlTranslationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#owner AwsS3Bucket#owner}
        */
        readonly owner: string;
    }
    class AccessControlTranslationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AccessControlTranslationProperty | undefined;
        set internalValue(value: AccessControlTranslationProperty | undefined);
        private _owner?;
        get owner(): string;
        set owner(value: string);
        get ownerInput(): string | undefined;
    }
    interface MetricsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#minutes AwsS3Bucket#minutes}
        */
        readonly minutes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#status AwsS3Bucket#status}
        */
        readonly status?: string;
    }
    class MetricsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MetricsProperty | undefined;
        set internalValue(value: MetricsProperty | undefined);
        private _minutes?;
        get minutes(): number;
        set minutes(value: number);
        resetMinutes(): void;
        get minutesInput(): number | undefined;
        private _status?;
        get status(): string;
        set status(value: string);
        resetStatus(): void;
        get statusInput(): string | undefined;
    }
    interface ReplicationTimeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#minutes AwsS3Bucket#minutes}
        */
        readonly minutes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#status AwsS3Bucket#status}
        */
        readonly status?: string;
    }
    class ReplicationTimePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ReplicationTimeProperty | undefined;
        set internalValue(value: ReplicationTimeProperty | undefined);
        private _minutes?;
        get minutes(): number;
        set minutes(value: number);
        resetMinutes(): void;
        get minutesInput(): number | undefined;
        private _status?;
        get status(): string;
        set status(value: string);
        resetStatus(): void;
        get statusInput(): string | undefined;
    }
    interface DestinationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#account_id AwsS3Bucket#account_id}
        */
        readonly accountId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#bucket AwsS3Bucket#bucket}
        */
        readonly bucket: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#replica_kms_key_id AwsS3Bucket#replica_kms_key_id}
        */
        readonly replicaKmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#storage_class AwsS3Bucket#storage_class}
        */
        readonly storageClass?: string;
        /**
        * access_control_translation block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#access_control_translation AwsS3Bucket#access_control_translation}
        */
        readonly accessControlTranslation?: AccessControlTranslationProperty;
        /**
        * metrics block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#metrics AwsS3Bucket#metrics}
        */
        readonly metrics?: MetricsProperty;
        /**
        * replication_time block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#replication_time AwsS3Bucket#replication_time}
        */
        readonly replicationTime?: ReplicationTimeProperty;
    }
    class DestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationProperty | undefined;
        set internalValue(value: DestinationProperty | undefined);
        private _accountId?;
        get accountId(): string;
        set accountId(value: string);
        resetAccountId(): void;
        get accountIdInput(): string | undefined;
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        get bucketInput(): string | undefined;
        private _replicaKmsKeyId?;
        get replicaKmsKeyId(): string;
        set replicaKmsKeyId(value: string);
        resetReplicaKmsKeyId(): void;
        get replicaKmsKeyIdInput(): string | undefined;
        private _storageClass?;
        get storageClass(): string;
        set storageClass(value: string);
        resetStorageClass(): void;
        get storageClassInput(): string | undefined;
        private _accessControlTranslation;
        get accessControlTranslation(): AccessControlTranslationPropertyOutputReference;
        putAccessControlTranslation(value: AccessControlTranslationProperty): void;
        resetAccessControlTranslation(): void;
        get accessControlTranslationInput(): AccessControlTranslationProperty | undefined;
        private _metrics;
        get metrics(): MetricsPropertyOutputReference;
        putMetrics(value: MetricsProperty): void;
        resetMetrics(): void;
        get metricsInput(): MetricsProperty | undefined;
        private _replicationTime;
        get replicationTime(): ReplicationTimePropertyOutputReference;
        putReplicationTime(value: ReplicationTimeProperty): void;
        resetReplicationTime(): void;
        get replicationTimeInput(): ReplicationTimeProperty | undefined;
    }
    interface FilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#prefix AwsS3Bucket#prefix}
        */
        readonly prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#tags AwsS3Bucket#tags}
        */
        readonly tags?: {
            [key: string]: string;
        };
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterProperty | undefined;
        set internalValue(value: FilterProperty | undefined);
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _tags?;
        get tags(): {
            [key: string]: string;
        };
        set tags(value: {
            [key: string]: string;
        });
        resetTags(): void;
        get tagsInput(): {
            [key: string]: string;
        } | undefined;
    }
    interface SseKmsEncryptedObjectsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#enabled AwsS3Bucket#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
    }
    class SseKmsEncryptedObjectsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SseKmsEncryptedObjectsProperty | undefined;
        set internalValue(value: SseKmsEncryptedObjectsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface SourceSelectionCriteriaProperty {
        /**
        * sse_kms_encrypted_objects block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#sse_kms_encrypted_objects AwsS3Bucket#sse_kms_encrypted_objects}
        */
        readonly sseKmsEncryptedObjects?: SseKmsEncryptedObjectsProperty;
    }
    class SourceSelectionCriteriaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceSelectionCriteriaProperty | undefined;
        set internalValue(value: SourceSelectionCriteriaProperty | undefined);
        private _sseKmsEncryptedObjects;
        get sseKmsEncryptedObjects(): SseKmsEncryptedObjectsPropertyOutputReference;
        putSseKmsEncryptedObjects(value: SseKmsEncryptedObjectsProperty): void;
        resetSseKmsEncryptedObjects(): void;
        get sseKmsEncryptedObjectsInput(): SseKmsEncryptedObjectsProperty | undefined;
    }
    interface RulesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#delete_marker_replication_status AwsS3Bucket#delete_marker_replication_status}
        */
        readonly deleteMarkerReplicationStatus?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#id AwsS3Bucket#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#prefix AwsS3Bucket#prefix}
        */
        readonly prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#priority AwsS3Bucket#priority}
        */
        readonly priority?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#status AwsS3Bucket#status}
        */
        readonly status: string;
        /**
        * destination block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#destination AwsS3Bucket#destination}
        */
        readonly destination: DestinationProperty;
        /**
        * filter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#filter AwsS3Bucket#filter}
        */
        readonly filter?: FilterProperty;
        /**
        * source_selection_criteria block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#source_selection_criteria AwsS3Bucket#source_selection_criteria}
        */
        readonly sourceSelectionCriteria?: SourceSelectionCriteriaProperty;
    }
    class RulesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RulesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RulesProperty | cdktn.IResolvable | undefined);
        private _deleteMarkerReplicationStatus?;
        get deleteMarkerReplicationStatus(): string;
        set deleteMarkerReplicationStatus(value: string);
        resetDeleteMarkerReplicationStatus(): void;
        get deleteMarkerReplicationStatusInput(): string | undefined;
        private _id?;
        get id(): string;
        set id(value: string);
        resetId(): void;
        get idInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _priority?;
        get priority(): number;
        set priority(value: number);
        resetPriority(): void;
        get priorityInput(): number | undefined;
        private _status?;
        get status(): string;
        set status(value: string);
        get statusInput(): string | undefined;
        private _destination;
        get destination(): DestinationPropertyOutputReference;
        putDestination(value: DestinationProperty): void;
        get destinationInput(): DestinationProperty | undefined;
        private _filter;
        get filter(): FilterPropertyOutputReference;
        putFilter(value: FilterProperty): void;
        resetFilter(): void;
        get filterInput(): FilterProperty | undefined;
        private _sourceSelectionCriteria;
        get sourceSelectionCriteria(): SourceSelectionCriteriaPropertyOutputReference;
        putSourceSelectionCriteria(value: SourceSelectionCriteriaProperty): void;
        resetSourceSelectionCriteria(): void;
        get sourceSelectionCriteriaInput(): SourceSelectionCriteriaProperty | undefined;
    }
    class RulesPropertyList extends cdktn.ComplexList {
        internalValue?: RulesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulesPropertyOutputReference;
    }
    interface ReplicationConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#role AwsS3Bucket#role}
        */
        readonly role: string;
        /**
        * rules block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#rules AwsS3Bucket#rules}
        */
        readonly rules: RulesProperty[] | cdktn.IResolvable;
    }
    class ReplicationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ReplicationConfigurationProperty | undefined;
        set internalValue(value: ReplicationConfigurationProperty | undefined);
        private _role?;
        get role(): string;
        set role(value: string);
        get roleInput(): string | undefined;
        private _rules;
        get rules(): RulesPropertyList;
        putRules(value: RulesProperty[] | cdktn.IResolvable): void;
        get rulesInput(): cdktn.IResolvable | RulesProperty[] | undefined;
    }
    interface ApplyServerSideEncryptionByDefaultProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#kms_master_key_id AwsS3Bucket#kms_master_key_id}
        */
        readonly kmsMasterKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#sse_algorithm AwsS3Bucket#sse_algorithm}
        */
        readonly sseAlgorithm: string;
    }
    class ApplyServerSideEncryptionByDefaultPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ApplyServerSideEncryptionByDefaultProperty | undefined;
        set internalValue(value: ApplyServerSideEncryptionByDefaultProperty | undefined);
        private _kmsMasterKeyId?;
        get kmsMasterKeyId(): string;
        set kmsMasterKeyId(value: string);
        resetKmsMasterKeyId(): void;
        get kmsMasterKeyIdInput(): string | undefined;
        private _sseAlgorithm?;
        get sseAlgorithm(): string;
        set sseAlgorithm(value: string);
        get sseAlgorithmInput(): string | undefined;
    }
    interface ServerSideEncryptionConfigurationRuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#bucket_key_enabled AwsS3Bucket#bucket_key_enabled}
        */
        readonly bucketKeyEnabled?: boolean | cdktn.IResolvable;
        /**
        * apply_server_side_encryption_by_default block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#apply_server_side_encryption_by_default AwsS3Bucket#apply_server_side_encryption_by_default}
        */
        readonly applyServerSideEncryptionByDefault: ApplyServerSideEncryptionByDefaultProperty;
    }
    class ServerSideEncryptionConfigurationRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ServerSideEncryptionConfigurationRuleProperty | undefined;
        set internalValue(value: ServerSideEncryptionConfigurationRuleProperty | undefined);
        private _bucketKeyEnabled?;
        get bucketKeyEnabled(): boolean | cdktn.IResolvable;
        set bucketKeyEnabled(value: boolean | cdktn.IResolvable);
        resetBucketKeyEnabled(): void;
        get bucketKeyEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _applyServerSideEncryptionByDefault;
        get applyServerSideEncryptionByDefault(): ApplyServerSideEncryptionByDefaultPropertyOutputReference;
        putApplyServerSideEncryptionByDefault(value: ApplyServerSideEncryptionByDefaultProperty): void;
        get applyServerSideEncryptionByDefaultInput(): ApplyServerSideEncryptionByDefaultProperty | undefined;
    }
    interface ServerSideEncryptionConfigurationProperty {
        /**
        * rule block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#rule AwsS3Bucket#rule}
        */
        readonly rule: ServerSideEncryptionConfigurationRuleProperty;
    }
    class ServerSideEncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ServerSideEncryptionConfigurationProperty | undefined;
        set internalValue(value: ServerSideEncryptionConfigurationProperty | undefined);
        private _rule;
        get rule(): ServerSideEncryptionConfigurationRulePropertyOutputReference;
        putRule(value: ServerSideEncryptionConfigurationRuleProperty): void;
        get ruleInput(): ServerSideEncryptionConfigurationRuleProperty | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#create AwsS3Bucket#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#delete AwsS3Bucket#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#read AwsS3Bucket#read}
        */
        readonly read?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#update AwsS3Bucket#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _read?;
        get read(): string;
        set read(value: string);
        resetRead(): void;
        get readInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface VersioningProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#enabled AwsS3Bucket#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#mfa_delete AwsS3Bucket#mfa_delete}
        */
        readonly mfaDelete?: boolean | cdktn.IResolvable;
    }
    class VersioningPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VersioningProperty | undefined;
        set internalValue(value: VersioningProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _mfaDelete?;
        get mfaDelete(): boolean | cdktn.IResolvable;
        set mfaDelete(value: boolean | cdktn.IResolvable);
        resetMfaDelete(): void;
        get mfaDeleteInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface WebsiteProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#error_document AwsS3Bucket#error_document}
        */
        readonly errorDocument?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#index_document AwsS3Bucket#index_document}
        */
        readonly indexDocument?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#redirect_all_requests_to AwsS3Bucket#redirect_all_requests_to}
        */
        readonly redirectAllRequestsTo?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#routing_rules AwsS3Bucket#routing_rules}
        */
        readonly routingRules?: string;
    }
    class WebsitePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): WebsiteProperty | undefined;
        set internalValue(value: WebsiteProperty | undefined);
        private _errorDocument?;
        get errorDocument(): string;
        set errorDocument(value: string);
        resetErrorDocument(): void;
        get errorDocumentInput(): string | undefined;
        private _indexDocument?;
        get indexDocument(): string;
        set indexDocument(value: string);
        resetIndexDocument(): void;
        get indexDocumentInput(): string | undefined;
        private _redirectAllRequestsTo?;
        get redirectAllRequestsTo(): string;
        set redirectAllRequestsTo(value: string);
        resetRedirectAllRequestsTo(): void;
        get redirectAllRequestsToInput(): string | undefined;
        private _routingRules?;
        get routingRules(): string;
        set routingRules(value: string);
        resetRoutingRules(): void;
        get routingRulesInput(): string | undefined;
    }
}
