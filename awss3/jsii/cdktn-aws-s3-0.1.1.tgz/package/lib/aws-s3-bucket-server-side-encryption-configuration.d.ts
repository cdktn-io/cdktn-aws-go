import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsS3BucketServerSideEncryptionConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_server_side_encryption_configuration#bucket AwsS3BucketServerSideEncryptionConfiguration#bucket}
    */
    readonly bucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_server_side_encryption_configuration#expected_bucket_owner AwsS3BucketServerSideEncryptionConfiguration#expected_bucket_owner}
    */
    readonly expectedBucketOwner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_server_side_encryption_configuration#id AwsS3BucketServerSideEncryptionConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_server_side_encryption_configuration#region AwsS3BucketServerSideEncryptionConfiguration#region}
    */
    readonly region?: string;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_server_side_encryption_configuration#rule AwsS3BucketServerSideEncryptionConfiguration#rule}
    */
    readonly rule: AwsS3BucketServerSideEncryptionConfiguration.RuleProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_server_side_encryption_configuration aws_s3_bucket_server_side_encryption_configuration}
*/
export declare class AwsS3BucketServerSideEncryptionConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3_bucket_server_side_encryption_configuration";
    /**
    * Generates CDKTN code for importing a AwsS3BucketServerSideEncryptionConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsS3BucketServerSideEncryptionConfiguration to import
    * @param importFromId The id of the existing AwsS3BucketServerSideEncryptionConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_server_side_encryption_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsS3BucketServerSideEncryptionConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_server_side_encryption_configuration aws_s3_bucket_server_side_encryption_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsS3BucketServerSideEncryptionConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsS3BucketServerSideEncryptionConfigurationConfig);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _expectedBucketOwner?;
    get expectedBucketOwner(): string;
    set expectedBucketOwner(value: string);
    resetExpectedBucketOwner(): void;
    get expectedBucketOwnerInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _rule;
    get rule(): AwsS3BucketServerSideEncryptionConfiguration.RulePropertyList;
    putRule(value: AwsS3BucketServerSideEncryptionConfiguration.RuleProperty[] | cdktn.IResolvable): void;
    get ruleInput(): cdktn.IResolvable | AwsS3BucketServerSideEncryptionConfiguration.RuleProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsS3BucketServerSideEncryptionConfigurationMapperApplyServerSideEncryptionByDefaultPropertyToTerraform(struct?: AwsS3BucketServerSideEncryptionConfiguration.ApplyServerSideEncryptionByDefaultPropertyOutputReference | AwsS3BucketServerSideEncryptionConfiguration.ApplyServerSideEncryptionByDefaultProperty): any;
export declare function awsS3BucketServerSideEncryptionConfigurationMapperApplyServerSideEncryptionByDefaultPropertyToHclTerraform(struct?: AwsS3BucketServerSideEncryptionConfiguration.ApplyServerSideEncryptionByDefaultPropertyOutputReference | AwsS3BucketServerSideEncryptionConfiguration.ApplyServerSideEncryptionByDefaultProperty): any;
export declare function awsS3BucketServerSideEncryptionConfigurationMapperRulePropertyToTerraform(struct?: AwsS3BucketServerSideEncryptionConfiguration.RuleProperty | cdktn.IResolvable): any;
export declare function awsS3BucketServerSideEncryptionConfigurationMapperRulePropertyToHclTerraform(struct?: AwsS3BucketServerSideEncryptionConfiguration.RuleProperty | cdktn.IResolvable): any;
export declare namespace AwsS3BucketServerSideEncryptionConfiguration {
    interface ApplyServerSideEncryptionByDefaultProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_server_side_encryption_configuration#kms_master_key_id AwsS3BucketServerSideEncryptionConfiguration#kms_master_key_id}
        */
        readonly kmsMasterKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_server_side_encryption_configuration#sse_algorithm AwsS3BucketServerSideEncryptionConfiguration#sse_algorithm}
        */
        readonly sseAlgorithm: string;
    }
    class ApplyServerSideEncryptionByDefaultPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ApplyServerSideEncryptionByDefaultProperty | undefined;
        set internalValue(value: ApplyServerSideEncryptionByDefaultProperty | undefined);
        private _kmsMasterKeyId?;
        get kmsMasterKeyId(): string;
        set kmsMasterKeyId(value: string);
        resetKmsMasterKeyId(): void;
        get kmsMasterKeyIdInput(): string | undefined;
        private _sseAlgorithm?;
        get sseAlgorithm(): string;
        set sseAlgorithm(value: string);
        get sseAlgorithmInput(): string | undefined;
    }
    interface RuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_server_side_encryption_configuration#blocked_encryption_types AwsS3BucketServerSideEncryptionConfiguration#blocked_encryption_types}
        */
        readonly blockedEncryptionTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_server_side_encryption_configuration#bucket_key_enabled AwsS3BucketServerSideEncryptionConfiguration#bucket_key_enabled}
        */
        readonly bucketKeyEnabled?: boolean | cdktn.IResolvable;
        /**
        * apply_server_side_encryption_by_default block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_server_side_encryption_configuration#apply_server_side_encryption_by_default AwsS3BucketServerSideEncryptionConfiguration#apply_server_side_encryption_by_default}
        */
        readonly applyServerSideEncryptionByDefault?: ApplyServerSideEncryptionByDefaultProperty;
    }
    class RulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleProperty | cdktn.IResolvable | undefined);
        private _blockedEncryptionTypes?;
        get blockedEncryptionTypes(): string[];
        set blockedEncryptionTypes(value: string[]);
        resetBlockedEncryptionTypes(): void;
        get blockedEncryptionTypesInput(): string[] | undefined;
        private _bucketKeyEnabled?;
        get bucketKeyEnabled(): boolean | cdktn.IResolvable;
        set bucketKeyEnabled(value: boolean | cdktn.IResolvable);
        resetBucketKeyEnabled(): void;
        get bucketKeyEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _applyServerSideEncryptionByDefault;
        get applyServerSideEncryptionByDefault(): ApplyServerSideEncryptionByDefaultPropertyOutputReference;
        putApplyServerSideEncryptionByDefault(value: ApplyServerSideEncryptionByDefaultProperty): void;
        resetApplyServerSideEncryptionByDefault(): void;
        get applyServerSideEncryptionByDefaultInput(): ApplyServerSideEncryptionByDefaultProperty | undefined;
    }
    class RulePropertyList extends cdktn.ComplexList {
        internalValue?: RuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulePropertyOutputReference;
    }
}
