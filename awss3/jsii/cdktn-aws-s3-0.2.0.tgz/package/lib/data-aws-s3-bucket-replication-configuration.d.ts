import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfBucketReplicationConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3_bucket_replication_configuration#bucket DataTfBucketReplicationConfiguration#bucket}
    */
    readonly bucket: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3_bucket_replication_configuration#region DataTfBucketReplicationConfiguration#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3_bucket_replication_configuration aws_s3_bucket_replication_configuration}
*/
export declare class DataTfBucketReplicationConfiguration extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_s3_bucket_replication_configuration";
    /**
    * Generates CDKTN code for importing a DataTfBucketReplicationConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfBucketReplicationConfiguration to import
    * @param importFromId The id of the existing DataTfBucketReplicationConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3_bucket_replication_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfBucketReplicationConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3_bucket_replication_configuration aws_s3_bucket_replication_configuration} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfBucketReplicationConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: DataTfBucketReplicationConfigurationConfig);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get role(): string;
    private _rule;
    get rule(): DataTfBucketReplicationConfiguration.RulePropertyList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfBucketReplicationConfigurationDeleteMarkerReplicationPropertyToTerraform(struct?: DataTfBucketReplicationConfiguration.DeleteMarkerReplicationProperty): any;
export declare function dataTfBucketReplicationConfigurationDeleteMarkerReplicationPropertyToHclTerraform(struct?: DataTfBucketReplicationConfiguration.DeleteMarkerReplicationProperty): any;
export declare function dataTfBucketReplicationConfigurationAccessControlTranslationPropertyToTerraform(struct?: DataTfBucketReplicationConfiguration.AccessControlTranslationProperty): any;
export declare function dataTfBucketReplicationConfigurationAccessControlTranslationPropertyToHclTerraform(struct?: DataTfBucketReplicationConfiguration.AccessControlTranslationProperty): any;
export declare function dataTfBucketReplicationConfigurationEncryptionConfigurationPropertyToTerraform(struct?: DataTfBucketReplicationConfiguration.EncryptionConfigurationProperty): any;
export declare function dataTfBucketReplicationConfigurationEncryptionConfigurationPropertyToHclTerraform(struct?: DataTfBucketReplicationConfiguration.EncryptionConfigurationProperty): any;
export declare function dataTfBucketReplicationConfigurationEventThresholdPropertyToTerraform(struct?: DataTfBucketReplicationConfiguration.EventThresholdProperty): any;
export declare function dataTfBucketReplicationConfigurationEventThresholdPropertyToHclTerraform(struct?: DataTfBucketReplicationConfiguration.EventThresholdProperty): any;
export declare function dataTfBucketReplicationConfigurationMetricsPropertyToTerraform(struct?: DataTfBucketReplicationConfiguration.MetricsProperty): any;
export declare function dataTfBucketReplicationConfigurationMetricsPropertyToHclTerraform(struct?: DataTfBucketReplicationConfiguration.MetricsProperty): any;
export declare function dataTfBucketReplicationConfigurationTimePropertyToTerraform(struct?: DataTfBucketReplicationConfiguration.TimeProperty): any;
export declare function dataTfBucketReplicationConfigurationTimePropertyToHclTerraform(struct?: DataTfBucketReplicationConfiguration.TimeProperty): any;
export declare function dataTfBucketReplicationConfigurationReplicationTimePropertyToTerraform(struct?: DataTfBucketReplicationConfiguration.ReplicationTimeProperty): any;
export declare function dataTfBucketReplicationConfigurationReplicationTimePropertyToHclTerraform(struct?: DataTfBucketReplicationConfiguration.ReplicationTimeProperty): any;
export declare function dataTfBucketReplicationConfigurationDestinationPropertyToTerraform(struct?: DataTfBucketReplicationConfiguration.DestinationProperty): any;
export declare function dataTfBucketReplicationConfigurationDestinationPropertyToHclTerraform(struct?: DataTfBucketReplicationConfiguration.DestinationProperty): any;
export declare function dataTfBucketReplicationConfigurationExistingObjectReplicationPropertyToTerraform(struct?: DataTfBucketReplicationConfiguration.ExistingObjectReplicationProperty): any;
export declare function dataTfBucketReplicationConfigurationExistingObjectReplicationPropertyToHclTerraform(struct?: DataTfBucketReplicationConfiguration.ExistingObjectReplicationProperty): any;
export declare function dataTfBucketReplicationConfigurationRuleFilterAndTagPropertyToTerraform(struct?: DataTfBucketReplicationConfiguration.RuleFilterAndTagProperty): any;
export declare function dataTfBucketReplicationConfigurationRuleFilterAndTagPropertyToHclTerraform(struct?: DataTfBucketReplicationConfiguration.RuleFilterAndTagProperty): any;
export declare function dataTfBucketReplicationConfigurationAndPropertyToTerraform(struct?: DataTfBucketReplicationConfiguration.AndProperty): any;
export declare function dataTfBucketReplicationConfigurationAndPropertyToHclTerraform(struct?: DataTfBucketReplicationConfiguration.AndProperty): any;
export declare function dataTfBucketReplicationConfigurationRuleFilterTagPropertyToTerraform(struct?: DataTfBucketReplicationConfiguration.RuleFilterTagProperty): any;
export declare function dataTfBucketReplicationConfigurationRuleFilterTagPropertyToHclTerraform(struct?: DataTfBucketReplicationConfiguration.RuleFilterTagProperty): any;
export declare function dataTfBucketReplicationConfigurationFilterPropertyToTerraform(struct?: DataTfBucketReplicationConfiguration.FilterProperty): any;
export declare function dataTfBucketReplicationConfigurationFilterPropertyToHclTerraform(struct?: DataTfBucketReplicationConfiguration.FilterProperty): any;
export declare function dataTfBucketReplicationConfigurationReplicaModificationsPropertyToTerraform(struct?: DataTfBucketReplicationConfiguration.ReplicaModificationsProperty): any;
export declare function dataTfBucketReplicationConfigurationReplicaModificationsPropertyToHclTerraform(struct?: DataTfBucketReplicationConfiguration.ReplicaModificationsProperty): any;
export declare function dataTfBucketReplicationConfigurationSseKmsEncryptedObjectsPropertyToTerraform(struct?: DataTfBucketReplicationConfiguration.SseKmsEncryptedObjectsProperty): any;
export declare function dataTfBucketReplicationConfigurationSseKmsEncryptedObjectsPropertyToHclTerraform(struct?: DataTfBucketReplicationConfiguration.SseKmsEncryptedObjectsProperty): any;
export declare function dataTfBucketReplicationConfigurationSourceSelectionCriteriaPropertyToTerraform(struct?: DataTfBucketReplicationConfiguration.SourceSelectionCriteriaProperty): any;
export declare function dataTfBucketReplicationConfigurationSourceSelectionCriteriaPropertyToHclTerraform(struct?: DataTfBucketReplicationConfiguration.SourceSelectionCriteriaProperty): any;
export declare function dataTfBucketReplicationConfigurationRulePropertyToTerraform(struct?: DataTfBucketReplicationConfiguration.RuleProperty): any;
export declare function dataTfBucketReplicationConfigurationRulePropertyToHclTerraform(struct?: DataTfBucketReplicationConfiguration.RuleProperty): any;
export declare namespace DataTfBucketReplicationConfiguration {
    interface DeleteMarkerReplicationProperty {
    }
    class DeleteMarkerReplicationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DeleteMarkerReplicationProperty | undefined;
        set internalValue(value: DeleteMarkerReplicationProperty | undefined);
        get status(): string;
    }
    class DeleteMarkerReplicationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DeleteMarkerReplicationPropertyOutputReference;
    }
    interface AccessControlTranslationProperty {
    }
    class AccessControlTranslationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AccessControlTranslationProperty | undefined;
        set internalValue(value: AccessControlTranslationProperty | undefined);
        get owner(): string;
    }
    class AccessControlTranslationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AccessControlTranslationPropertyOutputReference;
    }
    interface EncryptionConfigurationProperty {
    }
    class EncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EncryptionConfigurationProperty | undefined;
        set internalValue(value: EncryptionConfigurationProperty | undefined);
        get replicaKmsKeyId(): string;
    }
    class EncryptionConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EncryptionConfigurationPropertyOutputReference;
    }
    interface EventThresholdProperty {
    }
    class EventThresholdPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EventThresholdProperty | undefined;
        set internalValue(value: EventThresholdProperty | undefined);
        get minutes(): number;
    }
    class EventThresholdPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EventThresholdPropertyOutputReference;
    }
    interface MetricsProperty {
    }
    class MetricsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MetricsProperty | undefined;
        set internalValue(value: MetricsProperty | undefined);
        private _eventThreshold;
        get eventThreshold(): EventThresholdPropertyList;
        get status(): string;
    }
    class MetricsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MetricsPropertyOutputReference;
    }
    interface TimeProperty {
    }
    class TimePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TimeProperty | undefined;
        set internalValue(value: TimeProperty | undefined);
        get minutes(): number;
    }
    class TimePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TimePropertyOutputReference;
    }
    interface ReplicationTimeProperty {
    }
    class ReplicationTimePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReplicationTimeProperty | undefined;
        set internalValue(value: ReplicationTimeProperty | undefined);
        get status(): string;
        private _time;
        get time(): TimePropertyList;
    }
    class ReplicationTimePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReplicationTimePropertyOutputReference;
    }
    interface DestinationProperty {
    }
    class DestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DestinationProperty | undefined;
        set internalValue(value: DestinationProperty | undefined);
        private _accessControlTranslation;
        get accessControlTranslation(): AccessControlTranslationPropertyList;
        get account(): string;
        get bucket(): string;
        private _encryptionConfiguration;
        get encryptionConfiguration(): EncryptionConfigurationPropertyList;
        private _metrics;
        get metrics(): MetricsPropertyList;
        private _replicationTime;
        get replicationTime(): ReplicationTimePropertyList;
        get storageClass(): string;
    }
    class DestinationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DestinationPropertyOutputReference;
    }
    interface ExistingObjectReplicationProperty {
    }
    class ExistingObjectReplicationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExistingObjectReplicationProperty | undefined;
        set internalValue(value: ExistingObjectReplicationProperty | undefined);
        get status(): string;
    }
    class ExistingObjectReplicationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExistingObjectReplicationPropertyOutputReference;
    }
    interface RuleFilterAndTagProperty {
    }
    class RuleFilterAndTagPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleFilterAndTagProperty | undefined;
        set internalValue(value: RuleFilterAndTagProperty | undefined);
        get key(): string;
        get value(): string;
    }
    class RuleFilterAndTagPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleFilterAndTagPropertyOutputReference;
    }
    interface AndProperty {
    }
    class AndPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AndProperty | undefined;
        set internalValue(value: AndProperty | undefined);
        get prefix(): string;
        private _tag;
        get tag(): RuleFilterAndTagPropertyList;
    }
    class AndPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AndPropertyOutputReference;
    }
    interface RuleFilterTagProperty {
    }
    class RuleFilterTagPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleFilterTagProperty | undefined;
        set internalValue(value: RuleFilterTagProperty | undefined);
        get key(): string;
        get value(): string;
    }
    class RuleFilterTagPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleFilterTagPropertyOutputReference;
    }
    interface FilterProperty {
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterProperty | undefined;
        set internalValue(value: FilterProperty | undefined);
        private _and;
        get and(): AndPropertyList;
        get prefix(): string;
        private _tag;
        get tag(): RuleFilterTagPropertyList;
    }
    class FilterPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterPropertyOutputReference;
    }
    interface ReplicaModificationsProperty {
    }
    class ReplicaModificationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReplicaModificationsProperty | undefined;
        set internalValue(value: ReplicaModificationsProperty | undefined);
        get status(): string;
    }
    class ReplicaModificationsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReplicaModificationsPropertyOutputReference;
    }
    interface SseKmsEncryptedObjectsProperty {
    }
    class SseKmsEncryptedObjectsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SseKmsEncryptedObjectsProperty | undefined;
        set internalValue(value: SseKmsEncryptedObjectsProperty | undefined);
        get status(): string;
    }
    class SseKmsEncryptedObjectsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SseKmsEncryptedObjectsPropertyOutputReference;
    }
    interface SourceSelectionCriteriaProperty {
    }
    class SourceSelectionCriteriaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SourceSelectionCriteriaProperty | undefined;
        set internalValue(value: SourceSelectionCriteriaProperty | undefined);
        private _replicaModifications;
        get replicaModifications(): ReplicaModificationsPropertyList;
        private _sseKmsEncryptedObjects;
        get sseKmsEncryptedObjects(): SseKmsEncryptedObjectsPropertyList;
    }
    class SourceSelectionCriteriaPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SourceSelectionCriteriaPropertyOutputReference;
    }
    interface RuleProperty {
    }
    class RulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleProperty | undefined;
        set internalValue(value: RuleProperty | undefined);
        private _deleteMarkerReplication;
        get deleteMarkerReplication(): DeleteMarkerReplicationPropertyList;
        private _destination;
        get destination(): DestinationPropertyList;
        private _existingObjectReplication;
        get existingObjectReplication(): ExistingObjectReplicationPropertyList;
        private _filter;
        get filter(): FilterPropertyList;
        get id(): string;
        get prefix(): string;
        get priority(): number;
        private _sourceSelectionCriteria;
        get sourceSelectionCriteria(): SourceSelectionCriteriaPropertyList;
        get status(): string;
    }
    class RulePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulePropertyOutputReference;
    }
}
