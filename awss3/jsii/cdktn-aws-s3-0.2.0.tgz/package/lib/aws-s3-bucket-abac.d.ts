import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfBucketAbacConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_abac#bucket TfBucketAbac#bucket}
    */
    readonly bucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_abac#expected_bucket_owner TfBucketAbac#expected_bucket_owner}
    */
    readonly expectedBucketOwner?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_abac#region TfBucketAbac#region}
    */
    readonly region?: string;
    /**
    * abac_status block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_abac#abac_status TfBucketAbac#abac_status}
    */
    readonly abacStatus?: TfBucketAbac.AbacStatusProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_abac aws_s3_bucket_abac}
*/
export declare class TfBucketAbac extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3_bucket_abac";
    /**
    * Generates CDKTN code for importing a TfBucketAbac resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfBucketAbac to import
    * @param importFromId The id of the existing TfBucketAbac that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_abac#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfBucketAbac to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_abac aws_s3_bucket_abac} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfBucketAbacConfig
    */
    constructor(scope: Construct, id: string, config: TfBucketAbacConfig);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _expectedBucketOwner?;
    get expectedBucketOwner(): string;
    set expectedBucketOwner(value: string);
    resetExpectedBucketOwner(): void;
    get expectedBucketOwnerInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _abacStatus;
    get abacStatus(): TfBucketAbac.AbacStatusPropertyList;
    putAbacStatus(value: TfBucketAbac.AbacStatusProperty[] | cdktn.IResolvable): void;
    resetAbacStatus(): void;
    get abacStatusInput(): cdktn.IResolvable | TfBucketAbac.AbacStatusProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfBucketAbacAbacStatusPropertyToTerraform(struct?: TfBucketAbac.AbacStatusProperty | cdktn.IResolvable): any;
export declare function tfBucketAbacAbacStatusPropertyToHclTerraform(struct?: TfBucketAbac.AbacStatusProperty | cdktn.IResolvable): any;
export declare namespace TfBucketAbac {
    interface AbacStatusProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_abac#status TfBucketAbac#status}
        */
        readonly status: string;
    }
    class AbacStatusPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AbacStatusProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AbacStatusProperty | cdktn.IResolvable | undefined);
        private _status?;
        get status(): string;
        set status(value: string);
        get statusInput(): string | undefined;
    }
    class AbacStatusPropertyList extends cdktn.ComplexList {
        internalValue?: AbacStatusProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AbacStatusPropertyOutputReference;
    }
}
