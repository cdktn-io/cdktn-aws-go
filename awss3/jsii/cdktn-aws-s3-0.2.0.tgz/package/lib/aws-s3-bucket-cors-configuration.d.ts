import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfBucketCorsConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_cors_configuration#bucket TfBucketCorsConfiguration#bucket}
    */
    readonly bucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_cors_configuration#expected_bucket_owner TfBucketCorsConfiguration#expected_bucket_owner}
    */
    readonly expectedBucketOwner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_cors_configuration#id TfBucketCorsConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_cors_configuration#region TfBucketCorsConfiguration#region}
    */
    readonly region?: string;
    /**
    * cors_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_cors_configuration#cors_rule TfBucketCorsConfiguration#cors_rule}
    */
    readonly corsRule: TfBucketCorsConfiguration.CorsRuleProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_cors_configuration aws_s3_bucket_cors_configuration}
*/
export declare class TfBucketCorsConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3_bucket_cors_configuration";
    /**
    * Generates CDKTN code for importing a TfBucketCorsConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfBucketCorsConfiguration to import
    * @param importFromId The id of the existing TfBucketCorsConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_cors_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfBucketCorsConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_cors_configuration aws_s3_bucket_cors_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfBucketCorsConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: TfBucketCorsConfigurationConfig);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _expectedBucketOwner?;
    get expectedBucketOwner(): string;
    set expectedBucketOwner(value: string);
    resetExpectedBucketOwner(): void;
    get expectedBucketOwnerInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _corsRule;
    get corsRule(): TfBucketCorsConfiguration.CorsRulePropertyList;
    putCorsRule(value: TfBucketCorsConfiguration.CorsRuleProperty[] | cdktn.IResolvable): void;
    get corsRuleInput(): cdktn.IResolvable | TfBucketCorsConfiguration.CorsRuleProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfBucketCorsConfigurationCorsRulePropertyToTerraform(struct?: TfBucketCorsConfiguration.CorsRuleProperty | cdktn.IResolvable): any;
export declare function tfBucketCorsConfigurationCorsRulePropertyToHclTerraform(struct?: TfBucketCorsConfiguration.CorsRuleProperty | cdktn.IResolvable): any;
export declare namespace TfBucketCorsConfiguration {
    interface CorsRuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_cors_configuration#allowed_headers TfBucketCorsConfiguration#allowed_headers}
        */
        readonly allowedHeaders?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_cors_configuration#allowed_methods TfBucketCorsConfiguration#allowed_methods}
        */
        readonly allowedMethods: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_cors_configuration#allowed_origins TfBucketCorsConfiguration#allowed_origins}
        */
        readonly allowedOrigins: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_cors_configuration#expose_headers TfBucketCorsConfiguration#expose_headers}
        */
        readonly exposeHeaders?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_cors_configuration#id TfBucketCorsConfiguration#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_cors_configuration#max_age_seconds TfBucketCorsConfiguration#max_age_seconds}
        */
        readonly maxAgeSeconds?: number;
    }
    class CorsRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CorsRuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CorsRuleProperty | cdktn.IResolvable | undefined);
        private _allowedHeaders?;
        get allowedHeaders(): string[];
        set allowedHeaders(value: string[]);
        resetAllowedHeaders(): void;
        get allowedHeadersInput(): string[] | undefined;
        private _allowedMethods?;
        get allowedMethods(): string[];
        set allowedMethods(value: string[]);
        get allowedMethodsInput(): string[] | undefined;
        private _allowedOrigins?;
        get allowedOrigins(): string[];
        set allowedOrigins(value: string[]);
        get allowedOriginsInput(): string[] | undefined;
        private _exposeHeaders?;
        get exposeHeaders(): string[];
        set exposeHeaders(value: string[]);
        resetExposeHeaders(): void;
        get exposeHeadersInput(): string[] | undefined;
        private _id?;
        get id(): string;
        set id(value: string);
        resetId(): void;
        get idInput(): string | undefined;
        private _maxAgeSeconds?;
        get maxAgeSeconds(): number;
        set maxAgeSeconds(value: number);
        resetMaxAgeSeconds(): void;
        get maxAgeSecondsInput(): number | undefined;
    }
    class CorsRulePropertyList extends cdktn.ComplexList {
        internalValue?: CorsRuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CorsRulePropertyOutputReference;
    }
}
