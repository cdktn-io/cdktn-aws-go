import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfBucketInventoryConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory#bucket TfBucketInventory#bucket}
    */
    readonly bucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory#enabled TfBucketInventory#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory#id TfBucketInventory#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory#included_object_versions TfBucketInventory#included_object_versions}
    */
    readonly includedObjectVersions: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory#name TfBucketInventory#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory#optional_fields TfBucketInventory#optional_fields}
    */
    readonly optionalFields?: string[];
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory#region TfBucketInventory#region}
    */
    readonly region?: string;
    /**
    * destination block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory#destination TfBucketInventory#destination}
    */
    readonly destination: TfBucketInventory.DestinationProperty;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory#filter TfBucketInventory#filter}
    */
    readonly filter?: TfBucketInventory.FilterProperty;
    /**
    * schedule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory#schedule TfBucketInventory#schedule}
    */
    readonly schedule: TfBucketInventory.ScheduleProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory aws_s3_bucket_inventory}
*/
export declare class TfBucketInventory extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3_bucket_inventory";
    /**
    * Generates CDKTN code for importing a TfBucketInventory resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfBucketInventory to import
    * @param importFromId The id of the existing TfBucketInventory that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfBucketInventory to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory aws_s3_bucket_inventory} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfBucketInventoryConfig
    */
    constructor(scope: Construct, id: string, config: TfBucketInventoryConfig);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _includedObjectVersions?;
    get includedObjectVersions(): string;
    set includedObjectVersions(value: string);
    get includedObjectVersionsInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _optionalFields?;
    get optionalFields(): string[];
    set optionalFields(value: string[]);
    resetOptionalFields(): void;
    get optionalFieldsInput(): string[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _destination;
    get destination(): TfBucketInventory.DestinationPropertyOutputReference;
    putDestination(value: TfBucketInventory.DestinationProperty): void;
    get destinationInput(): TfBucketInventory.DestinationProperty | undefined;
    private _filter;
    get filter(): TfBucketInventory.FilterPropertyOutputReference;
    putFilter(value: TfBucketInventory.FilterProperty): void;
    resetFilter(): void;
    get filterInput(): TfBucketInventory.FilterProperty | undefined;
    private _schedule;
    get schedule(): TfBucketInventory.SchedulePropertyOutputReference;
    putSchedule(value: TfBucketInventory.ScheduleProperty): void;
    get scheduleInput(): TfBucketInventory.ScheduleProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfBucketInventorySseKmsPropertyToTerraform(struct?: TfBucketInventory.SseKmsPropertyOutputReference | TfBucketInventory.SseKmsProperty): any;
export declare function tfBucketInventorySseKmsPropertyToHclTerraform(struct?: TfBucketInventory.SseKmsPropertyOutputReference | TfBucketInventory.SseKmsProperty): any;
export declare function tfBucketInventorySseS3PropertyToTerraform(struct?: TfBucketInventory.SseS3PropertyOutputReference | TfBucketInventory.SseS3Property): any;
export declare function tfBucketInventorySseS3PropertyToHclTerraform(struct?: TfBucketInventory.SseS3PropertyOutputReference | TfBucketInventory.SseS3Property): any;
export declare function tfBucketInventoryEncryptionPropertyToTerraform(struct?: TfBucketInventory.EncryptionPropertyOutputReference | TfBucketInventory.EncryptionProperty): any;
export declare function tfBucketInventoryEncryptionPropertyToHclTerraform(struct?: TfBucketInventory.EncryptionPropertyOutputReference | TfBucketInventory.EncryptionProperty): any;
export declare function tfBucketInventoryBucketPropertyToTerraform(struct?: TfBucketInventory.BucketPropertyOutputReference | TfBucketInventory.BucketProperty): any;
export declare function tfBucketInventoryBucketPropertyToHclTerraform(struct?: TfBucketInventory.BucketPropertyOutputReference | TfBucketInventory.BucketProperty): any;
export declare function tfBucketInventoryDestinationPropertyToTerraform(struct?: TfBucketInventory.DestinationPropertyOutputReference | TfBucketInventory.DestinationProperty): any;
export declare function tfBucketInventoryDestinationPropertyToHclTerraform(struct?: TfBucketInventory.DestinationPropertyOutputReference | TfBucketInventory.DestinationProperty): any;
export declare function tfBucketInventoryFilterPropertyToTerraform(struct?: TfBucketInventory.FilterPropertyOutputReference | TfBucketInventory.FilterProperty): any;
export declare function tfBucketInventoryFilterPropertyToHclTerraform(struct?: TfBucketInventory.FilterPropertyOutputReference | TfBucketInventory.FilterProperty): any;
export declare function tfBucketInventorySchedulePropertyToTerraform(struct?: TfBucketInventory.SchedulePropertyOutputReference | TfBucketInventory.ScheduleProperty): any;
export declare function tfBucketInventorySchedulePropertyToHclTerraform(struct?: TfBucketInventory.SchedulePropertyOutputReference | TfBucketInventory.ScheduleProperty): any;
export declare namespace TfBucketInventory {
    interface SseKmsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory#key_id TfBucketInventory#key_id}
        */
        readonly keyId: string;
    }
    class SseKmsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SseKmsProperty | undefined;
        set internalValue(value: SseKmsProperty | undefined);
        private _keyId?;
        get keyId(): string;
        set keyId(value: string);
        get keyIdInput(): string | undefined;
    }
    interface SseS3Property {
    }
    class SseS3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SseS3Property | undefined;
        set internalValue(value: SseS3Property | undefined);
    }
    interface EncryptionProperty {
        /**
        * sse_kms block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory#sse_kms TfBucketInventory#sse_kms}
        */
        readonly sseKms?: SseKmsProperty;
        /**
        * sse_s3 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory#sse_s3 TfBucketInventory#sse_s3}
        */
        readonly sseS3?: SseS3Property;
    }
    class EncryptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncryptionProperty | undefined;
        set internalValue(value: EncryptionProperty | undefined);
        private _sseKms;
        get sseKms(): SseKmsPropertyOutputReference;
        putSseKms(value: SseKmsProperty): void;
        resetSseKms(): void;
        get sseKmsInput(): SseKmsProperty | undefined;
        private _sseS3;
        get sseS3(): SseS3PropertyOutputReference;
        putSseS3(value: SseS3Property): void;
        resetSseS3(): void;
        get sseS3Input(): SseS3Property | undefined;
    }
    interface BucketProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory#account_id TfBucketInventory#account_id}
        */
        readonly accountId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory#bucket_arn TfBucketInventory#bucket_arn}
        */
        readonly bucketArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory#format TfBucketInventory#format}
        */
        readonly format: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory#prefix TfBucketInventory#prefix}
        */
        readonly prefix?: string;
        /**
        * encryption block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory#encryption TfBucketInventory#encryption}
        */
        readonly encryption?: EncryptionProperty;
    }
    class BucketPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BucketProperty | undefined;
        set internalValue(value: BucketProperty | undefined);
        private _accountId?;
        get accountId(): string;
        set accountId(value: string);
        resetAccountId(): void;
        get accountIdInput(): string | undefined;
        private _bucketArn?;
        get bucketArn(): string;
        set bucketArn(value: string);
        get bucketArnInput(): string | undefined;
        private _format?;
        get format(): string;
        set format(value: string);
        get formatInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _encryption;
        get encryption(): EncryptionPropertyOutputReference;
        putEncryption(value: EncryptionProperty): void;
        resetEncryption(): void;
        get encryptionInput(): EncryptionProperty | undefined;
    }
    interface DestinationProperty {
        /**
        * bucket block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory#bucket TfBucketInventory#bucket}
        */
        readonly bucket: BucketProperty;
    }
    class DestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationProperty | undefined;
        set internalValue(value: DestinationProperty | undefined);
        private _bucket;
        get bucket(): BucketPropertyOutputReference;
        putBucket(value: BucketProperty): void;
        get bucketInput(): BucketProperty | undefined;
    }
    interface FilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory#prefix TfBucketInventory#prefix}
        */
        readonly prefix?: string;
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterProperty | undefined;
        set internalValue(value: FilterProperty | undefined);
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
    }
    interface ScheduleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_inventory#frequency TfBucketInventory#frequency}
        */
        readonly frequency: string;
    }
    class SchedulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ScheduleProperty | undefined;
        set internalValue(value: ScheduleProperty | undefined);
        private _frequency?;
        get frequency(): string;
        set frequency(value: string);
        get frequencyInput(): string | undefined;
    }
}
