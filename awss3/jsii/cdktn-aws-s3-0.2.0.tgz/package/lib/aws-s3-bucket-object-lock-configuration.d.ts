import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfBucketObjectLockConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_object_lock_configuration#bucket TfBucketObjectLockConfiguration#bucket}
    */
    readonly bucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_object_lock_configuration#expected_bucket_owner TfBucketObjectLockConfiguration#expected_bucket_owner}
    */
    readonly expectedBucketOwner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_object_lock_configuration#id TfBucketObjectLockConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_object_lock_configuration#object_lock_enabled TfBucketObjectLockConfiguration#object_lock_enabled}
    */
    readonly objectLockEnabled?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_object_lock_configuration#region TfBucketObjectLockConfiguration#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_object_lock_configuration#token TfBucketObjectLockConfiguration#token}
    */
    readonly token?: string;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_object_lock_configuration#rule TfBucketObjectLockConfiguration#rule}
    */
    readonly rule?: TfBucketObjectLockConfiguration.RuleProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_object_lock_configuration aws_s3_bucket_object_lock_configuration}
*/
export declare class TfBucketObjectLockConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3_bucket_object_lock_configuration";
    /**
    * Generates CDKTN code for importing a TfBucketObjectLockConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfBucketObjectLockConfiguration to import
    * @param importFromId The id of the existing TfBucketObjectLockConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_object_lock_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfBucketObjectLockConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_object_lock_configuration aws_s3_bucket_object_lock_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfBucketObjectLockConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: TfBucketObjectLockConfigurationConfig);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _expectedBucketOwner?;
    get expectedBucketOwner(): string;
    set expectedBucketOwner(value: string);
    resetExpectedBucketOwner(): void;
    get expectedBucketOwnerInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _objectLockEnabled?;
    get objectLockEnabled(): string;
    set objectLockEnabled(value: string);
    resetObjectLockEnabled(): void;
    get objectLockEnabledInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _token?;
    get token(): string;
    set token(value: string);
    resetToken(): void;
    get tokenInput(): string | undefined;
    private _rule;
    get rule(): TfBucketObjectLockConfiguration.RulePropertyOutputReference;
    putRule(value: TfBucketObjectLockConfiguration.RuleProperty): void;
    resetRule(): void;
    get ruleInput(): TfBucketObjectLockConfiguration.RuleProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfBucketObjectLockConfigurationMapperDefaultRetentionPropertyToTerraform(struct?: TfBucketObjectLockConfiguration.DefaultRetentionPropertyOutputReference | TfBucketObjectLockConfiguration.DefaultRetentionProperty): any;
export declare function tfBucketObjectLockConfigurationMapperDefaultRetentionPropertyToHclTerraform(struct?: TfBucketObjectLockConfiguration.DefaultRetentionPropertyOutputReference | TfBucketObjectLockConfiguration.DefaultRetentionProperty): any;
export declare function tfBucketObjectLockConfigurationMapperRulePropertyToTerraform(struct?: TfBucketObjectLockConfiguration.RulePropertyOutputReference | TfBucketObjectLockConfiguration.RuleProperty): any;
export declare function tfBucketObjectLockConfigurationMapperRulePropertyToHclTerraform(struct?: TfBucketObjectLockConfiguration.RulePropertyOutputReference | TfBucketObjectLockConfiguration.RuleProperty): any;
export declare namespace TfBucketObjectLockConfiguration {
    interface DefaultRetentionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_object_lock_configuration#days TfBucketObjectLockConfiguration#days}
        */
        readonly days?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_object_lock_configuration#mode TfBucketObjectLockConfiguration#mode}
        */
        readonly mode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_object_lock_configuration#years TfBucketObjectLockConfiguration#years}
        */
        readonly years?: number;
    }
    class DefaultRetentionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultRetentionProperty | undefined;
        set internalValue(value: DefaultRetentionProperty | undefined);
        private _days?;
        get days(): number;
        set days(value: number);
        resetDays(): void;
        get daysInput(): number | undefined;
        private _mode?;
        get mode(): string;
        set mode(value: string);
        resetMode(): void;
        get modeInput(): string | undefined;
        private _years?;
        get years(): number;
        set years(value: number);
        resetYears(): void;
        get yearsInput(): number | undefined;
    }
    interface RuleProperty {
        /**
        * default_retention block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_object_lock_configuration#default_retention TfBucketObjectLockConfiguration#default_retention}
        */
        readonly defaultRetention: DefaultRetentionProperty;
    }
    class RulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RuleProperty | undefined;
        set internalValue(value: RuleProperty | undefined);
        private _defaultRetention;
        get defaultRetention(): DefaultRetentionPropertyOutputReference;
        putDefaultRetention(value: DefaultRetentionProperty): void;
        get defaultRetentionInput(): DefaultRetentionProperty | undefined;
    }
}
