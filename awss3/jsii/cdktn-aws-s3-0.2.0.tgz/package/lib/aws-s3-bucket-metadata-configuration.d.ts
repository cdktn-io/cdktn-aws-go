import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfBucketMetadataConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_metadata_configuration#bucket TfBucketMetadataConfiguration#bucket}
    */
    readonly bucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_metadata_configuration#expected_bucket_owner TfBucketMetadataConfiguration#expected_bucket_owner}
    */
    readonly expectedBucketOwner?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_metadata_configuration#region TfBucketMetadataConfiguration#region}
    */
    readonly region?: string;
    /**
    * metadata_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_metadata_configuration#metadata_configuration TfBucketMetadataConfiguration#metadata_configuration}
    */
    readonly metadataConfiguration?: TfBucketMetadataConfiguration.MetadataConfigurationProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_metadata_configuration#timeouts TfBucketMetadataConfiguration#timeouts}
    */
    readonly timeouts?: TfBucketMetadataConfiguration.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_metadata_configuration aws_s3_bucket_metadata_configuration}
*/
export declare class TfBucketMetadataConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3_bucket_metadata_configuration";
    /**
    * Generates CDKTN code for importing a TfBucketMetadataConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfBucketMetadataConfiguration to import
    * @param importFromId The id of the existing TfBucketMetadataConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_metadata_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfBucketMetadataConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_metadata_configuration aws_s3_bucket_metadata_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfBucketMetadataConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: TfBucketMetadataConfigurationConfig);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _expectedBucketOwner?;
    get expectedBucketOwner(): string;
    set expectedBucketOwner(value: string);
    resetExpectedBucketOwner(): void;
    get expectedBucketOwnerInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _metadataConfiguration;
    get metadataConfiguration(): TfBucketMetadataConfiguration.MetadataConfigurationPropertyList;
    putMetadataConfiguration(value: TfBucketMetadataConfiguration.MetadataConfigurationProperty[] | cdktn.IResolvable): void;
    resetMetadataConfiguration(): void;
    get metadataConfigurationInput(): cdktn.IResolvable | TfBucketMetadataConfiguration.MetadataConfigurationProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfBucketMetadataConfiguration.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfBucketMetadataConfiguration.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfBucketMetadataConfiguration.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfBucketMetadataConfigurationDestinationPropertyToTerraform(struct?: TfBucketMetadataConfiguration.DestinationProperty): any;
export declare function tfBucketMetadataConfigurationDestinationPropertyToHclTerraform(struct?: TfBucketMetadataConfiguration.DestinationProperty): any;
export declare function tfBucketMetadataConfigurationMetadataConfigurationInventoryTableConfigurationEncryptionConfigurationPropertyToTerraform(struct?: TfBucketMetadataConfiguration.MetadataConfigurationInventoryTableConfigurationEncryptionConfigurationProperty | cdktn.IResolvable): any;
export declare function tfBucketMetadataConfigurationMetadataConfigurationInventoryTableConfigurationEncryptionConfigurationPropertyToHclTerraform(struct?: TfBucketMetadataConfiguration.MetadataConfigurationInventoryTableConfigurationEncryptionConfigurationProperty | cdktn.IResolvable): any;
export declare function tfBucketMetadataConfigurationInventoryTableConfigurationPropertyToTerraform(struct?: TfBucketMetadataConfiguration.InventoryTableConfigurationProperty | cdktn.IResolvable): any;
export declare function tfBucketMetadataConfigurationInventoryTableConfigurationPropertyToHclTerraform(struct?: TfBucketMetadataConfiguration.InventoryTableConfigurationProperty | cdktn.IResolvable): any;
export declare function tfBucketMetadataConfigurationMetadataConfigurationJournalTableConfigurationEncryptionConfigurationPropertyToTerraform(struct?: TfBucketMetadataConfiguration.MetadataConfigurationJournalTableConfigurationEncryptionConfigurationProperty | cdktn.IResolvable): any;
export declare function tfBucketMetadataConfigurationMetadataConfigurationJournalTableConfigurationEncryptionConfigurationPropertyToHclTerraform(struct?: TfBucketMetadataConfiguration.MetadataConfigurationJournalTableConfigurationEncryptionConfigurationProperty | cdktn.IResolvable): any;
export declare function tfBucketMetadataConfigurationRecordExpirationPropertyToTerraform(struct?: TfBucketMetadataConfiguration.RecordExpirationProperty | cdktn.IResolvable): any;
export declare function tfBucketMetadataConfigurationRecordExpirationPropertyToHclTerraform(struct?: TfBucketMetadataConfiguration.RecordExpirationProperty | cdktn.IResolvable): any;
export declare function tfBucketMetadataConfigurationJournalTableConfigurationPropertyToTerraform(struct?: TfBucketMetadataConfiguration.JournalTableConfigurationProperty | cdktn.IResolvable): any;
export declare function tfBucketMetadataConfigurationJournalTableConfigurationPropertyToHclTerraform(struct?: TfBucketMetadataConfiguration.JournalTableConfigurationProperty | cdktn.IResolvable): any;
export declare function tfBucketMetadataConfigurationMetadataConfigurationPropertyToTerraform(struct?: TfBucketMetadataConfiguration.MetadataConfigurationProperty | cdktn.IResolvable): any;
export declare function tfBucketMetadataConfigurationMetadataConfigurationPropertyToHclTerraform(struct?: TfBucketMetadataConfiguration.MetadataConfigurationProperty | cdktn.IResolvable): any;
export declare function tfBucketMetadataConfigurationTimeoutsPropertyToTerraform(struct?: TfBucketMetadataConfiguration.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfBucketMetadataConfigurationTimeoutsPropertyToHclTerraform(struct?: TfBucketMetadataConfiguration.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfBucketMetadataConfiguration {
    interface DestinationProperty {
    }
    class DestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DestinationProperty | undefined;
        set internalValue(value: DestinationProperty | undefined);
        get tableBucketArn(): string;
        get tableBucketType(): string;
        get tableNamespace(): string;
    }
    class DestinationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DestinationPropertyOutputReference;
    }
    interface MetadataConfigurationInventoryTableConfigurationEncryptionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_metadata_configuration#kms_key_arn TfBucketMetadataConfiguration#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_metadata_configuration#sse_algorithm TfBucketMetadataConfiguration#sse_algorithm}
        */
        readonly sseAlgorithm: string;
    }
    class MetadataConfigurationInventoryTableConfigurationEncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MetadataConfigurationInventoryTableConfigurationEncryptionConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MetadataConfigurationInventoryTableConfigurationEncryptionConfigurationProperty | cdktn.IResolvable | undefined);
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
        private _sseAlgorithm?;
        get sseAlgorithm(): string;
        set sseAlgorithm(value: string);
        get sseAlgorithmInput(): string | undefined;
    }
    class MetadataConfigurationInventoryTableConfigurationEncryptionConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: MetadataConfigurationInventoryTableConfigurationEncryptionConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MetadataConfigurationInventoryTableConfigurationEncryptionConfigurationPropertyOutputReference;
    }
    interface InventoryTableConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_metadata_configuration#configuration_state TfBucketMetadataConfiguration#configuration_state}
        */
        readonly configurationState: string;
        /**
        * encryption_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_metadata_configuration#encryption_configuration TfBucketMetadataConfiguration#encryption_configuration}
        */
        readonly encryptionConfiguration?: MetadataConfigurationInventoryTableConfigurationEncryptionConfigurationProperty[] | cdktn.IResolvable;
    }
    class InventoryTableConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InventoryTableConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InventoryTableConfigurationProperty | cdktn.IResolvable | undefined);
        private _configurationState?;
        get configurationState(): string;
        set configurationState(value: string);
        get configurationStateInput(): string | undefined;
        get tableArn(): string;
        get tableName(): string;
        private _encryptionConfiguration;
        get encryptionConfiguration(): MetadataConfigurationInventoryTableConfigurationEncryptionConfigurationPropertyList;
        putEncryptionConfiguration(value: MetadataConfigurationInventoryTableConfigurationEncryptionConfigurationProperty[] | cdktn.IResolvable): void;
        resetEncryptionConfiguration(): void;
        get encryptionConfigurationInput(): cdktn.IResolvable | MetadataConfigurationInventoryTableConfigurationEncryptionConfigurationProperty[] | undefined;
    }
    class InventoryTableConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: InventoryTableConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InventoryTableConfigurationPropertyOutputReference;
    }
    interface MetadataConfigurationJournalTableConfigurationEncryptionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_metadata_configuration#kms_key_arn TfBucketMetadataConfiguration#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_metadata_configuration#sse_algorithm TfBucketMetadataConfiguration#sse_algorithm}
        */
        readonly sseAlgorithm: string;
    }
    class MetadataConfigurationJournalTableConfigurationEncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MetadataConfigurationJournalTableConfigurationEncryptionConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MetadataConfigurationJournalTableConfigurationEncryptionConfigurationProperty | cdktn.IResolvable | undefined);
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
        private _sseAlgorithm?;
        get sseAlgorithm(): string;
        set sseAlgorithm(value: string);
        get sseAlgorithmInput(): string | undefined;
    }
    class MetadataConfigurationJournalTableConfigurationEncryptionConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: MetadataConfigurationJournalTableConfigurationEncryptionConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MetadataConfigurationJournalTableConfigurationEncryptionConfigurationPropertyOutputReference;
    }
    interface RecordExpirationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_metadata_configuration#days TfBucketMetadataConfiguration#days}
        */
        readonly days?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_metadata_configuration#expiration TfBucketMetadataConfiguration#expiration}
        */
        readonly expiration: string;
    }
    class RecordExpirationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RecordExpirationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RecordExpirationProperty | cdktn.IResolvable | undefined);
        private _days?;
        get days(): number;
        set days(value: number);
        resetDays(): void;
        get daysInput(): number | undefined;
        private _expiration?;
        get expiration(): string;
        set expiration(value: string);
        get expirationInput(): string | undefined;
    }
    class RecordExpirationPropertyList extends cdktn.ComplexList {
        internalValue?: RecordExpirationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RecordExpirationPropertyOutputReference;
    }
    interface JournalTableConfigurationProperty {
        /**
        * encryption_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_metadata_configuration#encryption_configuration TfBucketMetadataConfiguration#encryption_configuration}
        */
        readonly encryptionConfiguration?: MetadataConfigurationJournalTableConfigurationEncryptionConfigurationProperty[] | cdktn.IResolvable;
        /**
        * record_expiration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_metadata_configuration#record_expiration TfBucketMetadataConfiguration#record_expiration}
        */
        readonly recordExpiration?: RecordExpirationProperty[] | cdktn.IResolvable;
    }
    class JournalTableConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): JournalTableConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: JournalTableConfigurationProperty | cdktn.IResolvable | undefined);
        get tableArn(): string;
        get tableName(): string;
        private _encryptionConfiguration;
        get encryptionConfiguration(): MetadataConfigurationJournalTableConfigurationEncryptionConfigurationPropertyList;
        putEncryptionConfiguration(value: MetadataConfigurationJournalTableConfigurationEncryptionConfigurationProperty[] | cdktn.IResolvable): void;
        resetEncryptionConfiguration(): void;
        get encryptionConfigurationInput(): cdktn.IResolvable | MetadataConfigurationJournalTableConfigurationEncryptionConfigurationProperty[] | undefined;
        private _recordExpiration;
        get recordExpiration(): RecordExpirationPropertyList;
        putRecordExpiration(value: RecordExpirationProperty[] | cdktn.IResolvable): void;
        resetRecordExpiration(): void;
        get recordExpirationInput(): cdktn.IResolvable | RecordExpirationProperty[] | undefined;
    }
    class JournalTableConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: JournalTableConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): JournalTableConfigurationPropertyOutputReference;
    }
    interface MetadataConfigurationProperty {
        /**
        * inventory_table_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_metadata_configuration#inventory_table_configuration TfBucketMetadataConfiguration#inventory_table_configuration}
        */
        readonly inventoryTableConfiguration?: InventoryTableConfigurationProperty[] | cdktn.IResolvable;
        /**
        * journal_table_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_metadata_configuration#journal_table_configuration TfBucketMetadataConfiguration#journal_table_configuration}
        */
        readonly journalTableConfiguration?: JournalTableConfigurationProperty[] | cdktn.IResolvable;
    }
    class MetadataConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MetadataConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MetadataConfigurationProperty | cdktn.IResolvable | undefined);
        private _destination;
        get destination(): DestinationPropertyList;
        private _inventoryTableConfiguration;
        get inventoryTableConfiguration(): InventoryTableConfigurationPropertyList;
        putInventoryTableConfiguration(value: InventoryTableConfigurationProperty[] | cdktn.IResolvable): void;
        resetInventoryTableConfiguration(): void;
        get inventoryTableConfigurationInput(): cdktn.IResolvable | InventoryTableConfigurationProperty[] | undefined;
        private _journalTableConfiguration;
        get journalTableConfiguration(): JournalTableConfigurationPropertyList;
        putJournalTableConfiguration(value: JournalTableConfigurationProperty[] | cdktn.IResolvable): void;
        resetJournalTableConfiguration(): void;
        get journalTableConfigurationInput(): cdktn.IResolvable | JournalTableConfigurationProperty[] | undefined;
    }
    class MetadataConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: MetadataConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MetadataConfigurationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_metadata_configuration#create TfBucketMetadataConfiguration#create}
        */
        readonly create?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
    }
}
