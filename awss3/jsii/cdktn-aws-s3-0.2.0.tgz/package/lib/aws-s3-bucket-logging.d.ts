import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfBucketLoggingConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_logging#bucket TfBucketLogging#bucket}
    */
    readonly bucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_logging#expected_bucket_owner TfBucketLogging#expected_bucket_owner}
    */
    readonly expectedBucketOwner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_logging#id TfBucketLogging#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_logging#region TfBucketLogging#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_logging#target_bucket TfBucketLogging#target_bucket}
    */
    readonly targetBucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_logging#target_prefix TfBucketLogging#target_prefix}
    */
    readonly targetPrefix: string;
    /**
    * target_grant block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_logging#target_grant TfBucketLogging#target_grant}
    */
    readonly targetGrant?: TfBucketLogging.TargetGrantProperty[] | cdktn.IResolvable;
    /**
    * target_object_key_format block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_logging#target_object_key_format TfBucketLogging#target_object_key_format}
    */
    readonly targetObjectKeyFormat?: TfBucketLogging.TargetObjectKeyFormatProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_logging aws_s3_bucket_logging}
*/
export declare class TfBucketLogging extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3_bucket_logging";
    /**
    * Generates CDKTN code for importing a TfBucketLogging resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfBucketLogging to import
    * @param importFromId The id of the existing TfBucketLogging that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_logging#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfBucketLogging to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_logging aws_s3_bucket_logging} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfBucketLoggingConfig
    */
    constructor(scope: Construct, id: string, config: TfBucketLoggingConfig);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _expectedBucketOwner?;
    get expectedBucketOwner(): string;
    set expectedBucketOwner(value: string);
    resetExpectedBucketOwner(): void;
    get expectedBucketOwnerInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _targetBucket?;
    get targetBucket(): string;
    set targetBucket(value: string);
    get targetBucketInput(): string | undefined;
    private _targetPrefix?;
    get targetPrefix(): string;
    set targetPrefix(value: string);
    get targetPrefixInput(): string | undefined;
    private _targetGrant;
    get targetGrant(): TfBucketLogging.TargetGrantPropertyList;
    putTargetGrant(value: TfBucketLogging.TargetGrantProperty[] | cdktn.IResolvable): void;
    resetTargetGrant(): void;
    get targetGrantInput(): cdktn.IResolvable | TfBucketLogging.TargetGrantProperty[] | undefined;
    private _targetObjectKeyFormat;
    get targetObjectKeyFormat(): TfBucketLogging.TargetObjectKeyFormatPropertyOutputReference;
    putTargetObjectKeyFormat(value: TfBucketLogging.TargetObjectKeyFormatProperty): void;
    resetTargetObjectKeyFormat(): void;
    get targetObjectKeyFormatInput(): TfBucketLogging.TargetObjectKeyFormatProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfBucketLoggingGranteePropertyToTerraform(struct?: TfBucketLogging.GranteePropertyOutputReference | TfBucketLogging.GranteeProperty): any;
export declare function tfBucketLoggingGranteePropertyToHclTerraform(struct?: TfBucketLogging.GranteePropertyOutputReference | TfBucketLogging.GranteeProperty): any;
export declare function tfBucketLoggingTargetGrantPropertyToTerraform(struct?: TfBucketLogging.TargetGrantProperty | cdktn.IResolvable): any;
export declare function tfBucketLoggingTargetGrantPropertyToHclTerraform(struct?: TfBucketLogging.TargetGrantProperty | cdktn.IResolvable): any;
export declare function tfBucketLoggingPartitionedPrefixPropertyToTerraform(struct?: TfBucketLogging.PartitionedPrefixPropertyOutputReference | TfBucketLogging.PartitionedPrefixProperty): any;
export declare function tfBucketLoggingPartitionedPrefixPropertyToHclTerraform(struct?: TfBucketLogging.PartitionedPrefixPropertyOutputReference | TfBucketLogging.PartitionedPrefixProperty): any;
export declare function tfBucketLoggingSimplePrefixPropertyToTerraform(struct?: TfBucketLogging.SimplePrefixPropertyOutputReference | TfBucketLogging.SimplePrefixProperty): any;
export declare function tfBucketLoggingSimplePrefixPropertyToHclTerraform(struct?: TfBucketLogging.SimplePrefixPropertyOutputReference | TfBucketLogging.SimplePrefixProperty): any;
export declare function tfBucketLoggingTargetObjectKeyFormatPropertyToTerraform(struct?: TfBucketLogging.TargetObjectKeyFormatPropertyOutputReference | TfBucketLogging.TargetObjectKeyFormatProperty): any;
export declare function tfBucketLoggingTargetObjectKeyFormatPropertyToHclTerraform(struct?: TfBucketLogging.TargetObjectKeyFormatPropertyOutputReference | TfBucketLogging.TargetObjectKeyFormatProperty): any;
export declare namespace TfBucketLogging {
    interface GranteeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_logging#email_address TfBucketLogging#email_address}
        */
        readonly emailAddress?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_logging#id TfBucketLogging#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_logging#type TfBucketLogging#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_logging#uri TfBucketLogging#uri}
        */
        readonly uri?: string;
    }
    class GranteePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): GranteeProperty | undefined;
        set internalValue(value: GranteeProperty | undefined);
        get displayName(): string;
        private _emailAddress?;
        get emailAddress(): string;
        set emailAddress(value: string);
        resetEmailAddress(): void;
        get emailAddressInput(): string | undefined;
        private _id?;
        get id(): string;
        set id(value: string);
        resetId(): void;
        get idInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _uri?;
        get uri(): string;
        set uri(value: string);
        resetUri(): void;
        get uriInput(): string | undefined;
    }
    interface TargetGrantProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_logging#permission TfBucketLogging#permission}
        */
        readonly permission: string;
        /**
        * grantee block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_logging#grantee TfBucketLogging#grantee}
        */
        readonly grantee: GranteeProperty;
    }
    class TargetGrantPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetGrantProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetGrantProperty | cdktn.IResolvable | undefined);
        private _permission?;
        get permission(): string;
        set permission(value: string);
        get permissionInput(): string | undefined;
        private _grantee;
        get grantee(): GranteePropertyOutputReference;
        putGrantee(value: GranteeProperty): void;
        get granteeInput(): GranteeProperty | undefined;
    }
    class TargetGrantPropertyList extends cdktn.ComplexList {
        internalValue?: TargetGrantProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetGrantPropertyOutputReference;
    }
    interface PartitionedPrefixProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_logging#partition_date_source TfBucketLogging#partition_date_source}
        */
        readonly partitionDateSource: string;
    }
    class PartitionedPrefixPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PartitionedPrefixProperty | undefined;
        set internalValue(value: PartitionedPrefixProperty | undefined);
        private _partitionDateSource?;
        get partitionDateSource(): string;
        set partitionDateSource(value: string);
        get partitionDateSourceInput(): string | undefined;
    }
    interface SimplePrefixProperty {
    }
    class SimplePrefixPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SimplePrefixProperty | undefined;
        set internalValue(value: SimplePrefixProperty | undefined);
    }
    interface TargetObjectKeyFormatProperty {
        /**
        * partitioned_prefix block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_logging#partitioned_prefix TfBucketLogging#partitioned_prefix}
        */
        readonly partitionedPrefix?: PartitionedPrefixProperty;
        /**
        * simple_prefix block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_logging#simple_prefix TfBucketLogging#simple_prefix}
        */
        readonly simplePrefix?: SimplePrefixProperty;
    }
    class TargetObjectKeyFormatPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TargetObjectKeyFormatProperty | undefined;
        set internalValue(value: TargetObjectKeyFormatProperty | undefined);
        private _partitionedPrefix;
        get partitionedPrefix(): PartitionedPrefixPropertyOutputReference;
        putPartitionedPrefix(value: PartitionedPrefixProperty): void;
        resetPartitionedPrefix(): void;
        get partitionedPrefixInput(): PartitionedPrefixProperty | undefined;
        private _simplePrefix;
        get simplePrefix(): SimplePrefixPropertyOutputReference;
        putSimplePrefix(value: SimplePrefixProperty): void;
        resetSimplePrefix(): void;
        get simplePrefixInput(): SimplePrefixProperty | undefined;
    }
}
