import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfBucketConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#acceleration_status TfBucket#acceleration_status}
    */
    readonly accelerationStatus?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#acl TfBucket#acl}
    */
    readonly acl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#bucket TfBucket#bucket}
    */
    readonly bucket?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#bucket_namespace TfBucket#bucket_namespace}
    */
    readonly bucketNamespace?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#bucket_prefix TfBucket#bucket_prefix}
    */
    readonly bucketPrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#force_destroy TfBucket#force_destroy}
    */
    readonly forceDestroy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#id TfBucket#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#object_lock_enabled TfBucket#object_lock_enabled}
    */
    readonly objectLockEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#policy TfBucket#policy}
    */
    readonly policy?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#region TfBucket#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#request_payer TfBucket#request_payer}
    */
    readonly requestPayer?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#tags TfBucket#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#tags_all TfBucket#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * cors_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#cors_rule TfBucket#cors_rule}
    */
    readonly corsRule?: TfBucket.CorsRuleProperty[] | cdktn.IResolvable;
    /**
    * grant block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#grant TfBucket#grant}
    */
    readonly grant?: TfBucket.GrantProperty[] | cdktn.IResolvable;
    /**
    * lifecycle_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#lifecycle_rule TfBucket#lifecycle_rule}
    */
    readonly lifecycleRule?: TfBucket.LifecycleRuleProperty[] | cdktn.IResolvable;
    /**
    * logging block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#logging TfBucket#logging}
    */
    readonly logging?: TfBucket.LoggingProperty;
    /**
    * object_lock_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#object_lock_configuration TfBucket#object_lock_configuration}
    */
    readonly objectLockConfiguration?: TfBucket.ObjectLockConfigurationProperty;
    /**
    * replication_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#replication_configuration TfBucket#replication_configuration}
    */
    readonly replicationConfiguration?: TfBucket.ReplicationConfigurationProperty;
    /**
    * server_side_encryption_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#server_side_encryption_configuration TfBucket#server_side_encryption_configuration}
    */
    readonly serverSideEncryptionConfiguration?: TfBucket.ServerSideEncryptionConfigurationProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#timeouts TfBucket#timeouts}
    */
    readonly timeouts?: TfBucket.TimeoutsProperty;
    /**
    * versioning block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#versioning TfBucket#versioning}
    */
    readonly versioning?: TfBucket.VersioningProperty;
    /**
    * website block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#website TfBucket#website}
    */
    readonly website?: TfBucket.WebsiteProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket aws_s3_bucket}
*/
export declare class TfBucket extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3_bucket";
    /**
    * Generates CDKTN code for importing a TfBucket resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfBucket to import
    * @param importFromId The id of the existing TfBucket that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfBucket to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket aws_s3_bucket} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfBucketConfig = {}
    */
    constructor(scope: Construct, id: string, config?: TfBucketConfig);
    private _accelerationStatus?;
    get accelerationStatus(): string;
    set accelerationStatus(value: string);
    resetAccelerationStatus(): void;
    get accelerationStatusInput(): string | undefined;
    private _acl?;
    get acl(): string;
    set acl(value: string);
    resetAcl(): void;
    get aclInput(): string | undefined;
    get arn(): string;
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    resetBucket(): void;
    get bucketInput(): string | undefined;
    get bucketDomainName(): string;
    private _bucketNamespace?;
    get bucketNamespace(): string;
    set bucketNamespace(value: string);
    resetBucketNamespace(): void;
    get bucketNamespaceInput(): string | undefined;
    private _bucketPrefix?;
    get bucketPrefix(): string;
    set bucketPrefix(value: string);
    resetBucketPrefix(): void;
    get bucketPrefixInput(): string | undefined;
    get bucketRegion(): string;
    get bucketRegionalDomainName(): string;
    private _forceDestroy?;
    get forceDestroy(): boolean | cdktn.IResolvable;
    set forceDestroy(value: boolean | cdktn.IResolvable);
    resetForceDestroy(): void;
    get forceDestroyInput(): boolean | cdktn.IResolvable | undefined;
    get hostedZoneId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _objectLockEnabled?;
    get objectLockEnabled(): boolean | cdktn.IResolvable;
    set objectLockEnabled(value: boolean | cdktn.IResolvable);
    resetObjectLockEnabled(): void;
    get objectLockEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _policy?;
    get policy(): string;
    set policy(value: string);
    resetPolicy(): void;
    get policyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _requestPayer?;
    get requestPayer(): string;
    set requestPayer(value: string);
    resetRequestPayer(): void;
    get requestPayerInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get websiteDomain(): string;
    get websiteEndpoint(): string;
    private _corsRule;
    get corsRule(): TfBucket.CorsRulePropertyList;
    putCorsRule(value: TfBucket.CorsRuleProperty[] | cdktn.IResolvable): void;
    resetCorsRule(): void;
    get corsRuleInput(): cdktn.IResolvable | TfBucket.CorsRuleProperty[] | undefined;
    private _grant;
    get grant(): TfBucket.GrantPropertyList;
    putGrant(value: TfBucket.GrantProperty[] | cdktn.IResolvable): void;
    resetGrant(): void;
    get grantInput(): cdktn.IResolvable | TfBucket.GrantProperty[] | undefined;
    private _lifecycleRule;
    get lifecycleRule(): TfBucket.LifecycleRulePropertyList;
    putLifecycleRule(value: TfBucket.LifecycleRuleProperty[] | cdktn.IResolvable): void;
    resetLifecycleRule(): void;
    get lifecycleRuleInput(): cdktn.IResolvable | TfBucket.LifecycleRuleProperty[] | undefined;
    private _logging;
    get logging(): TfBucket.LoggingPropertyOutputReference;
    putLogging(value: TfBucket.LoggingProperty): void;
    resetLogging(): void;
    get loggingInput(): TfBucket.LoggingProperty | undefined;
    private _objectLockConfiguration;
    get objectLockConfiguration(): TfBucket.ObjectLockConfigurationPropertyOutputReference;
    putObjectLockConfiguration(value: TfBucket.ObjectLockConfigurationProperty): void;
    resetObjectLockConfiguration(): void;
    get objectLockConfigurationInput(): TfBucket.ObjectLockConfigurationProperty | undefined;
    private _replicationConfiguration;
    get replicationConfiguration(): TfBucket.ReplicationConfigurationPropertyOutputReference;
    putReplicationConfiguration(value: TfBucket.ReplicationConfigurationProperty): void;
    resetReplicationConfiguration(): void;
    get replicationConfigurationInput(): TfBucket.ReplicationConfigurationProperty | undefined;
    private _serverSideEncryptionConfiguration;
    get serverSideEncryptionConfiguration(): TfBucket.ServerSideEncryptionConfigurationPropertyOutputReference;
    putServerSideEncryptionConfiguration(value: TfBucket.ServerSideEncryptionConfigurationProperty): void;
    resetServerSideEncryptionConfiguration(): void;
    get serverSideEncryptionConfigurationInput(): TfBucket.ServerSideEncryptionConfigurationProperty | undefined;
    private _timeouts;
    get timeouts(): TfBucket.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfBucket.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfBucket.TimeoutsProperty | undefined;
    private _versioning;
    get versioning(): TfBucket.VersioningPropertyOutputReference;
    putVersioning(value: TfBucket.VersioningProperty): void;
    resetVersioning(): void;
    get versioningInput(): TfBucket.VersioningProperty | undefined;
    private _website;
    get website(): TfBucket.WebsitePropertyOutputReference;
    putWebsite(value: TfBucket.WebsiteProperty): void;
    resetWebsite(): void;
    get websiteInput(): TfBucket.WebsiteProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfBucketMapperCorsRulePropertyToTerraform(struct?: TfBucket.CorsRuleProperty | cdktn.IResolvable): any;
export declare function tfBucketMapperCorsRulePropertyToHclTerraform(struct?: TfBucket.CorsRuleProperty | cdktn.IResolvable): any;
export declare function tfBucketMapperGrantPropertyToTerraform(struct?: TfBucket.GrantProperty | cdktn.IResolvable): any;
export declare function tfBucketMapperGrantPropertyToHclTerraform(struct?: TfBucket.GrantProperty | cdktn.IResolvable): any;
export declare function tfBucketMapperExpirationPropertyToTerraform(struct?: TfBucket.ExpirationPropertyOutputReference | TfBucket.ExpirationProperty): any;
export declare function tfBucketMapperExpirationPropertyToHclTerraform(struct?: TfBucket.ExpirationPropertyOutputReference | TfBucket.ExpirationProperty): any;
export declare function tfBucketMapperNoncurrentVersionExpirationPropertyToTerraform(struct?: TfBucket.NoncurrentVersionExpirationPropertyOutputReference | TfBucket.NoncurrentVersionExpirationProperty): any;
export declare function tfBucketMapperNoncurrentVersionExpirationPropertyToHclTerraform(struct?: TfBucket.NoncurrentVersionExpirationPropertyOutputReference | TfBucket.NoncurrentVersionExpirationProperty): any;
export declare function tfBucketMapperNoncurrentVersionTransitionPropertyToTerraform(struct?: TfBucket.NoncurrentVersionTransitionProperty | cdktn.IResolvable): any;
export declare function tfBucketMapperNoncurrentVersionTransitionPropertyToHclTerraform(struct?: TfBucket.NoncurrentVersionTransitionProperty | cdktn.IResolvable): any;
export declare function tfBucketMapperTransitionPropertyToTerraform(struct?: TfBucket.TransitionProperty | cdktn.IResolvable): any;
export declare function tfBucketMapperTransitionPropertyToHclTerraform(struct?: TfBucket.TransitionProperty | cdktn.IResolvable): any;
export declare function tfBucketMapperLifecycleRulePropertyToTerraform(struct?: TfBucket.LifecycleRuleProperty | cdktn.IResolvable): any;
export declare function tfBucketMapperLifecycleRulePropertyToHclTerraform(struct?: TfBucket.LifecycleRuleProperty | cdktn.IResolvable): any;
export declare function tfBucketMapperLoggingPropertyToTerraform(struct?: TfBucket.LoggingPropertyOutputReference | TfBucket.LoggingProperty): any;
export declare function tfBucketMapperLoggingPropertyToHclTerraform(struct?: TfBucket.LoggingPropertyOutputReference | TfBucket.LoggingProperty): any;
export declare function tfBucketMapperDefaultRetentionPropertyToTerraform(struct?: TfBucket.DefaultRetentionPropertyOutputReference | TfBucket.DefaultRetentionProperty): any;
export declare function tfBucketMapperDefaultRetentionPropertyToHclTerraform(struct?: TfBucket.DefaultRetentionPropertyOutputReference | TfBucket.DefaultRetentionProperty): any;
export declare function tfBucketMapperObjectLockConfigurationRulePropertyToTerraform(struct?: TfBucket.ObjectLockConfigurationRulePropertyOutputReference | TfBucket.ObjectLockConfigurationRuleProperty): any;
export declare function tfBucketMapperObjectLockConfigurationRulePropertyToHclTerraform(struct?: TfBucket.ObjectLockConfigurationRulePropertyOutputReference | TfBucket.ObjectLockConfigurationRuleProperty): any;
export declare function tfBucketMapperObjectLockConfigurationPropertyToTerraform(struct?: TfBucket.ObjectLockConfigurationPropertyOutputReference | TfBucket.ObjectLockConfigurationProperty): any;
export declare function tfBucketMapperObjectLockConfigurationPropertyToHclTerraform(struct?: TfBucket.ObjectLockConfigurationPropertyOutputReference | TfBucket.ObjectLockConfigurationProperty): any;
export declare function tfBucketMapperAccessControlTranslationPropertyToTerraform(struct?: TfBucket.AccessControlTranslationPropertyOutputReference | TfBucket.AccessControlTranslationProperty): any;
export declare function tfBucketMapperAccessControlTranslationPropertyToHclTerraform(struct?: TfBucket.AccessControlTranslationPropertyOutputReference | TfBucket.AccessControlTranslationProperty): any;
export declare function tfBucketMapperMetricsPropertyToTerraform(struct?: TfBucket.MetricsPropertyOutputReference | TfBucket.MetricsProperty): any;
export declare function tfBucketMapperMetricsPropertyToHclTerraform(struct?: TfBucket.MetricsPropertyOutputReference | TfBucket.MetricsProperty): any;
export declare function tfBucketMapperReplicationTimePropertyToTerraform(struct?: TfBucket.ReplicationTimePropertyOutputReference | TfBucket.ReplicationTimeProperty): any;
export declare function tfBucketMapperReplicationTimePropertyToHclTerraform(struct?: TfBucket.ReplicationTimePropertyOutputReference | TfBucket.ReplicationTimeProperty): any;
export declare function tfBucketMapperDestinationPropertyToTerraform(struct?: TfBucket.DestinationPropertyOutputReference | TfBucket.DestinationProperty): any;
export declare function tfBucketMapperDestinationPropertyToHclTerraform(struct?: TfBucket.DestinationPropertyOutputReference | TfBucket.DestinationProperty): any;
export declare function tfBucketMapperFilterPropertyToTerraform(struct?: TfBucket.FilterPropertyOutputReference | TfBucket.FilterProperty): any;
export declare function tfBucketMapperFilterPropertyToHclTerraform(struct?: TfBucket.FilterPropertyOutputReference | TfBucket.FilterProperty): any;
export declare function tfBucketMapperSseKmsEncryptedObjectsPropertyToTerraform(struct?: TfBucket.SseKmsEncryptedObjectsPropertyOutputReference | TfBucket.SseKmsEncryptedObjectsProperty): any;
export declare function tfBucketMapperSseKmsEncryptedObjectsPropertyToHclTerraform(struct?: TfBucket.SseKmsEncryptedObjectsPropertyOutputReference | TfBucket.SseKmsEncryptedObjectsProperty): any;
export declare function tfBucketMapperSourceSelectionCriteriaPropertyToTerraform(struct?: TfBucket.SourceSelectionCriteriaPropertyOutputReference | TfBucket.SourceSelectionCriteriaProperty): any;
export declare function tfBucketMapperSourceSelectionCriteriaPropertyToHclTerraform(struct?: TfBucket.SourceSelectionCriteriaPropertyOutputReference | TfBucket.SourceSelectionCriteriaProperty): any;
export declare function tfBucketMapperRulesPropertyToTerraform(struct?: TfBucket.RulesProperty | cdktn.IResolvable): any;
export declare function tfBucketMapperRulesPropertyToHclTerraform(struct?: TfBucket.RulesProperty | cdktn.IResolvable): any;
export declare function tfBucketMapperReplicationConfigurationPropertyToTerraform(struct?: TfBucket.ReplicationConfigurationPropertyOutputReference | TfBucket.ReplicationConfigurationProperty): any;
export declare function tfBucketMapperReplicationConfigurationPropertyToHclTerraform(struct?: TfBucket.ReplicationConfigurationPropertyOutputReference | TfBucket.ReplicationConfigurationProperty): any;
export declare function tfBucketMapperApplyServerSideEncryptionByDefaultPropertyToTerraform(struct?: TfBucket.ApplyServerSideEncryptionByDefaultPropertyOutputReference | TfBucket.ApplyServerSideEncryptionByDefaultProperty): any;
export declare function tfBucketMapperApplyServerSideEncryptionByDefaultPropertyToHclTerraform(struct?: TfBucket.ApplyServerSideEncryptionByDefaultPropertyOutputReference | TfBucket.ApplyServerSideEncryptionByDefaultProperty): any;
export declare function tfBucketMapperServerSideEncryptionConfigurationRulePropertyToTerraform(struct?: TfBucket.ServerSideEncryptionConfigurationRulePropertyOutputReference | TfBucket.ServerSideEncryptionConfigurationRuleProperty): any;
export declare function tfBucketMapperServerSideEncryptionConfigurationRulePropertyToHclTerraform(struct?: TfBucket.ServerSideEncryptionConfigurationRulePropertyOutputReference | TfBucket.ServerSideEncryptionConfigurationRuleProperty): any;
export declare function tfBucketMapperServerSideEncryptionConfigurationPropertyToTerraform(struct?: TfBucket.ServerSideEncryptionConfigurationPropertyOutputReference | TfBucket.ServerSideEncryptionConfigurationProperty): any;
export declare function tfBucketMapperServerSideEncryptionConfigurationPropertyToHclTerraform(struct?: TfBucket.ServerSideEncryptionConfigurationPropertyOutputReference | TfBucket.ServerSideEncryptionConfigurationProperty): any;
export declare function tfBucketMapperTimeoutsPropertyToTerraform(struct?: TfBucket.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfBucketMapperTimeoutsPropertyToHclTerraform(struct?: TfBucket.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfBucketMapperVersioningPropertyToTerraform(struct?: TfBucket.VersioningPropertyOutputReference | TfBucket.VersioningProperty): any;
export declare function tfBucketMapperVersioningPropertyToHclTerraform(struct?: TfBucket.VersioningPropertyOutputReference | TfBucket.VersioningProperty): any;
export declare function tfBucketMapperWebsitePropertyToTerraform(struct?: TfBucket.WebsitePropertyOutputReference | TfBucket.WebsiteProperty): any;
export declare function tfBucketMapperWebsitePropertyToHclTerraform(struct?: TfBucket.WebsitePropertyOutputReference | TfBucket.WebsiteProperty): any;
export declare namespace TfBucket {
    interface CorsRuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#allowed_headers TfBucket#allowed_headers}
        */
        readonly allowedHeaders?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#allowed_methods TfBucket#allowed_methods}
        */
        readonly allowedMethods: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#allowed_origins TfBucket#allowed_origins}
        */
        readonly allowedOrigins: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#expose_headers TfBucket#expose_headers}
        */
        readonly exposeHeaders?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#max_age_seconds TfBucket#max_age_seconds}
        */
        readonly maxAgeSeconds?: number;
    }
    class CorsRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CorsRuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CorsRuleProperty | cdktn.IResolvable | undefined);
        private _allowedHeaders?;
        get allowedHeaders(): string[];
        set allowedHeaders(value: string[]);
        resetAllowedHeaders(): void;
        get allowedHeadersInput(): string[] | undefined;
        private _allowedMethods?;
        get allowedMethods(): string[];
        set allowedMethods(value: string[]);
        get allowedMethodsInput(): string[] | undefined;
        private _allowedOrigins?;
        get allowedOrigins(): string[];
        set allowedOrigins(value: string[]);
        get allowedOriginsInput(): string[] | undefined;
        private _exposeHeaders?;
        get exposeHeaders(): string[];
        set exposeHeaders(value: string[]);
        resetExposeHeaders(): void;
        get exposeHeadersInput(): string[] | undefined;
        private _maxAgeSeconds?;
        get maxAgeSeconds(): number;
        set maxAgeSeconds(value: number);
        resetMaxAgeSeconds(): void;
        get maxAgeSecondsInput(): number | undefined;
    }
    class CorsRulePropertyList extends cdktn.ComplexList {
        internalValue?: CorsRuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CorsRulePropertyOutputReference;
    }
    interface GrantProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#id TfBucket#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#permissions TfBucket#permissions}
        */
        readonly permissions: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#type TfBucket#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#uri TfBucket#uri}
        */
        readonly uri?: string;
    }
    class GrantPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GrantProperty | cdktn.IResolvable | undefined;
        set internalValue(value: GrantProperty | cdktn.IResolvable | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        resetId(): void;
        get idInput(): string | undefined;
        private _permissions?;
        get permissions(): string[];
        set permissions(value: string[]);
        get permissionsInput(): string[] | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _uri?;
        get uri(): string;
        set uri(value: string);
        resetUri(): void;
        get uriInput(): string | undefined;
    }
    class GrantPropertyList extends cdktn.ComplexList {
        internalValue?: GrantProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GrantPropertyOutputReference;
    }
    interface ExpirationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#date TfBucket#date}
        */
        readonly date?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#days TfBucket#days}
        */
        readonly days?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#expired_object_delete_marker TfBucket#expired_object_delete_marker}
        */
        readonly expiredObjectDeleteMarker?: boolean | cdktn.IResolvable;
    }
    class ExpirationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ExpirationProperty | undefined;
        set internalValue(value: ExpirationProperty | undefined);
        private _date?;
        get date(): string;
        set date(value: string);
        resetDate(): void;
        get dateInput(): string | undefined;
        private _days?;
        get days(): number;
        set days(value: number);
        resetDays(): void;
        get daysInput(): number | undefined;
        private _expiredObjectDeleteMarker?;
        get expiredObjectDeleteMarker(): boolean | cdktn.IResolvable;
        set expiredObjectDeleteMarker(value: boolean | cdktn.IResolvable);
        resetExpiredObjectDeleteMarker(): void;
        get expiredObjectDeleteMarkerInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface NoncurrentVersionExpirationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#days TfBucket#days}
        */
        readonly days?: number;
    }
    class NoncurrentVersionExpirationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NoncurrentVersionExpirationProperty | undefined;
        set internalValue(value: NoncurrentVersionExpirationProperty | undefined);
        private _days?;
        get days(): number;
        set days(value: number);
        resetDays(): void;
        get daysInput(): number | undefined;
    }
    interface NoncurrentVersionTransitionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#days TfBucket#days}
        */
        readonly days?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#storage_class TfBucket#storage_class}
        */
        readonly storageClass: string;
    }
    class NoncurrentVersionTransitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NoncurrentVersionTransitionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NoncurrentVersionTransitionProperty | cdktn.IResolvable | undefined);
        private _days?;
        get days(): number;
        set days(value: number);
        resetDays(): void;
        get daysInput(): number | undefined;
        private _storageClass?;
        get storageClass(): string;
        set storageClass(value: string);
        get storageClassInput(): string | undefined;
    }
    class NoncurrentVersionTransitionPropertyList extends cdktn.ComplexList {
        internalValue?: NoncurrentVersionTransitionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NoncurrentVersionTransitionPropertyOutputReference;
    }
    interface TransitionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#date TfBucket#date}
        */
        readonly date?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#days TfBucket#days}
        */
        readonly days?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#storage_class TfBucket#storage_class}
        */
        readonly storageClass: string;
    }
    class TransitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TransitionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TransitionProperty | cdktn.IResolvable | undefined);
        private _date?;
        get date(): string;
        set date(value: string);
        resetDate(): void;
        get dateInput(): string | undefined;
        private _days?;
        get days(): number;
        set days(value: number);
        resetDays(): void;
        get daysInput(): number | undefined;
        private _storageClass?;
        get storageClass(): string;
        set storageClass(value: string);
        get storageClassInput(): string | undefined;
    }
    class TransitionPropertyList extends cdktn.ComplexList {
        internalValue?: TransitionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TransitionPropertyOutputReference;
    }
    interface LifecycleRuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#abort_incomplete_multipart_upload_days TfBucket#abort_incomplete_multipart_upload_days}
        */
        readonly abortIncompleteMultipartUploadDays?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#enabled TfBucket#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#id TfBucket#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#prefix TfBucket#prefix}
        */
        readonly prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#tags TfBucket#tags}
        */
        readonly tags?: {
            [key: string]: string;
        };
        /**
        * expiration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#expiration TfBucket#expiration}
        */
        readonly expiration?: ExpirationProperty;
        /**
        * noncurrent_version_expiration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#noncurrent_version_expiration TfBucket#noncurrent_version_expiration}
        */
        readonly noncurrentVersionExpiration?: NoncurrentVersionExpirationProperty;
        /**
        * noncurrent_version_transition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#noncurrent_version_transition TfBucket#noncurrent_version_transition}
        */
        readonly noncurrentVersionTransition?: NoncurrentVersionTransitionProperty[] | cdktn.IResolvable;
        /**
        * transition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#transition TfBucket#transition}
        */
        readonly transition?: TransitionProperty[] | cdktn.IResolvable;
    }
    class LifecycleRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LifecycleRuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LifecycleRuleProperty | cdktn.IResolvable | undefined);
        private _abortIncompleteMultipartUploadDays?;
        get abortIncompleteMultipartUploadDays(): number;
        set abortIncompleteMultipartUploadDays(value: number);
        resetAbortIncompleteMultipartUploadDays(): void;
        get abortIncompleteMultipartUploadDaysInput(): number | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _id?;
        get id(): string;
        set id(value: string);
        resetId(): void;
        get idInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _tags?;
        get tags(): {
            [key: string]: string;
        };
        set tags(value: {
            [key: string]: string;
        });
        resetTags(): void;
        get tagsInput(): {
            [key: string]: string;
        } | undefined;
        private _expiration;
        get expiration(): ExpirationPropertyOutputReference;
        putExpiration(value: ExpirationProperty): void;
        resetExpiration(): void;
        get expirationInput(): ExpirationProperty | undefined;
        private _noncurrentVersionExpiration;
        get noncurrentVersionExpiration(): NoncurrentVersionExpirationPropertyOutputReference;
        putNoncurrentVersionExpiration(value: NoncurrentVersionExpirationProperty): void;
        resetNoncurrentVersionExpiration(): void;
        get noncurrentVersionExpirationInput(): NoncurrentVersionExpirationProperty | undefined;
        private _noncurrentVersionTransition;
        get noncurrentVersionTransition(): NoncurrentVersionTransitionPropertyList;
        putNoncurrentVersionTransition(value: NoncurrentVersionTransitionProperty[] | cdktn.IResolvable): void;
        resetNoncurrentVersionTransition(): void;
        get noncurrentVersionTransitionInput(): cdktn.IResolvable | NoncurrentVersionTransitionProperty[] | undefined;
        private _transition;
        get transition(): TransitionPropertyList;
        putTransition(value: TransitionProperty[] | cdktn.IResolvable): void;
        resetTransition(): void;
        get transitionInput(): cdktn.IResolvable | TransitionProperty[] | undefined;
    }
    class LifecycleRulePropertyList extends cdktn.ComplexList {
        internalValue?: LifecycleRuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LifecycleRulePropertyOutputReference;
    }
    interface LoggingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#target_bucket TfBucket#target_bucket}
        */
        readonly targetBucket: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#target_prefix TfBucket#target_prefix}
        */
        readonly targetPrefix?: string;
    }
    class LoggingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LoggingProperty | undefined;
        set internalValue(value: LoggingProperty | undefined);
        private _targetBucket?;
        get targetBucket(): string;
        set targetBucket(value: string);
        get targetBucketInput(): string | undefined;
        private _targetPrefix?;
        get targetPrefix(): string;
        set targetPrefix(value: string);
        resetTargetPrefix(): void;
        get targetPrefixInput(): string | undefined;
    }
    interface DefaultRetentionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#days TfBucket#days}
        */
        readonly days?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#mode TfBucket#mode}
        */
        readonly mode: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#years TfBucket#years}
        */
        readonly years?: number;
    }
    class DefaultRetentionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultRetentionProperty | undefined;
        set internalValue(value: DefaultRetentionProperty | undefined);
        private _days?;
        get days(): number;
        set days(value: number);
        resetDays(): void;
        get daysInput(): number | undefined;
        private _mode?;
        get mode(): string;
        set mode(value: string);
        get modeInput(): string | undefined;
        private _years?;
        get years(): number;
        set years(value: number);
        resetYears(): void;
        get yearsInput(): number | undefined;
    }
    interface ObjectLockConfigurationRuleProperty {
        /**
        * default_retention block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#default_retention TfBucket#default_retention}
        */
        readonly defaultRetention: DefaultRetentionProperty;
    }
    class ObjectLockConfigurationRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ObjectLockConfigurationRuleProperty | undefined;
        set internalValue(value: ObjectLockConfigurationRuleProperty | undefined);
        private _defaultRetention;
        get defaultRetention(): DefaultRetentionPropertyOutputReference;
        putDefaultRetention(value: DefaultRetentionProperty): void;
        get defaultRetentionInput(): DefaultRetentionProperty | undefined;
    }
    interface ObjectLockConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#object_lock_enabled TfBucket#object_lock_enabled}
        */
        readonly objectLockEnabled?: string;
        /**
        * rule block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#rule TfBucket#rule}
        */
        readonly rule?: ObjectLockConfigurationRuleProperty;
    }
    class ObjectLockConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ObjectLockConfigurationProperty | undefined;
        set internalValue(value: ObjectLockConfigurationProperty | undefined);
        private _objectLockEnabled?;
        get objectLockEnabled(): string;
        set objectLockEnabled(value: string);
        resetObjectLockEnabled(): void;
        get objectLockEnabledInput(): string | undefined;
        private _rule;
        get rule(): ObjectLockConfigurationRulePropertyOutputReference;
        putRule(value: ObjectLockConfigurationRuleProperty): void;
        resetRule(): void;
        get ruleInput(): ObjectLockConfigurationRuleProperty | undefined;
    }
    interface AccessControlTranslationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#owner TfBucket#owner}
        */
        readonly owner: string;
    }
    class AccessControlTranslationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AccessControlTranslationProperty | undefined;
        set internalValue(value: AccessControlTranslationProperty | undefined);
        private _owner?;
        get owner(): string;
        set owner(value: string);
        get ownerInput(): string | undefined;
    }
    interface MetricsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#minutes TfBucket#minutes}
        */
        readonly minutes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#status TfBucket#status}
        */
        readonly status?: string;
    }
    class MetricsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MetricsProperty | undefined;
        set internalValue(value: MetricsProperty | undefined);
        private _minutes?;
        get minutes(): number;
        set minutes(value: number);
        resetMinutes(): void;
        get minutesInput(): number | undefined;
        private _status?;
        get status(): string;
        set status(value: string);
        resetStatus(): void;
        get statusInput(): string | undefined;
    }
    interface ReplicationTimeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#minutes TfBucket#minutes}
        */
        readonly minutes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#status TfBucket#status}
        */
        readonly status?: string;
    }
    class ReplicationTimePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ReplicationTimeProperty | undefined;
        set internalValue(value: ReplicationTimeProperty | undefined);
        private _minutes?;
        get minutes(): number;
        set minutes(value: number);
        resetMinutes(): void;
        get minutesInput(): number | undefined;
        private _status?;
        get status(): string;
        set status(value: string);
        resetStatus(): void;
        get statusInput(): string | undefined;
    }
    interface DestinationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#account_id TfBucket#account_id}
        */
        readonly accountId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#bucket TfBucket#bucket}
        */
        readonly bucket: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#replica_kms_key_id TfBucket#replica_kms_key_id}
        */
        readonly replicaKmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#storage_class TfBucket#storage_class}
        */
        readonly storageClass?: string;
        /**
        * access_control_translation block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#access_control_translation TfBucket#access_control_translation}
        */
        readonly accessControlTranslation?: AccessControlTranslationProperty;
        /**
        * metrics block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#metrics TfBucket#metrics}
        */
        readonly metrics?: MetricsProperty;
        /**
        * replication_time block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#replication_time TfBucket#replication_time}
        */
        readonly replicationTime?: ReplicationTimeProperty;
    }
    class DestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationProperty | undefined;
        set internalValue(value: DestinationProperty | undefined);
        private _accountId?;
        get accountId(): string;
        set accountId(value: string);
        resetAccountId(): void;
        get accountIdInput(): string | undefined;
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        get bucketInput(): string | undefined;
        private _replicaKmsKeyId?;
        get replicaKmsKeyId(): string;
        set replicaKmsKeyId(value: string);
        resetReplicaKmsKeyId(): void;
        get replicaKmsKeyIdInput(): string | undefined;
        private _storageClass?;
        get storageClass(): string;
        set storageClass(value: string);
        resetStorageClass(): void;
        get storageClassInput(): string | undefined;
        private _accessControlTranslation;
        get accessControlTranslation(): AccessControlTranslationPropertyOutputReference;
        putAccessControlTranslation(value: AccessControlTranslationProperty): void;
        resetAccessControlTranslation(): void;
        get accessControlTranslationInput(): AccessControlTranslationProperty | undefined;
        private _metrics;
        get metrics(): MetricsPropertyOutputReference;
        putMetrics(value: MetricsProperty): void;
        resetMetrics(): void;
        get metricsInput(): MetricsProperty | undefined;
        private _replicationTime;
        get replicationTime(): ReplicationTimePropertyOutputReference;
        putReplicationTime(value: ReplicationTimeProperty): void;
        resetReplicationTime(): void;
        get replicationTimeInput(): ReplicationTimeProperty | undefined;
    }
    interface FilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#prefix TfBucket#prefix}
        */
        readonly prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#tags TfBucket#tags}
        */
        readonly tags?: {
            [key: string]: string;
        };
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterProperty | undefined;
        set internalValue(value: FilterProperty | undefined);
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _tags?;
        get tags(): {
            [key: string]: string;
        };
        set tags(value: {
            [key: string]: string;
        });
        resetTags(): void;
        get tagsInput(): {
            [key: string]: string;
        } | undefined;
    }
    interface SseKmsEncryptedObjectsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#enabled TfBucket#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
    }
    class SseKmsEncryptedObjectsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SseKmsEncryptedObjectsProperty | undefined;
        set internalValue(value: SseKmsEncryptedObjectsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface SourceSelectionCriteriaProperty {
        /**
        * sse_kms_encrypted_objects block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#sse_kms_encrypted_objects TfBucket#sse_kms_encrypted_objects}
        */
        readonly sseKmsEncryptedObjects?: SseKmsEncryptedObjectsProperty;
    }
    class SourceSelectionCriteriaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceSelectionCriteriaProperty | undefined;
        set internalValue(value: SourceSelectionCriteriaProperty | undefined);
        private _sseKmsEncryptedObjects;
        get sseKmsEncryptedObjects(): SseKmsEncryptedObjectsPropertyOutputReference;
        putSseKmsEncryptedObjects(value: SseKmsEncryptedObjectsProperty): void;
        resetSseKmsEncryptedObjects(): void;
        get sseKmsEncryptedObjectsInput(): SseKmsEncryptedObjectsProperty | undefined;
    }
    interface RulesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#delete_marker_replication_status TfBucket#delete_marker_replication_status}
        */
        readonly deleteMarkerReplicationStatus?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#id TfBucket#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#prefix TfBucket#prefix}
        */
        readonly prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#priority TfBucket#priority}
        */
        readonly priority?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#status TfBucket#status}
        */
        readonly status: string;
        /**
        * destination block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#destination TfBucket#destination}
        */
        readonly destination: DestinationProperty;
        /**
        * filter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#filter TfBucket#filter}
        */
        readonly filter?: FilterProperty;
        /**
        * source_selection_criteria block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#source_selection_criteria TfBucket#source_selection_criteria}
        */
        readonly sourceSelectionCriteria?: SourceSelectionCriteriaProperty;
    }
    class RulesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RulesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RulesProperty | cdktn.IResolvable | undefined);
        private _deleteMarkerReplicationStatus?;
        get deleteMarkerReplicationStatus(): string;
        set deleteMarkerReplicationStatus(value: string);
        resetDeleteMarkerReplicationStatus(): void;
        get deleteMarkerReplicationStatusInput(): string | undefined;
        private _id?;
        get id(): string;
        set id(value: string);
        resetId(): void;
        get idInput(): string | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _priority?;
        get priority(): number;
        set priority(value: number);
        resetPriority(): void;
        get priorityInput(): number | undefined;
        private _status?;
        get status(): string;
        set status(value: string);
        get statusInput(): string | undefined;
        private _destination;
        get destination(): DestinationPropertyOutputReference;
        putDestination(value: DestinationProperty): void;
        get destinationInput(): DestinationProperty | undefined;
        private _filter;
        get filter(): FilterPropertyOutputReference;
        putFilter(value: FilterProperty): void;
        resetFilter(): void;
        get filterInput(): FilterProperty | undefined;
        private _sourceSelectionCriteria;
        get sourceSelectionCriteria(): SourceSelectionCriteriaPropertyOutputReference;
        putSourceSelectionCriteria(value: SourceSelectionCriteriaProperty): void;
        resetSourceSelectionCriteria(): void;
        get sourceSelectionCriteriaInput(): SourceSelectionCriteriaProperty | undefined;
    }
    class RulesPropertyList extends cdktn.ComplexList {
        internalValue?: RulesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulesPropertyOutputReference;
    }
    interface ReplicationConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#role TfBucket#role}
        */
        readonly role: string;
        /**
        * rules block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#rules TfBucket#rules}
        */
        readonly rules: RulesProperty[] | cdktn.IResolvable;
    }
    class ReplicationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ReplicationConfigurationProperty | undefined;
        set internalValue(value: ReplicationConfigurationProperty | undefined);
        private _role?;
        get role(): string;
        set role(value: string);
        get roleInput(): string | undefined;
        private _rules;
        get rules(): RulesPropertyList;
        putRules(value: RulesProperty[] | cdktn.IResolvable): void;
        get rulesInput(): cdktn.IResolvable | RulesProperty[] | undefined;
    }
    interface ApplyServerSideEncryptionByDefaultProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#kms_master_key_id TfBucket#kms_master_key_id}
        */
        readonly kmsMasterKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#sse_algorithm TfBucket#sse_algorithm}
        */
        readonly sseAlgorithm: string;
    }
    class ApplyServerSideEncryptionByDefaultPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ApplyServerSideEncryptionByDefaultProperty | undefined;
        set internalValue(value: ApplyServerSideEncryptionByDefaultProperty | undefined);
        private _kmsMasterKeyId?;
        get kmsMasterKeyId(): string;
        set kmsMasterKeyId(value: string);
        resetKmsMasterKeyId(): void;
        get kmsMasterKeyIdInput(): string | undefined;
        private _sseAlgorithm?;
        get sseAlgorithm(): string;
        set sseAlgorithm(value: string);
        get sseAlgorithmInput(): string | undefined;
    }
    interface ServerSideEncryptionConfigurationRuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#bucket_key_enabled TfBucket#bucket_key_enabled}
        */
        readonly bucketKeyEnabled?: boolean | cdktn.IResolvable;
        /**
        * apply_server_side_encryption_by_default block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#apply_server_side_encryption_by_default TfBucket#apply_server_side_encryption_by_default}
        */
        readonly applyServerSideEncryptionByDefault: ApplyServerSideEncryptionByDefaultProperty;
    }
    class ServerSideEncryptionConfigurationRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ServerSideEncryptionConfigurationRuleProperty | undefined;
        set internalValue(value: ServerSideEncryptionConfigurationRuleProperty | undefined);
        private _bucketKeyEnabled?;
        get bucketKeyEnabled(): boolean | cdktn.IResolvable;
        set bucketKeyEnabled(value: boolean | cdktn.IResolvable);
        resetBucketKeyEnabled(): void;
        get bucketKeyEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _applyServerSideEncryptionByDefault;
        get applyServerSideEncryptionByDefault(): ApplyServerSideEncryptionByDefaultPropertyOutputReference;
        putApplyServerSideEncryptionByDefault(value: ApplyServerSideEncryptionByDefaultProperty): void;
        get applyServerSideEncryptionByDefaultInput(): ApplyServerSideEncryptionByDefaultProperty | undefined;
    }
    interface ServerSideEncryptionConfigurationProperty {
        /**
        * rule block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#rule TfBucket#rule}
        */
        readonly rule: ServerSideEncryptionConfigurationRuleProperty;
    }
    class ServerSideEncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ServerSideEncryptionConfigurationProperty | undefined;
        set internalValue(value: ServerSideEncryptionConfigurationProperty | undefined);
        private _rule;
        get rule(): ServerSideEncryptionConfigurationRulePropertyOutputReference;
        putRule(value: ServerSideEncryptionConfigurationRuleProperty): void;
        get ruleInput(): ServerSideEncryptionConfigurationRuleProperty | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#create TfBucket#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#delete TfBucket#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#read TfBucket#read}
        */
        readonly read?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#update TfBucket#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _read?;
        get read(): string;
        set read(value: string);
        resetRead(): void;
        get readInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface VersioningProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#enabled TfBucket#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#mfa_delete TfBucket#mfa_delete}
        */
        readonly mfaDelete?: boolean | cdktn.IResolvable;
    }
    class VersioningPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VersioningProperty | undefined;
        set internalValue(value: VersioningProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _mfaDelete?;
        get mfaDelete(): boolean | cdktn.IResolvable;
        set mfaDelete(value: boolean | cdktn.IResolvable);
        resetMfaDelete(): void;
        get mfaDeleteInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface WebsiteProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#error_document TfBucket#error_document}
        */
        readonly errorDocument?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#index_document TfBucket#index_document}
        */
        readonly indexDocument?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#redirect_all_requests_to TfBucket#redirect_all_requests_to}
        */
        readonly redirectAllRequestsTo?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket#routing_rules TfBucket#routing_rules}
        */
        readonly routingRules?: string;
    }
    class WebsitePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): WebsiteProperty | undefined;
        set internalValue(value: WebsiteProperty | undefined);
        private _errorDocument?;
        get errorDocument(): string;
        set errorDocument(value: string);
        resetErrorDocument(): void;
        get errorDocumentInput(): string | undefined;
        private _indexDocument?;
        get indexDocument(): string;
        set indexDocument(value: string);
        resetIndexDocument(): void;
        get indexDocumentInput(): string | undefined;
        private _redirectAllRequestsTo?;
        get redirectAllRequestsTo(): string;
        set redirectAllRequestsTo(value: string);
        resetRedirectAllRequestsTo(): void;
        get redirectAllRequestsToInput(): string | undefined;
        private _routingRules?;
        get routingRules(): string;
        set routingRules(value: string);
        resetRoutingRules(): void;
        get routingRulesInput(): string | undefined;
    }
}
