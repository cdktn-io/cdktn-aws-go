import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfBucketNotificationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3_bucket_notification#bucket DataTfBucketNotification#bucket}
    */
    readonly bucket: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3_bucket_notification#region DataTfBucketNotification#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3_bucket_notification aws_s3_bucket_notification}
*/
export declare class DataTfBucketNotification extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_s3_bucket_notification";
    /**
    * Generates CDKTN code for importing a DataTfBucketNotification resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfBucketNotification to import
    * @param importFromId The id of the existing DataTfBucketNotification that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3_bucket_notification#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfBucketNotification to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/s3_bucket_notification aws_s3_bucket_notification} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfBucketNotificationConfig
    */
    constructor(scope: Construct, id: string, config: DataTfBucketNotificationConfig);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    get eventbridge(): cdktn.IResolvable;
    private _lambdaFunction;
    get lambdaFunction(): DataTfBucketNotification.LambdaFunctionPropertyList;
    private _queue;
    get queue(): DataTfBucketNotification.QueuePropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _topic;
    get topic(): DataTfBucketNotification.TopicPropertyList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfBucketNotificationLambdaFunctionPropertyToTerraform(struct?: DataTfBucketNotification.LambdaFunctionProperty): any;
export declare function dataTfBucketNotificationLambdaFunctionPropertyToHclTerraform(struct?: DataTfBucketNotification.LambdaFunctionProperty): any;
export declare function dataTfBucketNotificationQueuePropertyToTerraform(struct?: DataTfBucketNotification.QueueProperty): any;
export declare function dataTfBucketNotificationQueuePropertyToHclTerraform(struct?: DataTfBucketNotification.QueueProperty): any;
export declare function dataTfBucketNotificationTopicPropertyToTerraform(struct?: DataTfBucketNotification.TopicProperty): any;
export declare function dataTfBucketNotificationTopicPropertyToHclTerraform(struct?: DataTfBucketNotification.TopicProperty): any;
export declare namespace DataTfBucketNotification {
    interface LambdaFunctionProperty {
    }
    class LambdaFunctionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LambdaFunctionProperty | undefined;
        set internalValue(value: LambdaFunctionProperty | undefined);
        get events(): string[];
        get filterPrefix(): string;
        get filterSuffix(): string;
        get id(): string;
        get lambdaFunctionArn(): string;
    }
    class LambdaFunctionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LambdaFunctionPropertyOutputReference;
    }
    interface QueueProperty {
    }
    class QueuePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): QueueProperty | undefined;
        set internalValue(value: QueueProperty | undefined);
        get events(): string[];
        get filterPrefix(): string;
        get filterSuffix(): string;
        get id(): string;
        get queueArn(): string;
    }
    class QueuePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): QueuePropertyOutputReference;
    }
    interface TopicProperty {
    }
    class TopicPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TopicProperty | undefined;
        set internalValue(value: TopicProperty | undefined);
        get events(): string[];
        get filterPrefix(): string;
        get filterSuffix(): string;
        get id(): string;
        get topicArn(): string;
    }
    class TopicPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TopicPropertyOutputReference;
    }
}
