import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfBucketAclConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_acl#acl TfBucketAcl#acl}
    */
    readonly acl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_acl#bucket TfBucketAcl#bucket}
    */
    readonly bucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_acl#expected_bucket_owner TfBucketAcl#expected_bucket_owner}
    */
    readonly expectedBucketOwner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_acl#id TfBucketAcl#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_acl#region TfBucketAcl#region}
    */
    readonly region?: string;
    /**
    * access_control_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_acl#access_control_policy TfBucketAcl#access_control_policy}
    */
    readonly accessControlPolicy?: TfBucketAcl.AccessControlPolicyProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_acl aws_s3_bucket_acl}
*/
export declare class TfBucketAcl extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_s3_bucket_acl";
    /**
    * Generates CDKTN code for importing a TfBucketAcl resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfBucketAcl to import
    * @param importFromId The id of the existing TfBucketAcl that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_acl#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfBucketAcl to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_acl aws_s3_bucket_acl} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfBucketAclConfig
    */
    constructor(scope: Construct, id: string, config: TfBucketAclConfig);
    private _acl?;
    get acl(): string;
    set acl(value: string);
    resetAcl(): void;
    get aclInput(): string | undefined;
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _expectedBucketOwner?;
    get expectedBucketOwner(): string;
    set expectedBucketOwner(value: string);
    resetExpectedBucketOwner(): void;
    get expectedBucketOwnerInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _accessControlPolicy;
    get accessControlPolicy(): TfBucketAcl.AccessControlPolicyPropertyOutputReference;
    putAccessControlPolicy(value: TfBucketAcl.AccessControlPolicyProperty): void;
    resetAccessControlPolicy(): void;
    get accessControlPolicyInput(): TfBucketAcl.AccessControlPolicyProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfBucketAclGranteePropertyToTerraform(struct?: TfBucketAcl.GranteePropertyOutputReference | TfBucketAcl.GranteeProperty): any;
export declare function tfBucketAclGranteePropertyToHclTerraform(struct?: TfBucketAcl.GranteePropertyOutputReference | TfBucketAcl.GranteeProperty): any;
export declare function tfBucketAclGrantPropertyToTerraform(struct?: TfBucketAcl.GrantProperty | cdktn.IResolvable): any;
export declare function tfBucketAclGrantPropertyToHclTerraform(struct?: TfBucketAcl.GrantProperty | cdktn.IResolvable): any;
export declare function tfBucketAclOwnerPropertyToTerraform(struct?: TfBucketAcl.OwnerPropertyOutputReference | TfBucketAcl.OwnerProperty): any;
export declare function tfBucketAclOwnerPropertyToHclTerraform(struct?: TfBucketAcl.OwnerPropertyOutputReference | TfBucketAcl.OwnerProperty): any;
export declare function tfBucketAclAccessControlPolicyPropertyToTerraform(struct?: TfBucketAcl.AccessControlPolicyPropertyOutputReference | TfBucketAcl.AccessControlPolicyProperty): any;
export declare function tfBucketAclAccessControlPolicyPropertyToHclTerraform(struct?: TfBucketAcl.AccessControlPolicyPropertyOutputReference | TfBucketAcl.AccessControlPolicyProperty): any;
export declare namespace TfBucketAcl {
    interface GranteeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_acl#email_address TfBucketAcl#email_address}
        */
        readonly emailAddress?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_acl#id TfBucketAcl#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_acl#type TfBucketAcl#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_acl#uri TfBucketAcl#uri}
        */
        readonly uri?: string;
    }
    class GranteePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): GranteeProperty | undefined;
        set internalValue(value: GranteeProperty | undefined);
        get displayName(): string;
        private _emailAddress?;
        get emailAddress(): string;
        set emailAddress(value: string);
        resetEmailAddress(): void;
        get emailAddressInput(): string | undefined;
        private _id?;
        get id(): string;
        set id(value: string);
        resetId(): void;
        get idInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _uri?;
        get uri(): string;
        set uri(value: string);
        resetUri(): void;
        get uriInput(): string | undefined;
    }
    interface GrantProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_acl#permission TfBucketAcl#permission}
        */
        readonly permission: string;
        /**
        * grantee block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_acl#grantee TfBucketAcl#grantee}
        */
        readonly grantee?: GranteeProperty;
    }
    class GrantPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GrantProperty | cdktn.IResolvable | undefined;
        set internalValue(value: GrantProperty | cdktn.IResolvable | undefined);
        private _permission?;
        get permission(): string;
        set permission(value: string);
        get permissionInput(): string | undefined;
        private _grantee;
        get grantee(): GranteePropertyOutputReference;
        putGrantee(value: GranteeProperty): void;
        resetGrantee(): void;
        get granteeInput(): GranteeProperty | undefined;
    }
    class GrantPropertyList extends cdktn.ComplexList {
        internalValue?: GrantProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GrantPropertyOutputReference;
    }
    interface OwnerProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_acl#display_name TfBucketAcl#display_name}
        */
        readonly displayName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_acl#id TfBucketAcl#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
    }
    class OwnerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OwnerProperty | undefined;
        set internalValue(value: OwnerProperty | undefined);
        private _displayName?;
        get displayName(): string;
        set displayName(value: string);
        resetDisplayName(): void;
        get displayNameInput(): string | undefined;
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
    }
    interface AccessControlPolicyProperty {
        /**
        * grant block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_acl#grant TfBucketAcl#grant}
        */
        readonly grant?: GrantProperty[] | cdktn.IResolvable;
        /**
        * owner block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/s3_bucket_acl#owner TfBucketAcl#owner}
        */
        readonly owner: OwnerProperty;
    }
    class AccessControlPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AccessControlPolicyProperty | undefined;
        set internalValue(value: AccessControlPolicyProperty | undefined);
        private _grant;
        get grant(): GrantPropertyList;
        putGrant(value: GrantProperty[] | cdktn.IResolvable): void;
        resetGrant(): void;
        get grantInput(): cdktn.IResolvable | GrantProperty[] | undefined;
        private _owner;
        get owner(): OwnerPropertyOutputReference;
        putOwner(value: OwnerProperty): void;
        get ownerInput(): OwnerProperty | undefined;
    }
}
