import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsInputConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#id AwsInput#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#input_security_groups AwsInput#input_security_groups}
    */
    readonly inputSecurityGroups?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#name AwsInput#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#region AwsInput#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#role_arn AwsInput#role_arn}
    */
    readonly roleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#tags AwsInput#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#tags_all AwsInput#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#type AwsInput#type}
    */
    readonly type: string;
    /**
    * destinations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#destinations AwsInput#destinations}
    */
    readonly destinations?: AwsInput.DestinationsProperty[] | cdktn.IResolvable;
    /**
    * input_devices block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#input_devices AwsInput#input_devices}
    */
    readonly inputDevices?: AwsInput.InputDevicesProperty[] | cdktn.IResolvable;
    /**
    * media_connect_flows block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#media_connect_flows AwsInput#media_connect_flows}
    */
    readonly mediaConnectFlows?: AwsInput.MediaConnectFlowsProperty[] | cdktn.IResolvable;
    /**
    * sources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#sources AwsInput#sources}
    */
    readonly sources?: AwsInput.SourcesProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#timeouts AwsInput#timeouts}
    */
    readonly timeouts?: AwsInput.TimeoutsProperty;
    /**
    * vpc block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#vpc AwsInput#vpc}
    */
    readonly vpc?: AwsInput.VpcProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input aws_medialive_input}
*/
export declare class AwsInput extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_medialive_input";
    /**
    * Generates CDKTN code for importing a AwsInput resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsInput to import
    * @param importFromId The id of the existing AwsInput that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsInput to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input aws_medialive_input} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsInputConfig
    */
    constructor(scope: Construct, id: string, config: AwsInputConfig);
    get arn(): string;
    get attachedChannels(): string[];
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get inputClass(): string;
    get inputPartnerIds(): string[];
    private _inputSecurityGroups?;
    get inputSecurityGroups(): string[];
    set inputSecurityGroups(value: string[]);
    resetInputSecurityGroups(): void;
    get inputSecurityGroupsInput(): string[] | undefined;
    get inputSourceType(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _destinations;
    get destinations(): AwsInput.DestinationsPropertyList;
    putDestinations(value: AwsInput.DestinationsProperty[] | cdktn.IResolvable): void;
    resetDestinations(): void;
    get destinationsInput(): cdktn.IResolvable | AwsInput.DestinationsProperty[] | undefined;
    private _inputDevices;
    get inputDevices(): AwsInput.InputDevicesPropertyList;
    putInputDevices(value: AwsInput.InputDevicesProperty[] | cdktn.IResolvable): void;
    resetInputDevices(): void;
    get inputDevicesInput(): cdktn.IResolvable | AwsInput.InputDevicesProperty[] | undefined;
    private _mediaConnectFlows;
    get mediaConnectFlows(): AwsInput.MediaConnectFlowsPropertyList;
    putMediaConnectFlows(value: AwsInput.MediaConnectFlowsProperty[] | cdktn.IResolvable): void;
    resetMediaConnectFlows(): void;
    get mediaConnectFlowsInput(): cdktn.IResolvable | AwsInput.MediaConnectFlowsProperty[] | undefined;
    private _sources;
    get sources(): AwsInput.SourcesPropertyList;
    putSources(value: AwsInput.SourcesProperty[] | cdktn.IResolvable): void;
    resetSources(): void;
    get sourcesInput(): cdktn.IResolvable | AwsInput.SourcesProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsInput.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsInput.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsInput.TimeoutsProperty | undefined;
    private _vpc;
    get vpc(): AwsInput.VpcPropertyOutputReference;
    putVpc(value: AwsInput.VpcProperty): void;
    resetVpc(): void;
    get vpcInput(): AwsInput.VpcProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsInputDestinationsPropertyToTerraform(struct?: AwsInput.DestinationsProperty | cdktn.IResolvable): any;
export declare function awsInputDestinationsPropertyToHclTerraform(struct?: AwsInput.DestinationsProperty | cdktn.IResolvable): any;
export declare function awsInputInputDevicesPropertyToTerraform(struct?: AwsInput.InputDevicesProperty | cdktn.IResolvable): any;
export declare function awsInputInputDevicesPropertyToHclTerraform(struct?: AwsInput.InputDevicesProperty | cdktn.IResolvable): any;
export declare function awsInputMediaConnectFlowsPropertyToTerraform(struct?: AwsInput.MediaConnectFlowsProperty | cdktn.IResolvable): any;
export declare function awsInputMediaConnectFlowsPropertyToHclTerraform(struct?: AwsInput.MediaConnectFlowsProperty | cdktn.IResolvable): any;
export declare function awsInputSourcesPropertyToTerraform(struct?: AwsInput.SourcesProperty | cdktn.IResolvable): any;
export declare function awsInputSourcesPropertyToHclTerraform(struct?: AwsInput.SourcesProperty | cdktn.IResolvable): any;
export declare function awsInputTimeoutsPropertyToTerraform(struct?: AwsInput.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsInputTimeoutsPropertyToHclTerraform(struct?: AwsInput.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsInputVpcPropertyToTerraform(struct?: AwsInput.VpcPropertyOutputReference | AwsInput.VpcProperty): any;
export declare function awsInputVpcPropertyToHclTerraform(struct?: AwsInput.VpcPropertyOutputReference | AwsInput.VpcProperty): any;
export declare namespace AwsInput {
    interface DestinationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#stream_name AwsInput#stream_name}
        */
        readonly streamName: string;
    }
    class DestinationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DestinationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DestinationsProperty | cdktn.IResolvable | undefined);
        private _streamName?;
        get streamName(): string;
        set streamName(value: string);
        get streamNameInput(): string | undefined;
    }
    class DestinationsPropertyList extends cdktn.ComplexList {
        internalValue?: DestinationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DestinationsPropertyOutputReference;
    }
    interface InputDevicesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#id AwsInput#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
    }
    class InputDevicesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InputDevicesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InputDevicesProperty | cdktn.IResolvable | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
    }
    class InputDevicesPropertyList extends cdktn.ComplexList {
        internalValue?: InputDevicesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InputDevicesPropertyOutputReference;
    }
    interface MediaConnectFlowsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#flow_arn AwsInput#flow_arn}
        */
        readonly flowArn: string;
    }
    class MediaConnectFlowsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MediaConnectFlowsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MediaConnectFlowsProperty | cdktn.IResolvable | undefined);
        private _flowArn?;
        get flowArn(): string;
        set flowArn(value: string);
        get flowArnInput(): string | undefined;
    }
    class MediaConnectFlowsPropertyList extends cdktn.ComplexList {
        internalValue?: MediaConnectFlowsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MediaConnectFlowsPropertyOutputReference;
    }
    interface SourcesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#password_param AwsInput#password_param}
        */
        readonly passwordParam: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#url AwsInput#url}
        */
        readonly url: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#username AwsInput#username}
        */
        readonly username: string;
    }
    class SourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SourcesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SourcesProperty | cdktn.IResolvable | undefined);
        private _passwordParam?;
        get passwordParam(): string;
        set passwordParam(value: string);
        get passwordParamInput(): string | undefined;
        private _url?;
        get url(): string;
        set url(value: string);
        get urlInput(): string | undefined;
        private _username?;
        get username(): string;
        set username(value: string);
        get usernameInput(): string | undefined;
    }
    class SourcesPropertyList extends cdktn.ComplexList {
        internalValue?: SourcesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SourcesPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#create AwsInput#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#delete AwsInput#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#update AwsInput#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface VpcProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#security_group_ids AwsInput#security_group_ids}
        */
        readonly securityGroupIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_input#subnet_ids AwsInput#subnet_ids}
        */
        readonly subnetIds: string[];
    }
    class VpcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcProperty | undefined;
        set internalValue(value: VpcProperty | undefined);
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        resetSecurityGroupIds(): void;
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
    }
}
