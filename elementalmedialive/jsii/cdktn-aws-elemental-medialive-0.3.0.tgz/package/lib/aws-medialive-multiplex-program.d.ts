import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsMultiplexProgramConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_multiplex_program#multiplex_id AwsMultiplexProgram#multiplex_id}
    */
    readonly multiplexId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_multiplex_program#program_name AwsMultiplexProgram#program_name}
    */
    readonly programName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_multiplex_program#region AwsMultiplexProgram#region}
    */
    readonly region?: string;
    /**
    * multiplex_program_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_multiplex_program#multiplex_program_settings AwsMultiplexProgram#multiplex_program_settings}
    */
    readonly multiplexProgramSettings?: AwsMultiplexProgram.MultiplexProgramSettingsProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_multiplex_program#timeouts AwsMultiplexProgram#timeouts}
    */
    readonly timeouts?: AwsMultiplexProgram.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_multiplex_program aws_medialive_multiplex_program}
*/
export declare class AwsMultiplexProgram extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_medialive_multiplex_program";
    /**
    * Generates CDKTN code for importing a AwsMultiplexProgram resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsMultiplexProgram to import
    * @param importFromId The id of the existing AwsMultiplexProgram that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_multiplex_program#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsMultiplexProgram to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_multiplex_program aws_medialive_multiplex_program} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsMultiplexProgramConfig
    */
    constructor(scope: Construct, id: string, config: AwsMultiplexProgramConfig);
    get id(): string;
    private _multiplexId?;
    get multiplexId(): string;
    set multiplexId(value: string);
    get multiplexIdInput(): string | undefined;
    private _programName?;
    get programName(): string;
    set programName(value: string);
    get programNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _multiplexProgramSettings;
    get multiplexProgramSettings(): AwsMultiplexProgram.MultiplexProgramSettingsPropertyList;
    putMultiplexProgramSettings(value: AwsMultiplexProgram.MultiplexProgramSettingsProperty[] | cdktn.IResolvable): void;
    resetMultiplexProgramSettings(): void;
    get multiplexProgramSettingsInput(): cdktn.IResolvable | AwsMultiplexProgram.MultiplexProgramSettingsProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsMultiplexProgram.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsMultiplexProgram.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsMultiplexProgram.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsMultiplexProgramServiceDescriptorPropertyToTerraform(struct?: AwsMultiplexProgram.ServiceDescriptorProperty | cdktn.IResolvable): any;
export declare function awsMultiplexProgramServiceDescriptorPropertyToHclTerraform(struct?: AwsMultiplexProgram.ServiceDescriptorProperty | cdktn.IResolvable): any;
export declare function awsMultiplexProgramStatmuxSettingsPropertyToTerraform(struct?: AwsMultiplexProgram.StatmuxSettingsProperty | cdktn.IResolvable): any;
export declare function awsMultiplexProgramStatmuxSettingsPropertyToHclTerraform(struct?: AwsMultiplexProgram.StatmuxSettingsProperty | cdktn.IResolvable): any;
export declare function awsMultiplexProgramVideoSettingsPropertyToTerraform(struct?: AwsMultiplexProgram.VideoSettingsProperty | cdktn.IResolvable): any;
export declare function awsMultiplexProgramVideoSettingsPropertyToHclTerraform(struct?: AwsMultiplexProgram.VideoSettingsProperty | cdktn.IResolvable): any;
export declare function awsMultiplexProgramMultiplexProgramSettingsPropertyToTerraform(struct?: AwsMultiplexProgram.MultiplexProgramSettingsProperty | cdktn.IResolvable): any;
export declare function awsMultiplexProgramMultiplexProgramSettingsPropertyToHclTerraform(struct?: AwsMultiplexProgram.MultiplexProgramSettingsProperty | cdktn.IResolvable): any;
export declare function awsMultiplexProgramTimeoutsPropertyToTerraform(struct?: AwsMultiplexProgram.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsMultiplexProgramTimeoutsPropertyToHclTerraform(struct?: AwsMultiplexProgram.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsMultiplexProgram {
    interface ServiceDescriptorProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_multiplex_program#provider_name AwsMultiplexProgram#provider_name}
        */
        readonly providerName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_multiplex_program#service_name AwsMultiplexProgram#service_name}
        */
        readonly serviceName: string;
    }
    class ServiceDescriptorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ServiceDescriptorProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ServiceDescriptorProperty | cdktn.IResolvable | undefined);
        private _providerName?;
        get providerName(): string;
        set providerName(value: string);
        get providerNameInput(): string | undefined;
        private _serviceName?;
        get serviceName(): string;
        set serviceName(value: string);
        get serviceNameInput(): string | undefined;
    }
    class ServiceDescriptorPropertyList extends cdktn.ComplexList {
        internalValue?: ServiceDescriptorProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ServiceDescriptorPropertyOutputReference;
    }
    interface StatmuxSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_multiplex_program#maximum_bitrate AwsMultiplexProgram#maximum_bitrate}
        */
        readonly maximumBitrate?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_multiplex_program#minimum_bitrate AwsMultiplexProgram#minimum_bitrate}
        */
        readonly minimumBitrate?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_multiplex_program#priority AwsMultiplexProgram#priority}
        */
        readonly priority?: number;
    }
    class StatmuxSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StatmuxSettingsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StatmuxSettingsProperty | cdktn.IResolvable | undefined);
        private _maximumBitrate?;
        get maximumBitrate(): number;
        set maximumBitrate(value: number);
        resetMaximumBitrate(): void;
        get maximumBitrateInput(): number | undefined;
        private _minimumBitrate?;
        get minimumBitrate(): number;
        set minimumBitrate(value: number);
        resetMinimumBitrate(): void;
        get minimumBitrateInput(): number | undefined;
        private _priority?;
        get priority(): number;
        set priority(value: number);
        resetPriority(): void;
        get priorityInput(): number | undefined;
    }
    class StatmuxSettingsPropertyList extends cdktn.ComplexList {
        internalValue?: StatmuxSettingsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StatmuxSettingsPropertyOutputReference;
    }
    interface VideoSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_multiplex_program#constant_bitrate AwsMultiplexProgram#constant_bitrate}
        */
        readonly constantBitrate?: number;
        /**
        * statmux_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_multiplex_program#statmux_settings AwsMultiplexProgram#statmux_settings}
        */
        readonly statmuxSettings?: StatmuxSettingsProperty[] | cdktn.IResolvable;
    }
    class VideoSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VideoSettingsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VideoSettingsProperty | cdktn.IResolvable | undefined);
        private _constantBitrate?;
        get constantBitrate(): number;
        set constantBitrate(value: number);
        resetConstantBitrate(): void;
        get constantBitrateInput(): number | undefined;
        private _statmuxSettings;
        get statmuxSettings(): StatmuxSettingsPropertyList;
        putStatmuxSettings(value: StatmuxSettingsProperty[] | cdktn.IResolvable): void;
        resetStatmuxSettings(): void;
        get statmuxSettingsInput(): cdktn.IResolvable | StatmuxSettingsProperty[] | undefined;
    }
    class VideoSettingsPropertyList extends cdktn.ComplexList {
        internalValue?: VideoSettingsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VideoSettingsPropertyOutputReference;
    }
    interface MultiplexProgramSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_multiplex_program#preferred_channel_pipeline AwsMultiplexProgram#preferred_channel_pipeline}
        */
        readonly preferredChannelPipeline: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_multiplex_program#program_number AwsMultiplexProgram#program_number}
        */
        readonly programNumber: number;
        /**
        * service_descriptor block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_multiplex_program#service_descriptor AwsMultiplexProgram#service_descriptor}
        */
        readonly serviceDescriptor?: ServiceDescriptorProperty[] | cdktn.IResolvable;
        /**
        * video_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_multiplex_program#video_settings AwsMultiplexProgram#video_settings}
        */
        readonly videoSettings?: VideoSettingsProperty[] | cdktn.IResolvable;
    }
    class MultiplexProgramSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MultiplexProgramSettingsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MultiplexProgramSettingsProperty | cdktn.IResolvable | undefined);
        private _preferredChannelPipeline?;
        get preferredChannelPipeline(): string;
        set preferredChannelPipeline(value: string);
        get preferredChannelPipelineInput(): string | undefined;
        private _programNumber?;
        get programNumber(): number;
        set programNumber(value: number);
        get programNumberInput(): number | undefined;
        private _serviceDescriptor;
        get serviceDescriptor(): ServiceDescriptorPropertyList;
        putServiceDescriptor(value: ServiceDescriptorProperty[] | cdktn.IResolvable): void;
        resetServiceDescriptor(): void;
        get serviceDescriptorInput(): cdktn.IResolvable | ServiceDescriptorProperty[] | undefined;
        private _videoSettings;
        get videoSettings(): VideoSettingsPropertyList;
        putVideoSettings(value: VideoSettingsProperty[] | cdktn.IResolvable): void;
        resetVideoSettings(): void;
        get videoSettingsInput(): cdktn.IResolvable | VideoSettingsProperty[] | undefined;
    }
    class MultiplexProgramSettingsPropertyList extends cdktn.ComplexList {
        internalValue?: MultiplexProgramSettingsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MultiplexProgramSettingsPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_multiplex_program#create AwsMultiplexProgram#create}
        */
        readonly create?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
    }
}
