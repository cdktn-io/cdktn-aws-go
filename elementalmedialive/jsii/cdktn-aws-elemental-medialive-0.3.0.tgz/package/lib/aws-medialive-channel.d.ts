import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsChannelConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#channel_class AwsChannel#channel_class}
    */
    readonly channelClass: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#id AwsChannel#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#log_level AwsChannel#log_level}
    */
    readonly logLevel?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#name AwsChannel#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#region AwsChannel#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#role_arn AwsChannel#role_arn}
    */
    readonly roleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#start_channel AwsChannel#start_channel}
    */
    readonly startChannel?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#tags AwsChannel#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#tags_all AwsChannel#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * cdi_input_specification block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#cdi_input_specification AwsChannel#cdi_input_specification}
    */
    readonly cdiInputSpecification?: AwsChannel.CdiInputSpecificationProperty;
    /**
    * destinations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#destinations AwsChannel#destinations}
    */
    readonly destinations: AwsChannel.DestinationsProperty[] | cdktn.IResolvable;
    /**
    * encoder_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#encoder_settings AwsChannel#encoder_settings}
    */
    readonly encoderSettings: AwsChannel.EncoderSettingsProperty;
    /**
    * input_attachments block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#input_attachments AwsChannel#input_attachments}
    */
    readonly inputAttachments: AwsChannel.InputAttachmentsProperty[] | cdktn.IResolvable;
    /**
    * input_specification block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#input_specification AwsChannel#input_specification}
    */
    readonly inputSpecification: AwsChannel.InputSpecificationProperty;
    /**
    * maintenance block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#maintenance AwsChannel#maintenance}
    */
    readonly maintenance?: AwsChannel.MaintenanceProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#timeouts AwsChannel#timeouts}
    */
    readonly timeouts?: AwsChannel.TimeoutsProperty;
    /**
    * vpc block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#vpc AwsChannel#vpc}
    */
    readonly vpc?: AwsChannel.VpcProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel aws_medialive_channel}
*/
export declare class AwsChannel extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_medialive_channel";
    /**
    * Generates CDKTN code for importing a AwsChannel resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsChannel to import
    * @param importFromId The id of the existing AwsChannel that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsChannel to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel aws_medialive_channel} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsChannelConfig
    */
    constructor(scope: Construct, id: string, config: AwsChannelConfig);
    get arn(): string;
    private _channelClass?;
    get channelClass(): string;
    set channelClass(value: string);
    get channelClassInput(): string | undefined;
    get channelId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _logLevel?;
    get logLevel(): string;
    set logLevel(value: string);
    resetLogLevel(): void;
    get logLevelInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
    private _startChannel?;
    get startChannel(): boolean | cdktn.IResolvable;
    set startChannel(value: boolean | cdktn.IResolvable);
    resetStartChannel(): void;
    get startChannelInput(): boolean | cdktn.IResolvable | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _cdiInputSpecification;
    get cdiInputSpecification(): AwsChannel.CdiInputSpecificationPropertyOutputReference;
    putCdiInputSpecification(value: AwsChannel.CdiInputSpecificationProperty): void;
    resetCdiInputSpecification(): void;
    get cdiInputSpecificationInput(): AwsChannel.CdiInputSpecificationProperty | undefined;
    private _destinations;
    get destinations(): AwsChannel.DestinationsPropertyList;
    putDestinations(value: AwsChannel.DestinationsProperty[] | cdktn.IResolvable): void;
    get destinationsInput(): cdktn.IResolvable | AwsChannel.DestinationsProperty[] | undefined;
    private _encoderSettings;
    get encoderSettings(): AwsChannel.EncoderSettingsPropertyOutputReference;
    putEncoderSettings(value: AwsChannel.EncoderSettingsProperty): void;
    get encoderSettingsInput(): AwsChannel.EncoderSettingsProperty | undefined;
    private _inputAttachments;
    get inputAttachments(): AwsChannel.InputAttachmentsPropertyList;
    putInputAttachments(value: AwsChannel.InputAttachmentsProperty[] | cdktn.IResolvable): void;
    get inputAttachmentsInput(): cdktn.IResolvable | AwsChannel.InputAttachmentsProperty[] | undefined;
    private _inputSpecification;
    get inputSpecification(): AwsChannel.InputSpecificationPropertyOutputReference;
    putInputSpecification(value: AwsChannel.InputSpecificationProperty): void;
    get inputSpecificationInput(): AwsChannel.InputSpecificationProperty | undefined;
    private _maintenance;
    get maintenance(): AwsChannel.MaintenancePropertyOutputReference;
    putMaintenance(value: AwsChannel.MaintenanceProperty): void;
    resetMaintenance(): void;
    get maintenanceInput(): AwsChannel.MaintenanceProperty | undefined;
    private _timeouts;
    get timeouts(): AwsChannel.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsChannel.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsChannel.TimeoutsProperty | undefined;
    private _vpc;
    get vpc(): AwsChannel.VpcPropertyOutputReference;
    putVpc(value: AwsChannel.VpcProperty): void;
    resetVpc(): void;
    get vpcInput(): AwsChannel.VpcProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsChannelCdiInputSpecificationPropertyToTerraform(struct?: AwsChannel.CdiInputSpecificationPropertyOutputReference | AwsChannel.CdiInputSpecificationProperty): any;
export declare function awsChannelCdiInputSpecificationPropertyToHclTerraform(struct?: AwsChannel.CdiInputSpecificationPropertyOutputReference | AwsChannel.CdiInputSpecificationProperty): any;
export declare function awsChannelMediaPackageSettingsPropertyToTerraform(struct?: AwsChannel.MediaPackageSettingsProperty | cdktn.IResolvable): any;
export declare function awsChannelMediaPackageSettingsPropertyToHclTerraform(struct?: AwsChannel.MediaPackageSettingsProperty | cdktn.IResolvable): any;
export declare function awsChannelMultiplexSettingsPropertyToTerraform(struct?: AwsChannel.MultiplexSettingsPropertyOutputReference | AwsChannel.MultiplexSettingsProperty): any;
export declare function awsChannelMultiplexSettingsPropertyToHclTerraform(struct?: AwsChannel.MultiplexSettingsPropertyOutputReference | AwsChannel.MultiplexSettingsProperty): any;
export declare function awsChannelSettingsPropertyToTerraform(struct?: AwsChannel.SettingsProperty | cdktn.IResolvable): any;
export declare function awsChannelSettingsPropertyToHclTerraform(struct?: AwsChannel.SettingsProperty | cdktn.IResolvable): any;
export declare function awsChannelDestinationsPropertyToTerraform(struct?: AwsChannel.DestinationsProperty | cdktn.IResolvable): any;
export declare function awsChannelDestinationsPropertyToHclTerraform(struct?: AwsChannel.DestinationsProperty | cdktn.IResolvable): any;
export declare function awsChannelAudioNormalizationSettingsPropertyToTerraform(struct?: AwsChannel.AudioNormalizationSettingsPropertyOutputReference | AwsChannel.AudioNormalizationSettingsProperty): any;
export declare function awsChannelAudioNormalizationSettingsPropertyToHclTerraform(struct?: AwsChannel.AudioNormalizationSettingsPropertyOutputReference | AwsChannel.AudioNormalizationSettingsProperty): any;
export declare function awsChannelNielsenCbetSettingsPropertyToTerraform(struct?: AwsChannel.NielsenCbetSettingsPropertyOutputReference | AwsChannel.NielsenCbetSettingsProperty): any;
export declare function awsChannelNielsenCbetSettingsPropertyToHclTerraform(struct?: AwsChannel.NielsenCbetSettingsPropertyOutputReference | AwsChannel.NielsenCbetSettingsProperty): any;
export declare function awsChannelNielsenNaesIiNwSettingsPropertyToTerraform(struct?: AwsChannel.NielsenNaesIiNwSettingsProperty | cdktn.IResolvable): any;
export declare function awsChannelNielsenNaesIiNwSettingsPropertyToHclTerraform(struct?: AwsChannel.NielsenNaesIiNwSettingsProperty | cdktn.IResolvable): any;
export declare function awsChannelNielsenWatermarksSettingsPropertyToTerraform(struct?: AwsChannel.NielsenWatermarksSettingsPropertyOutputReference | AwsChannel.NielsenWatermarksSettingsProperty): any;
export declare function awsChannelNielsenWatermarksSettingsPropertyToHclTerraform(struct?: AwsChannel.NielsenWatermarksSettingsPropertyOutputReference | AwsChannel.NielsenWatermarksSettingsProperty): any;
export declare function awsChannelAudioWatermarkSettingsPropertyToTerraform(struct?: AwsChannel.AudioWatermarkSettingsPropertyOutputReference | AwsChannel.AudioWatermarkSettingsProperty): any;
export declare function awsChannelAudioWatermarkSettingsPropertyToHclTerraform(struct?: AwsChannel.AudioWatermarkSettingsPropertyOutputReference | AwsChannel.AudioWatermarkSettingsProperty): any;
export declare function awsChannelAacSettingsPropertyToTerraform(struct?: AwsChannel.AacSettingsPropertyOutputReference | AwsChannel.AacSettingsProperty): any;
export declare function awsChannelAacSettingsPropertyToHclTerraform(struct?: AwsChannel.AacSettingsPropertyOutputReference | AwsChannel.AacSettingsProperty): any;
export declare function awsChannelAc3SettingsPropertyToTerraform(struct?: AwsChannel.Ac3SettingsPropertyOutputReference | AwsChannel.Ac3SettingsProperty): any;
export declare function awsChannelAc3SettingsPropertyToHclTerraform(struct?: AwsChannel.Ac3SettingsPropertyOutputReference | AwsChannel.Ac3SettingsProperty): any;
export declare function awsChannelEac3AtmosSettingsPropertyToTerraform(struct?: AwsChannel.Eac3AtmosSettingsPropertyOutputReference | AwsChannel.Eac3AtmosSettingsProperty): any;
export declare function awsChannelEac3AtmosSettingsPropertyToHclTerraform(struct?: AwsChannel.Eac3AtmosSettingsPropertyOutputReference | AwsChannel.Eac3AtmosSettingsProperty): any;
export declare function awsChannelEac3SettingsPropertyToTerraform(struct?: AwsChannel.Eac3SettingsPropertyOutputReference | AwsChannel.Eac3SettingsProperty): any;
export declare function awsChannelEac3SettingsPropertyToHclTerraform(struct?: AwsChannel.Eac3SettingsPropertyOutputReference | AwsChannel.Eac3SettingsProperty): any;
export declare function awsChannelMp2SettingsPropertyToTerraform(struct?: AwsChannel.Mp2SettingsPropertyOutputReference | AwsChannel.Mp2SettingsProperty): any;
export declare function awsChannelMp2SettingsPropertyToHclTerraform(struct?: AwsChannel.Mp2SettingsPropertyOutputReference | AwsChannel.Mp2SettingsProperty): any;
export declare function awsChannelPassThroughSettingsPropertyToTerraform(struct?: AwsChannel.PassThroughSettingsPropertyOutputReference | AwsChannel.PassThroughSettingsProperty): any;
export declare function awsChannelPassThroughSettingsPropertyToHclTerraform(struct?: AwsChannel.PassThroughSettingsPropertyOutputReference | AwsChannel.PassThroughSettingsProperty): any;
export declare function awsChannelWavSettingsPropertyToTerraform(struct?: AwsChannel.WavSettingsPropertyOutputReference | AwsChannel.WavSettingsProperty): any;
export declare function awsChannelWavSettingsPropertyToHclTerraform(struct?: AwsChannel.WavSettingsPropertyOutputReference | AwsChannel.WavSettingsProperty): any;
export declare function awsChannelEncoderSettingsAudioDescriptionsCodecSettingsPropertyToTerraform(struct?: AwsChannel.EncoderSettingsAudioDescriptionsCodecSettingsPropertyOutputReference | AwsChannel.EncoderSettingsAudioDescriptionsCodecSettingsProperty): any;
export declare function awsChannelEncoderSettingsAudioDescriptionsCodecSettingsPropertyToHclTerraform(struct?: AwsChannel.EncoderSettingsAudioDescriptionsCodecSettingsPropertyOutputReference | AwsChannel.EncoderSettingsAudioDescriptionsCodecSettingsProperty): any;
export declare function awsChannelInputChannelLevelsPropertyToTerraform(struct?: AwsChannel.InputChannelLevelsProperty | cdktn.IResolvable): any;
export declare function awsChannelInputChannelLevelsPropertyToHclTerraform(struct?: AwsChannel.InputChannelLevelsProperty | cdktn.IResolvable): any;
export declare function awsChannelChannelMappingsPropertyToTerraform(struct?: AwsChannel.ChannelMappingsProperty | cdktn.IResolvable): any;
export declare function awsChannelChannelMappingsPropertyToHclTerraform(struct?: AwsChannel.ChannelMappingsProperty | cdktn.IResolvable): any;
export declare function awsChannelRemixSettingsPropertyToTerraform(struct?: AwsChannel.RemixSettingsPropertyOutputReference | AwsChannel.RemixSettingsProperty): any;
export declare function awsChannelRemixSettingsPropertyToHclTerraform(struct?: AwsChannel.RemixSettingsPropertyOutputReference | AwsChannel.RemixSettingsProperty): any;
export declare function awsChannelAudioDescriptionsPropertyToTerraform(struct?: AwsChannel.AudioDescriptionsProperty | cdktn.IResolvable): any;
export declare function awsChannelAudioDescriptionsPropertyToHclTerraform(struct?: AwsChannel.AudioDescriptionsProperty | cdktn.IResolvable): any;
export declare function awsChannelAvailBlankingImagePropertyToTerraform(struct?: AwsChannel.AvailBlankingImagePropertyOutputReference | AwsChannel.AvailBlankingImageProperty): any;
export declare function awsChannelAvailBlankingImagePropertyToHclTerraform(struct?: AwsChannel.AvailBlankingImagePropertyOutputReference | AwsChannel.AvailBlankingImageProperty): any;
export declare function awsChannelAvailBlankingPropertyToTerraform(struct?: AwsChannel.AvailBlankingPropertyOutputReference | AwsChannel.AvailBlankingProperty): any;
export declare function awsChannelAvailBlankingPropertyToHclTerraform(struct?: AwsChannel.AvailBlankingPropertyOutputReference | AwsChannel.AvailBlankingProperty): any;
export declare function awsChannelAribDestinationSettingsPropertyToTerraform(struct?: AwsChannel.AribDestinationSettingsPropertyOutputReference | AwsChannel.AribDestinationSettingsProperty): any;
export declare function awsChannelAribDestinationSettingsPropertyToHclTerraform(struct?: AwsChannel.AribDestinationSettingsPropertyOutputReference | AwsChannel.AribDestinationSettingsProperty): any;
export declare function awsChannelEncoderSettingsCaptionDescriptionsDestinationSettingsBurnInDestinationSettingsFontPropertyToTerraform(struct?: AwsChannel.EncoderSettingsCaptionDescriptionsDestinationSettingsBurnInDestinationSettingsFontPropertyOutputReference | AwsChannel.EncoderSettingsCaptionDescriptionsDestinationSettingsBurnInDestinationSettingsFontProperty): any;
export declare function awsChannelEncoderSettingsCaptionDescriptionsDestinationSettingsBurnInDestinationSettingsFontPropertyToHclTerraform(struct?: AwsChannel.EncoderSettingsCaptionDescriptionsDestinationSettingsBurnInDestinationSettingsFontPropertyOutputReference | AwsChannel.EncoderSettingsCaptionDescriptionsDestinationSettingsBurnInDestinationSettingsFontProperty): any;
export declare function awsChannelBurnInDestinationSettingsPropertyToTerraform(struct?: AwsChannel.BurnInDestinationSettingsPropertyOutputReference | AwsChannel.BurnInDestinationSettingsProperty): any;
export declare function awsChannelBurnInDestinationSettingsPropertyToHclTerraform(struct?: AwsChannel.BurnInDestinationSettingsPropertyOutputReference | AwsChannel.BurnInDestinationSettingsProperty): any;
export declare function awsChannelEncoderSettingsCaptionDescriptionsDestinationSettingsDvbSubDestinationSettingsFontPropertyToTerraform(struct?: AwsChannel.EncoderSettingsCaptionDescriptionsDestinationSettingsDvbSubDestinationSettingsFontPropertyOutputReference | AwsChannel.EncoderSettingsCaptionDescriptionsDestinationSettingsDvbSubDestinationSettingsFontProperty): any;
export declare function awsChannelEncoderSettingsCaptionDescriptionsDestinationSettingsDvbSubDestinationSettingsFontPropertyToHclTerraform(struct?: AwsChannel.EncoderSettingsCaptionDescriptionsDestinationSettingsDvbSubDestinationSettingsFontPropertyOutputReference | AwsChannel.EncoderSettingsCaptionDescriptionsDestinationSettingsDvbSubDestinationSettingsFontProperty): any;
export declare function awsChannelDvbSubDestinationSettingsPropertyToTerraform(struct?: AwsChannel.DvbSubDestinationSettingsPropertyOutputReference | AwsChannel.DvbSubDestinationSettingsProperty): any;
export declare function awsChannelDvbSubDestinationSettingsPropertyToHclTerraform(struct?: AwsChannel.DvbSubDestinationSettingsPropertyOutputReference | AwsChannel.DvbSubDestinationSettingsProperty): any;
export declare function awsChannelEbuTtDDestinationSettingsPropertyToTerraform(struct?: AwsChannel.EbuTtDDestinationSettingsPropertyOutputReference | AwsChannel.EbuTtDDestinationSettingsProperty): any;
export declare function awsChannelEbuTtDDestinationSettingsPropertyToHclTerraform(struct?: AwsChannel.EbuTtDDestinationSettingsPropertyOutputReference | AwsChannel.EbuTtDDestinationSettingsProperty): any;
export declare function awsChannelEmbeddedDestinationSettingsPropertyToTerraform(struct?: AwsChannel.EmbeddedDestinationSettingsPropertyOutputReference | AwsChannel.EmbeddedDestinationSettingsProperty): any;
export declare function awsChannelEmbeddedDestinationSettingsPropertyToHclTerraform(struct?: AwsChannel.EmbeddedDestinationSettingsPropertyOutputReference | AwsChannel.EmbeddedDestinationSettingsProperty): any;
export declare function awsChannelEmbeddedPlusScte20DestinationSettingsPropertyToTerraform(struct?: AwsChannel.EmbeddedPlusScte20DestinationSettingsPropertyOutputReference | AwsChannel.EmbeddedPlusScte20DestinationSettingsProperty): any;
export declare function awsChannelEmbeddedPlusScte20DestinationSettingsPropertyToHclTerraform(struct?: AwsChannel.EmbeddedPlusScte20DestinationSettingsPropertyOutputReference | AwsChannel.EmbeddedPlusScte20DestinationSettingsProperty): any;
export declare function awsChannelRtmpCaptionInfoDestinationSettingsPropertyToTerraform(struct?: AwsChannel.RtmpCaptionInfoDestinationSettingsPropertyOutputReference | AwsChannel.RtmpCaptionInfoDestinationSettingsProperty): any;
export declare function awsChannelRtmpCaptionInfoDestinationSettingsPropertyToHclTerraform(struct?: AwsChannel.RtmpCaptionInfoDestinationSettingsPropertyOutputReference | AwsChannel.RtmpCaptionInfoDestinationSettingsProperty): any;
export declare function awsChannelScte20PlusEmbeddedDestinationSettingsPropertyToTerraform(struct?: AwsChannel.Scte20PlusEmbeddedDestinationSettingsPropertyOutputReference | AwsChannel.Scte20PlusEmbeddedDestinationSettingsProperty): any;
export declare function awsChannelScte20PlusEmbeddedDestinationSettingsPropertyToHclTerraform(struct?: AwsChannel.Scte20PlusEmbeddedDestinationSettingsPropertyOutputReference | AwsChannel.Scte20PlusEmbeddedDestinationSettingsProperty): any;
export declare function awsChannelScte27DestinationSettingsPropertyToTerraform(struct?: AwsChannel.Scte27DestinationSettingsPropertyOutputReference | AwsChannel.Scte27DestinationSettingsProperty): any;
export declare function awsChannelScte27DestinationSettingsPropertyToHclTerraform(struct?: AwsChannel.Scte27DestinationSettingsPropertyOutputReference | AwsChannel.Scte27DestinationSettingsProperty): any;
export declare function awsChannelSmpteTtDestinationSettingsPropertyToTerraform(struct?: AwsChannel.SmpteTtDestinationSettingsPropertyOutputReference | AwsChannel.SmpteTtDestinationSettingsProperty): any;
export declare function awsChannelSmpteTtDestinationSettingsPropertyToHclTerraform(struct?: AwsChannel.SmpteTtDestinationSettingsPropertyOutputReference | AwsChannel.SmpteTtDestinationSettingsProperty): any;
export declare function awsChannelTeletextDestinationSettingsPropertyToTerraform(struct?: AwsChannel.TeletextDestinationSettingsPropertyOutputReference | AwsChannel.TeletextDestinationSettingsProperty): any;
export declare function awsChannelTeletextDestinationSettingsPropertyToHclTerraform(struct?: AwsChannel.TeletextDestinationSettingsPropertyOutputReference | AwsChannel.TeletextDestinationSettingsProperty): any;
export declare function awsChannelTtmlDestinationSettingsPropertyToTerraform(struct?: AwsChannel.TtmlDestinationSettingsPropertyOutputReference | AwsChannel.TtmlDestinationSettingsProperty): any;
export declare function awsChannelTtmlDestinationSettingsPropertyToHclTerraform(struct?: AwsChannel.TtmlDestinationSettingsPropertyOutputReference | AwsChannel.TtmlDestinationSettingsProperty): any;
export declare function awsChannelWebvttDestinationSettingsPropertyToTerraform(struct?: AwsChannel.WebvttDestinationSettingsPropertyOutputReference | AwsChannel.WebvttDestinationSettingsProperty): any;
export declare function awsChannelWebvttDestinationSettingsPropertyToHclTerraform(struct?: AwsChannel.WebvttDestinationSettingsPropertyOutputReference | AwsChannel.WebvttDestinationSettingsProperty): any;
export declare function awsChannelDestinationSettingsPropertyToTerraform(struct?: AwsChannel.DestinationSettingsPropertyOutputReference | AwsChannel.DestinationSettingsProperty): any;
export declare function awsChannelDestinationSettingsPropertyToHclTerraform(struct?: AwsChannel.DestinationSettingsPropertyOutputReference | AwsChannel.DestinationSettingsProperty): any;
export declare function awsChannelCaptionDescriptionsPropertyToTerraform(struct?: AwsChannel.CaptionDescriptionsProperty | cdktn.IResolvable): any;
export declare function awsChannelCaptionDescriptionsPropertyToHclTerraform(struct?: AwsChannel.CaptionDescriptionsProperty | cdktn.IResolvable): any;
export declare function awsChannelInputLossImageSlatePropertyToTerraform(struct?: AwsChannel.InputLossImageSlatePropertyOutputReference | AwsChannel.InputLossImageSlateProperty): any;
export declare function awsChannelInputLossImageSlatePropertyToHclTerraform(struct?: AwsChannel.InputLossImageSlatePropertyOutputReference | AwsChannel.InputLossImageSlateProperty): any;
export declare function awsChannelInputLossBehaviorPropertyToTerraform(struct?: AwsChannel.InputLossBehaviorPropertyOutputReference | AwsChannel.InputLossBehaviorProperty): any;
export declare function awsChannelInputLossBehaviorPropertyToHclTerraform(struct?: AwsChannel.InputLossBehaviorPropertyOutputReference | AwsChannel.InputLossBehaviorProperty): any;
export declare function awsChannelGlobalConfigurationPropertyToTerraform(struct?: AwsChannel.GlobalConfigurationPropertyOutputReference | AwsChannel.GlobalConfigurationProperty): any;
export declare function awsChannelGlobalConfigurationPropertyToHclTerraform(struct?: AwsChannel.GlobalConfigurationPropertyOutputReference | AwsChannel.GlobalConfigurationProperty): any;
export declare function awsChannelHtmlMotionGraphicsSettingsPropertyToTerraform(struct?: AwsChannel.HtmlMotionGraphicsSettingsPropertyOutputReference | AwsChannel.HtmlMotionGraphicsSettingsProperty): any;
export declare function awsChannelHtmlMotionGraphicsSettingsPropertyToHclTerraform(struct?: AwsChannel.HtmlMotionGraphicsSettingsPropertyOutputReference | AwsChannel.HtmlMotionGraphicsSettingsProperty): any;
export declare function awsChannelMotionGraphicsSettingsPropertyToTerraform(struct?: AwsChannel.MotionGraphicsSettingsPropertyOutputReference | AwsChannel.MotionGraphicsSettingsProperty): any;
export declare function awsChannelMotionGraphicsSettingsPropertyToHclTerraform(struct?: AwsChannel.MotionGraphicsSettingsPropertyOutputReference | AwsChannel.MotionGraphicsSettingsProperty): any;
export declare function awsChannelMotionGraphicsConfigurationPropertyToTerraform(struct?: AwsChannel.MotionGraphicsConfigurationPropertyOutputReference | AwsChannel.MotionGraphicsConfigurationProperty): any;
export declare function awsChannelMotionGraphicsConfigurationPropertyToHclTerraform(struct?: AwsChannel.MotionGraphicsConfigurationPropertyOutputReference | AwsChannel.MotionGraphicsConfigurationProperty): any;
export declare function awsChannelNielsenConfigurationPropertyToTerraform(struct?: AwsChannel.NielsenConfigurationPropertyOutputReference | AwsChannel.NielsenConfigurationProperty): any;
export declare function awsChannelNielsenConfigurationPropertyToHclTerraform(struct?: AwsChannel.NielsenConfigurationPropertyOutputReference | AwsChannel.NielsenConfigurationProperty): any;
export declare function awsChannelArchiveS3SettingsPropertyToTerraform(struct?: AwsChannel.ArchiveS3SettingsPropertyOutputReference | AwsChannel.ArchiveS3SettingsProperty): any;
export declare function awsChannelArchiveS3SettingsPropertyToHclTerraform(struct?: AwsChannel.ArchiveS3SettingsPropertyOutputReference | AwsChannel.ArchiveS3SettingsProperty): any;
export declare function awsChannelArchiveCdnSettingsPropertyToTerraform(struct?: AwsChannel.ArchiveCdnSettingsPropertyOutputReference | AwsChannel.ArchiveCdnSettingsProperty): any;
export declare function awsChannelArchiveCdnSettingsPropertyToHclTerraform(struct?: AwsChannel.ArchiveCdnSettingsPropertyOutputReference | AwsChannel.ArchiveCdnSettingsProperty): any;
export declare function awsChannelEncoderSettingsOutputGroupsOutputGroupSettingsArchiveGroupSettingsDestinationPropertyToTerraform(struct?: AwsChannel.EncoderSettingsOutputGroupsOutputGroupSettingsArchiveGroupSettingsDestinationPropertyOutputReference | AwsChannel.EncoderSettingsOutputGroupsOutputGroupSettingsArchiveGroupSettingsDestinationProperty): any;
export declare function awsChannelEncoderSettingsOutputGroupsOutputGroupSettingsArchiveGroupSettingsDestinationPropertyToHclTerraform(struct?: AwsChannel.EncoderSettingsOutputGroupsOutputGroupSettingsArchiveGroupSettingsDestinationPropertyOutputReference | AwsChannel.EncoderSettingsOutputGroupsOutputGroupSettingsArchiveGroupSettingsDestinationProperty): any;
export declare function awsChannelArchiveGroupSettingsPropertyToTerraform(struct?: AwsChannel.ArchiveGroupSettingsProperty | cdktn.IResolvable): any;
export declare function awsChannelArchiveGroupSettingsPropertyToHclTerraform(struct?: AwsChannel.ArchiveGroupSettingsProperty | cdktn.IResolvable): any;
export declare function awsChannelEncoderSettingsOutputGroupsOutputGroupSettingsFrameCaptureGroupSettingsDestinationPropertyToTerraform(struct?: AwsChannel.EncoderSettingsOutputGroupsOutputGroupSettingsFrameCaptureGroupSettingsDestinationPropertyOutputReference | AwsChannel.EncoderSettingsOutputGroupsOutputGroupSettingsFrameCaptureGroupSettingsDestinationProperty): any;
export declare function awsChannelEncoderSettingsOutputGroupsOutputGroupSettingsFrameCaptureGroupSettingsDestinationPropertyToHclTerraform(struct?: AwsChannel.EncoderSettingsOutputGroupsOutputGroupSettingsFrameCaptureGroupSettingsDestinationPropertyOutputReference | AwsChannel.EncoderSettingsOutputGroupsOutputGroupSettingsFrameCaptureGroupSettingsDestinationProperty): any;
export declare function awsChannelFrameCaptureS3SettingsPropertyToTerraform(struct?: AwsChannel.FrameCaptureS3SettingsPropertyOutputReference | AwsChannel.FrameCaptureS3SettingsProperty): any;
export declare function awsChannelFrameCaptureS3SettingsPropertyToHclTerraform(struct?: AwsChannel.FrameCaptureS3SettingsPropertyOutputReference | AwsChannel.FrameCaptureS3SettingsProperty): any;
export declare function awsChannelFrameCaptureCdnSettingsPropertyToTerraform(struct?: AwsChannel.FrameCaptureCdnSettingsPropertyOutputReference | AwsChannel.FrameCaptureCdnSettingsProperty): any;
export declare function awsChannelFrameCaptureCdnSettingsPropertyToHclTerraform(struct?: AwsChannel.FrameCaptureCdnSettingsPropertyOutputReference | AwsChannel.FrameCaptureCdnSettingsProperty): any;
export declare function awsChannelFrameCaptureGroupSettingsPropertyToTerraform(struct?: AwsChannel.FrameCaptureGroupSettingsPropertyOutputReference | AwsChannel.FrameCaptureGroupSettingsProperty): any;
export declare function awsChannelFrameCaptureGroupSettingsPropertyToHclTerraform(struct?: AwsChannel.FrameCaptureGroupSettingsPropertyOutputReference | AwsChannel.FrameCaptureGroupSettingsProperty): any;
export declare function awsChannelCaptionLanguageMappingsPropertyToTerraform(struct?: AwsChannel.CaptionLanguageMappingsProperty | cdktn.IResolvable): any;
export declare function awsChannelCaptionLanguageMappingsPropertyToHclTerraform(struct?: AwsChannel.CaptionLanguageMappingsProperty | cdktn.IResolvable): any;
export declare function awsChannelEncoderSettingsOutputGroupsOutputGroupSettingsHlsGroupSettingsDestinationPropertyToTerraform(struct?: AwsChannel.EncoderSettingsOutputGroupsOutputGroupSettingsHlsGroupSettingsDestinationPropertyOutputReference | AwsChannel.EncoderSettingsOutputGroupsOutputGroupSettingsHlsGroupSettingsDestinationProperty): any;
export declare function awsChannelEncoderSettingsOutputGroupsOutputGroupSettingsHlsGroupSettingsDestinationPropertyToHclTerraform(struct?: AwsChannel.EncoderSettingsOutputGroupsOutputGroupSettingsHlsGroupSettingsDestinationPropertyOutputReference | AwsChannel.EncoderSettingsOutputGroupsOutputGroupSettingsHlsGroupSettingsDestinationProperty): any;
export declare function awsChannelHlsAkamaiSettingsPropertyToTerraform(struct?: AwsChannel.HlsAkamaiSettingsPropertyOutputReference | AwsChannel.HlsAkamaiSettingsProperty): any;
export declare function awsChannelHlsAkamaiSettingsPropertyToHclTerraform(struct?: AwsChannel.HlsAkamaiSettingsPropertyOutputReference | AwsChannel.HlsAkamaiSettingsProperty): any;
export declare function awsChannelHlsBasicPutSettingsPropertyToTerraform(struct?: AwsChannel.HlsBasicPutSettingsPropertyOutputReference | AwsChannel.HlsBasicPutSettingsProperty): any;
export declare function awsChannelHlsBasicPutSettingsPropertyToHclTerraform(struct?: AwsChannel.HlsBasicPutSettingsPropertyOutputReference | AwsChannel.HlsBasicPutSettingsProperty): any;
export declare function awsChannelHlsMediaStoreSettingsPropertyToTerraform(struct?: AwsChannel.HlsMediaStoreSettingsPropertyOutputReference | AwsChannel.HlsMediaStoreSettingsProperty): any;
export declare function awsChannelHlsMediaStoreSettingsPropertyToHclTerraform(struct?: AwsChannel.HlsMediaStoreSettingsPropertyOutputReference | AwsChannel.HlsMediaStoreSettingsProperty): any;
export declare function awsChannelHlsS3SettingsPropertyToTerraform(struct?: AwsChannel.HlsS3SettingsPropertyOutputReference | AwsChannel.HlsS3SettingsProperty): any;
export declare function awsChannelHlsS3SettingsPropertyToHclTerraform(struct?: AwsChannel.HlsS3SettingsPropertyOutputReference | AwsChannel.HlsS3SettingsProperty): any;
export declare function awsChannelHlsWebdavSettingsPropertyToTerraform(struct?: AwsChannel.HlsWebdavSettingsPropertyOutputReference | AwsChannel.HlsWebdavSettingsProperty): any;
export declare function awsChannelHlsWebdavSettingsPropertyToHclTerraform(struct?: AwsChannel.HlsWebdavSettingsPropertyOutputReference | AwsChannel.HlsWebdavSettingsProperty): any;
export declare function awsChannelHlsCdnSettingsPropertyToTerraform(struct?: AwsChannel.HlsCdnSettingsProperty | cdktn.IResolvable): any;
export declare function awsChannelHlsCdnSettingsPropertyToHclTerraform(struct?: AwsChannel.HlsCdnSettingsProperty | cdktn.IResolvable): any;
export declare function awsChannelKeyProviderServerPropertyToTerraform(struct?: AwsChannel.KeyProviderServerPropertyOutputReference | AwsChannel.KeyProviderServerProperty): any;
export declare function awsChannelKeyProviderServerPropertyToHclTerraform(struct?: AwsChannel.KeyProviderServerPropertyOutputReference | AwsChannel.KeyProviderServerProperty): any;
export declare function awsChannelStaticKeySettingsPropertyToTerraform(struct?: AwsChannel.StaticKeySettingsProperty | cdktn.IResolvable): any;
export declare function awsChannelStaticKeySettingsPropertyToHclTerraform(struct?: AwsChannel.StaticKeySettingsProperty | cdktn.IResolvable): any;
export declare function awsChannelKeyProviderSettingsPropertyToTerraform(struct?: AwsChannel.KeyProviderSettingsPropertyOutputReference | AwsChannel.KeyProviderSettingsProperty): any;
export declare function awsChannelKeyProviderSettingsPropertyToHclTerraform(struct?: AwsChannel.KeyProviderSettingsPropertyOutputReference | AwsChannel.KeyProviderSettingsProperty): any;
export declare function awsChannelHlsGroupSettingsPropertyToTerraform(struct?: AwsChannel.HlsGroupSettingsPropertyOutputReference | AwsChannel.HlsGroupSettingsProperty): any;
export declare function awsChannelHlsGroupSettingsPropertyToHclTerraform(struct?: AwsChannel.HlsGroupSettingsPropertyOutputReference | AwsChannel.HlsGroupSettingsProperty): any;
export declare function awsChannelEncoderSettingsOutputGroupsOutputGroupSettingsMediaPackageGroupSettingsDestinationPropertyToTerraform(struct?: AwsChannel.EncoderSettingsOutputGroupsOutputGroupSettingsMediaPackageGroupSettingsDestinationPropertyOutputReference | AwsChannel.EncoderSettingsOutputGroupsOutputGroupSettingsMediaPackageGroupSettingsDestinationProperty): any;
export declare function awsChannelEncoderSettingsOutputGroupsOutputGroupSettingsMediaPackageGroupSettingsDestinationPropertyToHclTerraform(struct?: AwsChannel.EncoderSettingsOutputGroupsOutputGroupSettingsMediaPackageGroupSettingsDestinationPropertyOutputReference | AwsChannel.EncoderSettingsOutputGroupsOutputGroupSettingsMediaPackageGroupSettingsDestinationProperty): any;
export declare function awsChannelMediaPackageGroupSettingsPropertyToTerraform(struct?: AwsChannel.MediaPackageGroupSettingsPropertyOutputReference | AwsChannel.MediaPackageGroupSettingsProperty): any;
export declare function awsChannelMediaPackageGroupSettingsPropertyToHclTerraform(struct?: AwsChannel.MediaPackageGroupSettingsPropertyOutputReference | AwsChannel.MediaPackageGroupSettingsProperty): any;
export declare function awsChannelEncoderSettingsOutputGroupsOutputGroupSettingsMsSmoothGroupSettingsDestinationPropertyToTerraform(struct?: AwsChannel.EncoderSettingsOutputGroupsOutputGroupSettingsMsSmoothGroupSettingsDestinationPropertyOutputReference | AwsChannel.EncoderSettingsOutputGroupsOutputGroupSettingsMsSmoothGroupSettingsDestinationProperty): any;
export declare function awsChannelEncoderSettingsOutputGroupsOutputGroupSettingsMsSmoothGroupSettingsDestinationPropertyToHclTerraform(struct?: AwsChannel.EncoderSettingsOutputGroupsOutputGroupSettingsMsSmoothGroupSettingsDestinationPropertyOutputReference | AwsChannel.EncoderSettingsOutputGroupsOutputGroupSettingsMsSmoothGroupSettingsDestinationProperty): any;
export declare function awsChannelMsSmoothGroupSettingsPropertyToTerraform(struct?: AwsChannel.MsSmoothGroupSettingsPropertyOutputReference | AwsChannel.MsSmoothGroupSettingsProperty): any;
export declare function awsChannelMsSmoothGroupSettingsPropertyToHclTerraform(struct?: AwsChannel.MsSmoothGroupSettingsPropertyOutputReference | AwsChannel.MsSmoothGroupSettingsProperty): any;
export declare function awsChannelMultiplexGroupSettingsPropertyToTerraform(struct?: AwsChannel.MultiplexGroupSettingsPropertyOutputReference | AwsChannel.MultiplexGroupSettingsProperty): any;
export declare function awsChannelMultiplexGroupSettingsPropertyToHclTerraform(struct?: AwsChannel.MultiplexGroupSettingsPropertyOutputReference | AwsChannel.MultiplexGroupSettingsProperty): any;
export declare function awsChannelRtmpGroupSettingsPropertyToTerraform(struct?: AwsChannel.RtmpGroupSettingsPropertyOutputReference | AwsChannel.RtmpGroupSettingsProperty): any;
export declare function awsChannelRtmpGroupSettingsPropertyToHclTerraform(struct?: AwsChannel.RtmpGroupSettingsPropertyOutputReference | AwsChannel.RtmpGroupSettingsProperty): any;
export declare function awsChannelUdpGroupSettingsPropertyToTerraform(struct?: AwsChannel.UdpGroupSettingsPropertyOutputReference | AwsChannel.UdpGroupSettingsProperty): any;
export declare function awsChannelUdpGroupSettingsPropertyToHclTerraform(struct?: AwsChannel.UdpGroupSettingsPropertyOutputReference | AwsChannel.UdpGroupSettingsProperty): any;
export declare function awsChannelOutputGroupSettingsPropertyToTerraform(struct?: AwsChannel.OutputGroupSettingsPropertyOutputReference | AwsChannel.OutputGroupSettingsProperty): any;
export declare function awsChannelOutputGroupSettingsPropertyToHclTerraform(struct?: AwsChannel.OutputGroupSettingsPropertyOutputReference | AwsChannel.OutputGroupSettingsProperty): any;
export declare function awsChannelEncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsDvbNitSettingsPropertyToTerraform(struct?: AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsDvbNitSettingsPropertyOutputReference | AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsDvbNitSettingsProperty): any;
export declare function awsChannelEncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsDvbNitSettingsPropertyToHclTerraform(struct?: AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsDvbNitSettingsPropertyOutputReference | AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsDvbNitSettingsProperty): any;
export declare function awsChannelEncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsDvbSdtSettingsPropertyToTerraform(struct?: AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsDvbSdtSettingsPropertyOutputReference | AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsDvbSdtSettingsProperty): any;
export declare function awsChannelEncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsDvbSdtSettingsPropertyToHclTerraform(struct?: AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsDvbSdtSettingsPropertyOutputReference | AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsDvbSdtSettingsProperty): any;
export declare function awsChannelEncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsDvbTdtSettingsPropertyToTerraform(struct?: AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsDvbTdtSettingsPropertyOutputReference | AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsDvbTdtSettingsProperty): any;
export declare function awsChannelEncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsDvbTdtSettingsPropertyToHclTerraform(struct?: AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsDvbTdtSettingsPropertyOutputReference | AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsDvbTdtSettingsProperty): any;
export declare function awsChannelEncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsPropertyToTerraform(struct?: AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsPropertyOutputReference | AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsProperty): any;
export declare function awsChannelEncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsPropertyToHclTerraform(struct?: AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsPropertyOutputReference | AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsProperty): any;
export declare function awsChannelRawSettingsPropertyToTerraform(struct?: AwsChannel.RawSettingsPropertyOutputReference | AwsChannel.RawSettingsProperty): any;
export declare function awsChannelRawSettingsPropertyToHclTerraform(struct?: AwsChannel.RawSettingsPropertyOutputReference | AwsChannel.RawSettingsProperty): any;
export declare function awsChannelEncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsPropertyToTerraform(struct?: AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsPropertyOutputReference | AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsProperty): any;
export declare function awsChannelEncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsPropertyToHclTerraform(struct?: AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsPropertyOutputReference | AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsProperty): any;
export declare function awsChannelArchiveOutputSettingsPropertyToTerraform(struct?: AwsChannel.ArchiveOutputSettingsPropertyOutputReference | AwsChannel.ArchiveOutputSettingsProperty): any;
export declare function awsChannelArchiveOutputSettingsPropertyToHclTerraform(struct?: AwsChannel.ArchiveOutputSettingsPropertyOutputReference | AwsChannel.ArchiveOutputSettingsProperty): any;
export declare function awsChannelFrameCaptureOutputSettingsPropertyToTerraform(struct?: AwsChannel.FrameCaptureOutputSettingsPropertyOutputReference | AwsChannel.FrameCaptureOutputSettingsProperty): any;
export declare function awsChannelFrameCaptureOutputSettingsPropertyToHclTerraform(struct?: AwsChannel.FrameCaptureOutputSettingsPropertyOutputReference | AwsChannel.FrameCaptureOutputSettingsProperty): any;
export declare function awsChannelAudioOnlyImagePropertyToTerraform(struct?: AwsChannel.AudioOnlyImagePropertyOutputReference | AwsChannel.AudioOnlyImageProperty): any;
export declare function awsChannelAudioOnlyImagePropertyToHclTerraform(struct?: AwsChannel.AudioOnlyImagePropertyOutputReference | AwsChannel.AudioOnlyImageProperty): any;
export declare function awsChannelAudioOnlyHlsSettingsPropertyToTerraform(struct?: AwsChannel.AudioOnlyHlsSettingsPropertyOutputReference | AwsChannel.AudioOnlyHlsSettingsProperty): any;
export declare function awsChannelAudioOnlyHlsSettingsPropertyToHclTerraform(struct?: AwsChannel.AudioOnlyHlsSettingsPropertyOutputReference | AwsChannel.AudioOnlyHlsSettingsProperty): any;
export declare function awsChannelFmp4HlsSettingsPropertyToTerraform(struct?: AwsChannel.Fmp4HlsSettingsPropertyOutputReference | AwsChannel.Fmp4HlsSettingsProperty): any;
export declare function awsChannelFmp4HlsSettingsPropertyToHclTerraform(struct?: AwsChannel.Fmp4HlsSettingsPropertyOutputReference | AwsChannel.Fmp4HlsSettingsProperty): any;
export declare function awsChannelFrameCaptureHlsSettingsPropertyToTerraform(struct?: AwsChannel.FrameCaptureHlsSettingsPropertyOutputReference | AwsChannel.FrameCaptureHlsSettingsProperty): any;
export declare function awsChannelFrameCaptureHlsSettingsPropertyToHclTerraform(struct?: AwsChannel.FrameCaptureHlsSettingsPropertyOutputReference | AwsChannel.FrameCaptureHlsSettingsProperty): any;
export declare function awsChannelM3u8SettingsPropertyToTerraform(struct?: AwsChannel.M3u8SettingsPropertyOutputReference | AwsChannel.M3u8SettingsProperty): any;
export declare function awsChannelM3u8SettingsPropertyToHclTerraform(struct?: AwsChannel.M3u8SettingsPropertyOutputReference | AwsChannel.M3u8SettingsProperty): any;
export declare function awsChannelStandardHlsSettingsPropertyToTerraform(struct?: AwsChannel.StandardHlsSettingsPropertyOutputReference | AwsChannel.StandardHlsSettingsProperty): any;
export declare function awsChannelStandardHlsSettingsPropertyToHclTerraform(struct?: AwsChannel.StandardHlsSettingsPropertyOutputReference | AwsChannel.StandardHlsSettingsProperty): any;
export declare function awsChannelHlsSettingsPropertyToTerraform(struct?: AwsChannel.HlsSettingsPropertyOutputReference | AwsChannel.HlsSettingsProperty): any;
export declare function awsChannelHlsSettingsPropertyToHclTerraform(struct?: AwsChannel.HlsSettingsPropertyOutputReference | AwsChannel.HlsSettingsProperty): any;
export declare function awsChannelHlsOutputSettingsPropertyToTerraform(struct?: AwsChannel.HlsOutputSettingsPropertyOutputReference | AwsChannel.HlsOutputSettingsProperty): any;
export declare function awsChannelHlsOutputSettingsPropertyToHclTerraform(struct?: AwsChannel.HlsOutputSettingsPropertyOutputReference | AwsChannel.HlsOutputSettingsProperty): any;
export declare function awsChannelMediaPackageOutputSettingsPropertyToTerraform(struct?: AwsChannel.MediaPackageOutputSettingsPropertyOutputReference | AwsChannel.MediaPackageOutputSettingsProperty): any;
export declare function awsChannelMediaPackageOutputSettingsPropertyToHclTerraform(struct?: AwsChannel.MediaPackageOutputSettingsPropertyOutputReference | AwsChannel.MediaPackageOutputSettingsProperty): any;
export declare function awsChannelMsSmoothOutputSettingsPropertyToTerraform(struct?: AwsChannel.MsSmoothOutputSettingsPropertyOutputReference | AwsChannel.MsSmoothOutputSettingsProperty): any;
export declare function awsChannelMsSmoothOutputSettingsPropertyToHclTerraform(struct?: AwsChannel.MsSmoothOutputSettingsPropertyOutputReference | AwsChannel.MsSmoothOutputSettingsProperty): any;
export declare function awsChannelEncoderSettingsOutputGroupsOutputsOutputSettingsMultiplexOutputSettingsDestinationPropertyToTerraform(struct?: AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsMultiplexOutputSettingsDestinationPropertyOutputReference | AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsMultiplexOutputSettingsDestinationProperty): any;
export declare function awsChannelEncoderSettingsOutputGroupsOutputsOutputSettingsMultiplexOutputSettingsDestinationPropertyToHclTerraform(struct?: AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsMultiplexOutputSettingsDestinationPropertyOutputReference | AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsMultiplexOutputSettingsDestinationProperty): any;
export declare function awsChannelMultiplexOutputSettingsPropertyToTerraform(struct?: AwsChannel.MultiplexOutputSettingsPropertyOutputReference | AwsChannel.MultiplexOutputSettingsProperty): any;
export declare function awsChannelMultiplexOutputSettingsPropertyToHclTerraform(struct?: AwsChannel.MultiplexOutputSettingsPropertyOutputReference | AwsChannel.MultiplexOutputSettingsProperty): any;
export declare function awsChannelEncoderSettingsOutputGroupsOutputsOutputSettingsRtmpOutputSettingsDestinationPropertyToTerraform(struct?: AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsRtmpOutputSettingsDestinationPropertyOutputReference | AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsRtmpOutputSettingsDestinationProperty): any;
export declare function awsChannelEncoderSettingsOutputGroupsOutputsOutputSettingsRtmpOutputSettingsDestinationPropertyToHclTerraform(struct?: AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsRtmpOutputSettingsDestinationPropertyOutputReference | AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsRtmpOutputSettingsDestinationProperty): any;
export declare function awsChannelRtmpOutputSettingsPropertyToTerraform(struct?: AwsChannel.RtmpOutputSettingsPropertyOutputReference | AwsChannel.RtmpOutputSettingsProperty): any;
export declare function awsChannelRtmpOutputSettingsPropertyToHclTerraform(struct?: AwsChannel.RtmpOutputSettingsPropertyOutputReference | AwsChannel.RtmpOutputSettingsProperty): any;
export declare function awsChannelEncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsDvbNitSettingsPropertyToTerraform(struct?: AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsDvbNitSettingsPropertyOutputReference | AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsDvbNitSettingsProperty): any;
export declare function awsChannelEncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsDvbNitSettingsPropertyToHclTerraform(struct?: AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsDvbNitSettingsPropertyOutputReference | AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsDvbNitSettingsProperty): any;
export declare function awsChannelEncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsDvbSdtSettingsPropertyToTerraform(struct?: AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsDvbSdtSettingsPropertyOutputReference | AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsDvbSdtSettingsProperty): any;
export declare function awsChannelEncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsDvbSdtSettingsPropertyToHclTerraform(struct?: AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsDvbSdtSettingsPropertyOutputReference | AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsDvbSdtSettingsProperty): any;
export declare function awsChannelEncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsDvbTdtSettingsPropertyToTerraform(struct?: AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsDvbTdtSettingsPropertyOutputReference | AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsDvbTdtSettingsProperty): any;
export declare function awsChannelEncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsDvbTdtSettingsPropertyToHclTerraform(struct?: AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsDvbTdtSettingsPropertyOutputReference | AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsDvbTdtSettingsProperty): any;
export declare function awsChannelEncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsPropertyToTerraform(struct?: AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsPropertyOutputReference | AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsProperty): any;
export declare function awsChannelEncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsPropertyToHclTerraform(struct?: AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsPropertyOutputReference | AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsProperty): any;
export declare function awsChannelEncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsPropertyToTerraform(struct?: AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsPropertyOutputReference | AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsProperty): any;
export declare function awsChannelEncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsPropertyToHclTerraform(struct?: AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsPropertyOutputReference | AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsProperty): any;
export declare function awsChannelEncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsDestinationPropertyToTerraform(struct?: AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsDestinationPropertyOutputReference | AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsDestinationProperty): any;
export declare function awsChannelEncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsDestinationPropertyToHclTerraform(struct?: AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsDestinationPropertyOutputReference | AwsChannel.EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsDestinationProperty): any;
export declare function awsChannelFecOutputSettingsPropertyToTerraform(struct?: AwsChannel.FecOutputSettingsPropertyOutputReference | AwsChannel.FecOutputSettingsProperty): any;
export declare function awsChannelFecOutputSettingsPropertyToHclTerraform(struct?: AwsChannel.FecOutputSettingsPropertyOutputReference | AwsChannel.FecOutputSettingsProperty): any;
export declare function awsChannelUdpOutputSettingsPropertyToTerraform(struct?: AwsChannel.UdpOutputSettingsPropertyOutputReference | AwsChannel.UdpOutputSettingsProperty): any;
export declare function awsChannelUdpOutputSettingsPropertyToHclTerraform(struct?: AwsChannel.UdpOutputSettingsPropertyOutputReference | AwsChannel.UdpOutputSettingsProperty): any;
export declare function awsChannelOutputSettingsPropertyToTerraform(struct?: AwsChannel.OutputSettingsPropertyOutputReference | AwsChannel.OutputSettingsProperty): any;
export declare function awsChannelOutputSettingsPropertyToHclTerraform(struct?: AwsChannel.OutputSettingsPropertyOutputReference | AwsChannel.OutputSettingsProperty): any;
export declare function awsChannelOutputsPropertyToTerraform(struct?: AwsChannel.OutputsProperty | cdktn.IResolvable): any;
export declare function awsChannelOutputsPropertyToHclTerraform(struct?: AwsChannel.OutputsProperty | cdktn.IResolvable): any;
export declare function awsChannelOutputGroupsPropertyToTerraform(struct?: AwsChannel.OutputGroupsProperty | cdktn.IResolvable): any;
export declare function awsChannelOutputGroupsPropertyToHclTerraform(struct?: AwsChannel.OutputGroupsProperty | cdktn.IResolvable): any;
export declare function awsChannelTimecodeConfigPropertyToTerraform(struct?: AwsChannel.TimecodeConfigPropertyOutputReference | AwsChannel.TimecodeConfigProperty): any;
export declare function awsChannelTimecodeConfigPropertyToHclTerraform(struct?: AwsChannel.TimecodeConfigPropertyOutputReference | AwsChannel.TimecodeConfigProperty): any;
export declare function awsChannelFrameCaptureSettingsPropertyToTerraform(struct?: AwsChannel.FrameCaptureSettingsPropertyOutputReference | AwsChannel.FrameCaptureSettingsProperty): any;
export declare function awsChannelFrameCaptureSettingsPropertyToHclTerraform(struct?: AwsChannel.FrameCaptureSettingsPropertyOutputReference | AwsChannel.FrameCaptureSettingsProperty): any;
export declare function awsChannelEncoderSettingsVideoDescriptionsCodecSettingsH264SettingsFilterSettingsTemporalFilterSettingsPropertyToTerraform(struct?: AwsChannel.EncoderSettingsVideoDescriptionsCodecSettingsH264SettingsFilterSettingsTemporalFilterSettingsPropertyOutputReference | AwsChannel.EncoderSettingsVideoDescriptionsCodecSettingsH264SettingsFilterSettingsTemporalFilterSettingsProperty): any;
export declare function awsChannelEncoderSettingsVideoDescriptionsCodecSettingsH264SettingsFilterSettingsTemporalFilterSettingsPropertyToHclTerraform(struct?: AwsChannel.EncoderSettingsVideoDescriptionsCodecSettingsH264SettingsFilterSettingsTemporalFilterSettingsPropertyOutputReference | AwsChannel.EncoderSettingsVideoDescriptionsCodecSettingsH264SettingsFilterSettingsTemporalFilterSettingsProperty): any;
export declare function awsChannelEncoderSettingsVideoDescriptionsCodecSettingsH264SettingsFilterSettingsPropertyToTerraform(struct?: AwsChannel.EncoderSettingsVideoDescriptionsCodecSettingsH264SettingsFilterSettingsPropertyOutputReference | AwsChannel.EncoderSettingsVideoDescriptionsCodecSettingsH264SettingsFilterSettingsProperty): any;
export declare function awsChannelEncoderSettingsVideoDescriptionsCodecSettingsH264SettingsFilterSettingsPropertyToHclTerraform(struct?: AwsChannel.EncoderSettingsVideoDescriptionsCodecSettingsH264SettingsFilterSettingsPropertyOutputReference | AwsChannel.EncoderSettingsVideoDescriptionsCodecSettingsH264SettingsFilterSettingsProperty): any;
export declare function awsChannelH264SettingsPropertyToTerraform(struct?: AwsChannel.H264SettingsPropertyOutputReference | AwsChannel.H264SettingsProperty): any;
export declare function awsChannelH264SettingsPropertyToHclTerraform(struct?: AwsChannel.H264SettingsPropertyOutputReference | AwsChannel.H264SettingsProperty): any;
export declare function awsChannelColorSpacePassthroughSettingsPropertyToTerraform(struct?: AwsChannel.ColorSpacePassthroughSettingsPropertyOutputReference | AwsChannel.ColorSpacePassthroughSettingsProperty): any;
export declare function awsChannelColorSpacePassthroughSettingsPropertyToHclTerraform(struct?: AwsChannel.ColorSpacePassthroughSettingsPropertyOutputReference | AwsChannel.ColorSpacePassthroughSettingsProperty): any;
export declare function awsChannelDolbyVision81SettingsPropertyToTerraform(struct?: AwsChannel.DolbyVision81SettingsPropertyOutputReference | AwsChannel.DolbyVision81SettingsProperty): any;
export declare function awsChannelDolbyVision81SettingsPropertyToHclTerraform(struct?: AwsChannel.DolbyVision81SettingsPropertyOutputReference | AwsChannel.DolbyVision81SettingsProperty): any;
export declare function awsChannelHdr10SettingsPropertyToTerraform(struct?: AwsChannel.Hdr10SettingsPropertyOutputReference | AwsChannel.Hdr10SettingsProperty): any;
export declare function awsChannelHdr10SettingsPropertyToHclTerraform(struct?: AwsChannel.Hdr10SettingsPropertyOutputReference | AwsChannel.Hdr10SettingsProperty): any;
export declare function awsChannelRec601SettingsPropertyToTerraform(struct?: AwsChannel.Rec601SettingsPropertyOutputReference | AwsChannel.Rec601SettingsProperty): any;
export declare function awsChannelRec601SettingsPropertyToHclTerraform(struct?: AwsChannel.Rec601SettingsPropertyOutputReference | AwsChannel.Rec601SettingsProperty): any;
export declare function awsChannelRec709SettingsPropertyToTerraform(struct?: AwsChannel.Rec709SettingsPropertyOutputReference | AwsChannel.Rec709SettingsProperty): any;
export declare function awsChannelRec709SettingsPropertyToHclTerraform(struct?: AwsChannel.Rec709SettingsPropertyOutputReference | AwsChannel.Rec709SettingsProperty): any;
export declare function awsChannelColorSpaceSettingsPropertyToTerraform(struct?: AwsChannel.ColorSpaceSettingsPropertyOutputReference | AwsChannel.ColorSpaceSettingsProperty): any;
export declare function awsChannelColorSpaceSettingsPropertyToHclTerraform(struct?: AwsChannel.ColorSpaceSettingsPropertyOutputReference | AwsChannel.ColorSpaceSettingsProperty): any;
export declare function awsChannelEncoderSettingsVideoDescriptionsCodecSettingsH265SettingsFilterSettingsTemporalFilterSettingsPropertyToTerraform(struct?: AwsChannel.EncoderSettingsVideoDescriptionsCodecSettingsH265SettingsFilterSettingsTemporalFilterSettingsPropertyOutputReference | AwsChannel.EncoderSettingsVideoDescriptionsCodecSettingsH265SettingsFilterSettingsTemporalFilterSettingsProperty): any;
export declare function awsChannelEncoderSettingsVideoDescriptionsCodecSettingsH265SettingsFilterSettingsTemporalFilterSettingsPropertyToHclTerraform(struct?: AwsChannel.EncoderSettingsVideoDescriptionsCodecSettingsH265SettingsFilterSettingsTemporalFilterSettingsPropertyOutputReference | AwsChannel.EncoderSettingsVideoDescriptionsCodecSettingsH265SettingsFilterSettingsTemporalFilterSettingsProperty): any;
export declare function awsChannelEncoderSettingsVideoDescriptionsCodecSettingsH265SettingsFilterSettingsPropertyToTerraform(struct?: AwsChannel.EncoderSettingsVideoDescriptionsCodecSettingsH265SettingsFilterSettingsPropertyOutputReference | AwsChannel.EncoderSettingsVideoDescriptionsCodecSettingsH265SettingsFilterSettingsProperty): any;
export declare function awsChannelEncoderSettingsVideoDescriptionsCodecSettingsH265SettingsFilterSettingsPropertyToHclTerraform(struct?: AwsChannel.EncoderSettingsVideoDescriptionsCodecSettingsH265SettingsFilterSettingsPropertyOutputReference | AwsChannel.EncoderSettingsVideoDescriptionsCodecSettingsH265SettingsFilterSettingsProperty): any;
export declare function awsChannelTimecodeBurninSettingsPropertyToTerraform(struct?: AwsChannel.TimecodeBurninSettingsPropertyOutputReference | AwsChannel.TimecodeBurninSettingsProperty): any;
export declare function awsChannelTimecodeBurninSettingsPropertyToHclTerraform(struct?: AwsChannel.TimecodeBurninSettingsPropertyOutputReference | AwsChannel.TimecodeBurninSettingsProperty): any;
export declare function awsChannelH265SettingsPropertyToTerraform(struct?: AwsChannel.H265SettingsPropertyOutputReference | AwsChannel.H265SettingsProperty): any;
export declare function awsChannelH265SettingsPropertyToHclTerraform(struct?: AwsChannel.H265SettingsPropertyOutputReference | AwsChannel.H265SettingsProperty): any;
export declare function awsChannelEncoderSettingsVideoDescriptionsCodecSettingsPropertyToTerraform(struct?: AwsChannel.EncoderSettingsVideoDescriptionsCodecSettingsPropertyOutputReference | AwsChannel.EncoderSettingsVideoDescriptionsCodecSettingsProperty): any;
export declare function awsChannelEncoderSettingsVideoDescriptionsCodecSettingsPropertyToHclTerraform(struct?: AwsChannel.EncoderSettingsVideoDescriptionsCodecSettingsPropertyOutputReference | AwsChannel.EncoderSettingsVideoDescriptionsCodecSettingsProperty): any;
export declare function awsChannelVideoDescriptionsPropertyToTerraform(struct?: AwsChannel.VideoDescriptionsProperty | cdktn.IResolvable): any;
export declare function awsChannelVideoDescriptionsPropertyToHclTerraform(struct?: AwsChannel.VideoDescriptionsProperty | cdktn.IResolvable): any;
export declare function awsChannelEncoderSettingsPropertyToTerraform(struct?: AwsChannel.EncoderSettingsPropertyOutputReference | AwsChannel.EncoderSettingsProperty): any;
export declare function awsChannelEncoderSettingsPropertyToHclTerraform(struct?: AwsChannel.EncoderSettingsPropertyOutputReference | AwsChannel.EncoderSettingsProperty): any;
export declare function awsChannelAudioSilenceSettingsPropertyToTerraform(struct?: AwsChannel.AudioSilenceSettingsPropertyOutputReference | AwsChannel.AudioSilenceSettingsProperty): any;
export declare function awsChannelAudioSilenceSettingsPropertyToHclTerraform(struct?: AwsChannel.AudioSilenceSettingsPropertyOutputReference | AwsChannel.AudioSilenceSettingsProperty): any;
export declare function awsChannelInputLossSettingsPropertyToTerraform(struct?: AwsChannel.InputLossSettingsPropertyOutputReference | AwsChannel.InputLossSettingsProperty): any;
export declare function awsChannelInputLossSettingsPropertyToHclTerraform(struct?: AwsChannel.InputLossSettingsPropertyOutputReference | AwsChannel.InputLossSettingsProperty): any;
export declare function awsChannelVideoBlackSettingsPropertyToTerraform(struct?: AwsChannel.VideoBlackSettingsPropertyOutputReference | AwsChannel.VideoBlackSettingsProperty): any;
export declare function awsChannelVideoBlackSettingsPropertyToHclTerraform(struct?: AwsChannel.VideoBlackSettingsPropertyOutputReference | AwsChannel.VideoBlackSettingsProperty): any;
export declare function awsChannelFailoverConditionSettingsPropertyToTerraform(struct?: AwsChannel.FailoverConditionSettingsPropertyOutputReference | AwsChannel.FailoverConditionSettingsProperty): any;
export declare function awsChannelFailoverConditionSettingsPropertyToHclTerraform(struct?: AwsChannel.FailoverConditionSettingsPropertyOutputReference | AwsChannel.FailoverConditionSettingsProperty): any;
export declare function awsChannelFailoverConditionPropertyToTerraform(struct?: AwsChannel.FailoverConditionProperty | cdktn.IResolvable): any;
export declare function awsChannelFailoverConditionPropertyToHclTerraform(struct?: AwsChannel.FailoverConditionProperty | cdktn.IResolvable): any;
export declare function awsChannelAutomaticInputFailoverSettingsPropertyToTerraform(struct?: AwsChannel.AutomaticInputFailoverSettingsPropertyOutputReference | AwsChannel.AutomaticInputFailoverSettingsProperty): any;
export declare function awsChannelAutomaticInputFailoverSettingsPropertyToHclTerraform(struct?: AwsChannel.AutomaticInputFailoverSettingsPropertyOutputReference | AwsChannel.AutomaticInputFailoverSettingsProperty): any;
export declare function awsChannelAudioHlsRenditionSelectionPropertyToTerraform(struct?: AwsChannel.AudioHlsRenditionSelectionPropertyOutputReference | AwsChannel.AudioHlsRenditionSelectionProperty): any;
export declare function awsChannelAudioHlsRenditionSelectionPropertyToHclTerraform(struct?: AwsChannel.AudioHlsRenditionSelectionPropertyOutputReference | AwsChannel.AudioHlsRenditionSelectionProperty): any;
export declare function awsChannelAudioLanguageSelectionPropertyToTerraform(struct?: AwsChannel.AudioLanguageSelectionPropertyOutputReference | AwsChannel.AudioLanguageSelectionProperty): any;
export declare function awsChannelAudioLanguageSelectionPropertyToHclTerraform(struct?: AwsChannel.AudioLanguageSelectionPropertyOutputReference | AwsChannel.AudioLanguageSelectionProperty): any;
export declare function awsChannelAudioPidSelectionPropertyToTerraform(struct?: AwsChannel.AudioPidSelectionPropertyOutputReference | AwsChannel.AudioPidSelectionProperty): any;
export declare function awsChannelAudioPidSelectionPropertyToHclTerraform(struct?: AwsChannel.AudioPidSelectionPropertyOutputReference | AwsChannel.AudioPidSelectionProperty): any;
export declare function awsChannelDolbyEDecodePropertyToTerraform(struct?: AwsChannel.DolbyEDecodePropertyOutputReference | AwsChannel.DolbyEDecodeProperty): any;
export declare function awsChannelDolbyEDecodePropertyToHclTerraform(struct?: AwsChannel.DolbyEDecodePropertyOutputReference | AwsChannel.DolbyEDecodeProperty): any;
export declare function awsChannelTracksPropertyToTerraform(struct?: AwsChannel.TracksProperty | cdktn.IResolvable): any;
export declare function awsChannelTracksPropertyToHclTerraform(struct?: AwsChannel.TracksProperty | cdktn.IResolvable): any;
export declare function awsChannelAudioTrackSelectionPropertyToTerraform(struct?: AwsChannel.AudioTrackSelectionPropertyOutputReference | AwsChannel.AudioTrackSelectionProperty): any;
export declare function awsChannelAudioTrackSelectionPropertyToHclTerraform(struct?: AwsChannel.AudioTrackSelectionPropertyOutputReference | AwsChannel.AudioTrackSelectionProperty): any;
export declare function awsChannelInputAttachmentsInputSettingsAudioSelectorSelectorSettingsPropertyToTerraform(struct?: AwsChannel.InputAttachmentsInputSettingsAudioSelectorSelectorSettingsPropertyOutputReference | AwsChannel.InputAttachmentsInputSettingsAudioSelectorSelectorSettingsProperty): any;
export declare function awsChannelInputAttachmentsInputSettingsAudioSelectorSelectorSettingsPropertyToHclTerraform(struct?: AwsChannel.InputAttachmentsInputSettingsAudioSelectorSelectorSettingsPropertyOutputReference | AwsChannel.InputAttachmentsInputSettingsAudioSelectorSelectorSettingsProperty): any;
export declare function awsChannelAudioSelectorPropertyToTerraform(struct?: AwsChannel.AudioSelectorProperty | cdktn.IResolvable): any;
export declare function awsChannelAudioSelectorPropertyToHclTerraform(struct?: AwsChannel.AudioSelectorProperty | cdktn.IResolvable): any;
export declare function awsChannelAncillarySourceSettingsPropertyToTerraform(struct?: AwsChannel.AncillarySourceSettingsPropertyOutputReference | AwsChannel.AncillarySourceSettingsProperty): any;
export declare function awsChannelAncillarySourceSettingsPropertyToHclTerraform(struct?: AwsChannel.AncillarySourceSettingsPropertyOutputReference | AwsChannel.AncillarySourceSettingsProperty): any;
export declare function awsChannelAribSourceSettingsPropertyToTerraform(struct?: AwsChannel.AribSourceSettingsPropertyOutputReference | AwsChannel.AribSourceSettingsProperty): any;
export declare function awsChannelAribSourceSettingsPropertyToHclTerraform(struct?: AwsChannel.AribSourceSettingsPropertyOutputReference | AwsChannel.AribSourceSettingsProperty): any;
export declare function awsChannelDvbSubSourceSettingsPropertyToTerraform(struct?: AwsChannel.DvbSubSourceSettingsPropertyOutputReference | AwsChannel.DvbSubSourceSettingsProperty): any;
export declare function awsChannelDvbSubSourceSettingsPropertyToHclTerraform(struct?: AwsChannel.DvbSubSourceSettingsPropertyOutputReference | AwsChannel.DvbSubSourceSettingsProperty): any;
export declare function awsChannelEmbeddedSourceSettingsPropertyToTerraform(struct?: AwsChannel.EmbeddedSourceSettingsPropertyOutputReference | AwsChannel.EmbeddedSourceSettingsProperty): any;
export declare function awsChannelEmbeddedSourceSettingsPropertyToHclTerraform(struct?: AwsChannel.EmbeddedSourceSettingsPropertyOutputReference | AwsChannel.EmbeddedSourceSettingsProperty): any;
export declare function awsChannelScte20SourceSettingsPropertyToTerraform(struct?: AwsChannel.Scte20SourceSettingsPropertyOutputReference | AwsChannel.Scte20SourceSettingsProperty): any;
export declare function awsChannelScte20SourceSettingsPropertyToHclTerraform(struct?: AwsChannel.Scte20SourceSettingsPropertyOutputReference | AwsChannel.Scte20SourceSettingsProperty): any;
export declare function awsChannelScte27SourceSettingsPropertyToTerraform(struct?: AwsChannel.Scte27SourceSettingsPropertyOutputReference | AwsChannel.Scte27SourceSettingsProperty): any;
export declare function awsChannelScte27SourceSettingsPropertyToHclTerraform(struct?: AwsChannel.Scte27SourceSettingsPropertyOutputReference | AwsChannel.Scte27SourceSettingsProperty): any;
export declare function awsChannelOutputRectanglePropertyToTerraform(struct?: AwsChannel.OutputRectanglePropertyOutputReference | AwsChannel.OutputRectangleProperty): any;
export declare function awsChannelOutputRectanglePropertyToHclTerraform(struct?: AwsChannel.OutputRectanglePropertyOutputReference | AwsChannel.OutputRectangleProperty): any;
export declare function awsChannelTeletextSourceSettingsPropertyToTerraform(struct?: AwsChannel.TeletextSourceSettingsPropertyOutputReference | AwsChannel.TeletextSourceSettingsProperty): any;
export declare function awsChannelTeletextSourceSettingsPropertyToHclTerraform(struct?: AwsChannel.TeletextSourceSettingsPropertyOutputReference | AwsChannel.TeletextSourceSettingsProperty): any;
export declare function awsChannelInputAttachmentsInputSettingsCaptionSelectorSelectorSettingsPropertyToTerraform(struct?: AwsChannel.InputAttachmentsInputSettingsCaptionSelectorSelectorSettingsPropertyOutputReference | AwsChannel.InputAttachmentsInputSettingsCaptionSelectorSelectorSettingsProperty): any;
export declare function awsChannelInputAttachmentsInputSettingsCaptionSelectorSelectorSettingsPropertyToHclTerraform(struct?: AwsChannel.InputAttachmentsInputSettingsCaptionSelectorSelectorSettingsPropertyOutputReference | AwsChannel.InputAttachmentsInputSettingsCaptionSelectorSelectorSettingsProperty): any;
export declare function awsChannelCaptionSelectorPropertyToTerraform(struct?: AwsChannel.CaptionSelectorProperty | cdktn.IResolvable): any;
export declare function awsChannelCaptionSelectorPropertyToHclTerraform(struct?: AwsChannel.CaptionSelectorProperty | cdktn.IResolvable): any;
export declare function awsChannelHlsInputSettingsPropertyToTerraform(struct?: AwsChannel.HlsInputSettingsPropertyOutputReference | AwsChannel.HlsInputSettingsProperty): any;
export declare function awsChannelHlsInputSettingsPropertyToHclTerraform(struct?: AwsChannel.HlsInputSettingsPropertyOutputReference | AwsChannel.HlsInputSettingsProperty): any;
export declare function awsChannelNetworkInputSettingsPropertyToTerraform(struct?: AwsChannel.NetworkInputSettingsPropertyOutputReference | AwsChannel.NetworkInputSettingsProperty): any;
export declare function awsChannelNetworkInputSettingsPropertyToHclTerraform(struct?: AwsChannel.NetworkInputSettingsPropertyOutputReference | AwsChannel.NetworkInputSettingsProperty): any;
export declare function awsChannelVideoSelectorPropertyToTerraform(struct?: AwsChannel.VideoSelectorPropertyOutputReference | AwsChannel.VideoSelectorProperty): any;
export declare function awsChannelVideoSelectorPropertyToHclTerraform(struct?: AwsChannel.VideoSelectorPropertyOutputReference | AwsChannel.VideoSelectorProperty): any;
export declare function awsChannelInputSettingsPropertyToTerraform(struct?: AwsChannel.InputSettingsPropertyOutputReference | AwsChannel.InputSettingsProperty): any;
export declare function awsChannelInputSettingsPropertyToHclTerraform(struct?: AwsChannel.InputSettingsPropertyOutputReference | AwsChannel.InputSettingsProperty): any;
export declare function awsChannelInputAttachmentsPropertyToTerraform(struct?: AwsChannel.InputAttachmentsProperty | cdktn.IResolvable): any;
export declare function awsChannelInputAttachmentsPropertyToHclTerraform(struct?: AwsChannel.InputAttachmentsProperty | cdktn.IResolvable): any;
export declare function awsChannelInputSpecificationPropertyToTerraform(struct?: AwsChannel.InputSpecificationPropertyOutputReference | AwsChannel.InputSpecificationProperty): any;
export declare function awsChannelInputSpecificationPropertyToHclTerraform(struct?: AwsChannel.InputSpecificationPropertyOutputReference | AwsChannel.InputSpecificationProperty): any;
export declare function awsChannelMaintenancePropertyToTerraform(struct?: AwsChannel.MaintenancePropertyOutputReference | AwsChannel.MaintenanceProperty): any;
export declare function awsChannelMaintenancePropertyToHclTerraform(struct?: AwsChannel.MaintenancePropertyOutputReference | AwsChannel.MaintenanceProperty): any;
export declare function awsChannelTimeoutsPropertyToTerraform(struct?: AwsChannel.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsChannelTimeoutsPropertyToHclTerraform(struct?: AwsChannel.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsChannelVpcPropertyToTerraform(struct?: AwsChannel.VpcPropertyOutputReference | AwsChannel.VpcProperty): any;
export declare function awsChannelVpcPropertyToHclTerraform(struct?: AwsChannel.VpcPropertyOutputReference | AwsChannel.VpcProperty): any;
export declare namespace AwsChannel {
    interface CdiInputSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#resolution AwsChannel#resolution}
        */
        readonly resolution: string;
    }
    class CdiInputSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CdiInputSpecificationProperty | undefined;
        set internalValue(value: CdiInputSpecificationProperty | undefined);
        private _resolution?;
        get resolution(): string;
        set resolution(value: string);
        get resolutionInput(): string | undefined;
    }
    interface MediaPackageSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#channel_id AwsChannel#channel_id}
        */
        readonly channelId: string;
    }
    class MediaPackageSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MediaPackageSettingsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MediaPackageSettingsProperty | cdktn.IResolvable | undefined);
        private _channelId?;
        get channelId(): string;
        set channelId(value: string);
        get channelIdInput(): string | undefined;
    }
    class MediaPackageSettingsPropertyList extends cdktn.ComplexList {
        internalValue?: MediaPackageSettingsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MediaPackageSettingsPropertyOutputReference;
    }
    interface MultiplexSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#multiplex_id AwsChannel#multiplex_id}
        */
        readonly multiplexId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#program_name AwsChannel#program_name}
        */
        readonly programName: string;
    }
    class MultiplexSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MultiplexSettingsProperty | undefined;
        set internalValue(value: MultiplexSettingsProperty | undefined);
        private _multiplexId?;
        get multiplexId(): string;
        set multiplexId(value: string);
        get multiplexIdInput(): string | undefined;
        private _programName?;
        get programName(): string;
        set programName(value: string);
        get programNameInput(): string | undefined;
    }
    interface SettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#password_param AwsChannel#password_param}
        */
        readonly passwordParam?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#stream_name AwsChannel#stream_name}
        */
        readonly streamName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#url AwsChannel#url}
        */
        readonly url?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#username AwsChannel#username}
        */
        readonly username?: string;
    }
    class SettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SettingsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SettingsProperty | cdktn.IResolvable | undefined);
        private _passwordParam?;
        get passwordParam(): string;
        set passwordParam(value: string);
        resetPasswordParam(): void;
        get passwordParamInput(): string | undefined;
        private _streamName?;
        get streamName(): string;
        set streamName(value: string);
        resetStreamName(): void;
        get streamNameInput(): string | undefined;
        private _url?;
        get url(): string;
        set url(value: string);
        resetUrl(): void;
        get urlInput(): string | undefined;
        private _username?;
        get username(): string;
        set username(value: string);
        resetUsername(): void;
        get usernameInput(): string | undefined;
    }
    class SettingsPropertyList extends cdktn.ComplexList {
        internalValue?: SettingsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SettingsPropertyOutputReference;
    }
    interface DestinationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#id AwsChannel#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
        /**
        * media_package_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#media_package_settings AwsChannel#media_package_settings}
        */
        readonly mediaPackageSettings?: MediaPackageSettingsProperty[] | cdktn.IResolvable;
        /**
        * multiplex_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#multiplex_settings AwsChannel#multiplex_settings}
        */
        readonly multiplexSettings?: MultiplexSettingsProperty;
        /**
        * settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#settings AwsChannel#settings}
        */
        readonly settings?: SettingsProperty[] | cdktn.IResolvable;
    }
    class DestinationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DestinationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DestinationsProperty | cdktn.IResolvable | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
        private _mediaPackageSettings;
        get mediaPackageSettings(): MediaPackageSettingsPropertyList;
        putMediaPackageSettings(value: MediaPackageSettingsProperty[] | cdktn.IResolvable): void;
        resetMediaPackageSettings(): void;
        get mediaPackageSettingsInput(): cdktn.IResolvable | MediaPackageSettingsProperty[] | undefined;
        private _multiplexSettings;
        get multiplexSettings(): MultiplexSettingsPropertyOutputReference;
        putMultiplexSettings(value: MultiplexSettingsProperty): void;
        resetMultiplexSettings(): void;
        get multiplexSettingsInput(): MultiplexSettingsProperty | undefined;
        private _settings;
        get settings(): SettingsPropertyList;
        putSettings(value: SettingsProperty[] | cdktn.IResolvable): void;
        resetSettings(): void;
        get settingsInput(): cdktn.IResolvable | SettingsProperty[] | undefined;
    }
    class DestinationsPropertyList extends cdktn.ComplexList {
        internalValue?: DestinationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DestinationsPropertyOutputReference;
    }
    interface AudioNormalizationSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#algorithm AwsChannel#algorithm}
        */
        readonly algorithm?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#algorithm_control AwsChannel#algorithm_control}
        */
        readonly algorithmControl?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#target_lkfs AwsChannel#target_lkfs}
        */
        readonly targetLkfs?: number;
    }
    class AudioNormalizationSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AudioNormalizationSettingsProperty | undefined;
        set internalValue(value: AudioNormalizationSettingsProperty | undefined);
        private _algorithm?;
        get algorithm(): string;
        set algorithm(value: string);
        resetAlgorithm(): void;
        get algorithmInput(): string | undefined;
        private _algorithmControl?;
        get algorithmControl(): string;
        set algorithmControl(value: string);
        resetAlgorithmControl(): void;
        get algorithmControlInput(): string | undefined;
        private _targetLkfs?;
        get targetLkfs(): number;
        set targetLkfs(value: number);
        resetTargetLkfs(): void;
        get targetLkfsInput(): number | undefined;
    }
    interface NielsenCbetSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#cbet_check_digit_string AwsChannel#cbet_check_digit_string}
        */
        readonly cbetCheckDigitString: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#cbet_stepaside AwsChannel#cbet_stepaside}
        */
        readonly cbetStepaside: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#csid AwsChannel#csid}
        */
        readonly csid: string;
    }
    class NielsenCbetSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NielsenCbetSettingsProperty | undefined;
        set internalValue(value: NielsenCbetSettingsProperty | undefined);
        private _cbetCheckDigitString?;
        get cbetCheckDigitString(): string;
        set cbetCheckDigitString(value: string);
        get cbetCheckDigitStringInput(): string | undefined;
        private _cbetStepaside?;
        get cbetStepaside(): string;
        set cbetStepaside(value: string);
        get cbetStepasideInput(): string | undefined;
        private _csid?;
        get csid(): string;
        set csid(value: string);
        get csidInput(): string | undefined;
    }
    interface NielsenNaesIiNwSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#check_digit_string AwsChannel#check_digit_string}
        */
        readonly checkDigitString: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#sid AwsChannel#sid}
        */
        readonly sid: number;
    }
    class NielsenNaesIiNwSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NielsenNaesIiNwSettingsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NielsenNaesIiNwSettingsProperty | cdktn.IResolvable | undefined);
        private _checkDigitString?;
        get checkDigitString(): string;
        set checkDigitString(value: string);
        get checkDigitStringInput(): string | undefined;
        private _sid?;
        get sid(): number;
        set sid(value: number);
        get sidInput(): number | undefined;
    }
    class NielsenNaesIiNwSettingsPropertyList extends cdktn.ComplexList {
        internalValue?: NielsenNaesIiNwSettingsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NielsenNaesIiNwSettingsPropertyOutputReference;
    }
    interface NielsenWatermarksSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#nielsen_distribution_type AwsChannel#nielsen_distribution_type}
        */
        readonly nielsenDistributionType?: string;
        /**
        * nielsen_cbet_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#nielsen_cbet_settings AwsChannel#nielsen_cbet_settings}
        */
        readonly nielsenCbetSettings?: NielsenCbetSettingsProperty;
        /**
        * nielsen_naes_ii_nw_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#nielsen_naes_ii_nw_settings AwsChannel#nielsen_naes_ii_nw_settings}
        */
        readonly nielsenNaesIiNwSettings?: NielsenNaesIiNwSettingsProperty[] | cdktn.IResolvable;
    }
    class NielsenWatermarksSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NielsenWatermarksSettingsProperty | undefined;
        set internalValue(value: NielsenWatermarksSettingsProperty | undefined);
        private _nielsenDistributionType?;
        get nielsenDistributionType(): string;
        set nielsenDistributionType(value: string);
        resetNielsenDistributionType(): void;
        get nielsenDistributionTypeInput(): string | undefined;
        private _nielsenCbetSettings;
        get nielsenCbetSettings(): NielsenCbetSettingsPropertyOutputReference;
        putNielsenCbetSettings(value: NielsenCbetSettingsProperty): void;
        resetNielsenCbetSettings(): void;
        get nielsenCbetSettingsInput(): NielsenCbetSettingsProperty | undefined;
        private _nielsenNaesIiNwSettings;
        get nielsenNaesIiNwSettings(): NielsenNaesIiNwSettingsPropertyList;
        putNielsenNaesIiNwSettings(value: NielsenNaesIiNwSettingsProperty[] | cdktn.IResolvable): void;
        resetNielsenNaesIiNwSettings(): void;
        get nielsenNaesIiNwSettingsInput(): cdktn.IResolvable | NielsenNaesIiNwSettingsProperty[] | undefined;
    }
    interface AudioWatermarkSettingsProperty {
        /**
        * nielsen_watermarks_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#nielsen_watermarks_settings AwsChannel#nielsen_watermarks_settings}
        */
        readonly nielsenWatermarksSettings?: NielsenWatermarksSettingsProperty;
    }
    class AudioWatermarkSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AudioWatermarkSettingsProperty | undefined;
        set internalValue(value: AudioWatermarkSettingsProperty | undefined);
        private _nielsenWatermarksSettings;
        get nielsenWatermarksSettings(): NielsenWatermarksSettingsPropertyOutputReference;
        putNielsenWatermarksSettings(value: NielsenWatermarksSettingsProperty): void;
        resetNielsenWatermarksSettings(): void;
        get nielsenWatermarksSettingsInput(): NielsenWatermarksSettingsProperty | undefined;
    }
    interface AacSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#bitrate AwsChannel#bitrate}
        */
        readonly bitrate?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#coding_mode AwsChannel#coding_mode}
        */
        readonly codingMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#input_type AwsChannel#input_type}
        */
        readonly inputType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#profile AwsChannel#profile}
        */
        readonly profile?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#rate_control_mode AwsChannel#rate_control_mode}
        */
        readonly rateControlMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#raw_format AwsChannel#raw_format}
        */
        readonly rawFormat?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#sample_rate AwsChannel#sample_rate}
        */
        readonly sampleRate?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#spec AwsChannel#spec}
        */
        readonly spec?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#vbr_quality AwsChannel#vbr_quality}
        */
        readonly vbrQuality?: string;
    }
    class AacSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AacSettingsProperty | undefined;
        set internalValue(value: AacSettingsProperty | undefined);
        private _bitrate?;
        get bitrate(): number;
        set bitrate(value: number);
        resetBitrate(): void;
        get bitrateInput(): number | undefined;
        private _codingMode?;
        get codingMode(): string;
        set codingMode(value: string);
        resetCodingMode(): void;
        get codingModeInput(): string | undefined;
        private _inputType?;
        get inputType(): string;
        set inputType(value: string);
        resetInputType(): void;
        get inputTypeInput(): string | undefined;
        private _profile?;
        get profile(): string;
        set profile(value: string);
        resetProfile(): void;
        get profileInput(): string | undefined;
        private _rateControlMode?;
        get rateControlMode(): string;
        set rateControlMode(value: string);
        resetRateControlMode(): void;
        get rateControlModeInput(): string | undefined;
        private _rawFormat?;
        get rawFormat(): string;
        set rawFormat(value: string);
        resetRawFormat(): void;
        get rawFormatInput(): string | undefined;
        private _sampleRate?;
        get sampleRate(): number;
        set sampleRate(value: number);
        resetSampleRate(): void;
        get sampleRateInput(): number | undefined;
        private _spec?;
        get spec(): string;
        set spec(value: string);
        resetSpec(): void;
        get specInput(): string | undefined;
        private _vbrQuality?;
        get vbrQuality(): string;
        set vbrQuality(value: string);
        resetVbrQuality(): void;
        get vbrQualityInput(): string | undefined;
    }
    interface Ac3SettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#bitrate AwsChannel#bitrate}
        */
        readonly bitrate?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#bitstream_mode AwsChannel#bitstream_mode}
        */
        readonly bitstreamMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#coding_mode AwsChannel#coding_mode}
        */
        readonly codingMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#dialnorm AwsChannel#dialnorm}
        */
        readonly dialnorm?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#drc_profile AwsChannel#drc_profile}
        */
        readonly drcProfile?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#lfe_filter AwsChannel#lfe_filter}
        */
        readonly lfeFilter?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#metadata_control AwsChannel#metadata_control}
        */
        readonly metadataControl?: string;
    }
    class Ac3SettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): Ac3SettingsProperty | undefined;
        set internalValue(value: Ac3SettingsProperty | undefined);
        private _bitrate?;
        get bitrate(): number;
        set bitrate(value: number);
        resetBitrate(): void;
        get bitrateInput(): number | undefined;
        private _bitstreamMode?;
        get bitstreamMode(): string;
        set bitstreamMode(value: string);
        resetBitstreamMode(): void;
        get bitstreamModeInput(): string | undefined;
        private _codingMode?;
        get codingMode(): string;
        set codingMode(value: string);
        resetCodingMode(): void;
        get codingModeInput(): string | undefined;
        private _dialnorm?;
        get dialnorm(): number;
        set dialnorm(value: number);
        resetDialnorm(): void;
        get dialnormInput(): number | undefined;
        private _drcProfile?;
        get drcProfile(): string;
        set drcProfile(value: string);
        resetDrcProfile(): void;
        get drcProfileInput(): string | undefined;
        private _lfeFilter?;
        get lfeFilter(): string;
        set lfeFilter(value: string);
        resetLfeFilter(): void;
        get lfeFilterInput(): string | undefined;
        private _metadataControl?;
        get metadataControl(): string;
        set metadataControl(value: string);
        resetMetadataControl(): void;
        get metadataControlInput(): string | undefined;
    }
    interface Eac3AtmosSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#bitrate AwsChannel#bitrate}
        */
        readonly bitrate?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#coding_mode AwsChannel#coding_mode}
        */
        readonly codingMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#dialnorm AwsChannel#dialnorm}
        */
        readonly dialnorm?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#drc_line AwsChannel#drc_line}
        */
        readonly drcLine?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#drc_rf AwsChannel#drc_rf}
        */
        readonly drcRf?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#height_trim AwsChannel#height_trim}
        */
        readonly heightTrim?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#surround_trim AwsChannel#surround_trim}
        */
        readonly surroundTrim?: number;
    }
    class Eac3AtmosSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): Eac3AtmosSettingsProperty | undefined;
        set internalValue(value: Eac3AtmosSettingsProperty | undefined);
        private _bitrate?;
        get bitrate(): number;
        set bitrate(value: number);
        resetBitrate(): void;
        get bitrateInput(): number | undefined;
        private _codingMode?;
        get codingMode(): string;
        set codingMode(value: string);
        resetCodingMode(): void;
        get codingModeInput(): string | undefined;
        private _dialnorm?;
        get dialnorm(): number;
        set dialnorm(value: number);
        resetDialnorm(): void;
        get dialnormInput(): number | undefined;
        private _drcLine?;
        get drcLine(): string;
        set drcLine(value: string);
        resetDrcLine(): void;
        get drcLineInput(): string | undefined;
        private _drcRf?;
        get drcRf(): string;
        set drcRf(value: string);
        resetDrcRf(): void;
        get drcRfInput(): string | undefined;
        private _heightTrim?;
        get heightTrim(): number;
        set heightTrim(value: number);
        resetHeightTrim(): void;
        get heightTrimInput(): number | undefined;
        private _surroundTrim?;
        get surroundTrim(): number;
        set surroundTrim(value: number);
        resetSurroundTrim(): void;
        get surroundTrimInput(): number | undefined;
    }
    interface Eac3SettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#attenuation_control AwsChannel#attenuation_control}
        */
        readonly attenuationControl?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#bitrate AwsChannel#bitrate}
        */
        readonly bitrate?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#bitstream_mode AwsChannel#bitstream_mode}
        */
        readonly bitstreamMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#coding_mode AwsChannel#coding_mode}
        */
        readonly codingMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#dc_filter AwsChannel#dc_filter}
        */
        readonly dcFilter?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#dialnorm AwsChannel#dialnorm}
        */
        readonly dialnorm?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#drc_line AwsChannel#drc_line}
        */
        readonly drcLine?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#drc_rf AwsChannel#drc_rf}
        */
        readonly drcRf?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#lfe_control AwsChannel#lfe_control}
        */
        readonly lfeControl?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#lfe_filter AwsChannel#lfe_filter}
        */
        readonly lfeFilter?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#lo_ro_center_mix_level AwsChannel#lo_ro_center_mix_level}
        */
        readonly loRoCenterMixLevel?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#lo_ro_surround_mix_level AwsChannel#lo_ro_surround_mix_level}
        */
        readonly loRoSurroundMixLevel?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#lt_rt_center_mix_level AwsChannel#lt_rt_center_mix_level}
        */
        readonly ltRtCenterMixLevel?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#lt_rt_surround_mix_level AwsChannel#lt_rt_surround_mix_level}
        */
        readonly ltRtSurroundMixLevel?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#metadata_control AwsChannel#metadata_control}
        */
        readonly metadataControl?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#passthrough_control AwsChannel#passthrough_control}
        */
        readonly passthroughControl?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#phase_control AwsChannel#phase_control}
        */
        readonly phaseControl?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#stereo_downmix AwsChannel#stereo_downmix}
        */
        readonly stereoDownmix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#surround_ex_mode AwsChannel#surround_ex_mode}
        */
        readonly surroundExMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#surround_mode AwsChannel#surround_mode}
        */
        readonly surroundMode?: string;
    }
    class Eac3SettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): Eac3SettingsProperty | undefined;
        set internalValue(value: Eac3SettingsProperty | undefined);
        private _attenuationControl?;
        get attenuationControl(): string;
        set attenuationControl(value: string);
        resetAttenuationControl(): void;
        get attenuationControlInput(): string | undefined;
        private _bitrate?;
        get bitrate(): number;
        set bitrate(value: number);
        resetBitrate(): void;
        get bitrateInput(): number | undefined;
        private _bitstreamMode?;
        get bitstreamMode(): string;
        set bitstreamMode(value: string);
        resetBitstreamMode(): void;
        get bitstreamModeInput(): string | undefined;
        private _codingMode?;
        get codingMode(): string;
        set codingMode(value: string);
        resetCodingMode(): void;
        get codingModeInput(): string | undefined;
        private _dcFilter?;
        get dcFilter(): string;
        set dcFilter(value: string);
        resetDcFilter(): void;
        get dcFilterInput(): string | undefined;
        private _dialnorm?;
        get dialnorm(): number;
        set dialnorm(value: number);
        resetDialnorm(): void;
        get dialnormInput(): number | undefined;
        private _drcLine?;
        get drcLine(): string;
        set drcLine(value: string);
        resetDrcLine(): void;
        get drcLineInput(): string | undefined;
        private _drcRf?;
        get drcRf(): string;
        set drcRf(value: string);
        resetDrcRf(): void;
        get drcRfInput(): string | undefined;
        private _lfeControl?;
        get lfeControl(): string;
        set lfeControl(value: string);
        resetLfeControl(): void;
        get lfeControlInput(): string | undefined;
        private _lfeFilter?;
        get lfeFilter(): string;
        set lfeFilter(value: string);
        resetLfeFilter(): void;
        get lfeFilterInput(): string | undefined;
        private _loRoCenterMixLevel?;
        get loRoCenterMixLevel(): number;
        set loRoCenterMixLevel(value: number);
        resetLoRoCenterMixLevel(): void;
        get loRoCenterMixLevelInput(): number | undefined;
        private _loRoSurroundMixLevel?;
        get loRoSurroundMixLevel(): number;
        set loRoSurroundMixLevel(value: number);
        resetLoRoSurroundMixLevel(): void;
        get loRoSurroundMixLevelInput(): number | undefined;
        private _ltRtCenterMixLevel?;
        get ltRtCenterMixLevel(): number;
        set ltRtCenterMixLevel(value: number);
        resetLtRtCenterMixLevel(): void;
        get ltRtCenterMixLevelInput(): number | undefined;
        private _ltRtSurroundMixLevel?;
        get ltRtSurroundMixLevel(): number;
        set ltRtSurroundMixLevel(value: number);
        resetLtRtSurroundMixLevel(): void;
        get ltRtSurroundMixLevelInput(): number | undefined;
        private _metadataControl?;
        get metadataControl(): string;
        set metadataControl(value: string);
        resetMetadataControl(): void;
        get metadataControlInput(): string | undefined;
        private _passthroughControl?;
        get passthroughControl(): string;
        set passthroughControl(value: string);
        resetPassthroughControl(): void;
        get passthroughControlInput(): string | undefined;
        private _phaseControl?;
        get phaseControl(): string;
        set phaseControl(value: string);
        resetPhaseControl(): void;
        get phaseControlInput(): string | undefined;
        private _stereoDownmix?;
        get stereoDownmix(): string;
        set stereoDownmix(value: string);
        resetStereoDownmix(): void;
        get stereoDownmixInput(): string | undefined;
        private _surroundExMode?;
        get surroundExMode(): string;
        set surroundExMode(value: string);
        resetSurroundExMode(): void;
        get surroundExModeInput(): string | undefined;
        private _surroundMode?;
        get surroundMode(): string;
        set surroundMode(value: string);
        resetSurroundMode(): void;
        get surroundModeInput(): string | undefined;
    }
    interface Mp2SettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#bitrate AwsChannel#bitrate}
        */
        readonly bitrate?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#coding_mode AwsChannel#coding_mode}
        */
        readonly codingMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#sample_rate AwsChannel#sample_rate}
        */
        readonly sampleRate?: number;
    }
    class Mp2SettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): Mp2SettingsProperty | undefined;
        set internalValue(value: Mp2SettingsProperty | undefined);
        private _bitrate?;
        get bitrate(): number;
        set bitrate(value: number);
        resetBitrate(): void;
        get bitrateInput(): number | undefined;
        private _codingMode?;
        get codingMode(): string;
        set codingMode(value: string);
        resetCodingMode(): void;
        get codingModeInput(): string | undefined;
        private _sampleRate?;
        get sampleRate(): number;
        set sampleRate(value: number);
        resetSampleRate(): void;
        get sampleRateInput(): number | undefined;
    }
    interface PassThroughSettingsProperty {
    }
    class PassThroughSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PassThroughSettingsProperty | undefined;
        set internalValue(value: PassThroughSettingsProperty | undefined);
    }
    interface WavSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#bit_depth AwsChannel#bit_depth}
        */
        readonly bitDepth?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#coding_mode AwsChannel#coding_mode}
        */
        readonly codingMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#sample_rate AwsChannel#sample_rate}
        */
        readonly sampleRate?: number;
    }
    class WavSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): WavSettingsProperty | undefined;
        set internalValue(value: WavSettingsProperty | undefined);
        private _bitDepth?;
        get bitDepth(): number;
        set bitDepth(value: number);
        resetBitDepth(): void;
        get bitDepthInput(): number | undefined;
        private _codingMode?;
        get codingMode(): string;
        set codingMode(value: string);
        resetCodingMode(): void;
        get codingModeInput(): string | undefined;
        private _sampleRate?;
        get sampleRate(): number;
        set sampleRate(value: number);
        resetSampleRate(): void;
        get sampleRateInput(): number | undefined;
    }
    interface EncoderSettingsAudioDescriptionsCodecSettingsProperty {
        /**
        * aac_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#aac_settings AwsChannel#aac_settings}
        */
        readonly aacSettings?: AacSettingsProperty;
        /**
        * ac3_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#ac3_settings AwsChannel#ac3_settings}
        */
        readonly ac3Settings?: Ac3SettingsProperty;
        /**
        * eac3_atmos_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#eac3_atmos_settings AwsChannel#eac3_atmos_settings}
        */
        readonly eac3AtmosSettings?: Eac3AtmosSettingsProperty;
        /**
        * eac3_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#eac3_settings AwsChannel#eac3_settings}
        */
        readonly eac3Settings?: Eac3SettingsProperty;
        /**
        * mp2_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#mp2_settings AwsChannel#mp2_settings}
        */
        readonly mp2Settings?: Mp2SettingsProperty;
        /**
        * pass_through_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#pass_through_settings AwsChannel#pass_through_settings}
        */
        readonly passThroughSettings?: PassThroughSettingsProperty;
        /**
        * wav_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#wav_settings AwsChannel#wav_settings}
        */
        readonly wavSettings?: WavSettingsProperty;
    }
    class EncoderSettingsAudioDescriptionsCodecSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncoderSettingsAudioDescriptionsCodecSettingsProperty | undefined;
        set internalValue(value: EncoderSettingsAudioDescriptionsCodecSettingsProperty | undefined);
        private _aacSettings;
        get aacSettings(): AacSettingsPropertyOutputReference;
        putAacSettings(value: AacSettingsProperty): void;
        resetAacSettings(): void;
        get aacSettingsInput(): AacSettingsProperty | undefined;
        private _ac3Settings;
        get ac3Settings(): Ac3SettingsPropertyOutputReference;
        putAc3Settings(value: Ac3SettingsProperty): void;
        resetAc3Settings(): void;
        get ac3SettingsInput(): Ac3SettingsProperty | undefined;
        private _eac3AtmosSettings;
        get eac3AtmosSettings(): Eac3AtmosSettingsPropertyOutputReference;
        putEac3AtmosSettings(value: Eac3AtmosSettingsProperty): void;
        resetEac3AtmosSettings(): void;
        get eac3AtmosSettingsInput(): Eac3AtmosSettingsProperty | undefined;
        private _eac3Settings;
        get eac3Settings(): Eac3SettingsPropertyOutputReference;
        putEac3Settings(value: Eac3SettingsProperty): void;
        resetEac3Settings(): void;
        get eac3SettingsInput(): Eac3SettingsProperty | undefined;
        private _mp2Settings;
        get mp2Settings(): Mp2SettingsPropertyOutputReference;
        putMp2Settings(value: Mp2SettingsProperty): void;
        resetMp2Settings(): void;
        get mp2SettingsInput(): Mp2SettingsProperty | undefined;
        private _passThroughSettings;
        get passThroughSettings(): PassThroughSettingsPropertyOutputReference;
        putPassThroughSettings(value: PassThroughSettingsProperty): void;
        resetPassThroughSettings(): void;
        get passThroughSettingsInput(): PassThroughSettingsProperty | undefined;
        private _wavSettings;
        get wavSettings(): WavSettingsPropertyOutputReference;
        putWavSettings(value: WavSettingsProperty): void;
        resetWavSettings(): void;
        get wavSettingsInput(): WavSettingsProperty | undefined;
    }
    interface InputChannelLevelsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#gain AwsChannel#gain}
        */
        readonly gain: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#input_channel AwsChannel#input_channel}
        */
        readonly inputChannel: number;
    }
    class InputChannelLevelsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InputChannelLevelsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InputChannelLevelsProperty | cdktn.IResolvable | undefined);
        private _gain?;
        get gain(): number;
        set gain(value: number);
        get gainInput(): number | undefined;
        private _inputChannel?;
        get inputChannel(): number;
        set inputChannel(value: number);
        get inputChannelInput(): number | undefined;
    }
    class InputChannelLevelsPropertyList extends cdktn.ComplexList {
        internalValue?: InputChannelLevelsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InputChannelLevelsPropertyOutputReference;
    }
    interface ChannelMappingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#output_channel AwsChannel#output_channel}
        */
        readonly outputChannel: number;
        /**
        * input_channel_levels block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#input_channel_levels AwsChannel#input_channel_levels}
        */
        readonly inputChannelLevels: InputChannelLevelsProperty[] | cdktn.IResolvable;
    }
    class ChannelMappingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ChannelMappingsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ChannelMappingsProperty | cdktn.IResolvable | undefined);
        private _outputChannel?;
        get outputChannel(): number;
        set outputChannel(value: number);
        get outputChannelInput(): number | undefined;
        private _inputChannelLevels;
        get inputChannelLevels(): InputChannelLevelsPropertyList;
        putInputChannelLevels(value: InputChannelLevelsProperty[] | cdktn.IResolvable): void;
        get inputChannelLevelsInput(): cdktn.IResolvable | InputChannelLevelsProperty[] | undefined;
    }
    class ChannelMappingsPropertyList extends cdktn.ComplexList {
        internalValue?: ChannelMappingsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ChannelMappingsPropertyOutputReference;
    }
    interface RemixSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#channels_in AwsChannel#channels_in}
        */
        readonly channelsIn?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#channels_out AwsChannel#channels_out}
        */
        readonly channelsOut?: number;
        /**
        * channel_mappings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#channel_mappings AwsChannel#channel_mappings}
        */
        readonly channelMappings: ChannelMappingsProperty[] | cdktn.IResolvable;
    }
    class RemixSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RemixSettingsProperty | undefined;
        set internalValue(value: RemixSettingsProperty | undefined);
        private _channelsIn?;
        get channelsIn(): number;
        set channelsIn(value: number);
        resetChannelsIn(): void;
        get channelsInInput(): number | undefined;
        private _channelsOut?;
        get channelsOut(): number;
        set channelsOut(value: number);
        resetChannelsOut(): void;
        get channelsOutInput(): number | undefined;
        private _channelMappings;
        get channelMappings(): ChannelMappingsPropertyList;
        putChannelMappings(value: ChannelMappingsProperty[] | cdktn.IResolvable): void;
        get channelMappingsInput(): cdktn.IResolvable | ChannelMappingsProperty[] | undefined;
    }
    interface AudioDescriptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#audio_selector_name AwsChannel#audio_selector_name}
        */
        readonly audioSelectorName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#audio_type AwsChannel#audio_type}
        */
        readonly audioType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#audio_type_control AwsChannel#audio_type_control}
        */
        readonly audioTypeControl?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#language_code AwsChannel#language_code}
        */
        readonly languageCode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#language_code_control AwsChannel#language_code_control}
        */
        readonly languageCodeControl?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#name AwsChannel#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#stream_name AwsChannel#stream_name}
        */
        readonly streamName?: string;
        /**
        * audio_normalization_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#audio_normalization_settings AwsChannel#audio_normalization_settings}
        */
        readonly audioNormalizationSettings?: AudioNormalizationSettingsProperty;
        /**
        * audio_watermark_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#audio_watermark_settings AwsChannel#audio_watermark_settings}
        */
        readonly audioWatermarkSettings?: AudioWatermarkSettingsProperty;
        /**
        * codec_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#codec_settings AwsChannel#codec_settings}
        */
        readonly codecSettings?: EncoderSettingsAudioDescriptionsCodecSettingsProperty;
        /**
        * remix_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#remix_settings AwsChannel#remix_settings}
        */
        readonly remixSettings?: RemixSettingsProperty;
    }
    class AudioDescriptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AudioDescriptionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AudioDescriptionsProperty | cdktn.IResolvable | undefined);
        private _audioSelectorName?;
        get audioSelectorName(): string;
        set audioSelectorName(value: string);
        get audioSelectorNameInput(): string | undefined;
        private _audioType?;
        get audioType(): string;
        set audioType(value: string);
        resetAudioType(): void;
        get audioTypeInput(): string | undefined;
        private _audioTypeControl?;
        get audioTypeControl(): string;
        set audioTypeControl(value: string);
        resetAudioTypeControl(): void;
        get audioTypeControlInput(): string | undefined;
        private _languageCode?;
        get languageCode(): string;
        set languageCode(value: string);
        resetLanguageCode(): void;
        get languageCodeInput(): string | undefined;
        private _languageCodeControl?;
        get languageCodeControl(): string;
        set languageCodeControl(value: string);
        resetLanguageCodeControl(): void;
        get languageCodeControlInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _streamName?;
        get streamName(): string;
        set streamName(value: string);
        resetStreamName(): void;
        get streamNameInput(): string | undefined;
        private _audioNormalizationSettings;
        get audioNormalizationSettings(): AudioNormalizationSettingsPropertyOutputReference;
        putAudioNormalizationSettings(value: AudioNormalizationSettingsProperty): void;
        resetAudioNormalizationSettings(): void;
        get audioNormalizationSettingsInput(): AudioNormalizationSettingsProperty | undefined;
        private _audioWatermarkSettings;
        get audioWatermarkSettings(): AudioWatermarkSettingsPropertyOutputReference;
        putAudioWatermarkSettings(value: AudioWatermarkSettingsProperty): void;
        resetAudioWatermarkSettings(): void;
        get audioWatermarkSettingsInput(): AudioWatermarkSettingsProperty | undefined;
        private _codecSettings;
        get codecSettings(): EncoderSettingsAudioDescriptionsCodecSettingsPropertyOutputReference;
        putCodecSettings(value: EncoderSettingsAudioDescriptionsCodecSettingsProperty): void;
        resetCodecSettings(): void;
        get codecSettingsInput(): EncoderSettingsAudioDescriptionsCodecSettingsProperty | undefined;
        private _remixSettings;
        get remixSettings(): RemixSettingsPropertyOutputReference;
        putRemixSettings(value: RemixSettingsProperty): void;
        resetRemixSettings(): void;
        get remixSettingsInput(): RemixSettingsProperty | undefined;
    }
    class AudioDescriptionsPropertyList extends cdktn.ComplexList {
        internalValue?: AudioDescriptionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AudioDescriptionsPropertyOutputReference;
    }
    interface AvailBlankingImageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#password_param AwsChannel#password_param}
        */
        readonly passwordParam?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#uri AwsChannel#uri}
        */
        readonly uri: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#username AwsChannel#username}
        */
        readonly username?: string;
    }
    class AvailBlankingImagePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AvailBlankingImageProperty | undefined;
        set internalValue(value: AvailBlankingImageProperty | undefined);
        private _passwordParam?;
        get passwordParam(): string;
        set passwordParam(value: string);
        resetPasswordParam(): void;
        get passwordParamInput(): string | undefined;
        private _uri?;
        get uri(): string;
        set uri(value: string);
        get uriInput(): string | undefined;
        private _username?;
        get username(): string;
        set username(value: string);
        resetUsername(): void;
        get usernameInput(): string | undefined;
    }
    interface AvailBlankingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#state AwsChannel#state}
        */
        readonly state?: string;
        /**
        * avail_blanking_image block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#avail_blanking_image AwsChannel#avail_blanking_image}
        */
        readonly availBlankingImage?: AvailBlankingImageProperty;
    }
    class AvailBlankingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AvailBlankingProperty | undefined;
        set internalValue(value: AvailBlankingProperty | undefined);
        private _state?;
        get state(): string;
        set state(value: string);
        resetState(): void;
        get stateInput(): string | undefined;
        private _availBlankingImage;
        get availBlankingImage(): AvailBlankingImagePropertyOutputReference;
        putAvailBlankingImage(value: AvailBlankingImageProperty): void;
        resetAvailBlankingImage(): void;
        get availBlankingImageInput(): AvailBlankingImageProperty | undefined;
    }
    interface AribDestinationSettingsProperty {
    }
    class AribDestinationSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AribDestinationSettingsProperty | undefined;
        set internalValue(value: AribDestinationSettingsProperty | undefined);
    }
    interface EncoderSettingsCaptionDescriptionsDestinationSettingsBurnInDestinationSettingsFontProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#password_param AwsChannel#password_param}
        */
        readonly passwordParam?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#uri AwsChannel#uri}
        */
        readonly uri: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#username AwsChannel#username}
        */
        readonly username?: string;
    }
    class EncoderSettingsCaptionDescriptionsDestinationSettingsBurnInDestinationSettingsFontPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncoderSettingsCaptionDescriptionsDestinationSettingsBurnInDestinationSettingsFontProperty | undefined;
        set internalValue(value: EncoderSettingsCaptionDescriptionsDestinationSettingsBurnInDestinationSettingsFontProperty | undefined);
        private _passwordParam?;
        get passwordParam(): string;
        set passwordParam(value: string);
        resetPasswordParam(): void;
        get passwordParamInput(): string | undefined;
        private _uri?;
        get uri(): string;
        set uri(value: string);
        get uriInput(): string | undefined;
        private _username?;
        get username(): string;
        set username(value: string);
        resetUsername(): void;
        get usernameInput(): string | undefined;
    }
    interface BurnInDestinationSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#alignment AwsChannel#alignment}
        */
        readonly alignment?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#background_color AwsChannel#background_color}
        */
        readonly backgroundColor?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#background_opacity AwsChannel#background_opacity}
        */
        readonly backgroundOpacity?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#font_color AwsChannel#font_color}
        */
        readonly fontColor?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#font_opacity AwsChannel#font_opacity}
        */
        readonly fontOpacity?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#font_resolution AwsChannel#font_resolution}
        */
        readonly fontResolution?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#font_size AwsChannel#font_size}
        */
        readonly fontSize?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#outline_color AwsChannel#outline_color}
        */
        readonly outlineColor: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#outline_size AwsChannel#outline_size}
        */
        readonly outlineSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#shadow_color AwsChannel#shadow_color}
        */
        readonly shadowColor?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#shadow_opacity AwsChannel#shadow_opacity}
        */
        readonly shadowOpacity?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#shadow_x_offset AwsChannel#shadow_x_offset}
        */
        readonly shadowXOffset?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#shadow_y_offset AwsChannel#shadow_y_offset}
        */
        readonly shadowYOffset?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#teletext_grid_control AwsChannel#teletext_grid_control}
        */
        readonly teletextGridControl: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#x_position AwsChannel#x_position}
        */
        readonly xPosition?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#y_position AwsChannel#y_position}
        */
        readonly yPosition?: number;
        /**
        * font block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#font AwsChannel#font}
        */
        readonly font?: EncoderSettingsCaptionDescriptionsDestinationSettingsBurnInDestinationSettingsFontProperty;
    }
    class BurnInDestinationSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BurnInDestinationSettingsProperty | undefined;
        set internalValue(value: BurnInDestinationSettingsProperty | undefined);
        private _alignment?;
        get alignment(): string;
        set alignment(value: string);
        resetAlignment(): void;
        get alignmentInput(): string | undefined;
        private _backgroundColor?;
        get backgroundColor(): string;
        set backgroundColor(value: string);
        resetBackgroundColor(): void;
        get backgroundColorInput(): string | undefined;
        private _backgroundOpacity?;
        get backgroundOpacity(): number;
        set backgroundOpacity(value: number);
        resetBackgroundOpacity(): void;
        get backgroundOpacityInput(): number | undefined;
        private _fontColor?;
        get fontColor(): string;
        set fontColor(value: string);
        resetFontColor(): void;
        get fontColorInput(): string | undefined;
        private _fontOpacity?;
        get fontOpacity(): number;
        set fontOpacity(value: number);
        resetFontOpacity(): void;
        get fontOpacityInput(): number | undefined;
        private _fontResolution?;
        get fontResolution(): number;
        set fontResolution(value: number);
        resetFontResolution(): void;
        get fontResolutionInput(): number | undefined;
        private _fontSize?;
        get fontSize(): string;
        set fontSize(value: string);
        resetFontSize(): void;
        get fontSizeInput(): string | undefined;
        private _outlineColor?;
        get outlineColor(): string;
        set outlineColor(value: string);
        get outlineColorInput(): string | undefined;
        private _outlineSize?;
        get outlineSize(): number;
        set outlineSize(value: number);
        resetOutlineSize(): void;
        get outlineSizeInput(): number | undefined;
        private _shadowColor?;
        get shadowColor(): string;
        set shadowColor(value: string);
        resetShadowColor(): void;
        get shadowColorInput(): string | undefined;
        private _shadowOpacity?;
        get shadowOpacity(): number;
        set shadowOpacity(value: number);
        resetShadowOpacity(): void;
        get shadowOpacityInput(): number | undefined;
        private _shadowXOffset?;
        get shadowXOffset(): number;
        set shadowXOffset(value: number);
        resetShadowXOffset(): void;
        get shadowXOffsetInput(): number | undefined;
        private _shadowYOffset?;
        get shadowYOffset(): number;
        set shadowYOffset(value: number);
        resetShadowYOffset(): void;
        get shadowYOffsetInput(): number | undefined;
        private _teletextGridControl?;
        get teletextGridControl(): string;
        set teletextGridControl(value: string);
        get teletextGridControlInput(): string | undefined;
        private _xPosition?;
        get xPosition(): number;
        set xPosition(value: number);
        resetXPosition(): void;
        get xPositionInput(): number | undefined;
        private _yPosition?;
        get yPosition(): number;
        set yPosition(value: number);
        resetYPosition(): void;
        get yPositionInput(): number | undefined;
        private _font;
        get font(): EncoderSettingsCaptionDescriptionsDestinationSettingsBurnInDestinationSettingsFontPropertyOutputReference;
        putFont(value: EncoderSettingsCaptionDescriptionsDestinationSettingsBurnInDestinationSettingsFontProperty): void;
        resetFont(): void;
        get fontInput(): EncoderSettingsCaptionDescriptionsDestinationSettingsBurnInDestinationSettingsFontProperty | undefined;
    }
    interface EncoderSettingsCaptionDescriptionsDestinationSettingsDvbSubDestinationSettingsFontProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#password_param AwsChannel#password_param}
        */
        readonly passwordParam?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#uri AwsChannel#uri}
        */
        readonly uri: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#username AwsChannel#username}
        */
        readonly username?: string;
    }
    class EncoderSettingsCaptionDescriptionsDestinationSettingsDvbSubDestinationSettingsFontPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncoderSettingsCaptionDescriptionsDestinationSettingsDvbSubDestinationSettingsFontProperty | undefined;
        set internalValue(value: EncoderSettingsCaptionDescriptionsDestinationSettingsDvbSubDestinationSettingsFontProperty | undefined);
        private _passwordParam?;
        get passwordParam(): string;
        set passwordParam(value: string);
        resetPasswordParam(): void;
        get passwordParamInput(): string | undefined;
        private _uri?;
        get uri(): string;
        set uri(value: string);
        get uriInput(): string | undefined;
        private _username?;
        get username(): string;
        set username(value: string);
        resetUsername(): void;
        get usernameInput(): string | undefined;
    }
    interface DvbSubDestinationSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#alignment AwsChannel#alignment}
        */
        readonly alignment?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#background_color AwsChannel#background_color}
        */
        readonly backgroundColor?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#background_opacity AwsChannel#background_opacity}
        */
        readonly backgroundOpacity?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#font_color AwsChannel#font_color}
        */
        readonly fontColor?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#font_opacity AwsChannel#font_opacity}
        */
        readonly fontOpacity?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#font_resolution AwsChannel#font_resolution}
        */
        readonly fontResolution?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#font_size AwsChannel#font_size}
        */
        readonly fontSize?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#outline_color AwsChannel#outline_color}
        */
        readonly outlineColor?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#outline_size AwsChannel#outline_size}
        */
        readonly outlineSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#shadow_color AwsChannel#shadow_color}
        */
        readonly shadowColor?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#shadow_opacity AwsChannel#shadow_opacity}
        */
        readonly shadowOpacity?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#shadow_x_offset AwsChannel#shadow_x_offset}
        */
        readonly shadowXOffset?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#shadow_y_offset AwsChannel#shadow_y_offset}
        */
        readonly shadowYOffset?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#teletext_grid_control AwsChannel#teletext_grid_control}
        */
        readonly teletextGridControl?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#x_position AwsChannel#x_position}
        */
        readonly xPosition?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#y_position AwsChannel#y_position}
        */
        readonly yPosition?: number;
        /**
        * font block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#font AwsChannel#font}
        */
        readonly font?: EncoderSettingsCaptionDescriptionsDestinationSettingsDvbSubDestinationSettingsFontProperty;
    }
    class DvbSubDestinationSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DvbSubDestinationSettingsProperty | undefined;
        set internalValue(value: DvbSubDestinationSettingsProperty | undefined);
        private _alignment?;
        get alignment(): string;
        set alignment(value: string);
        resetAlignment(): void;
        get alignmentInput(): string | undefined;
        private _backgroundColor?;
        get backgroundColor(): string;
        set backgroundColor(value: string);
        resetBackgroundColor(): void;
        get backgroundColorInput(): string | undefined;
        private _backgroundOpacity?;
        get backgroundOpacity(): number;
        set backgroundOpacity(value: number);
        resetBackgroundOpacity(): void;
        get backgroundOpacityInput(): number | undefined;
        private _fontColor?;
        get fontColor(): string;
        set fontColor(value: string);
        resetFontColor(): void;
        get fontColorInput(): string | undefined;
        private _fontOpacity?;
        get fontOpacity(): number;
        set fontOpacity(value: number);
        resetFontOpacity(): void;
        get fontOpacityInput(): number | undefined;
        private _fontResolution?;
        get fontResolution(): number;
        set fontResolution(value: number);
        resetFontResolution(): void;
        get fontResolutionInput(): number | undefined;
        private _fontSize?;
        get fontSize(): string;
        set fontSize(value: string);
        resetFontSize(): void;
        get fontSizeInput(): string | undefined;
        private _outlineColor?;
        get outlineColor(): string;
        set outlineColor(value: string);
        resetOutlineColor(): void;
        get outlineColorInput(): string | undefined;
        private _outlineSize?;
        get outlineSize(): number;
        set outlineSize(value: number);
        resetOutlineSize(): void;
        get outlineSizeInput(): number | undefined;
        private _shadowColor?;
        get shadowColor(): string;
        set shadowColor(value: string);
        resetShadowColor(): void;
        get shadowColorInput(): string | undefined;
        private _shadowOpacity?;
        get shadowOpacity(): number;
        set shadowOpacity(value: number);
        resetShadowOpacity(): void;
        get shadowOpacityInput(): number | undefined;
        private _shadowXOffset?;
        get shadowXOffset(): number;
        set shadowXOffset(value: number);
        resetShadowXOffset(): void;
        get shadowXOffsetInput(): number | undefined;
        private _shadowYOffset?;
        get shadowYOffset(): number;
        set shadowYOffset(value: number);
        resetShadowYOffset(): void;
        get shadowYOffsetInput(): number | undefined;
        private _teletextGridControl?;
        get teletextGridControl(): string;
        set teletextGridControl(value: string);
        resetTeletextGridControl(): void;
        get teletextGridControlInput(): string | undefined;
        private _xPosition?;
        get xPosition(): number;
        set xPosition(value: number);
        resetXPosition(): void;
        get xPositionInput(): number | undefined;
        private _yPosition?;
        get yPosition(): number;
        set yPosition(value: number);
        resetYPosition(): void;
        get yPositionInput(): number | undefined;
        private _font;
        get font(): EncoderSettingsCaptionDescriptionsDestinationSettingsDvbSubDestinationSettingsFontPropertyOutputReference;
        putFont(value: EncoderSettingsCaptionDescriptionsDestinationSettingsDvbSubDestinationSettingsFontProperty): void;
        resetFont(): void;
        get fontInput(): EncoderSettingsCaptionDescriptionsDestinationSettingsDvbSubDestinationSettingsFontProperty | undefined;
    }
    interface EbuTtDDestinationSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#copyright_holder AwsChannel#copyright_holder}
        */
        readonly copyrightHolder?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#fill_line_gap AwsChannel#fill_line_gap}
        */
        readonly fillLineGap?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#font_family AwsChannel#font_family}
        */
        readonly fontFamily?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#style_control AwsChannel#style_control}
        */
        readonly styleControl?: string;
    }
    class EbuTtDDestinationSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EbuTtDDestinationSettingsProperty | undefined;
        set internalValue(value: EbuTtDDestinationSettingsProperty | undefined);
        private _copyrightHolder?;
        get copyrightHolder(): string;
        set copyrightHolder(value: string);
        resetCopyrightHolder(): void;
        get copyrightHolderInput(): string | undefined;
        private _fillLineGap?;
        get fillLineGap(): string;
        set fillLineGap(value: string);
        resetFillLineGap(): void;
        get fillLineGapInput(): string | undefined;
        private _fontFamily?;
        get fontFamily(): string;
        set fontFamily(value: string);
        resetFontFamily(): void;
        get fontFamilyInput(): string | undefined;
        private _styleControl?;
        get styleControl(): string;
        set styleControl(value: string);
        resetStyleControl(): void;
        get styleControlInput(): string | undefined;
    }
    interface EmbeddedDestinationSettingsProperty {
    }
    class EmbeddedDestinationSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EmbeddedDestinationSettingsProperty | undefined;
        set internalValue(value: EmbeddedDestinationSettingsProperty | undefined);
    }
    interface EmbeddedPlusScte20DestinationSettingsProperty {
    }
    class EmbeddedPlusScte20DestinationSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EmbeddedPlusScte20DestinationSettingsProperty | undefined;
        set internalValue(value: EmbeddedPlusScte20DestinationSettingsProperty | undefined);
    }
    interface RtmpCaptionInfoDestinationSettingsProperty {
    }
    class RtmpCaptionInfoDestinationSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RtmpCaptionInfoDestinationSettingsProperty | undefined;
        set internalValue(value: RtmpCaptionInfoDestinationSettingsProperty | undefined);
    }
    interface Scte20PlusEmbeddedDestinationSettingsProperty {
    }
    class Scte20PlusEmbeddedDestinationSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): Scte20PlusEmbeddedDestinationSettingsProperty | undefined;
        set internalValue(value: Scte20PlusEmbeddedDestinationSettingsProperty | undefined);
    }
    interface Scte27DestinationSettingsProperty {
    }
    class Scte27DestinationSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): Scte27DestinationSettingsProperty | undefined;
        set internalValue(value: Scte27DestinationSettingsProperty | undefined);
    }
    interface SmpteTtDestinationSettingsProperty {
    }
    class SmpteTtDestinationSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SmpteTtDestinationSettingsProperty | undefined;
        set internalValue(value: SmpteTtDestinationSettingsProperty | undefined);
    }
    interface TeletextDestinationSettingsProperty {
    }
    class TeletextDestinationSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TeletextDestinationSettingsProperty | undefined;
        set internalValue(value: TeletextDestinationSettingsProperty | undefined);
    }
    interface TtmlDestinationSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#style_control AwsChannel#style_control}
        */
        readonly styleControl: string;
    }
    class TtmlDestinationSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TtmlDestinationSettingsProperty | undefined;
        set internalValue(value: TtmlDestinationSettingsProperty | undefined);
        private _styleControl?;
        get styleControl(): string;
        set styleControl(value: string);
        get styleControlInput(): string | undefined;
    }
    interface WebvttDestinationSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#style_control AwsChannel#style_control}
        */
        readonly styleControl: string;
    }
    class WebvttDestinationSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): WebvttDestinationSettingsProperty | undefined;
        set internalValue(value: WebvttDestinationSettingsProperty | undefined);
        private _styleControl?;
        get styleControl(): string;
        set styleControl(value: string);
        get styleControlInput(): string | undefined;
    }
    interface DestinationSettingsProperty {
        /**
        * arib_destination_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#arib_destination_settings AwsChannel#arib_destination_settings}
        */
        readonly aribDestinationSettings?: AribDestinationSettingsProperty;
        /**
        * burn_in_destination_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#burn_in_destination_settings AwsChannel#burn_in_destination_settings}
        */
        readonly burnInDestinationSettings?: BurnInDestinationSettingsProperty;
        /**
        * dvb_sub_destination_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#dvb_sub_destination_settings AwsChannel#dvb_sub_destination_settings}
        */
        readonly dvbSubDestinationSettings?: DvbSubDestinationSettingsProperty;
        /**
        * ebu_tt_d_destination_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#ebu_tt_d_destination_settings AwsChannel#ebu_tt_d_destination_settings}
        */
        readonly ebuTtDDestinationSettings?: EbuTtDDestinationSettingsProperty;
        /**
        * embedded_destination_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#embedded_destination_settings AwsChannel#embedded_destination_settings}
        */
        readonly embeddedDestinationSettings?: EmbeddedDestinationSettingsProperty;
        /**
        * embedded_plus_scte20_destination_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#embedded_plus_scte20_destination_settings AwsChannel#embedded_plus_scte20_destination_settings}
        */
        readonly embeddedPlusScte20DestinationSettings?: EmbeddedPlusScte20DestinationSettingsProperty;
        /**
        * rtmp_caption_info_destination_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#rtmp_caption_info_destination_settings AwsChannel#rtmp_caption_info_destination_settings}
        */
        readonly rtmpCaptionInfoDestinationSettings?: RtmpCaptionInfoDestinationSettingsProperty;
        /**
        * scte20_plus_embedded_destination_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#scte20_plus_embedded_destination_settings AwsChannel#scte20_plus_embedded_destination_settings}
        */
        readonly scte20PlusEmbeddedDestinationSettings?: Scte20PlusEmbeddedDestinationSettingsProperty;
        /**
        * scte27_destination_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#scte27_destination_settings AwsChannel#scte27_destination_settings}
        */
        readonly scte27DestinationSettings?: Scte27DestinationSettingsProperty;
        /**
        * smpte_tt_destination_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#smpte_tt_destination_settings AwsChannel#smpte_tt_destination_settings}
        */
        readonly smpteTtDestinationSettings?: SmpteTtDestinationSettingsProperty;
        /**
        * teletext_destination_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#teletext_destination_settings AwsChannel#teletext_destination_settings}
        */
        readonly teletextDestinationSettings?: TeletextDestinationSettingsProperty;
        /**
        * ttml_destination_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#ttml_destination_settings AwsChannel#ttml_destination_settings}
        */
        readonly ttmlDestinationSettings?: TtmlDestinationSettingsProperty;
        /**
        * webvtt_destination_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#webvtt_destination_settings AwsChannel#webvtt_destination_settings}
        */
        readonly webvttDestinationSettings?: WebvttDestinationSettingsProperty;
    }
    class DestinationSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationSettingsProperty | undefined;
        set internalValue(value: DestinationSettingsProperty | undefined);
        private _aribDestinationSettings;
        get aribDestinationSettings(): AribDestinationSettingsPropertyOutputReference;
        putAribDestinationSettings(value: AribDestinationSettingsProperty): void;
        resetAribDestinationSettings(): void;
        get aribDestinationSettingsInput(): AribDestinationSettingsProperty | undefined;
        private _burnInDestinationSettings;
        get burnInDestinationSettings(): BurnInDestinationSettingsPropertyOutputReference;
        putBurnInDestinationSettings(value: BurnInDestinationSettingsProperty): void;
        resetBurnInDestinationSettings(): void;
        get burnInDestinationSettingsInput(): BurnInDestinationSettingsProperty | undefined;
        private _dvbSubDestinationSettings;
        get dvbSubDestinationSettings(): DvbSubDestinationSettingsPropertyOutputReference;
        putDvbSubDestinationSettings(value: DvbSubDestinationSettingsProperty): void;
        resetDvbSubDestinationSettings(): void;
        get dvbSubDestinationSettingsInput(): DvbSubDestinationSettingsProperty | undefined;
        private _ebuTtDDestinationSettings;
        get ebuTtDDestinationSettings(): EbuTtDDestinationSettingsPropertyOutputReference;
        putEbuTtDDestinationSettings(value: EbuTtDDestinationSettingsProperty): void;
        resetEbuTtDDestinationSettings(): void;
        get ebuTtDDestinationSettingsInput(): EbuTtDDestinationSettingsProperty | undefined;
        private _embeddedDestinationSettings;
        get embeddedDestinationSettings(): EmbeddedDestinationSettingsPropertyOutputReference;
        putEmbeddedDestinationSettings(value: EmbeddedDestinationSettingsProperty): void;
        resetEmbeddedDestinationSettings(): void;
        get embeddedDestinationSettingsInput(): EmbeddedDestinationSettingsProperty | undefined;
        private _embeddedPlusScte20DestinationSettings;
        get embeddedPlusScte20DestinationSettings(): EmbeddedPlusScte20DestinationSettingsPropertyOutputReference;
        putEmbeddedPlusScte20DestinationSettings(value: EmbeddedPlusScte20DestinationSettingsProperty): void;
        resetEmbeddedPlusScte20DestinationSettings(): void;
        get embeddedPlusScte20DestinationSettingsInput(): EmbeddedPlusScte20DestinationSettingsProperty | undefined;
        private _rtmpCaptionInfoDestinationSettings;
        get rtmpCaptionInfoDestinationSettings(): RtmpCaptionInfoDestinationSettingsPropertyOutputReference;
        putRtmpCaptionInfoDestinationSettings(value: RtmpCaptionInfoDestinationSettingsProperty): void;
        resetRtmpCaptionInfoDestinationSettings(): void;
        get rtmpCaptionInfoDestinationSettingsInput(): RtmpCaptionInfoDestinationSettingsProperty | undefined;
        private _scte20PlusEmbeddedDestinationSettings;
        get scte20PlusEmbeddedDestinationSettings(): Scte20PlusEmbeddedDestinationSettingsPropertyOutputReference;
        putScte20PlusEmbeddedDestinationSettings(value: Scte20PlusEmbeddedDestinationSettingsProperty): void;
        resetScte20PlusEmbeddedDestinationSettings(): void;
        get scte20PlusEmbeddedDestinationSettingsInput(): Scte20PlusEmbeddedDestinationSettingsProperty | undefined;
        private _scte27DestinationSettings;
        get scte27DestinationSettings(): Scte27DestinationSettingsPropertyOutputReference;
        putScte27DestinationSettings(value: Scte27DestinationSettingsProperty): void;
        resetScte27DestinationSettings(): void;
        get scte27DestinationSettingsInput(): Scte27DestinationSettingsProperty | undefined;
        private _smpteTtDestinationSettings;
        get smpteTtDestinationSettings(): SmpteTtDestinationSettingsPropertyOutputReference;
        putSmpteTtDestinationSettings(value: SmpteTtDestinationSettingsProperty): void;
        resetSmpteTtDestinationSettings(): void;
        get smpteTtDestinationSettingsInput(): SmpteTtDestinationSettingsProperty | undefined;
        private _teletextDestinationSettings;
        get teletextDestinationSettings(): TeletextDestinationSettingsPropertyOutputReference;
        putTeletextDestinationSettings(value: TeletextDestinationSettingsProperty): void;
        resetTeletextDestinationSettings(): void;
        get teletextDestinationSettingsInput(): TeletextDestinationSettingsProperty | undefined;
        private _ttmlDestinationSettings;
        get ttmlDestinationSettings(): TtmlDestinationSettingsPropertyOutputReference;
        putTtmlDestinationSettings(value: TtmlDestinationSettingsProperty): void;
        resetTtmlDestinationSettings(): void;
        get ttmlDestinationSettingsInput(): TtmlDestinationSettingsProperty | undefined;
        private _webvttDestinationSettings;
        get webvttDestinationSettings(): WebvttDestinationSettingsPropertyOutputReference;
        putWebvttDestinationSettings(value: WebvttDestinationSettingsProperty): void;
        resetWebvttDestinationSettings(): void;
        get webvttDestinationSettingsInput(): WebvttDestinationSettingsProperty | undefined;
    }
    interface CaptionDescriptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#accessibility AwsChannel#accessibility}
        */
        readonly accessibility?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#caption_selector_name AwsChannel#caption_selector_name}
        */
        readonly captionSelectorName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#language_code AwsChannel#language_code}
        */
        readonly languageCode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#language_description AwsChannel#language_description}
        */
        readonly languageDescription?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#name AwsChannel#name}
        */
        readonly name: string;
        /**
        * destination_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#destination_settings AwsChannel#destination_settings}
        */
        readonly destinationSettings?: DestinationSettingsProperty;
    }
    class CaptionDescriptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CaptionDescriptionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CaptionDescriptionsProperty | cdktn.IResolvable | undefined);
        private _accessibility?;
        get accessibility(): string;
        set accessibility(value: string);
        resetAccessibility(): void;
        get accessibilityInput(): string | undefined;
        private _captionSelectorName?;
        get captionSelectorName(): string;
        set captionSelectorName(value: string);
        get captionSelectorNameInput(): string | undefined;
        private _languageCode?;
        get languageCode(): string;
        set languageCode(value: string);
        resetLanguageCode(): void;
        get languageCodeInput(): string | undefined;
        private _languageDescription?;
        get languageDescription(): string;
        set languageDescription(value: string);
        resetLanguageDescription(): void;
        get languageDescriptionInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _destinationSettings;
        get destinationSettings(): DestinationSettingsPropertyOutputReference;
        putDestinationSettings(value: DestinationSettingsProperty): void;
        resetDestinationSettings(): void;
        get destinationSettingsInput(): DestinationSettingsProperty | undefined;
    }
    class CaptionDescriptionsPropertyList extends cdktn.ComplexList {
        internalValue?: CaptionDescriptionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CaptionDescriptionsPropertyOutputReference;
    }
    interface InputLossImageSlateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#password_param AwsChannel#password_param}
        */
        readonly passwordParam?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#uri AwsChannel#uri}
        */
        readonly uri: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#username AwsChannel#username}
        */
        readonly username?: string;
    }
    class InputLossImageSlatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InputLossImageSlateProperty | undefined;
        set internalValue(value: InputLossImageSlateProperty | undefined);
        private _passwordParam?;
        get passwordParam(): string;
        set passwordParam(value: string);
        resetPasswordParam(): void;
        get passwordParamInput(): string | undefined;
        private _uri?;
        get uri(): string;
        set uri(value: string);
        get uriInput(): string | undefined;
        private _username?;
        get username(): string;
        set username(value: string);
        resetUsername(): void;
        get usernameInput(): string | undefined;
    }
    interface InputLossBehaviorProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#black_frame_msec AwsChannel#black_frame_msec}
        */
        readonly blackFrameMsec?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#input_loss_image_color AwsChannel#input_loss_image_color}
        */
        readonly inputLossImageColor?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#input_loss_image_type AwsChannel#input_loss_image_type}
        */
        readonly inputLossImageType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#repeat_frame_msec AwsChannel#repeat_frame_msec}
        */
        readonly repeatFrameMsec?: number;
        /**
        * input_loss_image_slate block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#input_loss_image_slate AwsChannel#input_loss_image_slate}
        */
        readonly inputLossImageSlate?: InputLossImageSlateProperty;
    }
    class InputLossBehaviorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InputLossBehaviorProperty | undefined;
        set internalValue(value: InputLossBehaviorProperty | undefined);
        private _blackFrameMsec?;
        get blackFrameMsec(): number;
        set blackFrameMsec(value: number);
        resetBlackFrameMsec(): void;
        get blackFrameMsecInput(): number | undefined;
        private _inputLossImageColor?;
        get inputLossImageColor(): string;
        set inputLossImageColor(value: string);
        resetInputLossImageColor(): void;
        get inputLossImageColorInput(): string | undefined;
        private _inputLossImageType?;
        get inputLossImageType(): string;
        set inputLossImageType(value: string);
        resetInputLossImageType(): void;
        get inputLossImageTypeInput(): string | undefined;
        private _repeatFrameMsec?;
        get repeatFrameMsec(): number;
        set repeatFrameMsec(value: number);
        resetRepeatFrameMsec(): void;
        get repeatFrameMsecInput(): number | undefined;
        private _inputLossImageSlate;
        get inputLossImageSlate(): InputLossImageSlatePropertyOutputReference;
        putInputLossImageSlate(value: InputLossImageSlateProperty): void;
        resetInputLossImageSlate(): void;
        get inputLossImageSlateInput(): InputLossImageSlateProperty | undefined;
    }
    interface GlobalConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#initial_audio_gain AwsChannel#initial_audio_gain}
        */
        readonly initialAudioGain?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#input_end_action AwsChannel#input_end_action}
        */
        readonly inputEndAction?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#output_locking_mode AwsChannel#output_locking_mode}
        */
        readonly outputLockingMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#output_timing_source AwsChannel#output_timing_source}
        */
        readonly outputTimingSource?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#support_low_framerate_inputs AwsChannel#support_low_framerate_inputs}
        */
        readonly supportLowFramerateInputs?: string;
        /**
        * input_loss_behavior block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#input_loss_behavior AwsChannel#input_loss_behavior}
        */
        readonly inputLossBehavior?: InputLossBehaviorProperty;
    }
    class GlobalConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): GlobalConfigurationProperty | undefined;
        set internalValue(value: GlobalConfigurationProperty | undefined);
        private _initialAudioGain?;
        get initialAudioGain(): number;
        set initialAudioGain(value: number);
        resetInitialAudioGain(): void;
        get initialAudioGainInput(): number | undefined;
        private _inputEndAction?;
        get inputEndAction(): string;
        set inputEndAction(value: string);
        resetInputEndAction(): void;
        get inputEndActionInput(): string | undefined;
        private _outputLockingMode?;
        get outputLockingMode(): string;
        set outputLockingMode(value: string);
        resetOutputLockingMode(): void;
        get outputLockingModeInput(): string | undefined;
        private _outputTimingSource?;
        get outputTimingSource(): string;
        set outputTimingSource(value: string);
        resetOutputTimingSource(): void;
        get outputTimingSourceInput(): string | undefined;
        private _supportLowFramerateInputs?;
        get supportLowFramerateInputs(): string;
        set supportLowFramerateInputs(value: string);
        resetSupportLowFramerateInputs(): void;
        get supportLowFramerateInputsInput(): string | undefined;
        private _inputLossBehavior;
        get inputLossBehavior(): InputLossBehaviorPropertyOutputReference;
        putInputLossBehavior(value: InputLossBehaviorProperty): void;
        resetInputLossBehavior(): void;
        get inputLossBehaviorInput(): InputLossBehaviorProperty | undefined;
    }
    interface HtmlMotionGraphicsSettingsProperty {
    }
    class HtmlMotionGraphicsSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HtmlMotionGraphicsSettingsProperty | undefined;
        set internalValue(value: HtmlMotionGraphicsSettingsProperty | undefined);
    }
    interface MotionGraphicsSettingsProperty {
        /**
        * html_motion_graphics_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#html_motion_graphics_settings AwsChannel#html_motion_graphics_settings}
        */
        readonly htmlMotionGraphicsSettings?: HtmlMotionGraphicsSettingsProperty;
    }
    class MotionGraphicsSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MotionGraphicsSettingsProperty | undefined;
        set internalValue(value: MotionGraphicsSettingsProperty | undefined);
        private _htmlMotionGraphicsSettings;
        get htmlMotionGraphicsSettings(): HtmlMotionGraphicsSettingsPropertyOutputReference;
        putHtmlMotionGraphicsSettings(value: HtmlMotionGraphicsSettingsProperty): void;
        resetHtmlMotionGraphicsSettings(): void;
        get htmlMotionGraphicsSettingsInput(): HtmlMotionGraphicsSettingsProperty | undefined;
    }
    interface MotionGraphicsConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#motion_graphics_insertion AwsChannel#motion_graphics_insertion}
        */
        readonly motionGraphicsInsertion?: string;
        /**
        * motion_graphics_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#motion_graphics_settings AwsChannel#motion_graphics_settings}
        */
        readonly motionGraphicsSettings: MotionGraphicsSettingsProperty;
    }
    class MotionGraphicsConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MotionGraphicsConfigurationProperty | undefined;
        set internalValue(value: MotionGraphicsConfigurationProperty | undefined);
        private _motionGraphicsInsertion?;
        get motionGraphicsInsertion(): string;
        set motionGraphicsInsertion(value: string);
        resetMotionGraphicsInsertion(): void;
        get motionGraphicsInsertionInput(): string | undefined;
        private _motionGraphicsSettings;
        get motionGraphicsSettings(): MotionGraphicsSettingsPropertyOutputReference;
        putMotionGraphicsSettings(value: MotionGraphicsSettingsProperty): void;
        get motionGraphicsSettingsInput(): MotionGraphicsSettingsProperty | undefined;
    }
    interface NielsenConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#distributor_id AwsChannel#distributor_id}
        */
        readonly distributorId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#nielsen_pcm_to_id3_tagging AwsChannel#nielsen_pcm_to_id3_tagging}
        */
        readonly nielsenPcmToId3Tagging?: string;
    }
    class NielsenConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NielsenConfigurationProperty | undefined;
        set internalValue(value: NielsenConfigurationProperty | undefined);
        private _distributorId?;
        get distributorId(): string;
        set distributorId(value: string);
        resetDistributorId(): void;
        get distributorIdInput(): string | undefined;
        private _nielsenPcmToId3Tagging?;
        get nielsenPcmToId3Tagging(): string;
        set nielsenPcmToId3Tagging(value: string);
        resetNielsenPcmToId3Tagging(): void;
        get nielsenPcmToId3TaggingInput(): string | undefined;
    }
    interface ArchiveS3SettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#canned_acl AwsChannel#canned_acl}
        */
        readonly cannedAcl?: string;
    }
    class ArchiveS3SettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ArchiveS3SettingsProperty | undefined;
        set internalValue(value: ArchiveS3SettingsProperty | undefined);
        private _cannedAcl?;
        get cannedAcl(): string;
        set cannedAcl(value: string);
        resetCannedAcl(): void;
        get cannedAclInput(): string | undefined;
    }
    interface ArchiveCdnSettingsProperty {
        /**
        * archive_s3_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#archive_s3_settings AwsChannel#archive_s3_settings}
        */
        readonly archiveS3Settings?: ArchiveS3SettingsProperty;
    }
    class ArchiveCdnSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ArchiveCdnSettingsProperty | undefined;
        set internalValue(value: ArchiveCdnSettingsProperty | undefined);
        private _archiveS3Settings;
        get archiveS3Settings(): ArchiveS3SettingsPropertyOutputReference;
        putArchiveS3Settings(value: ArchiveS3SettingsProperty): void;
        resetArchiveS3Settings(): void;
        get archiveS3SettingsInput(): ArchiveS3SettingsProperty | undefined;
    }
    interface EncoderSettingsOutputGroupsOutputGroupSettingsArchiveGroupSettingsDestinationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#destination_ref_id AwsChannel#destination_ref_id}
        */
        readonly destinationRefId: string;
    }
    class EncoderSettingsOutputGroupsOutputGroupSettingsArchiveGroupSettingsDestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncoderSettingsOutputGroupsOutputGroupSettingsArchiveGroupSettingsDestinationProperty | undefined;
        set internalValue(value: EncoderSettingsOutputGroupsOutputGroupSettingsArchiveGroupSettingsDestinationProperty | undefined);
        private _destinationRefId?;
        get destinationRefId(): string;
        set destinationRefId(value: string);
        get destinationRefIdInput(): string | undefined;
    }
    interface ArchiveGroupSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#rollover_interval AwsChannel#rollover_interval}
        */
        readonly rolloverInterval?: number;
        /**
        * archive_cdn_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#archive_cdn_settings AwsChannel#archive_cdn_settings}
        */
        readonly archiveCdnSettings?: ArchiveCdnSettingsProperty;
        /**
        * destination block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#destination AwsChannel#destination}
        */
        readonly destination: EncoderSettingsOutputGroupsOutputGroupSettingsArchiveGroupSettingsDestinationProperty;
    }
    class ArchiveGroupSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ArchiveGroupSettingsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ArchiveGroupSettingsProperty | cdktn.IResolvable | undefined);
        private _rolloverInterval?;
        get rolloverInterval(): number;
        set rolloverInterval(value: number);
        resetRolloverInterval(): void;
        get rolloverIntervalInput(): number | undefined;
        private _archiveCdnSettings;
        get archiveCdnSettings(): ArchiveCdnSettingsPropertyOutputReference;
        putArchiveCdnSettings(value: ArchiveCdnSettingsProperty): void;
        resetArchiveCdnSettings(): void;
        get archiveCdnSettingsInput(): ArchiveCdnSettingsProperty | undefined;
        private _destination;
        get destination(): EncoderSettingsOutputGroupsOutputGroupSettingsArchiveGroupSettingsDestinationPropertyOutputReference;
        putDestination(value: EncoderSettingsOutputGroupsOutputGroupSettingsArchiveGroupSettingsDestinationProperty): void;
        get destinationInput(): EncoderSettingsOutputGroupsOutputGroupSettingsArchiveGroupSettingsDestinationProperty | undefined;
    }
    class ArchiveGroupSettingsPropertyList extends cdktn.ComplexList {
        internalValue?: ArchiveGroupSettingsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ArchiveGroupSettingsPropertyOutputReference;
    }
    interface EncoderSettingsOutputGroupsOutputGroupSettingsFrameCaptureGroupSettingsDestinationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#destination_ref_id AwsChannel#destination_ref_id}
        */
        readonly destinationRefId: string;
    }
    class EncoderSettingsOutputGroupsOutputGroupSettingsFrameCaptureGroupSettingsDestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncoderSettingsOutputGroupsOutputGroupSettingsFrameCaptureGroupSettingsDestinationProperty | undefined;
        set internalValue(value: EncoderSettingsOutputGroupsOutputGroupSettingsFrameCaptureGroupSettingsDestinationProperty | undefined);
        private _destinationRefId?;
        get destinationRefId(): string;
        set destinationRefId(value: string);
        get destinationRefIdInput(): string | undefined;
    }
    interface FrameCaptureS3SettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#canned_acl AwsChannel#canned_acl}
        */
        readonly cannedAcl?: string;
    }
    class FrameCaptureS3SettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FrameCaptureS3SettingsProperty | undefined;
        set internalValue(value: FrameCaptureS3SettingsProperty | undefined);
        private _cannedAcl?;
        get cannedAcl(): string;
        set cannedAcl(value: string);
        resetCannedAcl(): void;
        get cannedAclInput(): string | undefined;
    }
    interface FrameCaptureCdnSettingsProperty {
        /**
        * frame_capture_s3_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#frame_capture_s3_settings AwsChannel#frame_capture_s3_settings}
        */
        readonly frameCaptureS3Settings?: FrameCaptureS3SettingsProperty;
    }
    class FrameCaptureCdnSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FrameCaptureCdnSettingsProperty | undefined;
        set internalValue(value: FrameCaptureCdnSettingsProperty | undefined);
        private _frameCaptureS3Settings;
        get frameCaptureS3Settings(): FrameCaptureS3SettingsPropertyOutputReference;
        putFrameCaptureS3Settings(value: FrameCaptureS3SettingsProperty): void;
        resetFrameCaptureS3Settings(): void;
        get frameCaptureS3SettingsInput(): FrameCaptureS3SettingsProperty | undefined;
    }
    interface FrameCaptureGroupSettingsProperty {
        /**
        * destination block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#destination AwsChannel#destination}
        */
        readonly destination: EncoderSettingsOutputGroupsOutputGroupSettingsFrameCaptureGroupSettingsDestinationProperty;
        /**
        * frame_capture_cdn_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#frame_capture_cdn_settings AwsChannel#frame_capture_cdn_settings}
        */
        readonly frameCaptureCdnSettings?: FrameCaptureCdnSettingsProperty;
    }
    class FrameCaptureGroupSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FrameCaptureGroupSettingsProperty | undefined;
        set internalValue(value: FrameCaptureGroupSettingsProperty | undefined);
        private _destination;
        get destination(): EncoderSettingsOutputGroupsOutputGroupSettingsFrameCaptureGroupSettingsDestinationPropertyOutputReference;
        putDestination(value: EncoderSettingsOutputGroupsOutputGroupSettingsFrameCaptureGroupSettingsDestinationProperty): void;
        get destinationInput(): EncoderSettingsOutputGroupsOutputGroupSettingsFrameCaptureGroupSettingsDestinationProperty | undefined;
        private _frameCaptureCdnSettings;
        get frameCaptureCdnSettings(): FrameCaptureCdnSettingsPropertyOutputReference;
        putFrameCaptureCdnSettings(value: FrameCaptureCdnSettingsProperty): void;
        resetFrameCaptureCdnSettings(): void;
        get frameCaptureCdnSettingsInput(): FrameCaptureCdnSettingsProperty | undefined;
    }
    interface CaptionLanguageMappingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#caption_channel AwsChannel#caption_channel}
        */
        readonly captionChannel: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#language_code AwsChannel#language_code}
        */
        readonly languageCode: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#language_description AwsChannel#language_description}
        */
        readonly languageDescription: string;
    }
    class CaptionLanguageMappingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CaptionLanguageMappingsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CaptionLanguageMappingsProperty | cdktn.IResolvable | undefined);
        private _captionChannel?;
        get captionChannel(): number;
        set captionChannel(value: number);
        get captionChannelInput(): number | undefined;
        private _languageCode?;
        get languageCode(): string;
        set languageCode(value: string);
        get languageCodeInput(): string | undefined;
        private _languageDescription?;
        get languageDescription(): string;
        set languageDescription(value: string);
        get languageDescriptionInput(): string | undefined;
    }
    class CaptionLanguageMappingsPropertyList extends cdktn.ComplexList {
        internalValue?: CaptionLanguageMappingsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CaptionLanguageMappingsPropertyOutputReference;
    }
    interface EncoderSettingsOutputGroupsOutputGroupSettingsHlsGroupSettingsDestinationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#destination_ref_id AwsChannel#destination_ref_id}
        */
        readonly destinationRefId: string;
    }
    class EncoderSettingsOutputGroupsOutputGroupSettingsHlsGroupSettingsDestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncoderSettingsOutputGroupsOutputGroupSettingsHlsGroupSettingsDestinationProperty | undefined;
        set internalValue(value: EncoderSettingsOutputGroupsOutputGroupSettingsHlsGroupSettingsDestinationProperty | undefined);
        private _destinationRefId?;
        get destinationRefId(): string;
        set destinationRefId(value: string);
        get destinationRefIdInput(): string | undefined;
    }
    interface HlsAkamaiSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#connection_retry_interval AwsChannel#connection_retry_interval}
        */
        readonly connectionRetryInterval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#filecache_duration AwsChannel#filecache_duration}
        */
        readonly filecacheDuration?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#http_transfer_mode AwsChannel#http_transfer_mode}
        */
        readonly httpTransferMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#num_retries AwsChannel#num_retries}
        */
        readonly numRetries?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#restart_delay AwsChannel#restart_delay}
        */
        readonly restartDelay?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#salt AwsChannel#salt}
        */
        readonly salt?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#token AwsChannel#token}
        */
        readonly token?: string;
    }
    class HlsAkamaiSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HlsAkamaiSettingsProperty | undefined;
        set internalValue(value: HlsAkamaiSettingsProperty | undefined);
        private _connectionRetryInterval?;
        get connectionRetryInterval(): number;
        set connectionRetryInterval(value: number);
        resetConnectionRetryInterval(): void;
        get connectionRetryIntervalInput(): number | undefined;
        private _filecacheDuration?;
        get filecacheDuration(): number;
        set filecacheDuration(value: number);
        resetFilecacheDuration(): void;
        get filecacheDurationInput(): number | undefined;
        private _httpTransferMode?;
        get httpTransferMode(): string;
        set httpTransferMode(value: string);
        resetHttpTransferMode(): void;
        get httpTransferModeInput(): string | undefined;
        private _numRetries?;
        get numRetries(): number;
        set numRetries(value: number);
        resetNumRetries(): void;
        get numRetriesInput(): number | undefined;
        private _restartDelay?;
        get restartDelay(): number;
        set restartDelay(value: number);
        resetRestartDelay(): void;
        get restartDelayInput(): number | undefined;
        private _salt?;
        get salt(): string;
        set salt(value: string);
        resetSalt(): void;
        get saltInput(): string | undefined;
        private _token?;
        get token(): string;
        set token(value: string);
        resetToken(): void;
        get tokenInput(): string | undefined;
    }
    interface HlsBasicPutSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#connection_retry_interval AwsChannel#connection_retry_interval}
        */
        readonly connectionRetryInterval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#filecache_duration AwsChannel#filecache_duration}
        */
        readonly filecacheDuration?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#num_retries AwsChannel#num_retries}
        */
        readonly numRetries?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#restart_delay AwsChannel#restart_delay}
        */
        readonly restartDelay?: number;
    }
    class HlsBasicPutSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HlsBasicPutSettingsProperty | undefined;
        set internalValue(value: HlsBasicPutSettingsProperty | undefined);
        private _connectionRetryInterval?;
        get connectionRetryInterval(): number;
        set connectionRetryInterval(value: number);
        resetConnectionRetryInterval(): void;
        get connectionRetryIntervalInput(): number | undefined;
        private _filecacheDuration?;
        get filecacheDuration(): number;
        set filecacheDuration(value: number);
        resetFilecacheDuration(): void;
        get filecacheDurationInput(): number | undefined;
        private _numRetries?;
        get numRetries(): number;
        set numRetries(value: number);
        resetNumRetries(): void;
        get numRetriesInput(): number | undefined;
        private _restartDelay?;
        get restartDelay(): number;
        set restartDelay(value: number);
        resetRestartDelay(): void;
        get restartDelayInput(): number | undefined;
    }
    interface HlsMediaStoreSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#connection_retry_interval AwsChannel#connection_retry_interval}
        */
        readonly connectionRetryInterval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#filecache_duration AwsChannel#filecache_duration}
        */
        readonly filecacheDuration?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#media_store_storage_class AwsChannel#media_store_storage_class}
        */
        readonly mediaStoreStorageClass?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#num_retries AwsChannel#num_retries}
        */
        readonly numRetries?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#restart_delay AwsChannel#restart_delay}
        */
        readonly restartDelay?: number;
    }
    class HlsMediaStoreSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HlsMediaStoreSettingsProperty | undefined;
        set internalValue(value: HlsMediaStoreSettingsProperty | undefined);
        private _connectionRetryInterval?;
        get connectionRetryInterval(): number;
        set connectionRetryInterval(value: number);
        resetConnectionRetryInterval(): void;
        get connectionRetryIntervalInput(): number | undefined;
        private _filecacheDuration?;
        get filecacheDuration(): number;
        set filecacheDuration(value: number);
        resetFilecacheDuration(): void;
        get filecacheDurationInput(): number | undefined;
        private _mediaStoreStorageClass?;
        get mediaStoreStorageClass(): string;
        set mediaStoreStorageClass(value: string);
        resetMediaStoreStorageClass(): void;
        get mediaStoreStorageClassInput(): string | undefined;
        private _numRetries?;
        get numRetries(): number;
        set numRetries(value: number);
        resetNumRetries(): void;
        get numRetriesInput(): number | undefined;
        private _restartDelay?;
        get restartDelay(): number;
        set restartDelay(value: number);
        resetRestartDelay(): void;
        get restartDelayInput(): number | undefined;
    }
    interface HlsS3SettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#canned_acl AwsChannel#canned_acl}
        */
        readonly cannedAcl?: string;
    }
    class HlsS3SettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HlsS3SettingsProperty | undefined;
        set internalValue(value: HlsS3SettingsProperty | undefined);
        private _cannedAcl?;
        get cannedAcl(): string;
        set cannedAcl(value: string);
        resetCannedAcl(): void;
        get cannedAclInput(): string | undefined;
    }
    interface HlsWebdavSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#connection_retry_interval AwsChannel#connection_retry_interval}
        */
        readonly connectionRetryInterval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#filecache_duration AwsChannel#filecache_duration}
        */
        readonly filecacheDuration?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#http_transfer_mode AwsChannel#http_transfer_mode}
        */
        readonly httpTransferMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#num_retries AwsChannel#num_retries}
        */
        readonly numRetries?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#restart_delay AwsChannel#restart_delay}
        */
        readonly restartDelay?: number;
    }
    class HlsWebdavSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HlsWebdavSettingsProperty | undefined;
        set internalValue(value: HlsWebdavSettingsProperty | undefined);
        private _connectionRetryInterval?;
        get connectionRetryInterval(): number;
        set connectionRetryInterval(value: number);
        resetConnectionRetryInterval(): void;
        get connectionRetryIntervalInput(): number | undefined;
        private _filecacheDuration?;
        get filecacheDuration(): number;
        set filecacheDuration(value: number);
        resetFilecacheDuration(): void;
        get filecacheDurationInput(): number | undefined;
        private _httpTransferMode?;
        get httpTransferMode(): string;
        set httpTransferMode(value: string);
        resetHttpTransferMode(): void;
        get httpTransferModeInput(): string | undefined;
        private _numRetries?;
        get numRetries(): number;
        set numRetries(value: number);
        resetNumRetries(): void;
        get numRetriesInput(): number | undefined;
        private _restartDelay?;
        get restartDelay(): number;
        set restartDelay(value: number);
        resetRestartDelay(): void;
        get restartDelayInput(): number | undefined;
    }
    interface HlsCdnSettingsProperty {
        /**
        * hls_akamai_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#hls_akamai_settings AwsChannel#hls_akamai_settings}
        */
        readonly hlsAkamaiSettings?: HlsAkamaiSettingsProperty;
        /**
        * hls_basic_put_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#hls_basic_put_settings AwsChannel#hls_basic_put_settings}
        */
        readonly hlsBasicPutSettings?: HlsBasicPutSettingsProperty;
        /**
        * hls_media_store_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#hls_media_store_settings AwsChannel#hls_media_store_settings}
        */
        readonly hlsMediaStoreSettings?: HlsMediaStoreSettingsProperty;
        /**
        * hls_s3_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#hls_s3_settings AwsChannel#hls_s3_settings}
        */
        readonly hlsS3Settings?: HlsS3SettingsProperty;
        /**
        * hls_webdav_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#hls_webdav_settings AwsChannel#hls_webdav_settings}
        */
        readonly hlsWebdavSettings?: HlsWebdavSettingsProperty;
    }
    class HlsCdnSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HlsCdnSettingsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HlsCdnSettingsProperty | cdktn.IResolvable | undefined);
        private _hlsAkamaiSettings;
        get hlsAkamaiSettings(): HlsAkamaiSettingsPropertyOutputReference;
        putHlsAkamaiSettings(value: HlsAkamaiSettingsProperty): void;
        resetHlsAkamaiSettings(): void;
        get hlsAkamaiSettingsInput(): HlsAkamaiSettingsProperty | undefined;
        private _hlsBasicPutSettings;
        get hlsBasicPutSettings(): HlsBasicPutSettingsPropertyOutputReference;
        putHlsBasicPutSettings(value: HlsBasicPutSettingsProperty): void;
        resetHlsBasicPutSettings(): void;
        get hlsBasicPutSettingsInput(): HlsBasicPutSettingsProperty | undefined;
        private _hlsMediaStoreSettings;
        get hlsMediaStoreSettings(): HlsMediaStoreSettingsPropertyOutputReference;
        putHlsMediaStoreSettings(value: HlsMediaStoreSettingsProperty): void;
        resetHlsMediaStoreSettings(): void;
        get hlsMediaStoreSettingsInput(): HlsMediaStoreSettingsProperty | undefined;
        private _hlsS3Settings;
        get hlsS3Settings(): HlsS3SettingsPropertyOutputReference;
        putHlsS3Settings(value: HlsS3SettingsProperty): void;
        resetHlsS3Settings(): void;
        get hlsS3SettingsInput(): HlsS3SettingsProperty | undefined;
        private _hlsWebdavSettings;
        get hlsWebdavSettings(): HlsWebdavSettingsPropertyOutputReference;
        putHlsWebdavSettings(value: HlsWebdavSettingsProperty): void;
        resetHlsWebdavSettings(): void;
        get hlsWebdavSettingsInput(): HlsWebdavSettingsProperty | undefined;
    }
    class HlsCdnSettingsPropertyList extends cdktn.ComplexList {
        internalValue?: HlsCdnSettingsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HlsCdnSettingsPropertyOutputReference;
    }
    interface KeyProviderServerProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#password_param AwsChannel#password_param}
        */
        readonly passwordParam?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#uri AwsChannel#uri}
        */
        readonly uri: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#username AwsChannel#username}
        */
        readonly username?: string;
    }
    class KeyProviderServerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KeyProviderServerProperty | undefined;
        set internalValue(value: KeyProviderServerProperty | undefined);
        private _passwordParam?;
        get passwordParam(): string;
        set passwordParam(value: string);
        resetPasswordParam(): void;
        get passwordParamInput(): string | undefined;
        private _uri?;
        get uri(): string;
        set uri(value: string);
        get uriInput(): string | undefined;
        private _username?;
        get username(): string;
        set username(value: string);
        resetUsername(): void;
        get usernameInput(): string | undefined;
    }
    interface StaticKeySettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#static_key_value AwsChannel#static_key_value}
        */
        readonly staticKeyValue: string;
        /**
        * key_provider_server block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#key_provider_server AwsChannel#key_provider_server}
        */
        readonly keyProviderServer?: KeyProviderServerProperty;
    }
    class StaticKeySettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StaticKeySettingsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StaticKeySettingsProperty | cdktn.IResolvable | undefined);
        private _staticKeyValue?;
        get staticKeyValue(): string;
        set staticKeyValue(value: string);
        get staticKeyValueInput(): string | undefined;
        private _keyProviderServer;
        get keyProviderServer(): KeyProviderServerPropertyOutputReference;
        putKeyProviderServer(value: KeyProviderServerProperty): void;
        resetKeyProviderServer(): void;
        get keyProviderServerInput(): KeyProviderServerProperty | undefined;
    }
    class StaticKeySettingsPropertyList extends cdktn.ComplexList {
        internalValue?: StaticKeySettingsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StaticKeySettingsPropertyOutputReference;
    }
    interface KeyProviderSettingsProperty {
        /**
        * static_key_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#static_key_settings AwsChannel#static_key_settings}
        */
        readonly staticKeySettings?: StaticKeySettingsProperty[] | cdktn.IResolvable;
    }
    class KeyProviderSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KeyProviderSettingsProperty | undefined;
        set internalValue(value: KeyProviderSettingsProperty | undefined);
        private _staticKeySettings;
        get staticKeySettings(): StaticKeySettingsPropertyList;
        putStaticKeySettings(value: StaticKeySettingsProperty[] | cdktn.IResolvable): void;
        resetStaticKeySettings(): void;
        get staticKeySettingsInput(): cdktn.IResolvable | StaticKeySettingsProperty[] | undefined;
    }
    interface HlsGroupSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#ad_markers AwsChannel#ad_markers}
        */
        readonly adMarkers?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#base_url_content AwsChannel#base_url_content}
        */
        readonly baseUrlContent?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#base_url_content1 AwsChannel#base_url_content1}
        */
        readonly baseUrlContent1?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#base_url_manifest AwsChannel#base_url_manifest}
        */
        readonly baseUrlManifest?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#base_url_manifest1 AwsChannel#base_url_manifest1}
        */
        readonly baseUrlManifest1?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#caption_language_setting AwsChannel#caption_language_setting}
        */
        readonly captionLanguageSetting?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#client_cache AwsChannel#client_cache}
        */
        readonly clientCache?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#codec_specification AwsChannel#codec_specification}
        */
        readonly codecSpecification?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#constant_iv AwsChannel#constant_iv}
        */
        readonly constantIv?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#directory_structure AwsChannel#directory_structure}
        */
        readonly directoryStructure?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#discontinuity_tags AwsChannel#discontinuity_tags}
        */
        readonly discontinuityTags?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#encryption_type AwsChannel#encryption_type}
        */
        readonly encryptionType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#hls_id3_segment_tagging AwsChannel#hls_id3_segment_tagging}
        */
        readonly hlsId3SegmentTagging?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#iframe_only_playlists AwsChannel#iframe_only_playlists}
        */
        readonly iframeOnlyPlaylists?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#incomplete_segment_behavior AwsChannel#incomplete_segment_behavior}
        */
        readonly incompleteSegmentBehavior?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#index_n_segments AwsChannel#index_n_segments}
        */
        readonly indexNSegments?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#input_loss_action AwsChannel#input_loss_action}
        */
        readonly inputLossAction?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#iv_in_manifest AwsChannel#iv_in_manifest}
        */
        readonly ivInManifest?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#iv_source AwsChannel#iv_source}
        */
        readonly ivSource?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#keep_segments AwsChannel#keep_segments}
        */
        readonly keepSegments?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#key_format AwsChannel#key_format}
        */
        readonly keyFormat?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#key_format_versions AwsChannel#key_format_versions}
        */
        readonly keyFormatVersions?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#manifest_compression AwsChannel#manifest_compression}
        */
        readonly manifestCompression?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#manifest_duration_format AwsChannel#manifest_duration_format}
        */
        readonly manifestDurationFormat?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#min_segment_length AwsChannel#min_segment_length}
        */
        readonly minSegmentLength?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#mode AwsChannel#mode}
        */
        readonly mode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#output_selection AwsChannel#output_selection}
        */
        readonly outputSelection?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#program_date_time AwsChannel#program_date_time}
        */
        readonly programDateTime?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#program_date_time_clock AwsChannel#program_date_time_clock}
        */
        readonly programDateTimeClock?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#program_date_time_period AwsChannel#program_date_time_period}
        */
        readonly programDateTimePeriod?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#redundant_manifest AwsChannel#redundant_manifest}
        */
        readonly redundantManifest?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#segment_length AwsChannel#segment_length}
        */
        readonly segmentLength?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#segments_per_subdirectory AwsChannel#segments_per_subdirectory}
        */
        readonly segmentsPerSubdirectory?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#stream_inf_resolution AwsChannel#stream_inf_resolution}
        */
        readonly streamInfResolution?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#timed_metadata_id3_frame AwsChannel#timed_metadata_id3_frame}
        */
        readonly timedMetadataId3Frame?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#timed_metadata_id3_period AwsChannel#timed_metadata_id3_period}
        */
        readonly timedMetadataId3Period?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#timestamp_delta_milliseconds AwsChannel#timestamp_delta_milliseconds}
        */
        readonly timestampDeltaMilliseconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#ts_file_mode AwsChannel#ts_file_mode}
        */
        readonly tsFileMode?: string;
        /**
        * caption_language_mappings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#caption_language_mappings AwsChannel#caption_language_mappings}
        */
        readonly captionLanguageMappings?: CaptionLanguageMappingsProperty[] | cdktn.IResolvable;
        /**
        * destination block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#destination AwsChannel#destination}
        */
        readonly destination: EncoderSettingsOutputGroupsOutputGroupSettingsHlsGroupSettingsDestinationProperty;
        /**
        * hls_cdn_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#hls_cdn_settings AwsChannel#hls_cdn_settings}
        */
        readonly hlsCdnSettings?: HlsCdnSettingsProperty[] | cdktn.IResolvable;
        /**
        * key_provider_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#key_provider_settings AwsChannel#key_provider_settings}
        */
        readonly keyProviderSettings?: KeyProviderSettingsProperty;
    }
    class HlsGroupSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HlsGroupSettingsProperty | undefined;
        set internalValue(value: HlsGroupSettingsProperty | undefined);
        private _adMarkers?;
        get adMarkers(): string[];
        set adMarkers(value: string[]);
        resetAdMarkers(): void;
        get adMarkersInput(): string[] | undefined;
        private _baseUrlContent?;
        get baseUrlContent(): string;
        set baseUrlContent(value: string);
        resetBaseUrlContent(): void;
        get baseUrlContentInput(): string | undefined;
        private _baseUrlContent1?;
        get baseUrlContent1(): string;
        set baseUrlContent1(value: string);
        resetBaseUrlContent1(): void;
        get baseUrlContent1Input(): string | undefined;
        private _baseUrlManifest?;
        get baseUrlManifest(): string;
        set baseUrlManifest(value: string);
        resetBaseUrlManifest(): void;
        get baseUrlManifestInput(): string | undefined;
        private _baseUrlManifest1?;
        get baseUrlManifest1(): string;
        set baseUrlManifest1(value: string);
        resetBaseUrlManifest1(): void;
        get baseUrlManifest1Input(): string | undefined;
        private _captionLanguageSetting?;
        get captionLanguageSetting(): string;
        set captionLanguageSetting(value: string);
        resetCaptionLanguageSetting(): void;
        get captionLanguageSettingInput(): string | undefined;
        private _clientCache?;
        get clientCache(): string;
        set clientCache(value: string);
        resetClientCache(): void;
        get clientCacheInput(): string | undefined;
        private _codecSpecification?;
        get codecSpecification(): string;
        set codecSpecification(value: string);
        resetCodecSpecification(): void;
        get codecSpecificationInput(): string | undefined;
        private _constantIv?;
        get constantIv(): string;
        set constantIv(value: string);
        resetConstantIv(): void;
        get constantIvInput(): string | undefined;
        private _directoryStructure?;
        get directoryStructure(): string;
        set directoryStructure(value: string);
        resetDirectoryStructure(): void;
        get directoryStructureInput(): string | undefined;
        private _discontinuityTags?;
        get discontinuityTags(): string;
        set discontinuityTags(value: string);
        resetDiscontinuityTags(): void;
        get discontinuityTagsInput(): string | undefined;
        private _encryptionType?;
        get encryptionType(): string;
        set encryptionType(value: string);
        resetEncryptionType(): void;
        get encryptionTypeInput(): string | undefined;
        private _hlsId3SegmentTagging?;
        get hlsId3SegmentTagging(): string;
        set hlsId3SegmentTagging(value: string);
        resetHlsId3SegmentTagging(): void;
        get hlsId3SegmentTaggingInput(): string | undefined;
        private _iframeOnlyPlaylists?;
        get iframeOnlyPlaylists(): string;
        set iframeOnlyPlaylists(value: string);
        resetIframeOnlyPlaylists(): void;
        get iframeOnlyPlaylistsInput(): string | undefined;
        private _incompleteSegmentBehavior?;
        get incompleteSegmentBehavior(): string;
        set incompleteSegmentBehavior(value: string);
        resetIncompleteSegmentBehavior(): void;
        get incompleteSegmentBehaviorInput(): string | undefined;
        private _indexNSegments?;
        get indexNSegments(): number;
        set indexNSegments(value: number);
        resetIndexNSegments(): void;
        get indexNSegmentsInput(): number | undefined;
        private _inputLossAction?;
        get inputLossAction(): string;
        set inputLossAction(value: string);
        resetInputLossAction(): void;
        get inputLossActionInput(): string | undefined;
        private _ivInManifest?;
        get ivInManifest(): string;
        set ivInManifest(value: string);
        resetIvInManifest(): void;
        get ivInManifestInput(): string | undefined;
        private _ivSource?;
        get ivSource(): string;
        set ivSource(value: string);
        resetIvSource(): void;
        get ivSourceInput(): string | undefined;
        private _keepSegments?;
        get keepSegments(): number;
        set keepSegments(value: number);
        resetKeepSegments(): void;
        get keepSegmentsInput(): number | undefined;
        private _keyFormat?;
        get keyFormat(): string;
        set keyFormat(value: string);
        resetKeyFormat(): void;
        get keyFormatInput(): string | undefined;
        private _keyFormatVersions?;
        get keyFormatVersions(): string;
        set keyFormatVersions(value: string);
        resetKeyFormatVersions(): void;
        get keyFormatVersionsInput(): string | undefined;
        private _manifestCompression?;
        get manifestCompression(): string;
        set manifestCompression(value: string);
        resetManifestCompression(): void;
        get manifestCompressionInput(): string | undefined;
        private _manifestDurationFormat?;
        get manifestDurationFormat(): string;
        set manifestDurationFormat(value: string);
        resetManifestDurationFormat(): void;
        get manifestDurationFormatInput(): string | undefined;
        private _minSegmentLength?;
        get minSegmentLength(): number;
        set minSegmentLength(value: number);
        resetMinSegmentLength(): void;
        get minSegmentLengthInput(): number | undefined;
        private _mode?;
        get mode(): string;
        set mode(value: string);
        resetMode(): void;
        get modeInput(): string | undefined;
        private _outputSelection?;
        get outputSelection(): string;
        set outputSelection(value: string);
        resetOutputSelection(): void;
        get outputSelectionInput(): string | undefined;
        private _programDateTime?;
        get programDateTime(): string;
        set programDateTime(value: string);
        resetProgramDateTime(): void;
        get programDateTimeInput(): string | undefined;
        private _programDateTimeClock?;
        get programDateTimeClock(): string;
        set programDateTimeClock(value: string);
        resetProgramDateTimeClock(): void;
        get programDateTimeClockInput(): string | undefined;
        private _programDateTimePeriod?;
        get programDateTimePeriod(): number;
        set programDateTimePeriod(value: number);
        resetProgramDateTimePeriod(): void;
        get programDateTimePeriodInput(): number | undefined;
        private _redundantManifest?;
        get redundantManifest(): string;
        set redundantManifest(value: string);
        resetRedundantManifest(): void;
        get redundantManifestInput(): string | undefined;
        private _segmentLength?;
        get segmentLength(): number;
        set segmentLength(value: number);
        resetSegmentLength(): void;
        get segmentLengthInput(): number | undefined;
        private _segmentsPerSubdirectory?;
        get segmentsPerSubdirectory(): number;
        set segmentsPerSubdirectory(value: number);
        resetSegmentsPerSubdirectory(): void;
        get segmentsPerSubdirectoryInput(): number | undefined;
        private _streamInfResolution?;
        get streamInfResolution(): string;
        set streamInfResolution(value: string);
        resetStreamInfResolution(): void;
        get streamInfResolutionInput(): string | undefined;
        private _timedMetadataId3Frame?;
        get timedMetadataId3Frame(): string;
        set timedMetadataId3Frame(value: string);
        resetTimedMetadataId3Frame(): void;
        get timedMetadataId3FrameInput(): string | undefined;
        private _timedMetadataId3Period?;
        get timedMetadataId3Period(): number;
        set timedMetadataId3Period(value: number);
        resetTimedMetadataId3Period(): void;
        get timedMetadataId3PeriodInput(): number | undefined;
        private _timestampDeltaMilliseconds?;
        get timestampDeltaMilliseconds(): number;
        set timestampDeltaMilliseconds(value: number);
        resetTimestampDeltaMilliseconds(): void;
        get timestampDeltaMillisecondsInput(): number | undefined;
        private _tsFileMode?;
        get tsFileMode(): string;
        set tsFileMode(value: string);
        resetTsFileMode(): void;
        get tsFileModeInput(): string | undefined;
        private _captionLanguageMappings;
        get captionLanguageMappings(): CaptionLanguageMappingsPropertyList;
        putCaptionLanguageMappings(value: CaptionLanguageMappingsProperty[] | cdktn.IResolvable): void;
        resetCaptionLanguageMappings(): void;
        get captionLanguageMappingsInput(): cdktn.IResolvable | CaptionLanguageMappingsProperty[] | undefined;
        private _destination;
        get destination(): EncoderSettingsOutputGroupsOutputGroupSettingsHlsGroupSettingsDestinationPropertyOutputReference;
        putDestination(value: EncoderSettingsOutputGroupsOutputGroupSettingsHlsGroupSettingsDestinationProperty): void;
        get destinationInput(): EncoderSettingsOutputGroupsOutputGroupSettingsHlsGroupSettingsDestinationProperty | undefined;
        private _hlsCdnSettings;
        get hlsCdnSettings(): HlsCdnSettingsPropertyList;
        putHlsCdnSettings(value: HlsCdnSettingsProperty[] | cdktn.IResolvable): void;
        resetHlsCdnSettings(): void;
        get hlsCdnSettingsInput(): cdktn.IResolvable | HlsCdnSettingsProperty[] | undefined;
        private _keyProviderSettings;
        get keyProviderSettings(): KeyProviderSettingsPropertyOutputReference;
        putKeyProviderSettings(value: KeyProviderSettingsProperty): void;
        resetKeyProviderSettings(): void;
        get keyProviderSettingsInput(): KeyProviderSettingsProperty | undefined;
    }
    interface EncoderSettingsOutputGroupsOutputGroupSettingsMediaPackageGroupSettingsDestinationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#destination_ref_id AwsChannel#destination_ref_id}
        */
        readonly destinationRefId: string;
    }
    class EncoderSettingsOutputGroupsOutputGroupSettingsMediaPackageGroupSettingsDestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncoderSettingsOutputGroupsOutputGroupSettingsMediaPackageGroupSettingsDestinationProperty | undefined;
        set internalValue(value: EncoderSettingsOutputGroupsOutputGroupSettingsMediaPackageGroupSettingsDestinationProperty | undefined);
        private _destinationRefId?;
        get destinationRefId(): string;
        set destinationRefId(value: string);
        get destinationRefIdInput(): string | undefined;
    }
    interface MediaPackageGroupSettingsProperty {
        /**
        * destination block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#destination AwsChannel#destination}
        */
        readonly destination: EncoderSettingsOutputGroupsOutputGroupSettingsMediaPackageGroupSettingsDestinationProperty;
    }
    class MediaPackageGroupSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MediaPackageGroupSettingsProperty | undefined;
        set internalValue(value: MediaPackageGroupSettingsProperty | undefined);
        private _destination;
        get destination(): EncoderSettingsOutputGroupsOutputGroupSettingsMediaPackageGroupSettingsDestinationPropertyOutputReference;
        putDestination(value: EncoderSettingsOutputGroupsOutputGroupSettingsMediaPackageGroupSettingsDestinationProperty): void;
        get destinationInput(): EncoderSettingsOutputGroupsOutputGroupSettingsMediaPackageGroupSettingsDestinationProperty | undefined;
    }
    interface EncoderSettingsOutputGroupsOutputGroupSettingsMsSmoothGroupSettingsDestinationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#destination_ref_id AwsChannel#destination_ref_id}
        */
        readonly destinationRefId: string;
    }
    class EncoderSettingsOutputGroupsOutputGroupSettingsMsSmoothGroupSettingsDestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncoderSettingsOutputGroupsOutputGroupSettingsMsSmoothGroupSettingsDestinationProperty | undefined;
        set internalValue(value: EncoderSettingsOutputGroupsOutputGroupSettingsMsSmoothGroupSettingsDestinationProperty | undefined);
        private _destinationRefId?;
        get destinationRefId(): string;
        set destinationRefId(value: string);
        get destinationRefIdInput(): string | undefined;
    }
    interface MsSmoothGroupSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#acquisition_point_id AwsChannel#acquisition_point_id}
        */
        readonly acquisitionPointId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#audio_only_timecode_control AwsChannel#audio_only_timecode_control}
        */
        readonly audioOnlyTimecodeControl?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#certificate_mode AwsChannel#certificate_mode}
        */
        readonly certificateMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#connection_retry_interval AwsChannel#connection_retry_interval}
        */
        readonly connectionRetryInterval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#event_id AwsChannel#event_id}
        */
        readonly eventId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#event_id_mode AwsChannel#event_id_mode}
        */
        readonly eventIdMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#event_stop_behavior AwsChannel#event_stop_behavior}
        */
        readonly eventStopBehavior?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#filecache_duration AwsChannel#filecache_duration}
        */
        readonly filecacheDuration?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#fragment_length AwsChannel#fragment_length}
        */
        readonly fragmentLength?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#input_loss_action AwsChannel#input_loss_action}
        */
        readonly inputLossAction?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#num_retries AwsChannel#num_retries}
        */
        readonly numRetries?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#restart_delay AwsChannel#restart_delay}
        */
        readonly restartDelay?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#segmentation_mode AwsChannel#segmentation_mode}
        */
        readonly segmentationMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#send_delay_ms AwsChannel#send_delay_ms}
        */
        readonly sendDelayMs?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#sparse_track_type AwsChannel#sparse_track_type}
        */
        readonly sparseTrackType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#stream_manifest_behavior AwsChannel#stream_manifest_behavior}
        */
        readonly streamManifestBehavior?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#timestamp_offset AwsChannel#timestamp_offset}
        */
        readonly timestampOffset?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#timestamp_offset_mode AwsChannel#timestamp_offset_mode}
        */
        readonly timestampOffsetMode?: string;
        /**
        * destination block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#destination AwsChannel#destination}
        */
        readonly destination: EncoderSettingsOutputGroupsOutputGroupSettingsMsSmoothGroupSettingsDestinationProperty;
    }
    class MsSmoothGroupSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MsSmoothGroupSettingsProperty | undefined;
        set internalValue(value: MsSmoothGroupSettingsProperty | undefined);
        private _acquisitionPointId?;
        get acquisitionPointId(): string;
        set acquisitionPointId(value: string);
        resetAcquisitionPointId(): void;
        get acquisitionPointIdInput(): string | undefined;
        private _audioOnlyTimecodeControl?;
        get audioOnlyTimecodeControl(): string;
        set audioOnlyTimecodeControl(value: string);
        resetAudioOnlyTimecodeControl(): void;
        get audioOnlyTimecodeControlInput(): string | undefined;
        private _certificateMode?;
        get certificateMode(): string;
        set certificateMode(value: string);
        resetCertificateMode(): void;
        get certificateModeInput(): string | undefined;
        private _connectionRetryInterval?;
        get connectionRetryInterval(): number;
        set connectionRetryInterval(value: number);
        resetConnectionRetryInterval(): void;
        get connectionRetryIntervalInput(): number | undefined;
        private _eventId?;
        get eventId(): string;
        set eventId(value: string);
        resetEventId(): void;
        get eventIdInput(): string | undefined;
        private _eventIdMode?;
        get eventIdMode(): string;
        set eventIdMode(value: string);
        resetEventIdMode(): void;
        get eventIdModeInput(): string | undefined;
        private _eventStopBehavior?;
        get eventStopBehavior(): string;
        set eventStopBehavior(value: string);
        resetEventStopBehavior(): void;
        get eventStopBehaviorInput(): string | undefined;
        private _filecacheDuration?;
        get filecacheDuration(): number;
        set filecacheDuration(value: number);
        resetFilecacheDuration(): void;
        get filecacheDurationInput(): number | undefined;
        private _fragmentLength?;
        get fragmentLength(): number;
        set fragmentLength(value: number);
        resetFragmentLength(): void;
        get fragmentLengthInput(): number | undefined;
        private _inputLossAction?;
        get inputLossAction(): string;
        set inputLossAction(value: string);
        resetInputLossAction(): void;
        get inputLossActionInput(): string | undefined;
        private _numRetries?;
        get numRetries(): number;
        set numRetries(value: number);
        resetNumRetries(): void;
        get numRetriesInput(): number | undefined;
        private _restartDelay?;
        get restartDelay(): number;
        set restartDelay(value: number);
        resetRestartDelay(): void;
        get restartDelayInput(): number | undefined;
        private _segmentationMode?;
        get segmentationMode(): string;
        set segmentationMode(value: string);
        resetSegmentationMode(): void;
        get segmentationModeInput(): string | undefined;
        private _sendDelayMs?;
        get sendDelayMs(): number;
        set sendDelayMs(value: number);
        resetSendDelayMs(): void;
        get sendDelayMsInput(): number | undefined;
        private _sparseTrackType?;
        get sparseTrackType(): string;
        set sparseTrackType(value: string);
        resetSparseTrackType(): void;
        get sparseTrackTypeInput(): string | undefined;
        private _streamManifestBehavior?;
        get streamManifestBehavior(): string;
        set streamManifestBehavior(value: string);
        resetStreamManifestBehavior(): void;
        get streamManifestBehaviorInput(): string | undefined;
        private _timestampOffset?;
        get timestampOffset(): string;
        set timestampOffset(value: string);
        resetTimestampOffset(): void;
        get timestampOffsetInput(): string | undefined;
        private _timestampOffsetMode?;
        get timestampOffsetMode(): string;
        set timestampOffsetMode(value: string);
        resetTimestampOffsetMode(): void;
        get timestampOffsetModeInput(): string | undefined;
        private _destination;
        get destination(): EncoderSettingsOutputGroupsOutputGroupSettingsMsSmoothGroupSettingsDestinationPropertyOutputReference;
        putDestination(value: EncoderSettingsOutputGroupsOutputGroupSettingsMsSmoothGroupSettingsDestinationProperty): void;
        get destinationInput(): EncoderSettingsOutputGroupsOutputGroupSettingsMsSmoothGroupSettingsDestinationProperty | undefined;
    }
    interface MultiplexGroupSettingsProperty {
    }
    class MultiplexGroupSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MultiplexGroupSettingsProperty | undefined;
        set internalValue(value: MultiplexGroupSettingsProperty | undefined);
    }
    interface RtmpGroupSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#ad_markers AwsChannel#ad_markers}
        */
        readonly adMarkers?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#authentication_scheme AwsChannel#authentication_scheme}
        */
        readonly authenticationScheme?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#cache_full_behavior AwsChannel#cache_full_behavior}
        */
        readonly cacheFullBehavior?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#cache_length AwsChannel#cache_length}
        */
        readonly cacheLength?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#caption_data AwsChannel#caption_data}
        */
        readonly captionData?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#input_loss_action AwsChannel#input_loss_action}
        */
        readonly inputLossAction?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#restart_delay AwsChannel#restart_delay}
        */
        readonly restartDelay?: number;
    }
    class RtmpGroupSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RtmpGroupSettingsProperty | undefined;
        set internalValue(value: RtmpGroupSettingsProperty | undefined);
        private _adMarkers?;
        get adMarkers(): string[];
        set adMarkers(value: string[]);
        resetAdMarkers(): void;
        get adMarkersInput(): string[] | undefined;
        private _authenticationScheme?;
        get authenticationScheme(): string;
        set authenticationScheme(value: string);
        resetAuthenticationScheme(): void;
        get authenticationSchemeInput(): string | undefined;
        private _cacheFullBehavior?;
        get cacheFullBehavior(): string;
        set cacheFullBehavior(value: string);
        resetCacheFullBehavior(): void;
        get cacheFullBehaviorInput(): string | undefined;
        private _cacheLength?;
        get cacheLength(): number;
        set cacheLength(value: number);
        resetCacheLength(): void;
        get cacheLengthInput(): number | undefined;
        private _captionData?;
        get captionData(): string;
        set captionData(value: string);
        resetCaptionData(): void;
        get captionDataInput(): string | undefined;
        private _inputLossAction?;
        get inputLossAction(): string;
        set inputLossAction(value: string);
        resetInputLossAction(): void;
        get inputLossActionInput(): string | undefined;
        private _restartDelay?;
        get restartDelay(): number;
        set restartDelay(value: number);
        resetRestartDelay(): void;
        get restartDelayInput(): number | undefined;
    }
    interface UdpGroupSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#input_loss_action AwsChannel#input_loss_action}
        */
        readonly inputLossAction?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#timed_metadata_id3_frame AwsChannel#timed_metadata_id3_frame}
        */
        readonly timedMetadataId3Frame?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#timed_metadata_id3_period AwsChannel#timed_metadata_id3_period}
        */
        readonly timedMetadataId3Period?: number;
    }
    class UdpGroupSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UdpGroupSettingsProperty | undefined;
        set internalValue(value: UdpGroupSettingsProperty | undefined);
        private _inputLossAction?;
        get inputLossAction(): string;
        set inputLossAction(value: string);
        resetInputLossAction(): void;
        get inputLossActionInput(): string | undefined;
        private _timedMetadataId3Frame?;
        get timedMetadataId3Frame(): string;
        set timedMetadataId3Frame(value: string);
        resetTimedMetadataId3Frame(): void;
        get timedMetadataId3FrameInput(): string | undefined;
        private _timedMetadataId3Period?;
        get timedMetadataId3Period(): number;
        set timedMetadataId3Period(value: number);
        resetTimedMetadataId3Period(): void;
        get timedMetadataId3PeriodInput(): number | undefined;
    }
    interface OutputGroupSettingsProperty {
        /**
        * archive_group_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#archive_group_settings AwsChannel#archive_group_settings}
        */
        readonly archiveGroupSettings?: ArchiveGroupSettingsProperty[] | cdktn.IResolvable;
        /**
        * frame_capture_group_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#frame_capture_group_settings AwsChannel#frame_capture_group_settings}
        */
        readonly frameCaptureGroupSettings?: FrameCaptureGroupSettingsProperty;
        /**
        * hls_group_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#hls_group_settings AwsChannel#hls_group_settings}
        */
        readonly hlsGroupSettings?: HlsGroupSettingsProperty;
        /**
        * media_package_group_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#media_package_group_settings AwsChannel#media_package_group_settings}
        */
        readonly mediaPackageGroupSettings?: MediaPackageGroupSettingsProperty;
        /**
        * ms_smooth_group_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#ms_smooth_group_settings AwsChannel#ms_smooth_group_settings}
        */
        readonly msSmoothGroupSettings?: MsSmoothGroupSettingsProperty;
        /**
        * multiplex_group_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#multiplex_group_settings AwsChannel#multiplex_group_settings}
        */
        readonly multiplexGroupSettings?: MultiplexGroupSettingsProperty;
        /**
        * rtmp_group_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#rtmp_group_settings AwsChannel#rtmp_group_settings}
        */
        readonly rtmpGroupSettings?: RtmpGroupSettingsProperty;
        /**
        * udp_group_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#udp_group_settings AwsChannel#udp_group_settings}
        */
        readonly udpGroupSettings?: UdpGroupSettingsProperty;
    }
    class OutputGroupSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OutputGroupSettingsProperty | undefined;
        set internalValue(value: OutputGroupSettingsProperty | undefined);
        private _archiveGroupSettings;
        get archiveGroupSettings(): ArchiveGroupSettingsPropertyList;
        putArchiveGroupSettings(value: ArchiveGroupSettingsProperty[] | cdktn.IResolvable): void;
        resetArchiveGroupSettings(): void;
        get archiveGroupSettingsInput(): cdktn.IResolvable | ArchiveGroupSettingsProperty[] | undefined;
        private _frameCaptureGroupSettings;
        get frameCaptureGroupSettings(): FrameCaptureGroupSettingsPropertyOutputReference;
        putFrameCaptureGroupSettings(value: FrameCaptureGroupSettingsProperty): void;
        resetFrameCaptureGroupSettings(): void;
        get frameCaptureGroupSettingsInput(): FrameCaptureGroupSettingsProperty | undefined;
        private _hlsGroupSettings;
        get hlsGroupSettings(): HlsGroupSettingsPropertyOutputReference;
        putHlsGroupSettings(value: HlsGroupSettingsProperty): void;
        resetHlsGroupSettings(): void;
        get hlsGroupSettingsInput(): HlsGroupSettingsProperty | undefined;
        private _mediaPackageGroupSettings;
        get mediaPackageGroupSettings(): MediaPackageGroupSettingsPropertyOutputReference;
        putMediaPackageGroupSettings(value: MediaPackageGroupSettingsProperty): void;
        resetMediaPackageGroupSettings(): void;
        get mediaPackageGroupSettingsInput(): MediaPackageGroupSettingsProperty | undefined;
        private _msSmoothGroupSettings;
        get msSmoothGroupSettings(): MsSmoothGroupSettingsPropertyOutputReference;
        putMsSmoothGroupSettings(value: MsSmoothGroupSettingsProperty): void;
        resetMsSmoothGroupSettings(): void;
        get msSmoothGroupSettingsInput(): MsSmoothGroupSettingsProperty | undefined;
        private _multiplexGroupSettings;
        get multiplexGroupSettings(): MultiplexGroupSettingsPropertyOutputReference;
        putMultiplexGroupSettings(value: MultiplexGroupSettingsProperty): void;
        resetMultiplexGroupSettings(): void;
        get multiplexGroupSettingsInput(): MultiplexGroupSettingsProperty | undefined;
        private _rtmpGroupSettings;
        get rtmpGroupSettings(): RtmpGroupSettingsPropertyOutputReference;
        putRtmpGroupSettings(value: RtmpGroupSettingsProperty): void;
        resetRtmpGroupSettings(): void;
        get rtmpGroupSettingsInput(): RtmpGroupSettingsProperty | undefined;
        private _udpGroupSettings;
        get udpGroupSettings(): UdpGroupSettingsPropertyOutputReference;
        putUdpGroupSettings(value: UdpGroupSettingsProperty): void;
        resetUdpGroupSettings(): void;
        get udpGroupSettingsInput(): UdpGroupSettingsProperty | undefined;
    }
    interface EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsDvbNitSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#network_id AwsChannel#network_id}
        */
        readonly networkId: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#network_name AwsChannel#network_name}
        */
        readonly networkName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#rep_interval AwsChannel#rep_interval}
        */
        readonly repInterval?: number;
    }
    class EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsDvbNitSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsDvbNitSettingsProperty | undefined;
        set internalValue(value: EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsDvbNitSettingsProperty | undefined);
        private _networkId?;
        get networkId(): number;
        set networkId(value: number);
        get networkIdInput(): number | undefined;
        private _networkName?;
        get networkName(): string;
        set networkName(value: string);
        get networkNameInput(): string | undefined;
        private _repInterval?;
        get repInterval(): number;
        set repInterval(value: number);
        resetRepInterval(): void;
        get repIntervalInput(): number | undefined;
    }
    interface EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsDvbSdtSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#output_sdt AwsChannel#output_sdt}
        */
        readonly outputSdt?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#rep_interval AwsChannel#rep_interval}
        */
        readonly repInterval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#service_name AwsChannel#service_name}
        */
        readonly serviceName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#service_provider_name AwsChannel#service_provider_name}
        */
        readonly serviceProviderName?: string;
    }
    class EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsDvbSdtSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsDvbSdtSettingsProperty | undefined;
        set internalValue(value: EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsDvbSdtSettingsProperty | undefined);
        private _outputSdt?;
        get outputSdt(): string;
        set outputSdt(value: string);
        resetOutputSdt(): void;
        get outputSdtInput(): string | undefined;
        private _repInterval?;
        get repInterval(): number;
        set repInterval(value: number);
        resetRepInterval(): void;
        get repIntervalInput(): number | undefined;
        private _serviceName?;
        get serviceName(): string;
        set serviceName(value: string);
        resetServiceName(): void;
        get serviceNameInput(): string | undefined;
        private _serviceProviderName?;
        get serviceProviderName(): string;
        set serviceProviderName(value: string);
        resetServiceProviderName(): void;
        get serviceProviderNameInput(): string | undefined;
    }
    interface EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsDvbTdtSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#rep_interval AwsChannel#rep_interval}
        */
        readonly repInterval?: number;
    }
    class EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsDvbTdtSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsDvbTdtSettingsProperty | undefined;
        set internalValue(value: EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsDvbTdtSettingsProperty | undefined);
        private _repInterval?;
        get repInterval(): number;
        set repInterval(value: number);
        resetRepInterval(): void;
        get repIntervalInput(): number | undefined;
    }
    interface EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#absent_input_audio_behavior AwsChannel#absent_input_audio_behavior}
        */
        readonly absentInputAudioBehavior?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#arib AwsChannel#arib}
        */
        readonly arib?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#arib_captions_pid AwsChannel#arib_captions_pid}
        */
        readonly aribCaptionsPid?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#arib_captions_pid_control AwsChannel#arib_captions_pid_control}
        */
        readonly aribCaptionsPidControl?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#audio_buffer_model AwsChannel#audio_buffer_model}
        */
        readonly audioBufferModel?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#audio_frames_per_pes AwsChannel#audio_frames_per_pes}
        */
        readonly audioFramesPerPes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#audio_pids AwsChannel#audio_pids}
        */
        readonly audioPids?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#audio_stream_type AwsChannel#audio_stream_type}
        */
        readonly audioStreamType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#bitrate AwsChannel#bitrate}
        */
        readonly bitrate?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#buffer_model AwsChannel#buffer_model}
        */
        readonly bufferModel?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#cc_descriptor AwsChannel#cc_descriptor}
        */
        readonly ccDescriptor?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#dvb_sub_pids AwsChannel#dvb_sub_pids}
        */
        readonly dvbSubPids?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#dvb_teletext_pid AwsChannel#dvb_teletext_pid}
        */
        readonly dvbTeletextPid?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#ebif AwsChannel#ebif}
        */
        readonly ebif?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#ebp_audio_interval AwsChannel#ebp_audio_interval}
        */
        readonly ebpAudioInterval?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#ebp_lookahead_ms AwsChannel#ebp_lookahead_ms}
        */
        readonly ebpLookaheadMs?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#ebp_placement AwsChannel#ebp_placement}
        */
        readonly ebpPlacement?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#ecm_pid AwsChannel#ecm_pid}
        */
        readonly ecmPid?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#es_rate_in_pes AwsChannel#es_rate_in_pes}
        */
        readonly esRateInPes?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#etv_platform_pid AwsChannel#etv_platform_pid}
        */
        readonly etvPlatformPid?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#etv_signal_pid AwsChannel#etv_signal_pid}
        */
        readonly etvSignalPid?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#fragment_time AwsChannel#fragment_time}
        */
        readonly fragmentTime?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#klv AwsChannel#klv}
        */
        readonly klv?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#klv_data_pids AwsChannel#klv_data_pids}
        */
        readonly klvDataPids?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#nielsen_id3_behavior AwsChannel#nielsen_id3_behavior}
        */
        readonly nielsenId3Behavior?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#null_packet_bitrate AwsChannel#null_packet_bitrate}
        */
        readonly nullPacketBitrate?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#pat_interval AwsChannel#pat_interval}
        */
        readonly patInterval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#pcr_control AwsChannel#pcr_control}
        */
        readonly pcrControl?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#pcr_period AwsChannel#pcr_period}
        */
        readonly pcrPeriod?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#pcr_pid AwsChannel#pcr_pid}
        */
        readonly pcrPid?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#pmt_interval AwsChannel#pmt_interval}
        */
        readonly pmtInterval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#pmt_pid AwsChannel#pmt_pid}
        */
        readonly pmtPid?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#program_num AwsChannel#program_num}
        */
        readonly programNum?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#rate_mode AwsChannel#rate_mode}
        */
        readonly rateMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#scte27_pids AwsChannel#scte27_pids}
        */
        readonly scte27Pids?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#scte35_control AwsChannel#scte35_control}
        */
        readonly scte35Control?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#scte35_pid AwsChannel#scte35_pid}
        */
        readonly scte35Pid?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#segmentation_markers AwsChannel#segmentation_markers}
        */
        readonly segmentationMarkers?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#segmentation_style AwsChannel#segmentation_style}
        */
        readonly segmentationStyle?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#segmentation_time AwsChannel#segmentation_time}
        */
        readonly segmentationTime?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#timed_metadata_behavior AwsChannel#timed_metadata_behavior}
        */
        readonly timedMetadataBehavior?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#timed_metadata_pid AwsChannel#timed_metadata_pid}
        */
        readonly timedMetadataPid?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#transport_stream_id AwsChannel#transport_stream_id}
        */
        readonly transportStreamId?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#video_pid AwsChannel#video_pid}
        */
        readonly videoPid?: string;
        /**
        * dvb_nit_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#dvb_nit_settings AwsChannel#dvb_nit_settings}
        */
        readonly dvbNitSettings?: EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsDvbNitSettingsProperty;
        /**
        * dvb_sdt_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#dvb_sdt_settings AwsChannel#dvb_sdt_settings}
        */
        readonly dvbSdtSettings?: EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsDvbSdtSettingsProperty;
        /**
        * dvb_tdt_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#dvb_tdt_settings AwsChannel#dvb_tdt_settings}
        */
        readonly dvbTdtSettings?: EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsDvbTdtSettingsProperty;
    }
    class EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsProperty | undefined;
        set internalValue(value: EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsProperty | undefined);
        private _absentInputAudioBehavior?;
        get absentInputAudioBehavior(): string;
        set absentInputAudioBehavior(value: string);
        resetAbsentInputAudioBehavior(): void;
        get absentInputAudioBehaviorInput(): string | undefined;
        private _arib?;
        get arib(): string;
        set arib(value: string);
        resetArib(): void;
        get aribInput(): string | undefined;
        private _aribCaptionsPid?;
        get aribCaptionsPid(): string;
        set aribCaptionsPid(value: string);
        resetAribCaptionsPid(): void;
        get aribCaptionsPidInput(): string | undefined;
        private _aribCaptionsPidControl?;
        get aribCaptionsPidControl(): string;
        set aribCaptionsPidControl(value: string);
        resetAribCaptionsPidControl(): void;
        get aribCaptionsPidControlInput(): string | undefined;
        private _audioBufferModel?;
        get audioBufferModel(): string;
        set audioBufferModel(value: string);
        resetAudioBufferModel(): void;
        get audioBufferModelInput(): string | undefined;
        private _audioFramesPerPes?;
        get audioFramesPerPes(): number;
        set audioFramesPerPes(value: number);
        resetAudioFramesPerPes(): void;
        get audioFramesPerPesInput(): number | undefined;
        private _audioPids?;
        get audioPids(): string;
        set audioPids(value: string);
        resetAudioPids(): void;
        get audioPidsInput(): string | undefined;
        private _audioStreamType?;
        get audioStreamType(): string;
        set audioStreamType(value: string);
        resetAudioStreamType(): void;
        get audioStreamTypeInput(): string | undefined;
        private _bitrate?;
        get bitrate(): number;
        set bitrate(value: number);
        resetBitrate(): void;
        get bitrateInput(): number | undefined;
        private _bufferModel?;
        get bufferModel(): string;
        set bufferModel(value: string);
        resetBufferModel(): void;
        get bufferModelInput(): string | undefined;
        private _ccDescriptor?;
        get ccDescriptor(): string;
        set ccDescriptor(value: string);
        resetCcDescriptor(): void;
        get ccDescriptorInput(): string | undefined;
        private _dvbSubPids?;
        get dvbSubPids(): string;
        set dvbSubPids(value: string);
        resetDvbSubPids(): void;
        get dvbSubPidsInput(): string | undefined;
        private _dvbTeletextPid?;
        get dvbTeletextPid(): string;
        set dvbTeletextPid(value: string);
        resetDvbTeletextPid(): void;
        get dvbTeletextPidInput(): string | undefined;
        private _ebif?;
        get ebif(): string;
        set ebif(value: string);
        resetEbif(): void;
        get ebifInput(): string | undefined;
        private _ebpAudioInterval?;
        get ebpAudioInterval(): string;
        set ebpAudioInterval(value: string);
        resetEbpAudioInterval(): void;
        get ebpAudioIntervalInput(): string | undefined;
        private _ebpLookaheadMs?;
        get ebpLookaheadMs(): number;
        set ebpLookaheadMs(value: number);
        resetEbpLookaheadMs(): void;
        get ebpLookaheadMsInput(): number | undefined;
        private _ebpPlacement?;
        get ebpPlacement(): string;
        set ebpPlacement(value: string);
        resetEbpPlacement(): void;
        get ebpPlacementInput(): string | undefined;
        private _ecmPid?;
        get ecmPid(): string;
        set ecmPid(value: string);
        resetEcmPid(): void;
        get ecmPidInput(): string | undefined;
        private _esRateInPes?;
        get esRateInPes(): string;
        set esRateInPes(value: string);
        resetEsRateInPes(): void;
        get esRateInPesInput(): string | undefined;
        private _etvPlatformPid?;
        get etvPlatformPid(): string;
        set etvPlatformPid(value: string);
        resetEtvPlatformPid(): void;
        get etvPlatformPidInput(): string | undefined;
        private _etvSignalPid?;
        get etvSignalPid(): string;
        set etvSignalPid(value: string);
        resetEtvSignalPid(): void;
        get etvSignalPidInput(): string | undefined;
        private _fragmentTime?;
        get fragmentTime(): number;
        set fragmentTime(value: number);
        resetFragmentTime(): void;
        get fragmentTimeInput(): number | undefined;
        private _klv?;
        get klv(): string;
        set klv(value: string);
        resetKlv(): void;
        get klvInput(): string | undefined;
        private _klvDataPids?;
        get klvDataPids(): string;
        set klvDataPids(value: string);
        resetKlvDataPids(): void;
        get klvDataPidsInput(): string | undefined;
        private _nielsenId3Behavior?;
        get nielsenId3Behavior(): string;
        set nielsenId3Behavior(value: string);
        resetNielsenId3Behavior(): void;
        get nielsenId3BehaviorInput(): string | undefined;
        private _nullPacketBitrate?;
        get nullPacketBitrate(): number;
        set nullPacketBitrate(value: number);
        resetNullPacketBitrate(): void;
        get nullPacketBitrateInput(): number | undefined;
        private _patInterval?;
        get patInterval(): number;
        set patInterval(value: number);
        resetPatInterval(): void;
        get patIntervalInput(): number | undefined;
        private _pcrControl?;
        get pcrControl(): string;
        set pcrControl(value: string);
        resetPcrControl(): void;
        get pcrControlInput(): string | undefined;
        private _pcrPeriod?;
        get pcrPeriod(): number;
        set pcrPeriod(value: number);
        resetPcrPeriod(): void;
        get pcrPeriodInput(): number | undefined;
        private _pcrPid?;
        get pcrPid(): string;
        set pcrPid(value: string);
        resetPcrPid(): void;
        get pcrPidInput(): string | undefined;
        private _pmtInterval?;
        get pmtInterval(): number;
        set pmtInterval(value: number);
        resetPmtInterval(): void;
        get pmtIntervalInput(): number | undefined;
        private _pmtPid?;
        get pmtPid(): string;
        set pmtPid(value: string);
        resetPmtPid(): void;
        get pmtPidInput(): string | undefined;
        private _programNum?;
        get programNum(): number;
        set programNum(value: number);
        resetProgramNum(): void;
        get programNumInput(): number | undefined;
        private _rateMode?;
        get rateMode(): string;
        set rateMode(value: string);
        resetRateMode(): void;
        get rateModeInput(): string | undefined;
        private _scte27Pids?;
        get scte27Pids(): string;
        set scte27Pids(value: string);
        resetScte27Pids(): void;
        get scte27PidsInput(): string | undefined;
        private _scte35Control?;
        get scte35Control(): string;
        set scte35Control(value: string);
        resetScte35Control(): void;
        get scte35ControlInput(): string | undefined;
        private _scte35Pid?;
        get scte35Pid(): string;
        set scte35Pid(value: string);
        resetScte35Pid(): void;
        get scte35PidInput(): string | undefined;
        private _segmentationMarkers?;
        get segmentationMarkers(): string;
        set segmentationMarkers(value: string);
        resetSegmentationMarkers(): void;
        get segmentationMarkersInput(): string | undefined;
        private _segmentationStyle?;
        get segmentationStyle(): string;
        set segmentationStyle(value: string);
        resetSegmentationStyle(): void;
        get segmentationStyleInput(): string | undefined;
        private _segmentationTime?;
        get segmentationTime(): number;
        set segmentationTime(value: number);
        resetSegmentationTime(): void;
        get segmentationTimeInput(): number | undefined;
        private _timedMetadataBehavior?;
        get timedMetadataBehavior(): string;
        set timedMetadataBehavior(value: string);
        resetTimedMetadataBehavior(): void;
        get timedMetadataBehaviorInput(): string | undefined;
        private _timedMetadataPid?;
        get timedMetadataPid(): string;
        set timedMetadataPid(value: string);
        resetTimedMetadataPid(): void;
        get timedMetadataPidInput(): string | undefined;
        private _transportStreamId?;
        get transportStreamId(): number;
        set transportStreamId(value: number);
        resetTransportStreamId(): void;
        get transportStreamIdInput(): number | undefined;
        private _videoPid?;
        get videoPid(): string;
        set videoPid(value: string);
        resetVideoPid(): void;
        get videoPidInput(): string | undefined;
        private _dvbNitSettings;
        get dvbNitSettings(): EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsDvbNitSettingsPropertyOutputReference;
        putDvbNitSettings(value: EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsDvbNitSettingsProperty): void;
        resetDvbNitSettings(): void;
        get dvbNitSettingsInput(): EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsDvbNitSettingsProperty | undefined;
        private _dvbSdtSettings;
        get dvbSdtSettings(): EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsDvbSdtSettingsPropertyOutputReference;
        putDvbSdtSettings(value: EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsDvbSdtSettingsProperty): void;
        resetDvbSdtSettings(): void;
        get dvbSdtSettingsInput(): EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsDvbSdtSettingsProperty | undefined;
        private _dvbTdtSettings;
        get dvbTdtSettings(): EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsDvbTdtSettingsPropertyOutputReference;
        putDvbTdtSettings(value: EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsDvbTdtSettingsProperty): void;
        resetDvbTdtSettings(): void;
        get dvbTdtSettingsInput(): EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsDvbTdtSettingsProperty | undefined;
    }
    interface RawSettingsProperty {
    }
    class RawSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RawSettingsProperty | undefined;
        set internalValue(value: RawSettingsProperty | undefined);
    }
    interface EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsProperty {
        /**
        * m2ts_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#m2ts_settings AwsChannel#m2ts_settings}
        */
        readonly m2TsSettings?: EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsProperty;
        /**
        * raw_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#raw_settings AwsChannel#raw_settings}
        */
        readonly rawSettings?: RawSettingsProperty;
    }
    class EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsProperty | undefined;
        set internalValue(value: EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsProperty | undefined);
        private _m2TsSettings;
        get m2TsSettings(): EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsPropertyOutputReference;
        putM2TsSettings(value: EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsProperty): void;
        resetM2TsSettings(): void;
        get m2TsSettingsInput(): EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsM2tsSettingsProperty | undefined;
        private _rawSettings;
        get rawSettings(): RawSettingsPropertyOutputReference;
        putRawSettings(value: RawSettingsProperty): void;
        resetRawSettings(): void;
        get rawSettingsInput(): RawSettingsProperty | undefined;
    }
    interface ArchiveOutputSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#extension AwsChannel#extension}
        */
        readonly extension?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#name_modifier AwsChannel#name_modifier}
        */
        readonly nameModifier?: string;
        /**
        * container_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#container_settings AwsChannel#container_settings}
        */
        readonly containerSettings?: EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsProperty;
    }
    class ArchiveOutputSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ArchiveOutputSettingsProperty | undefined;
        set internalValue(value: ArchiveOutputSettingsProperty | undefined);
        private _extension?;
        get extension(): string;
        set extension(value: string);
        resetExtension(): void;
        get extensionInput(): string | undefined;
        private _nameModifier?;
        get nameModifier(): string;
        set nameModifier(value: string);
        resetNameModifier(): void;
        get nameModifierInput(): string | undefined;
        private _containerSettings;
        get containerSettings(): EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsPropertyOutputReference;
        putContainerSettings(value: EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsProperty): void;
        resetContainerSettings(): void;
        get containerSettingsInput(): EncoderSettingsOutputGroupsOutputsOutputSettingsArchiveOutputSettingsContainerSettingsProperty | undefined;
    }
    interface FrameCaptureOutputSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#name_modifier AwsChannel#name_modifier}
        */
        readonly nameModifier?: string;
    }
    class FrameCaptureOutputSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FrameCaptureOutputSettingsProperty | undefined;
        set internalValue(value: FrameCaptureOutputSettingsProperty | undefined);
        private _nameModifier?;
        get nameModifier(): string;
        set nameModifier(value: string);
        resetNameModifier(): void;
        get nameModifierInput(): string | undefined;
    }
    interface AudioOnlyImageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#password_param AwsChannel#password_param}
        */
        readonly passwordParam?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#uri AwsChannel#uri}
        */
        readonly uri: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#username AwsChannel#username}
        */
        readonly username?: string;
    }
    class AudioOnlyImagePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AudioOnlyImageProperty | undefined;
        set internalValue(value: AudioOnlyImageProperty | undefined);
        private _passwordParam?;
        get passwordParam(): string;
        set passwordParam(value: string);
        resetPasswordParam(): void;
        get passwordParamInput(): string | undefined;
        private _uri?;
        get uri(): string;
        set uri(value: string);
        get uriInput(): string | undefined;
        private _username?;
        get username(): string;
        set username(value: string);
        resetUsername(): void;
        get usernameInput(): string | undefined;
    }
    interface AudioOnlyHlsSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#audio_group_id AwsChannel#audio_group_id}
        */
        readonly audioGroupId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#audio_track_type AwsChannel#audio_track_type}
        */
        readonly audioTrackType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#segment_type AwsChannel#segment_type}
        */
        readonly segmentType?: string;
        /**
        * audio_only_image block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#audio_only_image AwsChannel#audio_only_image}
        */
        readonly audioOnlyImage?: AudioOnlyImageProperty;
    }
    class AudioOnlyHlsSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AudioOnlyHlsSettingsProperty | undefined;
        set internalValue(value: AudioOnlyHlsSettingsProperty | undefined);
        private _audioGroupId?;
        get audioGroupId(): string;
        set audioGroupId(value: string);
        resetAudioGroupId(): void;
        get audioGroupIdInput(): string | undefined;
        private _audioTrackType?;
        get audioTrackType(): string;
        set audioTrackType(value: string);
        resetAudioTrackType(): void;
        get audioTrackTypeInput(): string | undefined;
        private _segmentType?;
        get segmentType(): string;
        set segmentType(value: string);
        resetSegmentType(): void;
        get segmentTypeInput(): string | undefined;
        private _audioOnlyImage;
        get audioOnlyImage(): AudioOnlyImagePropertyOutputReference;
        putAudioOnlyImage(value: AudioOnlyImageProperty): void;
        resetAudioOnlyImage(): void;
        get audioOnlyImageInput(): AudioOnlyImageProperty | undefined;
    }
    interface Fmp4HlsSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#audio_rendition_sets AwsChannel#audio_rendition_sets}
        */
        readonly audioRenditionSets?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#nielsen_id3_behavior AwsChannel#nielsen_id3_behavior}
        */
        readonly nielsenId3Behavior?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#timed_metadata_behavior AwsChannel#timed_metadata_behavior}
        */
        readonly timedMetadataBehavior?: string;
    }
    class Fmp4HlsSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): Fmp4HlsSettingsProperty | undefined;
        set internalValue(value: Fmp4HlsSettingsProperty | undefined);
        private _audioRenditionSets?;
        get audioRenditionSets(): string;
        set audioRenditionSets(value: string);
        resetAudioRenditionSets(): void;
        get audioRenditionSetsInput(): string | undefined;
        private _nielsenId3Behavior?;
        get nielsenId3Behavior(): string;
        set nielsenId3Behavior(value: string);
        resetNielsenId3Behavior(): void;
        get nielsenId3BehaviorInput(): string | undefined;
        private _timedMetadataBehavior?;
        get timedMetadataBehavior(): string;
        set timedMetadataBehavior(value: string);
        resetTimedMetadataBehavior(): void;
        get timedMetadataBehaviorInput(): string | undefined;
    }
    interface FrameCaptureHlsSettingsProperty {
    }
    class FrameCaptureHlsSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FrameCaptureHlsSettingsProperty | undefined;
        set internalValue(value: FrameCaptureHlsSettingsProperty | undefined);
    }
    interface M3u8SettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#audio_frames_per_pes AwsChannel#audio_frames_per_pes}
        */
        readonly audioFramesPerPes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#audio_pids AwsChannel#audio_pids}
        */
        readonly audioPids?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#ecm_pid AwsChannel#ecm_pid}
        */
        readonly ecmPid?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#nielsen_id3_behavior AwsChannel#nielsen_id3_behavior}
        */
        readonly nielsenId3Behavior?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#pat_interval AwsChannel#pat_interval}
        */
        readonly patInterval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#pcr_control AwsChannel#pcr_control}
        */
        readonly pcrControl?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#pcr_period AwsChannel#pcr_period}
        */
        readonly pcrPeriod?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#pcr_pid AwsChannel#pcr_pid}
        */
        readonly pcrPid?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#pmt_interval AwsChannel#pmt_interval}
        */
        readonly pmtInterval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#pmt_pid AwsChannel#pmt_pid}
        */
        readonly pmtPid?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#program_num AwsChannel#program_num}
        */
        readonly programNum?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#scte35_behavior AwsChannel#scte35_behavior}
        */
        readonly scte35Behavior?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#scte35_pid AwsChannel#scte35_pid}
        */
        readonly scte35Pid?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#timed_metadata_behavior AwsChannel#timed_metadata_behavior}
        */
        readonly timedMetadataBehavior?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#timed_metadata_pid AwsChannel#timed_metadata_pid}
        */
        readonly timedMetadataPid?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#transport_stream_id AwsChannel#transport_stream_id}
        */
        readonly transportStreamId?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#video_pid AwsChannel#video_pid}
        */
        readonly videoPid?: string;
    }
    class M3u8SettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): M3u8SettingsProperty | undefined;
        set internalValue(value: M3u8SettingsProperty | undefined);
        private _audioFramesPerPes?;
        get audioFramesPerPes(): number;
        set audioFramesPerPes(value: number);
        resetAudioFramesPerPes(): void;
        get audioFramesPerPesInput(): number | undefined;
        private _audioPids?;
        get audioPids(): string;
        set audioPids(value: string);
        resetAudioPids(): void;
        get audioPidsInput(): string | undefined;
        private _ecmPid?;
        get ecmPid(): string;
        set ecmPid(value: string);
        resetEcmPid(): void;
        get ecmPidInput(): string | undefined;
        private _nielsenId3Behavior?;
        get nielsenId3Behavior(): string;
        set nielsenId3Behavior(value: string);
        resetNielsenId3Behavior(): void;
        get nielsenId3BehaviorInput(): string | undefined;
        private _patInterval?;
        get patInterval(): number;
        set patInterval(value: number);
        resetPatInterval(): void;
        get patIntervalInput(): number | undefined;
        private _pcrControl?;
        get pcrControl(): string;
        set pcrControl(value: string);
        resetPcrControl(): void;
        get pcrControlInput(): string | undefined;
        private _pcrPeriod?;
        get pcrPeriod(): number;
        set pcrPeriod(value: number);
        resetPcrPeriod(): void;
        get pcrPeriodInput(): number | undefined;
        private _pcrPid?;
        get pcrPid(): string;
        set pcrPid(value: string);
        resetPcrPid(): void;
        get pcrPidInput(): string | undefined;
        private _pmtInterval?;
        get pmtInterval(): number;
        set pmtInterval(value: number);
        resetPmtInterval(): void;
        get pmtIntervalInput(): number | undefined;
        private _pmtPid?;
        get pmtPid(): string;
        set pmtPid(value: string);
        resetPmtPid(): void;
        get pmtPidInput(): string | undefined;
        private _programNum?;
        get programNum(): number;
        set programNum(value: number);
        resetProgramNum(): void;
        get programNumInput(): number | undefined;
        private _scte35Behavior?;
        get scte35Behavior(): string;
        set scte35Behavior(value: string);
        resetScte35Behavior(): void;
        get scte35BehaviorInput(): string | undefined;
        private _scte35Pid?;
        get scte35Pid(): string;
        set scte35Pid(value: string);
        resetScte35Pid(): void;
        get scte35PidInput(): string | undefined;
        private _timedMetadataBehavior?;
        get timedMetadataBehavior(): string;
        set timedMetadataBehavior(value: string);
        resetTimedMetadataBehavior(): void;
        get timedMetadataBehaviorInput(): string | undefined;
        private _timedMetadataPid?;
        get timedMetadataPid(): string;
        set timedMetadataPid(value: string);
        resetTimedMetadataPid(): void;
        get timedMetadataPidInput(): string | undefined;
        private _transportStreamId?;
        get transportStreamId(): number;
        set transportStreamId(value: number);
        resetTransportStreamId(): void;
        get transportStreamIdInput(): number | undefined;
        private _videoPid?;
        get videoPid(): string;
        set videoPid(value: string);
        resetVideoPid(): void;
        get videoPidInput(): string | undefined;
    }
    interface StandardHlsSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#audio_rendition_sets AwsChannel#audio_rendition_sets}
        */
        readonly audioRenditionSets?: string;
        /**
        * m3u8_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#m3u8_settings AwsChannel#m3u8_settings}
        */
        readonly m3U8Settings: M3u8SettingsProperty;
    }
    class StandardHlsSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StandardHlsSettingsProperty | undefined;
        set internalValue(value: StandardHlsSettingsProperty | undefined);
        private _audioRenditionSets?;
        get audioRenditionSets(): string;
        set audioRenditionSets(value: string);
        resetAudioRenditionSets(): void;
        get audioRenditionSetsInput(): string | undefined;
        private _m3U8Settings;
        get m3U8Settings(): M3u8SettingsPropertyOutputReference;
        putM3U8Settings(value: M3u8SettingsProperty): void;
        get m3U8SettingsInput(): M3u8SettingsProperty | undefined;
    }
    interface HlsSettingsProperty {
        /**
        * audio_only_hls_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#audio_only_hls_settings AwsChannel#audio_only_hls_settings}
        */
        readonly audioOnlyHlsSettings?: AudioOnlyHlsSettingsProperty;
        /**
        * fmp4_hls_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#fmp4_hls_settings AwsChannel#fmp4_hls_settings}
        */
        readonly fmp4HlsSettings?: Fmp4HlsSettingsProperty;
        /**
        * frame_capture_hls_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#frame_capture_hls_settings AwsChannel#frame_capture_hls_settings}
        */
        readonly frameCaptureHlsSettings?: FrameCaptureHlsSettingsProperty;
        /**
        * standard_hls_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#standard_hls_settings AwsChannel#standard_hls_settings}
        */
        readonly standardHlsSettings?: StandardHlsSettingsProperty;
    }
    class HlsSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HlsSettingsProperty | undefined;
        set internalValue(value: HlsSettingsProperty | undefined);
        private _audioOnlyHlsSettings;
        get audioOnlyHlsSettings(): AudioOnlyHlsSettingsPropertyOutputReference;
        putAudioOnlyHlsSettings(value: AudioOnlyHlsSettingsProperty): void;
        resetAudioOnlyHlsSettings(): void;
        get audioOnlyHlsSettingsInput(): AudioOnlyHlsSettingsProperty | undefined;
        private _fmp4HlsSettings;
        get fmp4HlsSettings(): Fmp4HlsSettingsPropertyOutputReference;
        putFmp4HlsSettings(value: Fmp4HlsSettingsProperty): void;
        resetFmp4HlsSettings(): void;
        get fmp4HlsSettingsInput(): Fmp4HlsSettingsProperty | undefined;
        private _frameCaptureHlsSettings;
        get frameCaptureHlsSettings(): FrameCaptureHlsSettingsPropertyOutputReference;
        putFrameCaptureHlsSettings(value: FrameCaptureHlsSettingsProperty): void;
        resetFrameCaptureHlsSettings(): void;
        get frameCaptureHlsSettingsInput(): FrameCaptureHlsSettingsProperty | undefined;
        private _standardHlsSettings;
        get standardHlsSettings(): StandardHlsSettingsPropertyOutputReference;
        putStandardHlsSettings(value: StandardHlsSettingsProperty): void;
        resetStandardHlsSettings(): void;
        get standardHlsSettingsInput(): StandardHlsSettingsProperty | undefined;
    }
    interface HlsOutputSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#h265_packaging_type AwsChannel#h265_packaging_type}
        */
        readonly h265PackagingType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#name_modifier AwsChannel#name_modifier}
        */
        readonly nameModifier?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#segment_modifier AwsChannel#segment_modifier}
        */
        readonly segmentModifier?: string;
        /**
        * hls_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#hls_settings AwsChannel#hls_settings}
        */
        readonly hlsSettings: HlsSettingsProperty;
    }
    class HlsOutputSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HlsOutputSettingsProperty | undefined;
        set internalValue(value: HlsOutputSettingsProperty | undefined);
        private _h265PackagingType?;
        get h265PackagingType(): string;
        set h265PackagingType(value: string);
        resetH265PackagingType(): void;
        get h265PackagingTypeInput(): string | undefined;
        private _nameModifier?;
        get nameModifier(): string;
        set nameModifier(value: string);
        resetNameModifier(): void;
        get nameModifierInput(): string | undefined;
        private _segmentModifier?;
        get segmentModifier(): string;
        set segmentModifier(value: string);
        resetSegmentModifier(): void;
        get segmentModifierInput(): string | undefined;
        private _hlsSettings;
        get hlsSettings(): HlsSettingsPropertyOutputReference;
        putHlsSettings(value: HlsSettingsProperty): void;
        get hlsSettingsInput(): HlsSettingsProperty | undefined;
    }
    interface MediaPackageOutputSettingsProperty {
    }
    class MediaPackageOutputSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MediaPackageOutputSettingsProperty | undefined;
        set internalValue(value: MediaPackageOutputSettingsProperty | undefined);
    }
    interface MsSmoothOutputSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#h265_packaging_type AwsChannel#h265_packaging_type}
        */
        readonly h265PackagingType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#name_modifier AwsChannel#name_modifier}
        */
        readonly nameModifier?: string;
    }
    class MsSmoothOutputSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MsSmoothOutputSettingsProperty | undefined;
        set internalValue(value: MsSmoothOutputSettingsProperty | undefined);
        private _h265PackagingType?;
        get h265PackagingType(): string;
        set h265PackagingType(value: string);
        resetH265PackagingType(): void;
        get h265PackagingTypeInput(): string | undefined;
        private _nameModifier?;
        get nameModifier(): string;
        set nameModifier(value: string);
        resetNameModifier(): void;
        get nameModifierInput(): string | undefined;
    }
    interface EncoderSettingsOutputGroupsOutputsOutputSettingsMultiplexOutputSettingsDestinationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#destination_ref_id AwsChannel#destination_ref_id}
        */
        readonly destinationRefId: string;
    }
    class EncoderSettingsOutputGroupsOutputsOutputSettingsMultiplexOutputSettingsDestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncoderSettingsOutputGroupsOutputsOutputSettingsMultiplexOutputSettingsDestinationProperty | undefined;
        set internalValue(value: EncoderSettingsOutputGroupsOutputsOutputSettingsMultiplexOutputSettingsDestinationProperty | undefined);
        private _destinationRefId?;
        get destinationRefId(): string;
        set destinationRefId(value: string);
        get destinationRefIdInput(): string | undefined;
    }
    interface MultiplexOutputSettingsProperty {
        /**
        * destination block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#destination AwsChannel#destination}
        */
        readonly destination: EncoderSettingsOutputGroupsOutputsOutputSettingsMultiplexOutputSettingsDestinationProperty;
    }
    class MultiplexOutputSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MultiplexOutputSettingsProperty | undefined;
        set internalValue(value: MultiplexOutputSettingsProperty | undefined);
        private _destination;
        get destination(): EncoderSettingsOutputGroupsOutputsOutputSettingsMultiplexOutputSettingsDestinationPropertyOutputReference;
        putDestination(value: EncoderSettingsOutputGroupsOutputsOutputSettingsMultiplexOutputSettingsDestinationProperty): void;
        get destinationInput(): EncoderSettingsOutputGroupsOutputsOutputSettingsMultiplexOutputSettingsDestinationProperty | undefined;
    }
    interface EncoderSettingsOutputGroupsOutputsOutputSettingsRtmpOutputSettingsDestinationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#destination_ref_id AwsChannel#destination_ref_id}
        */
        readonly destinationRefId: string;
    }
    class EncoderSettingsOutputGroupsOutputsOutputSettingsRtmpOutputSettingsDestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncoderSettingsOutputGroupsOutputsOutputSettingsRtmpOutputSettingsDestinationProperty | undefined;
        set internalValue(value: EncoderSettingsOutputGroupsOutputsOutputSettingsRtmpOutputSettingsDestinationProperty | undefined);
        private _destinationRefId?;
        get destinationRefId(): string;
        set destinationRefId(value: string);
        get destinationRefIdInput(): string | undefined;
    }
    interface RtmpOutputSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#certificate_mode AwsChannel#certificate_mode}
        */
        readonly certificateMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#connection_retry_interval AwsChannel#connection_retry_interval}
        */
        readonly connectionRetryInterval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#num_retries AwsChannel#num_retries}
        */
        readonly numRetries?: number;
        /**
        * destination block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#destination AwsChannel#destination}
        */
        readonly destination: EncoderSettingsOutputGroupsOutputsOutputSettingsRtmpOutputSettingsDestinationProperty;
    }
    class RtmpOutputSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RtmpOutputSettingsProperty | undefined;
        set internalValue(value: RtmpOutputSettingsProperty | undefined);
        private _certificateMode?;
        get certificateMode(): string;
        set certificateMode(value: string);
        resetCertificateMode(): void;
        get certificateModeInput(): string | undefined;
        private _connectionRetryInterval?;
        get connectionRetryInterval(): number;
        set connectionRetryInterval(value: number);
        resetConnectionRetryInterval(): void;
        get connectionRetryIntervalInput(): number | undefined;
        private _numRetries?;
        get numRetries(): number;
        set numRetries(value: number);
        resetNumRetries(): void;
        get numRetriesInput(): number | undefined;
        private _destination;
        get destination(): EncoderSettingsOutputGroupsOutputsOutputSettingsRtmpOutputSettingsDestinationPropertyOutputReference;
        putDestination(value: EncoderSettingsOutputGroupsOutputsOutputSettingsRtmpOutputSettingsDestinationProperty): void;
        get destinationInput(): EncoderSettingsOutputGroupsOutputsOutputSettingsRtmpOutputSettingsDestinationProperty | undefined;
    }
    interface EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsDvbNitSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#network_id AwsChannel#network_id}
        */
        readonly networkId: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#network_name AwsChannel#network_name}
        */
        readonly networkName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#rep_interval AwsChannel#rep_interval}
        */
        readonly repInterval?: number;
    }
    class EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsDvbNitSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsDvbNitSettingsProperty | undefined;
        set internalValue(value: EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsDvbNitSettingsProperty | undefined);
        private _networkId?;
        get networkId(): number;
        set networkId(value: number);
        get networkIdInput(): number | undefined;
        private _networkName?;
        get networkName(): string;
        set networkName(value: string);
        get networkNameInput(): string | undefined;
        private _repInterval?;
        get repInterval(): number;
        set repInterval(value: number);
        resetRepInterval(): void;
        get repIntervalInput(): number | undefined;
    }
    interface EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsDvbSdtSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#output_sdt AwsChannel#output_sdt}
        */
        readonly outputSdt?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#rep_interval AwsChannel#rep_interval}
        */
        readonly repInterval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#service_name AwsChannel#service_name}
        */
        readonly serviceName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#service_provider_name AwsChannel#service_provider_name}
        */
        readonly serviceProviderName?: string;
    }
    class EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsDvbSdtSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsDvbSdtSettingsProperty | undefined;
        set internalValue(value: EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsDvbSdtSettingsProperty | undefined);
        private _outputSdt?;
        get outputSdt(): string;
        set outputSdt(value: string);
        resetOutputSdt(): void;
        get outputSdtInput(): string | undefined;
        private _repInterval?;
        get repInterval(): number;
        set repInterval(value: number);
        resetRepInterval(): void;
        get repIntervalInput(): number | undefined;
        private _serviceName?;
        get serviceName(): string;
        set serviceName(value: string);
        resetServiceName(): void;
        get serviceNameInput(): string | undefined;
        private _serviceProviderName?;
        get serviceProviderName(): string;
        set serviceProviderName(value: string);
        resetServiceProviderName(): void;
        get serviceProviderNameInput(): string | undefined;
    }
    interface EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsDvbTdtSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#rep_interval AwsChannel#rep_interval}
        */
        readonly repInterval?: number;
    }
    class EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsDvbTdtSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsDvbTdtSettingsProperty | undefined;
        set internalValue(value: EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsDvbTdtSettingsProperty | undefined);
        private _repInterval?;
        get repInterval(): number;
        set repInterval(value: number);
        resetRepInterval(): void;
        get repIntervalInput(): number | undefined;
    }
    interface EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#absent_input_audio_behavior AwsChannel#absent_input_audio_behavior}
        */
        readonly absentInputAudioBehavior?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#arib AwsChannel#arib}
        */
        readonly arib?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#arib_captions_pid AwsChannel#arib_captions_pid}
        */
        readonly aribCaptionsPid?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#arib_captions_pid_control AwsChannel#arib_captions_pid_control}
        */
        readonly aribCaptionsPidControl?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#audio_buffer_model AwsChannel#audio_buffer_model}
        */
        readonly audioBufferModel?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#audio_frames_per_pes AwsChannel#audio_frames_per_pes}
        */
        readonly audioFramesPerPes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#audio_pids AwsChannel#audio_pids}
        */
        readonly audioPids?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#audio_stream_type AwsChannel#audio_stream_type}
        */
        readonly audioStreamType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#bitrate AwsChannel#bitrate}
        */
        readonly bitrate?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#buffer_model AwsChannel#buffer_model}
        */
        readonly bufferModel?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#cc_descriptor AwsChannel#cc_descriptor}
        */
        readonly ccDescriptor?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#dvb_sub_pids AwsChannel#dvb_sub_pids}
        */
        readonly dvbSubPids?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#dvb_teletext_pid AwsChannel#dvb_teletext_pid}
        */
        readonly dvbTeletextPid?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#ebif AwsChannel#ebif}
        */
        readonly ebif?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#ebp_audio_interval AwsChannel#ebp_audio_interval}
        */
        readonly ebpAudioInterval?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#ebp_lookahead_ms AwsChannel#ebp_lookahead_ms}
        */
        readonly ebpLookaheadMs?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#ebp_placement AwsChannel#ebp_placement}
        */
        readonly ebpPlacement?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#ecm_pid AwsChannel#ecm_pid}
        */
        readonly ecmPid?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#es_rate_in_pes AwsChannel#es_rate_in_pes}
        */
        readonly esRateInPes?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#etv_platform_pid AwsChannel#etv_platform_pid}
        */
        readonly etvPlatformPid?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#etv_signal_pid AwsChannel#etv_signal_pid}
        */
        readonly etvSignalPid?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#fragment_time AwsChannel#fragment_time}
        */
        readonly fragmentTime?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#klv AwsChannel#klv}
        */
        readonly klv?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#klv_data_pids AwsChannel#klv_data_pids}
        */
        readonly klvDataPids?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#nielsen_id3_behavior AwsChannel#nielsen_id3_behavior}
        */
        readonly nielsenId3Behavior?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#null_packet_bitrate AwsChannel#null_packet_bitrate}
        */
        readonly nullPacketBitrate?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#pat_interval AwsChannel#pat_interval}
        */
        readonly patInterval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#pcr_control AwsChannel#pcr_control}
        */
        readonly pcrControl?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#pcr_period AwsChannel#pcr_period}
        */
        readonly pcrPeriod?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#pcr_pid AwsChannel#pcr_pid}
        */
        readonly pcrPid?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#pmt_interval AwsChannel#pmt_interval}
        */
        readonly pmtInterval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#pmt_pid AwsChannel#pmt_pid}
        */
        readonly pmtPid?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#program_num AwsChannel#program_num}
        */
        readonly programNum?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#rate_mode AwsChannel#rate_mode}
        */
        readonly rateMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#scte27_pids AwsChannel#scte27_pids}
        */
        readonly scte27Pids?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#scte35_control AwsChannel#scte35_control}
        */
        readonly scte35Control?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#scte35_pid AwsChannel#scte35_pid}
        */
        readonly scte35Pid?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#segmentation_markers AwsChannel#segmentation_markers}
        */
        readonly segmentationMarkers?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#segmentation_style AwsChannel#segmentation_style}
        */
        readonly segmentationStyle?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#segmentation_time AwsChannel#segmentation_time}
        */
        readonly segmentationTime?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#timed_metadata_behavior AwsChannel#timed_metadata_behavior}
        */
        readonly timedMetadataBehavior?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#timed_metadata_pid AwsChannel#timed_metadata_pid}
        */
        readonly timedMetadataPid?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#transport_stream_id AwsChannel#transport_stream_id}
        */
        readonly transportStreamId?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#video_pid AwsChannel#video_pid}
        */
        readonly videoPid?: string;
        /**
        * dvb_nit_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#dvb_nit_settings AwsChannel#dvb_nit_settings}
        */
        readonly dvbNitSettings?: EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsDvbNitSettingsProperty;
        /**
        * dvb_sdt_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#dvb_sdt_settings AwsChannel#dvb_sdt_settings}
        */
        readonly dvbSdtSettings?: EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsDvbSdtSettingsProperty;
        /**
        * dvb_tdt_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#dvb_tdt_settings AwsChannel#dvb_tdt_settings}
        */
        readonly dvbTdtSettings?: EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsDvbTdtSettingsProperty;
    }
    class EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsProperty | undefined;
        set internalValue(value: EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsProperty | undefined);
        private _absentInputAudioBehavior?;
        get absentInputAudioBehavior(): string;
        set absentInputAudioBehavior(value: string);
        resetAbsentInputAudioBehavior(): void;
        get absentInputAudioBehaviorInput(): string | undefined;
        private _arib?;
        get arib(): string;
        set arib(value: string);
        resetArib(): void;
        get aribInput(): string | undefined;
        private _aribCaptionsPid?;
        get aribCaptionsPid(): string;
        set aribCaptionsPid(value: string);
        resetAribCaptionsPid(): void;
        get aribCaptionsPidInput(): string | undefined;
        private _aribCaptionsPidControl?;
        get aribCaptionsPidControl(): string;
        set aribCaptionsPidControl(value: string);
        resetAribCaptionsPidControl(): void;
        get aribCaptionsPidControlInput(): string | undefined;
        private _audioBufferModel?;
        get audioBufferModel(): string;
        set audioBufferModel(value: string);
        resetAudioBufferModel(): void;
        get audioBufferModelInput(): string | undefined;
        private _audioFramesPerPes?;
        get audioFramesPerPes(): number;
        set audioFramesPerPes(value: number);
        resetAudioFramesPerPes(): void;
        get audioFramesPerPesInput(): number | undefined;
        private _audioPids?;
        get audioPids(): string;
        set audioPids(value: string);
        resetAudioPids(): void;
        get audioPidsInput(): string | undefined;
        private _audioStreamType?;
        get audioStreamType(): string;
        set audioStreamType(value: string);
        resetAudioStreamType(): void;
        get audioStreamTypeInput(): string | undefined;
        private _bitrate?;
        get bitrate(): number;
        set bitrate(value: number);
        resetBitrate(): void;
        get bitrateInput(): number | undefined;
        private _bufferModel?;
        get bufferModel(): string;
        set bufferModel(value: string);
        resetBufferModel(): void;
        get bufferModelInput(): string | undefined;
        private _ccDescriptor?;
        get ccDescriptor(): string;
        set ccDescriptor(value: string);
        resetCcDescriptor(): void;
        get ccDescriptorInput(): string | undefined;
        private _dvbSubPids?;
        get dvbSubPids(): string;
        set dvbSubPids(value: string);
        resetDvbSubPids(): void;
        get dvbSubPidsInput(): string | undefined;
        private _dvbTeletextPid?;
        get dvbTeletextPid(): string;
        set dvbTeletextPid(value: string);
        resetDvbTeletextPid(): void;
        get dvbTeletextPidInput(): string | undefined;
        private _ebif?;
        get ebif(): string;
        set ebif(value: string);
        resetEbif(): void;
        get ebifInput(): string | undefined;
        private _ebpAudioInterval?;
        get ebpAudioInterval(): string;
        set ebpAudioInterval(value: string);
        resetEbpAudioInterval(): void;
        get ebpAudioIntervalInput(): string | undefined;
        private _ebpLookaheadMs?;
        get ebpLookaheadMs(): number;
        set ebpLookaheadMs(value: number);
        resetEbpLookaheadMs(): void;
        get ebpLookaheadMsInput(): number | undefined;
        private _ebpPlacement?;
        get ebpPlacement(): string;
        set ebpPlacement(value: string);
        resetEbpPlacement(): void;
        get ebpPlacementInput(): string | undefined;
        private _ecmPid?;
        get ecmPid(): string;
        set ecmPid(value: string);
        resetEcmPid(): void;
        get ecmPidInput(): string | undefined;
        private _esRateInPes?;
        get esRateInPes(): string;
        set esRateInPes(value: string);
        resetEsRateInPes(): void;
        get esRateInPesInput(): string | undefined;
        private _etvPlatformPid?;
        get etvPlatformPid(): string;
        set etvPlatformPid(value: string);
        resetEtvPlatformPid(): void;
        get etvPlatformPidInput(): string | undefined;
        private _etvSignalPid?;
        get etvSignalPid(): string;
        set etvSignalPid(value: string);
        resetEtvSignalPid(): void;
        get etvSignalPidInput(): string | undefined;
        private _fragmentTime?;
        get fragmentTime(): number;
        set fragmentTime(value: number);
        resetFragmentTime(): void;
        get fragmentTimeInput(): number | undefined;
        private _klv?;
        get klv(): string;
        set klv(value: string);
        resetKlv(): void;
        get klvInput(): string | undefined;
        private _klvDataPids?;
        get klvDataPids(): string;
        set klvDataPids(value: string);
        resetKlvDataPids(): void;
        get klvDataPidsInput(): string | undefined;
        private _nielsenId3Behavior?;
        get nielsenId3Behavior(): string;
        set nielsenId3Behavior(value: string);
        resetNielsenId3Behavior(): void;
        get nielsenId3BehaviorInput(): string | undefined;
        private _nullPacketBitrate?;
        get nullPacketBitrate(): number;
        set nullPacketBitrate(value: number);
        resetNullPacketBitrate(): void;
        get nullPacketBitrateInput(): number | undefined;
        private _patInterval?;
        get patInterval(): number;
        set patInterval(value: number);
        resetPatInterval(): void;
        get patIntervalInput(): number | undefined;
        private _pcrControl?;
        get pcrControl(): string;
        set pcrControl(value: string);
        resetPcrControl(): void;
        get pcrControlInput(): string | undefined;
        private _pcrPeriod?;
        get pcrPeriod(): number;
        set pcrPeriod(value: number);
        resetPcrPeriod(): void;
        get pcrPeriodInput(): number | undefined;
        private _pcrPid?;
        get pcrPid(): string;
        set pcrPid(value: string);
        resetPcrPid(): void;
        get pcrPidInput(): string | undefined;
        private _pmtInterval?;
        get pmtInterval(): number;
        set pmtInterval(value: number);
        resetPmtInterval(): void;
        get pmtIntervalInput(): number | undefined;
        private _pmtPid?;
        get pmtPid(): string;
        set pmtPid(value: string);
        resetPmtPid(): void;
        get pmtPidInput(): string | undefined;
        private _programNum?;
        get programNum(): number;
        set programNum(value: number);
        resetProgramNum(): void;
        get programNumInput(): number | undefined;
        private _rateMode?;
        get rateMode(): string;
        set rateMode(value: string);
        resetRateMode(): void;
        get rateModeInput(): string | undefined;
        private _scte27Pids?;
        get scte27Pids(): string;
        set scte27Pids(value: string);
        resetScte27Pids(): void;
        get scte27PidsInput(): string | undefined;
        private _scte35Control?;
        get scte35Control(): string;
        set scte35Control(value: string);
        resetScte35Control(): void;
        get scte35ControlInput(): string | undefined;
        private _scte35Pid?;
        get scte35Pid(): string;
        set scte35Pid(value: string);
        resetScte35Pid(): void;
        get scte35PidInput(): string | undefined;
        private _segmentationMarkers?;
        get segmentationMarkers(): string;
        set segmentationMarkers(value: string);
        resetSegmentationMarkers(): void;
        get segmentationMarkersInput(): string | undefined;
        private _segmentationStyle?;
        get segmentationStyle(): string;
        set segmentationStyle(value: string);
        resetSegmentationStyle(): void;
        get segmentationStyleInput(): string | undefined;
        private _segmentationTime?;
        get segmentationTime(): number;
        set segmentationTime(value: number);
        resetSegmentationTime(): void;
        get segmentationTimeInput(): number | undefined;
        private _timedMetadataBehavior?;
        get timedMetadataBehavior(): string;
        set timedMetadataBehavior(value: string);
        resetTimedMetadataBehavior(): void;
        get timedMetadataBehaviorInput(): string | undefined;
        private _timedMetadataPid?;
        get timedMetadataPid(): string;
        set timedMetadataPid(value: string);
        resetTimedMetadataPid(): void;
        get timedMetadataPidInput(): string | undefined;
        private _transportStreamId?;
        get transportStreamId(): number;
        set transportStreamId(value: number);
        resetTransportStreamId(): void;
        get transportStreamIdInput(): number | undefined;
        private _videoPid?;
        get videoPid(): string;
        set videoPid(value: string);
        resetVideoPid(): void;
        get videoPidInput(): string | undefined;
        private _dvbNitSettings;
        get dvbNitSettings(): EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsDvbNitSettingsPropertyOutputReference;
        putDvbNitSettings(value: EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsDvbNitSettingsProperty): void;
        resetDvbNitSettings(): void;
        get dvbNitSettingsInput(): EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsDvbNitSettingsProperty | undefined;
        private _dvbSdtSettings;
        get dvbSdtSettings(): EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsDvbSdtSettingsPropertyOutputReference;
        putDvbSdtSettings(value: EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsDvbSdtSettingsProperty): void;
        resetDvbSdtSettings(): void;
        get dvbSdtSettingsInput(): EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsDvbSdtSettingsProperty | undefined;
        private _dvbTdtSettings;
        get dvbTdtSettings(): EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsDvbTdtSettingsPropertyOutputReference;
        putDvbTdtSettings(value: EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsDvbTdtSettingsProperty): void;
        resetDvbTdtSettings(): void;
        get dvbTdtSettingsInput(): EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsDvbTdtSettingsProperty | undefined;
    }
    interface EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsProperty {
        /**
        * m2ts_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#m2ts_settings AwsChannel#m2ts_settings}
        */
        readonly m2TsSettings?: EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsProperty;
    }
    class EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsProperty | undefined;
        set internalValue(value: EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsProperty | undefined);
        private _m2TsSettings;
        get m2TsSettings(): EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsPropertyOutputReference;
        putM2TsSettings(value: EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsProperty): void;
        resetM2TsSettings(): void;
        get m2TsSettingsInput(): EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsM2tsSettingsProperty | undefined;
    }
    interface EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsDestinationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#destination_ref_id AwsChannel#destination_ref_id}
        */
        readonly destinationRefId: string;
    }
    class EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsDestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsDestinationProperty | undefined;
        set internalValue(value: EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsDestinationProperty | undefined);
        private _destinationRefId?;
        get destinationRefId(): string;
        set destinationRefId(value: string);
        get destinationRefIdInput(): string | undefined;
    }
    interface FecOutputSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#column_depth AwsChannel#column_depth}
        */
        readonly columnDepth?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#include_fec AwsChannel#include_fec}
        */
        readonly includeFec?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#row_length AwsChannel#row_length}
        */
        readonly rowLength?: number;
    }
    class FecOutputSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FecOutputSettingsProperty | undefined;
        set internalValue(value: FecOutputSettingsProperty | undefined);
        private _columnDepth?;
        get columnDepth(): number;
        set columnDepth(value: number);
        resetColumnDepth(): void;
        get columnDepthInput(): number | undefined;
        private _includeFec?;
        get includeFec(): string;
        set includeFec(value: string);
        resetIncludeFec(): void;
        get includeFecInput(): string | undefined;
        private _rowLength?;
        get rowLength(): number;
        set rowLength(value: number);
        resetRowLength(): void;
        get rowLengthInput(): number | undefined;
    }
    interface UdpOutputSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#buffer_msec AwsChannel#buffer_msec}
        */
        readonly bufferMsec?: number;
        /**
        * container_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#container_settings AwsChannel#container_settings}
        */
        readonly containerSettings: EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsProperty;
        /**
        * destination block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#destination AwsChannel#destination}
        */
        readonly destination: EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsDestinationProperty;
        /**
        * fec_output_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#fec_output_settings AwsChannel#fec_output_settings}
        */
        readonly fecOutputSettings?: FecOutputSettingsProperty;
    }
    class UdpOutputSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UdpOutputSettingsProperty | undefined;
        set internalValue(value: UdpOutputSettingsProperty | undefined);
        private _bufferMsec?;
        get bufferMsec(): number;
        set bufferMsec(value: number);
        resetBufferMsec(): void;
        get bufferMsecInput(): number | undefined;
        private _containerSettings;
        get containerSettings(): EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsPropertyOutputReference;
        putContainerSettings(value: EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsProperty): void;
        get containerSettingsInput(): EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsContainerSettingsProperty | undefined;
        private _destination;
        get destination(): EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsDestinationPropertyOutputReference;
        putDestination(value: EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsDestinationProperty): void;
        get destinationInput(): EncoderSettingsOutputGroupsOutputsOutputSettingsUdpOutputSettingsDestinationProperty | undefined;
        private _fecOutputSettings;
        get fecOutputSettings(): FecOutputSettingsPropertyOutputReference;
        putFecOutputSettings(value: FecOutputSettingsProperty): void;
        resetFecOutputSettings(): void;
        get fecOutputSettingsInput(): FecOutputSettingsProperty | undefined;
    }
    interface OutputSettingsProperty {
        /**
        * archive_output_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#archive_output_settings AwsChannel#archive_output_settings}
        */
        readonly archiveOutputSettings?: ArchiveOutputSettingsProperty;
        /**
        * frame_capture_output_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#frame_capture_output_settings AwsChannel#frame_capture_output_settings}
        */
        readonly frameCaptureOutputSettings?: FrameCaptureOutputSettingsProperty;
        /**
        * hls_output_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#hls_output_settings AwsChannel#hls_output_settings}
        */
        readonly hlsOutputSettings?: HlsOutputSettingsProperty;
        /**
        * media_package_output_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#media_package_output_settings AwsChannel#media_package_output_settings}
        */
        readonly mediaPackageOutputSettings?: MediaPackageOutputSettingsProperty;
        /**
        * ms_smooth_output_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#ms_smooth_output_settings AwsChannel#ms_smooth_output_settings}
        */
        readonly msSmoothOutputSettings?: MsSmoothOutputSettingsProperty;
        /**
        * multiplex_output_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#multiplex_output_settings AwsChannel#multiplex_output_settings}
        */
        readonly multiplexOutputSettings?: MultiplexOutputSettingsProperty;
        /**
        * rtmp_output_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#rtmp_output_settings AwsChannel#rtmp_output_settings}
        */
        readonly rtmpOutputSettings?: RtmpOutputSettingsProperty;
        /**
        * udp_output_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#udp_output_settings AwsChannel#udp_output_settings}
        */
        readonly udpOutputSettings?: UdpOutputSettingsProperty;
    }
    class OutputSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OutputSettingsProperty | undefined;
        set internalValue(value: OutputSettingsProperty | undefined);
        private _archiveOutputSettings;
        get archiveOutputSettings(): ArchiveOutputSettingsPropertyOutputReference;
        putArchiveOutputSettings(value: ArchiveOutputSettingsProperty): void;
        resetArchiveOutputSettings(): void;
        get archiveOutputSettingsInput(): ArchiveOutputSettingsProperty | undefined;
        private _frameCaptureOutputSettings;
        get frameCaptureOutputSettings(): FrameCaptureOutputSettingsPropertyOutputReference;
        putFrameCaptureOutputSettings(value: FrameCaptureOutputSettingsProperty): void;
        resetFrameCaptureOutputSettings(): void;
        get frameCaptureOutputSettingsInput(): FrameCaptureOutputSettingsProperty | undefined;
        private _hlsOutputSettings;
        get hlsOutputSettings(): HlsOutputSettingsPropertyOutputReference;
        putHlsOutputSettings(value: HlsOutputSettingsProperty): void;
        resetHlsOutputSettings(): void;
        get hlsOutputSettingsInput(): HlsOutputSettingsProperty | undefined;
        private _mediaPackageOutputSettings;
        get mediaPackageOutputSettings(): MediaPackageOutputSettingsPropertyOutputReference;
        putMediaPackageOutputSettings(value: MediaPackageOutputSettingsProperty): void;
        resetMediaPackageOutputSettings(): void;
        get mediaPackageOutputSettingsInput(): MediaPackageOutputSettingsProperty | undefined;
        private _msSmoothOutputSettings;
        get msSmoothOutputSettings(): MsSmoothOutputSettingsPropertyOutputReference;
        putMsSmoothOutputSettings(value: MsSmoothOutputSettingsProperty): void;
        resetMsSmoothOutputSettings(): void;
        get msSmoothOutputSettingsInput(): MsSmoothOutputSettingsProperty | undefined;
        private _multiplexOutputSettings;
        get multiplexOutputSettings(): MultiplexOutputSettingsPropertyOutputReference;
        putMultiplexOutputSettings(value: MultiplexOutputSettingsProperty): void;
        resetMultiplexOutputSettings(): void;
        get multiplexOutputSettingsInput(): MultiplexOutputSettingsProperty | undefined;
        private _rtmpOutputSettings;
        get rtmpOutputSettings(): RtmpOutputSettingsPropertyOutputReference;
        putRtmpOutputSettings(value: RtmpOutputSettingsProperty): void;
        resetRtmpOutputSettings(): void;
        get rtmpOutputSettingsInput(): RtmpOutputSettingsProperty | undefined;
        private _udpOutputSettings;
        get udpOutputSettings(): UdpOutputSettingsPropertyOutputReference;
        putUdpOutputSettings(value: UdpOutputSettingsProperty): void;
        resetUdpOutputSettings(): void;
        get udpOutputSettingsInput(): UdpOutputSettingsProperty | undefined;
    }
    interface OutputsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#audio_description_names AwsChannel#audio_description_names}
        */
        readonly audioDescriptionNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#caption_description_names AwsChannel#caption_description_names}
        */
        readonly captionDescriptionNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#output_name AwsChannel#output_name}
        */
        readonly outputName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#video_description_name AwsChannel#video_description_name}
        */
        readonly videoDescriptionName?: string;
        /**
        * output_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#output_settings AwsChannel#output_settings}
        */
        readonly outputSettings: OutputSettingsProperty;
    }
    class OutputsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OutputsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OutputsProperty | cdktn.IResolvable | undefined);
        private _audioDescriptionNames?;
        get audioDescriptionNames(): string[];
        set audioDescriptionNames(value: string[]);
        resetAudioDescriptionNames(): void;
        get audioDescriptionNamesInput(): string[] | undefined;
        private _captionDescriptionNames?;
        get captionDescriptionNames(): string[];
        set captionDescriptionNames(value: string[]);
        resetCaptionDescriptionNames(): void;
        get captionDescriptionNamesInput(): string[] | undefined;
        private _outputName?;
        get outputName(): string;
        set outputName(value: string);
        resetOutputName(): void;
        get outputNameInput(): string | undefined;
        private _videoDescriptionName?;
        get videoDescriptionName(): string;
        set videoDescriptionName(value: string);
        resetVideoDescriptionName(): void;
        get videoDescriptionNameInput(): string | undefined;
        private _outputSettings;
        get outputSettings(): OutputSettingsPropertyOutputReference;
        putOutputSettings(value: OutputSettingsProperty): void;
        get outputSettingsInput(): OutputSettingsProperty | undefined;
    }
    class OutputsPropertyList extends cdktn.ComplexList {
        internalValue?: OutputsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OutputsPropertyOutputReference;
    }
    interface OutputGroupsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#name AwsChannel#name}
        */
        readonly name?: string;
        /**
        * output_group_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#output_group_settings AwsChannel#output_group_settings}
        */
        readonly outputGroupSettings: OutputGroupSettingsProperty;
        /**
        * outputs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#outputs AwsChannel#outputs}
        */
        readonly outputs: OutputsProperty[] | cdktn.IResolvable;
    }
    class OutputGroupsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OutputGroupsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OutputGroupsProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _outputGroupSettings;
        get outputGroupSettings(): OutputGroupSettingsPropertyOutputReference;
        putOutputGroupSettings(value: OutputGroupSettingsProperty): void;
        get outputGroupSettingsInput(): OutputGroupSettingsProperty | undefined;
        private _outputs;
        get outputs(): OutputsPropertyList;
        putOutputs(value: OutputsProperty[] | cdktn.IResolvable): void;
        get outputsInput(): cdktn.IResolvable | OutputsProperty[] | undefined;
    }
    class OutputGroupsPropertyList extends cdktn.ComplexList {
        internalValue?: OutputGroupsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OutputGroupsPropertyOutputReference;
    }
    interface TimecodeConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#source AwsChannel#source}
        */
        readonly source: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#sync_threshold AwsChannel#sync_threshold}
        */
        readonly syncThreshold?: number;
    }
    class TimecodeConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimecodeConfigProperty | undefined;
        set internalValue(value: TimecodeConfigProperty | undefined);
        private _source?;
        get source(): string;
        set source(value: string);
        get sourceInput(): string | undefined;
        private _syncThreshold?;
        get syncThreshold(): number;
        set syncThreshold(value: number);
        resetSyncThreshold(): void;
        get syncThresholdInput(): number | undefined;
    }
    interface FrameCaptureSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#capture_interval AwsChannel#capture_interval}
        */
        readonly captureInterval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#capture_interval_units AwsChannel#capture_interval_units}
        */
        readonly captureIntervalUnits?: string;
    }
    class FrameCaptureSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FrameCaptureSettingsProperty | undefined;
        set internalValue(value: FrameCaptureSettingsProperty | undefined);
        private _captureInterval?;
        get captureInterval(): number;
        set captureInterval(value: number);
        resetCaptureInterval(): void;
        get captureIntervalInput(): number | undefined;
        private _captureIntervalUnits?;
        get captureIntervalUnits(): string;
        set captureIntervalUnits(value: string);
        resetCaptureIntervalUnits(): void;
        get captureIntervalUnitsInput(): string | undefined;
    }
    interface EncoderSettingsVideoDescriptionsCodecSettingsH264SettingsFilterSettingsTemporalFilterSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#post_filter_sharpening AwsChannel#post_filter_sharpening}
        */
        readonly postFilterSharpening?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#strength AwsChannel#strength}
        */
        readonly strength?: string;
    }
    class EncoderSettingsVideoDescriptionsCodecSettingsH264SettingsFilterSettingsTemporalFilterSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncoderSettingsVideoDescriptionsCodecSettingsH264SettingsFilterSettingsTemporalFilterSettingsProperty | undefined;
        set internalValue(value: EncoderSettingsVideoDescriptionsCodecSettingsH264SettingsFilterSettingsTemporalFilterSettingsProperty | undefined);
        private _postFilterSharpening?;
        get postFilterSharpening(): string;
        set postFilterSharpening(value: string);
        resetPostFilterSharpening(): void;
        get postFilterSharpeningInput(): string | undefined;
        private _strength?;
        get strength(): string;
        set strength(value: string);
        resetStrength(): void;
        get strengthInput(): string | undefined;
    }
    interface EncoderSettingsVideoDescriptionsCodecSettingsH264SettingsFilterSettingsProperty {
        /**
        * temporal_filter_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#temporal_filter_settings AwsChannel#temporal_filter_settings}
        */
        readonly temporalFilterSettings?: EncoderSettingsVideoDescriptionsCodecSettingsH264SettingsFilterSettingsTemporalFilterSettingsProperty;
    }
    class EncoderSettingsVideoDescriptionsCodecSettingsH264SettingsFilterSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncoderSettingsVideoDescriptionsCodecSettingsH264SettingsFilterSettingsProperty | undefined;
        set internalValue(value: EncoderSettingsVideoDescriptionsCodecSettingsH264SettingsFilterSettingsProperty | undefined);
        private _temporalFilterSettings;
        get temporalFilterSettings(): EncoderSettingsVideoDescriptionsCodecSettingsH264SettingsFilterSettingsTemporalFilterSettingsPropertyOutputReference;
        putTemporalFilterSettings(value: EncoderSettingsVideoDescriptionsCodecSettingsH264SettingsFilterSettingsTemporalFilterSettingsProperty): void;
        resetTemporalFilterSettings(): void;
        get temporalFilterSettingsInput(): EncoderSettingsVideoDescriptionsCodecSettingsH264SettingsFilterSettingsTemporalFilterSettingsProperty | undefined;
    }
    interface H264SettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#adaptive_quantization AwsChannel#adaptive_quantization}
        */
        readonly adaptiveQuantization?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#afd_signaling AwsChannel#afd_signaling}
        */
        readonly afdSignaling?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#bitrate AwsChannel#bitrate}
        */
        readonly bitrate?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#buf_fill_pct AwsChannel#buf_fill_pct}
        */
        readonly bufFillPct?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#buf_size AwsChannel#buf_size}
        */
        readonly bufSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#color_metadata AwsChannel#color_metadata}
        */
        readonly colorMetadata?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#entropy_encoding AwsChannel#entropy_encoding}
        */
        readonly entropyEncoding?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#fixed_afd AwsChannel#fixed_afd}
        */
        readonly fixedAfd?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#flicker_aq AwsChannel#flicker_aq}
        */
        readonly flickerAq?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#force_field_pictures AwsChannel#force_field_pictures}
        */
        readonly forceFieldPictures?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#framerate_control AwsChannel#framerate_control}
        */
        readonly framerateControl?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#framerate_denominator AwsChannel#framerate_denominator}
        */
        readonly framerateDenominator?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#framerate_numerator AwsChannel#framerate_numerator}
        */
        readonly framerateNumerator?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#gop_b_reference AwsChannel#gop_b_reference}
        */
        readonly gopBReference?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#gop_closed_cadence AwsChannel#gop_closed_cadence}
        */
        readonly gopClosedCadence?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#gop_num_b_frames AwsChannel#gop_num_b_frames}
        */
        readonly gopNumBFrames?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#gop_size AwsChannel#gop_size}
        */
        readonly gopSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#gop_size_units AwsChannel#gop_size_units}
        */
        readonly gopSizeUnits?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#level AwsChannel#level}
        */
        readonly level?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#look_ahead_rate_control AwsChannel#look_ahead_rate_control}
        */
        readonly lookAheadRateControl?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#max_bitrate AwsChannel#max_bitrate}
        */
        readonly maxBitrate?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#min_i_interval AwsChannel#min_i_interval}
        */
        readonly minIInterval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#num_ref_frames AwsChannel#num_ref_frames}
        */
        readonly numRefFrames?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#par_control AwsChannel#par_control}
        */
        readonly parControl?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#par_denominator AwsChannel#par_denominator}
        */
        readonly parDenominator?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#par_numerator AwsChannel#par_numerator}
        */
        readonly parNumerator?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#profile AwsChannel#profile}
        */
        readonly profile?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#quality_level AwsChannel#quality_level}
        */
        readonly qualityLevel?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#qvbr_quality_level AwsChannel#qvbr_quality_level}
        */
        readonly qvbrQualityLevel?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#rate_control_mode AwsChannel#rate_control_mode}
        */
        readonly rateControlMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#scan_type AwsChannel#scan_type}
        */
        readonly scanType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#scene_change_detect AwsChannel#scene_change_detect}
        */
        readonly sceneChangeDetect?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#slices AwsChannel#slices}
        */
        readonly slices?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#softness AwsChannel#softness}
        */
        readonly softness?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#spatial_aq AwsChannel#spatial_aq}
        */
        readonly spatialAq?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#subgop_length AwsChannel#subgop_length}
        */
        readonly subgopLength?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#syntax AwsChannel#syntax}
        */
        readonly syntax?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#temporal_aq AwsChannel#temporal_aq}
        */
        readonly temporalAq?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#timecode_insertion AwsChannel#timecode_insertion}
        */
        readonly timecodeInsertion?: string;
        /**
        * filter_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#filter_settings AwsChannel#filter_settings}
        */
        readonly filterSettings?: EncoderSettingsVideoDescriptionsCodecSettingsH264SettingsFilterSettingsProperty;
    }
    class H264SettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): H264SettingsProperty | undefined;
        set internalValue(value: H264SettingsProperty | undefined);
        private _adaptiveQuantization?;
        get adaptiveQuantization(): string;
        set adaptiveQuantization(value: string);
        resetAdaptiveQuantization(): void;
        get adaptiveQuantizationInput(): string | undefined;
        private _afdSignaling?;
        get afdSignaling(): string;
        set afdSignaling(value: string);
        resetAfdSignaling(): void;
        get afdSignalingInput(): string | undefined;
        private _bitrate?;
        get bitrate(): number;
        set bitrate(value: number);
        resetBitrate(): void;
        get bitrateInput(): number | undefined;
        private _bufFillPct?;
        get bufFillPct(): number;
        set bufFillPct(value: number);
        resetBufFillPct(): void;
        get bufFillPctInput(): number | undefined;
        private _bufSize?;
        get bufSize(): number;
        set bufSize(value: number);
        resetBufSize(): void;
        get bufSizeInput(): number | undefined;
        private _colorMetadata?;
        get colorMetadata(): string;
        set colorMetadata(value: string);
        resetColorMetadata(): void;
        get colorMetadataInput(): string | undefined;
        private _entropyEncoding?;
        get entropyEncoding(): string;
        set entropyEncoding(value: string);
        resetEntropyEncoding(): void;
        get entropyEncodingInput(): string | undefined;
        private _fixedAfd?;
        get fixedAfd(): string;
        set fixedAfd(value: string);
        resetFixedAfd(): void;
        get fixedAfdInput(): string | undefined;
        private _flickerAq?;
        get flickerAq(): string;
        set flickerAq(value: string);
        resetFlickerAq(): void;
        get flickerAqInput(): string | undefined;
        private _forceFieldPictures?;
        get forceFieldPictures(): string;
        set forceFieldPictures(value: string);
        resetForceFieldPictures(): void;
        get forceFieldPicturesInput(): string | undefined;
        private _framerateControl?;
        get framerateControl(): string;
        set framerateControl(value: string);
        resetFramerateControl(): void;
        get framerateControlInput(): string | undefined;
        private _framerateDenominator?;
        get framerateDenominator(): number;
        set framerateDenominator(value: number);
        resetFramerateDenominator(): void;
        get framerateDenominatorInput(): number | undefined;
        private _framerateNumerator?;
        get framerateNumerator(): number;
        set framerateNumerator(value: number);
        resetFramerateNumerator(): void;
        get framerateNumeratorInput(): number | undefined;
        private _gopBReference?;
        get gopBReference(): string;
        set gopBReference(value: string);
        resetGopBReference(): void;
        get gopBReferenceInput(): string | undefined;
        private _gopClosedCadence?;
        get gopClosedCadence(): number;
        set gopClosedCadence(value: number);
        resetGopClosedCadence(): void;
        get gopClosedCadenceInput(): number | undefined;
        private _gopNumBFrames?;
        get gopNumBFrames(): number;
        set gopNumBFrames(value: number);
        resetGopNumBFrames(): void;
        get gopNumBFramesInput(): number | undefined;
        private _gopSize?;
        get gopSize(): number;
        set gopSize(value: number);
        resetGopSize(): void;
        get gopSizeInput(): number | undefined;
        private _gopSizeUnits?;
        get gopSizeUnits(): string;
        set gopSizeUnits(value: string);
        resetGopSizeUnits(): void;
        get gopSizeUnitsInput(): string | undefined;
        private _level?;
        get level(): string;
        set level(value: string);
        resetLevel(): void;
        get levelInput(): string | undefined;
        private _lookAheadRateControl?;
        get lookAheadRateControl(): string;
        set lookAheadRateControl(value: string);
        resetLookAheadRateControl(): void;
        get lookAheadRateControlInput(): string | undefined;
        private _maxBitrate?;
        get maxBitrate(): number;
        set maxBitrate(value: number);
        resetMaxBitrate(): void;
        get maxBitrateInput(): number | undefined;
        private _minIInterval?;
        get minIInterval(): number;
        set minIInterval(value: number);
        resetMinIInterval(): void;
        get minIIntervalInput(): number | undefined;
        private _numRefFrames?;
        get numRefFrames(): number;
        set numRefFrames(value: number);
        resetNumRefFrames(): void;
        get numRefFramesInput(): number | undefined;
        private _parControl?;
        get parControl(): string;
        set parControl(value: string);
        resetParControl(): void;
        get parControlInput(): string | undefined;
        private _parDenominator?;
        get parDenominator(): number;
        set parDenominator(value: number);
        resetParDenominator(): void;
        get parDenominatorInput(): number | undefined;
        private _parNumerator?;
        get parNumerator(): number;
        set parNumerator(value: number);
        resetParNumerator(): void;
        get parNumeratorInput(): number | undefined;
        private _profile?;
        get profile(): string;
        set profile(value: string);
        resetProfile(): void;
        get profileInput(): string | undefined;
        private _qualityLevel?;
        get qualityLevel(): string;
        set qualityLevel(value: string);
        resetQualityLevel(): void;
        get qualityLevelInput(): string | undefined;
        private _qvbrQualityLevel?;
        get qvbrQualityLevel(): number;
        set qvbrQualityLevel(value: number);
        resetQvbrQualityLevel(): void;
        get qvbrQualityLevelInput(): number | undefined;
        private _rateControlMode?;
        get rateControlMode(): string;
        set rateControlMode(value: string);
        resetRateControlMode(): void;
        get rateControlModeInput(): string | undefined;
        private _scanType?;
        get scanType(): string;
        set scanType(value: string);
        resetScanType(): void;
        get scanTypeInput(): string | undefined;
        private _sceneChangeDetect?;
        get sceneChangeDetect(): string;
        set sceneChangeDetect(value: string);
        resetSceneChangeDetect(): void;
        get sceneChangeDetectInput(): string | undefined;
        private _slices?;
        get slices(): number;
        set slices(value: number);
        resetSlices(): void;
        get slicesInput(): number | undefined;
        private _softness?;
        get softness(): number;
        set softness(value: number);
        resetSoftness(): void;
        get softnessInput(): number | undefined;
        private _spatialAq?;
        get spatialAq(): string;
        set spatialAq(value: string);
        resetSpatialAq(): void;
        get spatialAqInput(): string | undefined;
        private _subgopLength?;
        get subgopLength(): string;
        set subgopLength(value: string);
        resetSubgopLength(): void;
        get subgopLengthInput(): string | undefined;
        private _syntax?;
        get syntax(): string;
        set syntax(value: string);
        resetSyntax(): void;
        get syntaxInput(): string | undefined;
        private _temporalAq?;
        get temporalAq(): string;
        set temporalAq(value: string);
        resetTemporalAq(): void;
        get temporalAqInput(): string | undefined;
        private _timecodeInsertion?;
        get timecodeInsertion(): string;
        set timecodeInsertion(value: string);
        resetTimecodeInsertion(): void;
        get timecodeInsertionInput(): string | undefined;
        private _filterSettings;
        get filterSettings(): EncoderSettingsVideoDescriptionsCodecSettingsH264SettingsFilterSettingsPropertyOutputReference;
        putFilterSettings(value: EncoderSettingsVideoDescriptionsCodecSettingsH264SettingsFilterSettingsProperty): void;
        resetFilterSettings(): void;
        get filterSettingsInput(): EncoderSettingsVideoDescriptionsCodecSettingsH264SettingsFilterSettingsProperty | undefined;
    }
    interface ColorSpacePassthroughSettingsProperty {
    }
    class ColorSpacePassthroughSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ColorSpacePassthroughSettingsProperty | undefined;
        set internalValue(value: ColorSpacePassthroughSettingsProperty | undefined);
    }
    interface DolbyVision81SettingsProperty {
    }
    class DolbyVision81SettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DolbyVision81SettingsProperty | undefined;
        set internalValue(value: DolbyVision81SettingsProperty | undefined);
    }
    interface Hdr10SettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#max_cll AwsChannel#max_cll}
        */
        readonly maxCll?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#max_fall AwsChannel#max_fall}
        */
        readonly maxFall?: number;
    }
    class Hdr10SettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): Hdr10SettingsProperty | undefined;
        set internalValue(value: Hdr10SettingsProperty | undefined);
        private _maxCll?;
        get maxCll(): number;
        set maxCll(value: number);
        resetMaxCll(): void;
        get maxCllInput(): number | undefined;
        private _maxFall?;
        get maxFall(): number;
        set maxFall(value: number);
        resetMaxFall(): void;
        get maxFallInput(): number | undefined;
    }
    interface Rec601SettingsProperty {
    }
    class Rec601SettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): Rec601SettingsProperty | undefined;
        set internalValue(value: Rec601SettingsProperty | undefined);
    }
    interface Rec709SettingsProperty {
    }
    class Rec709SettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): Rec709SettingsProperty | undefined;
        set internalValue(value: Rec709SettingsProperty | undefined);
    }
    interface ColorSpaceSettingsProperty {
        /**
        * color_space_passthrough_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#color_space_passthrough_settings AwsChannel#color_space_passthrough_settings}
        */
        readonly colorSpacePassthroughSettings?: ColorSpacePassthroughSettingsProperty;
        /**
        * dolby_vision81_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#dolby_vision81_settings AwsChannel#dolby_vision81_settings}
        */
        readonly dolbyVision81Settings?: DolbyVision81SettingsProperty;
        /**
        * hdr10_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#hdr10_settings AwsChannel#hdr10_settings}
        */
        readonly hdr10Settings?: Hdr10SettingsProperty;
        /**
        * rec601_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#rec601_settings AwsChannel#rec601_settings}
        */
        readonly rec601Settings?: Rec601SettingsProperty;
        /**
        * rec709_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#rec709_settings AwsChannel#rec709_settings}
        */
        readonly rec709Settings?: Rec709SettingsProperty;
    }
    class ColorSpaceSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ColorSpaceSettingsProperty | undefined;
        set internalValue(value: ColorSpaceSettingsProperty | undefined);
        private _colorSpacePassthroughSettings;
        get colorSpacePassthroughSettings(): ColorSpacePassthroughSettingsPropertyOutputReference;
        putColorSpacePassthroughSettings(value: ColorSpacePassthroughSettingsProperty): void;
        resetColorSpacePassthroughSettings(): void;
        get colorSpacePassthroughSettingsInput(): ColorSpacePassthroughSettingsProperty | undefined;
        private _dolbyVision81Settings;
        get dolbyVision81Settings(): DolbyVision81SettingsPropertyOutputReference;
        putDolbyVision81Settings(value: DolbyVision81SettingsProperty): void;
        resetDolbyVision81Settings(): void;
        get dolbyVision81SettingsInput(): DolbyVision81SettingsProperty | undefined;
        private _hdr10Settings;
        get hdr10Settings(): Hdr10SettingsPropertyOutputReference;
        putHdr10Settings(value: Hdr10SettingsProperty): void;
        resetHdr10Settings(): void;
        get hdr10SettingsInput(): Hdr10SettingsProperty | undefined;
        private _rec601Settings;
        get rec601Settings(): Rec601SettingsPropertyOutputReference;
        putRec601Settings(value: Rec601SettingsProperty): void;
        resetRec601Settings(): void;
        get rec601SettingsInput(): Rec601SettingsProperty | undefined;
        private _rec709Settings;
        get rec709Settings(): Rec709SettingsPropertyOutputReference;
        putRec709Settings(value: Rec709SettingsProperty): void;
        resetRec709Settings(): void;
        get rec709SettingsInput(): Rec709SettingsProperty | undefined;
    }
    interface EncoderSettingsVideoDescriptionsCodecSettingsH265SettingsFilterSettingsTemporalFilterSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#post_filter_sharpening AwsChannel#post_filter_sharpening}
        */
        readonly postFilterSharpening?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#strength AwsChannel#strength}
        */
        readonly strength?: string;
    }
    class EncoderSettingsVideoDescriptionsCodecSettingsH265SettingsFilterSettingsTemporalFilterSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncoderSettingsVideoDescriptionsCodecSettingsH265SettingsFilterSettingsTemporalFilterSettingsProperty | undefined;
        set internalValue(value: EncoderSettingsVideoDescriptionsCodecSettingsH265SettingsFilterSettingsTemporalFilterSettingsProperty | undefined);
        private _postFilterSharpening?;
        get postFilterSharpening(): string;
        set postFilterSharpening(value: string);
        resetPostFilterSharpening(): void;
        get postFilterSharpeningInput(): string | undefined;
        private _strength?;
        get strength(): string;
        set strength(value: string);
        resetStrength(): void;
        get strengthInput(): string | undefined;
    }
    interface EncoderSettingsVideoDescriptionsCodecSettingsH265SettingsFilterSettingsProperty {
        /**
        * temporal_filter_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#temporal_filter_settings AwsChannel#temporal_filter_settings}
        */
        readonly temporalFilterSettings?: EncoderSettingsVideoDescriptionsCodecSettingsH265SettingsFilterSettingsTemporalFilterSettingsProperty;
    }
    class EncoderSettingsVideoDescriptionsCodecSettingsH265SettingsFilterSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncoderSettingsVideoDescriptionsCodecSettingsH265SettingsFilterSettingsProperty | undefined;
        set internalValue(value: EncoderSettingsVideoDescriptionsCodecSettingsH265SettingsFilterSettingsProperty | undefined);
        private _temporalFilterSettings;
        get temporalFilterSettings(): EncoderSettingsVideoDescriptionsCodecSettingsH265SettingsFilterSettingsTemporalFilterSettingsPropertyOutputReference;
        putTemporalFilterSettings(value: EncoderSettingsVideoDescriptionsCodecSettingsH265SettingsFilterSettingsTemporalFilterSettingsProperty): void;
        resetTemporalFilterSettings(): void;
        get temporalFilterSettingsInput(): EncoderSettingsVideoDescriptionsCodecSettingsH265SettingsFilterSettingsTemporalFilterSettingsProperty | undefined;
    }
    interface TimecodeBurninSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#prefix AwsChannel#prefix}
        */
        readonly prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#timecode_burnin_font_size AwsChannel#timecode_burnin_font_size}
        */
        readonly timecodeBurninFontSize?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#timecode_burnin_position AwsChannel#timecode_burnin_position}
        */
        readonly timecodeBurninPosition?: string;
    }
    class TimecodeBurninSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimecodeBurninSettingsProperty | undefined;
        set internalValue(value: TimecodeBurninSettingsProperty | undefined);
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
        private _timecodeBurninFontSize?;
        get timecodeBurninFontSize(): string;
        set timecodeBurninFontSize(value: string);
        resetTimecodeBurninFontSize(): void;
        get timecodeBurninFontSizeInput(): string | undefined;
        private _timecodeBurninPosition?;
        get timecodeBurninPosition(): string;
        set timecodeBurninPosition(value: string);
        resetTimecodeBurninPosition(): void;
        get timecodeBurninPositionInput(): string | undefined;
    }
    interface H265SettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#adaptive_quantization AwsChannel#adaptive_quantization}
        */
        readonly adaptiveQuantization?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#afd_signaling AwsChannel#afd_signaling}
        */
        readonly afdSignaling?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#alternative_transfer_function AwsChannel#alternative_transfer_function}
        */
        readonly alternativeTransferFunction?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#bitrate AwsChannel#bitrate}
        */
        readonly bitrate: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#buf_size AwsChannel#buf_size}
        */
        readonly bufSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#color_metadata AwsChannel#color_metadata}
        */
        readonly colorMetadata?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#fixed_afd AwsChannel#fixed_afd}
        */
        readonly fixedAfd?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#flicker_aq AwsChannel#flicker_aq}
        */
        readonly flickerAq?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#framerate_denominator AwsChannel#framerate_denominator}
        */
        readonly framerateDenominator: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#framerate_numerator AwsChannel#framerate_numerator}
        */
        readonly framerateNumerator: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#gop_closed_cadence AwsChannel#gop_closed_cadence}
        */
        readonly gopClosedCadence?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#gop_size AwsChannel#gop_size}
        */
        readonly gopSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#gop_size_units AwsChannel#gop_size_units}
        */
        readonly gopSizeUnits?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#level AwsChannel#level}
        */
        readonly level?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#look_ahead_rate_control AwsChannel#look_ahead_rate_control}
        */
        readonly lookAheadRateControl?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#max_bitrate AwsChannel#max_bitrate}
        */
        readonly maxBitrate?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#min_i_interval AwsChannel#min_i_interval}
        */
        readonly minIInterval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#min_qp AwsChannel#min_qp}
        */
        readonly minQp?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#mv_over_picture_boundaries AwsChannel#mv_over_picture_boundaries}
        */
        readonly mvOverPictureBoundaries?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#mv_temporal_predictor AwsChannel#mv_temporal_predictor}
        */
        readonly mvTemporalPredictor?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#par_denominator AwsChannel#par_denominator}
        */
        readonly parDenominator?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#par_numerator AwsChannel#par_numerator}
        */
        readonly parNumerator?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#profile AwsChannel#profile}
        */
        readonly profile?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#qvbr_quality_level AwsChannel#qvbr_quality_level}
        */
        readonly qvbrQualityLevel?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#rate_control_mode AwsChannel#rate_control_mode}
        */
        readonly rateControlMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#scan_type AwsChannel#scan_type}
        */
        readonly scanType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#scene_change_detect AwsChannel#scene_change_detect}
        */
        readonly sceneChangeDetect?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#slices AwsChannel#slices}
        */
        readonly slices?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#tier AwsChannel#tier}
        */
        readonly tier?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#tile_height AwsChannel#tile_height}
        */
        readonly tileHeight?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#tile_padding AwsChannel#tile_padding}
        */
        readonly tilePadding?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#tile_width AwsChannel#tile_width}
        */
        readonly tileWidth?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#timecode_insertion AwsChannel#timecode_insertion}
        */
        readonly timecodeInsertion?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#treeblock_size AwsChannel#treeblock_size}
        */
        readonly treeblockSize?: string;
        /**
        * color_space_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#color_space_settings AwsChannel#color_space_settings}
        */
        readonly colorSpaceSettings?: ColorSpaceSettingsProperty;
        /**
        * filter_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#filter_settings AwsChannel#filter_settings}
        */
        readonly filterSettings?: EncoderSettingsVideoDescriptionsCodecSettingsH265SettingsFilterSettingsProperty;
        /**
        * timecode_burnin_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#timecode_burnin_settings AwsChannel#timecode_burnin_settings}
        */
        readonly timecodeBurninSettings?: TimecodeBurninSettingsProperty;
    }
    class H265SettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): H265SettingsProperty | undefined;
        set internalValue(value: H265SettingsProperty | undefined);
        private _adaptiveQuantization?;
        get adaptiveQuantization(): string;
        set adaptiveQuantization(value: string);
        resetAdaptiveQuantization(): void;
        get adaptiveQuantizationInput(): string | undefined;
        private _afdSignaling?;
        get afdSignaling(): string;
        set afdSignaling(value: string);
        resetAfdSignaling(): void;
        get afdSignalingInput(): string | undefined;
        private _alternativeTransferFunction?;
        get alternativeTransferFunction(): string;
        set alternativeTransferFunction(value: string);
        resetAlternativeTransferFunction(): void;
        get alternativeTransferFunctionInput(): string | undefined;
        private _bitrate?;
        get bitrate(): number;
        set bitrate(value: number);
        get bitrateInput(): number | undefined;
        private _bufSize?;
        get bufSize(): number;
        set bufSize(value: number);
        resetBufSize(): void;
        get bufSizeInput(): number | undefined;
        private _colorMetadata?;
        get colorMetadata(): string;
        set colorMetadata(value: string);
        resetColorMetadata(): void;
        get colorMetadataInput(): string | undefined;
        private _fixedAfd?;
        get fixedAfd(): string;
        set fixedAfd(value: string);
        resetFixedAfd(): void;
        get fixedAfdInput(): string | undefined;
        private _flickerAq?;
        get flickerAq(): string;
        set flickerAq(value: string);
        resetFlickerAq(): void;
        get flickerAqInput(): string | undefined;
        private _framerateDenominator?;
        get framerateDenominator(): number;
        set framerateDenominator(value: number);
        get framerateDenominatorInput(): number | undefined;
        private _framerateNumerator?;
        get framerateNumerator(): number;
        set framerateNumerator(value: number);
        get framerateNumeratorInput(): number | undefined;
        private _gopClosedCadence?;
        get gopClosedCadence(): number;
        set gopClosedCadence(value: number);
        resetGopClosedCadence(): void;
        get gopClosedCadenceInput(): number | undefined;
        private _gopSize?;
        get gopSize(): number;
        set gopSize(value: number);
        resetGopSize(): void;
        get gopSizeInput(): number | undefined;
        private _gopSizeUnits?;
        get gopSizeUnits(): string;
        set gopSizeUnits(value: string);
        resetGopSizeUnits(): void;
        get gopSizeUnitsInput(): string | undefined;
        private _level?;
        get level(): string;
        set level(value: string);
        resetLevel(): void;
        get levelInput(): string | undefined;
        private _lookAheadRateControl?;
        get lookAheadRateControl(): string;
        set lookAheadRateControl(value: string);
        resetLookAheadRateControl(): void;
        get lookAheadRateControlInput(): string | undefined;
        private _maxBitrate?;
        get maxBitrate(): number;
        set maxBitrate(value: number);
        resetMaxBitrate(): void;
        get maxBitrateInput(): number | undefined;
        private _minIInterval?;
        get minIInterval(): number;
        set minIInterval(value: number);
        resetMinIInterval(): void;
        get minIIntervalInput(): number | undefined;
        private _minQp?;
        get minQp(): number;
        set minQp(value: number);
        resetMinQp(): void;
        get minQpInput(): number | undefined;
        private _mvOverPictureBoundaries?;
        get mvOverPictureBoundaries(): string;
        set mvOverPictureBoundaries(value: string);
        resetMvOverPictureBoundaries(): void;
        get mvOverPictureBoundariesInput(): string | undefined;
        private _mvTemporalPredictor?;
        get mvTemporalPredictor(): string;
        set mvTemporalPredictor(value: string);
        resetMvTemporalPredictor(): void;
        get mvTemporalPredictorInput(): string | undefined;
        private _parDenominator?;
        get parDenominator(): number;
        set parDenominator(value: number);
        resetParDenominator(): void;
        get parDenominatorInput(): number | undefined;
        private _parNumerator?;
        get parNumerator(): number;
        set parNumerator(value: number);
        resetParNumerator(): void;
        get parNumeratorInput(): number | undefined;
        private _profile?;
        get profile(): string;
        set profile(value: string);
        resetProfile(): void;
        get profileInput(): string | undefined;
        private _qvbrQualityLevel?;
        get qvbrQualityLevel(): number;
        set qvbrQualityLevel(value: number);
        resetQvbrQualityLevel(): void;
        get qvbrQualityLevelInput(): number | undefined;
        private _rateControlMode?;
        get rateControlMode(): string;
        set rateControlMode(value: string);
        resetRateControlMode(): void;
        get rateControlModeInput(): string | undefined;
        private _scanType?;
        get scanType(): string;
        set scanType(value: string);
        resetScanType(): void;
        get scanTypeInput(): string | undefined;
        private _sceneChangeDetect?;
        get sceneChangeDetect(): string;
        set sceneChangeDetect(value: string);
        resetSceneChangeDetect(): void;
        get sceneChangeDetectInput(): string | undefined;
        private _slices?;
        get slices(): number;
        set slices(value: number);
        resetSlices(): void;
        get slicesInput(): number | undefined;
        private _tier?;
        get tier(): string;
        set tier(value: string);
        resetTier(): void;
        get tierInput(): string | undefined;
        private _tileHeight?;
        get tileHeight(): number;
        set tileHeight(value: number);
        resetTileHeight(): void;
        get tileHeightInput(): number | undefined;
        private _tilePadding?;
        get tilePadding(): string;
        set tilePadding(value: string);
        resetTilePadding(): void;
        get tilePaddingInput(): string | undefined;
        private _tileWidth?;
        get tileWidth(): number;
        set tileWidth(value: number);
        resetTileWidth(): void;
        get tileWidthInput(): number | undefined;
        private _timecodeInsertion?;
        get timecodeInsertion(): string;
        set timecodeInsertion(value: string);
        resetTimecodeInsertion(): void;
        get timecodeInsertionInput(): string | undefined;
        private _treeblockSize?;
        get treeblockSize(): string;
        set treeblockSize(value: string);
        resetTreeblockSize(): void;
        get treeblockSizeInput(): string | undefined;
        private _colorSpaceSettings;
        get colorSpaceSettings(): ColorSpaceSettingsPropertyOutputReference;
        putColorSpaceSettings(value: ColorSpaceSettingsProperty): void;
        resetColorSpaceSettings(): void;
        get colorSpaceSettingsInput(): ColorSpaceSettingsProperty | undefined;
        private _filterSettings;
        get filterSettings(): EncoderSettingsVideoDescriptionsCodecSettingsH265SettingsFilterSettingsPropertyOutputReference;
        putFilterSettings(value: EncoderSettingsVideoDescriptionsCodecSettingsH265SettingsFilterSettingsProperty): void;
        resetFilterSettings(): void;
        get filterSettingsInput(): EncoderSettingsVideoDescriptionsCodecSettingsH265SettingsFilterSettingsProperty | undefined;
        private _timecodeBurninSettings;
        get timecodeBurninSettings(): TimecodeBurninSettingsPropertyOutputReference;
        putTimecodeBurninSettings(value: TimecodeBurninSettingsProperty): void;
        resetTimecodeBurninSettings(): void;
        get timecodeBurninSettingsInput(): TimecodeBurninSettingsProperty | undefined;
    }
    interface EncoderSettingsVideoDescriptionsCodecSettingsProperty {
        /**
        * frame_capture_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#frame_capture_settings AwsChannel#frame_capture_settings}
        */
        readonly frameCaptureSettings?: FrameCaptureSettingsProperty;
        /**
        * h264_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#h264_settings AwsChannel#h264_settings}
        */
        readonly h264Settings?: H264SettingsProperty;
        /**
        * h265_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#h265_settings AwsChannel#h265_settings}
        */
        readonly h265Settings?: H265SettingsProperty;
    }
    class EncoderSettingsVideoDescriptionsCodecSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncoderSettingsVideoDescriptionsCodecSettingsProperty | undefined;
        set internalValue(value: EncoderSettingsVideoDescriptionsCodecSettingsProperty | undefined);
        private _frameCaptureSettings;
        get frameCaptureSettings(): FrameCaptureSettingsPropertyOutputReference;
        putFrameCaptureSettings(value: FrameCaptureSettingsProperty): void;
        resetFrameCaptureSettings(): void;
        get frameCaptureSettingsInput(): FrameCaptureSettingsProperty | undefined;
        private _h264Settings;
        get h264Settings(): H264SettingsPropertyOutputReference;
        putH264Settings(value: H264SettingsProperty): void;
        resetH264Settings(): void;
        get h264SettingsInput(): H264SettingsProperty | undefined;
        private _h265Settings;
        get h265Settings(): H265SettingsPropertyOutputReference;
        putH265Settings(value: H265SettingsProperty): void;
        resetH265Settings(): void;
        get h265SettingsInput(): H265SettingsProperty | undefined;
    }
    interface VideoDescriptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#height AwsChannel#height}
        */
        readonly height?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#name AwsChannel#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#respond_to_afd AwsChannel#respond_to_afd}
        */
        readonly respondToAfd?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#scaling_behavior AwsChannel#scaling_behavior}
        */
        readonly scalingBehavior?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#sharpness AwsChannel#sharpness}
        */
        readonly sharpness?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#width AwsChannel#width}
        */
        readonly width?: number;
        /**
        * codec_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#codec_settings AwsChannel#codec_settings}
        */
        readonly codecSettings?: EncoderSettingsVideoDescriptionsCodecSettingsProperty;
    }
    class VideoDescriptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VideoDescriptionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VideoDescriptionsProperty | cdktn.IResolvable | undefined);
        private _height?;
        get height(): number;
        set height(value: number);
        resetHeight(): void;
        get heightInput(): number | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _respondToAfd?;
        get respondToAfd(): string;
        set respondToAfd(value: string);
        resetRespondToAfd(): void;
        get respondToAfdInput(): string | undefined;
        private _scalingBehavior?;
        get scalingBehavior(): string;
        set scalingBehavior(value: string);
        resetScalingBehavior(): void;
        get scalingBehaviorInput(): string | undefined;
        private _sharpness?;
        get sharpness(): number;
        set sharpness(value: number);
        resetSharpness(): void;
        get sharpnessInput(): number | undefined;
        private _width?;
        get width(): number;
        set width(value: number);
        resetWidth(): void;
        get widthInput(): number | undefined;
        private _codecSettings;
        get codecSettings(): EncoderSettingsVideoDescriptionsCodecSettingsPropertyOutputReference;
        putCodecSettings(value: EncoderSettingsVideoDescriptionsCodecSettingsProperty): void;
        resetCodecSettings(): void;
        get codecSettingsInput(): EncoderSettingsVideoDescriptionsCodecSettingsProperty | undefined;
    }
    class VideoDescriptionsPropertyList extends cdktn.ComplexList {
        internalValue?: VideoDescriptionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VideoDescriptionsPropertyOutputReference;
    }
    interface EncoderSettingsProperty {
        /**
        * audio_descriptions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#audio_descriptions AwsChannel#audio_descriptions}
        */
        readonly audioDescriptions?: AudioDescriptionsProperty[] | cdktn.IResolvable;
        /**
        * avail_blanking block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#avail_blanking AwsChannel#avail_blanking}
        */
        readonly availBlanking?: AvailBlankingProperty;
        /**
        * caption_descriptions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#caption_descriptions AwsChannel#caption_descriptions}
        */
        readonly captionDescriptions?: CaptionDescriptionsProperty[] | cdktn.IResolvable;
        /**
        * global_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#global_configuration AwsChannel#global_configuration}
        */
        readonly globalConfiguration?: GlobalConfigurationProperty;
        /**
        * motion_graphics_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#motion_graphics_configuration AwsChannel#motion_graphics_configuration}
        */
        readonly motionGraphicsConfiguration?: MotionGraphicsConfigurationProperty;
        /**
        * nielsen_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#nielsen_configuration AwsChannel#nielsen_configuration}
        */
        readonly nielsenConfiguration?: NielsenConfigurationProperty;
        /**
        * output_groups block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#output_groups AwsChannel#output_groups}
        */
        readonly outputGroups: OutputGroupsProperty[] | cdktn.IResolvable;
        /**
        * timecode_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#timecode_config AwsChannel#timecode_config}
        */
        readonly timecodeConfig: TimecodeConfigProperty;
        /**
        * video_descriptions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#video_descriptions AwsChannel#video_descriptions}
        */
        readonly videoDescriptions?: VideoDescriptionsProperty[] | cdktn.IResolvable;
    }
    class EncoderSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncoderSettingsProperty | undefined;
        set internalValue(value: EncoderSettingsProperty | undefined);
        private _audioDescriptions;
        get audioDescriptions(): AudioDescriptionsPropertyList;
        putAudioDescriptions(value: AudioDescriptionsProperty[] | cdktn.IResolvable): void;
        resetAudioDescriptions(): void;
        get audioDescriptionsInput(): cdktn.IResolvable | AudioDescriptionsProperty[] | undefined;
        private _availBlanking;
        get availBlanking(): AvailBlankingPropertyOutputReference;
        putAvailBlanking(value: AvailBlankingProperty): void;
        resetAvailBlanking(): void;
        get availBlankingInput(): AvailBlankingProperty | undefined;
        private _captionDescriptions;
        get captionDescriptions(): CaptionDescriptionsPropertyList;
        putCaptionDescriptions(value: CaptionDescriptionsProperty[] | cdktn.IResolvable): void;
        resetCaptionDescriptions(): void;
        get captionDescriptionsInput(): cdktn.IResolvable | CaptionDescriptionsProperty[] | undefined;
        private _globalConfiguration;
        get globalConfiguration(): GlobalConfigurationPropertyOutputReference;
        putGlobalConfiguration(value: GlobalConfigurationProperty): void;
        resetGlobalConfiguration(): void;
        get globalConfigurationInput(): GlobalConfigurationProperty | undefined;
        private _motionGraphicsConfiguration;
        get motionGraphicsConfiguration(): MotionGraphicsConfigurationPropertyOutputReference;
        putMotionGraphicsConfiguration(value: MotionGraphicsConfigurationProperty): void;
        resetMotionGraphicsConfiguration(): void;
        get motionGraphicsConfigurationInput(): MotionGraphicsConfigurationProperty | undefined;
        private _nielsenConfiguration;
        get nielsenConfiguration(): NielsenConfigurationPropertyOutputReference;
        putNielsenConfiguration(value: NielsenConfigurationProperty): void;
        resetNielsenConfiguration(): void;
        get nielsenConfigurationInput(): NielsenConfigurationProperty | undefined;
        private _outputGroups;
        get outputGroups(): OutputGroupsPropertyList;
        putOutputGroups(value: OutputGroupsProperty[] | cdktn.IResolvable): void;
        get outputGroupsInput(): cdktn.IResolvable | OutputGroupsProperty[] | undefined;
        private _timecodeConfig;
        get timecodeConfig(): TimecodeConfigPropertyOutputReference;
        putTimecodeConfig(value: TimecodeConfigProperty): void;
        get timecodeConfigInput(): TimecodeConfigProperty | undefined;
        private _videoDescriptions;
        get videoDescriptions(): VideoDescriptionsPropertyList;
        putVideoDescriptions(value: VideoDescriptionsProperty[] | cdktn.IResolvable): void;
        resetVideoDescriptions(): void;
        get videoDescriptionsInput(): cdktn.IResolvable | VideoDescriptionsProperty[] | undefined;
    }
    interface AudioSilenceSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#audio_selector_name AwsChannel#audio_selector_name}
        */
        readonly audioSelectorName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#audio_silence_threshold_msec AwsChannel#audio_silence_threshold_msec}
        */
        readonly audioSilenceThresholdMsec?: number;
    }
    class AudioSilenceSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AudioSilenceSettingsProperty | undefined;
        set internalValue(value: AudioSilenceSettingsProperty | undefined);
        private _audioSelectorName?;
        get audioSelectorName(): string;
        set audioSelectorName(value: string);
        get audioSelectorNameInput(): string | undefined;
        private _audioSilenceThresholdMsec?;
        get audioSilenceThresholdMsec(): number;
        set audioSilenceThresholdMsec(value: number);
        resetAudioSilenceThresholdMsec(): void;
        get audioSilenceThresholdMsecInput(): number | undefined;
    }
    interface InputLossSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#input_loss_threshold_msec AwsChannel#input_loss_threshold_msec}
        */
        readonly inputLossThresholdMsec?: number;
    }
    class InputLossSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InputLossSettingsProperty | undefined;
        set internalValue(value: InputLossSettingsProperty | undefined);
        private _inputLossThresholdMsec?;
        get inputLossThresholdMsec(): number;
        set inputLossThresholdMsec(value: number);
        resetInputLossThresholdMsec(): void;
        get inputLossThresholdMsecInput(): number | undefined;
    }
    interface VideoBlackSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#black_detect_threshold AwsChannel#black_detect_threshold}
        */
        readonly blackDetectThreshold?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#video_black_threshold_msec AwsChannel#video_black_threshold_msec}
        */
        readonly videoBlackThresholdMsec?: number;
    }
    class VideoBlackSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VideoBlackSettingsProperty | undefined;
        set internalValue(value: VideoBlackSettingsProperty | undefined);
        private _blackDetectThreshold?;
        get blackDetectThreshold(): number;
        set blackDetectThreshold(value: number);
        resetBlackDetectThreshold(): void;
        get blackDetectThresholdInput(): number | undefined;
        private _videoBlackThresholdMsec?;
        get videoBlackThresholdMsec(): number;
        set videoBlackThresholdMsec(value: number);
        resetVideoBlackThresholdMsec(): void;
        get videoBlackThresholdMsecInput(): number | undefined;
    }
    interface FailoverConditionSettingsProperty {
        /**
        * audio_silence_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#audio_silence_settings AwsChannel#audio_silence_settings}
        */
        readonly audioSilenceSettings?: AudioSilenceSettingsProperty;
        /**
        * input_loss_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#input_loss_settings AwsChannel#input_loss_settings}
        */
        readonly inputLossSettings?: InputLossSettingsProperty;
        /**
        * video_black_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#video_black_settings AwsChannel#video_black_settings}
        */
        readonly videoBlackSettings?: VideoBlackSettingsProperty;
    }
    class FailoverConditionSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FailoverConditionSettingsProperty | undefined;
        set internalValue(value: FailoverConditionSettingsProperty | undefined);
        private _audioSilenceSettings;
        get audioSilenceSettings(): AudioSilenceSettingsPropertyOutputReference;
        putAudioSilenceSettings(value: AudioSilenceSettingsProperty): void;
        resetAudioSilenceSettings(): void;
        get audioSilenceSettingsInput(): AudioSilenceSettingsProperty | undefined;
        private _inputLossSettings;
        get inputLossSettings(): InputLossSettingsPropertyOutputReference;
        putInputLossSettings(value: InputLossSettingsProperty): void;
        resetInputLossSettings(): void;
        get inputLossSettingsInput(): InputLossSettingsProperty | undefined;
        private _videoBlackSettings;
        get videoBlackSettings(): VideoBlackSettingsPropertyOutputReference;
        putVideoBlackSettings(value: VideoBlackSettingsProperty): void;
        resetVideoBlackSettings(): void;
        get videoBlackSettingsInput(): VideoBlackSettingsProperty | undefined;
    }
    interface FailoverConditionProperty {
        /**
        * failover_condition_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#failover_condition_settings AwsChannel#failover_condition_settings}
        */
        readonly failoverConditionSettings?: FailoverConditionSettingsProperty;
    }
    class FailoverConditionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FailoverConditionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FailoverConditionProperty | cdktn.IResolvable | undefined);
        private _failoverConditionSettings;
        get failoverConditionSettings(): FailoverConditionSettingsPropertyOutputReference;
        putFailoverConditionSettings(value: FailoverConditionSettingsProperty): void;
        resetFailoverConditionSettings(): void;
        get failoverConditionSettingsInput(): FailoverConditionSettingsProperty | undefined;
    }
    class FailoverConditionPropertyList extends cdktn.ComplexList {
        internalValue?: FailoverConditionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FailoverConditionPropertyOutputReference;
    }
    interface AutomaticInputFailoverSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#error_clear_time_msec AwsChannel#error_clear_time_msec}
        */
        readonly errorClearTimeMsec?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#input_preference AwsChannel#input_preference}
        */
        readonly inputPreference?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#secondary_input_id AwsChannel#secondary_input_id}
        */
        readonly secondaryInputId: string;
        /**
        * failover_condition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#failover_condition AwsChannel#failover_condition}
        */
        readonly failoverCondition?: FailoverConditionProperty[] | cdktn.IResolvable;
    }
    class AutomaticInputFailoverSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AutomaticInputFailoverSettingsProperty | undefined;
        set internalValue(value: AutomaticInputFailoverSettingsProperty | undefined);
        private _errorClearTimeMsec?;
        get errorClearTimeMsec(): number;
        set errorClearTimeMsec(value: number);
        resetErrorClearTimeMsec(): void;
        get errorClearTimeMsecInput(): number | undefined;
        private _inputPreference?;
        get inputPreference(): string;
        set inputPreference(value: string);
        resetInputPreference(): void;
        get inputPreferenceInput(): string | undefined;
        private _secondaryInputId?;
        get secondaryInputId(): string;
        set secondaryInputId(value: string);
        get secondaryInputIdInput(): string | undefined;
        private _failoverCondition;
        get failoverCondition(): FailoverConditionPropertyList;
        putFailoverCondition(value: FailoverConditionProperty[] | cdktn.IResolvable): void;
        resetFailoverCondition(): void;
        get failoverConditionInput(): cdktn.IResolvable | FailoverConditionProperty[] | undefined;
    }
    interface AudioHlsRenditionSelectionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#group_id AwsChannel#group_id}
        */
        readonly groupId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#name AwsChannel#name}
        */
        readonly name: string;
    }
    class AudioHlsRenditionSelectionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AudioHlsRenditionSelectionProperty | undefined;
        set internalValue(value: AudioHlsRenditionSelectionProperty | undefined);
        private _groupId?;
        get groupId(): string;
        set groupId(value: string);
        get groupIdInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    interface AudioLanguageSelectionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#language_code AwsChannel#language_code}
        */
        readonly languageCode: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#language_selection_policy AwsChannel#language_selection_policy}
        */
        readonly languageSelectionPolicy?: string;
    }
    class AudioLanguageSelectionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AudioLanguageSelectionProperty | undefined;
        set internalValue(value: AudioLanguageSelectionProperty | undefined);
        private _languageCode?;
        get languageCode(): string;
        set languageCode(value: string);
        get languageCodeInput(): string | undefined;
        private _languageSelectionPolicy?;
        get languageSelectionPolicy(): string;
        set languageSelectionPolicy(value: string);
        resetLanguageSelectionPolicy(): void;
        get languageSelectionPolicyInput(): string | undefined;
    }
    interface AudioPidSelectionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#pid AwsChannel#pid}
        */
        readonly pid: number;
    }
    class AudioPidSelectionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AudioPidSelectionProperty | undefined;
        set internalValue(value: AudioPidSelectionProperty | undefined);
        private _pid?;
        get pid(): number;
        set pid(value: number);
        get pidInput(): number | undefined;
    }
    interface DolbyEDecodeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#program_selection AwsChannel#program_selection}
        */
        readonly programSelection: string;
    }
    class DolbyEDecodePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DolbyEDecodeProperty | undefined;
        set internalValue(value: DolbyEDecodeProperty | undefined);
        private _programSelection?;
        get programSelection(): string;
        set programSelection(value: string);
        get programSelectionInput(): string | undefined;
    }
    interface TracksProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#track AwsChannel#track}
        */
        readonly track: number;
    }
    class TracksPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TracksProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TracksProperty | cdktn.IResolvable | undefined);
        private _track?;
        get track(): number;
        set track(value: number);
        get trackInput(): number | undefined;
    }
    class TracksPropertyList extends cdktn.ComplexList {
        internalValue?: TracksProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TracksPropertyOutputReference;
    }
    interface AudioTrackSelectionProperty {
        /**
        * dolby_e_decode block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#dolby_e_decode AwsChannel#dolby_e_decode}
        */
        readonly dolbyEDecode?: DolbyEDecodeProperty;
        /**
        * tracks block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#tracks AwsChannel#tracks}
        */
        readonly tracks: TracksProperty[] | cdktn.IResolvable;
    }
    class AudioTrackSelectionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AudioTrackSelectionProperty | undefined;
        set internalValue(value: AudioTrackSelectionProperty | undefined);
        private _dolbyEDecode;
        get dolbyEDecode(): DolbyEDecodePropertyOutputReference;
        putDolbyEDecode(value: DolbyEDecodeProperty): void;
        resetDolbyEDecode(): void;
        get dolbyEDecodeInput(): DolbyEDecodeProperty | undefined;
        private _tracks;
        get tracks(): TracksPropertyList;
        putTracks(value: TracksProperty[] | cdktn.IResolvable): void;
        get tracksInput(): cdktn.IResolvable | TracksProperty[] | undefined;
    }
    interface InputAttachmentsInputSettingsAudioSelectorSelectorSettingsProperty {
        /**
        * audio_hls_rendition_selection block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#audio_hls_rendition_selection AwsChannel#audio_hls_rendition_selection}
        */
        readonly audioHlsRenditionSelection?: AudioHlsRenditionSelectionProperty;
        /**
        * audio_language_selection block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#audio_language_selection AwsChannel#audio_language_selection}
        */
        readonly audioLanguageSelection?: AudioLanguageSelectionProperty;
        /**
        * audio_pid_selection block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#audio_pid_selection AwsChannel#audio_pid_selection}
        */
        readonly audioPidSelection?: AudioPidSelectionProperty;
        /**
        * audio_track_selection block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#audio_track_selection AwsChannel#audio_track_selection}
        */
        readonly audioTrackSelection?: AudioTrackSelectionProperty;
    }
    class InputAttachmentsInputSettingsAudioSelectorSelectorSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InputAttachmentsInputSettingsAudioSelectorSelectorSettingsProperty | undefined;
        set internalValue(value: InputAttachmentsInputSettingsAudioSelectorSelectorSettingsProperty | undefined);
        private _audioHlsRenditionSelection;
        get audioHlsRenditionSelection(): AudioHlsRenditionSelectionPropertyOutputReference;
        putAudioHlsRenditionSelection(value: AudioHlsRenditionSelectionProperty): void;
        resetAudioHlsRenditionSelection(): void;
        get audioHlsRenditionSelectionInput(): AudioHlsRenditionSelectionProperty | undefined;
        private _audioLanguageSelection;
        get audioLanguageSelection(): AudioLanguageSelectionPropertyOutputReference;
        putAudioLanguageSelection(value: AudioLanguageSelectionProperty): void;
        resetAudioLanguageSelection(): void;
        get audioLanguageSelectionInput(): AudioLanguageSelectionProperty | undefined;
        private _audioPidSelection;
        get audioPidSelection(): AudioPidSelectionPropertyOutputReference;
        putAudioPidSelection(value: AudioPidSelectionProperty): void;
        resetAudioPidSelection(): void;
        get audioPidSelectionInput(): AudioPidSelectionProperty | undefined;
        private _audioTrackSelection;
        get audioTrackSelection(): AudioTrackSelectionPropertyOutputReference;
        putAudioTrackSelection(value: AudioTrackSelectionProperty): void;
        resetAudioTrackSelection(): void;
        get audioTrackSelectionInput(): AudioTrackSelectionProperty | undefined;
    }
    interface AudioSelectorProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#name AwsChannel#name}
        */
        readonly name: string;
        /**
        * selector_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#selector_settings AwsChannel#selector_settings}
        */
        readonly selectorSettings?: InputAttachmentsInputSettingsAudioSelectorSelectorSettingsProperty;
    }
    class AudioSelectorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AudioSelectorProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AudioSelectorProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _selectorSettings;
        get selectorSettings(): InputAttachmentsInputSettingsAudioSelectorSelectorSettingsPropertyOutputReference;
        putSelectorSettings(value: InputAttachmentsInputSettingsAudioSelectorSelectorSettingsProperty): void;
        resetSelectorSettings(): void;
        get selectorSettingsInput(): InputAttachmentsInputSettingsAudioSelectorSelectorSettingsProperty | undefined;
    }
    class AudioSelectorPropertyList extends cdktn.ComplexList {
        internalValue?: AudioSelectorProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AudioSelectorPropertyOutputReference;
    }
    interface AncillarySourceSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#source_ancillary_channel_number AwsChannel#source_ancillary_channel_number}
        */
        readonly sourceAncillaryChannelNumber?: number;
    }
    class AncillarySourceSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AncillarySourceSettingsProperty | undefined;
        set internalValue(value: AncillarySourceSettingsProperty | undefined);
        private _sourceAncillaryChannelNumber?;
        get sourceAncillaryChannelNumber(): number;
        set sourceAncillaryChannelNumber(value: number);
        resetSourceAncillaryChannelNumber(): void;
        get sourceAncillaryChannelNumberInput(): number | undefined;
    }
    interface AribSourceSettingsProperty {
    }
    class AribSourceSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AribSourceSettingsProperty | undefined;
        set internalValue(value: AribSourceSettingsProperty | undefined);
    }
    interface DvbSubSourceSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#ocr_language AwsChannel#ocr_language}
        */
        readonly ocrLanguage?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#pid AwsChannel#pid}
        */
        readonly pid?: number;
    }
    class DvbSubSourceSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DvbSubSourceSettingsProperty | undefined;
        set internalValue(value: DvbSubSourceSettingsProperty | undefined);
        private _ocrLanguage?;
        get ocrLanguage(): string;
        set ocrLanguage(value: string);
        resetOcrLanguage(): void;
        get ocrLanguageInput(): string | undefined;
        private _pid?;
        get pid(): number;
        set pid(value: number);
        resetPid(): void;
        get pidInput(): number | undefined;
    }
    interface EmbeddedSourceSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#convert_608_to_708 AwsChannel#convert_608_to_708}
        */
        readonly convert608To708?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#scte20_detection AwsChannel#scte20_detection}
        */
        readonly scte20Detection?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#source_608_channel_number AwsChannel#source_608_channel_number}
        */
        readonly source608ChannelNumber?: number;
    }
    class EmbeddedSourceSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EmbeddedSourceSettingsProperty | undefined;
        set internalValue(value: EmbeddedSourceSettingsProperty | undefined);
        private _convert608To708?;
        get convert608To708(): string;
        set convert608To708(value: string);
        resetConvert608To708(): void;
        get convert608To708Input(): string | undefined;
        private _scte20Detection?;
        get scte20Detection(): string;
        set scte20Detection(value: string);
        resetScte20Detection(): void;
        get scte20DetectionInput(): string | undefined;
        private _source608ChannelNumber?;
        get source608ChannelNumber(): number;
        set source608ChannelNumber(value: number);
        resetSource608ChannelNumber(): void;
        get source608ChannelNumberInput(): number | undefined;
    }
    interface Scte20SourceSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#convert_608_to_708 AwsChannel#convert_608_to_708}
        */
        readonly convert608To708?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#source_608_channel_number AwsChannel#source_608_channel_number}
        */
        readonly source608ChannelNumber?: number;
    }
    class Scte20SourceSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): Scte20SourceSettingsProperty | undefined;
        set internalValue(value: Scte20SourceSettingsProperty | undefined);
        private _convert608To708?;
        get convert608To708(): string;
        set convert608To708(value: string);
        resetConvert608To708(): void;
        get convert608To708Input(): string | undefined;
        private _source608ChannelNumber?;
        get source608ChannelNumber(): number;
        set source608ChannelNumber(value: number);
        resetSource608ChannelNumber(): void;
        get source608ChannelNumberInput(): number | undefined;
    }
    interface Scte27SourceSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#ocr_language AwsChannel#ocr_language}
        */
        readonly ocrLanguage?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#pid AwsChannel#pid}
        */
        readonly pid?: number;
    }
    class Scte27SourceSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): Scte27SourceSettingsProperty | undefined;
        set internalValue(value: Scte27SourceSettingsProperty | undefined);
        private _ocrLanguage?;
        get ocrLanguage(): string;
        set ocrLanguage(value: string);
        resetOcrLanguage(): void;
        get ocrLanguageInput(): string | undefined;
        private _pid?;
        get pid(): number;
        set pid(value: number);
        resetPid(): void;
        get pidInput(): number | undefined;
    }
    interface OutputRectangleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#height AwsChannel#height}
        */
        readonly height: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#left_offset AwsChannel#left_offset}
        */
        readonly leftOffset: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#top_offset AwsChannel#top_offset}
        */
        readonly topOffset: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#width AwsChannel#width}
        */
        readonly width: number;
    }
    class OutputRectanglePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OutputRectangleProperty | undefined;
        set internalValue(value: OutputRectangleProperty | undefined);
        private _height?;
        get height(): number;
        set height(value: number);
        get heightInput(): number | undefined;
        private _leftOffset?;
        get leftOffset(): number;
        set leftOffset(value: number);
        get leftOffsetInput(): number | undefined;
        private _topOffset?;
        get topOffset(): number;
        set topOffset(value: number);
        get topOffsetInput(): number | undefined;
        private _width?;
        get width(): number;
        set width(value: number);
        get widthInput(): number | undefined;
    }
    interface TeletextSourceSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#page_number AwsChannel#page_number}
        */
        readonly pageNumber?: string;
        /**
        * output_rectangle block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#output_rectangle AwsChannel#output_rectangle}
        */
        readonly outputRectangle?: OutputRectangleProperty;
    }
    class TeletextSourceSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TeletextSourceSettingsProperty | undefined;
        set internalValue(value: TeletextSourceSettingsProperty | undefined);
        private _pageNumber?;
        get pageNumber(): string;
        set pageNumber(value: string);
        resetPageNumber(): void;
        get pageNumberInput(): string | undefined;
        private _outputRectangle;
        get outputRectangle(): OutputRectanglePropertyOutputReference;
        putOutputRectangle(value: OutputRectangleProperty): void;
        resetOutputRectangle(): void;
        get outputRectangleInput(): OutputRectangleProperty | undefined;
    }
    interface InputAttachmentsInputSettingsCaptionSelectorSelectorSettingsProperty {
        /**
        * ancillary_source_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#ancillary_source_settings AwsChannel#ancillary_source_settings}
        */
        readonly ancillarySourceSettings?: AncillarySourceSettingsProperty;
        /**
        * arib_source_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#arib_source_settings AwsChannel#arib_source_settings}
        */
        readonly aribSourceSettings?: AribSourceSettingsProperty;
        /**
        * dvb_sub_source_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#dvb_sub_source_settings AwsChannel#dvb_sub_source_settings}
        */
        readonly dvbSubSourceSettings?: DvbSubSourceSettingsProperty;
        /**
        * embedded_source_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#embedded_source_settings AwsChannel#embedded_source_settings}
        */
        readonly embeddedSourceSettings?: EmbeddedSourceSettingsProperty;
        /**
        * scte20_source_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#scte20_source_settings AwsChannel#scte20_source_settings}
        */
        readonly scte20SourceSettings?: Scte20SourceSettingsProperty;
        /**
        * scte27_source_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#scte27_source_settings AwsChannel#scte27_source_settings}
        */
        readonly scte27SourceSettings?: Scte27SourceSettingsProperty;
        /**
        * teletext_source_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#teletext_source_settings AwsChannel#teletext_source_settings}
        */
        readonly teletextSourceSettings?: TeletextSourceSettingsProperty;
    }
    class InputAttachmentsInputSettingsCaptionSelectorSelectorSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InputAttachmentsInputSettingsCaptionSelectorSelectorSettingsProperty | undefined;
        set internalValue(value: InputAttachmentsInputSettingsCaptionSelectorSelectorSettingsProperty | undefined);
        private _ancillarySourceSettings;
        get ancillarySourceSettings(): AncillarySourceSettingsPropertyOutputReference;
        putAncillarySourceSettings(value: AncillarySourceSettingsProperty): void;
        resetAncillarySourceSettings(): void;
        get ancillarySourceSettingsInput(): AncillarySourceSettingsProperty | undefined;
        private _aribSourceSettings;
        get aribSourceSettings(): AribSourceSettingsPropertyOutputReference;
        putAribSourceSettings(value: AribSourceSettingsProperty): void;
        resetAribSourceSettings(): void;
        get aribSourceSettingsInput(): AribSourceSettingsProperty | undefined;
        private _dvbSubSourceSettings;
        get dvbSubSourceSettings(): DvbSubSourceSettingsPropertyOutputReference;
        putDvbSubSourceSettings(value: DvbSubSourceSettingsProperty): void;
        resetDvbSubSourceSettings(): void;
        get dvbSubSourceSettingsInput(): DvbSubSourceSettingsProperty | undefined;
        private _embeddedSourceSettings;
        get embeddedSourceSettings(): EmbeddedSourceSettingsPropertyOutputReference;
        putEmbeddedSourceSettings(value: EmbeddedSourceSettingsProperty): void;
        resetEmbeddedSourceSettings(): void;
        get embeddedSourceSettingsInput(): EmbeddedSourceSettingsProperty | undefined;
        private _scte20SourceSettings;
        get scte20SourceSettings(): Scte20SourceSettingsPropertyOutputReference;
        putScte20SourceSettings(value: Scte20SourceSettingsProperty): void;
        resetScte20SourceSettings(): void;
        get scte20SourceSettingsInput(): Scte20SourceSettingsProperty | undefined;
        private _scte27SourceSettings;
        get scte27SourceSettings(): Scte27SourceSettingsPropertyOutputReference;
        putScte27SourceSettings(value: Scte27SourceSettingsProperty): void;
        resetScte27SourceSettings(): void;
        get scte27SourceSettingsInput(): Scte27SourceSettingsProperty | undefined;
        private _teletextSourceSettings;
        get teletextSourceSettings(): TeletextSourceSettingsPropertyOutputReference;
        putTeletextSourceSettings(value: TeletextSourceSettingsProperty): void;
        resetTeletextSourceSettings(): void;
        get teletextSourceSettingsInput(): TeletextSourceSettingsProperty | undefined;
    }
    interface CaptionSelectorProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#language_code AwsChannel#language_code}
        */
        readonly languageCode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#name AwsChannel#name}
        */
        readonly name: string;
        /**
        * selector_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#selector_settings AwsChannel#selector_settings}
        */
        readonly selectorSettings?: InputAttachmentsInputSettingsCaptionSelectorSelectorSettingsProperty;
    }
    class CaptionSelectorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CaptionSelectorProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CaptionSelectorProperty | cdktn.IResolvable | undefined);
        private _languageCode?;
        get languageCode(): string;
        set languageCode(value: string);
        resetLanguageCode(): void;
        get languageCodeInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _selectorSettings;
        get selectorSettings(): InputAttachmentsInputSettingsCaptionSelectorSelectorSettingsPropertyOutputReference;
        putSelectorSettings(value: InputAttachmentsInputSettingsCaptionSelectorSelectorSettingsProperty): void;
        resetSelectorSettings(): void;
        get selectorSettingsInput(): InputAttachmentsInputSettingsCaptionSelectorSelectorSettingsProperty | undefined;
    }
    class CaptionSelectorPropertyList extends cdktn.ComplexList {
        internalValue?: CaptionSelectorProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CaptionSelectorPropertyOutputReference;
    }
    interface HlsInputSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#bandwidth AwsChannel#bandwidth}
        */
        readonly bandwidth?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#buffer_segments AwsChannel#buffer_segments}
        */
        readonly bufferSegments?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#retries AwsChannel#retries}
        */
        readonly retries?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#retry_interval AwsChannel#retry_interval}
        */
        readonly retryInterval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#scte35_source AwsChannel#scte35_source}
        */
        readonly scte35Source?: string;
    }
    class HlsInputSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HlsInputSettingsProperty | undefined;
        set internalValue(value: HlsInputSettingsProperty | undefined);
        private _bandwidth?;
        get bandwidth(): number;
        set bandwidth(value: number);
        resetBandwidth(): void;
        get bandwidthInput(): number | undefined;
        private _bufferSegments?;
        get bufferSegments(): number;
        set bufferSegments(value: number);
        resetBufferSegments(): void;
        get bufferSegmentsInput(): number | undefined;
        private _retries?;
        get retries(): number;
        set retries(value: number);
        resetRetries(): void;
        get retriesInput(): number | undefined;
        private _retryInterval?;
        get retryInterval(): number;
        set retryInterval(value: number);
        resetRetryInterval(): void;
        get retryIntervalInput(): number | undefined;
        private _scte35Source?;
        get scte35Source(): string;
        set scte35Source(value: string);
        resetScte35Source(): void;
        get scte35SourceInput(): string | undefined;
    }
    interface NetworkInputSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#server_validation AwsChannel#server_validation}
        */
        readonly serverValidation?: string;
        /**
        * hls_input_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#hls_input_settings AwsChannel#hls_input_settings}
        */
        readonly hlsInputSettings?: HlsInputSettingsProperty;
    }
    class NetworkInputSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NetworkInputSettingsProperty | undefined;
        set internalValue(value: NetworkInputSettingsProperty | undefined);
        private _serverValidation?;
        get serverValidation(): string;
        set serverValidation(value: string);
        resetServerValidation(): void;
        get serverValidationInput(): string | undefined;
        private _hlsInputSettings;
        get hlsInputSettings(): HlsInputSettingsPropertyOutputReference;
        putHlsInputSettings(value: HlsInputSettingsProperty): void;
        resetHlsInputSettings(): void;
        get hlsInputSettingsInput(): HlsInputSettingsProperty | undefined;
    }
    interface VideoSelectorProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#color_space AwsChannel#color_space}
        */
        readonly colorSpace?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#color_space_usage AwsChannel#color_space_usage}
        */
        readonly colorSpaceUsage?: string;
    }
    class VideoSelectorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VideoSelectorProperty | undefined;
        set internalValue(value: VideoSelectorProperty | undefined);
        private _colorSpace?;
        get colorSpace(): string;
        set colorSpace(value: string);
        resetColorSpace(): void;
        get colorSpaceInput(): string | undefined;
        private _colorSpaceUsage?;
        get colorSpaceUsage(): string;
        set colorSpaceUsage(value: string);
        resetColorSpaceUsage(): void;
        get colorSpaceUsageInput(): string | undefined;
    }
    interface InputSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#deblock_filter AwsChannel#deblock_filter}
        */
        readonly deblockFilter?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#denoise_filter AwsChannel#denoise_filter}
        */
        readonly denoiseFilter?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#filter_strength AwsChannel#filter_strength}
        */
        readonly filterStrength?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#input_filter AwsChannel#input_filter}
        */
        readonly inputFilter?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#scte35_pid AwsChannel#scte35_pid}
        */
        readonly scte35Pid?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#smpte2038_data_preference AwsChannel#smpte2038_data_preference}
        */
        readonly smpte2038DataPreference?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#source_end_behavior AwsChannel#source_end_behavior}
        */
        readonly sourceEndBehavior?: string;
        /**
        * audio_selector block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#audio_selector AwsChannel#audio_selector}
        */
        readonly audioSelector?: AudioSelectorProperty[] | cdktn.IResolvable;
        /**
        * caption_selector block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#caption_selector AwsChannel#caption_selector}
        */
        readonly captionSelector?: CaptionSelectorProperty[] | cdktn.IResolvable;
        /**
        * network_input_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#network_input_settings AwsChannel#network_input_settings}
        */
        readonly networkInputSettings?: NetworkInputSettingsProperty;
        /**
        * video_selector block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#video_selector AwsChannel#video_selector}
        */
        readonly videoSelector?: VideoSelectorProperty;
    }
    class InputSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InputSettingsProperty | undefined;
        set internalValue(value: InputSettingsProperty | undefined);
        private _deblockFilter?;
        get deblockFilter(): string;
        set deblockFilter(value: string);
        resetDeblockFilter(): void;
        get deblockFilterInput(): string | undefined;
        private _denoiseFilter?;
        get denoiseFilter(): string;
        set denoiseFilter(value: string);
        resetDenoiseFilter(): void;
        get denoiseFilterInput(): string | undefined;
        private _filterStrength?;
        get filterStrength(): number;
        set filterStrength(value: number);
        resetFilterStrength(): void;
        get filterStrengthInput(): number | undefined;
        private _inputFilter?;
        get inputFilter(): string;
        set inputFilter(value: string);
        resetInputFilter(): void;
        get inputFilterInput(): string | undefined;
        private _scte35Pid?;
        get scte35Pid(): number;
        set scte35Pid(value: number);
        resetScte35Pid(): void;
        get scte35PidInput(): number | undefined;
        private _smpte2038DataPreference?;
        get smpte2038DataPreference(): string;
        set smpte2038DataPreference(value: string);
        resetSmpte2038DataPreference(): void;
        get smpte2038DataPreferenceInput(): string | undefined;
        private _sourceEndBehavior?;
        get sourceEndBehavior(): string;
        set sourceEndBehavior(value: string);
        resetSourceEndBehavior(): void;
        get sourceEndBehaviorInput(): string | undefined;
        private _audioSelector;
        get audioSelector(): AudioSelectorPropertyList;
        putAudioSelector(value: AudioSelectorProperty[] | cdktn.IResolvable): void;
        resetAudioSelector(): void;
        get audioSelectorInput(): cdktn.IResolvable | AudioSelectorProperty[] | undefined;
        private _captionSelector;
        get captionSelector(): CaptionSelectorPropertyList;
        putCaptionSelector(value: CaptionSelectorProperty[] | cdktn.IResolvable): void;
        resetCaptionSelector(): void;
        get captionSelectorInput(): cdktn.IResolvable | CaptionSelectorProperty[] | undefined;
        private _networkInputSettings;
        get networkInputSettings(): NetworkInputSettingsPropertyOutputReference;
        putNetworkInputSettings(value: NetworkInputSettingsProperty): void;
        resetNetworkInputSettings(): void;
        get networkInputSettingsInput(): NetworkInputSettingsProperty | undefined;
        private _videoSelector;
        get videoSelector(): VideoSelectorPropertyOutputReference;
        putVideoSelector(value: VideoSelectorProperty): void;
        resetVideoSelector(): void;
        get videoSelectorInput(): VideoSelectorProperty | undefined;
    }
    interface InputAttachmentsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#input_attachment_name AwsChannel#input_attachment_name}
        */
        readonly inputAttachmentName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#input_id AwsChannel#input_id}
        */
        readonly inputId: string;
        /**
        * automatic_input_failover_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#automatic_input_failover_settings AwsChannel#automatic_input_failover_settings}
        */
        readonly automaticInputFailoverSettings?: AutomaticInputFailoverSettingsProperty;
        /**
        * input_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#input_settings AwsChannel#input_settings}
        */
        readonly inputSettings?: InputSettingsProperty;
    }
    class InputAttachmentsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InputAttachmentsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InputAttachmentsProperty | cdktn.IResolvable | undefined);
        private _inputAttachmentName?;
        get inputAttachmentName(): string;
        set inputAttachmentName(value: string);
        get inputAttachmentNameInput(): string | undefined;
        private _inputId?;
        get inputId(): string;
        set inputId(value: string);
        get inputIdInput(): string | undefined;
        private _automaticInputFailoverSettings;
        get automaticInputFailoverSettings(): AutomaticInputFailoverSettingsPropertyOutputReference;
        putAutomaticInputFailoverSettings(value: AutomaticInputFailoverSettingsProperty): void;
        resetAutomaticInputFailoverSettings(): void;
        get automaticInputFailoverSettingsInput(): AutomaticInputFailoverSettingsProperty | undefined;
        private _inputSettings;
        get inputSettings(): InputSettingsPropertyOutputReference;
        putInputSettings(value: InputSettingsProperty): void;
        resetInputSettings(): void;
        get inputSettingsInput(): InputSettingsProperty | undefined;
    }
    class InputAttachmentsPropertyList extends cdktn.ComplexList {
        internalValue?: InputAttachmentsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InputAttachmentsPropertyOutputReference;
    }
    interface InputSpecificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#codec AwsChannel#codec}
        */
        readonly codec: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#input_resolution AwsChannel#input_resolution}
        */
        readonly inputResolution: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#maximum_bitrate AwsChannel#maximum_bitrate}
        */
        readonly maximumBitrate: string;
    }
    class InputSpecificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InputSpecificationProperty | undefined;
        set internalValue(value: InputSpecificationProperty | undefined);
        private _codec?;
        get codec(): string;
        set codec(value: string);
        get codecInput(): string | undefined;
        private _inputResolution?;
        get inputResolution(): string;
        set inputResolution(value: string);
        get inputResolutionInput(): string | undefined;
        private _maximumBitrate?;
        get maximumBitrate(): string;
        set maximumBitrate(value: string);
        get maximumBitrateInput(): string | undefined;
    }
    interface MaintenanceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#maintenance_day AwsChannel#maintenance_day}
        */
        readonly maintenanceDay: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#maintenance_start_time AwsChannel#maintenance_start_time}
        */
        readonly maintenanceStartTime: string;
    }
    class MaintenancePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MaintenanceProperty | undefined;
        set internalValue(value: MaintenanceProperty | undefined);
        private _maintenanceDay?;
        get maintenanceDay(): string;
        set maintenanceDay(value: string);
        get maintenanceDayInput(): string | undefined;
        private _maintenanceStartTime?;
        get maintenanceStartTime(): string;
        set maintenanceStartTime(value: string);
        get maintenanceStartTimeInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#create AwsChannel#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#delete AwsChannel#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#update AwsChannel#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface VpcProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#public_address_allocation_ids AwsChannel#public_address_allocation_ids}
        */
        readonly publicAddressAllocationIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#security_group_ids AwsChannel#security_group_ids}
        */
        readonly securityGroupIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_channel#subnet_ids AwsChannel#subnet_ids}
        */
        readonly subnetIds: string[];
    }
    class VpcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcProperty | undefined;
        set internalValue(value: VpcProperty | undefined);
        get availabilityZones(): string[];
        get networkInterfaceIds(): string[];
        private _publicAddressAllocationIds?;
        get publicAddressAllocationIds(): string[];
        set publicAddressAllocationIds(value: string[]);
        get publicAddressAllocationIdsInput(): string[] | undefined;
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        resetSecurityGroupIds(): void;
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
    }
}
