import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsMultiplexConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_multiplex#availability_zones AwsMultiplex#availability_zones}
    */
    readonly availabilityZones: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_multiplex#id AwsMultiplex#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_multiplex#name AwsMultiplex#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_multiplex#region AwsMultiplex#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_multiplex#start_multiplex AwsMultiplex#start_multiplex}
    */
    readonly startMultiplex?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_multiplex#tags AwsMultiplex#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_multiplex#tags_all AwsMultiplex#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * multiplex_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_multiplex#multiplex_settings AwsMultiplex#multiplex_settings}
    */
    readonly multiplexSettings?: AwsMultiplex.MultiplexSettingsProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_multiplex#timeouts AwsMultiplex#timeouts}
    */
    readonly timeouts?: AwsMultiplex.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_multiplex aws_medialive_multiplex}
*/
export declare class AwsMultiplex extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_medialive_multiplex";
    /**
    * Generates CDKTN code for importing a AwsMultiplex resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsMultiplex to import
    * @param importFromId The id of the existing AwsMultiplex that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_multiplex#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsMultiplex to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_multiplex aws_medialive_multiplex} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsMultiplexConfig
    */
    constructor(scope: Construct, id: string, config: AwsMultiplexConfig);
    get arn(): string;
    private _availabilityZones?;
    get availabilityZones(): string[];
    set availabilityZones(value: string[]);
    get availabilityZonesInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _startMultiplex?;
    get startMultiplex(): boolean | cdktn.IResolvable;
    set startMultiplex(value: boolean | cdktn.IResolvable);
    resetStartMultiplex(): void;
    get startMultiplexInput(): boolean | cdktn.IResolvable | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _multiplexSettings;
    get multiplexSettings(): AwsMultiplex.MultiplexSettingsPropertyOutputReference;
    putMultiplexSettings(value: AwsMultiplex.MultiplexSettingsProperty): void;
    resetMultiplexSettings(): void;
    get multiplexSettingsInput(): AwsMultiplex.MultiplexSettingsProperty | undefined;
    private _timeouts;
    get timeouts(): AwsMultiplex.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsMultiplex.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsMultiplex.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsMultiplexMultiplexSettingsPropertyToTerraform(struct?: AwsMultiplex.MultiplexSettingsPropertyOutputReference | AwsMultiplex.MultiplexSettingsProperty): any;
export declare function awsMultiplexMultiplexSettingsPropertyToHclTerraform(struct?: AwsMultiplex.MultiplexSettingsPropertyOutputReference | AwsMultiplex.MultiplexSettingsProperty): any;
export declare function awsMultiplexTimeoutsPropertyToTerraform(struct?: AwsMultiplex.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsMultiplexTimeoutsPropertyToHclTerraform(struct?: AwsMultiplex.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsMultiplex {
    interface MultiplexSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_multiplex#maximum_video_buffer_delay_milliseconds AwsMultiplex#maximum_video_buffer_delay_milliseconds}
        */
        readonly maximumVideoBufferDelayMilliseconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_multiplex#transport_stream_bitrate AwsMultiplex#transport_stream_bitrate}
        */
        readonly transportStreamBitrate: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_multiplex#transport_stream_id AwsMultiplex#transport_stream_id}
        */
        readonly transportStreamId: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_multiplex#transport_stream_reserved_bitrate AwsMultiplex#transport_stream_reserved_bitrate}
        */
        readonly transportStreamReservedBitrate?: number;
    }
    class MultiplexSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MultiplexSettingsProperty | undefined;
        set internalValue(value: MultiplexSettingsProperty | undefined);
        private _maximumVideoBufferDelayMilliseconds?;
        get maximumVideoBufferDelayMilliseconds(): number;
        set maximumVideoBufferDelayMilliseconds(value: number);
        resetMaximumVideoBufferDelayMilliseconds(): void;
        get maximumVideoBufferDelayMillisecondsInput(): number | undefined;
        private _transportStreamBitrate?;
        get transportStreamBitrate(): number;
        set transportStreamBitrate(value: number);
        get transportStreamBitrateInput(): number | undefined;
        private _transportStreamId?;
        get transportStreamId(): number;
        set transportStreamId(value: number);
        get transportStreamIdInput(): number | undefined;
        private _transportStreamReservedBitrate?;
        get transportStreamReservedBitrate(): number;
        set transportStreamReservedBitrate(value: number);
        resetTransportStreamReservedBitrate(): void;
        get transportStreamReservedBitrateInput(): number | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_multiplex#create AwsMultiplex#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_multiplex#delete AwsMultiplex#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/medialive_multiplex#update AwsMultiplex#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
