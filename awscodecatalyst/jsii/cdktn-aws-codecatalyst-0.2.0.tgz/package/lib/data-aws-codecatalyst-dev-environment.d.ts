import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfDevEnvironmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/codecatalyst_dev_environment#alias DataTfDevEnvironment#alias}
    */
    readonly alias?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/codecatalyst_dev_environment#creator_id DataTfDevEnvironment#creator_id}
    */
    readonly creatorId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/codecatalyst_dev_environment#env_id DataTfDevEnvironment#env_id}
    */
    readonly envId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/codecatalyst_dev_environment#id DataTfDevEnvironment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/codecatalyst_dev_environment#project_name DataTfDevEnvironment#project_name}
    */
    readonly projectName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/codecatalyst_dev_environment#region DataTfDevEnvironment#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/codecatalyst_dev_environment#space_name DataTfDevEnvironment#space_name}
    */
    readonly spaceName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/codecatalyst_dev_environment#tags DataTfDevEnvironment#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * repositories block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/codecatalyst_dev_environment#repositories DataTfDevEnvironment#repositories}
    */
    readonly repositories?: DataTfDevEnvironment.RepositoriesProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/codecatalyst_dev_environment aws_codecatalyst_dev_environment}
*/
export declare class DataTfDevEnvironment extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_codecatalyst_dev_environment";
    /**
    * Generates CDKTN code for importing a DataTfDevEnvironment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfDevEnvironment to import
    * @param importFromId The id of the existing DataTfDevEnvironment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/codecatalyst_dev_environment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfDevEnvironment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/codecatalyst_dev_environment aws_codecatalyst_dev_environment} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfDevEnvironmentConfig
    */
    constructor(scope: Construct, id: string, config: DataTfDevEnvironmentConfig);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _creatorId?;
    get creatorId(): string;
    set creatorId(value: string);
    resetCreatorId(): void;
    get creatorIdInput(): string | undefined;
    private _envId?;
    get envId(): string;
    set envId(value: string);
    get envIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ides;
    get ides(): DataTfDevEnvironment.IdesPropertyList;
    get inactivityTimeoutMinutes(): number;
    get instanceType(): string;
    get lastUpdatedTime(): string;
    private _persistentStorage;
    get persistentStorage(): DataTfDevEnvironment.PersistentStoragePropertyList;
    private _projectName?;
    get projectName(): string;
    set projectName(value: string);
    get projectNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _spaceName?;
    get spaceName(): string;
    set spaceName(value: string);
    get spaceNameInput(): string | undefined;
    get status(): string;
    get statusReason(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _repositories;
    get repositories(): DataTfDevEnvironment.RepositoriesPropertyList;
    putRepositories(value: DataTfDevEnvironment.RepositoriesProperty[] | cdktn.IResolvable): void;
    resetRepositories(): void;
    get repositoriesInput(): cdktn.IResolvable | DataTfDevEnvironment.RepositoriesProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfDevEnvironmentIdesPropertyToTerraform(struct?: DataTfDevEnvironment.IdesProperty): any;
export declare function dataTfDevEnvironmentIdesPropertyToHclTerraform(struct?: DataTfDevEnvironment.IdesProperty): any;
export declare function dataTfDevEnvironmentPersistentStoragePropertyToTerraform(struct?: DataTfDevEnvironment.PersistentStorageProperty): any;
export declare function dataTfDevEnvironmentPersistentStoragePropertyToHclTerraform(struct?: DataTfDevEnvironment.PersistentStorageProperty): any;
export declare function dataTfDevEnvironmentRepositoriesPropertyToTerraform(struct?: DataTfDevEnvironment.RepositoriesProperty | cdktn.IResolvable): any;
export declare function dataTfDevEnvironmentRepositoriesPropertyToHclTerraform(struct?: DataTfDevEnvironment.RepositoriesProperty | cdktn.IResolvable): any;
export declare namespace DataTfDevEnvironment {
    interface IdesProperty {
    }
    class IdesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IdesProperty | undefined;
        set internalValue(value: IdesProperty | undefined);
        get name(): string;
        get runtime(): string;
    }
    class IdesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IdesPropertyOutputReference;
    }
    interface PersistentStorageProperty {
    }
    class PersistentStoragePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PersistentStorageProperty | undefined;
        set internalValue(value: PersistentStorageProperty | undefined);
        get size(): number;
    }
    class PersistentStoragePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PersistentStoragePropertyOutputReference;
    }
    interface RepositoriesProperty {
    }
    class RepositoriesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RepositoriesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RepositoriesProperty | cdktn.IResolvable | undefined);
        get branchName(): string;
        get repositoryName(): string;
    }
    class RepositoriesPropertyList extends cdktn.ComplexList {
        internalValue?: RepositoriesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RepositoriesPropertyOutputReference;
    }
}
