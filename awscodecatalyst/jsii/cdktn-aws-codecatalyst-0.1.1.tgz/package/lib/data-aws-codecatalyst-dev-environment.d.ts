import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsCodecatalystDevEnvironmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/codecatalyst_dev_environment#alias DataAwsCodecatalystDevEnvironment#alias}
    */
    readonly alias?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/codecatalyst_dev_environment#creator_id DataAwsCodecatalystDevEnvironment#creator_id}
    */
    readonly creatorId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/codecatalyst_dev_environment#env_id DataAwsCodecatalystDevEnvironment#env_id}
    */
    readonly envId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/codecatalyst_dev_environment#id DataAwsCodecatalystDevEnvironment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/codecatalyst_dev_environment#project_name DataAwsCodecatalystDevEnvironment#project_name}
    */
    readonly projectName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/codecatalyst_dev_environment#region DataAwsCodecatalystDevEnvironment#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/codecatalyst_dev_environment#space_name DataAwsCodecatalystDevEnvironment#space_name}
    */
    readonly spaceName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/codecatalyst_dev_environment#tags DataAwsCodecatalystDevEnvironment#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * repositories block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/codecatalyst_dev_environment#repositories DataAwsCodecatalystDevEnvironment#repositories}
    */
    readonly repositories?: DataAwsCodecatalystDevEnvironment.RepositoriesProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/codecatalyst_dev_environment aws_codecatalyst_dev_environment}
*/
export declare class DataAwsCodecatalystDevEnvironment extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_codecatalyst_dev_environment";
    /**
    * Generates CDKTN code for importing a DataAwsCodecatalystDevEnvironment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsCodecatalystDevEnvironment to import
    * @param importFromId The id of the existing DataAwsCodecatalystDevEnvironment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/codecatalyst_dev_environment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsCodecatalystDevEnvironment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/codecatalyst_dev_environment aws_codecatalyst_dev_environment} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsCodecatalystDevEnvironmentConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsCodecatalystDevEnvironmentConfig);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    private _creatorId?;
    get creatorId(): string;
    set creatorId(value: string);
    resetCreatorId(): void;
    get creatorIdInput(): string | undefined;
    private _envId?;
    get envId(): string;
    set envId(value: string);
    get envIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ides;
    get ides(): DataAwsCodecatalystDevEnvironment.IdesPropertyList;
    get inactivityTimeoutMinutes(): number;
    get instanceType(): string;
    get lastUpdatedTime(): string;
    private _persistentStorage;
    get persistentStorage(): DataAwsCodecatalystDevEnvironment.PersistentStoragePropertyList;
    private _projectName?;
    get projectName(): string;
    set projectName(value: string);
    get projectNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _spaceName?;
    get spaceName(): string;
    set spaceName(value: string);
    get spaceNameInput(): string | undefined;
    get status(): string;
    get statusReason(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _repositories;
    get repositories(): DataAwsCodecatalystDevEnvironment.RepositoriesPropertyList;
    putRepositories(value: DataAwsCodecatalystDevEnvironment.RepositoriesProperty[] | cdktn.IResolvable): void;
    resetRepositories(): void;
    get repositoriesInput(): cdktn.IResolvable | DataAwsCodecatalystDevEnvironment.RepositoriesProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsCodecatalystDevEnvironmentIdesPropertyToTerraform(struct?: DataAwsCodecatalystDevEnvironment.IdesProperty): any;
export declare function dataAwsCodecatalystDevEnvironmentIdesPropertyToHclTerraform(struct?: DataAwsCodecatalystDevEnvironment.IdesProperty): any;
export declare function dataAwsCodecatalystDevEnvironmentPersistentStoragePropertyToTerraform(struct?: DataAwsCodecatalystDevEnvironment.PersistentStorageProperty): any;
export declare function dataAwsCodecatalystDevEnvironmentPersistentStoragePropertyToHclTerraform(struct?: DataAwsCodecatalystDevEnvironment.PersistentStorageProperty): any;
export declare function dataAwsCodecatalystDevEnvironmentRepositoriesPropertyToTerraform(struct?: DataAwsCodecatalystDevEnvironment.RepositoriesProperty | cdktn.IResolvable): any;
export declare function dataAwsCodecatalystDevEnvironmentRepositoriesPropertyToHclTerraform(struct?: DataAwsCodecatalystDevEnvironment.RepositoriesProperty | cdktn.IResolvable): any;
export declare namespace DataAwsCodecatalystDevEnvironment {
    interface IdesProperty {
    }
    class IdesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IdesProperty | undefined;
        set internalValue(value: IdesProperty | undefined);
        get name(): string;
        get runtime(): string;
    }
    class IdesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IdesPropertyOutputReference;
    }
    interface PersistentStorageProperty {
    }
    class PersistentStoragePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PersistentStorageProperty | undefined;
        set internalValue(value: PersistentStorageProperty | undefined);
        get size(): number;
    }
    class PersistentStoragePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PersistentStoragePropertyOutputReference;
    }
    interface RepositoriesProperty {
    }
    class RepositoriesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RepositoriesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RepositoriesProperty | cdktn.IResolvable | undefined);
        get branchName(): string;
        get repositoryName(): string;
    }
    class RepositoriesPropertyList extends cdktn.ComplexList {
        internalValue?: RepositoriesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RepositoriesPropertyOutputReference;
    }
}
