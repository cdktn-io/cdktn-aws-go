import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsVpcIpamConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc_ipam#id DataAwsVpcIpam#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc_ipam#region DataAwsVpcIpam#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc_ipam aws_vpc_ipam}
*/
export declare class DataAwsVpcIpam extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_vpc_ipam";
    /**
    * Generates CDKTN code for importing a DataAwsVpcIpam resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsVpcIpam to import
    * @param importFromId The id of the existing DataAwsVpcIpam that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc_ipam#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsVpcIpam to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc_ipam aws_vpc_ipam} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsVpcIpamConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsVpcIpamConfig);
    get arn(): string;
    get defaultResourceDiscoveryAssociationId(): string;
    get defaultResourceDiscoveryId(): string;
    get description(): string;
    get enablePrivateGua(): cdktn.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get ipamRegion(): string;
    get meteredAccount(): string;
    private _operatingRegions;
    get operatingRegions(): DataAwsVpcIpam.OperatingRegionsPropertyList;
    get ownerId(): string;
    get privateDefaultScopeId(): string;
    get publicDefaultScopeId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get resourceDiscoveryAssociationCount(): number;
    get scopeCount(): number;
    get state(): string;
    get stateMessage(): string;
    private _tags;
    get tags(): cdktn.StringMap;
    get tier(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsVpcIpamOperatingRegionsPropertyToTerraform(struct?: DataAwsVpcIpam.OperatingRegionsProperty): any;
export declare function dataAwsVpcIpamOperatingRegionsPropertyToHclTerraform(struct?: DataAwsVpcIpam.OperatingRegionsProperty): any;
export declare namespace DataAwsVpcIpam {
    interface OperatingRegionsProperty {
    }
    class OperatingRegionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OperatingRegionsProperty | undefined;
        set internalValue(value: OperatingRegionsProperty | undefined);
        get regionName(): string;
    }
    class OperatingRegionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OperatingRegionsPropertyOutputReference;
    }
}
