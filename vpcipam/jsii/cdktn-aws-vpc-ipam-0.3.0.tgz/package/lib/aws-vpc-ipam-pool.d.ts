import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsPoolConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool#address_family AwsPool#address_family}
    */
    readonly addressFamily: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool#allocation_default_netmask_length AwsPool#allocation_default_netmask_length}
    */
    readonly allocationDefaultNetmaskLength?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool#allocation_max_netmask_length AwsPool#allocation_max_netmask_length}
    */
    readonly allocationMaxNetmaskLength?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool#allocation_min_netmask_length AwsPool#allocation_min_netmask_length}
    */
    readonly allocationMinNetmaskLength?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool#allocation_resource_tags AwsPool#allocation_resource_tags}
    */
    readonly allocationResourceTags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool#auto_import AwsPool#auto_import}
    */
    readonly autoImport?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool#aws_service AwsPool#aws_service}
    */
    readonly awsService?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool#cascade AwsPool#cascade}
    */
    readonly cascade?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool#description AwsPool#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool#id AwsPool#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool#ipam_scope_id AwsPool#ipam_scope_id}
    */
    readonly ipamScopeId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool#locale AwsPool#locale}
    */
    readonly locale?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool#public_ip_source AwsPool#public_ip_source}
    */
    readonly publicIpSource?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool#publicly_advertisable AwsPool#publicly_advertisable}
    */
    readonly publiclyAdvertisable?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool#region AwsPool#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool#source_ipam_pool_id AwsPool#source_ipam_pool_id}
    */
    readonly sourceIpamPoolId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool#tags AwsPool#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool#tags_all AwsPool#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * source_resource block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool#source_resource AwsPool#source_resource}
    */
    readonly sourceResource?: AwsPool.SourceResourceProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool#timeouts AwsPool#timeouts}
    */
    readonly timeouts?: AwsPool.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool aws_vpc_ipam_pool}
*/
export declare class AwsPool extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_vpc_ipam_pool";
    /**
    * Generates CDKTN code for importing a AwsPool resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsPool to import
    * @param importFromId The id of the existing AwsPool that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsPool to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool aws_vpc_ipam_pool} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsPoolConfig
    */
    constructor(scope: Construct, id: string, config: AwsPoolConfig);
    private _addressFamily?;
    get addressFamily(): string;
    set addressFamily(value: string);
    get addressFamilyInput(): string | undefined;
    private _allocationDefaultNetmaskLength?;
    get allocationDefaultNetmaskLength(): number;
    set allocationDefaultNetmaskLength(value: number);
    resetAllocationDefaultNetmaskLength(): void;
    get allocationDefaultNetmaskLengthInput(): number | undefined;
    private _allocationMaxNetmaskLength?;
    get allocationMaxNetmaskLength(): number;
    set allocationMaxNetmaskLength(value: number);
    resetAllocationMaxNetmaskLength(): void;
    get allocationMaxNetmaskLengthInput(): number | undefined;
    private _allocationMinNetmaskLength?;
    get allocationMinNetmaskLength(): number;
    set allocationMinNetmaskLength(value: number);
    resetAllocationMinNetmaskLength(): void;
    get allocationMinNetmaskLengthInput(): number | undefined;
    private _allocationResourceTags?;
    get allocationResourceTags(): {
        [key: string]: string;
    };
    set allocationResourceTags(value: {
        [key: string]: string;
    });
    resetAllocationResourceTags(): void;
    get allocationResourceTagsInput(): {
        [key: string]: string;
    } | undefined;
    get arn(): string;
    private _autoImport?;
    get autoImport(): boolean | cdktn.IResolvable;
    set autoImport(value: boolean | cdktn.IResolvable);
    resetAutoImport(): void;
    get autoImportInput(): boolean | cdktn.IResolvable | undefined;
    private _awsService?;
    get awsService(): string;
    set awsService(value: string);
    resetAwsService(): void;
    get awsServiceInput(): string | undefined;
    private _cascade?;
    get cascade(): boolean | cdktn.IResolvable;
    set cascade(value: boolean | cdktn.IResolvable);
    resetCascade(): void;
    get cascadeInput(): boolean | cdktn.IResolvable | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipamScopeId?;
    get ipamScopeId(): string;
    set ipamScopeId(value: string);
    get ipamScopeIdInput(): string | undefined;
    get ipamScopeType(): string;
    private _locale?;
    get locale(): string;
    set locale(value: string);
    resetLocale(): void;
    get localeInput(): string | undefined;
    get poolDepth(): number;
    private _publicIpSource?;
    get publicIpSource(): string;
    set publicIpSource(value: string);
    resetPublicIpSource(): void;
    get publicIpSourceInput(): string | undefined;
    private _publiclyAdvertisable?;
    get publiclyAdvertisable(): boolean | cdktn.IResolvable;
    set publiclyAdvertisable(value: boolean | cdktn.IResolvable);
    resetPubliclyAdvertisable(): void;
    get publiclyAdvertisableInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _sourceIpamPoolId?;
    get sourceIpamPoolId(): string;
    set sourceIpamPoolId(value: string);
    resetSourceIpamPoolId(): void;
    get sourceIpamPoolIdInput(): string | undefined;
    get state(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _sourceResource;
    get sourceResource(): AwsPool.SourceResourcePropertyOutputReference;
    putSourceResource(value: AwsPool.SourceResourceProperty): void;
    resetSourceResource(): void;
    get sourceResourceInput(): AwsPool.SourceResourceProperty | undefined;
    private _timeouts;
    get timeouts(): AwsPool.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsPool.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsPool.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsPoolSourceResourcePropertyToTerraform(struct?: AwsPool.SourceResourcePropertyOutputReference | AwsPool.SourceResourceProperty): any;
export declare function awsPoolSourceResourcePropertyToHclTerraform(struct?: AwsPool.SourceResourcePropertyOutputReference | AwsPool.SourceResourceProperty): any;
export declare function awsPoolTimeoutsPropertyToTerraform(struct?: AwsPool.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsPoolTimeoutsPropertyToHclTerraform(struct?: AwsPool.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsPool {
    interface SourceResourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool#resource_id AwsPool#resource_id}
        */
        readonly resourceId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool#resource_owner AwsPool#resource_owner}
        */
        readonly resourceOwner: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool#resource_region AwsPool#resource_region}
        */
        readonly resourceRegion: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool#resource_type AwsPool#resource_type}
        */
        readonly resourceType: string;
    }
    class SourceResourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceResourceProperty | undefined;
        set internalValue(value: SourceResourceProperty | undefined);
        private _resourceId?;
        get resourceId(): string;
        set resourceId(value: string);
        get resourceIdInput(): string | undefined;
        private _resourceOwner?;
        get resourceOwner(): string;
        set resourceOwner(value: string);
        get resourceOwnerInput(): string | undefined;
        private _resourceRegion?;
        get resourceRegion(): string;
        set resourceRegion(value: string);
        get resourceRegionInput(): string | undefined;
        private _resourceType?;
        get resourceType(): string;
        set resourceType(value: string);
        get resourceTypeInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool#create AwsPool#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool#delete AwsPool#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool#update AwsPool#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
