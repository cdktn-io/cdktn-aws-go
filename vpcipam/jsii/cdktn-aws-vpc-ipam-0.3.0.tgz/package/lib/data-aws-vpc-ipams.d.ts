import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsVpcIpamsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc_ipams#ipam_ids DataAwsVpcIpams#ipam_ids}
    */
    readonly ipamIds?: string[];
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc_ipams#region DataAwsVpcIpams#region}
    */
    readonly region?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc_ipams#filter DataAwsVpcIpams#filter}
    */
    readonly filter?: DataAwsVpcIpams.FilterProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc_ipams aws_vpc_ipams}
*/
export declare class DataAwsVpcIpams extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_vpc_ipams";
    /**
    * Generates CDKTN code for importing a DataAwsVpcIpams resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsVpcIpams to import
    * @param importFromId The id of the existing DataAwsVpcIpams that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc_ipams#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsVpcIpams to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc_ipams aws_vpc_ipams} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsVpcIpamsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsVpcIpamsConfig);
    private _ipamIds?;
    get ipamIds(): string[];
    set ipamIds(value: string[]);
    resetIpamIds(): void;
    get ipamIdsInput(): string[] | undefined;
    private _ipams;
    get ipams(): DataAwsVpcIpams.IpamsPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _filter;
    get filter(): DataAwsVpcIpams.FilterPropertyList;
    putFilter(value: DataAwsVpcIpams.FilterProperty[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataAwsVpcIpams.FilterProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsVpcIpamsOperatingRegionsPropertyToTerraform(struct?: DataAwsVpcIpams.OperatingRegionsProperty): any;
export declare function dataAwsVpcIpamsOperatingRegionsPropertyToHclTerraform(struct?: DataAwsVpcIpams.OperatingRegionsProperty): any;
export declare function dataAwsVpcIpamsIpamsPropertyToTerraform(struct?: DataAwsVpcIpams.IpamsProperty): any;
export declare function dataAwsVpcIpamsIpamsPropertyToHclTerraform(struct?: DataAwsVpcIpams.IpamsProperty): any;
export declare function dataAwsVpcIpamsFilterPropertyToTerraform(struct?: DataAwsVpcIpams.FilterProperty | cdktn.IResolvable): any;
export declare function dataAwsVpcIpamsFilterPropertyToHclTerraform(struct?: DataAwsVpcIpams.FilterProperty | cdktn.IResolvable): any;
export declare namespace DataAwsVpcIpams {
    interface OperatingRegionsProperty {
    }
    class OperatingRegionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OperatingRegionsProperty | undefined;
        set internalValue(value: OperatingRegionsProperty | undefined);
        get regionName(): string;
    }
    class OperatingRegionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OperatingRegionsPropertyOutputReference;
    }
    interface IpamsProperty {
    }
    class IpamsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IpamsProperty | undefined;
        set internalValue(value: IpamsProperty | undefined);
        get arn(): string;
        get defaultResourceDiscoveryAssociationId(): string;
        get defaultResourceDiscoveryId(): string;
        get description(): string;
        get enablePrivateGua(): cdktn.IResolvable;
        get id(): string;
        get ipamRegion(): string;
        get meteredAccount(): string;
        private _operatingRegions;
        get operatingRegions(): OperatingRegionsPropertyList;
        get ownerId(): string;
        get privateDefaultScopeId(): string;
        get publicDefaultScopeId(): string;
        get resourceDiscoveryAssociationCount(): number;
        get scopeCount(): number;
        get state(): string;
        get stateMessage(): string;
        get tier(): string;
    }
    class IpamsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IpamsPropertyOutputReference;
    }
    interface FilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc_ipams#name DataAwsVpcIpams#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/vpc_ipams#values DataAwsVpcIpams#values}
        */
        readonly values: string[];
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class FilterPropertyList extends cdktn.ComplexList {
        internalValue?: FilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterPropertyOutputReference;
    }
}
