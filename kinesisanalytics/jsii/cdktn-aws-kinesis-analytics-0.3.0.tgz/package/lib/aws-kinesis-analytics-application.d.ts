import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsApplicationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#code AwsApplication#code}
    */
    readonly code?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#description AwsApplication#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#id AwsApplication#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#name AwsApplication#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#region AwsApplication#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#start_application AwsApplication#start_application}
    */
    readonly startApplication?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#tags AwsApplication#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#tags_all AwsApplication#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * cloudwatch_logging_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#cloudwatch_logging_options AwsApplication#cloudwatch_logging_options}
    */
    readonly cloudwatchLoggingOptions?: AwsApplication.CloudwatchLoggingOptionsProperty;
    /**
    * inputs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#inputs AwsApplication#inputs}
    */
    readonly inputs?: AwsApplication.InputsProperty;
    /**
    * outputs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#outputs AwsApplication#outputs}
    */
    readonly outputs?: AwsApplication.OutputsProperty[] | cdktn.IResolvable;
    /**
    * reference_data_sources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#reference_data_sources AwsApplication#reference_data_sources}
    */
    readonly referenceDataSources?: AwsApplication.ReferenceDataSourcesProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application aws_kinesis_analytics_application}
*/
export declare class AwsApplication extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_kinesis_analytics_application";
    /**
    * Generates CDKTN code for importing a AwsApplication resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsApplication to import
    * @param importFromId The id of the existing AwsApplication that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsApplication to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application aws_kinesis_analytics_application} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsApplicationConfig
    */
    constructor(scope: Construct, id: string, config: AwsApplicationConfig);
    get arn(): string;
    private _code?;
    get code(): string;
    set code(value: string);
    resetCode(): void;
    get codeInput(): string | undefined;
    get createTimestamp(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastUpdateTimestamp(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _startApplication?;
    get startApplication(): boolean | cdktn.IResolvable;
    set startApplication(value: boolean | cdktn.IResolvable);
    resetStartApplication(): void;
    get startApplicationInput(): boolean | cdktn.IResolvable | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get version(): number;
    private _cloudwatchLoggingOptions;
    get cloudwatchLoggingOptions(): AwsApplication.CloudwatchLoggingOptionsPropertyOutputReference;
    putCloudwatchLoggingOptions(value: AwsApplication.CloudwatchLoggingOptionsProperty): void;
    resetCloudwatchLoggingOptions(): void;
    get cloudwatchLoggingOptionsInput(): AwsApplication.CloudwatchLoggingOptionsProperty | undefined;
    private _inputs;
    get inputs(): AwsApplication.InputsPropertyOutputReference;
    putInputs(value: AwsApplication.InputsProperty): void;
    resetInputs(): void;
    get inputsInput(): AwsApplication.InputsProperty | undefined;
    private _outputs;
    get outputs(): AwsApplication.OutputsPropertyList;
    putOutputs(value: AwsApplication.OutputsProperty[] | cdktn.IResolvable): void;
    resetOutputs(): void;
    get outputsInput(): cdktn.IResolvable | AwsApplication.OutputsProperty[] | undefined;
    private _referenceDataSources;
    get referenceDataSources(): AwsApplication.ReferenceDataSourcesPropertyOutputReference;
    putReferenceDataSources(value: AwsApplication.ReferenceDataSourcesProperty): void;
    resetReferenceDataSources(): void;
    get referenceDataSourcesInput(): AwsApplication.ReferenceDataSourcesProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsApplicationCloudwatchLoggingOptionsPropertyToTerraform(struct?: AwsApplication.CloudwatchLoggingOptionsPropertyOutputReference | AwsApplication.CloudwatchLoggingOptionsProperty): any;
export declare function awsApplicationCloudwatchLoggingOptionsPropertyToHclTerraform(struct?: AwsApplication.CloudwatchLoggingOptionsPropertyOutputReference | AwsApplication.CloudwatchLoggingOptionsProperty): any;
export declare function awsApplicationInputsKinesisFirehosePropertyToTerraform(struct?: AwsApplication.InputsKinesisFirehosePropertyOutputReference | AwsApplication.InputsKinesisFirehoseProperty): any;
export declare function awsApplicationInputsKinesisFirehosePropertyToHclTerraform(struct?: AwsApplication.InputsKinesisFirehosePropertyOutputReference | AwsApplication.InputsKinesisFirehoseProperty): any;
export declare function awsApplicationInputsKinesisStreamPropertyToTerraform(struct?: AwsApplication.InputsKinesisStreamPropertyOutputReference | AwsApplication.InputsKinesisStreamProperty): any;
export declare function awsApplicationInputsKinesisStreamPropertyToHclTerraform(struct?: AwsApplication.InputsKinesisStreamPropertyOutputReference | AwsApplication.InputsKinesisStreamProperty): any;
export declare function awsApplicationParallelismPropertyToTerraform(struct?: AwsApplication.ParallelismPropertyOutputReference | AwsApplication.ParallelismProperty): any;
export declare function awsApplicationParallelismPropertyToHclTerraform(struct?: AwsApplication.ParallelismPropertyOutputReference | AwsApplication.ParallelismProperty): any;
export declare function awsApplicationInputsProcessingConfigurationLambdaPropertyToTerraform(struct?: AwsApplication.InputsProcessingConfigurationLambdaPropertyOutputReference | AwsApplication.InputsProcessingConfigurationLambdaProperty): any;
export declare function awsApplicationInputsProcessingConfigurationLambdaPropertyToHclTerraform(struct?: AwsApplication.InputsProcessingConfigurationLambdaPropertyOutputReference | AwsApplication.InputsProcessingConfigurationLambdaProperty): any;
export declare function awsApplicationProcessingConfigurationPropertyToTerraform(struct?: AwsApplication.ProcessingConfigurationPropertyOutputReference | AwsApplication.ProcessingConfigurationProperty): any;
export declare function awsApplicationProcessingConfigurationPropertyToHclTerraform(struct?: AwsApplication.ProcessingConfigurationPropertyOutputReference | AwsApplication.ProcessingConfigurationProperty): any;
export declare function awsApplicationInputsSchemaRecordColumnsPropertyToTerraform(struct?: AwsApplication.InputsSchemaRecordColumnsProperty | cdktn.IResolvable): any;
export declare function awsApplicationInputsSchemaRecordColumnsPropertyToHclTerraform(struct?: AwsApplication.InputsSchemaRecordColumnsProperty | cdktn.IResolvable): any;
export declare function awsApplicationInputsSchemaRecordFormatMappingParametersCsvPropertyToTerraform(struct?: AwsApplication.InputsSchemaRecordFormatMappingParametersCsvPropertyOutputReference | AwsApplication.InputsSchemaRecordFormatMappingParametersCsvProperty): any;
export declare function awsApplicationInputsSchemaRecordFormatMappingParametersCsvPropertyToHclTerraform(struct?: AwsApplication.InputsSchemaRecordFormatMappingParametersCsvPropertyOutputReference | AwsApplication.InputsSchemaRecordFormatMappingParametersCsvProperty): any;
export declare function awsApplicationInputsSchemaRecordFormatMappingParametersJsonPropertyToTerraform(struct?: AwsApplication.InputsSchemaRecordFormatMappingParametersJsonPropertyOutputReference | AwsApplication.InputsSchemaRecordFormatMappingParametersJsonProperty): any;
export declare function awsApplicationInputsSchemaRecordFormatMappingParametersJsonPropertyToHclTerraform(struct?: AwsApplication.InputsSchemaRecordFormatMappingParametersJsonPropertyOutputReference | AwsApplication.InputsSchemaRecordFormatMappingParametersJsonProperty): any;
export declare function awsApplicationInputsSchemaRecordFormatMappingParametersPropertyToTerraform(struct?: AwsApplication.InputsSchemaRecordFormatMappingParametersPropertyOutputReference | AwsApplication.InputsSchemaRecordFormatMappingParametersProperty): any;
export declare function awsApplicationInputsSchemaRecordFormatMappingParametersPropertyToHclTerraform(struct?: AwsApplication.InputsSchemaRecordFormatMappingParametersPropertyOutputReference | AwsApplication.InputsSchemaRecordFormatMappingParametersProperty): any;
export declare function awsApplicationInputsSchemaRecordFormatPropertyToTerraform(struct?: AwsApplication.InputsSchemaRecordFormatPropertyOutputReference | AwsApplication.InputsSchemaRecordFormatProperty): any;
export declare function awsApplicationInputsSchemaRecordFormatPropertyToHclTerraform(struct?: AwsApplication.InputsSchemaRecordFormatPropertyOutputReference | AwsApplication.InputsSchemaRecordFormatProperty): any;
export declare function awsApplicationInputsSchemaPropertyToTerraform(struct?: AwsApplication.InputsSchemaPropertyOutputReference | AwsApplication.InputsSchemaProperty): any;
export declare function awsApplicationInputsSchemaPropertyToHclTerraform(struct?: AwsApplication.InputsSchemaPropertyOutputReference | AwsApplication.InputsSchemaProperty): any;
export declare function awsApplicationStartingPositionConfigurationPropertyToTerraform(struct?: AwsApplication.StartingPositionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsApplicationStartingPositionConfigurationPropertyToHclTerraform(struct?: AwsApplication.StartingPositionConfigurationProperty | cdktn.IResolvable): any;
export declare function awsApplicationInputsPropertyToTerraform(struct?: AwsApplication.InputsPropertyOutputReference | AwsApplication.InputsProperty): any;
export declare function awsApplicationInputsPropertyToHclTerraform(struct?: AwsApplication.InputsPropertyOutputReference | AwsApplication.InputsProperty): any;
export declare function awsApplicationOutputsKinesisFirehosePropertyToTerraform(struct?: AwsApplication.OutputsKinesisFirehosePropertyOutputReference | AwsApplication.OutputsKinesisFirehoseProperty): any;
export declare function awsApplicationOutputsKinesisFirehosePropertyToHclTerraform(struct?: AwsApplication.OutputsKinesisFirehosePropertyOutputReference | AwsApplication.OutputsKinesisFirehoseProperty): any;
export declare function awsApplicationOutputsKinesisStreamPropertyToTerraform(struct?: AwsApplication.OutputsKinesisStreamPropertyOutputReference | AwsApplication.OutputsKinesisStreamProperty): any;
export declare function awsApplicationOutputsKinesisStreamPropertyToHclTerraform(struct?: AwsApplication.OutputsKinesisStreamPropertyOutputReference | AwsApplication.OutputsKinesisStreamProperty): any;
export declare function awsApplicationOutputsLambdaPropertyToTerraform(struct?: AwsApplication.OutputsLambdaPropertyOutputReference | AwsApplication.OutputsLambdaProperty): any;
export declare function awsApplicationOutputsLambdaPropertyToHclTerraform(struct?: AwsApplication.OutputsLambdaPropertyOutputReference | AwsApplication.OutputsLambdaProperty): any;
export declare function awsApplicationOutputsSchemaPropertyToTerraform(struct?: AwsApplication.OutputsSchemaPropertyOutputReference | AwsApplication.OutputsSchemaProperty): any;
export declare function awsApplicationOutputsSchemaPropertyToHclTerraform(struct?: AwsApplication.OutputsSchemaPropertyOutputReference | AwsApplication.OutputsSchemaProperty): any;
export declare function awsApplicationOutputsPropertyToTerraform(struct?: AwsApplication.OutputsProperty | cdktn.IResolvable): any;
export declare function awsApplicationOutputsPropertyToHclTerraform(struct?: AwsApplication.OutputsProperty | cdktn.IResolvable): any;
export declare function awsApplicationS3PropertyToTerraform(struct?: AwsApplication.S3PropertyOutputReference | AwsApplication.S3Property): any;
export declare function awsApplicationS3PropertyToHclTerraform(struct?: AwsApplication.S3PropertyOutputReference | AwsApplication.S3Property): any;
export declare function awsApplicationReferenceDataSourcesSchemaRecordColumnsPropertyToTerraform(struct?: AwsApplication.ReferenceDataSourcesSchemaRecordColumnsProperty | cdktn.IResolvable): any;
export declare function awsApplicationReferenceDataSourcesSchemaRecordColumnsPropertyToHclTerraform(struct?: AwsApplication.ReferenceDataSourcesSchemaRecordColumnsProperty | cdktn.IResolvable): any;
export declare function awsApplicationReferenceDataSourcesSchemaRecordFormatMappingParametersCsvPropertyToTerraform(struct?: AwsApplication.ReferenceDataSourcesSchemaRecordFormatMappingParametersCsvPropertyOutputReference | AwsApplication.ReferenceDataSourcesSchemaRecordFormatMappingParametersCsvProperty): any;
export declare function awsApplicationReferenceDataSourcesSchemaRecordFormatMappingParametersCsvPropertyToHclTerraform(struct?: AwsApplication.ReferenceDataSourcesSchemaRecordFormatMappingParametersCsvPropertyOutputReference | AwsApplication.ReferenceDataSourcesSchemaRecordFormatMappingParametersCsvProperty): any;
export declare function awsApplicationReferenceDataSourcesSchemaRecordFormatMappingParametersJsonPropertyToTerraform(struct?: AwsApplication.ReferenceDataSourcesSchemaRecordFormatMappingParametersJsonPropertyOutputReference | AwsApplication.ReferenceDataSourcesSchemaRecordFormatMappingParametersJsonProperty): any;
export declare function awsApplicationReferenceDataSourcesSchemaRecordFormatMappingParametersJsonPropertyToHclTerraform(struct?: AwsApplication.ReferenceDataSourcesSchemaRecordFormatMappingParametersJsonPropertyOutputReference | AwsApplication.ReferenceDataSourcesSchemaRecordFormatMappingParametersJsonProperty): any;
export declare function awsApplicationReferenceDataSourcesSchemaRecordFormatMappingParametersPropertyToTerraform(struct?: AwsApplication.ReferenceDataSourcesSchemaRecordFormatMappingParametersPropertyOutputReference | AwsApplication.ReferenceDataSourcesSchemaRecordFormatMappingParametersProperty): any;
export declare function awsApplicationReferenceDataSourcesSchemaRecordFormatMappingParametersPropertyToHclTerraform(struct?: AwsApplication.ReferenceDataSourcesSchemaRecordFormatMappingParametersPropertyOutputReference | AwsApplication.ReferenceDataSourcesSchemaRecordFormatMappingParametersProperty): any;
export declare function awsApplicationReferenceDataSourcesSchemaRecordFormatPropertyToTerraform(struct?: AwsApplication.ReferenceDataSourcesSchemaRecordFormatPropertyOutputReference | AwsApplication.ReferenceDataSourcesSchemaRecordFormatProperty): any;
export declare function awsApplicationReferenceDataSourcesSchemaRecordFormatPropertyToHclTerraform(struct?: AwsApplication.ReferenceDataSourcesSchemaRecordFormatPropertyOutputReference | AwsApplication.ReferenceDataSourcesSchemaRecordFormatProperty): any;
export declare function awsApplicationReferenceDataSourcesSchemaPropertyToTerraform(struct?: AwsApplication.ReferenceDataSourcesSchemaPropertyOutputReference | AwsApplication.ReferenceDataSourcesSchemaProperty): any;
export declare function awsApplicationReferenceDataSourcesSchemaPropertyToHclTerraform(struct?: AwsApplication.ReferenceDataSourcesSchemaPropertyOutputReference | AwsApplication.ReferenceDataSourcesSchemaProperty): any;
export declare function awsApplicationReferenceDataSourcesPropertyToTerraform(struct?: AwsApplication.ReferenceDataSourcesPropertyOutputReference | AwsApplication.ReferenceDataSourcesProperty): any;
export declare function awsApplicationReferenceDataSourcesPropertyToHclTerraform(struct?: AwsApplication.ReferenceDataSourcesPropertyOutputReference | AwsApplication.ReferenceDataSourcesProperty): any;
export declare namespace AwsApplication {
    interface CloudwatchLoggingOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#log_stream_arn AwsApplication#log_stream_arn}
        */
        readonly logStreamArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#role_arn AwsApplication#role_arn}
        */
        readonly roleArn: string;
    }
    class CloudwatchLoggingOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CloudwatchLoggingOptionsProperty | undefined;
        set internalValue(value: CloudwatchLoggingOptionsProperty | undefined);
        get id(): string;
        private _logStreamArn?;
        get logStreamArn(): string;
        set logStreamArn(value: string);
        get logStreamArnInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
    }
    interface InputsKinesisFirehoseProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#resource_arn AwsApplication#resource_arn}
        */
        readonly resourceArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#role_arn AwsApplication#role_arn}
        */
        readonly roleArn: string;
    }
    class InputsKinesisFirehosePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InputsKinesisFirehoseProperty | undefined;
        set internalValue(value: InputsKinesisFirehoseProperty | undefined);
        private _resourceArn?;
        get resourceArn(): string;
        set resourceArn(value: string);
        get resourceArnInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
    }
    interface InputsKinesisStreamProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#resource_arn AwsApplication#resource_arn}
        */
        readonly resourceArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#role_arn AwsApplication#role_arn}
        */
        readonly roleArn: string;
    }
    class InputsKinesisStreamPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InputsKinesisStreamProperty | undefined;
        set internalValue(value: InputsKinesisStreamProperty | undefined);
        private _resourceArn?;
        get resourceArn(): string;
        set resourceArn(value: string);
        get resourceArnInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
    }
    interface ParallelismProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#count AwsApplication#count}
        */
        readonly count?: number;
    }
    class ParallelismPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ParallelismProperty | undefined;
        set internalValue(value: ParallelismProperty | undefined);
        private _count?;
        get count(): number;
        set count(value: number);
        resetCount(): void;
        get countInput(): number | undefined;
    }
    interface InputsProcessingConfigurationLambdaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#resource_arn AwsApplication#resource_arn}
        */
        readonly resourceArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#role_arn AwsApplication#role_arn}
        */
        readonly roleArn: string;
    }
    class InputsProcessingConfigurationLambdaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InputsProcessingConfigurationLambdaProperty | undefined;
        set internalValue(value: InputsProcessingConfigurationLambdaProperty | undefined);
        private _resourceArn?;
        get resourceArn(): string;
        set resourceArn(value: string);
        get resourceArnInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
    }
    interface ProcessingConfigurationProperty {
        /**
        * lambda block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#lambda AwsApplication#lambda}
        */
        readonly lambda: InputsProcessingConfigurationLambdaProperty;
    }
    class ProcessingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ProcessingConfigurationProperty | undefined;
        set internalValue(value: ProcessingConfigurationProperty | undefined);
        private _lambda;
        get lambda(): InputsProcessingConfigurationLambdaPropertyOutputReference;
        putLambda(value: InputsProcessingConfigurationLambdaProperty): void;
        get lambdaInput(): InputsProcessingConfigurationLambdaProperty | undefined;
    }
    interface InputsSchemaRecordColumnsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#mapping AwsApplication#mapping}
        */
        readonly mapping?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#name AwsApplication#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#sql_type AwsApplication#sql_type}
        */
        readonly sqlType: string;
    }
    class InputsSchemaRecordColumnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InputsSchemaRecordColumnsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InputsSchemaRecordColumnsProperty | cdktn.IResolvable | undefined);
        private _mapping?;
        get mapping(): string;
        set mapping(value: string);
        resetMapping(): void;
        get mappingInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _sqlType?;
        get sqlType(): string;
        set sqlType(value: string);
        get sqlTypeInput(): string | undefined;
    }
    class InputsSchemaRecordColumnsPropertyList extends cdktn.ComplexList {
        internalValue?: InputsSchemaRecordColumnsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InputsSchemaRecordColumnsPropertyOutputReference;
    }
    interface InputsSchemaRecordFormatMappingParametersCsvProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#record_column_delimiter AwsApplication#record_column_delimiter}
        */
        readonly recordColumnDelimiter: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#record_row_delimiter AwsApplication#record_row_delimiter}
        */
        readonly recordRowDelimiter: string;
    }
    class InputsSchemaRecordFormatMappingParametersCsvPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InputsSchemaRecordFormatMappingParametersCsvProperty | undefined;
        set internalValue(value: InputsSchemaRecordFormatMappingParametersCsvProperty | undefined);
        private _recordColumnDelimiter?;
        get recordColumnDelimiter(): string;
        set recordColumnDelimiter(value: string);
        get recordColumnDelimiterInput(): string | undefined;
        private _recordRowDelimiter?;
        get recordRowDelimiter(): string;
        set recordRowDelimiter(value: string);
        get recordRowDelimiterInput(): string | undefined;
    }
    interface InputsSchemaRecordFormatMappingParametersJsonProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#record_row_path AwsApplication#record_row_path}
        */
        readonly recordRowPath: string;
    }
    class InputsSchemaRecordFormatMappingParametersJsonPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InputsSchemaRecordFormatMappingParametersJsonProperty | undefined;
        set internalValue(value: InputsSchemaRecordFormatMappingParametersJsonProperty | undefined);
        private _recordRowPath?;
        get recordRowPath(): string;
        set recordRowPath(value: string);
        get recordRowPathInput(): string | undefined;
    }
    interface InputsSchemaRecordFormatMappingParametersProperty {
        /**
        * csv block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#csv AwsApplication#csv}
        */
        readonly csv?: InputsSchemaRecordFormatMappingParametersCsvProperty;
        /**
        * json block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#json AwsApplication#json}
        */
        readonly json?: InputsSchemaRecordFormatMappingParametersJsonProperty;
    }
    class InputsSchemaRecordFormatMappingParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InputsSchemaRecordFormatMappingParametersProperty | undefined;
        set internalValue(value: InputsSchemaRecordFormatMappingParametersProperty | undefined);
        private _csv;
        get csv(): InputsSchemaRecordFormatMappingParametersCsvPropertyOutputReference;
        putCsv(value: InputsSchemaRecordFormatMappingParametersCsvProperty): void;
        resetCsv(): void;
        get csvInput(): InputsSchemaRecordFormatMappingParametersCsvProperty | undefined;
        private _json;
        get json(): InputsSchemaRecordFormatMappingParametersJsonPropertyOutputReference;
        putJson(value: InputsSchemaRecordFormatMappingParametersJsonProperty): void;
        resetJson(): void;
        get jsonInput(): InputsSchemaRecordFormatMappingParametersJsonProperty | undefined;
    }
    interface InputsSchemaRecordFormatProperty {
        /**
        * mapping_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#mapping_parameters AwsApplication#mapping_parameters}
        */
        readonly mappingParameters?: InputsSchemaRecordFormatMappingParametersProperty;
    }
    class InputsSchemaRecordFormatPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InputsSchemaRecordFormatProperty | undefined;
        set internalValue(value: InputsSchemaRecordFormatProperty | undefined);
        get recordFormatType(): string;
        private _mappingParameters;
        get mappingParameters(): InputsSchemaRecordFormatMappingParametersPropertyOutputReference;
        putMappingParameters(value: InputsSchemaRecordFormatMappingParametersProperty): void;
        resetMappingParameters(): void;
        get mappingParametersInput(): InputsSchemaRecordFormatMappingParametersProperty | undefined;
    }
    interface InputsSchemaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#record_encoding AwsApplication#record_encoding}
        */
        readonly recordEncoding?: string;
        /**
        * record_columns block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#record_columns AwsApplication#record_columns}
        */
        readonly recordColumns: InputsSchemaRecordColumnsProperty[] | cdktn.IResolvable;
        /**
        * record_format block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#record_format AwsApplication#record_format}
        */
        readonly recordFormat: InputsSchemaRecordFormatProperty;
    }
    class InputsSchemaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InputsSchemaProperty | undefined;
        set internalValue(value: InputsSchemaProperty | undefined);
        private _recordEncoding?;
        get recordEncoding(): string;
        set recordEncoding(value: string);
        resetRecordEncoding(): void;
        get recordEncodingInput(): string | undefined;
        private _recordColumns;
        get recordColumns(): InputsSchemaRecordColumnsPropertyList;
        putRecordColumns(value: InputsSchemaRecordColumnsProperty[] | cdktn.IResolvable): void;
        get recordColumnsInput(): cdktn.IResolvable | InputsSchemaRecordColumnsProperty[] | undefined;
        private _recordFormat;
        get recordFormat(): InputsSchemaRecordFormatPropertyOutputReference;
        putRecordFormat(value: InputsSchemaRecordFormatProperty): void;
        get recordFormatInput(): InputsSchemaRecordFormatProperty | undefined;
    }
    interface StartingPositionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#starting_position AwsApplication#starting_position}
        */
        readonly startingPosition?: string;
    }
    class StartingPositionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StartingPositionConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StartingPositionConfigurationProperty | cdktn.IResolvable | undefined);
        private _startingPosition?;
        get startingPosition(): string;
        set startingPosition(value: string);
        resetStartingPosition(): void;
        get startingPositionInput(): string | undefined;
    }
    class StartingPositionConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: StartingPositionConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StartingPositionConfigurationPropertyOutputReference;
    }
    interface InputsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#name_prefix AwsApplication#name_prefix}
        */
        readonly namePrefix: string;
        /**
        * kinesis_firehose block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#kinesis_firehose AwsApplication#kinesis_firehose}
        */
        readonly kinesisFirehose?: InputsKinesisFirehoseProperty;
        /**
        * kinesis_stream block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#kinesis_stream AwsApplication#kinesis_stream}
        */
        readonly kinesisStream?: InputsKinesisStreamProperty;
        /**
        * parallelism block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#parallelism AwsApplication#parallelism}
        */
        readonly parallelism?: ParallelismProperty;
        /**
        * processing_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#processing_configuration AwsApplication#processing_configuration}
        */
        readonly processingConfiguration?: ProcessingConfigurationProperty;
        /**
        * schema block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#schema AwsApplication#schema}
        */
        readonly schema: InputsSchemaProperty;
        /**
        * starting_position_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#starting_position_configuration AwsApplication#starting_position_configuration}
        */
        readonly startingPositionConfiguration?: StartingPositionConfigurationProperty[] | cdktn.IResolvable;
    }
    class InputsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InputsProperty | undefined;
        set internalValue(value: InputsProperty | undefined);
        get id(): string;
        private _namePrefix?;
        get namePrefix(): string;
        set namePrefix(value: string);
        get namePrefixInput(): string | undefined;
        get streamNames(): string[];
        private _kinesisFirehose;
        get kinesisFirehose(): InputsKinesisFirehosePropertyOutputReference;
        putKinesisFirehose(value: InputsKinesisFirehoseProperty): void;
        resetKinesisFirehose(): void;
        get kinesisFirehoseInput(): InputsKinesisFirehoseProperty | undefined;
        private _kinesisStream;
        get kinesisStream(): InputsKinesisStreamPropertyOutputReference;
        putKinesisStream(value: InputsKinesisStreamProperty): void;
        resetKinesisStream(): void;
        get kinesisStreamInput(): InputsKinesisStreamProperty | undefined;
        private _parallelism;
        get parallelism(): ParallelismPropertyOutputReference;
        putParallelism(value: ParallelismProperty): void;
        resetParallelism(): void;
        get parallelismInput(): ParallelismProperty | undefined;
        private _processingConfiguration;
        get processingConfiguration(): ProcessingConfigurationPropertyOutputReference;
        putProcessingConfiguration(value: ProcessingConfigurationProperty): void;
        resetProcessingConfiguration(): void;
        get processingConfigurationInput(): ProcessingConfigurationProperty | undefined;
        private _schema;
        get schema(): InputsSchemaPropertyOutputReference;
        putSchema(value: InputsSchemaProperty): void;
        get schemaInput(): InputsSchemaProperty | undefined;
        private _startingPositionConfiguration;
        get startingPositionConfiguration(): StartingPositionConfigurationPropertyList;
        putStartingPositionConfiguration(value: StartingPositionConfigurationProperty[] | cdktn.IResolvable): void;
        resetStartingPositionConfiguration(): void;
        get startingPositionConfigurationInput(): cdktn.IResolvable | StartingPositionConfigurationProperty[] | undefined;
    }
    interface OutputsKinesisFirehoseProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#resource_arn AwsApplication#resource_arn}
        */
        readonly resourceArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#role_arn AwsApplication#role_arn}
        */
        readonly roleArn: string;
    }
    class OutputsKinesisFirehosePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OutputsKinesisFirehoseProperty | undefined;
        set internalValue(value: OutputsKinesisFirehoseProperty | undefined);
        private _resourceArn?;
        get resourceArn(): string;
        set resourceArn(value: string);
        get resourceArnInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
    }
    interface OutputsKinesisStreamProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#resource_arn AwsApplication#resource_arn}
        */
        readonly resourceArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#role_arn AwsApplication#role_arn}
        */
        readonly roleArn: string;
    }
    class OutputsKinesisStreamPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OutputsKinesisStreamProperty | undefined;
        set internalValue(value: OutputsKinesisStreamProperty | undefined);
        private _resourceArn?;
        get resourceArn(): string;
        set resourceArn(value: string);
        get resourceArnInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
    }
    interface OutputsLambdaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#resource_arn AwsApplication#resource_arn}
        */
        readonly resourceArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#role_arn AwsApplication#role_arn}
        */
        readonly roleArn: string;
    }
    class OutputsLambdaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OutputsLambdaProperty | undefined;
        set internalValue(value: OutputsLambdaProperty | undefined);
        private _resourceArn?;
        get resourceArn(): string;
        set resourceArn(value: string);
        get resourceArnInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
    }
    interface OutputsSchemaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#record_format_type AwsApplication#record_format_type}
        */
        readonly recordFormatType: string;
    }
    class OutputsSchemaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OutputsSchemaProperty | undefined;
        set internalValue(value: OutputsSchemaProperty | undefined);
        private _recordFormatType?;
        get recordFormatType(): string;
        set recordFormatType(value: string);
        get recordFormatTypeInput(): string | undefined;
    }
    interface OutputsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#name AwsApplication#name}
        */
        readonly name: string;
        /**
        * kinesis_firehose block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#kinesis_firehose AwsApplication#kinesis_firehose}
        */
        readonly kinesisFirehose?: OutputsKinesisFirehoseProperty;
        /**
        * kinesis_stream block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#kinesis_stream AwsApplication#kinesis_stream}
        */
        readonly kinesisStream?: OutputsKinesisStreamProperty;
        /**
        * lambda block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#lambda AwsApplication#lambda}
        */
        readonly lambda?: OutputsLambdaProperty;
        /**
        * schema block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#schema AwsApplication#schema}
        */
        readonly schema: OutputsSchemaProperty;
    }
    class OutputsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OutputsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OutputsProperty | cdktn.IResolvable | undefined);
        get id(): string;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _kinesisFirehose;
        get kinesisFirehose(): OutputsKinesisFirehosePropertyOutputReference;
        putKinesisFirehose(value: OutputsKinesisFirehoseProperty): void;
        resetKinesisFirehose(): void;
        get kinesisFirehoseInput(): OutputsKinesisFirehoseProperty | undefined;
        private _kinesisStream;
        get kinesisStream(): OutputsKinesisStreamPropertyOutputReference;
        putKinesisStream(value: OutputsKinesisStreamProperty): void;
        resetKinesisStream(): void;
        get kinesisStreamInput(): OutputsKinesisStreamProperty | undefined;
        private _lambda;
        get lambda(): OutputsLambdaPropertyOutputReference;
        putLambda(value: OutputsLambdaProperty): void;
        resetLambda(): void;
        get lambdaInput(): OutputsLambdaProperty | undefined;
        private _schema;
        get schema(): OutputsSchemaPropertyOutputReference;
        putSchema(value: OutputsSchemaProperty): void;
        get schemaInput(): OutputsSchemaProperty | undefined;
    }
    class OutputsPropertyList extends cdktn.ComplexList {
        internalValue?: OutputsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OutputsPropertyOutputReference;
    }
    interface S3Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#bucket_arn AwsApplication#bucket_arn}
        */
        readonly bucketArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#file_key AwsApplication#file_key}
        */
        readonly fileKey: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#role_arn AwsApplication#role_arn}
        */
        readonly roleArn: string;
    }
    class S3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3Property | undefined;
        set internalValue(value: S3Property | undefined);
        private _bucketArn?;
        get bucketArn(): string;
        set bucketArn(value: string);
        get bucketArnInput(): string | undefined;
        private _fileKey?;
        get fileKey(): string;
        set fileKey(value: string);
        get fileKeyInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
    }
    interface ReferenceDataSourcesSchemaRecordColumnsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#mapping AwsApplication#mapping}
        */
        readonly mapping?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#name AwsApplication#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#sql_type AwsApplication#sql_type}
        */
        readonly sqlType: string;
    }
    class ReferenceDataSourcesSchemaRecordColumnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReferenceDataSourcesSchemaRecordColumnsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ReferenceDataSourcesSchemaRecordColumnsProperty | cdktn.IResolvable | undefined);
        private _mapping?;
        get mapping(): string;
        set mapping(value: string);
        resetMapping(): void;
        get mappingInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _sqlType?;
        get sqlType(): string;
        set sqlType(value: string);
        get sqlTypeInput(): string | undefined;
    }
    class ReferenceDataSourcesSchemaRecordColumnsPropertyList extends cdktn.ComplexList {
        internalValue?: ReferenceDataSourcesSchemaRecordColumnsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReferenceDataSourcesSchemaRecordColumnsPropertyOutputReference;
    }
    interface ReferenceDataSourcesSchemaRecordFormatMappingParametersCsvProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#record_column_delimiter AwsApplication#record_column_delimiter}
        */
        readonly recordColumnDelimiter: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#record_row_delimiter AwsApplication#record_row_delimiter}
        */
        readonly recordRowDelimiter: string;
    }
    class ReferenceDataSourcesSchemaRecordFormatMappingParametersCsvPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ReferenceDataSourcesSchemaRecordFormatMappingParametersCsvProperty | undefined;
        set internalValue(value: ReferenceDataSourcesSchemaRecordFormatMappingParametersCsvProperty | undefined);
        private _recordColumnDelimiter?;
        get recordColumnDelimiter(): string;
        set recordColumnDelimiter(value: string);
        get recordColumnDelimiterInput(): string | undefined;
        private _recordRowDelimiter?;
        get recordRowDelimiter(): string;
        set recordRowDelimiter(value: string);
        get recordRowDelimiterInput(): string | undefined;
    }
    interface ReferenceDataSourcesSchemaRecordFormatMappingParametersJsonProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#record_row_path AwsApplication#record_row_path}
        */
        readonly recordRowPath: string;
    }
    class ReferenceDataSourcesSchemaRecordFormatMappingParametersJsonPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ReferenceDataSourcesSchemaRecordFormatMappingParametersJsonProperty | undefined;
        set internalValue(value: ReferenceDataSourcesSchemaRecordFormatMappingParametersJsonProperty | undefined);
        private _recordRowPath?;
        get recordRowPath(): string;
        set recordRowPath(value: string);
        get recordRowPathInput(): string | undefined;
    }
    interface ReferenceDataSourcesSchemaRecordFormatMappingParametersProperty {
        /**
        * csv block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#csv AwsApplication#csv}
        */
        readonly csv?: ReferenceDataSourcesSchemaRecordFormatMappingParametersCsvProperty;
        /**
        * json block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#json AwsApplication#json}
        */
        readonly json?: ReferenceDataSourcesSchemaRecordFormatMappingParametersJsonProperty;
    }
    class ReferenceDataSourcesSchemaRecordFormatMappingParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ReferenceDataSourcesSchemaRecordFormatMappingParametersProperty | undefined;
        set internalValue(value: ReferenceDataSourcesSchemaRecordFormatMappingParametersProperty | undefined);
        private _csv;
        get csv(): ReferenceDataSourcesSchemaRecordFormatMappingParametersCsvPropertyOutputReference;
        putCsv(value: ReferenceDataSourcesSchemaRecordFormatMappingParametersCsvProperty): void;
        resetCsv(): void;
        get csvInput(): ReferenceDataSourcesSchemaRecordFormatMappingParametersCsvProperty | undefined;
        private _json;
        get json(): ReferenceDataSourcesSchemaRecordFormatMappingParametersJsonPropertyOutputReference;
        putJson(value: ReferenceDataSourcesSchemaRecordFormatMappingParametersJsonProperty): void;
        resetJson(): void;
        get jsonInput(): ReferenceDataSourcesSchemaRecordFormatMappingParametersJsonProperty | undefined;
    }
    interface ReferenceDataSourcesSchemaRecordFormatProperty {
        /**
        * mapping_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#mapping_parameters AwsApplication#mapping_parameters}
        */
        readonly mappingParameters?: ReferenceDataSourcesSchemaRecordFormatMappingParametersProperty;
    }
    class ReferenceDataSourcesSchemaRecordFormatPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ReferenceDataSourcesSchemaRecordFormatProperty | undefined;
        set internalValue(value: ReferenceDataSourcesSchemaRecordFormatProperty | undefined);
        get recordFormatType(): string;
        private _mappingParameters;
        get mappingParameters(): ReferenceDataSourcesSchemaRecordFormatMappingParametersPropertyOutputReference;
        putMappingParameters(value: ReferenceDataSourcesSchemaRecordFormatMappingParametersProperty): void;
        resetMappingParameters(): void;
        get mappingParametersInput(): ReferenceDataSourcesSchemaRecordFormatMappingParametersProperty | undefined;
    }
    interface ReferenceDataSourcesSchemaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#record_encoding AwsApplication#record_encoding}
        */
        readonly recordEncoding?: string;
        /**
        * record_columns block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#record_columns AwsApplication#record_columns}
        */
        readonly recordColumns: ReferenceDataSourcesSchemaRecordColumnsProperty[] | cdktn.IResolvable;
        /**
        * record_format block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#record_format AwsApplication#record_format}
        */
        readonly recordFormat: ReferenceDataSourcesSchemaRecordFormatProperty;
    }
    class ReferenceDataSourcesSchemaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ReferenceDataSourcesSchemaProperty | undefined;
        set internalValue(value: ReferenceDataSourcesSchemaProperty | undefined);
        private _recordEncoding?;
        get recordEncoding(): string;
        set recordEncoding(value: string);
        resetRecordEncoding(): void;
        get recordEncodingInput(): string | undefined;
        private _recordColumns;
        get recordColumns(): ReferenceDataSourcesSchemaRecordColumnsPropertyList;
        putRecordColumns(value: ReferenceDataSourcesSchemaRecordColumnsProperty[] | cdktn.IResolvable): void;
        get recordColumnsInput(): cdktn.IResolvable | ReferenceDataSourcesSchemaRecordColumnsProperty[] | undefined;
        private _recordFormat;
        get recordFormat(): ReferenceDataSourcesSchemaRecordFormatPropertyOutputReference;
        putRecordFormat(value: ReferenceDataSourcesSchemaRecordFormatProperty): void;
        get recordFormatInput(): ReferenceDataSourcesSchemaRecordFormatProperty | undefined;
    }
    interface ReferenceDataSourcesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#table_name AwsApplication#table_name}
        */
        readonly tableName: string;
        /**
        * s3 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#s3 AwsApplication#s3}
        */
        readonly s3: S3Property;
        /**
        * schema block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/kinesis_analytics_application#schema AwsApplication#schema}
        */
        readonly schema: ReferenceDataSourcesSchemaProperty;
    }
    class ReferenceDataSourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ReferenceDataSourcesProperty | undefined;
        set internalValue(value: ReferenceDataSourcesProperty | undefined);
        get id(): string;
        private _tableName?;
        get tableName(): string;
        set tableName(value: string);
        get tableNameInput(): string | undefined;
        private _s3;
        get s3(): S3PropertyOutputReference;
        putS3(value: S3Property): void;
        get s3Input(): S3Property | undefined;
        private _schema;
        get schema(): ReferenceDataSourcesSchemaPropertyOutputReference;
        putSchema(value: ReferenceDataSourcesSchemaProperty): void;
        get schemaInput(): ReferenceDataSourcesSchemaProperty | undefined;
    }
}
