import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsEc2TransitGatewayPeeringAttachmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_transit_gateway_peering_attachment#id AwsEc2TransitGatewayPeeringAttachment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_transit_gateway_peering_attachment#peer_account_id AwsEc2TransitGatewayPeeringAttachment#peer_account_id}
    */
    readonly peerAccountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_transit_gateway_peering_attachment#peer_region AwsEc2TransitGatewayPeeringAttachment#peer_region}
    */
    readonly peerRegion: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_transit_gateway_peering_attachment#peer_transit_gateway_id AwsEc2TransitGatewayPeeringAttachment#peer_transit_gateway_id}
    */
    readonly peerTransitGatewayId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_transit_gateway_peering_attachment#region AwsEc2TransitGatewayPeeringAttachment#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_transit_gateway_peering_attachment#tags AwsEc2TransitGatewayPeeringAttachment#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_transit_gateway_peering_attachment#tags_all AwsEc2TransitGatewayPeeringAttachment#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_transit_gateway_peering_attachment#transit_gateway_id AwsEc2TransitGatewayPeeringAttachment#transit_gateway_id}
    */
    readonly transitGatewayId: string;
    /**
    * options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_transit_gateway_peering_attachment#options AwsEc2TransitGatewayPeeringAttachment#options}
    */
    readonly options?: AwsEc2TransitGatewayPeeringAttachment.OptionsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_transit_gateway_peering_attachment aws_ec2_transit_gateway_peering_attachment}
*/
export declare class AwsEc2TransitGatewayPeeringAttachment extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ec2_transit_gateway_peering_attachment";
    /**
    * Generates CDKTN code for importing a AwsEc2TransitGatewayPeeringAttachment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsEc2TransitGatewayPeeringAttachment to import
    * @param importFromId The id of the existing AwsEc2TransitGatewayPeeringAttachment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_transit_gateway_peering_attachment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsEc2TransitGatewayPeeringAttachment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_transit_gateway_peering_attachment aws_ec2_transit_gateway_peering_attachment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsEc2TransitGatewayPeeringAttachmentConfig
    */
    constructor(scope: Construct, id: string, config: AwsEc2TransitGatewayPeeringAttachmentConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _peerAccountId?;
    get peerAccountId(): string;
    set peerAccountId(value: string);
    resetPeerAccountId(): void;
    get peerAccountIdInput(): string | undefined;
    private _peerRegion?;
    get peerRegion(): string;
    set peerRegion(value: string);
    get peerRegionInput(): string | undefined;
    private _peerTransitGatewayId?;
    get peerTransitGatewayId(): string;
    set peerTransitGatewayId(value: string);
    get peerTransitGatewayIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get state(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _transitGatewayId?;
    get transitGatewayId(): string;
    set transitGatewayId(value: string);
    get transitGatewayIdInput(): string | undefined;
    private _options;
    get options(): AwsEc2TransitGatewayPeeringAttachment.OptionsPropertyOutputReference;
    putOptions(value: AwsEc2TransitGatewayPeeringAttachment.OptionsProperty): void;
    resetOptions(): void;
    get optionsInput(): AwsEc2TransitGatewayPeeringAttachment.OptionsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsEc2TransitGatewayPeeringAttachmentOptionsPropertyToTerraform(struct?: AwsEc2TransitGatewayPeeringAttachment.OptionsPropertyOutputReference | AwsEc2TransitGatewayPeeringAttachment.OptionsProperty): any;
export declare function awsEc2TransitGatewayPeeringAttachmentOptionsPropertyToHclTerraform(struct?: AwsEc2TransitGatewayPeeringAttachment.OptionsPropertyOutputReference | AwsEc2TransitGatewayPeeringAttachment.OptionsProperty): any;
export declare namespace AwsEc2TransitGatewayPeeringAttachment {
    interface OptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_transit_gateway_peering_attachment#dynamic_routing AwsEc2TransitGatewayPeeringAttachment#dynamic_routing}
        */
        readonly dynamicRouting?: string;
    }
    class OptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OptionsProperty | undefined;
        set internalValue(value: OptionsProperty | undefined);
        private _dynamicRouting?;
        get dynamicRouting(): string;
        set dynamicRouting(value: string);
        resetDynamicRouting(): void;
        get dynamicRoutingInput(): string | undefined;
    }
}
