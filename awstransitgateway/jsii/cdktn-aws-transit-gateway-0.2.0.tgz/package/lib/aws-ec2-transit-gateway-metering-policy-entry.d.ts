import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfMeteringPolicyEntryConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_transit_gateway_metering_policy_entry#destination_cidr_block TfMeteringPolicyEntry#destination_cidr_block}
    */
    readonly destinationCidrBlock?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_transit_gateway_metering_policy_entry#destination_port_range TfMeteringPolicyEntry#destination_port_range}
    */
    readonly destinationPortRange?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_transit_gateway_metering_policy_entry#destination_transit_gateway_attachment_id TfMeteringPolicyEntry#destination_transit_gateway_attachment_id}
    */
    readonly destinationTransitGatewayAttachmentId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_transit_gateway_metering_policy_entry#destination_transit_gateway_attachment_type TfMeteringPolicyEntry#destination_transit_gateway_attachment_type}
    */
    readonly destinationTransitGatewayAttachmentType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_transit_gateway_metering_policy_entry#metered_account TfMeteringPolicyEntry#metered_account}
    */
    readonly meteredAccount: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_transit_gateway_metering_policy_entry#policy_rule_number TfMeteringPolicyEntry#policy_rule_number}
    */
    readonly policyRuleNumber: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_transit_gateway_metering_policy_entry#protocol TfMeteringPolicyEntry#protocol}
    */
    readonly protocol?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_transit_gateway_metering_policy_entry#region TfMeteringPolicyEntry#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_transit_gateway_metering_policy_entry#source_cidr_block TfMeteringPolicyEntry#source_cidr_block}
    */
    readonly sourceCidrBlock?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_transit_gateway_metering_policy_entry#source_port_range TfMeteringPolicyEntry#source_port_range}
    */
    readonly sourcePortRange?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_transit_gateway_metering_policy_entry#source_transit_gateway_attachment_id TfMeteringPolicyEntry#source_transit_gateway_attachment_id}
    */
    readonly sourceTransitGatewayAttachmentId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_transit_gateway_metering_policy_entry#source_transit_gateway_attachment_type TfMeteringPolicyEntry#source_transit_gateway_attachment_type}
    */
    readonly sourceTransitGatewayAttachmentType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_transit_gateway_metering_policy_entry#transit_gateway_metering_policy_id TfMeteringPolicyEntry#transit_gateway_metering_policy_id}
    */
    readonly transitGatewayMeteringPolicyId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_transit_gateway_metering_policy_entry#timeouts TfMeteringPolicyEntry#timeouts}
    */
    readonly timeouts?: TfMeteringPolicyEntry.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_transit_gateway_metering_policy_entry aws_ec2_transit_gateway_metering_policy_entry}
*/
export declare class TfMeteringPolicyEntry extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ec2_transit_gateway_metering_policy_entry";
    /**
    * Generates CDKTN code for importing a TfMeteringPolicyEntry resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfMeteringPolicyEntry to import
    * @param importFromId The id of the existing TfMeteringPolicyEntry that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_transit_gateway_metering_policy_entry#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfMeteringPolicyEntry to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_transit_gateway_metering_policy_entry aws_ec2_transit_gateway_metering_policy_entry} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfMeteringPolicyEntryConfig
    */
    constructor(scope: Construct, id: string, config: TfMeteringPolicyEntryConfig);
    private _destinationCidrBlock?;
    get destinationCidrBlock(): string;
    set destinationCidrBlock(value: string);
    resetDestinationCidrBlock(): void;
    get destinationCidrBlockInput(): string | undefined;
    private _destinationPortRange?;
    get destinationPortRange(): string;
    set destinationPortRange(value: string);
    resetDestinationPortRange(): void;
    get destinationPortRangeInput(): string | undefined;
    private _destinationTransitGatewayAttachmentId?;
    get destinationTransitGatewayAttachmentId(): string;
    set destinationTransitGatewayAttachmentId(value: string);
    resetDestinationTransitGatewayAttachmentId(): void;
    get destinationTransitGatewayAttachmentIdInput(): string | undefined;
    private _destinationTransitGatewayAttachmentType?;
    get destinationTransitGatewayAttachmentType(): string;
    set destinationTransitGatewayAttachmentType(value: string);
    resetDestinationTransitGatewayAttachmentType(): void;
    get destinationTransitGatewayAttachmentTypeInput(): string | undefined;
    private _meteredAccount?;
    get meteredAccount(): string;
    set meteredAccount(value: string);
    get meteredAccountInput(): string | undefined;
    private _policyRuleNumber?;
    get policyRuleNumber(): number;
    set policyRuleNumber(value: number);
    get policyRuleNumberInput(): number | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    resetProtocol(): void;
    get protocolInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _sourceCidrBlock?;
    get sourceCidrBlock(): string;
    set sourceCidrBlock(value: string);
    resetSourceCidrBlock(): void;
    get sourceCidrBlockInput(): string | undefined;
    private _sourcePortRange?;
    get sourcePortRange(): string;
    set sourcePortRange(value: string);
    resetSourcePortRange(): void;
    get sourcePortRangeInput(): string | undefined;
    private _sourceTransitGatewayAttachmentId?;
    get sourceTransitGatewayAttachmentId(): string;
    set sourceTransitGatewayAttachmentId(value: string);
    resetSourceTransitGatewayAttachmentId(): void;
    get sourceTransitGatewayAttachmentIdInput(): string | undefined;
    private _sourceTransitGatewayAttachmentType?;
    get sourceTransitGatewayAttachmentType(): string;
    set sourceTransitGatewayAttachmentType(value: string);
    resetSourceTransitGatewayAttachmentType(): void;
    get sourceTransitGatewayAttachmentTypeInput(): string | undefined;
    private _transitGatewayMeteringPolicyId?;
    get transitGatewayMeteringPolicyId(): string;
    set transitGatewayMeteringPolicyId(value: string);
    get transitGatewayMeteringPolicyIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): TfMeteringPolicyEntry.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfMeteringPolicyEntry.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfMeteringPolicyEntry.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfMeteringPolicyEntryTimeoutsPropertyToTerraform(struct?: TfMeteringPolicyEntry.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfMeteringPolicyEntryTimeoutsPropertyToHclTerraform(struct?: TfMeteringPolicyEntry.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfMeteringPolicyEntry {
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_transit_gateway_metering_policy_entry#create TfMeteringPolicyEntry#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ec2_transit_gateway_metering_policy_entry#delete TfMeteringPolicyEntry#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
