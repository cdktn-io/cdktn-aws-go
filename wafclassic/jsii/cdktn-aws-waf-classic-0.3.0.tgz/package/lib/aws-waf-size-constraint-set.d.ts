import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSizeConstraintSetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_size_constraint_set#id AwsSizeConstraintSet#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_size_constraint_set#name AwsSizeConstraintSet#name}
    */
    readonly name: string;
    /**
    * size_constraints block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_size_constraint_set#size_constraints AwsSizeConstraintSet#size_constraints}
    */
    readonly sizeConstraints?: AwsSizeConstraintSet.SizeConstraintsProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_size_constraint_set aws_waf_size_constraint_set}
*/
export declare class AwsSizeConstraintSet extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_waf_size_constraint_set";
    /**
    * Generates CDKTN code for importing a AwsSizeConstraintSet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSizeConstraintSet to import
    * @param importFromId The id of the existing AwsSizeConstraintSet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_size_constraint_set#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSizeConstraintSet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_size_constraint_set aws_waf_size_constraint_set} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSizeConstraintSetConfig
    */
    constructor(scope: Construct, id: string, config: AwsSizeConstraintSetConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _sizeConstraints;
    get sizeConstraints(): AwsSizeConstraintSet.SizeConstraintsPropertyList;
    putSizeConstraints(value: AwsSizeConstraintSet.SizeConstraintsProperty[] | cdktn.IResolvable): void;
    resetSizeConstraints(): void;
    get sizeConstraintsInput(): cdktn.IResolvable | AwsSizeConstraintSet.SizeConstraintsProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSizeConstraintSetFieldToMatchPropertyToTerraform(struct?: AwsSizeConstraintSet.FieldToMatchPropertyOutputReference | AwsSizeConstraintSet.FieldToMatchProperty): any;
export declare function awsSizeConstraintSetFieldToMatchPropertyToHclTerraform(struct?: AwsSizeConstraintSet.FieldToMatchPropertyOutputReference | AwsSizeConstraintSet.FieldToMatchProperty): any;
export declare function awsSizeConstraintSetSizeConstraintsPropertyToTerraform(struct?: AwsSizeConstraintSet.SizeConstraintsProperty | cdktn.IResolvable): any;
export declare function awsSizeConstraintSetSizeConstraintsPropertyToHclTerraform(struct?: AwsSizeConstraintSet.SizeConstraintsProperty | cdktn.IResolvable): any;
export declare namespace AwsSizeConstraintSet {
    interface FieldToMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_size_constraint_set#data AwsSizeConstraintSet#data}
        */
        readonly data?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_size_constraint_set#type AwsSizeConstraintSet#type}
        */
        readonly type: string;
    }
    class FieldToMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FieldToMatchProperty | undefined;
        set internalValue(value: FieldToMatchProperty | undefined);
        private _data?;
        get data(): string;
        set data(value: string);
        resetData(): void;
        get dataInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    interface SizeConstraintsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_size_constraint_set#comparison_operator AwsSizeConstraintSet#comparison_operator}
        */
        readonly comparisonOperator: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_size_constraint_set#size AwsSizeConstraintSet#size}
        */
        readonly size: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_size_constraint_set#text_transformation AwsSizeConstraintSet#text_transformation}
        */
        readonly textTransformation: string;
        /**
        * field_to_match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_size_constraint_set#field_to_match AwsSizeConstraintSet#field_to_match}
        */
        readonly fieldToMatch: FieldToMatchProperty;
    }
    class SizeConstraintsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SizeConstraintsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SizeConstraintsProperty | cdktn.IResolvable | undefined);
        private _comparisonOperator?;
        get comparisonOperator(): string;
        set comparisonOperator(value: string);
        get comparisonOperatorInput(): string | undefined;
        private _size?;
        get size(): number;
        set size(value: number);
        get sizeInput(): number | undefined;
        private _textTransformation?;
        get textTransformation(): string;
        set textTransformation(value: string);
        get textTransformationInput(): string | undefined;
        private _fieldToMatch;
        get fieldToMatch(): FieldToMatchPropertyOutputReference;
        putFieldToMatch(value: FieldToMatchProperty): void;
        get fieldToMatchInput(): FieldToMatchProperty | undefined;
    }
    class SizeConstraintsPropertyList extends cdktn.ComplexList {
        internalValue?: SizeConstraintsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SizeConstraintsPropertyOutputReference;
    }
}
