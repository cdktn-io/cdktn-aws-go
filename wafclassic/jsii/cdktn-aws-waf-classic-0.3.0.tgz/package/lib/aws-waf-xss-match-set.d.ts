import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsXssMatchSetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_xss_match_set#id AwsXssMatchSet#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_xss_match_set#name AwsXssMatchSet#name}
    */
    readonly name: string;
    /**
    * xss_match_tuples block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_xss_match_set#xss_match_tuples AwsXssMatchSet#xss_match_tuples}
    */
    readonly xssMatchTuples?: AwsXssMatchSet.XssMatchTuplesProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_xss_match_set aws_waf_xss_match_set}
*/
export declare class AwsXssMatchSet extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_waf_xss_match_set";
    /**
    * Generates CDKTN code for importing a AwsXssMatchSet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsXssMatchSet to import
    * @param importFromId The id of the existing AwsXssMatchSet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_xss_match_set#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsXssMatchSet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_xss_match_set aws_waf_xss_match_set} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsXssMatchSetConfig
    */
    constructor(scope: Construct, id: string, config: AwsXssMatchSetConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _xssMatchTuples;
    get xssMatchTuples(): AwsXssMatchSet.XssMatchTuplesPropertyList;
    putXssMatchTuples(value: AwsXssMatchSet.XssMatchTuplesProperty[] | cdktn.IResolvable): void;
    resetXssMatchTuples(): void;
    get xssMatchTuplesInput(): cdktn.IResolvable | AwsXssMatchSet.XssMatchTuplesProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsXssMatchSetFieldToMatchPropertyToTerraform(struct?: AwsXssMatchSet.FieldToMatchPropertyOutputReference | AwsXssMatchSet.FieldToMatchProperty): any;
export declare function awsXssMatchSetFieldToMatchPropertyToHclTerraform(struct?: AwsXssMatchSet.FieldToMatchPropertyOutputReference | AwsXssMatchSet.FieldToMatchProperty): any;
export declare function awsXssMatchSetXssMatchTuplesPropertyToTerraform(struct?: AwsXssMatchSet.XssMatchTuplesProperty | cdktn.IResolvable): any;
export declare function awsXssMatchSetXssMatchTuplesPropertyToHclTerraform(struct?: AwsXssMatchSet.XssMatchTuplesProperty | cdktn.IResolvable): any;
export declare namespace AwsXssMatchSet {
    interface FieldToMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_xss_match_set#data AwsXssMatchSet#data}
        */
        readonly data?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_xss_match_set#type AwsXssMatchSet#type}
        */
        readonly type: string;
    }
    class FieldToMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FieldToMatchProperty | undefined;
        set internalValue(value: FieldToMatchProperty | undefined);
        private _data?;
        get data(): string;
        set data(value: string);
        resetData(): void;
        get dataInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    interface XssMatchTuplesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_xss_match_set#text_transformation AwsXssMatchSet#text_transformation}
        */
        readonly textTransformation: string;
        /**
        * field_to_match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/waf_xss_match_set#field_to_match AwsXssMatchSet#field_to_match}
        */
        readonly fieldToMatch: FieldToMatchProperty;
    }
    class XssMatchTuplesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): XssMatchTuplesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: XssMatchTuplesProperty | cdktn.IResolvable | undefined);
        private _textTransformation?;
        get textTransformation(): string;
        set textTransformation(value: string);
        get textTransformationInput(): string | undefined;
        private _fieldToMatch;
        get fieldToMatch(): FieldToMatchPropertyOutputReference;
        putFieldToMatch(value: FieldToMatchProperty): void;
        get fieldToMatchInput(): FieldToMatchProperty | undefined;
    }
    class XssMatchTuplesPropertyList extends cdktn.ComplexList {
        internalValue?: XssMatchTuplesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): XssMatchTuplesPropertyOutputReference;
    }
}
