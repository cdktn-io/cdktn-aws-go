import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsCertificateConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acm_certificate#certificate_authority_arn AwsCertificate#certificate_authority_arn}
    */
    readonly certificateAuthorityArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acm_certificate#certificate_body AwsCertificate#certificate_body}
    */
    readonly certificateBody?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acm_certificate#certificate_chain AwsCertificate#certificate_chain}
    */
    readonly certificateChain?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acm_certificate#domain_name AwsCertificate#domain_name}
    */
    readonly domainName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acm_certificate#early_renewal_duration AwsCertificate#early_renewal_duration}
    */
    readonly earlyRenewalDuration?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acm_certificate#id AwsCertificate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acm_certificate#key_algorithm AwsCertificate#key_algorithm}
    */
    readonly keyAlgorithm?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acm_certificate#private_key AwsCertificate#private_key}
    */
    readonly privateKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acm_certificate#private_key_wo AwsCertificate#private_key_wo}
    */
    readonly privateKeyWo?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acm_certificate#private_key_wo_version AwsCertificate#private_key_wo_version}
    */
    readonly privateKeyWoVersion?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acm_certificate#region AwsCertificate#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acm_certificate#subject_alternative_names AwsCertificate#subject_alternative_names}
    */
    readonly subjectAlternativeNames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acm_certificate#tags AwsCertificate#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acm_certificate#tags_all AwsCertificate#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acm_certificate#validation_method AwsCertificate#validation_method}
    */
    readonly validationMethod?: string;
    /**
    * options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acm_certificate#options AwsCertificate#options}
    */
    readonly options?: AwsCertificate.OptionsProperty;
    /**
    * validation_option block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acm_certificate#validation_option AwsCertificate#validation_option}
    */
    readonly validationOption?: AwsCertificate.ValidationOptionProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acm_certificate aws_acm_certificate}
*/
export declare class AwsCertificate extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_acm_certificate";
    /**
    * Generates CDKTN code for importing a AwsCertificate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCertificate to import
    * @param importFromId The id of the existing AwsCertificate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acm_certificate#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCertificate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acm_certificate aws_acm_certificate} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsCertificateConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsCertificateConfig);
    get arn(): string;
    private _certificateAuthorityArn?;
    get certificateAuthorityArn(): string;
    set certificateAuthorityArn(value: string);
    resetCertificateAuthorityArn(): void;
    get certificateAuthorityArnInput(): string | undefined;
    private _certificateBody?;
    get certificateBody(): string;
    set certificateBody(value: string);
    resetCertificateBody(): void;
    get certificateBodyInput(): string | undefined;
    private _certificateChain?;
    get certificateChain(): string;
    set certificateChain(value: string);
    resetCertificateChain(): void;
    get certificateChainInput(): string | undefined;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    resetDomainName(): void;
    get domainNameInput(): string | undefined;
    private _domainValidationOptions;
    get domainValidationOptions(): AwsCertificate.DomainValidationOptionsPropertyList;
    private _earlyRenewalDuration?;
    get earlyRenewalDuration(): string;
    set earlyRenewalDuration(value: string);
    resetEarlyRenewalDuration(): void;
    get earlyRenewalDurationInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _keyAlgorithm?;
    get keyAlgorithm(): string;
    set keyAlgorithm(value: string);
    resetKeyAlgorithm(): void;
    get keyAlgorithmInput(): string | undefined;
    get notAfter(): string;
    get notBefore(): string;
    get pendingRenewal(): cdktn.IResolvable;
    private _privateKey?;
    get privateKey(): string;
    set privateKey(value: string);
    resetPrivateKey(): void;
    get privateKeyInput(): string | undefined;
    private _privateKeyWo?;
    /**
    * @deprecated Write-only: the provider never returns this value; reading it always yields null by protocol contract. The getter remains for compatibility and will be removed in a future prebuilt-provider major.
    */
    get privateKeyWo(): string;
    set privateKeyWo(value: string);
    resetPrivateKeyWo(): void;
    get privateKeyWoInput(): string | undefined;
    private _privateKeyWoVersion?;
    get privateKeyWoVersion(): number;
    set privateKeyWoVersion(value: number);
    resetPrivateKeyWoVersion(): void;
    get privateKeyWoVersionInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get renewalEligibility(): string;
    private _renewalSummary;
    get renewalSummary(): AwsCertificate.RenewalSummaryPropertyList;
    get status(): string;
    private _subjectAlternativeNames?;
    get subjectAlternativeNames(): string[];
    set subjectAlternativeNames(value: string[]);
    resetSubjectAlternativeNames(): void;
    get subjectAlternativeNamesInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get type(): string;
    get validationEmails(): string[];
    private _validationMethod?;
    get validationMethod(): string;
    set validationMethod(value: string);
    resetValidationMethod(): void;
    get validationMethodInput(): string | undefined;
    private _options;
    get options(): AwsCertificate.OptionsPropertyOutputReference;
    putOptions(value: AwsCertificate.OptionsProperty): void;
    resetOptions(): void;
    get optionsInput(): AwsCertificate.OptionsProperty | undefined;
    private _validationOption;
    get validationOption(): AwsCertificate.ValidationOptionPropertyList;
    putValidationOption(value: AwsCertificate.ValidationOptionProperty[] | cdktn.IResolvable): void;
    resetValidationOption(): void;
    get validationOptionInput(): cdktn.IResolvable | AwsCertificate.ValidationOptionProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsCertificateDomainValidationOptionsPropertyToTerraform(struct?: AwsCertificate.DomainValidationOptionsProperty): any;
export declare function awsCertificateDomainValidationOptionsPropertyToHclTerraform(struct?: AwsCertificate.DomainValidationOptionsProperty): any;
export declare function awsCertificateRenewalSummaryPropertyToTerraform(struct?: AwsCertificate.RenewalSummaryProperty): any;
export declare function awsCertificateRenewalSummaryPropertyToHclTerraform(struct?: AwsCertificate.RenewalSummaryProperty): any;
export declare function awsCertificateOptionsPropertyToTerraform(struct?: AwsCertificate.OptionsPropertyOutputReference | AwsCertificate.OptionsProperty): any;
export declare function awsCertificateOptionsPropertyToHclTerraform(struct?: AwsCertificate.OptionsPropertyOutputReference | AwsCertificate.OptionsProperty): any;
export declare function awsCertificateValidationOptionPropertyToTerraform(struct?: AwsCertificate.ValidationOptionProperty | cdktn.IResolvable): any;
export declare function awsCertificateValidationOptionPropertyToHclTerraform(struct?: AwsCertificate.ValidationOptionProperty | cdktn.IResolvable): any;
export declare namespace AwsCertificate {
    interface DomainValidationOptionsProperty {
    }
    class DomainValidationOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DomainValidationOptionsProperty | undefined;
        set internalValue(value: DomainValidationOptionsProperty | undefined);
        get domainName(): string;
        get resourceRecordName(): string;
        get resourceRecordType(): string;
        get resourceRecordValue(): string;
    }
    class DomainValidationOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DomainValidationOptionsPropertyOutputReference;
    }
    interface RenewalSummaryProperty {
    }
    class RenewalSummaryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RenewalSummaryProperty | undefined;
        set internalValue(value: RenewalSummaryProperty | undefined);
        get renewalStatus(): string;
        get renewalStatusReason(): string;
        get updatedAt(): string;
    }
    class RenewalSummaryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RenewalSummaryPropertyOutputReference;
    }
    interface OptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acm_certificate#certificate_transparency_logging_preference AwsCertificate#certificate_transparency_logging_preference}
        */
        readonly certificateTransparencyLoggingPreference?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acm_certificate#export AwsCertificate#export}
        */
        readonly export?: string;
    }
    class OptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OptionsProperty | undefined;
        set internalValue(value: OptionsProperty | undefined);
        private _certificateTransparencyLoggingPreference?;
        get certificateTransparencyLoggingPreference(): string;
        set certificateTransparencyLoggingPreference(value: string);
        resetCertificateTransparencyLoggingPreference(): void;
        get certificateTransparencyLoggingPreferenceInput(): string | undefined;
        private _export?;
        get export(): string;
        set export(value: string);
        resetExport(): void;
        get exportInput(): string | undefined;
    }
    interface ValidationOptionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acm_certificate#domain_name AwsCertificate#domain_name}
        */
        readonly domainName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acm_certificate#validation_domain AwsCertificate#validation_domain}
        */
        readonly validationDomain: string;
    }
    class ValidationOptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ValidationOptionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ValidationOptionProperty | cdktn.IResolvable | undefined);
        private _domainName?;
        get domainName(): string;
        set domainName(value: string);
        get domainNameInput(): string | undefined;
        private _validationDomain?;
        get validationDomain(): string;
        set validationDomain(value: string);
        get validationDomainInput(): string | undefined;
    }
    class ValidationOptionPropertyList extends cdktn.ComplexList {
        internalValue?: ValidationOptionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ValidationOptionPropertyOutputReference;
    }
}
