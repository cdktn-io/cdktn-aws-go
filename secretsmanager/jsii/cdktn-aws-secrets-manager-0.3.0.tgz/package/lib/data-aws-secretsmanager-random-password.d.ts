import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsRandomPasswordConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/secretsmanager_random_password#exclude_characters DataAwsRandomPassword#exclude_characters}
    */
    readonly excludeCharacters?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/secretsmanager_random_password#exclude_lowercase DataAwsRandomPassword#exclude_lowercase}
    */
    readonly excludeLowercase?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/secretsmanager_random_password#exclude_numbers DataAwsRandomPassword#exclude_numbers}
    */
    readonly excludeNumbers?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/secretsmanager_random_password#exclude_punctuation DataAwsRandomPassword#exclude_punctuation}
    */
    readonly excludePunctuation?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/secretsmanager_random_password#exclude_uppercase DataAwsRandomPassword#exclude_uppercase}
    */
    readonly excludeUppercase?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/secretsmanager_random_password#id DataAwsRandomPassword#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/secretsmanager_random_password#include_space DataAwsRandomPassword#include_space}
    */
    readonly includeSpace?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/secretsmanager_random_password#password_length DataAwsRandomPassword#password_length}
    */
    readonly passwordLength?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/secretsmanager_random_password#region DataAwsRandomPassword#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/secretsmanager_random_password#require_each_included_type DataAwsRandomPassword#require_each_included_type}
    */
    readonly requireEachIncludedType?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/secretsmanager_random_password aws_secretsmanager_random_password}
*/
export declare class DataAwsRandomPassword extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_secretsmanager_random_password";
    /**
    * Generates CDKTN code for importing a DataAwsRandomPassword resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsRandomPassword to import
    * @param importFromId The id of the existing DataAwsRandomPassword that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/secretsmanager_random_password#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsRandomPassword to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/secretsmanager_random_password aws_secretsmanager_random_password} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsRandomPasswordConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsRandomPasswordConfig);
    private _excludeCharacters?;
    get excludeCharacters(): string;
    set excludeCharacters(value: string);
    resetExcludeCharacters(): void;
    get excludeCharactersInput(): string | undefined;
    private _excludeLowercase?;
    get excludeLowercase(): boolean | cdktn.IResolvable;
    set excludeLowercase(value: boolean | cdktn.IResolvable);
    resetExcludeLowercase(): void;
    get excludeLowercaseInput(): boolean | cdktn.IResolvable | undefined;
    private _excludeNumbers?;
    get excludeNumbers(): boolean | cdktn.IResolvable;
    set excludeNumbers(value: boolean | cdktn.IResolvable);
    resetExcludeNumbers(): void;
    get excludeNumbersInput(): boolean | cdktn.IResolvable | undefined;
    private _excludePunctuation?;
    get excludePunctuation(): boolean | cdktn.IResolvable;
    set excludePunctuation(value: boolean | cdktn.IResolvable);
    resetExcludePunctuation(): void;
    get excludePunctuationInput(): boolean | cdktn.IResolvable | undefined;
    private _excludeUppercase?;
    get excludeUppercase(): boolean | cdktn.IResolvable;
    set excludeUppercase(value: boolean | cdktn.IResolvable);
    resetExcludeUppercase(): void;
    get excludeUppercaseInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _includeSpace?;
    get includeSpace(): boolean | cdktn.IResolvable;
    set includeSpace(value: boolean | cdktn.IResolvable);
    resetIncludeSpace(): void;
    get includeSpaceInput(): boolean | cdktn.IResolvable | undefined;
    private _passwordLength?;
    get passwordLength(): number;
    set passwordLength(value: number);
    resetPasswordLength(): void;
    get passwordLengthInput(): number | undefined;
    get randomPassword(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _requireEachIncludedType?;
    get requireEachIncludedType(): boolean | cdktn.IResolvable;
    set requireEachIncludedType(value: boolean | cdktn.IResolvable);
    resetRequireEachIncludedType(): void;
    get requireEachIncludedTypeInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
