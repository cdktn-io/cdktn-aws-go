import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsSecretRotationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/secretsmanager_secret_rotation#id DataAwsSecretRotation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/secretsmanager_secret_rotation#region DataAwsSecretRotation#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/secretsmanager_secret_rotation#secret_id DataAwsSecretRotation#secret_id}
    */
    readonly secretId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/secretsmanager_secret_rotation aws_secretsmanager_secret_rotation}
*/
export declare class DataAwsSecretRotation extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_secretsmanager_secret_rotation";
    /**
    * Generates CDKTN code for importing a DataAwsSecretRotation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsSecretRotation to import
    * @param importFromId The id of the existing DataAwsSecretRotation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/secretsmanager_secret_rotation#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsSecretRotation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/secretsmanager_secret_rotation aws_secretsmanager_secret_rotation} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsSecretRotationConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsSecretRotationConfig);
    private _externalSecretRotationMetadata;
    get externalSecretRotationMetadata(): DataAwsSecretRotation.ExternalSecretRotationMetadataPropertyList;
    get externalSecretRotationRoleArn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get rotationEnabled(): cdktn.IResolvable;
    get rotationLambdaArn(): string;
    private _rotationRules;
    get rotationRules(): DataAwsSecretRotation.RotationRulesPropertyList;
    private _secretId?;
    get secretId(): string;
    set secretId(value: string);
    get secretIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsSecretRotationExternalSecretRotationMetadataPropertyToTerraform(struct?: DataAwsSecretRotation.ExternalSecretRotationMetadataProperty): any;
export declare function dataAwsSecretRotationExternalSecretRotationMetadataPropertyToHclTerraform(struct?: DataAwsSecretRotation.ExternalSecretRotationMetadataProperty): any;
export declare function dataAwsSecretRotationRotationRulesPropertyToTerraform(struct?: DataAwsSecretRotation.RotationRulesProperty): any;
export declare function dataAwsSecretRotationRotationRulesPropertyToHclTerraform(struct?: DataAwsSecretRotation.RotationRulesProperty): any;
export declare namespace DataAwsSecretRotation {
    interface ExternalSecretRotationMetadataProperty {
    }
    class ExternalSecretRotationMetadataPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExternalSecretRotationMetadataProperty | undefined;
        set internalValue(value: ExternalSecretRotationMetadataProperty | undefined);
        get key(): string;
        get value(): string;
    }
    class ExternalSecretRotationMetadataPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExternalSecretRotationMetadataPropertyOutputReference;
    }
    interface RotationRulesProperty {
    }
    class RotationRulesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RotationRulesProperty | undefined;
        set internalValue(value: RotationRulesProperty | undefined);
        get automaticallyAfterDays(): number;
        get duration(): string;
        get scheduleExpression(): string;
    }
    class RotationRulesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RotationRulesPropertyOutputReference;
    }
}
