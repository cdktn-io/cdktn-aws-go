import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfTriggerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codecommit_trigger#id TfTrigger#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codecommit_trigger#region TfTrigger#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codecommit_trigger#repository_name TfTrigger#repository_name}
    */
    readonly repositoryName: string;
    /**
    * trigger block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codecommit_trigger#trigger TfTrigger#trigger}
    */
    readonly trigger: TfTrigger.TriggerProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codecommit_trigger aws_codecommit_trigger}
*/
export declare class TfTrigger extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_codecommit_trigger";
    /**
    * Generates CDKTN code for importing a TfTrigger resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfTrigger to import
    * @param importFromId The id of the existing TfTrigger that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codecommit_trigger#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfTrigger to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codecommit_trigger aws_codecommit_trigger} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfTriggerConfig
    */
    constructor(scope: Construct, id: string, config: TfTriggerConfig);
    get configurationId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _repositoryName?;
    get repositoryName(): string;
    set repositoryName(value: string);
    get repositoryNameInput(): string | undefined;
    private _trigger;
    get trigger(): TfTrigger.TriggerPropertyList;
    putTrigger(value: TfTrigger.TriggerProperty[] | cdktn.IResolvable): void;
    get triggerInput(): cdktn.IResolvable | TfTrigger.TriggerProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfTriggerTriggerPropertyToTerraform(struct?: TfTrigger.TriggerProperty | cdktn.IResolvable): any;
export declare function tfTriggerTriggerPropertyToHclTerraform(struct?: TfTrigger.TriggerProperty | cdktn.IResolvable): any;
export declare namespace TfTrigger {
    interface TriggerProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codecommit_trigger#branches TfTrigger#branches}
        */
        readonly branches?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codecommit_trigger#custom_data TfTrigger#custom_data}
        */
        readonly customData?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codecommit_trigger#destination_arn TfTrigger#destination_arn}
        */
        readonly destinationArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codecommit_trigger#events TfTrigger#events}
        */
        readonly events: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codecommit_trigger#name TfTrigger#name}
        */
        readonly name: string;
    }
    class TriggerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TriggerProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TriggerProperty | cdktn.IResolvable | undefined);
        private _branches?;
        get branches(): string[];
        set branches(value: string[]);
        resetBranches(): void;
        get branchesInput(): string[] | undefined;
        private _customData?;
        get customData(): string;
        set customData(value: string);
        resetCustomData(): void;
        get customDataInput(): string | undefined;
        private _destinationArn?;
        get destinationArn(): string;
        set destinationArn(value: string);
        get destinationArnInput(): string | undefined;
        private _events?;
        get events(): string[];
        set events(value: string[]);
        get eventsInput(): string[] | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    class TriggerPropertyList extends cdktn.ComplexList {
        internalValue?: TriggerProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TriggerPropertyOutputReference;
    }
}
