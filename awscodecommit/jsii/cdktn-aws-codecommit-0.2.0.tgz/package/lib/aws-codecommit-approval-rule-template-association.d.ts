import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfApprovalRuleTemplateAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codecommit_approval_rule_template_association#approval_rule_template_name TfApprovalRuleTemplateAssociation#approval_rule_template_name}
    */
    readonly approvalRuleTemplateName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codecommit_approval_rule_template_association#id TfApprovalRuleTemplateAssociation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codecommit_approval_rule_template_association#region TfApprovalRuleTemplateAssociation#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codecommit_approval_rule_template_association#repository_name TfApprovalRuleTemplateAssociation#repository_name}
    */
    readonly repositoryName: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codecommit_approval_rule_template_association aws_codecommit_approval_rule_template_association}
*/
export declare class TfApprovalRuleTemplateAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_codecommit_approval_rule_template_association";
    /**
    * Generates CDKTN code for importing a TfApprovalRuleTemplateAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfApprovalRuleTemplateAssociation to import
    * @param importFromId The id of the existing TfApprovalRuleTemplateAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codecommit_approval_rule_template_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfApprovalRuleTemplateAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codecommit_approval_rule_template_association aws_codecommit_approval_rule_template_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfApprovalRuleTemplateAssociationConfig
    */
    constructor(scope: Construct, id: string, config: TfApprovalRuleTemplateAssociationConfig);
    private _approvalRuleTemplateName?;
    get approvalRuleTemplateName(): string;
    set approvalRuleTemplateName(value: string);
    get approvalRuleTemplateNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _repositoryName?;
    get repositoryName(): string;
    set repositoryName(value: string);
    get repositoryNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
