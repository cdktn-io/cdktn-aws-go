import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAppMonitorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rum_app_monitor#cw_log_enabled AwsAppMonitor#cw_log_enabled}
    */
    readonly cwLogEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rum_app_monitor#domain AwsAppMonitor#domain}
    */
    readonly domain?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rum_app_monitor#domain_list AwsAppMonitor#domain_list}
    */
    readonly domainList?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rum_app_monitor#id AwsAppMonitor#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rum_app_monitor#name AwsAppMonitor#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rum_app_monitor#region AwsAppMonitor#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rum_app_monitor#tags AwsAppMonitor#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rum_app_monitor#tags_all AwsAppMonitor#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * app_monitor_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rum_app_monitor#app_monitor_configuration AwsAppMonitor#app_monitor_configuration}
    */
    readonly appMonitorConfiguration?: AwsAppMonitor.AppMonitorConfigurationProperty;
    /**
    * custom_events block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rum_app_monitor#custom_events AwsAppMonitor#custom_events}
    */
    readonly customEvents?: AwsAppMonitor.CustomEventsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rum_app_monitor aws_rum_app_monitor}
*/
export declare class AwsAppMonitor extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_rum_app_monitor";
    /**
    * Generates CDKTN code for importing a AwsAppMonitor resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAppMonitor to import
    * @param importFromId The id of the existing AwsAppMonitor that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rum_app_monitor#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAppMonitor to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rum_app_monitor aws_rum_app_monitor} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAppMonitorConfig
    */
    constructor(scope: Construct, id: string, config: AwsAppMonitorConfig);
    get appMonitorId(): string;
    get arn(): string;
    private _cwLogEnabled?;
    get cwLogEnabled(): boolean | cdktn.IResolvable;
    set cwLogEnabled(value: boolean | cdktn.IResolvable);
    resetCwLogEnabled(): void;
    get cwLogEnabledInput(): boolean | cdktn.IResolvable | undefined;
    get cwLogGroup(): string;
    private _domain?;
    get domain(): string;
    set domain(value: string);
    resetDomain(): void;
    get domainInput(): string | undefined;
    private _domainList?;
    get domainList(): string[];
    set domainList(value: string[]);
    resetDomainList(): void;
    get domainListInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _appMonitorConfiguration;
    get appMonitorConfiguration(): AwsAppMonitor.AppMonitorConfigurationPropertyOutputReference;
    putAppMonitorConfiguration(value: AwsAppMonitor.AppMonitorConfigurationProperty): void;
    resetAppMonitorConfiguration(): void;
    get appMonitorConfigurationInput(): AwsAppMonitor.AppMonitorConfigurationProperty | undefined;
    private _customEvents;
    get customEvents(): AwsAppMonitor.CustomEventsPropertyOutputReference;
    putCustomEvents(value: AwsAppMonitor.CustomEventsProperty): void;
    resetCustomEvents(): void;
    get customEventsInput(): AwsAppMonitor.CustomEventsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsAppMonitorAppMonitorConfigurationPropertyToTerraform(struct?: AwsAppMonitor.AppMonitorConfigurationPropertyOutputReference | AwsAppMonitor.AppMonitorConfigurationProperty): any;
export declare function awsAppMonitorAppMonitorConfigurationPropertyToHclTerraform(struct?: AwsAppMonitor.AppMonitorConfigurationPropertyOutputReference | AwsAppMonitor.AppMonitorConfigurationProperty): any;
export declare function awsAppMonitorCustomEventsPropertyToTerraform(struct?: AwsAppMonitor.CustomEventsPropertyOutputReference | AwsAppMonitor.CustomEventsProperty): any;
export declare function awsAppMonitorCustomEventsPropertyToHclTerraform(struct?: AwsAppMonitor.CustomEventsPropertyOutputReference | AwsAppMonitor.CustomEventsProperty): any;
export declare namespace AwsAppMonitor {
    interface AppMonitorConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rum_app_monitor#allow_cookies AwsAppMonitor#allow_cookies}
        */
        readonly allowCookies?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rum_app_monitor#enable_xray AwsAppMonitor#enable_xray}
        */
        readonly enableXray?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rum_app_monitor#excluded_pages AwsAppMonitor#excluded_pages}
        */
        readonly excludedPages?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rum_app_monitor#favorite_pages AwsAppMonitor#favorite_pages}
        */
        readonly favoritePages?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rum_app_monitor#guest_role_arn AwsAppMonitor#guest_role_arn}
        */
        readonly guestRoleArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rum_app_monitor#identity_pool_id AwsAppMonitor#identity_pool_id}
        */
        readonly identityPoolId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rum_app_monitor#included_pages AwsAppMonitor#included_pages}
        */
        readonly includedPages?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rum_app_monitor#session_sample_rate AwsAppMonitor#session_sample_rate}
        */
        readonly sessionSampleRate?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rum_app_monitor#telemetries AwsAppMonitor#telemetries}
        */
        readonly telemetries?: string[];
    }
    class AppMonitorConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AppMonitorConfigurationProperty | undefined;
        set internalValue(value: AppMonitorConfigurationProperty | undefined);
        private _allowCookies?;
        get allowCookies(): boolean | cdktn.IResolvable;
        set allowCookies(value: boolean | cdktn.IResolvable);
        resetAllowCookies(): void;
        get allowCookiesInput(): boolean | cdktn.IResolvable | undefined;
        private _enableXray?;
        get enableXray(): boolean | cdktn.IResolvable;
        set enableXray(value: boolean | cdktn.IResolvable);
        resetEnableXray(): void;
        get enableXrayInput(): boolean | cdktn.IResolvable | undefined;
        private _excludedPages?;
        get excludedPages(): string[];
        set excludedPages(value: string[]);
        resetExcludedPages(): void;
        get excludedPagesInput(): string[] | undefined;
        private _favoritePages?;
        get favoritePages(): string[];
        set favoritePages(value: string[]);
        resetFavoritePages(): void;
        get favoritePagesInput(): string[] | undefined;
        private _guestRoleArn?;
        get guestRoleArn(): string;
        set guestRoleArn(value: string);
        resetGuestRoleArn(): void;
        get guestRoleArnInput(): string | undefined;
        private _identityPoolId?;
        get identityPoolId(): string;
        set identityPoolId(value: string);
        resetIdentityPoolId(): void;
        get identityPoolIdInput(): string | undefined;
        private _includedPages?;
        get includedPages(): string[];
        set includedPages(value: string[]);
        resetIncludedPages(): void;
        get includedPagesInput(): string[] | undefined;
        private _sessionSampleRate?;
        get sessionSampleRate(): number;
        set sessionSampleRate(value: number);
        resetSessionSampleRate(): void;
        get sessionSampleRateInput(): number | undefined;
        private _telemetries?;
        get telemetries(): string[];
        set telemetries(value: string[]);
        resetTelemetries(): void;
        get telemetriesInput(): string[] | undefined;
    }
    interface CustomEventsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rum_app_monitor#status AwsAppMonitor#status}
        */
        readonly status?: string;
    }
    class CustomEventsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CustomEventsProperty | undefined;
        set internalValue(value: CustomEventsProperty | undefined);
        private _status?;
        get status(): string;
        set status(value: string);
        resetStatus(): void;
        get statusInput(): string | undefined;
    }
}
