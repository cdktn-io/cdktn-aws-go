import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsTopicRuleDestinationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule_destination#enabled AwsTopicRuleDestination#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule_destination#id AwsTopicRuleDestination#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule_destination#region AwsTopicRuleDestination#region}
    */
    readonly region?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule_destination#timeouts AwsTopicRuleDestination#timeouts}
    */
    readonly timeouts?: AwsTopicRuleDestination.TimeoutsProperty;
    /**
    * vpc_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule_destination#vpc_configuration AwsTopicRuleDestination#vpc_configuration}
    */
    readonly vpcConfiguration: AwsTopicRuleDestination.VpcConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule_destination aws_iot_topic_rule_destination}
*/
export declare class AwsTopicRuleDestination extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_iot_topic_rule_destination";
    /**
    * Generates CDKTN code for importing a AwsTopicRuleDestination resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsTopicRuleDestination to import
    * @param importFromId The id of the existing AwsTopicRuleDestination that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule_destination#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsTopicRuleDestination to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule_destination aws_iot_topic_rule_destination} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsTopicRuleDestinationConfig
    */
    constructor(scope: Construct, id: string, config: AwsTopicRuleDestinationConfig);
    get arn(): string;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _timeouts;
    get timeouts(): AwsTopicRuleDestination.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsTopicRuleDestination.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsTopicRuleDestination.TimeoutsProperty | undefined;
    private _vpcConfiguration;
    get vpcConfiguration(): AwsTopicRuleDestination.VpcConfigurationPropertyOutputReference;
    putVpcConfiguration(value: AwsTopicRuleDestination.VpcConfigurationProperty): void;
    get vpcConfigurationInput(): AwsTopicRuleDestination.VpcConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsTopicRuleDestinationTimeoutsPropertyToTerraform(struct?: AwsTopicRuleDestination.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleDestinationTimeoutsPropertyToHclTerraform(struct?: AwsTopicRuleDestination.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleDestinationVpcConfigurationPropertyToTerraform(struct?: AwsTopicRuleDestination.VpcConfigurationPropertyOutputReference | AwsTopicRuleDestination.VpcConfigurationProperty): any;
export declare function awsTopicRuleDestinationVpcConfigurationPropertyToHclTerraform(struct?: AwsTopicRuleDestination.VpcConfigurationPropertyOutputReference | AwsTopicRuleDestination.VpcConfigurationProperty): any;
export declare namespace AwsTopicRuleDestination {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule_destination#create AwsTopicRuleDestination#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule_destination#delete AwsTopicRuleDestination#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule_destination#update AwsTopicRuleDestination#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface VpcConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule_destination#role_arn AwsTopicRuleDestination#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule_destination#security_groups AwsTopicRuleDestination#security_groups}
        */
        readonly securityGroups?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule_destination#subnet_ids AwsTopicRuleDestination#subnet_ids}
        */
        readonly subnetIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule_destination#vpc_id AwsTopicRuleDestination#vpc_id}
        */
        readonly vpcId: string;
    }
    class VpcConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcConfigurationProperty | undefined;
        set internalValue(value: VpcConfigurationProperty | undefined);
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _securityGroups?;
        get securityGroups(): string[];
        set securityGroups(value: string[]);
        resetSecurityGroups(): void;
        get securityGroupsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
        private _vpcId?;
        get vpcId(): string;
        set vpcId(value: string);
        get vpcIdInput(): string | undefined;
    }
}
