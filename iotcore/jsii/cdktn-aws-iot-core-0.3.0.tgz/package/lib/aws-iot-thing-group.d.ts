import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsThingGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_thing_group#id AwsThingGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_thing_group#name AwsThingGroup#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_thing_group#parent_group_name AwsThingGroup#parent_group_name}
    */
    readonly parentGroupName?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_thing_group#region AwsThingGroup#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_thing_group#tags AwsThingGroup#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_thing_group#tags_all AwsThingGroup#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * properties block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_thing_group#properties AwsThingGroup#properties}
    */
    readonly properties?: AwsThingGroup.PropertiesProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_thing_group aws_iot_thing_group}
*/
export declare class AwsThingGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_iot_thing_group";
    /**
    * Generates CDKTN code for importing a AwsThingGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsThingGroup to import
    * @param importFromId The id of the existing AwsThingGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_thing_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsThingGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_thing_group aws_iot_thing_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsThingGroupConfig
    */
    constructor(scope: Construct, id: string, config: AwsThingGroupConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metadata;
    get metadata(): AwsThingGroup.MetadataPropertyList;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parentGroupName?;
    get parentGroupName(): string;
    set parentGroupName(value: string);
    resetParentGroupName(): void;
    get parentGroupNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get version(): number;
    private _properties;
    get properties(): AwsThingGroup.PropertiesPropertyOutputReference;
    putProperties(value: AwsThingGroup.PropertiesProperty): void;
    resetProperties(): void;
    get propertiesInput(): AwsThingGroup.PropertiesProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsThingGroupRootToParentGroupsPropertyToTerraform(struct?: AwsThingGroup.RootToParentGroupsProperty): any;
export declare function awsThingGroupRootToParentGroupsPropertyToHclTerraform(struct?: AwsThingGroup.RootToParentGroupsProperty): any;
export declare function awsThingGroupMetadataPropertyToTerraform(struct?: AwsThingGroup.MetadataProperty): any;
export declare function awsThingGroupMetadataPropertyToHclTerraform(struct?: AwsThingGroup.MetadataProperty): any;
export declare function awsThingGroupAttributePayloadPropertyToTerraform(struct?: AwsThingGroup.AttributePayloadPropertyOutputReference | AwsThingGroup.AttributePayloadProperty): any;
export declare function awsThingGroupAttributePayloadPropertyToHclTerraform(struct?: AwsThingGroup.AttributePayloadPropertyOutputReference | AwsThingGroup.AttributePayloadProperty): any;
export declare function awsThingGroupPropertiesPropertyToTerraform(struct?: AwsThingGroup.PropertiesPropertyOutputReference | AwsThingGroup.PropertiesProperty): any;
export declare function awsThingGroupPropertiesPropertyToHclTerraform(struct?: AwsThingGroup.PropertiesPropertyOutputReference | AwsThingGroup.PropertiesProperty): any;
export declare namespace AwsThingGroup {
    interface RootToParentGroupsProperty {
    }
    class RootToParentGroupsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RootToParentGroupsProperty | undefined;
        set internalValue(value: RootToParentGroupsProperty | undefined);
        get groupArn(): string;
        get groupName(): string;
    }
    class RootToParentGroupsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RootToParentGroupsPropertyOutputReference;
    }
    interface MetadataProperty {
    }
    class MetadataPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MetadataProperty | undefined;
        set internalValue(value: MetadataProperty | undefined);
        get creationDate(): string;
        get parentGroupName(): string;
        private _rootToParentGroups;
        get rootToParentGroups(): RootToParentGroupsPropertyList;
    }
    class MetadataPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MetadataPropertyOutputReference;
    }
    interface AttributePayloadProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_thing_group#attributes AwsThingGroup#attributes}
        */
        readonly attributes?: {
            [key: string]: string;
        };
    }
    class AttributePayloadPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AttributePayloadProperty | undefined;
        set internalValue(value: AttributePayloadProperty | undefined);
        private _attributes?;
        get attributes(): {
            [key: string]: string;
        };
        set attributes(value: {
            [key: string]: string;
        });
        resetAttributes(): void;
        get attributesInput(): {
            [key: string]: string;
        } | undefined;
    }
    interface PropertiesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_thing_group#description AwsThingGroup#description}
        */
        readonly description?: string;
        /**
        * attribute_payload block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_thing_group#attribute_payload AwsThingGroup#attribute_payload}
        */
        readonly attributePayload?: AttributePayloadProperty;
    }
    class PropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PropertiesProperty | undefined;
        set internalValue(value: PropertiesProperty | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _attributePayload;
        get attributePayload(): AttributePayloadPropertyOutputReference;
        putAttributePayload(value: AttributePayloadProperty): void;
        resetAttributePayload(): void;
        get attributePayloadInput(): AttributePayloadProperty | undefined;
    }
}
