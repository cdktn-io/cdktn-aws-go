import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsProvisioningTemplateConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_provisioning_template#description AwsProvisioningTemplate#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_provisioning_template#enabled AwsProvisioningTemplate#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_provisioning_template#id AwsProvisioningTemplate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_provisioning_template#name AwsProvisioningTemplate#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_provisioning_template#provisioning_role_arn AwsProvisioningTemplate#provisioning_role_arn}
    */
    readonly provisioningRoleArn: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_provisioning_template#region AwsProvisioningTemplate#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_provisioning_template#tags AwsProvisioningTemplate#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_provisioning_template#tags_all AwsProvisioningTemplate#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_provisioning_template#template_body AwsProvisioningTemplate#template_body}
    */
    readonly templateBody: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_provisioning_template#type AwsProvisioningTemplate#type}
    */
    readonly type?: string;
    /**
    * pre_provisioning_hook block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_provisioning_template#pre_provisioning_hook AwsProvisioningTemplate#pre_provisioning_hook}
    */
    readonly preProvisioningHook?: AwsProvisioningTemplate.PreProvisioningHookProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_provisioning_template aws_iot_provisioning_template}
*/
export declare class AwsProvisioningTemplate extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_iot_provisioning_template";
    /**
    * Generates CDKTN code for importing a AwsProvisioningTemplate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsProvisioningTemplate to import
    * @param importFromId The id of the existing AwsProvisioningTemplate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_provisioning_template#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsProvisioningTemplate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_provisioning_template aws_iot_provisioning_template} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsProvisioningTemplateConfig
    */
    constructor(scope: Construct, id: string, config: AwsProvisioningTemplateConfig);
    get arn(): string;
    get defaultVersionId(): number;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _provisioningRoleArn?;
    get provisioningRoleArn(): string;
    set provisioningRoleArn(value: string);
    get provisioningRoleArnInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _templateBody?;
    get templateBody(): string;
    set templateBody(value: string);
    get templateBodyInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _preProvisioningHook;
    get preProvisioningHook(): AwsProvisioningTemplate.PreProvisioningHookPropertyOutputReference;
    putPreProvisioningHook(value: AwsProvisioningTemplate.PreProvisioningHookProperty): void;
    resetPreProvisioningHook(): void;
    get preProvisioningHookInput(): AwsProvisioningTemplate.PreProvisioningHookProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsProvisioningTemplatePreProvisioningHookPropertyToTerraform(struct?: AwsProvisioningTemplate.PreProvisioningHookPropertyOutputReference | AwsProvisioningTemplate.PreProvisioningHookProperty): any;
export declare function awsProvisioningTemplatePreProvisioningHookPropertyToHclTerraform(struct?: AwsProvisioningTemplate.PreProvisioningHookPropertyOutputReference | AwsProvisioningTemplate.PreProvisioningHookProperty): any;
export declare namespace AwsProvisioningTemplate {
    interface PreProvisioningHookProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_provisioning_template#payload_version AwsProvisioningTemplate#payload_version}
        */
        readonly payloadVersion?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_provisioning_template#target_arn AwsProvisioningTemplate#target_arn}
        */
        readonly targetArn: string;
    }
    class PreProvisioningHookPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PreProvisioningHookProperty | undefined;
        set internalValue(value: PreProvisioningHookProperty | undefined);
        private _payloadVersion?;
        get payloadVersion(): string;
        set payloadVersion(value: string);
        resetPayloadVersion(): void;
        get payloadVersionInput(): string | undefined;
        private _targetArn?;
        get targetArn(): string;
        set targetArn(value: string);
        get targetArnInput(): string | undefined;
    }
}
