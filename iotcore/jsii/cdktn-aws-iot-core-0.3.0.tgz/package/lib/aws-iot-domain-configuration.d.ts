import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDomainConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_domain_configuration#application_protocol AwsDomainConfiguration#application_protocol}
    */
    readonly applicationProtocol?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_domain_configuration#authentication_type AwsDomainConfiguration#authentication_type}
    */
    readonly authenticationType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_domain_configuration#domain_name AwsDomainConfiguration#domain_name}
    */
    readonly domainName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_domain_configuration#id AwsDomainConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_domain_configuration#name AwsDomainConfiguration#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_domain_configuration#region AwsDomainConfiguration#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_domain_configuration#server_certificate_arns AwsDomainConfiguration#server_certificate_arns}
    */
    readonly serverCertificateArns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_domain_configuration#service_type AwsDomainConfiguration#service_type}
    */
    readonly serviceType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_domain_configuration#status AwsDomainConfiguration#status}
    */
    readonly status?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_domain_configuration#tags AwsDomainConfiguration#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_domain_configuration#tags_all AwsDomainConfiguration#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_domain_configuration#validation_certificate_arn AwsDomainConfiguration#validation_certificate_arn}
    */
    readonly validationCertificateArn?: string;
    /**
    * authorizer_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_domain_configuration#authorizer_config AwsDomainConfiguration#authorizer_config}
    */
    readonly authorizerConfig?: AwsDomainConfiguration.AuthorizerConfigProperty;
    /**
    * tls_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_domain_configuration#tls_config AwsDomainConfiguration#tls_config}
    */
    readonly tlsConfig?: AwsDomainConfiguration.TlsConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_domain_configuration aws_iot_domain_configuration}
*/
export declare class AwsDomainConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_iot_domain_configuration";
    /**
    * Generates CDKTN code for importing a AwsDomainConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDomainConfiguration to import
    * @param importFromId The id of the existing AwsDomainConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_domain_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDomainConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_domain_configuration aws_iot_domain_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDomainConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsDomainConfigurationConfig);
    private _applicationProtocol?;
    get applicationProtocol(): string;
    set applicationProtocol(value: string);
    resetApplicationProtocol(): void;
    get applicationProtocolInput(): string | undefined;
    get arn(): string;
    private _authenticationType?;
    get authenticationType(): string;
    set authenticationType(value: string);
    resetAuthenticationType(): void;
    get authenticationTypeInput(): string | undefined;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    resetDomainName(): void;
    get domainNameInput(): string | undefined;
    get domainType(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _serverCertificateArns?;
    get serverCertificateArns(): string[];
    set serverCertificateArns(value: string[]);
    resetServerCertificateArns(): void;
    get serverCertificateArnsInput(): string[] | undefined;
    private _serviceType?;
    get serviceType(): string;
    set serviceType(value: string);
    resetServiceType(): void;
    get serviceTypeInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _validationCertificateArn?;
    get validationCertificateArn(): string;
    set validationCertificateArn(value: string);
    resetValidationCertificateArn(): void;
    get validationCertificateArnInput(): string | undefined;
    private _authorizerConfig;
    get authorizerConfig(): AwsDomainConfiguration.AuthorizerConfigPropertyOutputReference;
    putAuthorizerConfig(value: AwsDomainConfiguration.AuthorizerConfigProperty): void;
    resetAuthorizerConfig(): void;
    get authorizerConfigInput(): AwsDomainConfiguration.AuthorizerConfigProperty | undefined;
    private _tlsConfig;
    get tlsConfig(): AwsDomainConfiguration.TlsConfigPropertyOutputReference;
    putTlsConfig(value: AwsDomainConfiguration.TlsConfigProperty): void;
    resetTlsConfig(): void;
    get tlsConfigInput(): AwsDomainConfiguration.TlsConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDomainConfigurationAuthorizerConfigPropertyToTerraform(struct?: AwsDomainConfiguration.AuthorizerConfigPropertyOutputReference | AwsDomainConfiguration.AuthorizerConfigProperty): any;
export declare function awsDomainConfigurationAuthorizerConfigPropertyToHclTerraform(struct?: AwsDomainConfiguration.AuthorizerConfigPropertyOutputReference | AwsDomainConfiguration.AuthorizerConfigProperty): any;
export declare function awsDomainConfigurationTlsConfigPropertyToTerraform(struct?: AwsDomainConfiguration.TlsConfigPropertyOutputReference | AwsDomainConfiguration.TlsConfigProperty): any;
export declare function awsDomainConfigurationTlsConfigPropertyToHclTerraform(struct?: AwsDomainConfiguration.TlsConfigPropertyOutputReference | AwsDomainConfiguration.TlsConfigProperty): any;
export declare namespace AwsDomainConfiguration {
    interface AuthorizerConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_domain_configuration#allow_authorizer_override AwsDomainConfiguration#allow_authorizer_override}
        */
        readonly allowAuthorizerOverride?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_domain_configuration#default_authorizer_name AwsDomainConfiguration#default_authorizer_name}
        */
        readonly defaultAuthorizerName?: string;
    }
    class AuthorizerConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AuthorizerConfigProperty | undefined;
        set internalValue(value: AuthorizerConfigProperty | undefined);
        private _allowAuthorizerOverride?;
        get allowAuthorizerOverride(): boolean | cdktn.IResolvable;
        set allowAuthorizerOverride(value: boolean | cdktn.IResolvable);
        resetAllowAuthorizerOverride(): void;
        get allowAuthorizerOverrideInput(): boolean | cdktn.IResolvable | undefined;
        private _defaultAuthorizerName?;
        get defaultAuthorizerName(): string;
        set defaultAuthorizerName(value: string);
        resetDefaultAuthorizerName(): void;
        get defaultAuthorizerNameInput(): string | undefined;
    }
    interface TlsConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_domain_configuration#security_policy AwsDomainConfiguration#security_policy}
        */
        readonly securityPolicy?: string;
    }
    class TlsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TlsConfigProperty | undefined;
        set internalValue(value: TlsConfigProperty | undefined);
        private _securityPolicy?;
        get securityPolicy(): string;
        set securityPolicy(value: string);
        resetSecurityPolicy(): void;
        get securityPolicyInput(): string | undefined;
    }
}
