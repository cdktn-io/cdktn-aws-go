import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsLoggingOptionsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_logging_options#default_log_level AwsLoggingOptions#default_log_level}
    */
    readonly defaultLogLevel: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_logging_options#disable_all_logs AwsLoggingOptions#disable_all_logs}
    */
    readonly disableAllLogs?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_logging_options#id AwsLoggingOptions#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_logging_options#region AwsLoggingOptions#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_logging_options#role_arn AwsLoggingOptions#role_arn}
    */
    readonly roleArn: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_logging_options aws_iot_logging_options}
*/
export declare class AwsLoggingOptions extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_iot_logging_options";
    /**
    * Generates CDKTN code for importing a AwsLoggingOptions resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsLoggingOptions to import
    * @param importFromId The id of the existing AwsLoggingOptions that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_logging_options#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsLoggingOptions to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_logging_options aws_iot_logging_options} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsLoggingOptionsConfig
    */
    constructor(scope: Construct, id: string, config: AwsLoggingOptionsConfig);
    private _defaultLogLevel?;
    get defaultLogLevel(): string;
    set defaultLogLevel(value: string);
    get defaultLogLevelInput(): string | undefined;
    private _disableAllLogs?;
    get disableAllLogs(): boolean | cdktn.IResolvable;
    set disableAllLogs(value: boolean | cdktn.IResolvable);
    resetDisableAllLogs(): void;
    get disableAllLogsInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
