import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsTopicRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#description AwsTopicRule#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#enabled AwsTopicRule#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#id AwsTopicRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#name AwsTopicRule#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#region AwsTopicRule#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#sql AwsTopicRule#sql}
    */
    readonly sql: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#sql_version AwsTopicRule#sql_version}
    */
    readonly sqlVersion: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#tags AwsTopicRule#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#tags_all AwsTopicRule#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * cloudwatch_alarm block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#cloudwatch_alarm AwsTopicRule#cloudwatch_alarm}
    */
    readonly cloudwatchAlarm?: AwsTopicRule.CloudwatchAlarmProperty[] | cdktn.IResolvable;
    /**
    * cloudwatch_logs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#cloudwatch_logs AwsTopicRule#cloudwatch_logs}
    */
    readonly cloudwatchLogs?: AwsTopicRule.CloudwatchLogsProperty[] | cdktn.IResolvable;
    /**
    * cloudwatch_metric block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#cloudwatch_metric AwsTopicRule#cloudwatch_metric}
    */
    readonly cloudwatchMetric?: AwsTopicRule.CloudwatchMetricProperty[] | cdktn.IResolvable;
    /**
    * dynamodb block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#dynamodb AwsTopicRule#dynamodb}
    */
    readonly dynamodb?: AwsTopicRule.DynamodbProperty[] | cdktn.IResolvable;
    /**
    * dynamodbv2 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#dynamodbv2 AwsTopicRule#dynamodbv2}
    */
    readonly dynamodbv2?: AwsTopicRule.Dynamodbv2Property[] | cdktn.IResolvable;
    /**
    * elasticsearch block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#elasticsearch AwsTopicRule#elasticsearch}
    */
    readonly elasticsearch?: AwsTopicRule.ElasticsearchProperty[] | cdktn.IResolvable;
    /**
    * error_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#error_action AwsTopicRule#error_action}
    */
    readonly errorAction?: AwsTopicRule.ErrorActionProperty;
    /**
    * firehose block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#firehose AwsTopicRule#firehose}
    */
    readonly firehose?: AwsTopicRule.FirehoseProperty[] | cdktn.IResolvable;
    /**
    * http block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#http AwsTopicRule#http}
    */
    readonly http?: AwsTopicRule.HttpProperty[] | cdktn.IResolvable;
    /**
    * iot_analytics block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#iot_analytics AwsTopicRule#iot_analytics}
    */
    readonly iotAnalytics?: AwsTopicRule.IotAnalyticsProperty[] | cdktn.IResolvable;
    /**
    * iot_events block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#iot_events AwsTopicRule#iot_events}
    */
    readonly iotEvents?: AwsTopicRule.IotEventsProperty[] | cdktn.IResolvable;
    /**
    * kafka block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#kafka AwsTopicRule#kafka}
    */
    readonly kafka?: AwsTopicRule.KafkaProperty[] | cdktn.IResolvable;
    /**
    * kinesis block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#kinesis AwsTopicRule#kinesis}
    */
    readonly kinesis?: AwsTopicRule.KinesisProperty[] | cdktn.IResolvable;
    /**
    * lambda block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#lambda AwsTopicRule#lambda}
    */
    readonly lambda?: AwsTopicRule.LambdaProperty[] | cdktn.IResolvable;
    /**
    * republish block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#republish AwsTopicRule#republish}
    */
    readonly republish?: AwsTopicRule.RepublishProperty[] | cdktn.IResolvable;
    /**
    * s3 block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#s3 AwsTopicRule#s3}
    */
    readonly s3?: AwsTopicRule.S3Property[] | cdktn.IResolvable;
    /**
    * sns block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#sns AwsTopicRule#sns}
    */
    readonly sns?: AwsTopicRule.SnsProperty[] | cdktn.IResolvable;
    /**
    * sqs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#sqs AwsTopicRule#sqs}
    */
    readonly sqs?: AwsTopicRule.SqsProperty[] | cdktn.IResolvable;
    /**
    * step_functions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#step_functions AwsTopicRule#step_functions}
    */
    readonly stepFunctions?: AwsTopicRule.StepFunctionsProperty[] | cdktn.IResolvable;
    /**
    * timestream block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#timestream AwsTopicRule#timestream}
    */
    readonly timestream?: AwsTopicRule.TimestreamProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule aws_iot_topic_rule}
*/
export declare class AwsTopicRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_iot_topic_rule";
    /**
    * Generates CDKTN code for importing a AwsTopicRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsTopicRule to import
    * @param importFromId The id of the existing AwsTopicRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsTopicRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule aws_iot_topic_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsTopicRuleConfig
    */
    constructor(scope: Construct, id: string, config: AwsTopicRuleConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _sql?;
    get sql(): string;
    set sql(value: string);
    get sqlInput(): string | undefined;
    private _sqlVersion?;
    get sqlVersion(): string;
    set sqlVersion(value: string);
    get sqlVersionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _cloudwatchAlarm;
    get cloudwatchAlarm(): AwsTopicRule.CloudwatchAlarmPropertyList;
    putCloudwatchAlarm(value: AwsTopicRule.CloudwatchAlarmProperty[] | cdktn.IResolvable): void;
    resetCloudwatchAlarm(): void;
    get cloudwatchAlarmInput(): cdktn.IResolvable | AwsTopicRule.CloudwatchAlarmProperty[] | undefined;
    private _cloudwatchLogs;
    get cloudwatchLogs(): AwsTopicRule.CloudwatchLogsPropertyList;
    putCloudwatchLogs(value: AwsTopicRule.CloudwatchLogsProperty[] | cdktn.IResolvable): void;
    resetCloudwatchLogs(): void;
    get cloudwatchLogsInput(): cdktn.IResolvable | AwsTopicRule.CloudwatchLogsProperty[] | undefined;
    private _cloudwatchMetric;
    get cloudwatchMetric(): AwsTopicRule.CloudwatchMetricPropertyList;
    putCloudwatchMetric(value: AwsTopicRule.CloudwatchMetricProperty[] | cdktn.IResolvable): void;
    resetCloudwatchMetric(): void;
    get cloudwatchMetricInput(): cdktn.IResolvable | AwsTopicRule.CloudwatchMetricProperty[] | undefined;
    private _dynamodb;
    get dynamodb(): AwsTopicRule.DynamodbPropertyList;
    putDynamodb(value: AwsTopicRule.DynamodbProperty[] | cdktn.IResolvable): void;
    resetDynamodb(): void;
    get dynamodbInput(): cdktn.IResolvable | AwsTopicRule.DynamodbProperty[] | undefined;
    private _dynamodbv2;
    get dynamodbv2(): AwsTopicRule.Dynamodbv2PropertyList;
    putDynamodbv2(value: AwsTopicRule.Dynamodbv2Property[] | cdktn.IResolvable): void;
    resetDynamodbv2(): void;
    get dynamodbv2Input(): cdktn.IResolvable | AwsTopicRule.Dynamodbv2Property[] | undefined;
    private _elasticsearch;
    get elasticsearch(): AwsTopicRule.ElasticsearchPropertyList;
    putElasticsearch(value: AwsTopicRule.ElasticsearchProperty[] | cdktn.IResolvable): void;
    resetElasticsearch(): void;
    get elasticsearchInput(): cdktn.IResolvable | AwsTopicRule.ElasticsearchProperty[] | undefined;
    private _errorAction;
    get errorAction(): AwsTopicRule.ErrorActionPropertyOutputReference;
    putErrorAction(value: AwsTopicRule.ErrorActionProperty): void;
    resetErrorAction(): void;
    get errorActionInput(): AwsTopicRule.ErrorActionProperty | undefined;
    private _firehose;
    get firehose(): AwsTopicRule.FirehosePropertyList;
    putFirehose(value: AwsTopicRule.FirehoseProperty[] | cdktn.IResolvable): void;
    resetFirehose(): void;
    get firehoseInput(): cdktn.IResolvable | AwsTopicRule.FirehoseProperty[] | undefined;
    private _http;
    get http(): AwsTopicRule.HttpPropertyList;
    putHttp(value: AwsTopicRule.HttpProperty[] | cdktn.IResolvable): void;
    resetHttp(): void;
    get httpInput(): cdktn.IResolvable | AwsTopicRule.HttpProperty[] | undefined;
    private _iotAnalytics;
    get iotAnalytics(): AwsTopicRule.IotAnalyticsPropertyList;
    putIotAnalytics(value: AwsTopicRule.IotAnalyticsProperty[] | cdktn.IResolvable): void;
    resetIotAnalytics(): void;
    get iotAnalyticsInput(): cdktn.IResolvable | AwsTopicRule.IotAnalyticsProperty[] | undefined;
    private _iotEvents;
    get iotEvents(): AwsTopicRule.IotEventsPropertyList;
    putIotEvents(value: AwsTopicRule.IotEventsProperty[] | cdktn.IResolvable): void;
    resetIotEvents(): void;
    get iotEventsInput(): cdktn.IResolvable | AwsTopicRule.IotEventsProperty[] | undefined;
    private _kafka;
    get kafka(): AwsTopicRule.KafkaPropertyList;
    putKafka(value: AwsTopicRule.KafkaProperty[] | cdktn.IResolvable): void;
    resetKafka(): void;
    get kafkaInput(): cdktn.IResolvable | AwsTopicRule.KafkaProperty[] | undefined;
    private _kinesis;
    get kinesis(): AwsTopicRule.KinesisPropertyList;
    putKinesis(value: AwsTopicRule.KinesisProperty[] | cdktn.IResolvable): void;
    resetKinesis(): void;
    get kinesisInput(): cdktn.IResolvable | AwsTopicRule.KinesisProperty[] | undefined;
    private _lambda;
    get lambda(): AwsTopicRule.LambdaPropertyList;
    putLambda(value: AwsTopicRule.LambdaProperty[] | cdktn.IResolvable): void;
    resetLambda(): void;
    get lambdaInput(): cdktn.IResolvable | AwsTopicRule.LambdaProperty[] | undefined;
    private _republish;
    get republish(): AwsTopicRule.RepublishPropertyList;
    putRepublish(value: AwsTopicRule.RepublishProperty[] | cdktn.IResolvable): void;
    resetRepublish(): void;
    get republishInput(): cdktn.IResolvable | AwsTopicRule.RepublishProperty[] | undefined;
    private _s3;
    get s3(): AwsTopicRule.S3PropertyList;
    putS3(value: AwsTopicRule.S3Property[] | cdktn.IResolvable): void;
    resetS3(): void;
    get s3Input(): cdktn.IResolvable | AwsTopicRule.S3Property[] | undefined;
    private _sns;
    get sns(): AwsTopicRule.SnsPropertyList;
    putSns(value: AwsTopicRule.SnsProperty[] | cdktn.IResolvable): void;
    resetSns(): void;
    get snsInput(): cdktn.IResolvable | AwsTopicRule.SnsProperty[] | undefined;
    private _sqs;
    get sqs(): AwsTopicRule.SqsPropertyList;
    putSqs(value: AwsTopicRule.SqsProperty[] | cdktn.IResolvable): void;
    resetSqs(): void;
    get sqsInput(): cdktn.IResolvable | AwsTopicRule.SqsProperty[] | undefined;
    private _stepFunctions;
    get stepFunctions(): AwsTopicRule.StepFunctionsPropertyList;
    putStepFunctions(value: AwsTopicRule.StepFunctionsProperty[] | cdktn.IResolvable): void;
    resetStepFunctions(): void;
    get stepFunctionsInput(): cdktn.IResolvable | AwsTopicRule.StepFunctionsProperty[] | undefined;
    private _timestream;
    get timestream(): AwsTopicRule.TimestreamPropertyList;
    putTimestream(value: AwsTopicRule.TimestreamProperty[] | cdktn.IResolvable): void;
    resetTimestream(): void;
    get timestreamInput(): cdktn.IResolvable | AwsTopicRule.TimestreamProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsTopicRuleCloudwatchAlarmPropertyToTerraform(struct?: AwsTopicRule.CloudwatchAlarmProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleCloudwatchAlarmPropertyToHclTerraform(struct?: AwsTopicRule.CloudwatchAlarmProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleCloudwatchLogsPropertyToTerraform(struct?: AwsTopicRule.CloudwatchLogsProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleCloudwatchLogsPropertyToHclTerraform(struct?: AwsTopicRule.CloudwatchLogsProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleCloudwatchMetricPropertyToTerraform(struct?: AwsTopicRule.CloudwatchMetricProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleCloudwatchMetricPropertyToHclTerraform(struct?: AwsTopicRule.CloudwatchMetricProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleDynamodbPropertyToTerraform(struct?: AwsTopicRule.DynamodbProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleDynamodbPropertyToHclTerraform(struct?: AwsTopicRule.DynamodbProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleDynamodbv2PutItemPropertyToTerraform(struct?: AwsTopicRule.Dynamodbv2PutItemPropertyOutputReference | AwsTopicRule.Dynamodbv2PutItemProperty): any;
export declare function awsTopicRuleDynamodbv2PutItemPropertyToHclTerraform(struct?: AwsTopicRule.Dynamodbv2PutItemPropertyOutputReference | AwsTopicRule.Dynamodbv2PutItemProperty): any;
export declare function awsTopicRuleDynamodbv2PropertyToTerraform(struct?: AwsTopicRule.Dynamodbv2Property | cdktn.IResolvable): any;
export declare function awsTopicRuleDynamodbv2PropertyToHclTerraform(struct?: AwsTopicRule.Dynamodbv2Property | cdktn.IResolvable): any;
export declare function awsTopicRuleElasticsearchPropertyToTerraform(struct?: AwsTopicRule.ElasticsearchProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleElasticsearchPropertyToHclTerraform(struct?: AwsTopicRule.ElasticsearchProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleErrorActionCloudwatchAlarmPropertyToTerraform(struct?: AwsTopicRule.ErrorActionCloudwatchAlarmPropertyOutputReference | AwsTopicRule.ErrorActionCloudwatchAlarmProperty): any;
export declare function awsTopicRuleErrorActionCloudwatchAlarmPropertyToHclTerraform(struct?: AwsTopicRule.ErrorActionCloudwatchAlarmPropertyOutputReference | AwsTopicRule.ErrorActionCloudwatchAlarmProperty): any;
export declare function awsTopicRuleErrorActionCloudwatchLogsPropertyToTerraform(struct?: AwsTopicRule.ErrorActionCloudwatchLogsPropertyOutputReference | AwsTopicRule.ErrorActionCloudwatchLogsProperty): any;
export declare function awsTopicRuleErrorActionCloudwatchLogsPropertyToHclTerraform(struct?: AwsTopicRule.ErrorActionCloudwatchLogsPropertyOutputReference | AwsTopicRule.ErrorActionCloudwatchLogsProperty): any;
export declare function awsTopicRuleErrorActionCloudwatchMetricPropertyToTerraform(struct?: AwsTopicRule.ErrorActionCloudwatchMetricPropertyOutputReference | AwsTopicRule.ErrorActionCloudwatchMetricProperty): any;
export declare function awsTopicRuleErrorActionCloudwatchMetricPropertyToHclTerraform(struct?: AwsTopicRule.ErrorActionCloudwatchMetricPropertyOutputReference | AwsTopicRule.ErrorActionCloudwatchMetricProperty): any;
export declare function awsTopicRuleErrorActionDynamodbPropertyToTerraform(struct?: AwsTopicRule.ErrorActionDynamodbPropertyOutputReference | AwsTopicRule.ErrorActionDynamodbProperty): any;
export declare function awsTopicRuleErrorActionDynamodbPropertyToHclTerraform(struct?: AwsTopicRule.ErrorActionDynamodbPropertyOutputReference | AwsTopicRule.ErrorActionDynamodbProperty): any;
export declare function awsTopicRuleErrorActionDynamodbv2PutItemPropertyToTerraform(struct?: AwsTopicRule.ErrorActionDynamodbv2PutItemPropertyOutputReference | AwsTopicRule.ErrorActionDynamodbv2PutItemProperty): any;
export declare function awsTopicRuleErrorActionDynamodbv2PutItemPropertyToHclTerraform(struct?: AwsTopicRule.ErrorActionDynamodbv2PutItemPropertyOutputReference | AwsTopicRule.ErrorActionDynamodbv2PutItemProperty): any;
export declare function awsTopicRuleErrorActionDynamodbv2PropertyToTerraform(struct?: AwsTopicRule.ErrorActionDynamodbv2PropertyOutputReference | AwsTopicRule.ErrorActionDynamodbv2Property): any;
export declare function awsTopicRuleErrorActionDynamodbv2PropertyToHclTerraform(struct?: AwsTopicRule.ErrorActionDynamodbv2PropertyOutputReference | AwsTopicRule.ErrorActionDynamodbv2Property): any;
export declare function awsTopicRuleErrorActionElasticsearchPropertyToTerraform(struct?: AwsTopicRule.ErrorActionElasticsearchPropertyOutputReference | AwsTopicRule.ErrorActionElasticsearchProperty): any;
export declare function awsTopicRuleErrorActionElasticsearchPropertyToHclTerraform(struct?: AwsTopicRule.ErrorActionElasticsearchPropertyOutputReference | AwsTopicRule.ErrorActionElasticsearchProperty): any;
export declare function awsTopicRuleErrorActionFirehosePropertyToTerraform(struct?: AwsTopicRule.ErrorActionFirehosePropertyOutputReference | AwsTopicRule.ErrorActionFirehoseProperty): any;
export declare function awsTopicRuleErrorActionFirehosePropertyToHclTerraform(struct?: AwsTopicRule.ErrorActionFirehosePropertyOutputReference | AwsTopicRule.ErrorActionFirehoseProperty): any;
export declare function awsTopicRuleErrorActionHttpHttpHeaderPropertyToTerraform(struct?: AwsTopicRule.ErrorActionHttpHttpHeaderProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleErrorActionHttpHttpHeaderPropertyToHclTerraform(struct?: AwsTopicRule.ErrorActionHttpHttpHeaderProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleErrorActionHttpPropertyToTerraform(struct?: AwsTopicRule.ErrorActionHttpPropertyOutputReference | AwsTopicRule.ErrorActionHttpProperty): any;
export declare function awsTopicRuleErrorActionHttpPropertyToHclTerraform(struct?: AwsTopicRule.ErrorActionHttpPropertyOutputReference | AwsTopicRule.ErrorActionHttpProperty): any;
export declare function awsTopicRuleErrorActionIotAnalyticsPropertyToTerraform(struct?: AwsTopicRule.ErrorActionIotAnalyticsPropertyOutputReference | AwsTopicRule.ErrorActionIotAnalyticsProperty): any;
export declare function awsTopicRuleErrorActionIotAnalyticsPropertyToHclTerraform(struct?: AwsTopicRule.ErrorActionIotAnalyticsPropertyOutputReference | AwsTopicRule.ErrorActionIotAnalyticsProperty): any;
export declare function awsTopicRuleErrorActionIotEventsPropertyToTerraform(struct?: AwsTopicRule.ErrorActionIotEventsPropertyOutputReference | AwsTopicRule.ErrorActionIotEventsProperty): any;
export declare function awsTopicRuleErrorActionIotEventsPropertyToHclTerraform(struct?: AwsTopicRule.ErrorActionIotEventsPropertyOutputReference | AwsTopicRule.ErrorActionIotEventsProperty): any;
export declare function awsTopicRuleErrorActionKafkaHeaderPropertyToTerraform(struct?: AwsTopicRule.ErrorActionKafkaHeaderProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleErrorActionKafkaHeaderPropertyToHclTerraform(struct?: AwsTopicRule.ErrorActionKafkaHeaderProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleErrorActionKafkaPropertyToTerraform(struct?: AwsTopicRule.ErrorActionKafkaPropertyOutputReference | AwsTopicRule.ErrorActionKafkaProperty): any;
export declare function awsTopicRuleErrorActionKafkaPropertyToHclTerraform(struct?: AwsTopicRule.ErrorActionKafkaPropertyOutputReference | AwsTopicRule.ErrorActionKafkaProperty): any;
export declare function awsTopicRuleErrorActionKinesisPropertyToTerraform(struct?: AwsTopicRule.ErrorActionKinesisPropertyOutputReference | AwsTopicRule.ErrorActionKinesisProperty): any;
export declare function awsTopicRuleErrorActionKinesisPropertyToHclTerraform(struct?: AwsTopicRule.ErrorActionKinesisPropertyOutputReference | AwsTopicRule.ErrorActionKinesisProperty): any;
export declare function awsTopicRuleErrorActionLambdaPropertyToTerraform(struct?: AwsTopicRule.ErrorActionLambdaPropertyOutputReference | AwsTopicRule.ErrorActionLambdaProperty): any;
export declare function awsTopicRuleErrorActionLambdaPropertyToHclTerraform(struct?: AwsTopicRule.ErrorActionLambdaPropertyOutputReference | AwsTopicRule.ErrorActionLambdaProperty): any;
export declare function awsTopicRuleErrorActionRepublishPropertyToTerraform(struct?: AwsTopicRule.ErrorActionRepublishPropertyOutputReference | AwsTopicRule.ErrorActionRepublishProperty): any;
export declare function awsTopicRuleErrorActionRepublishPropertyToHclTerraform(struct?: AwsTopicRule.ErrorActionRepublishPropertyOutputReference | AwsTopicRule.ErrorActionRepublishProperty): any;
export declare function awsTopicRuleErrorActionS3PropertyToTerraform(struct?: AwsTopicRule.ErrorActionS3PropertyOutputReference | AwsTopicRule.ErrorActionS3Property): any;
export declare function awsTopicRuleErrorActionS3PropertyToHclTerraform(struct?: AwsTopicRule.ErrorActionS3PropertyOutputReference | AwsTopicRule.ErrorActionS3Property): any;
export declare function awsTopicRuleErrorActionSnsPropertyToTerraform(struct?: AwsTopicRule.ErrorActionSnsPropertyOutputReference | AwsTopicRule.ErrorActionSnsProperty): any;
export declare function awsTopicRuleErrorActionSnsPropertyToHclTerraform(struct?: AwsTopicRule.ErrorActionSnsPropertyOutputReference | AwsTopicRule.ErrorActionSnsProperty): any;
export declare function awsTopicRuleErrorActionSqsPropertyToTerraform(struct?: AwsTopicRule.ErrorActionSqsPropertyOutputReference | AwsTopicRule.ErrorActionSqsProperty): any;
export declare function awsTopicRuleErrorActionSqsPropertyToHclTerraform(struct?: AwsTopicRule.ErrorActionSqsPropertyOutputReference | AwsTopicRule.ErrorActionSqsProperty): any;
export declare function awsTopicRuleErrorActionStepFunctionsPropertyToTerraform(struct?: AwsTopicRule.ErrorActionStepFunctionsPropertyOutputReference | AwsTopicRule.ErrorActionStepFunctionsProperty): any;
export declare function awsTopicRuleErrorActionStepFunctionsPropertyToHclTerraform(struct?: AwsTopicRule.ErrorActionStepFunctionsPropertyOutputReference | AwsTopicRule.ErrorActionStepFunctionsProperty): any;
export declare function awsTopicRuleErrorActionTimestreamDimensionPropertyToTerraform(struct?: AwsTopicRule.ErrorActionTimestreamDimensionProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleErrorActionTimestreamDimensionPropertyToHclTerraform(struct?: AwsTopicRule.ErrorActionTimestreamDimensionProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleErrorActionTimestreamTimestampPropertyToTerraform(struct?: AwsTopicRule.ErrorActionTimestreamTimestampPropertyOutputReference | AwsTopicRule.ErrorActionTimestreamTimestampProperty): any;
export declare function awsTopicRuleErrorActionTimestreamTimestampPropertyToHclTerraform(struct?: AwsTopicRule.ErrorActionTimestreamTimestampPropertyOutputReference | AwsTopicRule.ErrorActionTimestreamTimestampProperty): any;
export declare function awsTopicRuleErrorActionTimestreamPropertyToTerraform(struct?: AwsTopicRule.ErrorActionTimestreamPropertyOutputReference | AwsTopicRule.ErrorActionTimestreamProperty): any;
export declare function awsTopicRuleErrorActionTimestreamPropertyToHclTerraform(struct?: AwsTopicRule.ErrorActionTimestreamPropertyOutputReference | AwsTopicRule.ErrorActionTimestreamProperty): any;
export declare function awsTopicRuleErrorActionPropertyToTerraform(struct?: AwsTopicRule.ErrorActionPropertyOutputReference | AwsTopicRule.ErrorActionProperty): any;
export declare function awsTopicRuleErrorActionPropertyToHclTerraform(struct?: AwsTopicRule.ErrorActionPropertyOutputReference | AwsTopicRule.ErrorActionProperty): any;
export declare function awsTopicRuleFirehosePropertyToTerraform(struct?: AwsTopicRule.FirehoseProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleFirehosePropertyToHclTerraform(struct?: AwsTopicRule.FirehoseProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleHttpHttpHeaderPropertyToTerraform(struct?: AwsTopicRule.HttpHttpHeaderProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleHttpHttpHeaderPropertyToHclTerraform(struct?: AwsTopicRule.HttpHttpHeaderProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleHttpPropertyToTerraform(struct?: AwsTopicRule.HttpProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleHttpPropertyToHclTerraform(struct?: AwsTopicRule.HttpProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleIotAnalyticsPropertyToTerraform(struct?: AwsTopicRule.IotAnalyticsProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleIotAnalyticsPropertyToHclTerraform(struct?: AwsTopicRule.IotAnalyticsProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleIotEventsPropertyToTerraform(struct?: AwsTopicRule.IotEventsProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleIotEventsPropertyToHclTerraform(struct?: AwsTopicRule.IotEventsProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleKafkaHeaderPropertyToTerraform(struct?: AwsTopicRule.KafkaHeaderProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleKafkaHeaderPropertyToHclTerraform(struct?: AwsTopicRule.KafkaHeaderProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleKafkaPropertyToTerraform(struct?: AwsTopicRule.KafkaProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleKafkaPropertyToHclTerraform(struct?: AwsTopicRule.KafkaProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleKinesisPropertyToTerraform(struct?: AwsTopicRule.KinesisProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleKinesisPropertyToHclTerraform(struct?: AwsTopicRule.KinesisProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleLambdaPropertyToTerraform(struct?: AwsTopicRule.LambdaProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleLambdaPropertyToHclTerraform(struct?: AwsTopicRule.LambdaProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleRepublishPropertyToTerraform(struct?: AwsTopicRule.RepublishProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleRepublishPropertyToHclTerraform(struct?: AwsTopicRule.RepublishProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleS3PropertyToTerraform(struct?: AwsTopicRule.S3Property | cdktn.IResolvable): any;
export declare function awsTopicRuleS3PropertyToHclTerraform(struct?: AwsTopicRule.S3Property | cdktn.IResolvable): any;
export declare function awsTopicRuleSnsPropertyToTerraform(struct?: AwsTopicRule.SnsProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleSnsPropertyToHclTerraform(struct?: AwsTopicRule.SnsProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleSqsPropertyToTerraform(struct?: AwsTopicRule.SqsProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleSqsPropertyToHclTerraform(struct?: AwsTopicRule.SqsProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleStepFunctionsPropertyToTerraform(struct?: AwsTopicRule.StepFunctionsProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleStepFunctionsPropertyToHclTerraform(struct?: AwsTopicRule.StepFunctionsProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleTimestreamDimensionPropertyToTerraform(struct?: AwsTopicRule.TimestreamDimensionProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleTimestreamDimensionPropertyToHclTerraform(struct?: AwsTopicRule.TimestreamDimensionProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleTimestreamTimestampPropertyToTerraform(struct?: AwsTopicRule.TimestreamTimestampPropertyOutputReference | AwsTopicRule.TimestreamTimestampProperty): any;
export declare function awsTopicRuleTimestreamTimestampPropertyToHclTerraform(struct?: AwsTopicRule.TimestreamTimestampPropertyOutputReference | AwsTopicRule.TimestreamTimestampProperty): any;
export declare function awsTopicRuleTimestreamPropertyToTerraform(struct?: AwsTopicRule.TimestreamProperty | cdktn.IResolvable): any;
export declare function awsTopicRuleTimestreamPropertyToHclTerraform(struct?: AwsTopicRule.TimestreamProperty | cdktn.IResolvable): any;
export declare namespace AwsTopicRule {
    interface CloudwatchAlarmProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#alarm_name AwsTopicRule#alarm_name}
        */
        readonly alarmName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn AwsTopicRule#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#state_reason AwsTopicRule#state_reason}
        */
        readonly stateReason: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#state_value AwsTopicRule#state_value}
        */
        readonly stateValue: string;
    }
    class CloudwatchAlarmPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CloudwatchAlarmProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CloudwatchAlarmProperty | cdktn.IResolvable | undefined);
        private _alarmName?;
        get alarmName(): string;
        set alarmName(value: string);
        get alarmNameInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _stateReason?;
        get stateReason(): string;
        set stateReason(value: string);
        get stateReasonInput(): string | undefined;
        private _stateValue?;
        get stateValue(): string;
        set stateValue(value: string);
        get stateValueInput(): string | undefined;
    }
    class CloudwatchAlarmPropertyList extends cdktn.ComplexList {
        internalValue?: CloudwatchAlarmProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CloudwatchAlarmPropertyOutputReference;
    }
    interface CloudwatchLogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#batch_mode AwsTopicRule#batch_mode}
        */
        readonly batchMode?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#log_group_name AwsTopicRule#log_group_name}
        */
        readonly logGroupName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn AwsTopicRule#role_arn}
        */
        readonly roleArn: string;
    }
    class CloudwatchLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CloudwatchLogsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CloudwatchLogsProperty | cdktn.IResolvable | undefined);
        private _batchMode?;
        get batchMode(): boolean | cdktn.IResolvable;
        set batchMode(value: boolean | cdktn.IResolvable);
        resetBatchMode(): void;
        get batchModeInput(): boolean | cdktn.IResolvable | undefined;
        private _logGroupName?;
        get logGroupName(): string;
        set logGroupName(value: string);
        get logGroupNameInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
    }
    class CloudwatchLogsPropertyList extends cdktn.ComplexList {
        internalValue?: CloudwatchLogsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CloudwatchLogsPropertyOutputReference;
    }
    interface CloudwatchMetricProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#metric_name AwsTopicRule#metric_name}
        */
        readonly metricName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#metric_namespace AwsTopicRule#metric_namespace}
        */
        readonly metricNamespace: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#metric_timestamp AwsTopicRule#metric_timestamp}
        */
        readonly metricTimestamp?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#metric_unit AwsTopicRule#metric_unit}
        */
        readonly metricUnit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#metric_value AwsTopicRule#metric_value}
        */
        readonly metricValue: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn AwsTopicRule#role_arn}
        */
        readonly roleArn: string;
    }
    class CloudwatchMetricPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CloudwatchMetricProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CloudwatchMetricProperty | cdktn.IResolvable | undefined);
        private _metricName?;
        get metricName(): string;
        set metricName(value: string);
        get metricNameInput(): string | undefined;
        private _metricNamespace?;
        get metricNamespace(): string;
        set metricNamespace(value: string);
        get metricNamespaceInput(): string | undefined;
        private _metricTimestamp?;
        get metricTimestamp(): string;
        set metricTimestamp(value: string);
        resetMetricTimestamp(): void;
        get metricTimestampInput(): string | undefined;
        private _metricUnit?;
        get metricUnit(): string;
        set metricUnit(value: string);
        get metricUnitInput(): string | undefined;
        private _metricValue?;
        get metricValue(): string;
        set metricValue(value: string);
        get metricValueInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
    }
    class CloudwatchMetricPropertyList extends cdktn.ComplexList {
        internalValue?: CloudwatchMetricProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CloudwatchMetricPropertyOutputReference;
    }
    interface DynamodbProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#hash_key_field AwsTopicRule#hash_key_field}
        */
        readonly hashKeyField: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#hash_key_type AwsTopicRule#hash_key_type}
        */
        readonly hashKeyType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#hash_key_value AwsTopicRule#hash_key_value}
        */
        readonly hashKeyValue: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#operation AwsTopicRule#operation}
        */
        readonly operation?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#payload_field AwsTopicRule#payload_field}
        */
        readonly payloadField?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#range_key_field AwsTopicRule#range_key_field}
        */
        readonly rangeKeyField?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#range_key_type AwsTopicRule#range_key_type}
        */
        readonly rangeKeyType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#range_key_value AwsTopicRule#range_key_value}
        */
        readonly rangeKeyValue?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn AwsTopicRule#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#table_name AwsTopicRule#table_name}
        */
        readonly tableName: string;
    }
    class DynamodbPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DynamodbProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DynamodbProperty | cdktn.IResolvable | undefined);
        private _hashKeyField?;
        get hashKeyField(): string;
        set hashKeyField(value: string);
        get hashKeyFieldInput(): string | undefined;
        private _hashKeyType?;
        get hashKeyType(): string;
        set hashKeyType(value: string);
        resetHashKeyType(): void;
        get hashKeyTypeInput(): string | undefined;
        private _hashKeyValue?;
        get hashKeyValue(): string;
        set hashKeyValue(value: string);
        get hashKeyValueInput(): string | undefined;
        private _operation?;
        get operation(): string;
        set operation(value: string);
        resetOperation(): void;
        get operationInput(): string | undefined;
        private _payloadField?;
        get payloadField(): string;
        set payloadField(value: string);
        resetPayloadField(): void;
        get payloadFieldInput(): string | undefined;
        private _rangeKeyField?;
        get rangeKeyField(): string;
        set rangeKeyField(value: string);
        resetRangeKeyField(): void;
        get rangeKeyFieldInput(): string | undefined;
        private _rangeKeyType?;
        get rangeKeyType(): string;
        set rangeKeyType(value: string);
        resetRangeKeyType(): void;
        get rangeKeyTypeInput(): string | undefined;
        private _rangeKeyValue?;
        get rangeKeyValue(): string;
        set rangeKeyValue(value: string);
        resetRangeKeyValue(): void;
        get rangeKeyValueInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _tableName?;
        get tableName(): string;
        set tableName(value: string);
        get tableNameInput(): string | undefined;
    }
    class DynamodbPropertyList extends cdktn.ComplexList {
        internalValue?: DynamodbProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DynamodbPropertyOutputReference;
    }
    interface Dynamodbv2PutItemProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#table_name AwsTopicRule#table_name}
        */
        readonly tableName: string;
    }
    class Dynamodbv2PutItemPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): Dynamodbv2PutItemProperty | undefined;
        set internalValue(value: Dynamodbv2PutItemProperty | undefined);
        private _tableName?;
        get tableName(): string;
        set tableName(value: string);
        get tableNameInput(): string | undefined;
    }
    interface Dynamodbv2Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn AwsTopicRule#role_arn}
        */
        readonly roleArn: string;
        /**
        * put_item block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#put_item AwsTopicRule#put_item}
        */
        readonly putItem?: Dynamodbv2PutItemProperty;
    }
    class Dynamodbv2PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): Dynamodbv2Property | cdktn.IResolvable | undefined;
        set internalValue(value: Dynamodbv2Property | cdktn.IResolvable | undefined);
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _putItem;
        get putItem(): Dynamodbv2PutItemPropertyOutputReference;
        putPutItem(value: Dynamodbv2PutItemProperty): void;
        resetPutItem(): void;
        get putItemInput(): Dynamodbv2PutItemProperty | undefined;
    }
    class Dynamodbv2PropertyList extends cdktn.ComplexList {
        internalValue?: Dynamodbv2Property[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): Dynamodbv2PropertyOutputReference;
    }
    interface ElasticsearchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#endpoint AwsTopicRule#endpoint}
        */
        readonly endpoint: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#id AwsTopicRule#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#index AwsTopicRule#index}
        */
        readonly index: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn AwsTopicRule#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#type AwsTopicRule#type}
        */
        readonly type: string;
    }
    class ElasticsearchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ElasticsearchProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ElasticsearchProperty | cdktn.IResolvable | undefined);
        private _endpoint?;
        get endpoint(): string;
        set endpoint(value: string);
        get endpointInput(): string | undefined;
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
        private _index?;
        get index(): string;
        set index(value: string);
        get indexInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class ElasticsearchPropertyList extends cdktn.ComplexList {
        internalValue?: ElasticsearchProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ElasticsearchPropertyOutputReference;
    }
    interface ErrorActionCloudwatchAlarmProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#alarm_name AwsTopicRule#alarm_name}
        */
        readonly alarmName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn AwsTopicRule#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#state_reason AwsTopicRule#state_reason}
        */
        readonly stateReason: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#state_value AwsTopicRule#state_value}
        */
        readonly stateValue: string;
    }
    class ErrorActionCloudwatchAlarmPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorActionCloudwatchAlarmProperty | undefined;
        set internalValue(value: ErrorActionCloudwatchAlarmProperty | undefined);
        private _alarmName?;
        get alarmName(): string;
        set alarmName(value: string);
        get alarmNameInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _stateReason?;
        get stateReason(): string;
        set stateReason(value: string);
        get stateReasonInput(): string | undefined;
        private _stateValue?;
        get stateValue(): string;
        set stateValue(value: string);
        get stateValueInput(): string | undefined;
    }
    interface ErrorActionCloudwatchLogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#batch_mode AwsTopicRule#batch_mode}
        */
        readonly batchMode?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#log_group_name AwsTopicRule#log_group_name}
        */
        readonly logGroupName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn AwsTopicRule#role_arn}
        */
        readonly roleArn: string;
    }
    class ErrorActionCloudwatchLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorActionCloudwatchLogsProperty | undefined;
        set internalValue(value: ErrorActionCloudwatchLogsProperty | undefined);
        private _batchMode?;
        get batchMode(): boolean | cdktn.IResolvable;
        set batchMode(value: boolean | cdktn.IResolvable);
        resetBatchMode(): void;
        get batchModeInput(): boolean | cdktn.IResolvable | undefined;
        private _logGroupName?;
        get logGroupName(): string;
        set logGroupName(value: string);
        get logGroupNameInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
    }
    interface ErrorActionCloudwatchMetricProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#metric_name AwsTopicRule#metric_name}
        */
        readonly metricName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#metric_namespace AwsTopicRule#metric_namespace}
        */
        readonly metricNamespace: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#metric_timestamp AwsTopicRule#metric_timestamp}
        */
        readonly metricTimestamp?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#metric_unit AwsTopicRule#metric_unit}
        */
        readonly metricUnit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#metric_value AwsTopicRule#metric_value}
        */
        readonly metricValue: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn AwsTopicRule#role_arn}
        */
        readonly roleArn: string;
    }
    class ErrorActionCloudwatchMetricPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorActionCloudwatchMetricProperty | undefined;
        set internalValue(value: ErrorActionCloudwatchMetricProperty | undefined);
        private _metricName?;
        get metricName(): string;
        set metricName(value: string);
        get metricNameInput(): string | undefined;
        private _metricNamespace?;
        get metricNamespace(): string;
        set metricNamespace(value: string);
        get metricNamespaceInput(): string | undefined;
        private _metricTimestamp?;
        get metricTimestamp(): string;
        set metricTimestamp(value: string);
        resetMetricTimestamp(): void;
        get metricTimestampInput(): string | undefined;
        private _metricUnit?;
        get metricUnit(): string;
        set metricUnit(value: string);
        get metricUnitInput(): string | undefined;
        private _metricValue?;
        get metricValue(): string;
        set metricValue(value: string);
        get metricValueInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
    }
    interface ErrorActionDynamodbProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#hash_key_field AwsTopicRule#hash_key_field}
        */
        readonly hashKeyField: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#hash_key_type AwsTopicRule#hash_key_type}
        */
        readonly hashKeyType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#hash_key_value AwsTopicRule#hash_key_value}
        */
        readonly hashKeyValue: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#operation AwsTopicRule#operation}
        */
        readonly operation?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#payload_field AwsTopicRule#payload_field}
        */
        readonly payloadField?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#range_key_field AwsTopicRule#range_key_field}
        */
        readonly rangeKeyField?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#range_key_type AwsTopicRule#range_key_type}
        */
        readonly rangeKeyType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#range_key_value AwsTopicRule#range_key_value}
        */
        readonly rangeKeyValue?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn AwsTopicRule#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#table_name AwsTopicRule#table_name}
        */
        readonly tableName: string;
    }
    class ErrorActionDynamodbPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorActionDynamodbProperty | undefined;
        set internalValue(value: ErrorActionDynamodbProperty | undefined);
        private _hashKeyField?;
        get hashKeyField(): string;
        set hashKeyField(value: string);
        get hashKeyFieldInput(): string | undefined;
        private _hashKeyType?;
        get hashKeyType(): string;
        set hashKeyType(value: string);
        resetHashKeyType(): void;
        get hashKeyTypeInput(): string | undefined;
        private _hashKeyValue?;
        get hashKeyValue(): string;
        set hashKeyValue(value: string);
        get hashKeyValueInput(): string | undefined;
        private _operation?;
        get operation(): string;
        set operation(value: string);
        resetOperation(): void;
        get operationInput(): string | undefined;
        private _payloadField?;
        get payloadField(): string;
        set payloadField(value: string);
        resetPayloadField(): void;
        get payloadFieldInput(): string | undefined;
        private _rangeKeyField?;
        get rangeKeyField(): string;
        set rangeKeyField(value: string);
        resetRangeKeyField(): void;
        get rangeKeyFieldInput(): string | undefined;
        private _rangeKeyType?;
        get rangeKeyType(): string;
        set rangeKeyType(value: string);
        resetRangeKeyType(): void;
        get rangeKeyTypeInput(): string | undefined;
        private _rangeKeyValue?;
        get rangeKeyValue(): string;
        set rangeKeyValue(value: string);
        resetRangeKeyValue(): void;
        get rangeKeyValueInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _tableName?;
        get tableName(): string;
        set tableName(value: string);
        get tableNameInput(): string | undefined;
    }
    interface ErrorActionDynamodbv2PutItemProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#table_name AwsTopicRule#table_name}
        */
        readonly tableName: string;
    }
    class ErrorActionDynamodbv2PutItemPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorActionDynamodbv2PutItemProperty | undefined;
        set internalValue(value: ErrorActionDynamodbv2PutItemProperty | undefined);
        private _tableName?;
        get tableName(): string;
        set tableName(value: string);
        get tableNameInput(): string | undefined;
    }
    interface ErrorActionDynamodbv2Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn AwsTopicRule#role_arn}
        */
        readonly roleArn: string;
        /**
        * put_item block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#put_item AwsTopicRule#put_item}
        */
        readonly putItem?: ErrorActionDynamodbv2PutItemProperty;
    }
    class ErrorActionDynamodbv2PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorActionDynamodbv2Property | undefined;
        set internalValue(value: ErrorActionDynamodbv2Property | undefined);
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _putItem;
        get putItem(): ErrorActionDynamodbv2PutItemPropertyOutputReference;
        putPutItem(value: ErrorActionDynamodbv2PutItemProperty): void;
        resetPutItem(): void;
        get putItemInput(): ErrorActionDynamodbv2PutItemProperty | undefined;
    }
    interface ErrorActionElasticsearchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#endpoint AwsTopicRule#endpoint}
        */
        readonly endpoint: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#id AwsTopicRule#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#index AwsTopicRule#index}
        */
        readonly index: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn AwsTopicRule#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#type AwsTopicRule#type}
        */
        readonly type: string;
    }
    class ErrorActionElasticsearchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorActionElasticsearchProperty | undefined;
        set internalValue(value: ErrorActionElasticsearchProperty | undefined);
        private _endpoint?;
        get endpoint(): string;
        set endpoint(value: string);
        get endpointInput(): string | undefined;
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
        private _index?;
        get index(): string;
        set index(value: string);
        get indexInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    interface ErrorActionFirehoseProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#batch_mode AwsTopicRule#batch_mode}
        */
        readonly batchMode?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#delivery_stream_name AwsTopicRule#delivery_stream_name}
        */
        readonly deliveryStreamName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn AwsTopicRule#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#separator AwsTopicRule#separator}
        */
        readonly separator?: string;
    }
    class ErrorActionFirehosePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorActionFirehoseProperty | undefined;
        set internalValue(value: ErrorActionFirehoseProperty | undefined);
        private _batchMode?;
        get batchMode(): boolean | cdktn.IResolvable;
        set batchMode(value: boolean | cdktn.IResolvable);
        resetBatchMode(): void;
        get batchModeInput(): boolean | cdktn.IResolvable | undefined;
        private _deliveryStreamName?;
        get deliveryStreamName(): string;
        set deliveryStreamName(value: string);
        get deliveryStreamNameInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _separator?;
        get separator(): string;
        set separator(value: string);
        resetSeparator(): void;
        get separatorInput(): string | undefined;
    }
    interface ErrorActionHttpHttpHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#key AwsTopicRule#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#value AwsTopicRule#value}
        */
        readonly value: string;
    }
    class ErrorActionHttpHttpHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ErrorActionHttpHttpHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ErrorActionHttpHttpHeaderProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ErrorActionHttpHttpHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: ErrorActionHttpHttpHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ErrorActionHttpHttpHeaderPropertyOutputReference;
    }
    interface ErrorActionHttpProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#confirmation_url AwsTopicRule#confirmation_url}
        */
        readonly confirmationUrl?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#url AwsTopicRule#url}
        */
        readonly url: string;
        /**
        * http_header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#http_header AwsTopicRule#http_header}
        */
        readonly httpHeader?: ErrorActionHttpHttpHeaderProperty[] | cdktn.IResolvable;
    }
    class ErrorActionHttpPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorActionHttpProperty | undefined;
        set internalValue(value: ErrorActionHttpProperty | undefined);
        private _confirmationUrl?;
        get confirmationUrl(): string;
        set confirmationUrl(value: string);
        resetConfirmationUrl(): void;
        get confirmationUrlInput(): string | undefined;
        private _url?;
        get url(): string;
        set url(value: string);
        get urlInput(): string | undefined;
        private _httpHeader;
        get httpHeader(): ErrorActionHttpHttpHeaderPropertyList;
        putHttpHeader(value: ErrorActionHttpHttpHeaderProperty[] | cdktn.IResolvable): void;
        resetHttpHeader(): void;
        get httpHeaderInput(): cdktn.IResolvable | ErrorActionHttpHttpHeaderProperty[] | undefined;
    }
    interface ErrorActionIotAnalyticsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#batch_mode AwsTopicRule#batch_mode}
        */
        readonly batchMode?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#channel_name AwsTopicRule#channel_name}
        */
        readonly channelName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn AwsTopicRule#role_arn}
        */
        readonly roleArn: string;
    }
    class ErrorActionIotAnalyticsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorActionIotAnalyticsProperty | undefined;
        set internalValue(value: ErrorActionIotAnalyticsProperty | undefined);
        private _batchMode?;
        get batchMode(): boolean | cdktn.IResolvable;
        set batchMode(value: boolean | cdktn.IResolvable);
        resetBatchMode(): void;
        get batchModeInput(): boolean | cdktn.IResolvable | undefined;
        private _channelName?;
        get channelName(): string;
        set channelName(value: string);
        get channelNameInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
    }
    interface ErrorActionIotEventsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#batch_mode AwsTopicRule#batch_mode}
        */
        readonly batchMode?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#input_name AwsTopicRule#input_name}
        */
        readonly inputName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#message_id AwsTopicRule#message_id}
        */
        readonly messageId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn AwsTopicRule#role_arn}
        */
        readonly roleArn: string;
    }
    class ErrorActionIotEventsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorActionIotEventsProperty | undefined;
        set internalValue(value: ErrorActionIotEventsProperty | undefined);
        private _batchMode?;
        get batchMode(): boolean | cdktn.IResolvable;
        set batchMode(value: boolean | cdktn.IResolvable);
        resetBatchMode(): void;
        get batchModeInput(): boolean | cdktn.IResolvable | undefined;
        private _inputName?;
        get inputName(): string;
        set inputName(value: string);
        get inputNameInput(): string | undefined;
        private _messageId?;
        get messageId(): string;
        set messageId(value: string);
        resetMessageId(): void;
        get messageIdInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
    }
    interface ErrorActionKafkaHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#key AwsTopicRule#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#value AwsTopicRule#value}
        */
        readonly value: string;
    }
    class ErrorActionKafkaHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ErrorActionKafkaHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ErrorActionKafkaHeaderProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ErrorActionKafkaHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: ErrorActionKafkaHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ErrorActionKafkaHeaderPropertyOutputReference;
    }
    interface ErrorActionKafkaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#client_properties AwsTopicRule#client_properties}
        */
        readonly clientProperties: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#destination_arn AwsTopicRule#destination_arn}
        */
        readonly destinationArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#key AwsTopicRule#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#partition AwsTopicRule#partition}
        */
        readonly partition?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#topic AwsTopicRule#topic}
        */
        readonly topic: string;
        /**
        * header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#header AwsTopicRule#header}
        */
        readonly header?: ErrorActionKafkaHeaderProperty[] | cdktn.IResolvable;
    }
    class ErrorActionKafkaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorActionKafkaProperty | undefined;
        set internalValue(value: ErrorActionKafkaProperty | undefined);
        private _clientProperties?;
        get clientProperties(): {
            [key: string]: string;
        };
        set clientProperties(value: {
            [key: string]: string;
        });
        get clientPropertiesInput(): {
            [key: string]: string;
        } | undefined;
        private _destinationArn?;
        get destinationArn(): string;
        set destinationArn(value: string);
        get destinationArnInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _partition?;
        get partition(): string;
        set partition(value: string);
        resetPartition(): void;
        get partitionInput(): string | undefined;
        private _topic?;
        get topic(): string;
        set topic(value: string);
        get topicInput(): string | undefined;
        private _header;
        get header(): ErrorActionKafkaHeaderPropertyList;
        putHeader(value: ErrorActionKafkaHeaderProperty[] | cdktn.IResolvable): void;
        resetHeader(): void;
        get headerInput(): cdktn.IResolvable | ErrorActionKafkaHeaderProperty[] | undefined;
    }
    interface ErrorActionKinesisProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#partition_key AwsTopicRule#partition_key}
        */
        readonly partitionKey?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn AwsTopicRule#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#stream_name AwsTopicRule#stream_name}
        */
        readonly streamName: string;
    }
    class ErrorActionKinesisPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorActionKinesisProperty | undefined;
        set internalValue(value: ErrorActionKinesisProperty | undefined);
        private _partitionKey?;
        get partitionKey(): string;
        set partitionKey(value: string);
        resetPartitionKey(): void;
        get partitionKeyInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _streamName?;
        get streamName(): string;
        set streamName(value: string);
        get streamNameInput(): string | undefined;
    }
    interface ErrorActionLambdaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#function_arn AwsTopicRule#function_arn}
        */
        readonly functionArn: string;
    }
    class ErrorActionLambdaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorActionLambdaProperty | undefined;
        set internalValue(value: ErrorActionLambdaProperty | undefined);
        private _functionArn?;
        get functionArn(): string;
        set functionArn(value: string);
        get functionArnInput(): string | undefined;
    }
    interface ErrorActionRepublishProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#qos AwsTopicRule#qos}
        */
        readonly qos?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn AwsTopicRule#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#topic AwsTopicRule#topic}
        */
        readonly topic: string;
    }
    class ErrorActionRepublishPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorActionRepublishProperty | undefined;
        set internalValue(value: ErrorActionRepublishProperty | undefined);
        private _qos?;
        get qos(): number;
        set qos(value: number);
        resetQos(): void;
        get qosInput(): number | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _topic?;
        get topic(): string;
        set topic(value: string);
        get topicInput(): string | undefined;
    }
    interface ErrorActionS3Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#bucket_name AwsTopicRule#bucket_name}
        */
        readonly bucketName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#canned_acl AwsTopicRule#canned_acl}
        */
        readonly cannedAcl?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#key AwsTopicRule#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn AwsTopicRule#role_arn}
        */
        readonly roleArn: string;
    }
    class ErrorActionS3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorActionS3Property | undefined;
        set internalValue(value: ErrorActionS3Property | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        get bucketNameInput(): string | undefined;
        private _cannedAcl?;
        get cannedAcl(): string;
        set cannedAcl(value: string);
        resetCannedAcl(): void;
        get cannedAclInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
    }
    interface ErrorActionSnsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#message_format AwsTopicRule#message_format}
        */
        readonly messageFormat?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn AwsTopicRule#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#target_arn AwsTopicRule#target_arn}
        */
        readonly targetArn: string;
    }
    class ErrorActionSnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorActionSnsProperty | undefined;
        set internalValue(value: ErrorActionSnsProperty | undefined);
        private _messageFormat?;
        get messageFormat(): string;
        set messageFormat(value: string);
        resetMessageFormat(): void;
        get messageFormatInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _targetArn?;
        get targetArn(): string;
        set targetArn(value: string);
        get targetArnInput(): string | undefined;
    }
    interface ErrorActionSqsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#queue_url AwsTopicRule#queue_url}
        */
        readonly queueUrl: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn AwsTopicRule#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#use_base64 AwsTopicRule#use_base64}
        */
        readonly useBase64: boolean | cdktn.IResolvable;
    }
    class ErrorActionSqsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorActionSqsProperty | undefined;
        set internalValue(value: ErrorActionSqsProperty | undefined);
        private _queueUrl?;
        get queueUrl(): string;
        set queueUrl(value: string);
        get queueUrlInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _useBase64?;
        get useBase64(): boolean | cdktn.IResolvable;
        set useBase64(value: boolean | cdktn.IResolvable);
        get useBase64Input(): boolean | cdktn.IResolvable | undefined;
    }
    interface ErrorActionStepFunctionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#execution_name_prefix AwsTopicRule#execution_name_prefix}
        */
        readonly executionNamePrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn AwsTopicRule#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#state_machine_name AwsTopicRule#state_machine_name}
        */
        readonly stateMachineName: string;
    }
    class ErrorActionStepFunctionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorActionStepFunctionsProperty | undefined;
        set internalValue(value: ErrorActionStepFunctionsProperty | undefined);
        private _executionNamePrefix?;
        get executionNamePrefix(): string;
        set executionNamePrefix(value: string);
        resetExecutionNamePrefix(): void;
        get executionNamePrefixInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _stateMachineName?;
        get stateMachineName(): string;
        set stateMachineName(value: string);
        get stateMachineNameInput(): string | undefined;
    }
    interface ErrorActionTimestreamDimensionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#name AwsTopicRule#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#value AwsTopicRule#value}
        */
        readonly value: string;
    }
    class ErrorActionTimestreamDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ErrorActionTimestreamDimensionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ErrorActionTimestreamDimensionProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ErrorActionTimestreamDimensionPropertyList extends cdktn.ComplexList {
        internalValue?: ErrorActionTimestreamDimensionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ErrorActionTimestreamDimensionPropertyOutputReference;
    }
    interface ErrorActionTimestreamTimestampProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#unit AwsTopicRule#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#value AwsTopicRule#value}
        */
        readonly value: string;
    }
    class ErrorActionTimestreamTimestampPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorActionTimestreamTimestampProperty | undefined;
        set internalValue(value: ErrorActionTimestreamTimestampProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    interface ErrorActionTimestreamProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#database_name AwsTopicRule#database_name}
        */
        readonly databaseName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn AwsTopicRule#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#table_name AwsTopicRule#table_name}
        */
        readonly tableName: string;
        /**
        * dimension block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#dimension AwsTopicRule#dimension}
        */
        readonly dimension: ErrorActionTimestreamDimensionProperty[] | cdktn.IResolvable;
        /**
        * timestamp block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#timestamp AwsTopicRule#timestamp}
        */
        readonly timestamp?: ErrorActionTimestreamTimestampProperty;
    }
    class ErrorActionTimestreamPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorActionTimestreamProperty | undefined;
        set internalValue(value: ErrorActionTimestreamProperty | undefined);
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        get databaseNameInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _tableName?;
        get tableName(): string;
        set tableName(value: string);
        get tableNameInput(): string | undefined;
        private _dimension;
        get dimension(): ErrorActionTimestreamDimensionPropertyList;
        putDimension(value: ErrorActionTimestreamDimensionProperty[] | cdktn.IResolvable): void;
        get dimensionInput(): cdktn.IResolvable | ErrorActionTimestreamDimensionProperty[] | undefined;
        private _timestamp;
        get timestamp(): ErrorActionTimestreamTimestampPropertyOutputReference;
        putTimestamp(value: ErrorActionTimestreamTimestampProperty): void;
        resetTimestamp(): void;
        get timestampInput(): ErrorActionTimestreamTimestampProperty | undefined;
    }
    interface ErrorActionProperty {
        /**
        * cloudwatch_alarm block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#cloudwatch_alarm AwsTopicRule#cloudwatch_alarm}
        */
        readonly cloudwatchAlarm?: ErrorActionCloudwatchAlarmProperty;
        /**
        * cloudwatch_logs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#cloudwatch_logs AwsTopicRule#cloudwatch_logs}
        */
        readonly cloudwatchLogs?: ErrorActionCloudwatchLogsProperty;
        /**
        * cloudwatch_metric block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#cloudwatch_metric AwsTopicRule#cloudwatch_metric}
        */
        readonly cloudwatchMetric?: ErrorActionCloudwatchMetricProperty;
        /**
        * dynamodb block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#dynamodb AwsTopicRule#dynamodb}
        */
        readonly dynamodb?: ErrorActionDynamodbProperty;
        /**
        * dynamodbv2 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#dynamodbv2 AwsTopicRule#dynamodbv2}
        */
        readonly dynamodbv2?: ErrorActionDynamodbv2Property;
        /**
        * elasticsearch block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#elasticsearch AwsTopicRule#elasticsearch}
        */
        readonly elasticsearch?: ErrorActionElasticsearchProperty;
        /**
        * firehose block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#firehose AwsTopicRule#firehose}
        */
        readonly firehose?: ErrorActionFirehoseProperty;
        /**
        * http block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#http AwsTopicRule#http}
        */
        readonly http?: ErrorActionHttpProperty;
        /**
        * iot_analytics block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#iot_analytics AwsTopicRule#iot_analytics}
        */
        readonly iotAnalytics?: ErrorActionIotAnalyticsProperty;
        /**
        * iot_events block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#iot_events AwsTopicRule#iot_events}
        */
        readonly iotEvents?: ErrorActionIotEventsProperty;
        /**
        * kafka block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#kafka AwsTopicRule#kafka}
        */
        readonly kafka?: ErrorActionKafkaProperty;
        /**
        * kinesis block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#kinesis AwsTopicRule#kinesis}
        */
        readonly kinesis?: ErrorActionKinesisProperty;
        /**
        * lambda block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#lambda AwsTopicRule#lambda}
        */
        readonly lambda?: ErrorActionLambdaProperty;
        /**
        * republish block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#republish AwsTopicRule#republish}
        */
        readonly republish?: ErrorActionRepublishProperty;
        /**
        * s3 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#s3 AwsTopicRule#s3}
        */
        readonly s3?: ErrorActionS3Property;
        /**
        * sns block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#sns AwsTopicRule#sns}
        */
        readonly sns?: ErrorActionSnsProperty;
        /**
        * sqs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#sqs AwsTopicRule#sqs}
        */
        readonly sqs?: ErrorActionSqsProperty;
        /**
        * step_functions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#step_functions AwsTopicRule#step_functions}
        */
        readonly stepFunctions?: ErrorActionStepFunctionsProperty;
        /**
        * timestream block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#timestream AwsTopicRule#timestream}
        */
        readonly timestream?: ErrorActionTimestreamProperty;
    }
    class ErrorActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ErrorActionProperty | undefined;
        set internalValue(value: ErrorActionProperty | undefined);
        private _cloudwatchAlarm;
        get cloudwatchAlarm(): ErrorActionCloudwatchAlarmPropertyOutputReference;
        putCloudwatchAlarm(value: ErrorActionCloudwatchAlarmProperty): void;
        resetCloudwatchAlarm(): void;
        get cloudwatchAlarmInput(): ErrorActionCloudwatchAlarmProperty | undefined;
        private _cloudwatchLogs;
        get cloudwatchLogs(): ErrorActionCloudwatchLogsPropertyOutputReference;
        putCloudwatchLogs(value: ErrorActionCloudwatchLogsProperty): void;
        resetCloudwatchLogs(): void;
        get cloudwatchLogsInput(): ErrorActionCloudwatchLogsProperty | undefined;
        private _cloudwatchMetric;
        get cloudwatchMetric(): ErrorActionCloudwatchMetricPropertyOutputReference;
        putCloudwatchMetric(value: ErrorActionCloudwatchMetricProperty): void;
        resetCloudwatchMetric(): void;
        get cloudwatchMetricInput(): ErrorActionCloudwatchMetricProperty | undefined;
        private _dynamodb;
        get dynamodb(): ErrorActionDynamodbPropertyOutputReference;
        putDynamodb(value: ErrorActionDynamodbProperty): void;
        resetDynamodb(): void;
        get dynamodbInput(): ErrorActionDynamodbProperty | undefined;
        private _dynamodbv2;
        get dynamodbv2(): ErrorActionDynamodbv2PropertyOutputReference;
        putDynamodbv2(value: ErrorActionDynamodbv2Property): void;
        resetDynamodbv2(): void;
        get dynamodbv2Input(): ErrorActionDynamodbv2Property | undefined;
        private _elasticsearch;
        get elasticsearch(): ErrorActionElasticsearchPropertyOutputReference;
        putElasticsearch(value: ErrorActionElasticsearchProperty): void;
        resetElasticsearch(): void;
        get elasticsearchInput(): ErrorActionElasticsearchProperty | undefined;
        private _firehose;
        get firehose(): ErrorActionFirehosePropertyOutputReference;
        putFirehose(value: ErrorActionFirehoseProperty): void;
        resetFirehose(): void;
        get firehoseInput(): ErrorActionFirehoseProperty | undefined;
        private _http;
        get http(): ErrorActionHttpPropertyOutputReference;
        putHttp(value: ErrorActionHttpProperty): void;
        resetHttp(): void;
        get httpInput(): ErrorActionHttpProperty | undefined;
        private _iotAnalytics;
        get iotAnalytics(): ErrorActionIotAnalyticsPropertyOutputReference;
        putIotAnalytics(value: ErrorActionIotAnalyticsProperty): void;
        resetIotAnalytics(): void;
        get iotAnalyticsInput(): ErrorActionIotAnalyticsProperty | undefined;
        private _iotEvents;
        get iotEvents(): ErrorActionIotEventsPropertyOutputReference;
        putIotEvents(value: ErrorActionIotEventsProperty): void;
        resetIotEvents(): void;
        get iotEventsInput(): ErrorActionIotEventsProperty | undefined;
        private _kafka;
        get kafka(): ErrorActionKafkaPropertyOutputReference;
        putKafka(value: ErrorActionKafkaProperty): void;
        resetKafka(): void;
        get kafkaInput(): ErrorActionKafkaProperty | undefined;
        private _kinesis;
        get kinesis(): ErrorActionKinesisPropertyOutputReference;
        putKinesis(value: ErrorActionKinesisProperty): void;
        resetKinesis(): void;
        get kinesisInput(): ErrorActionKinesisProperty | undefined;
        private _lambda;
        get lambda(): ErrorActionLambdaPropertyOutputReference;
        putLambda(value: ErrorActionLambdaProperty): void;
        resetLambda(): void;
        get lambdaInput(): ErrorActionLambdaProperty | undefined;
        private _republish;
        get republish(): ErrorActionRepublishPropertyOutputReference;
        putRepublish(value: ErrorActionRepublishProperty): void;
        resetRepublish(): void;
        get republishInput(): ErrorActionRepublishProperty | undefined;
        private _s3;
        get s3(): ErrorActionS3PropertyOutputReference;
        putS3(value: ErrorActionS3Property): void;
        resetS3(): void;
        get s3Input(): ErrorActionS3Property | undefined;
        private _sns;
        get sns(): ErrorActionSnsPropertyOutputReference;
        putSns(value: ErrorActionSnsProperty): void;
        resetSns(): void;
        get snsInput(): ErrorActionSnsProperty | undefined;
        private _sqs;
        get sqs(): ErrorActionSqsPropertyOutputReference;
        putSqs(value: ErrorActionSqsProperty): void;
        resetSqs(): void;
        get sqsInput(): ErrorActionSqsProperty | undefined;
        private _stepFunctions;
        get stepFunctions(): ErrorActionStepFunctionsPropertyOutputReference;
        putStepFunctions(value: ErrorActionStepFunctionsProperty): void;
        resetStepFunctions(): void;
        get stepFunctionsInput(): ErrorActionStepFunctionsProperty | undefined;
        private _timestream;
        get timestream(): ErrorActionTimestreamPropertyOutputReference;
        putTimestream(value: ErrorActionTimestreamProperty): void;
        resetTimestream(): void;
        get timestreamInput(): ErrorActionTimestreamProperty | undefined;
    }
    interface FirehoseProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#batch_mode AwsTopicRule#batch_mode}
        */
        readonly batchMode?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#delivery_stream_name AwsTopicRule#delivery_stream_name}
        */
        readonly deliveryStreamName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn AwsTopicRule#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#separator AwsTopicRule#separator}
        */
        readonly separator?: string;
    }
    class FirehosePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FirehoseProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FirehoseProperty | cdktn.IResolvable | undefined);
        private _batchMode?;
        get batchMode(): boolean | cdktn.IResolvable;
        set batchMode(value: boolean | cdktn.IResolvable);
        resetBatchMode(): void;
        get batchModeInput(): boolean | cdktn.IResolvable | undefined;
        private _deliveryStreamName?;
        get deliveryStreamName(): string;
        set deliveryStreamName(value: string);
        get deliveryStreamNameInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _separator?;
        get separator(): string;
        set separator(value: string);
        resetSeparator(): void;
        get separatorInput(): string | undefined;
    }
    class FirehosePropertyList extends cdktn.ComplexList {
        internalValue?: FirehoseProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FirehosePropertyOutputReference;
    }
    interface HttpHttpHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#key AwsTopicRule#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#value AwsTopicRule#value}
        */
        readonly value: string;
    }
    class HttpHttpHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HttpHttpHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HttpHttpHeaderProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class HttpHttpHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: HttpHttpHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HttpHttpHeaderPropertyOutputReference;
    }
    interface HttpProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#confirmation_url AwsTopicRule#confirmation_url}
        */
        readonly confirmationUrl?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#url AwsTopicRule#url}
        */
        readonly url: string;
        /**
        * http_header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#http_header AwsTopicRule#http_header}
        */
        readonly httpHeader?: HttpHttpHeaderProperty[] | cdktn.IResolvable;
    }
    class HttpPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HttpProperty | cdktn.IResolvable | undefined;
        set internalValue(value: HttpProperty | cdktn.IResolvable | undefined);
        private _confirmationUrl?;
        get confirmationUrl(): string;
        set confirmationUrl(value: string);
        resetConfirmationUrl(): void;
        get confirmationUrlInput(): string | undefined;
        private _url?;
        get url(): string;
        set url(value: string);
        get urlInput(): string | undefined;
        private _httpHeader;
        get httpHeader(): HttpHttpHeaderPropertyList;
        putHttpHeader(value: HttpHttpHeaderProperty[] | cdktn.IResolvable): void;
        resetHttpHeader(): void;
        get httpHeaderInput(): cdktn.IResolvable | HttpHttpHeaderProperty[] | undefined;
    }
    class HttpPropertyList extends cdktn.ComplexList {
        internalValue?: HttpProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HttpPropertyOutputReference;
    }
    interface IotAnalyticsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#batch_mode AwsTopicRule#batch_mode}
        */
        readonly batchMode?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#channel_name AwsTopicRule#channel_name}
        */
        readonly channelName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn AwsTopicRule#role_arn}
        */
        readonly roleArn: string;
    }
    class IotAnalyticsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IotAnalyticsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IotAnalyticsProperty | cdktn.IResolvable | undefined);
        private _batchMode?;
        get batchMode(): boolean | cdktn.IResolvable;
        set batchMode(value: boolean | cdktn.IResolvable);
        resetBatchMode(): void;
        get batchModeInput(): boolean | cdktn.IResolvable | undefined;
        private _channelName?;
        get channelName(): string;
        set channelName(value: string);
        get channelNameInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
    }
    class IotAnalyticsPropertyList extends cdktn.ComplexList {
        internalValue?: IotAnalyticsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IotAnalyticsPropertyOutputReference;
    }
    interface IotEventsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#batch_mode AwsTopicRule#batch_mode}
        */
        readonly batchMode?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#input_name AwsTopicRule#input_name}
        */
        readonly inputName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#message_id AwsTopicRule#message_id}
        */
        readonly messageId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn AwsTopicRule#role_arn}
        */
        readonly roleArn: string;
    }
    class IotEventsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IotEventsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IotEventsProperty | cdktn.IResolvable | undefined);
        private _batchMode?;
        get batchMode(): boolean | cdktn.IResolvable;
        set batchMode(value: boolean | cdktn.IResolvable);
        resetBatchMode(): void;
        get batchModeInput(): boolean | cdktn.IResolvable | undefined;
        private _inputName?;
        get inputName(): string;
        set inputName(value: string);
        get inputNameInput(): string | undefined;
        private _messageId?;
        get messageId(): string;
        set messageId(value: string);
        resetMessageId(): void;
        get messageIdInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
    }
    class IotEventsPropertyList extends cdktn.ComplexList {
        internalValue?: IotEventsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IotEventsPropertyOutputReference;
    }
    interface KafkaHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#key AwsTopicRule#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#value AwsTopicRule#value}
        */
        readonly value: string;
    }
    class KafkaHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KafkaHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KafkaHeaderProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class KafkaHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: KafkaHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KafkaHeaderPropertyOutputReference;
    }
    interface KafkaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#client_properties AwsTopicRule#client_properties}
        */
        readonly clientProperties: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#destination_arn AwsTopicRule#destination_arn}
        */
        readonly destinationArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#key AwsTopicRule#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#partition AwsTopicRule#partition}
        */
        readonly partition?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#topic AwsTopicRule#topic}
        */
        readonly topic: string;
        /**
        * header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#header AwsTopicRule#header}
        */
        readonly header?: KafkaHeaderProperty[] | cdktn.IResolvable;
    }
    class KafkaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KafkaProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KafkaProperty | cdktn.IResolvable | undefined);
        private _clientProperties?;
        get clientProperties(): {
            [key: string]: string;
        };
        set clientProperties(value: {
            [key: string]: string;
        });
        get clientPropertiesInput(): {
            [key: string]: string;
        } | undefined;
        private _destinationArn?;
        get destinationArn(): string;
        set destinationArn(value: string);
        get destinationArnInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _partition?;
        get partition(): string;
        set partition(value: string);
        resetPartition(): void;
        get partitionInput(): string | undefined;
        private _topic?;
        get topic(): string;
        set topic(value: string);
        get topicInput(): string | undefined;
        private _header;
        get header(): KafkaHeaderPropertyList;
        putHeader(value: KafkaHeaderProperty[] | cdktn.IResolvable): void;
        resetHeader(): void;
        get headerInput(): cdktn.IResolvable | KafkaHeaderProperty[] | undefined;
    }
    class KafkaPropertyList extends cdktn.ComplexList {
        internalValue?: KafkaProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KafkaPropertyOutputReference;
    }
    interface KinesisProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#partition_key AwsTopicRule#partition_key}
        */
        readonly partitionKey?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn AwsTopicRule#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#stream_name AwsTopicRule#stream_name}
        */
        readonly streamName: string;
    }
    class KinesisPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KinesisProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KinesisProperty | cdktn.IResolvable | undefined);
        private _partitionKey?;
        get partitionKey(): string;
        set partitionKey(value: string);
        resetPartitionKey(): void;
        get partitionKeyInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _streamName?;
        get streamName(): string;
        set streamName(value: string);
        get streamNameInput(): string | undefined;
    }
    class KinesisPropertyList extends cdktn.ComplexList {
        internalValue?: KinesisProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KinesisPropertyOutputReference;
    }
    interface LambdaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#function_arn AwsTopicRule#function_arn}
        */
        readonly functionArn: string;
    }
    class LambdaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LambdaProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LambdaProperty | cdktn.IResolvable | undefined);
        private _functionArn?;
        get functionArn(): string;
        set functionArn(value: string);
        get functionArnInput(): string | undefined;
    }
    class LambdaPropertyList extends cdktn.ComplexList {
        internalValue?: LambdaProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LambdaPropertyOutputReference;
    }
    interface RepublishProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#qos AwsTopicRule#qos}
        */
        readonly qos?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn AwsTopicRule#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#topic AwsTopicRule#topic}
        */
        readonly topic: string;
    }
    class RepublishPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RepublishProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RepublishProperty | cdktn.IResolvable | undefined);
        private _qos?;
        get qos(): number;
        set qos(value: number);
        resetQos(): void;
        get qosInput(): number | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _topic?;
        get topic(): string;
        set topic(value: string);
        get topicInput(): string | undefined;
    }
    class RepublishPropertyList extends cdktn.ComplexList {
        internalValue?: RepublishProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RepublishPropertyOutputReference;
    }
    interface S3Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#bucket_name AwsTopicRule#bucket_name}
        */
        readonly bucketName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#canned_acl AwsTopicRule#canned_acl}
        */
        readonly cannedAcl?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#key AwsTopicRule#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn AwsTopicRule#role_arn}
        */
        readonly roleArn: string;
    }
    class S3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3Property | cdktn.IResolvable | undefined;
        set internalValue(value: S3Property | cdktn.IResolvable | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        get bucketNameInput(): string | undefined;
        private _cannedAcl?;
        get cannedAcl(): string;
        set cannedAcl(value: string);
        resetCannedAcl(): void;
        get cannedAclInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
    }
    class S3PropertyList extends cdktn.ComplexList {
        internalValue?: S3Property[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3PropertyOutputReference;
    }
    interface SnsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#message_format AwsTopicRule#message_format}
        */
        readonly messageFormat?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn AwsTopicRule#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#target_arn AwsTopicRule#target_arn}
        */
        readonly targetArn: string;
    }
    class SnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SnsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SnsProperty | cdktn.IResolvable | undefined);
        private _messageFormat?;
        get messageFormat(): string;
        set messageFormat(value: string);
        resetMessageFormat(): void;
        get messageFormatInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _targetArn?;
        get targetArn(): string;
        set targetArn(value: string);
        get targetArnInput(): string | undefined;
    }
    class SnsPropertyList extends cdktn.ComplexList {
        internalValue?: SnsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SnsPropertyOutputReference;
    }
    interface SqsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#queue_url AwsTopicRule#queue_url}
        */
        readonly queueUrl: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn AwsTopicRule#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#use_base64 AwsTopicRule#use_base64}
        */
        readonly useBase64: boolean | cdktn.IResolvable;
    }
    class SqsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SqsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SqsProperty | cdktn.IResolvable | undefined);
        private _queueUrl?;
        get queueUrl(): string;
        set queueUrl(value: string);
        get queueUrlInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _useBase64?;
        get useBase64(): boolean | cdktn.IResolvable;
        set useBase64(value: boolean | cdktn.IResolvable);
        get useBase64Input(): boolean | cdktn.IResolvable | undefined;
    }
    class SqsPropertyList extends cdktn.ComplexList {
        internalValue?: SqsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SqsPropertyOutputReference;
    }
    interface StepFunctionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#execution_name_prefix AwsTopicRule#execution_name_prefix}
        */
        readonly executionNamePrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn AwsTopicRule#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#state_machine_name AwsTopicRule#state_machine_name}
        */
        readonly stateMachineName: string;
    }
    class StepFunctionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StepFunctionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StepFunctionsProperty | cdktn.IResolvable | undefined);
        private _executionNamePrefix?;
        get executionNamePrefix(): string;
        set executionNamePrefix(value: string);
        resetExecutionNamePrefix(): void;
        get executionNamePrefixInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _stateMachineName?;
        get stateMachineName(): string;
        set stateMachineName(value: string);
        get stateMachineNameInput(): string | undefined;
    }
    class StepFunctionsPropertyList extends cdktn.ComplexList {
        internalValue?: StepFunctionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StepFunctionsPropertyOutputReference;
    }
    interface TimestreamDimensionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#name AwsTopicRule#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#value AwsTopicRule#value}
        */
        readonly value: string;
    }
    class TimestreamDimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TimestreamDimensionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimestreamDimensionProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class TimestreamDimensionPropertyList extends cdktn.ComplexList {
        internalValue?: TimestreamDimensionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TimestreamDimensionPropertyOutputReference;
    }
    interface TimestreamTimestampProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#unit AwsTopicRule#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#value AwsTopicRule#value}
        */
        readonly value: string;
    }
    class TimestreamTimestampPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimestreamTimestampProperty | undefined;
        set internalValue(value: TimestreamTimestampProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    interface TimestreamProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#database_name AwsTopicRule#database_name}
        */
        readonly databaseName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#role_arn AwsTopicRule#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#table_name AwsTopicRule#table_name}
        */
        readonly tableName: string;
        /**
        * dimension block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#dimension AwsTopicRule#dimension}
        */
        readonly dimension: TimestreamDimensionProperty[] | cdktn.IResolvable;
        /**
        * timestamp block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_topic_rule#timestamp AwsTopicRule#timestamp}
        */
        readonly timestamp?: TimestreamTimestampProperty;
    }
    class TimestreamPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TimestreamProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimestreamProperty | cdktn.IResolvable | undefined);
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        get databaseNameInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _tableName?;
        get tableName(): string;
        set tableName(value: string);
        get tableNameInput(): string | undefined;
        private _dimension;
        get dimension(): TimestreamDimensionPropertyList;
        putDimension(value: TimestreamDimensionProperty[] | cdktn.IResolvable): void;
        get dimensionInput(): cdktn.IResolvable | TimestreamDimensionProperty[] | undefined;
        private _timestamp;
        get timestamp(): TimestreamTimestampPropertyOutputReference;
        putTimestamp(value: TimestreamTimestampProperty): void;
        resetTimestamp(): void;
        get timestampInput(): TimestreamTimestampProperty | undefined;
    }
    class TimestreamPropertyList extends cdktn.ComplexList {
        internalValue?: TimestreamProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TimestreamPropertyOutputReference;
    }
}
