import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsThingGroupMembershipConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_thing_group_membership#id AwsThingGroupMembership#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_thing_group_membership#override_dynamic_group AwsThingGroupMembership#override_dynamic_group}
    */
    readonly overrideDynamicGroup?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_thing_group_membership#region AwsThingGroupMembership#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_thing_group_membership#thing_group_name AwsThingGroupMembership#thing_group_name}
    */
    readonly thingGroupName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_thing_group_membership#thing_name AwsThingGroupMembership#thing_name}
    */
    readonly thingName: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_thing_group_membership aws_iot_thing_group_membership}
*/
export declare class AwsThingGroupMembership extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_iot_thing_group_membership";
    /**
    * Generates CDKTN code for importing a AwsThingGroupMembership resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsThingGroupMembership to import
    * @param importFromId The id of the existing AwsThingGroupMembership that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_thing_group_membership#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsThingGroupMembership to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iot_thing_group_membership aws_iot_thing_group_membership} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsThingGroupMembershipConfig
    */
    constructor(scope: Construct, id: string, config: AwsThingGroupMembershipConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _overrideDynamicGroup?;
    get overrideDynamicGroup(): boolean | cdktn.IResolvable;
    set overrideDynamicGroup(value: boolean | cdktn.IResolvable);
    resetOverrideDynamicGroup(): void;
    get overrideDynamicGroupInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _thingGroupName?;
    get thingGroupName(): string;
    set thingGroupName(value: string);
    get thingGroupNameInput(): string | undefined;
    private _thingName?;
    get thingName(): string;
    set thingName(value: string);
    get thingNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
