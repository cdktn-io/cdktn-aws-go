import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsServerlessapplicationrepositoryCloudformationStackConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/serverlessapplicationrepository_cloudformation_stack#application_id AwsServerlessapplicationrepositoryCloudformationStack#application_id}
    */
    readonly applicationId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/serverlessapplicationrepository_cloudformation_stack#capabilities AwsServerlessapplicationrepositoryCloudformationStack#capabilities}
    */
    readonly capabilities?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/serverlessapplicationrepository_cloudformation_stack#id AwsServerlessapplicationrepositoryCloudformationStack#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/serverlessapplicationrepository_cloudformation_stack#name AwsServerlessapplicationrepositoryCloudformationStack#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/serverlessapplicationrepository_cloudformation_stack#parameters AwsServerlessapplicationrepositoryCloudformationStack#parameters}
    */
    readonly parameters?: {
        [key: string]: string;
    };
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/serverlessapplicationrepository_cloudformation_stack#region AwsServerlessapplicationrepositoryCloudformationStack#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/serverlessapplicationrepository_cloudformation_stack#semantic_version AwsServerlessapplicationrepositoryCloudformationStack#semantic_version}
    */
    readonly semanticVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/serverlessapplicationrepository_cloudformation_stack#tags AwsServerlessapplicationrepositoryCloudformationStack#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/serverlessapplicationrepository_cloudformation_stack#tags_all AwsServerlessapplicationrepositoryCloudformationStack#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/serverlessapplicationrepository_cloudformation_stack#timeouts AwsServerlessapplicationrepositoryCloudformationStack#timeouts}
    */
    readonly timeouts?: AwsServerlessapplicationrepositoryCloudformationStack.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/serverlessapplicationrepository_cloudformation_stack aws_serverlessapplicationrepository_cloudformation_stack}
*/
export declare class AwsServerlessapplicationrepositoryCloudformationStack extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_serverlessapplicationrepository_cloudformation_stack";
    /**
    * Generates CDKTN code for importing a AwsServerlessapplicationrepositoryCloudformationStack resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsServerlessapplicationrepositoryCloudformationStack to import
    * @param importFromId The id of the existing AwsServerlessapplicationrepositoryCloudformationStack that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/serverlessapplicationrepository_cloudformation_stack#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsServerlessapplicationrepositoryCloudformationStack to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/serverlessapplicationrepository_cloudformation_stack aws_serverlessapplicationrepository_cloudformation_stack} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsServerlessapplicationrepositoryCloudformationStackConfig
    */
    constructor(scope: Construct, id: string, config: AwsServerlessapplicationrepositoryCloudformationStackConfig);
    private _applicationId?;
    get applicationId(): string;
    set applicationId(value: string);
    get applicationIdInput(): string | undefined;
    private _capabilities?;
    get capabilities(): string[];
    set capabilities(value: string[]);
    resetCapabilities(): void;
    get capabilitiesInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _outputs;
    get outputs(): cdktn.StringMap;
    private _parameters?;
    get parameters(): {
        [key: string]: string;
    };
    set parameters(value: {
        [key: string]: string;
    });
    resetParameters(): void;
    get parametersInput(): {
        [key: string]: string;
    } | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _semanticVersion?;
    get semanticVersion(): string;
    set semanticVersion(value: string);
    resetSemanticVersion(): void;
    get semanticVersionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _timeouts;
    get timeouts(): AwsServerlessapplicationrepositoryCloudformationStack.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsServerlessapplicationrepositoryCloudformationStack.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): AwsServerlessapplicationrepositoryCloudformationStack.TimeoutsProperty | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsServerlessapplicationrepositoryCloudformationStackTimeoutsPropertyToTerraform(struct?: AwsServerlessapplicationrepositoryCloudformationStack.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsServerlessapplicationrepositoryCloudformationStackTimeoutsPropertyToHclTerraform(struct?: AwsServerlessapplicationrepositoryCloudformationStack.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsServerlessapplicationrepositoryCloudformationStack {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/serverlessapplicationrepository_cloudformation_stack#create AwsServerlessapplicationrepositoryCloudformationStack#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/serverlessapplicationrepository_cloudformation_stack#delete AwsServerlessapplicationrepositoryCloudformationStack#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/serverlessapplicationrepository_cloudformation_stack#update AwsServerlessapplicationrepositoryCloudformationStack#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
