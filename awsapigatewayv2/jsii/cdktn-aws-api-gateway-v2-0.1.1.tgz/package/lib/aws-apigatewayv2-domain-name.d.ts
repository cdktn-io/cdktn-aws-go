import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsApigatewayv2DomainNameConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_domain_name#domain_name AwsApigatewayv2DomainName#domain_name}
    */
    readonly domainName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_domain_name#id AwsApigatewayv2DomainName#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_domain_name#region AwsApigatewayv2DomainName#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_domain_name#routing_mode AwsApigatewayv2DomainName#routing_mode}
    */
    readonly routingMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_domain_name#tags AwsApigatewayv2DomainName#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_domain_name#tags_all AwsApigatewayv2DomainName#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * domain_name_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_domain_name#domain_name_configuration AwsApigatewayv2DomainName#domain_name_configuration}
    */
    readonly domainNameConfiguration: AwsApigatewayv2DomainName.DomainNameConfigurationProperty;
    /**
    * mutual_tls_authentication block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_domain_name#mutual_tls_authentication AwsApigatewayv2DomainName#mutual_tls_authentication}
    */
    readonly mutualTlsAuthentication?: AwsApigatewayv2DomainName.MutualTlsAuthenticationProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_domain_name#timeouts AwsApigatewayv2DomainName#timeouts}
    */
    readonly timeouts?: AwsApigatewayv2DomainName.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_domain_name aws_apigatewayv2_domain_name}
*/
export declare class AwsApigatewayv2DomainName extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_apigatewayv2_domain_name";
    /**
    * Generates CDKTN code for importing a AwsApigatewayv2DomainName resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsApigatewayv2DomainName to import
    * @param importFromId The id of the existing AwsApigatewayv2DomainName that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_domain_name#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsApigatewayv2DomainName to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_domain_name aws_apigatewayv2_domain_name} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsApigatewayv2DomainNameConfig
    */
    constructor(scope: Construct, id: string, config: AwsApigatewayv2DomainNameConfig);
    get apiMappingSelectionExpression(): string;
    get arn(): string;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _routingMode?;
    get routingMode(): string;
    set routingMode(value: string);
    resetRoutingMode(): void;
    get routingModeInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _domainNameConfiguration;
    get domainNameConfiguration(): AwsApigatewayv2DomainName.DomainNameConfigurationPropertyOutputReference;
    putDomainNameConfiguration(value: AwsApigatewayv2DomainName.DomainNameConfigurationProperty): void;
    get domainNameConfigurationInput(): AwsApigatewayv2DomainName.DomainNameConfigurationProperty | undefined;
    private _mutualTlsAuthentication;
    get mutualTlsAuthentication(): AwsApigatewayv2DomainName.MutualTlsAuthenticationPropertyOutputReference;
    putMutualTlsAuthentication(value: AwsApigatewayv2DomainName.MutualTlsAuthenticationProperty): void;
    resetMutualTlsAuthentication(): void;
    get mutualTlsAuthenticationInput(): AwsApigatewayv2DomainName.MutualTlsAuthenticationProperty | undefined;
    private _timeouts;
    get timeouts(): AwsApigatewayv2DomainName.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsApigatewayv2DomainName.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsApigatewayv2DomainName.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsApigatewayv2DomainNameDomainNameConfigurationPropertyToTerraform(struct?: AwsApigatewayv2DomainName.DomainNameConfigurationPropertyOutputReference | AwsApigatewayv2DomainName.DomainNameConfigurationProperty): any;
export declare function awsApigatewayv2DomainNameDomainNameConfigurationPropertyToHclTerraform(struct?: AwsApigatewayv2DomainName.DomainNameConfigurationPropertyOutputReference | AwsApigatewayv2DomainName.DomainNameConfigurationProperty): any;
export declare function awsApigatewayv2DomainNameMutualTlsAuthenticationPropertyToTerraform(struct?: AwsApigatewayv2DomainName.MutualTlsAuthenticationPropertyOutputReference | AwsApigatewayv2DomainName.MutualTlsAuthenticationProperty): any;
export declare function awsApigatewayv2DomainNameMutualTlsAuthenticationPropertyToHclTerraform(struct?: AwsApigatewayv2DomainName.MutualTlsAuthenticationPropertyOutputReference | AwsApigatewayv2DomainName.MutualTlsAuthenticationProperty): any;
export declare function awsApigatewayv2DomainNameTimeoutsPropertyToTerraform(struct?: AwsApigatewayv2DomainName.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsApigatewayv2DomainNameTimeoutsPropertyToHclTerraform(struct?: AwsApigatewayv2DomainName.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsApigatewayv2DomainName {
    interface DomainNameConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_domain_name#certificate_arn AwsApigatewayv2DomainName#certificate_arn}
        */
        readonly certificateArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_domain_name#endpoint_type AwsApigatewayv2DomainName#endpoint_type}
        */
        readonly endpointType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_domain_name#ip_address_type AwsApigatewayv2DomainName#ip_address_type}
        */
        readonly ipAddressType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_domain_name#ownership_verification_certificate_arn AwsApigatewayv2DomainName#ownership_verification_certificate_arn}
        */
        readonly ownershipVerificationCertificateArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_domain_name#security_policy AwsApigatewayv2DomainName#security_policy}
        */
        readonly securityPolicy: string;
    }
    class DomainNameConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DomainNameConfigurationProperty | undefined;
        set internalValue(value: DomainNameConfigurationProperty | undefined);
        private _certificateArn?;
        get certificateArn(): string;
        set certificateArn(value: string);
        get certificateArnInput(): string | undefined;
        private _endpointType?;
        get endpointType(): string;
        set endpointType(value: string);
        get endpointTypeInput(): string | undefined;
        get hostedZoneId(): string;
        private _ipAddressType?;
        get ipAddressType(): string;
        set ipAddressType(value: string);
        resetIpAddressType(): void;
        get ipAddressTypeInput(): string | undefined;
        private _ownershipVerificationCertificateArn?;
        get ownershipVerificationCertificateArn(): string;
        set ownershipVerificationCertificateArn(value: string);
        resetOwnershipVerificationCertificateArn(): void;
        get ownershipVerificationCertificateArnInput(): string | undefined;
        private _securityPolicy?;
        get securityPolicy(): string;
        set securityPolicy(value: string);
        get securityPolicyInput(): string | undefined;
        get targetDomainName(): string;
    }
    interface MutualTlsAuthenticationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_domain_name#truststore_uri AwsApigatewayv2DomainName#truststore_uri}
        */
        readonly truststoreUri: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_domain_name#truststore_version AwsApigatewayv2DomainName#truststore_version}
        */
        readonly truststoreVersion?: string;
    }
    class MutualTlsAuthenticationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MutualTlsAuthenticationProperty | undefined;
        set internalValue(value: MutualTlsAuthenticationProperty | undefined);
        private _truststoreUri?;
        get truststoreUri(): string;
        set truststoreUri(value: string);
        get truststoreUriInput(): string | undefined;
        private _truststoreVersion?;
        get truststoreVersion(): string;
        set truststoreVersion(value: string);
        resetTruststoreVersion(): void;
        get truststoreVersionInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_domain_name#create AwsApigatewayv2DomainName#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_domain_name#update AwsApigatewayv2DomainName#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
