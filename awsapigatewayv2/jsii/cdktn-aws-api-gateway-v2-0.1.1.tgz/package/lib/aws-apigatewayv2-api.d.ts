import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsApigatewayv2ApiConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_api#api_key_selection_expression AwsApigatewayv2Api#api_key_selection_expression}
    */
    readonly apiKeySelectionExpression?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_api#body AwsApigatewayv2Api#body}
    */
    readonly body?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_api#credentials_arn AwsApigatewayv2Api#credentials_arn}
    */
    readonly credentialsArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_api#description AwsApigatewayv2Api#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_api#disable_execute_api_endpoint AwsApigatewayv2Api#disable_execute_api_endpoint}
    */
    readonly disableExecuteApiEndpoint?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_api#fail_on_warnings AwsApigatewayv2Api#fail_on_warnings}
    */
    readonly failOnWarnings?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_api#id AwsApigatewayv2Api#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_api#ip_address_type AwsApigatewayv2Api#ip_address_type}
    */
    readonly ipAddressType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_api#name AwsApigatewayv2Api#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_api#protocol_type AwsApigatewayv2Api#protocol_type}
    */
    readonly protocolType: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_api#region AwsApigatewayv2Api#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_api#route_key AwsApigatewayv2Api#route_key}
    */
    readonly routeKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_api#route_selection_expression AwsApigatewayv2Api#route_selection_expression}
    */
    readonly routeSelectionExpression?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_api#tags AwsApigatewayv2Api#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_api#tags_all AwsApigatewayv2Api#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_api#target AwsApigatewayv2Api#target}
    */
    readonly target?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_api#version AwsApigatewayv2Api#version}
    */
    readonly version?: string;
    /**
    * cors_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_api#cors_configuration AwsApigatewayv2Api#cors_configuration}
    */
    readonly corsConfiguration?: AwsApigatewayv2Api.CorsConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_api aws_apigatewayv2_api}
*/
export declare class AwsApigatewayv2Api extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_apigatewayv2_api";
    /**
    * Generates CDKTN code for importing a AwsApigatewayv2Api resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsApigatewayv2Api to import
    * @param importFromId The id of the existing AwsApigatewayv2Api that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_api#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsApigatewayv2Api to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_api aws_apigatewayv2_api} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsApigatewayv2ApiConfig
    */
    constructor(scope: Construct, id: string, config: AwsApigatewayv2ApiConfig);
    get apiEndpoint(): string;
    private _apiKeySelectionExpression?;
    get apiKeySelectionExpression(): string;
    set apiKeySelectionExpression(value: string);
    resetApiKeySelectionExpression(): void;
    get apiKeySelectionExpressionInput(): string | undefined;
    get arn(): string;
    private _body?;
    get body(): string;
    set body(value: string);
    resetBody(): void;
    get bodyInput(): string | undefined;
    private _credentialsArn?;
    get credentialsArn(): string;
    set credentialsArn(value: string);
    resetCredentialsArn(): void;
    get credentialsArnInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _disableExecuteApiEndpoint?;
    get disableExecuteApiEndpoint(): boolean | cdktn.IResolvable;
    set disableExecuteApiEndpoint(value: boolean | cdktn.IResolvable);
    resetDisableExecuteApiEndpoint(): void;
    get disableExecuteApiEndpointInput(): boolean | cdktn.IResolvable | undefined;
    get executionArn(): string;
    private _failOnWarnings?;
    get failOnWarnings(): boolean | cdktn.IResolvable;
    set failOnWarnings(value: boolean | cdktn.IResolvable);
    resetFailOnWarnings(): void;
    get failOnWarningsInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipAddressType?;
    get ipAddressType(): string;
    set ipAddressType(value: string);
    resetIpAddressType(): void;
    get ipAddressTypeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _protocolType?;
    get protocolType(): string;
    set protocolType(value: string);
    get protocolTypeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _routeKey?;
    get routeKey(): string;
    set routeKey(value: string);
    resetRouteKey(): void;
    get routeKeyInput(): string | undefined;
    private _routeSelectionExpression?;
    get routeSelectionExpression(): string;
    set routeSelectionExpression(value: string);
    resetRouteSelectionExpression(): void;
    get routeSelectionExpressionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _target?;
    get target(): string;
    set target(value: string);
    resetTarget(): void;
    get targetInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
    private _corsConfiguration;
    get corsConfiguration(): AwsApigatewayv2Api.CorsConfigurationPropertyOutputReference;
    putCorsConfiguration(value: AwsApigatewayv2Api.CorsConfigurationProperty): void;
    resetCorsConfiguration(): void;
    get corsConfigurationInput(): AwsApigatewayv2Api.CorsConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsApigatewayv2ApiCorsConfigurationPropertyToTerraform(struct?: AwsApigatewayv2Api.CorsConfigurationPropertyOutputReference | AwsApigatewayv2Api.CorsConfigurationProperty): any;
export declare function awsApigatewayv2ApiCorsConfigurationPropertyToHclTerraform(struct?: AwsApigatewayv2Api.CorsConfigurationPropertyOutputReference | AwsApigatewayv2Api.CorsConfigurationProperty): any;
export declare namespace AwsApigatewayv2Api {
    interface CorsConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_api#allow_credentials AwsApigatewayv2Api#allow_credentials}
        */
        readonly allowCredentials?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_api#allow_headers AwsApigatewayv2Api#allow_headers}
        */
        readonly allowHeaders?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_api#allow_methods AwsApigatewayv2Api#allow_methods}
        */
        readonly allowMethods?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_api#allow_origins AwsApigatewayv2Api#allow_origins}
        */
        readonly allowOrigins?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_api#expose_headers AwsApigatewayv2Api#expose_headers}
        */
        readonly exposeHeaders?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_api#max_age AwsApigatewayv2Api#max_age}
        */
        readonly maxAge?: number;
    }
    class CorsConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CorsConfigurationProperty | undefined;
        set internalValue(value: CorsConfigurationProperty | undefined);
        private _allowCredentials?;
        get allowCredentials(): boolean | cdktn.IResolvable;
        set allowCredentials(value: boolean | cdktn.IResolvable);
        resetAllowCredentials(): void;
        get allowCredentialsInput(): boolean | cdktn.IResolvable | undefined;
        private _allowHeaders?;
        get allowHeaders(): string[];
        set allowHeaders(value: string[]);
        resetAllowHeaders(): void;
        get allowHeadersInput(): string[] | undefined;
        private _allowMethods?;
        get allowMethods(): string[];
        set allowMethods(value: string[]);
        resetAllowMethods(): void;
        get allowMethodsInput(): string[] | undefined;
        private _allowOrigins?;
        get allowOrigins(): string[];
        set allowOrigins(value: string[]);
        resetAllowOrigins(): void;
        get allowOriginsInput(): string[] | undefined;
        private _exposeHeaders?;
        get exposeHeaders(): string[];
        set exposeHeaders(value: string[]);
        resetExposeHeaders(): void;
        get exposeHeadersInput(): string[] | undefined;
        private _maxAge?;
        get maxAge(): number;
        set maxAge(value: number);
        resetMaxAge(): void;
        get maxAgeInput(): number | undefined;
    }
}
