import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsApigatewayv2AuthorizerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_authorizer#api_id AwsApigatewayv2Authorizer#api_id}
    */
    readonly apiId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_authorizer#authorizer_credentials_arn AwsApigatewayv2Authorizer#authorizer_credentials_arn}
    */
    readonly authorizerCredentialsArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_authorizer#authorizer_payload_format_version AwsApigatewayv2Authorizer#authorizer_payload_format_version}
    */
    readonly authorizerPayloadFormatVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_authorizer#authorizer_result_ttl_in_seconds AwsApigatewayv2Authorizer#authorizer_result_ttl_in_seconds}
    */
    readonly authorizerResultTtlInSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_authorizer#authorizer_type AwsApigatewayv2Authorizer#authorizer_type}
    */
    readonly authorizerType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_authorizer#authorizer_uri AwsApigatewayv2Authorizer#authorizer_uri}
    */
    readonly authorizerUri?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_authorizer#enable_simple_responses AwsApigatewayv2Authorizer#enable_simple_responses}
    */
    readonly enableSimpleResponses?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_authorizer#id AwsApigatewayv2Authorizer#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_authorizer#identity_sources AwsApigatewayv2Authorizer#identity_sources}
    */
    readonly identitySources?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_authorizer#name AwsApigatewayv2Authorizer#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_authorizer#region AwsApigatewayv2Authorizer#region}
    */
    readonly region?: string;
    /**
    * jwt_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_authorizer#jwt_configuration AwsApigatewayv2Authorizer#jwt_configuration}
    */
    readonly jwtConfiguration?: AwsApigatewayv2Authorizer.JwtConfigurationProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_authorizer#timeouts AwsApigatewayv2Authorizer#timeouts}
    */
    readonly timeouts?: AwsApigatewayv2Authorizer.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_authorizer aws_apigatewayv2_authorizer}
*/
export declare class AwsApigatewayv2Authorizer extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_apigatewayv2_authorizer";
    /**
    * Generates CDKTN code for importing a AwsApigatewayv2Authorizer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsApigatewayv2Authorizer to import
    * @param importFromId The id of the existing AwsApigatewayv2Authorizer that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_authorizer#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsApigatewayv2Authorizer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_authorizer aws_apigatewayv2_authorizer} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsApigatewayv2AuthorizerConfig
    */
    constructor(scope: Construct, id: string, config: AwsApigatewayv2AuthorizerConfig);
    private _apiId?;
    get apiId(): string;
    set apiId(value: string);
    get apiIdInput(): string | undefined;
    private _authorizerCredentialsArn?;
    get authorizerCredentialsArn(): string;
    set authorizerCredentialsArn(value: string);
    resetAuthorizerCredentialsArn(): void;
    get authorizerCredentialsArnInput(): string | undefined;
    private _authorizerPayloadFormatVersion?;
    get authorizerPayloadFormatVersion(): string;
    set authorizerPayloadFormatVersion(value: string);
    resetAuthorizerPayloadFormatVersion(): void;
    get authorizerPayloadFormatVersionInput(): string | undefined;
    private _authorizerResultTtlInSeconds?;
    get authorizerResultTtlInSeconds(): number;
    set authorizerResultTtlInSeconds(value: number);
    resetAuthorizerResultTtlInSeconds(): void;
    get authorizerResultTtlInSecondsInput(): number | undefined;
    private _authorizerType?;
    get authorizerType(): string;
    set authorizerType(value: string);
    get authorizerTypeInput(): string | undefined;
    private _authorizerUri?;
    get authorizerUri(): string;
    set authorizerUri(value: string);
    resetAuthorizerUri(): void;
    get authorizerUriInput(): string | undefined;
    private _enableSimpleResponses?;
    get enableSimpleResponses(): boolean | cdktn.IResolvable;
    set enableSimpleResponses(value: boolean | cdktn.IResolvable);
    resetEnableSimpleResponses(): void;
    get enableSimpleResponsesInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identitySources?;
    get identitySources(): string[];
    set identitySources(value: string[]);
    resetIdentitySources(): void;
    get identitySourcesInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _jwtConfiguration;
    get jwtConfiguration(): AwsApigatewayv2Authorizer.JwtConfigurationPropertyOutputReference;
    putJwtConfiguration(value: AwsApigatewayv2Authorizer.JwtConfigurationProperty): void;
    resetJwtConfiguration(): void;
    get jwtConfigurationInput(): AwsApigatewayv2Authorizer.JwtConfigurationProperty | undefined;
    private _timeouts;
    get timeouts(): AwsApigatewayv2Authorizer.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsApigatewayv2Authorizer.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsApigatewayv2Authorizer.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsApigatewayv2AuthorizerJwtConfigurationPropertyToTerraform(struct?: AwsApigatewayv2Authorizer.JwtConfigurationPropertyOutputReference | AwsApigatewayv2Authorizer.JwtConfigurationProperty): any;
export declare function awsApigatewayv2AuthorizerJwtConfigurationPropertyToHclTerraform(struct?: AwsApigatewayv2Authorizer.JwtConfigurationPropertyOutputReference | AwsApigatewayv2Authorizer.JwtConfigurationProperty): any;
export declare function awsApigatewayv2AuthorizerTimeoutsPropertyToTerraform(struct?: AwsApigatewayv2Authorizer.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsApigatewayv2AuthorizerTimeoutsPropertyToHclTerraform(struct?: AwsApigatewayv2Authorizer.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsApigatewayv2Authorizer {
    interface JwtConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_authorizer#audience AwsApigatewayv2Authorizer#audience}
        */
        readonly audience?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_authorizer#issuer AwsApigatewayv2Authorizer#issuer}
        */
        readonly issuer?: string;
    }
    class JwtConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): JwtConfigurationProperty | undefined;
        set internalValue(value: JwtConfigurationProperty | undefined);
        private _audience?;
        get audience(): string[];
        set audience(value: string[]);
        resetAudience(): void;
        get audienceInput(): string[] | undefined;
        private _issuer?;
        get issuer(): string;
        set issuer(value: string);
        resetIssuer(): void;
        get issuerInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_authorizer#delete AwsApigatewayv2Authorizer#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
