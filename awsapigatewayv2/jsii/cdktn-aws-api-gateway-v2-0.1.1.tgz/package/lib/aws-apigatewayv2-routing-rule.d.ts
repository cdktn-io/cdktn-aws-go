import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsApigatewayv2RoutingRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_routing_rule#domain_name AwsApigatewayv2RoutingRule#domain_name}
    */
    readonly domainName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_routing_rule#priority AwsApigatewayv2RoutingRule#priority}
    */
    readonly priority: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_routing_rule#region AwsApigatewayv2RoutingRule#region}
    */
    readonly region?: string;
    /**
    * action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_routing_rule#action AwsApigatewayv2RoutingRule#action}
    */
    readonly action?: AwsApigatewayv2RoutingRule.ActionProperty[] | cdktn.IResolvable;
    /**
    * condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_routing_rule#condition AwsApigatewayv2RoutingRule#condition}
    */
    readonly condition?: AwsApigatewayv2RoutingRule.ConditionProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_routing_rule aws_apigatewayv2_routing_rule}
*/
export declare class AwsApigatewayv2RoutingRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_apigatewayv2_routing_rule";
    /**
    * Generates CDKTN code for importing a AwsApigatewayv2RoutingRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsApigatewayv2RoutingRule to import
    * @param importFromId The id of the existing AwsApigatewayv2RoutingRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_routing_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsApigatewayv2RoutingRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_routing_rule aws_apigatewayv2_routing_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsApigatewayv2RoutingRuleConfig
    */
    constructor(scope: Construct, id: string, config: AwsApigatewayv2RoutingRuleConfig);
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    get priorityInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get routingRuleArn(): string;
    get routingRuleId(): string;
    private _action;
    get action(): AwsApigatewayv2RoutingRule.ActionPropertyList;
    putAction(value: AwsApigatewayv2RoutingRule.ActionProperty[] | cdktn.IResolvable): void;
    resetAction(): void;
    get actionInput(): cdktn.IResolvable | AwsApigatewayv2RoutingRule.ActionProperty[] | undefined;
    private _condition;
    get condition(): AwsApigatewayv2RoutingRule.ConditionPropertyList;
    putCondition(value: AwsApigatewayv2RoutingRule.ConditionProperty[] | cdktn.IResolvable): void;
    resetCondition(): void;
    get conditionInput(): cdktn.IResolvable | AwsApigatewayv2RoutingRule.ConditionProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsApigatewayv2RoutingRuleInvokeApiPropertyToTerraform(struct?: AwsApigatewayv2RoutingRule.InvokeApiProperty | cdktn.IResolvable): any;
export declare function awsApigatewayv2RoutingRuleInvokeApiPropertyToHclTerraform(struct?: AwsApigatewayv2RoutingRule.InvokeApiProperty | cdktn.IResolvable): any;
export declare function awsApigatewayv2RoutingRuleActionPropertyToTerraform(struct?: AwsApigatewayv2RoutingRule.ActionProperty | cdktn.IResolvable): any;
export declare function awsApigatewayv2RoutingRuleActionPropertyToHclTerraform(struct?: AwsApigatewayv2RoutingRule.ActionProperty | cdktn.IResolvable): any;
export declare function awsApigatewayv2RoutingRuleMatchBasePathsPropertyToTerraform(struct?: AwsApigatewayv2RoutingRule.MatchBasePathsProperty | cdktn.IResolvable): any;
export declare function awsApigatewayv2RoutingRuleMatchBasePathsPropertyToHclTerraform(struct?: AwsApigatewayv2RoutingRule.MatchBasePathsProperty | cdktn.IResolvable): any;
export declare function awsApigatewayv2RoutingRuleAnyOfPropertyToTerraform(struct?: AwsApigatewayv2RoutingRule.AnyOfProperty | cdktn.IResolvable): any;
export declare function awsApigatewayv2RoutingRuleAnyOfPropertyToHclTerraform(struct?: AwsApigatewayv2RoutingRule.AnyOfProperty | cdktn.IResolvable): any;
export declare function awsApigatewayv2RoutingRuleMatchHeadersPropertyToTerraform(struct?: AwsApigatewayv2RoutingRule.MatchHeadersProperty | cdktn.IResolvable): any;
export declare function awsApigatewayv2RoutingRuleMatchHeadersPropertyToHclTerraform(struct?: AwsApigatewayv2RoutingRule.MatchHeadersProperty | cdktn.IResolvable): any;
export declare function awsApigatewayv2RoutingRuleConditionPropertyToTerraform(struct?: AwsApigatewayv2RoutingRule.ConditionProperty | cdktn.IResolvable): any;
export declare function awsApigatewayv2RoutingRuleConditionPropertyToHclTerraform(struct?: AwsApigatewayv2RoutingRule.ConditionProperty | cdktn.IResolvable): any;
export declare namespace AwsApigatewayv2RoutingRule {
    interface InvokeApiProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_routing_rule#api_id AwsApigatewayv2RoutingRule#api_id}
        */
        readonly apiId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_routing_rule#stage AwsApigatewayv2RoutingRule#stage}
        */
        readonly stage: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_routing_rule#strip_base_path AwsApigatewayv2RoutingRule#strip_base_path}
        */
        readonly stripBasePath?: boolean | cdktn.IResolvable;
    }
    class InvokeApiPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InvokeApiProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InvokeApiProperty | cdktn.IResolvable | undefined);
        private _apiId?;
        get apiId(): string;
        set apiId(value: string);
        get apiIdInput(): string | undefined;
        private _stage?;
        get stage(): string;
        set stage(value: string);
        get stageInput(): string | undefined;
        private _stripBasePath?;
        get stripBasePath(): boolean | cdktn.IResolvable;
        set stripBasePath(value: boolean | cdktn.IResolvable);
        resetStripBasePath(): void;
        get stripBasePathInput(): boolean | cdktn.IResolvable | undefined;
    }
    class InvokeApiPropertyList extends cdktn.ComplexList {
        internalValue?: InvokeApiProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InvokeApiPropertyOutputReference;
    }
    interface ActionProperty {
        /**
        * invoke_api block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_routing_rule#invoke_api AwsApigatewayv2RoutingRule#invoke_api}
        */
        readonly invokeApi?: InvokeApiProperty[] | cdktn.IResolvable;
    }
    class ActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ActionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ActionProperty | cdktn.IResolvable | undefined);
        private _invokeApi;
        get invokeApi(): InvokeApiPropertyList;
        putInvokeApi(value: InvokeApiProperty[] | cdktn.IResolvable): void;
        resetInvokeApi(): void;
        get invokeApiInput(): cdktn.IResolvable | InvokeApiProperty[] | undefined;
    }
    class ActionPropertyList extends cdktn.ComplexList {
        internalValue?: ActionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ActionPropertyOutputReference;
    }
    interface MatchBasePathsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_routing_rule#any_of AwsApigatewayv2RoutingRule#any_of}
        */
        readonly anyOf: string[];
    }
    class MatchBasePathsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MatchBasePathsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MatchBasePathsProperty | cdktn.IResolvable | undefined);
        private _anyOf?;
        get anyOf(): string[];
        set anyOf(value: string[]);
        get anyOfInput(): string[] | undefined;
    }
    class MatchBasePathsPropertyList extends cdktn.ComplexList {
        internalValue?: MatchBasePathsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MatchBasePathsPropertyOutputReference;
    }
    interface AnyOfProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_routing_rule#header AwsApigatewayv2RoutingRule#header}
        */
        readonly header: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_routing_rule#value_glob AwsApigatewayv2RoutingRule#value_glob}
        */
        readonly valueGlob: string;
    }
    class AnyOfPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AnyOfProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AnyOfProperty | cdktn.IResolvable | undefined);
        private _header?;
        get header(): string;
        set header(value: string);
        get headerInput(): string | undefined;
        private _valueGlob?;
        get valueGlob(): string;
        set valueGlob(value: string);
        get valueGlobInput(): string | undefined;
    }
    class AnyOfPropertyList extends cdktn.ComplexList {
        internalValue?: AnyOfProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AnyOfPropertyOutputReference;
    }
    interface MatchHeadersProperty {
        /**
        * any_of block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_routing_rule#any_of AwsApigatewayv2RoutingRule#any_of}
        */
        readonly anyOf?: AnyOfProperty[] | cdktn.IResolvable;
    }
    class MatchHeadersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MatchHeadersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MatchHeadersProperty | cdktn.IResolvable | undefined);
        private _anyOf;
        get anyOf(): AnyOfPropertyList;
        putAnyOf(value: AnyOfProperty[] | cdktn.IResolvable): void;
        resetAnyOf(): void;
        get anyOfInput(): cdktn.IResolvable | AnyOfProperty[] | undefined;
    }
    class MatchHeadersPropertyList extends cdktn.ComplexList {
        internalValue?: MatchHeadersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MatchHeadersPropertyOutputReference;
    }
    interface ConditionProperty {
        /**
        * match_base_paths block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_routing_rule#match_base_paths AwsApigatewayv2RoutingRule#match_base_paths}
        */
        readonly matchBasePaths?: MatchBasePathsProperty[] | cdktn.IResolvable;
        /**
        * match_headers block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_routing_rule#match_headers AwsApigatewayv2RoutingRule#match_headers}
        */
        readonly matchHeaders?: MatchHeadersProperty[] | cdktn.IResolvable;
    }
    class ConditionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConditionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConditionProperty | cdktn.IResolvable | undefined);
        private _matchBasePaths;
        get matchBasePaths(): MatchBasePathsPropertyList;
        putMatchBasePaths(value: MatchBasePathsProperty[] | cdktn.IResolvable): void;
        resetMatchBasePaths(): void;
        get matchBasePathsInput(): cdktn.IResolvable | MatchBasePathsProperty[] | undefined;
        private _matchHeaders;
        get matchHeaders(): MatchHeadersPropertyList;
        putMatchHeaders(value: MatchHeadersProperty[] | cdktn.IResolvable): void;
        resetMatchHeaders(): void;
        get matchHeadersInput(): cdktn.IResolvable | MatchHeadersProperty[] | undefined;
    }
    class ConditionPropertyList extends cdktn.ComplexList {
        internalValue?: ConditionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConditionPropertyOutputReference;
    }
}
