import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsApigatewayv2IntegrationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_integration#api_id AwsApigatewayv2Integration#api_id}
    */
    readonly apiId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_integration#connection_id AwsApigatewayv2Integration#connection_id}
    */
    readonly connectionId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_integration#connection_type AwsApigatewayv2Integration#connection_type}
    */
    readonly connectionType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_integration#content_handling_strategy AwsApigatewayv2Integration#content_handling_strategy}
    */
    readonly contentHandlingStrategy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_integration#credentials_arn AwsApigatewayv2Integration#credentials_arn}
    */
    readonly credentialsArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_integration#description AwsApigatewayv2Integration#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_integration#id AwsApigatewayv2Integration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_integration#integration_method AwsApigatewayv2Integration#integration_method}
    */
    readonly integrationMethod?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_integration#integration_subtype AwsApigatewayv2Integration#integration_subtype}
    */
    readonly integrationSubtype?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_integration#integration_type AwsApigatewayv2Integration#integration_type}
    */
    readonly integrationType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_integration#integration_uri AwsApigatewayv2Integration#integration_uri}
    */
    readonly integrationUri?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_integration#passthrough_behavior AwsApigatewayv2Integration#passthrough_behavior}
    */
    readonly passthroughBehavior?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_integration#payload_format_version AwsApigatewayv2Integration#payload_format_version}
    */
    readonly payloadFormatVersion?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_integration#region AwsApigatewayv2Integration#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_integration#request_parameters AwsApigatewayv2Integration#request_parameters}
    */
    readonly requestParameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_integration#request_templates AwsApigatewayv2Integration#request_templates}
    */
    readonly requestTemplates?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_integration#template_selection_expression AwsApigatewayv2Integration#template_selection_expression}
    */
    readonly templateSelectionExpression?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_integration#timeout_milliseconds AwsApigatewayv2Integration#timeout_milliseconds}
    */
    readonly timeoutMilliseconds?: number;
    /**
    * response_parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_integration#response_parameters AwsApigatewayv2Integration#response_parameters}
    */
    readonly responseParameters?: AwsApigatewayv2Integration.ResponseParametersProperty[] | cdktn.IResolvable;
    /**
    * tls_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_integration#tls_config AwsApigatewayv2Integration#tls_config}
    */
    readonly tlsConfig?: AwsApigatewayv2Integration.TlsConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_integration aws_apigatewayv2_integration}
*/
export declare class AwsApigatewayv2Integration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_apigatewayv2_integration";
    /**
    * Generates CDKTN code for importing a AwsApigatewayv2Integration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsApigatewayv2Integration to import
    * @param importFromId The id of the existing AwsApigatewayv2Integration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_integration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsApigatewayv2Integration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_integration aws_apigatewayv2_integration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsApigatewayv2IntegrationConfig
    */
    constructor(scope: Construct, id: string, config: AwsApigatewayv2IntegrationConfig);
    private _apiId?;
    get apiId(): string;
    set apiId(value: string);
    get apiIdInput(): string | undefined;
    private _connectionId?;
    get connectionId(): string;
    set connectionId(value: string);
    resetConnectionId(): void;
    get connectionIdInput(): string | undefined;
    private _connectionType?;
    get connectionType(): string;
    set connectionType(value: string);
    resetConnectionType(): void;
    get connectionTypeInput(): string | undefined;
    private _contentHandlingStrategy?;
    get contentHandlingStrategy(): string;
    set contentHandlingStrategy(value: string);
    resetContentHandlingStrategy(): void;
    get contentHandlingStrategyInput(): string | undefined;
    private _credentialsArn?;
    get credentialsArn(): string;
    set credentialsArn(value: string);
    resetCredentialsArn(): void;
    get credentialsArnInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _integrationMethod?;
    get integrationMethod(): string;
    set integrationMethod(value: string);
    resetIntegrationMethod(): void;
    get integrationMethodInput(): string | undefined;
    get integrationResponseSelectionExpression(): string;
    private _integrationSubtype?;
    get integrationSubtype(): string;
    set integrationSubtype(value: string);
    resetIntegrationSubtype(): void;
    get integrationSubtypeInput(): string | undefined;
    private _integrationType?;
    get integrationType(): string;
    set integrationType(value: string);
    get integrationTypeInput(): string | undefined;
    private _integrationUri?;
    get integrationUri(): string;
    set integrationUri(value: string);
    resetIntegrationUri(): void;
    get integrationUriInput(): string | undefined;
    private _passthroughBehavior?;
    get passthroughBehavior(): string;
    set passthroughBehavior(value: string);
    resetPassthroughBehavior(): void;
    get passthroughBehaviorInput(): string | undefined;
    private _payloadFormatVersion?;
    get payloadFormatVersion(): string;
    set payloadFormatVersion(value: string);
    resetPayloadFormatVersion(): void;
    get payloadFormatVersionInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _requestParameters?;
    get requestParameters(): {
        [key: string]: string;
    };
    set requestParameters(value: {
        [key: string]: string;
    });
    resetRequestParameters(): void;
    get requestParametersInput(): {
        [key: string]: string;
    } | undefined;
    private _requestTemplates?;
    get requestTemplates(): {
        [key: string]: string;
    };
    set requestTemplates(value: {
        [key: string]: string;
    });
    resetRequestTemplates(): void;
    get requestTemplatesInput(): {
        [key: string]: string;
    } | undefined;
    private _templateSelectionExpression?;
    get templateSelectionExpression(): string;
    set templateSelectionExpression(value: string);
    resetTemplateSelectionExpression(): void;
    get templateSelectionExpressionInput(): string | undefined;
    private _timeoutMilliseconds?;
    get timeoutMilliseconds(): number;
    set timeoutMilliseconds(value: number);
    resetTimeoutMilliseconds(): void;
    get timeoutMillisecondsInput(): number | undefined;
    private _responseParameters;
    get responseParameters(): AwsApigatewayv2Integration.ResponseParametersPropertyList;
    putResponseParameters(value: AwsApigatewayv2Integration.ResponseParametersProperty[] | cdktn.IResolvable): void;
    resetResponseParameters(): void;
    get responseParametersInput(): cdktn.IResolvable | AwsApigatewayv2Integration.ResponseParametersProperty[] | undefined;
    private _tlsConfig;
    get tlsConfig(): AwsApigatewayv2Integration.TlsConfigPropertyOutputReference;
    putTlsConfig(value: AwsApigatewayv2Integration.TlsConfigProperty): void;
    resetTlsConfig(): void;
    get tlsConfigInput(): AwsApigatewayv2Integration.TlsConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsApigatewayv2IntegrationResponseParametersPropertyToTerraform(struct?: AwsApigatewayv2Integration.ResponseParametersProperty | cdktn.IResolvable): any;
export declare function awsApigatewayv2IntegrationResponseParametersPropertyToHclTerraform(struct?: AwsApigatewayv2Integration.ResponseParametersProperty | cdktn.IResolvable): any;
export declare function awsApigatewayv2IntegrationTlsConfigPropertyToTerraform(struct?: AwsApigatewayv2Integration.TlsConfigPropertyOutputReference | AwsApigatewayv2Integration.TlsConfigProperty): any;
export declare function awsApigatewayv2IntegrationTlsConfigPropertyToHclTerraform(struct?: AwsApigatewayv2Integration.TlsConfigPropertyOutputReference | AwsApigatewayv2Integration.TlsConfigProperty): any;
export declare namespace AwsApigatewayv2Integration {
    interface ResponseParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_integration#mappings AwsApigatewayv2Integration#mappings}
        */
        readonly mappings: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_integration#status_code AwsApigatewayv2Integration#status_code}
        */
        readonly statusCode: string;
    }
    class ResponseParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResponseParametersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResponseParametersProperty | cdktn.IResolvable | undefined);
        private _mappings?;
        get mappings(): {
            [key: string]: string;
        };
        set mappings(value: {
            [key: string]: string;
        });
        get mappingsInput(): {
            [key: string]: string;
        } | undefined;
        private _statusCode?;
        get statusCode(): string;
        set statusCode(value: string);
        get statusCodeInput(): string | undefined;
    }
    class ResponseParametersPropertyList extends cdktn.ComplexList {
        internalValue?: ResponseParametersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResponseParametersPropertyOutputReference;
    }
    interface TlsConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apigatewayv2_integration#server_name_to_verify AwsApigatewayv2Integration#server_name_to_verify}
        */
        readonly serverNameToVerify?: string;
    }
    class TlsConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TlsConfigProperty | undefined;
        set internalValue(value: TlsConfigProperty | undefined);
        private _serverNameToVerify?;
        get serverNameToVerify(): string;
        set serverNameToVerify(value: string);
        resetServerNameToVerify(): void;
        get serverNameToVerifyInput(): string | undefined;
    }
}
