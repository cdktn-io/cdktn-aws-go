import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsIamOrganizationsFeaturesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_organizations_features#enabled_features AwsIamOrganizationsFeatures#enabled_features}
    */
    readonly enabledFeatures: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_organizations_features aws_iam_organizations_features}
*/
export declare class AwsIamOrganizationsFeatures extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_iam_organizations_features";
    /**
    * Generates CDKTN code for importing a AwsIamOrganizationsFeatures resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsIamOrganizationsFeatures to import
    * @param importFromId The id of the existing AwsIamOrganizationsFeatures that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_organizations_features#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsIamOrganizationsFeatures to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_organizations_features aws_iam_organizations_features} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsIamOrganizationsFeaturesConfig
    */
    constructor(scope: Construct, id: string, config: AwsIamOrganizationsFeaturesConfig);
    private _enabledFeatures?;
    get enabledFeatures(): string[];
    set enabledFeatures(value: string[]);
    get enabledFeaturesInput(): string[] | undefined;
    get id(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
