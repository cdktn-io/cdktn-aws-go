import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsIamRolePolicyAttachmentsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/iam_role_policy_attachments#path_prefix DataAwsIamRolePolicyAttachments#path_prefix}
    */
    readonly pathPrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/iam_role_policy_attachments#role_name DataAwsIamRolePolicyAttachments#role_name}
    */
    readonly roleName: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/iam_role_policy_attachments aws_iam_role_policy_attachments}
*/
export declare class DataAwsIamRolePolicyAttachments extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_iam_role_policy_attachments";
    /**
    * Generates CDKTN code for importing a DataAwsIamRolePolicyAttachments resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsIamRolePolicyAttachments to import
    * @param importFromId The id of the existing DataAwsIamRolePolicyAttachments that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/iam_role_policy_attachments#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsIamRolePolicyAttachments to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/iam_role_policy_attachments aws_iam_role_policy_attachments} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsIamRolePolicyAttachmentsConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsIamRolePolicyAttachmentsConfig);
    private _attachedPolicies;
    get attachedPolicies(): DataAwsIamRolePolicyAttachments.AttachedPoliciesPropertyList;
    private _pathPrefix?;
    get pathPrefix(): string;
    set pathPrefix(value: string);
    resetPathPrefix(): void;
    get pathPrefixInput(): string | undefined;
    private _roleName?;
    get roleName(): string;
    set roleName(value: string);
    get roleNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsIamRolePolicyAttachmentsAttachedPoliciesPropertyToTerraform(struct?: DataAwsIamRolePolicyAttachments.AttachedPoliciesProperty): any;
export declare function dataAwsIamRolePolicyAttachmentsAttachedPoliciesPropertyToHclTerraform(struct?: DataAwsIamRolePolicyAttachments.AttachedPoliciesProperty): any;
export declare namespace DataAwsIamRolePolicyAttachments {
    interface AttachedPoliciesProperty {
    }
    class AttachedPoliciesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AttachedPoliciesProperty | undefined;
        set internalValue(value: AttachedPoliciesProperty | undefined);
        get policyArn(): string;
        get policyName(): string;
    }
    class AttachedPoliciesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AttachedPoliciesPropertyOutputReference;
    }
}
