import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsIamVirtualMfaDeviceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_virtual_mfa_device#id AwsIamVirtualMfaDevice#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_virtual_mfa_device#path AwsIamVirtualMfaDevice#path}
    */
    readonly path?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_virtual_mfa_device#tags AwsIamVirtualMfaDevice#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_virtual_mfa_device#tags_all AwsIamVirtualMfaDevice#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_virtual_mfa_device#virtual_mfa_device_name AwsIamVirtualMfaDevice#virtual_mfa_device_name}
    */
    readonly virtualMfaDeviceName: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_virtual_mfa_device aws_iam_virtual_mfa_device}
*/
export declare class AwsIamVirtualMfaDevice extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_iam_virtual_mfa_device";
    /**
    * Generates CDKTN code for importing a AwsIamVirtualMfaDevice resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsIamVirtualMfaDevice to import
    * @param importFromId The id of the existing AwsIamVirtualMfaDevice that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_virtual_mfa_device#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsIamVirtualMfaDevice to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_virtual_mfa_device aws_iam_virtual_mfa_device} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsIamVirtualMfaDeviceConfig
    */
    constructor(scope: Construct, id: string, config: AwsIamVirtualMfaDeviceConfig);
    get arn(): string;
    get base32StringSeed(): string;
    get enableDate(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    get qrCodePng(): string;
    get serialNumber(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get userName(): string;
    private _virtualMfaDeviceName?;
    get virtualMfaDeviceName(): string;
    set virtualMfaDeviceName(value: string);
    get virtualMfaDeviceNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
