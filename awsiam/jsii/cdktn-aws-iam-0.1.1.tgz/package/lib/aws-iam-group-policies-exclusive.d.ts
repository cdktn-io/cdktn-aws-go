import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsIamGroupPoliciesExclusiveConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_group_policies_exclusive#group_name AwsIamGroupPoliciesExclusive#group_name}
    */
    readonly groupName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_group_policies_exclusive#policy_names AwsIamGroupPoliciesExclusive#policy_names}
    */
    readonly policyNames: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_group_policies_exclusive aws_iam_group_policies_exclusive}
*/
export declare class AwsIamGroupPoliciesExclusive extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_iam_group_policies_exclusive";
    /**
    * Generates CDKTN code for importing a AwsIamGroupPoliciesExclusive resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsIamGroupPoliciesExclusive to import
    * @param importFromId The id of the existing AwsIamGroupPoliciesExclusive that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_group_policies_exclusive#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsIamGroupPoliciesExclusive to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_group_policies_exclusive aws_iam_group_policies_exclusive} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsIamGroupPoliciesExclusiveConfig
    */
    constructor(scope: Construct, id: string, config: AwsIamGroupPoliciesExclusiveConfig);
    private _groupName?;
    get groupName(): string;
    set groupName(value: string);
    get groupNameInput(): string | undefined;
    private _policyNames?;
    get policyNames(): string[];
    set policyNames(value: string[]);
    get policyNamesInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
