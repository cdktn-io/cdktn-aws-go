import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfRolePoliciesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/iam_role_policies#role_name DataTfRolePolicies#role_name}
    */
    readonly roleName: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/iam_role_policies aws_iam_role_policies}
*/
export declare class DataTfRolePolicies extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_iam_role_policies";
    /**
    * Generates CDKTN code for importing a DataTfRolePolicies resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfRolePolicies to import
    * @param importFromId The id of the existing DataTfRolePolicies that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/iam_role_policies#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfRolePolicies to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/iam_role_policies aws_iam_role_policies} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfRolePoliciesConfig
    */
    constructor(scope: Construct, id: string, config: DataTfRolePoliciesConfig);
    get policyNames(): string[];
    private _roleName?;
    get roleName(): string;
    set roleName(value: string);
    get roleNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
