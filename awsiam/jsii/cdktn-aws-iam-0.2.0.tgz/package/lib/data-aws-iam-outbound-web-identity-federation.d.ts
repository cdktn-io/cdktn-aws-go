import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfOutboundWebIdentityFederationConfig extends cdktn.TerraformMetaArguments {
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/iam_outbound_web_identity_federation aws_iam_outbound_web_identity_federation}
*/
export declare class DataTfOutboundWebIdentityFederation extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_iam_outbound_web_identity_federation";
    /**
    * Generates CDKTN code for importing a DataTfOutboundWebIdentityFederation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfOutboundWebIdentityFederation to import
    * @param importFromId The id of the existing DataTfOutboundWebIdentityFederation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/iam_outbound_web_identity_federation#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfOutboundWebIdentityFederation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/iam_outbound_web_identity_federation aws_iam_outbound_web_identity_federation} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfOutboundWebIdentityFederationConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataTfOutboundWebIdentityFederationConfig);
    get issuerIdentifier(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
