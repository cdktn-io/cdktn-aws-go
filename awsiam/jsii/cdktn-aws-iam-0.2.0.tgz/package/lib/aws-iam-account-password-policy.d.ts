import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfAccountPasswordPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_account_password_policy#allow_users_to_change_password TfAccountPasswordPolicy#allow_users_to_change_password}
    */
    readonly allowUsersToChangePassword?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_account_password_policy#hard_expiry TfAccountPasswordPolicy#hard_expiry}
    */
    readonly hardExpiry?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_account_password_policy#id TfAccountPasswordPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_account_password_policy#max_password_age TfAccountPasswordPolicy#max_password_age}
    */
    readonly maxPasswordAge?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_account_password_policy#minimum_password_length TfAccountPasswordPolicy#minimum_password_length}
    */
    readonly minimumPasswordLength?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_account_password_policy#password_reuse_prevention TfAccountPasswordPolicy#password_reuse_prevention}
    */
    readonly passwordReusePrevention?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_account_password_policy#require_lowercase_characters TfAccountPasswordPolicy#require_lowercase_characters}
    */
    readonly requireLowercaseCharacters?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_account_password_policy#require_numbers TfAccountPasswordPolicy#require_numbers}
    */
    readonly requireNumbers?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_account_password_policy#require_symbols TfAccountPasswordPolicy#require_symbols}
    */
    readonly requireSymbols?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_account_password_policy#require_uppercase_characters TfAccountPasswordPolicy#require_uppercase_characters}
    */
    readonly requireUppercaseCharacters?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_account_password_policy aws_iam_account_password_policy}
*/
export declare class TfAccountPasswordPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_iam_account_password_policy";
    /**
    * Generates CDKTN code for importing a TfAccountPasswordPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfAccountPasswordPolicy to import
    * @param importFromId The id of the existing TfAccountPasswordPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_account_password_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfAccountPasswordPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/iam_account_password_policy aws_iam_account_password_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfAccountPasswordPolicyConfig = {}
    */
    constructor(scope: Construct, id: string, config?: TfAccountPasswordPolicyConfig);
    private _allowUsersToChangePassword?;
    get allowUsersToChangePassword(): boolean | cdktn.IResolvable;
    set allowUsersToChangePassword(value: boolean | cdktn.IResolvable);
    resetAllowUsersToChangePassword(): void;
    get allowUsersToChangePasswordInput(): boolean | cdktn.IResolvable | undefined;
    get expirePasswords(): cdktn.IResolvable;
    private _hardExpiry?;
    get hardExpiry(): boolean | cdktn.IResolvable;
    set hardExpiry(value: boolean | cdktn.IResolvable);
    resetHardExpiry(): void;
    get hardExpiryInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _maxPasswordAge?;
    get maxPasswordAge(): number;
    set maxPasswordAge(value: number);
    resetMaxPasswordAge(): void;
    get maxPasswordAgeInput(): number | undefined;
    private _minimumPasswordLength?;
    get minimumPasswordLength(): number;
    set minimumPasswordLength(value: number);
    resetMinimumPasswordLength(): void;
    get minimumPasswordLengthInput(): number | undefined;
    private _passwordReusePrevention?;
    get passwordReusePrevention(): number;
    set passwordReusePrevention(value: number);
    resetPasswordReusePrevention(): void;
    get passwordReusePreventionInput(): number | undefined;
    private _requireLowercaseCharacters?;
    get requireLowercaseCharacters(): boolean | cdktn.IResolvable;
    set requireLowercaseCharacters(value: boolean | cdktn.IResolvable);
    resetRequireLowercaseCharacters(): void;
    get requireLowercaseCharactersInput(): boolean | cdktn.IResolvable | undefined;
    private _requireNumbers?;
    get requireNumbers(): boolean | cdktn.IResolvable;
    set requireNumbers(value: boolean | cdktn.IResolvable);
    resetRequireNumbers(): void;
    get requireNumbersInput(): boolean | cdktn.IResolvable | undefined;
    private _requireSymbols?;
    get requireSymbols(): boolean | cdktn.IResolvable;
    set requireSymbols(value: boolean | cdktn.IResolvable);
    resetRequireSymbols(): void;
    get requireSymbolsInput(): boolean | cdktn.IResolvable | undefined;
    private _requireUppercaseCharacters?;
    get requireUppercaseCharacters(): boolean | cdktn.IResolvable;
    set requireUppercaseCharacters(value: boolean | cdktn.IResolvable);
    resetRequireUppercaseCharacters(): void;
    get requireUppercaseCharactersInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
