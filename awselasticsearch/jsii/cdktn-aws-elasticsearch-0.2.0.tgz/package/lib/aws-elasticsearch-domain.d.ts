import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfDomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#access_policies TfDomain#access_policies}
    */
    readonly accessPolicies?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#advanced_options TfDomain#advanced_options}
    */
    readonly advancedOptions?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#domain_name TfDomain#domain_name}
    */
    readonly domainName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#elasticsearch_version TfDomain#elasticsearch_version}
    */
    readonly elasticsearchVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#id TfDomain#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#region TfDomain#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#tags TfDomain#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#tags_all TfDomain#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * advanced_security_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#advanced_security_options TfDomain#advanced_security_options}
    */
    readonly advancedSecurityOptions?: TfDomain.AdvancedSecurityOptionsProperty;
    /**
    * auto_tune_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#auto_tune_options TfDomain#auto_tune_options}
    */
    readonly autoTuneOptions?: TfDomain.AutoTuneOptionsProperty;
    /**
    * cluster_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#cluster_config TfDomain#cluster_config}
    */
    readonly clusterConfig?: TfDomain.ClusterConfigProperty;
    /**
    * cognito_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#cognito_options TfDomain#cognito_options}
    */
    readonly cognitoOptions?: TfDomain.CognitoOptionsProperty;
    /**
    * domain_endpoint_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#domain_endpoint_options TfDomain#domain_endpoint_options}
    */
    readonly domainEndpointOptions?: TfDomain.DomainEndpointOptionsProperty;
    /**
    * ebs_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#ebs_options TfDomain#ebs_options}
    */
    readonly ebsOptions?: TfDomain.EbsOptionsProperty;
    /**
    * encrypt_at_rest block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#encrypt_at_rest TfDomain#encrypt_at_rest}
    */
    readonly encryptAtRest?: TfDomain.EncryptAtRestProperty;
    /**
    * log_publishing_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#log_publishing_options TfDomain#log_publishing_options}
    */
    readonly logPublishingOptions?: TfDomain.LogPublishingOptionsProperty[] | cdktn.IResolvable;
    /**
    * node_to_node_encryption block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#node_to_node_encryption TfDomain#node_to_node_encryption}
    */
    readonly nodeToNodeEncryption?: TfDomain.NodeToNodeEncryptionProperty;
    /**
    * snapshot_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#snapshot_options TfDomain#snapshot_options}
    */
    readonly snapshotOptions?: TfDomain.SnapshotOptionsProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#timeouts TfDomain#timeouts}
    */
    readonly timeouts?: TfDomain.TimeoutsProperty;
    /**
    * vpc_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#vpc_options TfDomain#vpc_options}
    */
    readonly vpcOptions?: TfDomain.VpcOptionsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain aws_elasticsearch_domain}
*/
export declare class TfDomain extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_elasticsearch_domain";
    /**
    * Generates CDKTN code for importing a TfDomain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfDomain to import
    * @param importFromId The id of the existing TfDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain aws_elasticsearch_domain} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfDomainConfig
    */
    constructor(scope: Construct, id: string, config: TfDomainConfig);
    private _accessPolicies?;
    get accessPolicies(): string;
    set accessPolicies(value: string);
    resetAccessPolicies(): void;
    get accessPoliciesInput(): string | undefined;
    private _advancedOptions?;
    get advancedOptions(): {
        [key: string]: string;
    };
    set advancedOptions(value: {
        [key: string]: string;
    });
    resetAdvancedOptions(): void;
    get advancedOptionsInput(): {
        [key: string]: string;
    } | undefined;
    get arn(): string;
    get domainId(): string;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    private _elasticsearchVersion?;
    get elasticsearchVersion(): string;
    set elasticsearchVersion(value: string);
    resetElasticsearchVersion(): void;
    get elasticsearchVersionInput(): string | undefined;
    get endpoint(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get kibanaEndpoint(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _advancedSecurityOptions;
    get advancedSecurityOptions(): TfDomain.AdvancedSecurityOptionsPropertyOutputReference;
    putAdvancedSecurityOptions(value: TfDomain.AdvancedSecurityOptionsProperty): void;
    resetAdvancedSecurityOptions(): void;
    get advancedSecurityOptionsInput(): TfDomain.AdvancedSecurityOptionsProperty | undefined;
    private _autoTuneOptions;
    get autoTuneOptions(): TfDomain.AutoTuneOptionsPropertyOutputReference;
    putAutoTuneOptions(value: TfDomain.AutoTuneOptionsProperty): void;
    resetAutoTuneOptions(): void;
    get autoTuneOptionsInput(): TfDomain.AutoTuneOptionsProperty | undefined;
    private _clusterConfig;
    get clusterConfig(): TfDomain.ClusterConfigPropertyOutputReference;
    putClusterConfig(value: TfDomain.ClusterConfigProperty): void;
    resetClusterConfig(): void;
    get clusterConfigInput(): TfDomain.ClusterConfigProperty | undefined;
    private _cognitoOptions;
    get cognitoOptions(): TfDomain.CognitoOptionsPropertyOutputReference;
    putCognitoOptions(value: TfDomain.CognitoOptionsProperty): void;
    resetCognitoOptions(): void;
    get cognitoOptionsInput(): TfDomain.CognitoOptionsProperty | undefined;
    private _domainEndpointOptions;
    get domainEndpointOptions(): TfDomain.DomainEndpointOptionsPropertyOutputReference;
    putDomainEndpointOptions(value: TfDomain.DomainEndpointOptionsProperty): void;
    resetDomainEndpointOptions(): void;
    get domainEndpointOptionsInput(): TfDomain.DomainEndpointOptionsProperty | undefined;
    private _ebsOptions;
    get ebsOptions(): TfDomain.EbsOptionsPropertyOutputReference;
    putEbsOptions(value: TfDomain.EbsOptionsProperty): void;
    resetEbsOptions(): void;
    get ebsOptionsInput(): TfDomain.EbsOptionsProperty | undefined;
    private _encryptAtRest;
    get encryptAtRest(): TfDomain.EncryptAtRestPropertyOutputReference;
    putEncryptAtRest(value: TfDomain.EncryptAtRestProperty): void;
    resetEncryptAtRest(): void;
    get encryptAtRestInput(): TfDomain.EncryptAtRestProperty | undefined;
    private _logPublishingOptions;
    get logPublishingOptions(): TfDomain.LogPublishingOptionsPropertyList;
    putLogPublishingOptions(value: TfDomain.LogPublishingOptionsProperty[] | cdktn.IResolvable): void;
    resetLogPublishingOptions(): void;
    get logPublishingOptionsInput(): cdktn.IResolvable | TfDomain.LogPublishingOptionsProperty[] | undefined;
    private _nodeToNodeEncryption;
    get nodeToNodeEncryption(): TfDomain.NodeToNodeEncryptionPropertyOutputReference;
    putNodeToNodeEncryption(value: TfDomain.NodeToNodeEncryptionProperty): void;
    resetNodeToNodeEncryption(): void;
    get nodeToNodeEncryptionInput(): TfDomain.NodeToNodeEncryptionProperty | undefined;
    private _snapshotOptions;
    get snapshotOptions(): TfDomain.SnapshotOptionsPropertyOutputReference;
    putSnapshotOptions(value: TfDomain.SnapshotOptionsProperty): void;
    resetSnapshotOptions(): void;
    get snapshotOptionsInput(): TfDomain.SnapshotOptionsProperty | undefined;
    private _timeouts;
    get timeouts(): TfDomain.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfDomain.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfDomain.TimeoutsProperty | undefined;
    private _vpcOptions;
    get vpcOptions(): TfDomain.VpcOptionsPropertyOutputReference;
    putVpcOptions(value: TfDomain.VpcOptionsProperty): void;
    resetVpcOptions(): void;
    get vpcOptionsInput(): TfDomain.VpcOptionsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfDomainMasterUserOptionsPropertyToTerraform(struct?: TfDomain.MasterUserOptionsPropertyOutputReference | TfDomain.MasterUserOptionsProperty): any;
export declare function tfDomainMasterUserOptionsPropertyToHclTerraform(struct?: TfDomain.MasterUserOptionsPropertyOutputReference | TfDomain.MasterUserOptionsProperty): any;
export declare function tfDomainAdvancedSecurityOptionsPropertyToTerraform(struct?: TfDomain.AdvancedSecurityOptionsPropertyOutputReference | TfDomain.AdvancedSecurityOptionsProperty): any;
export declare function tfDomainAdvancedSecurityOptionsPropertyToHclTerraform(struct?: TfDomain.AdvancedSecurityOptionsPropertyOutputReference | TfDomain.AdvancedSecurityOptionsProperty): any;
export declare function tfDomainDurationPropertyToTerraform(struct?: TfDomain.DurationPropertyOutputReference | TfDomain.DurationProperty): any;
export declare function tfDomainDurationPropertyToHclTerraform(struct?: TfDomain.DurationPropertyOutputReference | TfDomain.DurationProperty): any;
export declare function tfDomainMaintenanceSchedulePropertyToTerraform(struct?: TfDomain.MaintenanceScheduleProperty | cdktn.IResolvable): any;
export declare function tfDomainMaintenanceSchedulePropertyToHclTerraform(struct?: TfDomain.MaintenanceScheduleProperty | cdktn.IResolvable): any;
export declare function tfDomainAutoTuneOptionsPropertyToTerraform(struct?: TfDomain.AutoTuneOptionsPropertyOutputReference | TfDomain.AutoTuneOptionsProperty): any;
export declare function tfDomainAutoTuneOptionsPropertyToHclTerraform(struct?: TfDomain.AutoTuneOptionsPropertyOutputReference | TfDomain.AutoTuneOptionsProperty): any;
export declare function tfDomainColdStorageOptionsPropertyToTerraform(struct?: TfDomain.ColdStorageOptionsPropertyOutputReference | TfDomain.ColdStorageOptionsProperty): any;
export declare function tfDomainColdStorageOptionsPropertyToHclTerraform(struct?: TfDomain.ColdStorageOptionsPropertyOutputReference | TfDomain.ColdStorageOptionsProperty): any;
export declare function tfDomainZoneAwarenessConfigPropertyToTerraform(struct?: TfDomain.ZoneAwarenessConfigPropertyOutputReference | TfDomain.ZoneAwarenessConfigProperty): any;
export declare function tfDomainZoneAwarenessConfigPropertyToHclTerraform(struct?: TfDomain.ZoneAwarenessConfigPropertyOutputReference | TfDomain.ZoneAwarenessConfigProperty): any;
export declare function tfDomainClusterConfigPropertyToTerraform(struct?: TfDomain.ClusterConfigPropertyOutputReference | TfDomain.ClusterConfigProperty): any;
export declare function tfDomainClusterConfigPropertyToHclTerraform(struct?: TfDomain.ClusterConfigPropertyOutputReference | TfDomain.ClusterConfigProperty): any;
export declare function tfDomainCognitoOptionsPropertyToTerraform(struct?: TfDomain.CognitoOptionsPropertyOutputReference | TfDomain.CognitoOptionsProperty): any;
export declare function tfDomainCognitoOptionsPropertyToHclTerraform(struct?: TfDomain.CognitoOptionsPropertyOutputReference | TfDomain.CognitoOptionsProperty): any;
export declare function tfDomainDomainEndpointOptionsPropertyToTerraform(struct?: TfDomain.DomainEndpointOptionsPropertyOutputReference | TfDomain.DomainEndpointOptionsProperty): any;
export declare function tfDomainDomainEndpointOptionsPropertyToHclTerraform(struct?: TfDomain.DomainEndpointOptionsPropertyOutputReference | TfDomain.DomainEndpointOptionsProperty): any;
export declare function tfDomainEbsOptionsPropertyToTerraform(struct?: TfDomain.EbsOptionsPropertyOutputReference | TfDomain.EbsOptionsProperty): any;
export declare function tfDomainEbsOptionsPropertyToHclTerraform(struct?: TfDomain.EbsOptionsPropertyOutputReference | TfDomain.EbsOptionsProperty): any;
export declare function tfDomainEncryptAtRestPropertyToTerraform(struct?: TfDomain.EncryptAtRestPropertyOutputReference | TfDomain.EncryptAtRestProperty): any;
export declare function tfDomainEncryptAtRestPropertyToHclTerraform(struct?: TfDomain.EncryptAtRestPropertyOutputReference | TfDomain.EncryptAtRestProperty): any;
export declare function tfDomainLogPublishingOptionsPropertyToTerraform(struct?: TfDomain.LogPublishingOptionsProperty | cdktn.IResolvable): any;
export declare function tfDomainLogPublishingOptionsPropertyToHclTerraform(struct?: TfDomain.LogPublishingOptionsProperty | cdktn.IResolvable): any;
export declare function tfDomainNodeToNodeEncryptionPropertyToTerraform(struct?: TfDomain.NodeToNodeEncryptionPropertyOutputReference | TfDomain.NodeToNodeEncryptionProperty): any;
export declare function tfDomainNodeToNodeEncryptionPropertyToHclTerraform(struct?: TfDomain.NodeToNodeEncryptionPropertyOutputReference | TfDomain.NodeToNodeEncryptionProperty): any;
export declare function tfDomainSnapshotOptionsPropertyToTerraform(struct?: TfDomain.SnapshotOptionsPropertyOutputReference | TfDomain.SnapshotOptionsProperty): any;
export declare function tfDomainSnapshotOptionsPropertyToHclTerraform(struct?: TfDomain.SnapshotOptionsPropertyOutputReference | TfDomain.SnapshotOptionsProperty): any;
export declare function tfDomainTimeoutsPropertyToTerraform(struct?: TfDomain.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfDomainTimeoutsPropertyToHclTerraform(struct?: TfDomain.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfDomainVpcOptionsPropertyToTerraform(struct?: TfDomain.VpcOptionsPropertyOutputReference | TfDomain.VpcOptionsProperty): any;
export declare function tfDomainVpcOptionsPropertyToHclTerraform(struct?: TfDomain.VpcOptionsPropertyOutputReference | TfDomain.VpcOptionsProperty): any;
export declare namespace TfDomain {
    interface MasterUserOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#master_user_arn TfDomain#master_user_arn}
        */
        readonly masterUserArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#master_user_name TfDomain#master_user_name}
        */
        readonly masterUserName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#master_user_password TfDomain#master_user_password}
        */
        readonly masterUserPassword?: string;
    }
    class MasterUserOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MasterUserOptionsProperty | undefined;
        set internalValue(value: MasterUserOptionsProperty | undefined);
        private _masterUserArn?;
        get masterUserArn(): string;
        set masterUserArn(value: string);
        resetMasterUserArn(): void;
        get masterUserArnInput(): string | undefined;
        private _masterUserName?;
        get masterUserName(): string;
        set masterUserName(value: string);
        resetMasterUserName(): void;
        get masterUserNameInput(): string | undefined;
        private _masterUserPassword?;
        get masterUserPassword(): string;
        set masterUserPassword(value: string);
        resetMasterUserPassword(): void;
        get masterUserPasswordInput(): string | undefined;
    }
    interface AdvancedSecurityOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#enabled TfDomain#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#internal_user_database_enabled TfDomain#internal_user_database_enabled}
        */
        readonly internalUserDatabaseEnabled?: boolean | cdktn.IResolvable;
        /**
        * master_user_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#master_user_options TfDomain#master_user_options}
        */
        readonly masterUserOptions?: MasterUserOptionsProperty;
    }
    class AdvancedSecurityOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AdvancedSecurityOptionsProperty | undefined;
        set internalValue(value: AdvancedSecurityOptionsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _internalUserDatabaseEnabled?;
        get internalUserDatabaseEnabled(): boolean | cdktn.IResolvable;
        set internalUserDatabaseEnabled(value: boolean | cdktn.IResolvable);
        resetInternalUserDatabaseEnabled(): void;
        get internalUserDatabaseEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _masterUserOptions;
        get masterUserOptions(): MasterUserOptionsPropertyOutputReference;
        putMasterUserOptions(value: MasterUserOptionsProperty): void;
        resetMasterUserOptions(): void;
        get masterUserOptionsInput(): MasterUserOptionsProperty | undefined;
    }
    interface DurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#unit TfDomain#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#value TfDomain#value}
        */
        readonly value: number;
    }
    class DurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DurationProperty | undefined;
        set internalValue(value: DurationProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface MaintenanceScheduleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#cron_expression_for_recurrence TfDomain#cron_expression_for_recurrence}
        */
        readonly cronExpressionForRecurrence: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#start_at TfDomain#start_at}
        */
        readonly startAt: string;
        /**
        * duration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#duration TfDomain#duration}
        */
        readonly duration: DurationProperty;
    }
    class MaintenanceSchedulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MaintenanceScheduleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MaintenanceScheduleProperty | cdktn.IResolvable | undefined);
        private _cronExpressionForRecurrence?;
        get cronExpressionForRecurrence(): string;
        set cronExpressionForRecurrence(value: string);
        get cronExpressionForRecurrenceInput(): string | undefined;
        private _startAt?;
        get startAt(): string;
        set startAt(value: string);
        get startAtInput(): string | undefined;
        private _duration;
        get duration(): DurationPropertyOutputReference;
        putDuration(value: DurationProperty): void;
        get durationInput(): DurationProperty | undefined;
    }
    class MaintenanceSchedulePropertyList extends cdktn.ComplexList {
        internalValue?: MaintenanceScheduleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MaintenanceSchedulePropertyOutputReference;
    }
    interface AutoTuneOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#desired_state TfDomain#desired_state}
        */
        readonly desiredState: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#rollback_on_disable TfDomain#rollback_on_disable}
        */
        readonly rollbackOnDisable?: string;
        /**
        * maintenance_schedule block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#maintenance_schedule TfDomain#maintenance_schedule}
        */
        readonly maintenanceSchedule?: MaintenanceScheduleProperty[] | cdktn.IResolvable;
    }
    class AutoTuneOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AutoTuneOptionsProperty | undefined;
        set internalValue(value: AutoTuneOptionsProperty | undefined);
        private _desiredState?;
        get desiredState(): string;
        set desiredState(value: string);
        get desiredStateInput(): string | undefined;
        private _rollbackOnDisable?;
        get rollbackOnDisable(): string;
        set rollbackOnDisable(value: string);
        resetRollbackOnDisable(): void;
        get rollbackOnDisableInput(): string | undefined;
        private _maintenanceSchedule;
        get maintenanceSchedule(): MaintenanceSchedulePropertyList;
        putMaintenanceSchedule(value: MaintenanceScheduleProperty[] | cdktn.IResolvable): void;
        resetMaintenanceSchedule(): void;
        get maintenanceScheduleInput(): cdktn.IResolvable | MaintenanceScheduleProperty[] | undefined;
    }
    interface ColdStorageOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#enabled TfDomain#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class ColdStorageOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ColdStorageOptionsProperty | undefined;
        set internalValue(value: ColdStorageOptionsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface ZoneAwarenessConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#availability_zone_count TfDomain#availability_zone_count}
        */
        readonly availabilityZoneCount?: number;
    }
    class ZoneAwarenessConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ZoneAwarenessConfigProperty | undefined;
        set internalValue(value: ZoneAwarenessConfigProperty | undefined);
        private _availabilityZoneCount?;
        get availabilityZoneCount(): number;
        set availabilityZoneCount(value: number);
        resetAvailabilityZoneCount(): void;
        get availabilityZoneCountInput(): number | undefined;
    }
    interface ClusterConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#dedicated_master_count TfDomain#dedicated_master_count}
        */
        readonly dedicatedMasterCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#dedicated_master_enabled TfDomain#dedicated_master_enabled}
        */
        readonly dedicatedMasterEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#dedicated_master_type TfDomain#dedicated_master_type}
        */
        readonly dedicatedMasterType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#instance_count TfDomain#instance_count}
        */
        readonly instanceCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#instance_type TfDomain#instance_type}
        */
        readonly instanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#warm_count TfDomain#warm_count}
        */
        readonly warmCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#warm_enabled TfDomain#warm_enabled}
        */
        readonly warmEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#warm_type TfDomain#warm_type}
        */
        readonly warmType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#zone_awareness_enabled TfDomain#zone_awareness_enabled}
        */
        readonly zoneAwarenessEnabled?: boolean | cdktn.IResolvable;
        /**
        * cold_storage_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#cold_storage_options TfDomain#cold_storage_options}
        */
        readonly coldStorageOptions?: ColdStorageOptionsProperty;
        /**
        * zone_awareness_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#zone_awareness_config TfDomain#zone_awareness_config}
        */
        readonly zoneAwarenessConfig?: ZoneAwarenessConfigProperty;
    }
    class ClusterConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ClusterConfigProperty | undefined;
        set internalValue(value: ClusterConfigProperty | undefined);
        private _dedicatedMasterCount?;
        get dedicatedMasterCount(): number;
        set dedicatedMasterCount(value: number);
        resetDedicatedMasterCount(): void;
        get dedicatedMasterCountInput(): number | undefined;
        private _dedicatedMasterEnabled?;
        get dedicatedMasterEnabled(): boolean | cdktn.IResolvable;
        set dedicatedMasterEnabled(value: boolean | cdktn.IResolvable);
        resetDedicatedMasterEnabled(): void;
        get dedicatedMasterEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _dedicatedMasterType?;
        get dedicatedMasterType(): string;
        set dedicatedMasterType(value: string);
        resetDedicatedMasterType(): void;
        get dedicatedMasterTypeInput(): string | undefined;
        private _instanceCount?;
        get instanceCount(): number;
        set instanceCount(value: number);
        resetInstanceCount(): void;
        get instanceCountInput(): number | undefined;
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _warmCount?;
        get warmCount(): number;
        set warmCount(value: number);
        resetWarmCount(): void;
        get warmCountInput(): number | undefined;
        private _warmEnabled?;
        get warmEnabled(): boolean | cdktn.IResolvable;
        set warmEnabled(value: boolean | cdktn.IResolvable);
        resetWarmEnabled(): void;
        get warmEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _warmType?;
        get warmType(): string;
        set warmType(value: string);
        resetWarmType(): void;
        get warmTypeInput(): string | undefined;
        private _zoneAwarenessEnabled?;
        get zoneAwarenessEnabled(): boolean | cdktn.IResolvable;
        set zoneAwarenessEnabled(value: boolean | cdktn.IResolvable);
        resetZoneAwarenessEnabled(): void;
        get zoneAwarenessEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _coldStorageOptions;
        get coldStorageOptions(): ColdStorageOptionsPropertyOutputReference;
        putColdStorageOptions(value: ColdStorageOptionsProperty): void;
        resetColdStorageOptions(): void;
        get coldStorageOptionsInput(): ColdStorageOptionsProperty | undefined;
        private _zoneAwarenessConfig;
        get zoneAwarenessConfig(): ZoneAwarenessConfigPropertyOutputReference;
        putZoneAwarenessConfig(value: ZoneAwarenessConfigProperty): void;
        resetZoneAwarenessConfig(): void;
        get zoneAwarenessConfigInput(): ZoneAwarenessConfigProperty | undefined;
    }
    interface CognitoOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#enabled TfDomain#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#identity_pool_id TfDomain#identity_pool_id}
        */
        readonly identityPoolId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#role_arn TfDomain#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#user_pool_id TfDomain#user_pool_id}
        */
        readonly userPoolId: string;
    }
    class CognitoOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CognitoOptionsProperty | undefined;
        set internalValue(value: CognitoOptionsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _identityPoolId?;
        get identityPoolId(): string;
        set identityPoolId(value: string);
        get identityPoolIdInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _userPoolId?;
        get userPoolId(): string;
        set userPoolId(value: string);
        get userPoolIdInput(): string | undefined;
    }
    interface DomainEndpointOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#custom_endpoint TfDomain#custom_endpoint}
        */
        readonly customEndpoint?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#custom_endpoint_certificate_arn TfDomain#custom_endpoint_certificate_arn}
        */
        readonly customEndpointCertificateArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#custom_endpoint_enabled TfDomain#custom_endpoint_enabled}
        */
        readonly customEndpointEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#enforce_https TfDomain#enforce_https}
        */
        readonly enforceHttps?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#tls_security_policy TfDomain#tls_security_policy}
        */
        readonly tlsSecurityPolicy?: string;
    }
    class DomainEndpointOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DomainEndpointOptionsProperty | undefined;
        set internalValue(value: DomainEndpointOptionsProperty | undefined);
        private _customEndpoint?;
        get customEndpoint(): string;
        set customEndpoint(value: string);
        resetCustomEndpoint(): void;
        get customEndpointInput(): string | undefined;
        private _customEndpointCertificateArn?;
        get customEndpointCertificateArn(): string;
        set customEndpointCertificateArn(value: string);
        resetCustomEndpointCertificateArn(): void;
        get customEndpointCertificateArnInput(): string | undefined;
        private _customEndpointEnabled?;
        get customEndpointEnabled(): boolean | cdktn.IResolvable;
        set customEndpointEnabled(value: boolean | cdktn.IResolvable);
        resetCustomEndpointEnabled(): void;
        get customEndpointEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _enforceHttps?;
        get enforceHttps(): boolean | cdktn.IResolvable;
        set enforceHttps(value: boolean | cdktn.IResolvable);
        resetEnforceHttps(): void;
        get enforceHttpsInput(): boolean | cdktn.IResolvable | undefined;
        private _tlsSecurityPolicy?;
        get tlsSecurityPolicy(): string;
        set tlsSecurityPolicy(value: string);
        resetTlsSecurityPolicy(): void;
        get tlsSecurityPolicyInput(): string | undefined;
    }
    interface EbsOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#ebs_enabled TfDomain#ebs_enabled}
        */
        readonly ebsEnabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#iops TfDomain#iops}
        */
        readonly iops?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#throughput TfDomain#throughput}
        */
        readonly throughput?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#volume_size TfDomain#volume_size}
        */
        readonly volumeSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#volume_type TfDomain#volume_type}
        */
        readonly volumeType?: string;
    }
    class EbsOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EbsOptionsProperty | undefined;
        set internalValue(value: EbsOptionsProperty | undefined);
        private _ebsEnabled?;
        get ebsEnabled(): boolean | cdktn.IResolvable;
        set ebsEnabled(value: boolean | cdktn.IResolvable);
        get ebsEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _iops?;
        get iops(): number;
        set iops(value: number);
        resetIops(): void;
        get iopsInput(): number | undefined;
        private _throughput?;
        get throughput(): number;
        set throughput(value: number);
        resetThroughput(): void;
        get throughputInput(): number | undefined;
        private _volumeSize?;
        get volumeSize(): number;
        set volumeSize(value: number);
        resetVolumeSize(): void;
        get volumeSizeInput(): number | undefined;
        private _volumeType?;
        get volumeType(): string;
        set volumeType(value: string);
        resetVolumeType(): void;
        get volumeTypeInput(): string | undefined;
    }
    interface EncryptAtRestProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#enabled TfDomain#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#kms_key_id TfDomain#kms_key_id}
        */
        readonly kmsKeyId?: string;
    }
    class EncryptAtRestPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncryptAtRestProperty | undefined;
        set internalValue(value: EncryptAtRestProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
    }
    interface LogPublishingOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#cloudwatch_log_group_arn TfDomain#cloudwatch_log_group_arn}
        */
        readonly cloudwatchLogGroupArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#enabled TfDomain#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#log_type TfDomain#log_type}
        */
        readonly logType: string;
    }
    class LogPublishingOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LogPublishingOptionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LogPublishingOptionsProperty | cdktn.IResolvable | undefined);
        private _cloudwatchLogGroupArn?;
        get cloudwatchLogGroupArn(): string;
        set cloudwatchLogGroupArn(value: string);
        get cloudwatchLogGroupArnInput(): string | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _logType?;
        get logType(): string;
        set logType(value: string);
        get logTypeInput(): string | undefined;
    }
    class LogPublishingOptionsPropertyList extends cdktn.ComplexList {
        internalValue?: LogPublishingOptionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LogPublishingOptionsPropertyOutputReference;
    }
    interface NodeToNodeEncryptionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#enabled TfDomain#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
    }
    class NodeToNodeEncryptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NodeToNodeEncryptionProperty | undefined;
        set internalValue(value: NodeToNodeEncryptionProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface SnapshotOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#automated_snapshot_start_hour TfDomain#automated_snapshot_start_hour}
        */
        readonly automatedSnapshotStartHour: number;
    }
    class SnapshotOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SnapshotOptionsProperty | undefined;
        set internalValue(value: SnapshotOptionsProperty | undefined);
        private _automatedSnapshotStartHour?;
        get automatedSnapshotStartHour(): number;
        set automatedSnapshotStartHour(value: number);
        get automatedSnapshotStartHourInput(): number | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#create TfDomain#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#delete TfDomain#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#update TfDomain#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface VpcOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#security_group_ids TfDomain#security_group_ids}
        */
        readonly securityGroupIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#subnet_ids TfDomain#subnet_ids}
        */
        readonly subnetIds?: string[];
    }
    class VpcOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcOptionsProperty | undefined;
        set internalValue(value: VpcOptionsProperty | undefined);
        get availabilityZones(): string[];
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        resetSecurityGroupIds(): void;
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        resetSubnetIds(): void;
        get subnetIdsInput(): string[] | undefined;
        get vpcId(): string;
    }
}
