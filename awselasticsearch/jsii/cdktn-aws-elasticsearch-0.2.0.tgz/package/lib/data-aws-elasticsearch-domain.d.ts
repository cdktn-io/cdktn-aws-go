import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfDomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticsearch_domain#domain_name DataTfDomain#domain_name}
    */
    readonly domainName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticsearch_domain#id DataTfDomain#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticsearch_domain#region DataTfDomain#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticsearch_domain#tags DataTfDomain#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticsearch_domain aws_elasticsearch_domain}
*/
export declare class DataTfDomain extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_elasticsearch_domain";
    /**
    * Generates CDKTN code for importing a DataTfDomain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfDomain to import
    * @param importFromId The id of the existing DataTfDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticsearch_domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticsearch_domain aws_elasticsearch_domain} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfDomainConfig
    */
    constructor(scope: Construct, id: string, config: DataTfDomainConfig);
    get accessPolicies(): string;
    private _advancedOptions;
    get advancedOptions(): cdktn.StringMap;
    private _advancedSecurityOptions;
    get advancedSecurityOptions(): DataTfDomain.AdvancedSecurityOptionsPropertyList;
    get arn(): string;
    private _autoTuneOptions;
    get autoTuneOptions(): DataTfDomain.AutoTuneOptionsPropertyList;
    private _clusterConfig;
    get clusterConfig(): DataTfDomain.ClusterConfigPropertyList;
    private _cognitoOptions;
    get cognitoOptions(): DataTfDomain.CognitoOptionsPropertyList;
    get created(): cdktn.IResolvable;
    get deleted(): cdktn.IResolvable;
    get domainId(): string;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    private _ebsOptions;
    get ebsOptions(): DataTfDomain.EbsOptionsPropertyList;
    get elasticsearchVersion(): string;
    private _encryptionAtRest;
    get encryptionAtRest(): DataTfDomain.EncryptionAtRestPropertyList;
    get endpoint(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get kibanaEndpoint(): string;
    private _logPublishingOptions;
    get logPublishingOptions(): DataTfDomain.LogPublishingOptionsPropertyList;
    private _nodeToNodeEncryption;
    get nodeToNodeEncryption(): DataTfDomain.NodeToNodeEncryptionPropertyList;
    get processing(): cdktn.IResolvable;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _snapshotOptions;
    get snapshotOptions(): DataTfDomain.SnapshotOptionsPropertyList;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _vpcOptions;
    get vpcOptions(): DataTfDomain.VpcOptionsPropertyList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfDomainAdvancedSecurityOptionsPropertyToTerraform(struct?: DataTfDomain.AdvancedSecurityOptionsProperty): any;
export declare function dataTfDomainAdvancedSecurityOptionsPropertyToHclTerraform(struct?: DataTfDomain.AdvancedSecurityOptionsProperty): any;
export declare function dataTfDomainDurationPropertyToTerraform(struct?: DataTfDomain.DurationProperty): any;
export declare function dataTfDomainDurationPropertyToHclTerraform(struct?: DataTfDomain.DurationProperty): any;
export declare function dataTfDomainMaintenanceSchedulePropertyToTerraform(struct?: DataTfDomain.MaintenanceScheduleProperty): any;
export declare function dataTfDomainMaintenanceSchedulePropertyToHclTerraform(struct?: DataTfDomain.MaintenanceScheduleProperty): any;
export declare function dataTfDomainAutoTuneOptionsPropertyToTerraform(struct?: DataTfDomain.AutoTuneOptionsProperty): any;
export declare function dataTfDomainAutoTuneOptionsPropertyToHclTerraform(struct?: DataTfDomain.AutoTuneOptionsProperty): any;
export declare function dataTfDomainColdStorageOptionsPropertyToTerraform(struct?: DataTfDomain.ColdStorageOptionsProperty): any;
export declare function dataTfDomainColdStorageOptionsPropertyToHclTerraform(struct?: DataTfDomain.ColdStorageOptionsProperty): any;
export declare function dataTfDomainZoneAwarenessConfigPropertyToTerraform(struct?: DataTfDomain.ZoneAwarenessConfigProperty): any;
export declare function dataTfDomainZoneAwarenessConfigPropertyToHclTerraform(struct?: DataTfDomain.ZoneAwarenessConfigProperty): any;
export declare function dataTfDomainClusterConfigPropertyToTerraform(struct?: DataTfDomain.ClusterConfigProperty): any;
export declare function dataTfDomainClusterConfigPropertyToHclTerraform(struct?: DataTfDomain.ClusterConfigProperty): any;
export declare function dataTfDomainCognitoOptionsPropertyToTerraform(struct?: DataTfDomain.CognitoOptionsProperty): any;
export declare function dataTfDomainCognitoOptionsPropertyToHclTerraform(struct?: DataTfDomain.CognitoOptionsProperty): any;
export declare function dataTfDomainEbsOptionsPropertyToTerraform(struct?: DataTfDomain.EbsOptionsProperty): any;
export declare function dataTfDomainEbsOptionsPropertyToHclTerraform(struct?: DataTfDomain.EbsOptionsProperty): any;
export declare function dataTfDomainEncryptionAtRestPropertyToTerraform(struct?: DataTfDomain.EncryptionAtRestProperty): any;
export declare function dataTfDomainEncryptionAtRestPropertyToHclTerraform(struct?: DataTfDomain.EncryptionAtRestProperty): any;
export declare function dataTfDomainLogPublishingOptionsPropertyToTerraform(struct?: DataTfDomain.LogPublishingOptionsProperty): any;
export declare function dataTfDomainLogPublishingOptionsPropertyToHclTerraform(struct?: DataTfDomain.LogPublishingOptionsProperty): any;
export declare function dataTfDomainNodeToNodeEncryptionPropertyToTerraform(struct?: DataTfDomain.NodeToNodeEncryptionProperty): any;
export declare function dataTfDomainNodeToNodeEncryptionPropertyToHclTerraform(struct?: DataTfDomain.NodeToNodeEncryptionProperty): any;
export declare function dataTfDomainSnapshotOptionsPropertyToTerraform(struct?: DataTfDomain.SnapshotOptionsProperty): any;
export declare function dataTfDomainSnapshotOptionsPropertyToHclTerraform(struct?: DataTfDomain.SnapshotOptionsProperty): any;
export declare function dataTfDomainVpcOptionsPropertyToTerraform(struct?: DataTfDomain.VpcOptionsProperty): any;
export declare function dataTfDomainVpcOptionsPropertyToHclTerraform(struct?: DataTfDomain.VpcOptionsProperty): any;
export declare namespace DataTfDomain {
    interface AdvancedSecurityOptionsProperty {
    }
    class AdvancedSecurityOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AdvancedSecurityOptionsProperty | undefined;
        set internalValue(value: AdvancedSecurityOptionsProperty | undefined);
        get enabled(): cdktn.IResolvable;
        get internalUserDatabaseEnabled(): cdktn.IResolvable;
    }
    class AdvancedSecurityOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AdvancedSecurityOptionsPropertyOutputReference;
    }
    interface DurationProperty {
    }
    class DurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DurationProperty | undefined;
        set internalValue(value: DurationProperty | undefined);
        get unit(): string;
        get value(): number;
    }
    class DurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DurationPropertyOutputReference;
    }
    interface MaintenanceScheduleProperty {
    }
    class MaintenanceSchedulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MaintenanceScheduleProperty | undefined;
        set internalValue(value: MaintenanceScheduleProperty | undefined);
        get cronExpressionForRecurrence(): string;
        private _duration;
        get duration(): DurationPropertyList;
        get startAt(): string;
    }
    class MaintenanceSchedulePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MaintenanceSchedulePropertyOutputReference;
    }
    interface AutoTuneOptionsProperty {
    }
    class AutoTuneOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AutoTuneOptionsProperty | undefined;
        set internalValue(value: AutoTuneOptionsProperty | undefined);
        get desiredState(): string;
        private _maintenanceSchedule;
        get maintenanceSchedule(): MaintenanceSchedulePropertyList;
        get rollbackOnDisable(): string;
    }
    class AutoTuneOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AutoTuneOptionsPropertyOutputReference;
    }
    interface ColdStorageOptionsProperty {
    }
    class ColdStorageOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ColdStorageOptionsProperty | undefined;
        set internalValue(value: ColdStorageOptionsProperty | undefined);
        get enabled(): cdktn.IResolvable;
    }
    class ColdStorageOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ColdStorageOptionsPropertyOutputReference;
    }
    interface ZoneAwarenessConfigProperty {
    }
    class ZoneAwarenessConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ZoneAwarenessConfigProperty | undefined;
        set internalValue(value: ZoneAwarenessConfigProperty | undefined);
        get availabilityZoneCount(): number;
    }
    class ZoneAwarenessConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ZoneAwarenessConfigPropertyOutputReference;
    }
    interface ClusterConfigProperty {
    }
    class ClusterConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ClusterConfigProperty | undefined;
        set internalValue(value: ClusterConfigProperty | undefined);
        private _coldStorageOptions;
        get coldStorageOptions(): ColdStorageOptionsPropertyList;
        get dedicatedMasterCount(): number;
        get dedicatedMasterEnabled(): cdktn.IResolvable;
        get dedicatedMasterType(): string;
        get instanceCount(): number;
        get instanceType(): string;
        get warmCount(): number;
        get warmEnabled(): cdktn.IResolvable;
        get warmType(): string;
        private _zoneAwarenessConfig;
        get zoneAwarenessConfig(): ZoneAwarenessConfigPropertyList;
        get zoneAwarenessEnabled(): cdktn.IResolvable;
    }
    class ClusterConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ClusterConfigPropertyOutputReference;
    }
    interface CognitoOptionsProperty {
    }
    class CognitoOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CognitoOptionsProperty | undefined;
        set internalValue(value: CognitoOptionsProperty | undefined);
        get enabled(): cdktn.IResolvable;
        get identityPoolId(): string;
        get roleArn(): string;
        get userPoolId(): string;
    }
    class CognitoOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CognitoOptionsPropertyOutputReference;
    }
    interface EbsOptionsProperty {
    }
    class EbsOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EbsOptionsProperty | undefined;
        set internalValue(value: EbsOptionsProperty | undefined);
        get ebsEnabled(): cdktn.IResolvable;
        get iops(): number;
        get throughput(): number;
        get volumeSize(): number;
        get volumeType(): string;
    }
    class EbsOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EbsOptionsPropertyOutputReference;
    }
    interface EncryptionAtRestProperty {
    }
    class EncryptionAtRestPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EncryptionAtRestProperty | undefined;
        set internalValue(value: EncryptionAtRestProperty | undefined);
        get enabled(): cdktn.IResolvable;
        get kmsKeyId(): string;
    }
    class EncryptionAtRestPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EncryptionAtRestPropertyOutputReference;
    }
    interface LogPublishingOptionsProperty {
    }
    class LogPublishingOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LogPublishingOptionsProperty | undefined;
        set internalValue(value: LogPublishingOptionsProperty | undefined);
        get cloudwatchLogGroupArn(): string;
        get enabled(): cdktn.IResolvable;
        get logType(): string;
    }
    class LogPublishingOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LogPublishingOptionsPropertyOutputReference;
    }
    interface NodeToNodeEncryptionProperty {
    }
    class NodeToNodeEncryptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NodeToNodeEncryptionProperty | undefined;
        set internalValue(value: NodeToNodeEncryptionProperty | undefined);
        get enabled(): cdktn.IResolvable;
    }
    class NodeToNodeEncryptionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NodeToNodeEncryptionPropertyOutputReference;
    }
    interface SnapshotOptionsProperty {
    }
    class SnapshotOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SnapshotOptionsProperty | undefined;
        set internalValue(value: SnapshotOptionsProperty | undefined);
        get automatedSnapshotStartHour(): number;
    }
    class SnapshotOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SnapshotOptionsPropertyOutputReference;
    }
    interface VpcOptionsProperty {
    }
    class VpcOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpcOptionsProperty | undefined;
        set internalValue(value: VpcOptionsProperty | undefined);
        get availabilityZones(): string[];
        get securityGroupIds(): string[];
        get subnetIds(): string[];
        get vpcId(): string;
    }
    class VpcOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpcOptionsPropertyOutputReference;
    }
}
