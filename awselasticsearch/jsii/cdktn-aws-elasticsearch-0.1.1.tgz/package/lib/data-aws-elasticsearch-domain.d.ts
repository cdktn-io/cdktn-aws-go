import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsElasticsearchDomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticsearch_domain#domain_name DataAwsElasticsearchDomain#domain_name}
    */
    readonly domainName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticsearch_domain#id DataAwsElasticsearchDomain#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticsearch_domain#region DataAwsElasticsearchDomain#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticsearch_domain#tags DataAwsElasticsearchDomain#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticsearch_domain aws_elasticsearch_domain}
*/
export declare class DataAwsElasticsearchDomain extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_elasticsearch_domain";
    /**
    * Generates CDKTN code for importing a DataAwsElasticsearchDomain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsElasticsearchDomain to import
    * @param importFromId The id of the existing DataAwsElasticsearchDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticsearch_domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsElasticsearchDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/elasticsearch_domain aws_elasticsearch_domain} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsElasticsearchDomainConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsElasticsearchDomainConfig);
    get accessPolicies(): string;
    private _advancedOptions;
    get advancedOptions(): cdktn.StringMap;
    private _advancedSecurityOptions;
    get advancedSecurityOptions(): DataAwsElasticsearchDomain.AdvancedSecurityOptionsPropertyList;
    get arn(): string;
    private _autoTuneOptions;
    get autoTuneOptions(): DataAwsElasticsearchDomain.AutoTuneOptionsPropertyList;
    private _clusterConfig;
    get clusterConfig(): DataAwsElasticsearchDomain.ClusterConfigPropertyList;
    private _cognitoOptions;
    get cognitoOptions(): DataAwsElasticsearchDomain.CognitoOptionsPropertyList;
    get created(): cdktn.IResolvable;
    get deleted(): cdktn.IResolvable;
    get domainId(): string;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    private _ebsOptions;
    get ebsOptions(): DataAwsElasticsearchDomain.EbsOptionsPropertyList;
    get elasticsearchVersion(): string;
    private _encryptionAtRest;
    get encryptionAtRest(): DataAwsElasticsearchDomain.EncryptionAtRestPropertyList;
    get endpoint(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get kibanaEndpoint(): string;
    private _logPublishingOptions;
    get logPublishingOptions(): DataAwsElasticsearchDomain.LogPublishingOptionsPropertyList;
    private _nodeToNodeEncryption;
    get nodeToNodeEncryption(): DataAwsElasticsearchDomain.NodeToNodeEncryptionPropertyList;
    get processing(): cdktn.IResolvable;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _snapshotOptions;
    get snapshotOptions(): DataAwsElasticsearchDomain.SnapshotOptionsPropertyList;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _vpcOptions;
    get vpcOptions(): DataAwsElasticsearchDomain.VpcOptionsPropertyList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsElasticsearchDomainAdvancedSecurityOptionsPropertyToTerraform(struct?: DataAwsElasticsearchDomain.AdvancedSecurityOptionsProperty): any;
export declare function dataAwsElasticsearchDomainAdvancedSecurityOptionsPropertyToHclTerraform(struct?: DataAwsElasticsearchDomain.AdvancedSecurityOptionsProperty): any;
export declare function dataAwsElasticsearchDomainDurationPropertyToTerraform(struct?: DataAwsElasticsearchDomain.DurationProperty): any;
export declare function dataAwsElasticsearchDomainDurationPropertyToHclTerraform(struct?: DataAwsElasticsearchDomain.DurationProperty): any;
export declare function dataAwsElasticsearchDomainMaintenanceSchedulePropertyToTerraform(struct?: DataAwsElasticsearchDomain.MaintenanceScheduleProperty): any;
export declare function dataAwsElasticsearchDomainMaintenanceSchedulePropertyToHclTerraform(struct?: DataAwsElasticsearchDomain.MaintenanceScheduleProperty): any;
export declare function dataAwsElasticsearchDomainAutoTuneOptionsPropertyToTerraform(struct?: DataAwsElasticsearchDomain.AutoTuneOptionsProperty): any;
export declare function dataAwsElasticsearchDomainAutoTuneOptionsPropertyToHclTerraform(struct?: DataAwsElasticsearchDomain.AutoTuneOptionsProperty): any;
export declare function dataAwsElasticsearchDomainColdStorageOptionsPropertyToTerraform(struct?: DataAwsElasticsearchDomain.ColdStorageOptionsProperty): any;
export declare function dataAwsElasticsearchDomainColdStorageOptionsPropertyToHclTerraform(struct?: DataAwsElasticsearchDomain.ColdStorageOptionsProperty): any;
export declare function dataAwsElasticsearchDomainZoneAwarenessConfigPropertyToTerraform(struct?: DataAwsElasticsearchDomain.ZoneAwarenessConfigProperty): any;
export declare function dataAwsElasticsearchDomainZoneAwarenessConfigPropertyToHclTerraform(struct?: DataAwsElasticsearchDomain.ZoneAwarenessConfigProperty): any;
export declare function dataAwsElasticsearchDomainClusterConfigPropertyToTerraform(struct?: DataAwsElasticsearchDomain.ClusterConfigProperty): any;
export declare function dataAwsElasticsearchDomainClusterConfigPropertyToHclTerraform(struct?: DataAwsElasticsearchDomain.ClusterConfigProperty): any;
export declare function dataAwsElasticsearchDomainCognitoOptionsPropertyToTerraform(struct?: DataAwsElasticsearchDomain.CognitoOptionsProperty): any;
export declare function dataAwsElasticsearchDomainCognitoOptionsPropertyToHclTerraform(struct?: DataAwsElasticsearchDomain.CognitoOptionsProperty): any;
export declare function dataAwsElasticsearchDomainEbsOptionsPropertyToTerraform(struct?: DataAwsElasticsearchDomain.EbsOptionsProperty): any;
export declare function dataAwsElasticsearchDomainEbsOptionsPropertyToHclTerraform(struct?: DataAwsElasticsearchDomain.EbsOptionsProperty): any;
export declare function dataAwsElasticsearchDomainEncryptionAtRestPropertyToTerraform(struct?: DataAwsElasticsearchDomain.EncryptionAtRestProperty): any;
export declare function dataAwsElasticsearchDomainEncryptionAtRestPropertyToHclTerraform(struct?: DataAwsElasticsearchDomain.EncryptionAtRestProperty): any;
export declare function dataAwsElasticsearchDomainLogPublishingOptionsPropertyToTerraform(struct?: DataAwsElasticsearchDomain.LogPublishingOptionsProperty): any;
export declare function dataAwsElasticsearchDomainLogPublishingOptionsPropertyToHclTerraform(struct?: DataAwsElasticsearchDomain.LogPublishingOptionsProperty): any;
export declare function dataAwsElasticsearchDomainNodeToNodeEncryptionPropertyToTerraform(struct?: DataAwsElasticsearchDomain.NodeToNodeEncryptionProperty): any;
export declare function dataAwsElasticsearchDomainNodeToNodeEncryptionPropertyToHclTerraform(struct?: DataAwsElasticsearchDomain.NodeToNodeEncryptionProperty): any;
export declare function dataAwsElasticsearchDomainSnapshotOptionsPropertyToTerraform(struct?: DataAwsElasticsearchDomain.SnapshotOptionsProperty): any;
export declare function dataAwsElasticsearchDomainSnapshotOptionsPropertyToHclTerraform(struct?: DataAwsElasticsearchDomain.SnapshotOptionsProperty): any;
export declare function dataAwsElasticsearchDomainVpcOptionsPropertyToTerraform(struct?: DataAwsElasticsearchDomain.VpcOptionsProperty): any;
export declare function dataAwsElasticsearchDomainVpcOptionsPropertyToHclTerraform(struct?: DataAwsElasticsearchDomain.VpcOptionsProperty): any;
export declare namespace DataAwsElasticsearchDomain {
    interface AdvancedSecurityOptionsProperty {
    }
    class AdvancedSecurityOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AdvancedSecurityOptionsProperty | undefined;
        set internalValue(value: AdvancedSecurityOptionsProperty | undefined);
        get enabled(): cdktn.IResolvable;
        get internalUserDatabaseEnabled(): cdktn.IResolvable;
    }
    class AdvancedSecurityOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AdvancedSecurityOptionsPropertyOutputReference;
    }
    interface DurationProperty {
    }
    class DurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DurationProperty | undefined;
        set internalValue(value: DurationProperty | undefined);
        get unit(): string;
        get value(): number;
    }
    class DurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DurationPropertyOutputReference;
    }
    interface MaintenanceScheduleProperty {
    }
    class MaintenanceSchedulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MaintenanceScheduleProperty | undefined;
        set internalValue(value: MaintenanceScheduleProperty | undefined);
        get cronExpressionForRecurrence(): string;
        private _duration;
        get duration(): DurationPropertyList;
        get startAt(): string;
    }
    class MaintenanceSchedulePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MaintenanceSchedulePropertyOutputReference;
    }
    interface AutoTuneOptionsProperty {
    }
    class AutoTuneOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AutoTuneOptionsProperty | undefined;
        set internalValue(value: AutoTuneOptionsProperty | undefined);
        get desiredState(): string;
        private _maintenanceSchedule;
        get maintenanceSchedule(): MaintenanceSchedulePropertyList;
        get rollbackOnDisable(): string;
    }
    class AutoTuneOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AutoTuneOptionsPropertyOutputReference;
    }
    interface ColdStorageOptionsProperty {
    }
    class ColdStorageOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ColdStorageOptionsProperty | undefined;
        set internalValue(value: ColdStorageOptionsProperty | undefined);
        get enabled(): cdktn.IResolvable;
    }
    class ColdStorageOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ColdStorageOptionsPropertyOutputReference;
    }
    interface ZoneAwarenessConfigProperty {
    }
    class ZoneAwarenessConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ZoneAwarenessConfigProperty | undefined;
        set internalValue(value: ZoneAwarenessConfigProperty | undefined);
        get availabilityZoneCount(): number;
    }
    class ZoneAwarenessConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ZoneAwarenessConfigPropertyOutputReference;
    }
    interface ClusterConfigProperty {
    }
    class ClusterConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ClusterConfigProperty | undefined;
        set internalValue(value: ClusterConfigProperty | undefined);
        private _coldStorageOptions;
        get coldStorageOptions(): ColdStorageOptionsPropertyList;
        get dedicatedMasterCount(): number;
        get dedicatedMasterEnabled(): cdktn.IResolvable;
        get dedicatedMasterType(): string;
        get instanceCount(): number;
        get instanceType(): string;
        get warmCount(): number;
        get warmEnabled(): cdktn.IResolvable;
        get warmType(): string;
        private _zoneAwarenessConfig;
        get zoneAwarenessConfig(): ZoneAwarenessConfigPropertyList;
        get zoneAwarenessEnabled(): cdktn.IResolvable;
    }
    class ClusterConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ClusterConfigPropertyOutputReference;
    }
    interface CognitoOptionsProperty {
    }
    class CognitoOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CognitoOptionsProperty | undefined;
        set internalValue(value: CognitoOptionsProperty | undefined);
        get enabled(): cdktn.IResolvable;
        get identityPoolId(): string;
        get roleArn(): string;
        get userPoolId(): string;
    }
    class CognitoOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CognitoOptionsPropertyOutputReference;
    }
    interface EbsOptionsProperty {
    }
    class EbsOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EbsOptionsProperty | undefined;
        set internalValue(value: EbsOptionsProperty | undefined);
        get ebsEnabled(): cdktn.IResolvable;
        get iops(): number;
        get throughput(): number;
        get volumeSize(): number;
        get volumeType(): string;
    }
    class EbsOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EbsOptionsPropertyOutputReference;
    }
    interface EncryptionAtRestProperty {
    }
    class EncryptionAtRestPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EncryptionAtRestProperty | undefined;
        set internalValue(value: EncryptionAtRestProperty | undefined);
        get enabled(): cdktn.IResolvable;
        get kmsKeyId(): string;
    }
    class EncryptionAtRestPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EncryptionAtRestPropertyOutputReference;
    }
    interface LogPublishingOptionsProperty {
    }
    class LogPublishingOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LogPublishingOptionsProperty | undefined;
        set internalValue(value: LogPublishingOptionsProperty | undefined);
        get cloudwatchLogGroupArn(): string;
        get enabled(): cdktn.IResolvable;
        get logType(): string;
    }
    class LogPublishingOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LogPublishingOptionsPropertyOutputReference;
    }
    interface NodeToNodeEncryptionProperty {
    }
    class NodeToNodeEncryptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NodeToNodeEncryptionProperty | undefined;
        set internalValue(value: NodeToNodeEncryptionProperty | undefined);
        get enabled(): cdktn.IResolvable;
    }
    class NodeToNodeEncryptionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NodeToNodeEncryptionPropertyOutputReference;
    }
    interface SnapshotOptionsProperty {
    }
    class SnapshotOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SnapshotOptionsProperty | undefined;
        set internalValue(value: SnapshotOptionsProperty | undefined);
        get automatedSnapshotStartHour(): number;
    }
    class SnapshotOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SnapshotOptionsPropertyOutputReference;
    }
    interface VpcOptionsProperty {
    }
    class VpcOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpcOptionsProperty | undefined;
        set internalValue(value: VpcOptionsProperty | undefined);
        get availabilityZones(): string[];
        get securityGroupIds(): string[];
        get subnetIds(): string[];
        get vpcId(): string;
    }
    class VpcOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpcOptionsPropertyOutputReference;
    }
}
