import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsElasticsearchDomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#access_policies AwsElasticsearchDomain#access_policies}
    */
    readonly accessPolicies?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#advanced_options AwsElasticsearchDomain#advanced_options}
    */
    readonly advancedOptions?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#domain_name AwsElasticsearchDomain#domain_name}
    */
    readonly domainName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#elasticsearch_version AwsElasticsearchDomain#elasticsearch_version}
    */
    readonly elasticsearchVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#id AwsElasticsearchDomain#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#region AwsElasticsearchDomain#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#tags AwsElasticsearchDomain#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#tags_all AwsElasticsearchDomain#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * advanced_security_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#advanced_security_options AwsElasticsearchDomain#advanced_security_options}
    */
    readonly advancedSecurityOptions?: AwsElasticsearchDomain.AdvancedSecurityOptionsProperty;
    /**
    * auto_tune_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#auto_tune_options AwsElasticsearchDomain#auto_tune_options}
    */
    readonly autoTuneOptions?: AwsElasticsearchDomain.AutoTuneOptionsProperty;
    /**
    * cluster_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#cluster_config AwsElasticsearchDomain#cluster_config}
    */
    readonly clusterConfig?: AwsElasticsearchDomain.ClusterConfigProperty;
    /**
    * cognito_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#cognito_options AwsElasticsearchDomain#cognito_options}
    */
    readonly cognitoOptions?: AwsElasticsearchDomain.CognitoOptionsProperty;
    /**
    * domain_endpoint_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#domain_endpoint_options AwsElasticsearchDomain#domain_endpoint_options}
    */
    readonly domainEndpointOptions?: AwsElasticsearchDomain.DomainEndpointOptionsProperty;
    /**
    * ebs_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#ebs_options AwsElasticsearchDomain#ebs_options}
    */
    readonly ebsOptions?: AwsElasticsearchDomain.EbsOptionsProperty;
    /**
    * encrypt_at_rest block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#encrypt_at_rest AwsElasticsearchDomain#encrypt_at_rest}
    */
    readonly encryptAtRest?: AwsElasticsearchDomain.EncryptAtRestProperty;
    /**
    * log_publishing_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#log_publishing_options AwsElasticsearchDomain#log_publishing_options}
    */
    readonly logPublishingOptions?: AwsElasticsearchDomain.LogPublishingOptionsProperty[] | cdktn.IResolvable;
    /**
    * node_to_node_encryption block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#node_to_node_encryption AwsElasticsearchDomain#node_to_node_encryption}
    */
    readonly nodeToNodeEncryption?: AwsElasticsearchDomain.NodeToNodeEncryptionProperty;
    /**
    * snapshot_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#snapshot_options AwsElasticsearchDomain#snapshot_options}
    */
    readonly snapshotOptions?: AwsElasticsearchDomain.SnapshotOptionsProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#timeouts AwsElasticsearchDomain#timeouts}
    */
    readonly timeouts?: AwsElasticsearchDomain.TimeoutsProperty;
    /**
    * vpc_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#vpc_options AwsElasticsearchDomain#vpc_options}
    */
    readonly vpcOptions?: AwsElasticsearchDomain.VpcOptionsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain aws_elasticsearch_domain}
*/
export declare class AwsElasticsearchDomain extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_elasticsearch_domain";
    /**
    * Generates CDKTN code for importing a AwsElasticsearchDomain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsElasticsearchDomain to import
    * @param importFromId The id of the existing AwsElasticsearchDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsElasticsearchDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain aws_elasticsearch_domain} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsElasticsearchDomainConfig
    */
    constructor(scope: Construct, id: string, config: AwsElasticsearchDomainConfig);
    private _accessPolicies?;
    get accessPolicies(): string;
    set accessPolicies(value: string);
    resetAccessPolicies(): void;
    get accessPoliciesInput(): string | undefined;
    private _advancedOptions?;
    get advancedOptions(): {
        [key: string]: string;
    };
    set advancedOptions(value: {
        [key: string]: string;
    });
    resetAdvancedOptions(): void;
    get advancedOptionsInput(): {
        [key: string]: string;
    } | undefined;
    get arn(): string;
    get domainId(): string;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    private _elasticsearchVersion?;
    get elasticsearchVersion(): string;
    set elasticsearchVersion(value: string);
    resetElasticsearchVersion(): void;
    get elasticsearchVersionInput(): string | undefined;
    get endpoint(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get kibanaEndpoint(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _advancedSecurityOptions;
    get advancedSecurityOptions(): AwsElasticsearchDomain.AdvancedSecurityOptionsPropertyOutputReference;
    putAdvancedSecurityOptions(value: AwsElasticsearchDomain.AdvancedSecurityOptionsProperty): void;
    resetAdvancedSecurityOptions(): void;
    get advancedSecurityOptionsInput(): AwsElasticsearchDomain.AdvancedSecurityOptionsProperty | undefined;
    private _autoTuneOptions;
    get autoTuneOptions(): AwsElasticsearchDomain.AutoTuneOptionsPropertyOutputReference;
    putAutoTuneOptions(value: AwsElasticsearchDomain.AutoTuneOptionsProperty): void;
    resetAutoTuneOptions(): void;
    get autoTuneOptionsInput(): AwsElasticsearchDomain.AutoTuneOptionsProperty | undefined;
    private _clusterConfig;
    get clusterConfig(): AwsElasticsearchDomain.ClusterConfigPropertyOutputReference;
    putClusterConfig(value: AwsElasticsearchDomain.ClusterConfigProperty): void;
    resetClusterConfig(): void;
    get clusterConfigInput(): AwsElasticsearchDomain.ClusterConfigProperty | undefined;
    private _cognitoOptions;
    get cognitoOptions(): AwsElasticsearchDomain.CognitoOptionsPropertyOutputReference;
    putCognitoOptions(value: AwsElasticsearchDomain.CognitoOptionsProperty): void;
    resetCognitoOptions(): void;
    get cognitoOptionsInput(): AwsElasticsearchDomain.CognitoOptionsProperty | undefined;
    private _domainEndpointOptions;
    get domainEndpointOptions(): AwsElasticsearchDomain.DomainEndpointOptionsPropertyOutputReference;
    putDomainEndpointOptions(value: AwsElasticsearchDomain.DomainEndpointOptionsProperty): void;
    resetDomainEndpointOptions(): void;
    get domainEndpointOptionsInput(): AwsElasticsearchDomain.DomainEndpointOptionsProperty | undefined;
    private _ebsOptions;
    get ebsOptions(): AwsElasticsearchDomain.EbsOptionsPropertyOutputReference;
    putEbsOptions(value: AwsElasticsearchDomain.EbsOptionsProperty): void;
    resetEbsOptions(): void;
    get ebsOptionsInput(): AwsElasticsearchDomain.EbsOptionsProperty | undefined;
    private _encryptAtRest;
    get encryptAtRest(): AwsElasticsearchDomain.EncryptAtRestPropertyOutputReference;
    putEncryptAtRest(value: AwsElasticsearchDomain.EncryptAtRestProperty): void;
    resetEncryptAtRest(): void;
    get encryptAtRestInput(): AwsElasticsearchDomain.EncryptAtRestProperty | undefined;
    private _logPublishingOptions;
    get logPublishingOptions(): AwsElasticsearchDomain.LogPublishingOptionsPropertyList;
    putLogPublishingOptions(value: AwsElasticsearchDomain.LogPublishingOptionsProperty[] | cdktn.IResolvable): void;
    resetLogPublishingOptions(): void;
    get logPublishingOptionsInput(): cdktn.IResolvable | AwsElasticsearchDomain.LogPublishingOptionsProperty[] | undefined;
    private _nodeToNodeEncryption;
    get nodeToNodeEncryption(): AwsElasticsearchDomain.NodeToNodeEncryptionPropertyOutputReference;
    putNodeToNodeEncryption(value: AwsElasticsearchDomain.NodeToNodeEncryptionProperty): void;
    resetNodeToNodeEncryption(): void;
    get nodeToNodeEncryptionInput(): AwsElasticsearchDomain.NodeToNodeEncryptionProperty | undefined;
    private _snapshotOptions;
    get snapshotOptions(): AwsElasticsearchDomain.SnapshotOptionsPropertyOutputReference;
    putSnapshotOptions(value: AwsElasticsearchDomain.SnapshotOptionsProperty): void;
    resetSnapshotOptions(): void;
    get snapshotOptionsInput(): AwsElasticsearchDomain.SnapshotOptionsProperty | undefined;
    private _timeouts;
    get timeouts(): AwsElasticsearchDomain.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsElasticsearchDomain.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsElasticsearchDomain.TimeoutsProperty | undefined;
    private _vpcOptions;
    get vpcOptions(): AwsElasticsearchDomain.VpcOptionsPropertyOutputReference;
    putVpcOptions(value: AwsElasticsearchDomain.VpcOptionsProperty): void;
    resetVpcOptions(): void;
    get vpcOptionsInput(): AwsElasticsearchDomain.VpcOptionsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsElasticsearchDomainMasterUserOptionsPropertyToTerraform(struct?: AwsElasticsearchDomain.MasterUserOptionsPropertyOutputReference | AwsElasticsearchDomain.MasterUserOptionsProperty): any;
export declare function awsElasticsearchDomainMasterUserOptionsPropertyToHclTerraform(struct?: AwsElasticsearchDomain.MasterUserOptionsPropertyOutputReference | AwsElasticsearchDomain.MasterUserOptionsProperty): any;
export declare function awsElasticsearchDomainAdvancedSecurityOptionsPropertyToTerraform(struct?: AwsElasticsearchDomain.AdvancedSecurityOptionsPropertyOutputReference | AwsElasticsearchDomain.AdvancedSecurityOptionsProperty): any;
export declare function awsElasticsearchDomainAdvancedSecurityOptionsPropertyToHclTerraform(struct?: AwsElasticsearchDomain.AdvancedSecurityOptionsPropertyOutputReference | AwsElasticsearchDomain.AdvancedSecurityOptionsProperty): any;
export declare function awsElasticsearchDomainDurationPropertyToTerraform(struct?: AwsElasticsearchDomain.DurationPropertyOutputReference | AwsElasticsearchDomain.DurationProperty): any;
export declare function awsElasticsearchDomainDurationPropertyToHclTerraform(struct?: AwsElasticsearchDomain.DurationPropertyOutputReference | AwsElasticsearchDomain.DurationProperty): any;
export declare function awsElasticsearchDomainMaintenanceSchedulePropertyToTerraform(struct?: AwsElasticsearchDomain.MaintenanceScheduleProperty | cdktn.IResolvable): any;
export declare function awsElasticsearchDomainMaintenanceSchedulePropertyToHclTerraform(struct?: AwsElasticsearchDomain.MaintenanceScheduleProperty | cdktn.IResolvable): any;
export declare function awsElasticsearchDomainAutoTuneOptionsPropertyToTerraform(struct?: AwsElasticsearchDomain.AutoTuneOptionsPropertyOutputReference | AwsElasticsearchDomain.AutoTuneOptionsProperty): any;
export declare function awsElasticsearchDomainAutoTuneOptionsPropertyToHclTerraform(struct?: AwsElasticsearchDomain.AutoTuneOptionsPropertyOutputReference | AwsElasticsearchDomain.AutoTuneOptionsProperty): any;
export declare function awsElasticsearchDomainColdStorageOptionsPropertyToTerraform(struct?: AwsElasticsearchDomain.ColdStorageOptionsPropertyOutputReference | AwsElasticsearchDomain.ColdStorageOptionsProperty): any;
export declare function awsElasticsearchDomainColdStorageOptionsPropertyToHclTerraform(struct?: AwsElasticsearchDomain.ColdStorageOptionsPropertyOutputReference | AwsElasticsearchDomain.ColdStorageOptionsProperty): any;
export declare function awsElasticsearchDomainZoneAwarenessConfigPropertyToTerraform(struct?: AwsElasticsearchDomain.ZoneAwarenessConfigPropertyOutputReference | AwsElasticsearchDomain.ZoneAwarenessConfigProperty): any;
export declare function awsElasticsearchDomainZoneAwarenessConfigPropertyToHclTerraform(struct?: AwsElasticsearchDomain.ZoneAwarenessConfigPropertyOutputReference | AwsElasticsearchDomain.ZoneAwarenessConfigProperty): any;
export declare function awsElasticsearchDomainClusterConfigPropertyToTerraform(struct?: AwsElasticsearchDomain.ClusterConfigPropertyOutputReference | AwsElasticsearchDomain.ClusterConfigProperty): any;
export declare function awsElasticsearchDomainClusterConfigPropertyToHclTerraform(struct?: AwsElasticsearchDomain.ClusterConfigPropertyOutputReference | AwsElasticsearchDomain.ClusterConfigProperty): any;
export declare function awsElasticsearchDomainCognitoOptionsPropertyToTerraform(struct?: AwsElasticsearchDomain.CognitoOptionsPropertyOutputReference | AwsElasticsearchDomain.CognitoOptionsProperty): any;
export declare function awsElasticsearchDomainCognitoOptionsPropertyToHclTerraform(struct?: AwsElasticsearchDomain.CognitoOptionsPropertyOutputReference | AwsElasticsearchDomain.CognitoOptionsProperty): any;
export declare function awsElasticsearchDomainDomainEndpointOptionsPropertyToTerraform(struct?: AwsElasticsearchDomain.DomainEndpointOptionsPropertyOutputReference | AwsElasticsearchDomain.DomainEndpointOptionsProperty): any;
export declare function awsElasticsearchDomainDomainEndpointOptionsPropertyToHclTerraform(struct?: AwsElasticsearchDomain.DomainEndpointOptionsPropertyOutputReference | AwsElasticsearchDomain.DomainEndpointOptionsProperty): any;
export declare function awsElasticsearchDomainEbsOptionsPropertyToTerraform(struct?: AwsElasticsearchDomain.EbsOptionsPropertyOutputReference | AwsElasticsearchDomain.EbsOptionsProperty): any;
export declare function awsElasticsearchDomainEbsOptionsPropertyToHclTerraform(struct?: AwsElasticsearchDomain.EbsOptionsPropertyOutputReference | AwsElasticsearchDomain.EbsOptionsProperty): any;
export declare function awsElasticsearchDomainEncryptAtRestPropertyToTerraform(struct?: AwsElasticsearchDomain.EncryptAtRestPropertyOutputReference | AwsElasticsearchDomain.EncryptAtRestProperty): any;
export declare function awsElasticsearchDomainEncryptAtRestPropertyToHclTerraform(struct?: AwsElasticsearchDomain.EncryptAtRestPropertyOutputReference | AwsElasticsearchDomain.EncryptAtRestProperty): any;
export declare function awsElasticsearchDomainLogPublishingOptionsPropertyToTerraform(struct?: AwsElasticsearchDomain.LogPublishingOptionsProperty | cdktn.IResolvable): any;
export declare function awsElasticsearchDomainLogPublishingOptionsPropertyToHclTerraform(struct?: AwsElasticsearchDomain.LogPublishingOptionsProperty | cdktn.IResolvable): any;
export declare function awsElasticsearchDomainNodeToNodeEncryptionPropertyToTerraform(struct?: AwsElasticsearchDomain.NodeToNodeEncryptionPropertyOutputReference | AwsElasticsearchDomain.NodeToNodeEncryptionProperty): any;
export declare function awsElasticsearchDomainNodeToNodeEncryptionPropertyToHclTerraform(struct?: AwsElasticsearchDomain.NodeToNodeEncryptionPropertyOutputReference | AwsElasticsearchDomain.NodeToNodeEncryptionProperty): any;
export declare function awsElasticsearchDomainSnapshotOptionsPropertyToTerraform(struct?: AwsElasticsearchDomain.SnapshotOptionsPropertyOutputReference | AwsElasticsearchDomain.SnapshotOptionsProperty): any;
export declare function awsElasticsearchDomainSnapshotOptionsPropertyToHclTerraform(struct?: AwsElasticsearchDomain.SnapshotOptionsPropertyOutputReference | AwsElasticsearchDomain.SnapshotOptionsProperty): any;
export declare function awsElasticsearchDomainTimeoutsPropertyToTerraform(struct?: AwsElasticsearchDomain.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsElasticsearchDomainTimeoutsPropertyToHclTerraform(struct?: AwsElasticsearchDomain.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsElasticsearchDomainVpcOptionsPropertyToTerraform(struct?: AwsElasticsearchDomain.VpcOptionsPropertyOutputReference | AwsElasticsearchDomain.VpcOptionsProperty): any;
export declare function awsElasticsearchDomainVpcOptionsPropertyToHclTerraform(struct?: AwsElasticsearchDomain.VpcOptionsPropertyOutputReference | AwsElasticsearchDomain.VpcOptionsProperty): any;
export declare namespace AwsElasticsearchDomain {
    interface MasterUserOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#master_user_arn AwsElasticsearchDomain#master_user_arn}
        */
        readonly masterUserArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#master_user_name AwsElasticsearchDomain#master_user_name}
        */
        readonly masterUserName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#master_user_password AwsElasticsearchDomain#master_user_password}
        */
        readonly masterUserPassword?: string;
    }
    class MasterUserOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MasterUserOptionsProperty | undefined;
        set internalValue(value: MasterUserOptionsProperty | undefined);
        private _masterUserArn?;
        get masterUserArn(): string;
        set masterUserArn(value: string);
        resetMasterUserArn(): void;
        get masterUserArnInput(): string | undefined;
        private _masterUserName?;
        get masterUserName(): string;
        set masterUserName(value: string);
        resetMasterUserName(): void;
        get masterUserNameInput(): string | undefined;
        private _masterUserPassword?;
        get masterUserPassword(): string;
        set masterUserPassword(value: string);
        resetMasterUserPassword(): void;
        get masterUserPasswordInput(): string | undefined;
    }
    interface AdvancedSecurityOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#enabled AwsElasticsearchDomain#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#internal_user_database_enabled AwsElasticsearchDomain#internal_user_database_enabled}
        */
        readonly internalUserDatabaseEnabled?: boolean | cdktn.IResolvable;
        /**
        * master_user_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#master_user_options AwsElasticsearchDomain#master_user_options}
        */
        readonly masterUserOptions?: MasterUserOptionsProperty;
    }
    class AdvancedSecurityOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AdvancedSecurityOptionsProperty | undefined;
        set internalValue(value: AdvancedSecurityOptionsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _internalUserDatabaseEnabled?;
        get internalUserDatabaseEnabled(): boolean | cdktn.IResolvable;
        set internalUserDatabaseEnabled(value: boolean | cdktn.IResolvable);
        resetInternalUserDatabaseEnabled(): void;
        get internalUserDatabaseEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _masterUserOptions;
        get masterUserOptions(): MasterUserOptionsPropertyOutputReference;
        putMasterUserOptions(value: MasterUserOptionsProperty): void;
        resetMasterUserOptions(): void;
        get masterUserOptionsInput(): MasterUserOptionsProperty | undefined;
    }
    interface DurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#unit AwsElasticsearchDomain#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#value AwsElasticsearchDomain#value}
        */
        readonly value: number;
    }
    class DurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DurationProperty | undefined;
        set internalValue(value: DurationProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface MaintenanceScheduleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#cron_expression_for_recurrence AwsElasticsearchDomain#cron_expression_for_recurrence}
        */
        readonly cronExpressionForRecurrence: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#start_at AwsElasticsearchDomain#start_at}
        */
        readonly startAt: string;
        /**
        * duration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#duration AwsElasticsearchDomain#duration}
        */
        readonly duration: DurationProperty;
    }
    class MaintenanceSchedulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MaintenanceScheduleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MaintenanceScheduleProperty | cdktn.IResolvable | undefined);
        private _cronExpressionForRecurrence?;
        get cronExpressionForRecurrence(): string;
        set cronExpressionForRecurrence(value: string);
        get cronExpressionForRecurrenceInput(): string | undefined;
        private _startAt?;
        get startAt(): string;
        set startAt(value: string);
        get startAtInput(): string | undefined;
        private _duration;
        get duration(): DurationPropertyOutputReference;
        putDuration(value: DurationProperty): void;
        get durationInput(): DurationProperty | undefined;
    }
    class MaintenanceSchedulePropertyList extends cdktn.ComplexList {
        internalValue?: MaintenanceScheduleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MaintenanceSchedulePropertyOutputReference;
    }
    interface AutoTuneOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#desired_state AwsElasticsearchDomain#desired_state}
        */
        readonly desiredState: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#rollback_on_disable AwsElasticsearchDomain#rollback_on_disable}
        */
        readonly rollbackOnDisable?: string;
        /**
        * maintenance_schedule block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#maintenance_schedule AwsElasticsearchDomain#maintenance_schedule}
        */
        readonly maintenanceSchedule?: MaintenanceScheduleProperty[] | cdktn.IResolvable;
    }
    class AutoTuneOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AutoTuneOptionsProperty | undefined;
        set internalValue(value: AutoTuneOptionsProperty | undefined);
        private _desiredState?;
        get desiredState(): string;
        set desiredState(value: string);
        get desiredStateInput(): string | undefined;
        private _rollbackOnDisable?;
        get rollbackOnDisable(): string;
        set rollbackOnDisable(value: string);
        resetRollbackOnDisable(): void;
        get rollbackOnDisableInput(): string | undefined;
        private _maintenanceSchedule;
        get maintenanceSchedule(): MaintenanceSchedulePropertyList;
        putMaintenanceSchedule(value: MaintenanceScheduleProperty[] | cdktn.IResolvable): void;
        resetMaintenanceSchedule(): void;
        get maintenanceScheduleInput(): cdktn.IResolvable | MaintenanceScheduleProperty[] | undefined;
    }
    interface ColdStorageOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#enabled AwsElasticsearchDomain#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class ColdStorageOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ColdStorageOptionsProperty | undefined;
        set internalValue(value: ColdStorageOptionsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface ZoneAwarenessConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#availability_zone_count AwsElasticsearchDomain#availability_zone_count}
        */
        readonly availabilityZoneCount?: number;
    }
    class ZoneAwarenessConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ZoneAwarenessConfigProperty | undefined;
        set internalValue(value: ZoneAwarenessConfigProperty | undefined);
        private _availabilityZoneCount?;
        get availabilityZoneCount(): number;
        set availabilityZoneCount(value: number);
        resetAvailabilityZoneCount(): void;
        get availabilityZoneCountInput(): number | undefined;
    }
    interface ClusterConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#dedicated_master_count AwsElasticsearchDomain#dedicated_master_count}
        */
        readonly dedicatedMasterCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#dedicated_master_enabled AwsElasticsearchDomain#dedicated_master_enabled}
        */
        readonly dedicatedMasterEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#dedicated_master_type AwsElasticsearchDomain#dedicated_master_type}
        */
        readonly dedicatedMasterType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#instance_count AwsElasticsearchDomain#instance_count}
        */
        readonly instanceCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#instance_type AwsElasticsearchDomain#instance_type}
        */
        readonly instanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#warm_count AwsElasticsearchDomain#warm_count}
        */
        readonly warmCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#warm_enabled AwsElasticsearchDomain#warm_enabled}
        */
        readonly warmEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#warm_type AwsElasticsearchDomain#warm_type}
        */
        readonly warmType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#zone_awareness_enabled AwsElasticsearchDomain#zone_awareness_enabled}
        */
        readonly zoneAwarenessEnabled?: boolean | cdktn.IResolvable;
        /**
        * cold_storage_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#cold_storage_options AwsElasticsearchDomain#cold_storage_options}
        */
        readonly coldStorageOptions?: ColdStorageOptionsProperty;
        /**
        * zone_awareness_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#zone_awareness_config AwsElasticsearchDomain#zone_awareness_config}
        */
        readonly zoneAwarenessConfig?: ZoneAwarenessConfigProperty;
    }
    class ClusterConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ClusterConfigProperty | undefined;
        set internalValue(value: ClusterConfigProperty | undefined);
        private _dedicatedMasterCount?;
        get dedicatedMasterCount(): number;
        set dedicatedMasterCount(value: number);
        resetDedicatedMasterCount(): void;
        get dedicatedMasterCountInput(): number | undefined;
        private _dedicatedMasterEnabled?;
        get dedicatedMasterEnabled(): boolean | cdktn.IResolvable;
        set dedicatedMasterEnabled(value: boolean | cdktn.IResolvable);
        resetDedicatedMasterEnabled(): void;
        get dedicatedMasterEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _dedicatedMasterType?;
        get dedicatedMasterType(): string;
        set dedicatedMasterType(value: string);
        resetDedicatedMasterType(): void;
        get dedicatedMasterTypeInput(): string | undefined;
        private _instanceCount?;
        get instanceCount(): number;
        set instanceCount(value: number);
        resetInstanceCount(): void;
        get instanceCountInput(): number | undefined;
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _warmCount?;
        get warmCount(): number;
        set warmCount(value: number);
        resetWarmCount(): void;
        get warmCountInput(): number | undefined;
        private _warmEnabled?;
        get warmEnabled(): boolean | cdktn.IResolvable;
        set warmEnabled(value: boolean | cdktn.IResolvable);
        resetWarmEnabled(): void;
        get warmEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _warmType?;
        get warmType(): string;
        set warmType(value: string);
        resetWarmType(): void;
        get warmTypeInput(): string | undefined;
        private _zoneAwarenessEnabled?;
        get zoneAwarenessEnabled(): boolean | cdktn.IResolvable;
        set zoneAwarenessEnabled(value: boolean | cdktn.IResolvable);
        resetZoneAwarenessEnabled(): void;
        get zoneAwarenessEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _coldStorageOptions;
        get coldStorageOptions(): ColdStorageOptionsPropertyOutputReference;
        putColdStorageOptions(value: ColdStorageOptionsProperty): void;
        resetColdStorageOptions(): void;
        get coldStorageOptionsInput(): ColdStorageOptionsProperty | undefined;
        private _zoneAwarenessConfig;
        get zoneAwarenessConfig(): ZoneAwarenessConfigPropertyOutputReference;
        putZoneAwarenessConfig(value: ZoneAwarenessConfigProperty): void;
        resetZoneAwarenessConfig(): void;
        get zoneAwarenessConfigInput(): ZoneAwarenessConfigProperty | undefined;
    }
    interface CognitoOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#enabled AwsElasticsearchDomain#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#identity_pool_id AwsElasticsearchDomain#identity_pool_id}
        */
        readonly identityPoolId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#role_arn AwsElasticsearchDomain#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#user_pool_id AwsElasticsearchDomain#user_pool_id}
        */
        readonly userPoolId: string;
    }
    class CognitoOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CognitoOptionsProperty | undefined;
        set internalValue(value: CognitoOptionsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _identityPoolId?;
        get identityPoolId(): string;
        set identityPoolId(value: string);
        get identityPoolIdInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _userPoolId?;
        get userPoolId(): string;
        set userPoolId(value: string);
        get userPoolIdInput(): string | undefined;
    }
    interface DomainEndpointOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#custom_endpoint AwsElasticsearchDomain#custom_endpoint}
        */
        readonly customEndpoint?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#custom_endpoint_certificate_arn AwsElasticsearchDomain#custom_endpoint_certificate_arn}
        */
        readonly customEndpointCertificateArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#custom_endpoint_enabled AwsElasticsearchDomain#custom_endpoint_enabled}
        */
        readonly customEndpointEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#enforce_https AwsElasticsearchDomain#enforce_https}
        */
        readonly enforceHttps?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#tls_security_policy AwsElasticsearchDomain#tls_security_policy}
        */
        readonly tlsSecurityPolicy?: string;
    }
    class DomainEndpointOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DomainEndpointOptionsProperty | undefined;
        set internalValue(value: DomainEndpointOptionsProperty | undefined);
        private _customEndpoint?;
        get customEndpoint(): string;
        set customEndpoint(value: string);
        resetCustomEndpoint(): void;
        get customEndpointInput(): string | undefined;
        private _customEndpointCertificateArn?;
        get customEndpointCertificateArn(): string;
        set customEndpointCertificateArn(value: string);
        resetCustomEndpointCertificateArn(): void;
        get customEndpointCertificateArnInput(): string | undefined;
        private _customEndpointEnabled?;
        get customEndpointEnabled(): boolean | cdktn.IResolvable;
        set customEndpointEnabled(value: boolean | cdktn.IResolvable);
        resetCustomEndpointEnabled(): void;
        get customEndpointEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _enforceHttps?;
        get enforceHttps(): boolean | cdktn.IResolvable;
        set enforceHttps(value: boolean | cdktn.IResolvable);
        resetEnforceHttps(): void;
        get enforceHttpsInput(): boolean | cdktn.IResolvable | undefined;
        private _tlsSecurityPolicy?;
        get tlsSecurityPolicy(): string;
        set tlsSecurityPolicy(value: string);
        resetTlsSecurityPolicy(): void;
        get tlsSecurityPolicyInput(): string | undefined;
    }
    interface EbsOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#ebs_enabled AwsElasticsearchDomain#ebs_enabled}
        */
        readonly ebsEnabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#iops AwsElasticsearchDomain#iops}
        */
        readonly iops?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#throughput AwsElasticsearchDomain#throughput}
        */
        readonly throughput?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#volume_size AwsElasticsearchDomain#volume_size}
        */
        readonly volumeSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#volume_type AwsElasticsearchDomain#volume_type}
        */
        readonly volumeType?: string;
    }
    class EbsOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EbsOptionsProperty | undefined;
        set internalValue(value: EbsOptionsProperty | undefined);
        private _ebsEnabled?;
        get ebsEnabled(): boolean | cdktn.IResolvable;
        set ebsEnabled(value: boolean | cdktn.IResolvable);
        get ebsEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _iops?;
        get iops(): number;
        set iops(value: number);
        resetIops(): void;
        get iopsInput(): number | undefined;
        private _throughput?;
        get throughput(): number;
        set throughput(value: number);
        resetThroughput(): void;
        get throughputInput(): number | undefined;
        private _volumeSize?;
        get volumeSize(): number;
        set volumeSize(value: number);
        resetVolumeSize(): void;
        get volumeSizeInput(): number | undefined;
        private _volumeType?;
        get volumeType(): string;
        set volumeType(value: string);
        resetVolumeType(): void;
        get volumeTypeInput(): string | undefined;
    }
    interface EncryptAtRestProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#enabled AwsElasticsearchDomain#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#kms_key_id AwsElasticsearchDomain#kms_key_id}
        */
        readonly kmsKeyId?: string;
    }
    class EncryptAtRestPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncryptAtRestProperty | undefined;
        set internalValue(value: EncryptAtRestProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
    }
    interface LogPublishingOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#cloudwatch_log_group_arn AwsElasticsearchDomain#cloudwatch_log_group_arn}
        */
        readonly cloudwatchLogGroupArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#enabled AwsElasticsearchDomain#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#log_type AwsElasticsearchDomain#log_type}
        */
        readonly logType: string;
    }
    class LogPublishingOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LogPublishingOptionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LogPublishingOptionsProperty | cdktn.IResolvable | undefined);
        private _cloudwatchLogGroupArn?;
        get cloudwatchLogGroupArn(): string;
        set cloudwatchLogGroupArn(value: string);
        get cloudwatchLogGroupArnInput(): string | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _logType?;
        get logType(): string;
        set logType(value: string);
        get logTypeInput(): string | undefined;
    }
    class LogPublishingOptionsPropertyList extends cdktn.ComplexList {
        internalValue?: LogPublishingOptionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LogPublishingOptionsPropertyOutputReference;
    }
    interface NodeToNodeEncryptionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#enabled AwsElasticsearchDomain#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
    }
    class NodeToNodeEncryptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NodeToNodeEncryptionProperty | undefined;
        set internalValue(value: NodeToNodeEncryptionProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface SnapshotOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#automated_snapshot_start_hour AwsElasticsearchDomain#automated_snapshot_start_hour}
        */
        readonly automatedSnapshotStartHour: number;
    }
    class SnapshotOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SnapshotOptionsProperty | undefined;
        set internalValue(value: SnapshotOptionsProperty | undefined);
        private _automatedSnapshotStartHour?;
        get automatedSnapshotStartHour(): number;
        set automatedSnapshotStartHour(value: number);
        get automatedSnapshotStartHourInput(): number | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#create AwsElasticsearchDomain#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#delete AwsElasticsearchDomain#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#update AwsElasticsearchDomain#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface VpcOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#security_group_ids AwsElasticsearchDomain#security_group_ids}
        */
        readonly securityGroupIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elasticsearch_domain#subnet_ids AwsElasticsearchDomain#subnet_ids}
        */
        readonly subnetIds?: string[];
    }
    class VpcOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcOptionsProperty | undefined;
        set internalValue(value: VpcOptionsProperty | undefined);
        get availabilityZones(): string[];
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        resetSecurityGroupIds(): void;
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        resetSubnetIds(): void;
        get subnetIdsInput(): string[] | undefined;
        get vpcId(): string;
    }
}
