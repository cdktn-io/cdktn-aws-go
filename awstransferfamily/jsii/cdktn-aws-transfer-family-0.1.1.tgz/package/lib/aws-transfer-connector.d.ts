import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsTransferConnectorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#access_role AwsTransferConnector#access_role}
    */
    readonly accessRole: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#id AwsTransferConnector#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#logging_role AwsTransferConnector#logging_role}
    */
    readonly loggingRole?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#region AwsTransferConnector#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#security_policy_name AwsTransferConnector#security_policy_name}
    */
    readonly securityPolicyName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#tags AwsTransferConnector#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#tags_all AwsTransferConnector#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#url AwsTransferConnector#url}
    */
    readonly url?: string;
    /**
    * as2_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#as2_config AwsTransferConnector#as2_config}
    */
    readonly as2Config?: AwsTransferConnector.As2ConfigProperty;
    /**
    * egress_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#egress_config AwsTransferConnector#egress_config}
    */
    readonly egressConfig?: AwsTransferConnector.EgressConfigProperty;
    /**
    * sftp_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#sftp_config AwsTransferConnector#sftp_config}
    */
    readonly sftpConfig?: AwsTransferConnector.SftpConfigProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#timeouts AwsTransferConnector#timeouts}
    */
    readonly timeouts?: AwsTransferConnector.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector aws_transfer_connector}
*/
export declare class AwsTransferConnector extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_transfer_connector";
    /**
    * Generates CDKTN code for importing a AwsTransferConnector resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsTransferConnector to import
    * @param importFromId The id of the existing AwsTransferConnector that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsTransferConnector to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector aws_transfer_connector} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsTransferConnectorConfig
    */
    constructor(scope: Construct, id: string, config: AwsTransferConnectorConfig);
    private _accessRole?;
    get accessRole(): string;
    set accessRole(value: string);
    get accessRoleInput(): string | undefined;
    get arn(): string;
    get connectorId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _loggingRole?;
    get loggingRole(): string;
    set loggingRole(value: string);
    resetLoggingRole(): void;
    get loggingRoleInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _securityPolicyName?;
    get securityPolicyName(): string;
    set securityPolicyName(value: string);
    resetSecurityPolicyName(): void;
    get securityPolicyNameInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _as2Config;
    get as2Config(): AwsTransferConnector.As2ConfigPropertyOutputReference;
    putAs2Config(value: AwsTransferConnector.As2ConfigProperty): void;
    resetAs2Config(): void;
    get as2ConfigInput(): AwsTransferConnector.As2ConfigProperty | undefined;
    private _egressConfig;
    get egressConfig(): AwsTransferConnector.EgressConfigPropertyOutputReference;
    putEgressConfig(value: AwsTransferConnector.EgressConfigProperty): void;
    resetEgressConfig(): void;
    get egressConfigInput(): AwsTransferConnector.EgressConfigProperty | undefined;
    private _sftpConfig;
    get sftpConfig(): AwsTransferConnector.SftpConfigPropertyOutputReference;
    putSftpConfig(value: AwsTransferConnector.SftpConfigProperty): void;
    resetSftpConfig(): void;
    get sftpConfigInput(): AwsTransferConnector.SftpConfigProperty | undefined;
    private _timeouts;
    get timeouts(): AwsTransferConnector.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsTransferConnector.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsTransferConnector.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsTransferConnectorAs2ConfigPropertyToTerraform(struct?: AwsTransferConnector.As2ConfigPropertyOutputReference | AwsTransferConnector.As2ConfigProperty): any;
export declare function awsTransferConnectorAs2ConfigPropertyToHclTerraform(struct?: AwsTransferConnector.As2ConfigPropertyOutputReference | AwsTransferConnector.As2ConfigProperty): any;
export declare function awsTransferConnectorVpcLatticePropertyToTerraform(struct?: AwsTransferConnector.VpcLatticePropertyOutputReference | AwsTransferConnector.VpcLatticeProperty): any;
export declare function awsTransferConnectorVpcLatticePropertyToHclTerraform(struct?: AwsTransferConnector.VpcLatticePropertyOutputReference | AwsTransferConnector.VpcLatticeProperty): any;
export declare function awsTransferConnectorEgressConfigPropertyToTerraform(struct?: AwsTransferConnector.EgressConfigPropertyOutputReference | AwsTransferConnector.EgressConfigProperty): any;
export declare function awsTransferConnectorEgressConfigPropertyToHclTerraform(struct?: AwsTransferConnector.EgressConfigPropertyOutputReference | AwsTransferConnector.EgressConfigProperty): any;
export declare function awsTransferConnectorSftpConfigPropertyToTerraform(struct?: AwsTransferConnector.SftpConfigPropertyOutputReference | AwsTransferConnector.SftpConfigProperty): any;
export declare function awsTransferConnectorSftpConfigPropertyToHclTerraform(struct?: AwsTransferConnector.SftpConfigPropertyOutputReference | AwsTransferConnector.SftpConfigProperty): any;
export declare function awsTransferConnectorTimeoutsPropertyToTerraform(struct?: AwsTransferConnector.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsTransferConnectorTimeoutsPropertyToHclTerraform(struct?: AwsTransferConnector.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsTransferConnector {
    interface As2ConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#compression AwsTransferConnector#compression}
        */
        readonly compression: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#encryption_algorithm AwsTransferConnector#encryption_algorithm}
        */
        readonly encryptionAlgorithm: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#local_profile_id AwsTransferConnector#local_profile_id}
        */
        readonly localProfileId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#mdn_response AwsTransferConnector#mdn_response}
        */
        readonly mdnResponse: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#mdn_signing_algorithm AwsTransferConnector#mdn_signing_algorithm}
        */
        readonly mdnSigningAlgorithm?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#message_subject AwsTransferConnector#message_subject}
        */
        readonly messageSubject?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#partner_profile_id AwsTransferConnector#partner_profile_id}
        */
        readonly partnerProfileId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#signing_algorithm AwsTransferConnector#signing_algorithm}
        */
        readonly signingAlgorithm: string;
    }
    class As2ConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): As2ConfigProperty | undefined;
        set internalValue(value: As2ConfigProperty | undefined);
        private _compression?;
        get compression(): string;
        set compression(value: string);
        get compressionInput(): string | undefined;
        private _encryptionAlgorithm?;
        get encryptionAlgorithm(): string;
        set encryptionAlgorithm(value: string);
        get encryptionAlgorithmInput(): string | undefined;
        private _localProfileId?;
        get localProfileId(): string;
        set localProfileId(value: string);
        get localProfileIdInput(): string | undefined;
        private _mdnResponse?;
        get mdnResponse(): string;
        set mdnResponse(value: string);
        get mdnResponseInput(): string | undefined;
        private _mdnSigningAlgorithm?;
        get mdnSigningAlgorithm(): string;
        set mdnSigningAlgorithm(value: string);
        resetMdnSigningAlgorithm(): void;
        get mdnSigningAlgorithmInput(): string | undefined;
        private _messageSubject?;
        get messageSubject(): string;
        set messageSubject(value: string);
        resetMessageSubject(): void;
        get messageSubjectInput(): string | undefined;
        private _partnerProfileId?;
        get partnerProfileId(): string;
        set partnerProfileId(value: string);
        get partnerProfileIdInput(): string | undefined;
        private _signingAlgorithm?;
        get signingAlgorithm(): string;
        set signingAlgorithm(value: string);
        get signingAlgorithmInput(): string | undefined;
    }
    interface VpcLatticeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#port_number AwsTransferConnector#port_number}
        */
        readonly portNumber?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#resource_configuration_arn AwsTransferConnector#resource_configuration_arn}
        */
        readonly resourceConfigurationArn: string;
    }
    class VpcLatticePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcLatticeProperty | undefined;
        set internalValue(value: VpcLatticeProperty | undefined);
        private _portNumber?;
        get portNumber(): number;
        set portNumber(value: number);
        resetPortNumber(): void;
        get portNumberInput(): number | undefined;
        private _resourceConfigurationArn?;
        get resourceConfigurationArn(): string;
        set resourceConfigurationArn(value: string);
        get resourceConfigurationArnInput(): string | undefined;
    }
    interface EgressConfigProperty {
        /**
        * vpc_lattice block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#vpc_lattice AwsTransferConnector#vpc_lattice}
        */
        readonly vpcLattice?: VpcLatticeProperty;
    }
    class EgressConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EgressConfigProperty | undefined;
        set internalValue(value: EgressConfigProperty | undefined);
        private _vpcLattice;
        get vpcLattice(): VpcLatticePropertyOutputReference;
        putVpcLattice(value: VpcLatticeProperty): void;
        resetVpcLattice(): void;
        get vpcLatticeInput(): VpcLatticeProperty | undefined;
    }
    interface SftpConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#trusted_host_keys AwsTransferConnector#trusted_host_keys}
        */
        readonly trustedHostKeys?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#user_secret_id AwsTransferConnector#user_secret_id}
        */
        readonly userSecretId?: string;
    }
    class SftpConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SftpConfigProperty | undefined;
        set internalValue(value: SftpConfigProperty | undefined);
        private _trustedHostKeys?;
        get trustedHostKeys(): string[];
        set trustedHostKeys(value: string[]);
        resetTrustedHostKeys(): void;
        get trustedHostKeysInput(): string[] | undefined;
        private _userSecretId?;
        get userSecretId(): string;
        set userSecretId(value: string);
        resetUserSecretId(): void;
        get userSecretIdInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#create AwsTransferConnector#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#delete AwsTransferConnector#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#update AwsTransferConnector#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
