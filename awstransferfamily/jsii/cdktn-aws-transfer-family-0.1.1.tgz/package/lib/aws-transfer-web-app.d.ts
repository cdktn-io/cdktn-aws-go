import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsTransferWebAppConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_web_app#access_endpoint AwsTransferWebApp#access_endpoint}
    */
    readonly accessEndpoint?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_web_app#region AwsTransferWebApp#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_web_app#tags AwsTransferWebApp#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_web_app#web_app_endpoint_policy AwsTransferWebApp#web_app_endpoint_policy}
    */
    readonly webAppEndpointPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_web_app#web_app_units AwsTransferWebApp#web_app_units}
    */
    readonly webAppUnits?: AwsTransferWebApp.WebAppUnitsProperty[] | cdktn.IResolvable;
    /**
    * endpoint_details block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_web_app#endpoint_details AwsTransferWebApp#endpoint_details}
    */
    readonly endpointDetails?: AwsTransferWebApp.EndpointDetailsProperty[] | cdktn.IResolvable;
    /**
    * identity_provider_details block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_web_app#identity_provider_details AwsTransferWebApp#identity_provider_details}
    */
    readonly identityProviderDetails?: AwsTransferWebApp.IdentityProviderDetailsProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_web_app aws_transfer_web_app}
*/
export declare class AwsTransferWebApp extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_transfer_web_app";
    /**
    * Generates CDKTN code for importing a AwsTransferWebApp resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsTransferWebApp to import
    * @param importFromId The id of the existing AwsTransferWebApp that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_web_app#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsTransferWebApp to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_web_app aws_transfer_web_app} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsTransferWebAppConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsTransferWebAppConfig);
    private _accessEndpoint?;
    get accessEndpoint(): string;
    set accessEndpoint(value: string);
    resetAccessEndpoint(): void;
    get accessEndpointInput(): string | undefined;
    get arn(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _webAppEndpointPolicy?;
    get webAppEndpointPolicy(): string;
    set webAppEndpointPolicy(value: string);
    resetWebAppEndpointPolicy(): void;
    get webAppEndpointPolicyInput(): string | undefined;
    get webAppId(): string;
    private _webAppUnits;
    get webAppUnits(): AwsTransferWebApp.WebAppUnitsPropertyList;
    putWebAppUnits(value: AwsTransferWebApp.WebAppUnitsProperty[] | cdktn.IResolvable): void;
    resetWebAppUnits(): void;
    get webAppUnitsInput(): cdktn.IResolvable | AwsTransferWebApp.WebAppUnitsProperty[] | undefined;
    private _endpointDetails;
    get endpointDetails(): AwsTransferWebApp.EndpointDetailsPropertyList;
    putEndpointDetails(value: AwsTransferWebApp.EndpointDetailsProperty[] | cdktn.IResolvable): void;
    resetEndpointDetails(): void;
    get endpointDetailsInput(): cdktn.IResolvable | AwsTransferWebApp.EndpointDetailsProperty[] | undefined;
    private _identityProviderDetails;
    get identityProviderDetails(): AwsTransferWebApp.IdentityProviderDetailsPropertyList;
    putIdentityProviderDetails(value: AwsTransferWebApp.IdentityProviderDetailsProperty[] | cdktn.IResolvable): void;
    resetIdentityProviderDetails(): void;
    get identityProviderDetailsInput(): cdktn.IResolvable | AwsTransferWebApp.IdentityProviderDetailsProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsTransferWebAppWebAppUnitsPropertyToTerraform(struct?: AwsTransferWebApp.WebAppUnitsProperty | cdktn.IResolvable): any;
export declare function awsTransferWebAppWebAppUnitsPropertyToHclTerraform(struct?: AwsTransferWebApp.WebAppUnitsProperty | cdktn.IResolvable): any;
export declare function awsTransferWebAppVpcPropertyToTerraform(struct?: AwsTransferWebApp.VpcProperty | cdktn.IResolvable): any;
export declare function awsTransferWebAppVpcPropertyToHclTerraform(struct?: AwsTransferWebApp.VpcProperty | cdktn.IResolvable): any;
export declare function awsTransferWebAppEndpointDetailsPropertyToTerraform(struct?: AwsTransferWebApp.EndpointDetailsProperty | cdktn.IResolvable): any;
export declare function awsTransferWebAppEndpointDetailsPropertyToHclTerraform(struct?: AwsTransferWebApp.EndpointDetailsProperty | cdktn.IResolvable): any;
export declare function awsTransferWebAppIdentityCenterConfigPropertyToTerraform(struct?: AwsTransferWebApp.IdentityCenterConfigProperty | cdktn.IResolvable): any;
export declare function awsTransferWebAppIdentityCenterConfigPropertyToHclTerraform(struct?: AwsTransferWebApp.IdentityCenterConfigProperty | cdktn.IResolvable): any;
export declare function awsTransferWebAppIdentityProviderDetailsPropertyToTerraform(struct?: AwsTransferWebApp.IdentityProviderDetailsProperty | cdktn.IResolvable): any;
export declare function awsTransferWebAppIdentityProviderDetailsPropertyToHclTerraform(struct?: AwsTransferWebApp.IdentityProviderDetailsProperty | cdktn.IResolvable): any;
export declare namespace AwsTransferWebApp {
    interface WebAppUnitsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_web_app#provisioned AwsTransferWebApp#provisioned}
        */
        readonly provisioned?: number;
    }
    class WebAppUnitsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WebAppUnitsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WebAppUnitsProperty | cdktn.IResolvable | undefined);
        private _provisioned?;
        get provisioned(): number;
        set provisioned(value: number);
        resetProvisioned(): void;
        get provisionedInput(): number | undefined;
    }
    class WebAppUnitsPropertyList extends cdktn.ComplexList {
        internalValue?: WebAppUnitsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WebAppUnitsPropertyOutputReference;
    }
    interface VpcProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_web_app#security_group_ids AwsTransferWebApp#security_group_ids}
        */
        readonly securityGroupIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_web_app#subnet_ids AwsTransferWebApp#subnet_ids}
        */
        readonly subnetIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_web_app#vpc_id AwsTransferWebApp#vpc_id}
        */
        readonly vpcId: string;
    }
    class VpcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpcProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VpcProperty | cdktn.IResolvable | undefined);
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        resetSecurityGroupIds(): void;
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
        get vpcEndpointId(): string;
        private _vpcId?;
        get vpcId(): string;
        set vpcId(value: string);
        get vpcIdInput(): string | undefined;
    }
    class VpcPropertyList extends cdktn.ComplexList {
        internalValue?: VpcProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpcPropertyOutputReference;
    }
    interface EndpointDetailsProperty {
        /**
        * vpc block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_web_app#vpc AwsTransferWebApp#vpc}
        */
        readonly vpc?: VpcProperty[] | cdktn.IResolvable;
    }
    class EndpointDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EndpointDetailsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EndpointDetailsProperty | cdktn.IResolvable | undefined);
        private _vpc;
        get vpc(): VpcPropertyList;
        putVpc(value: VpcProperty[] | cdktn.IResolvable): void;
        resetVpc(): void;
        get vpcInput(): cdktn.IResolvable | VpcProperty[] | undefined;
    }
    class EndpointDetailsPropertyList extends cdktn.ComplexList {
        internalValue?: EndpointDetailsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EndpointDetailsPropertyOutputReference;
    }
    interface IdentityCenterConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_web_app#instance_arn AwsTransferWebApp#instance_arn}
        */
        readonly instanceArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_web_app#role AwsTransferWebApp#role}
        */
        readonly role?: string;
    }
    class IdentityCenterConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IdentityCenterConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IdentityCenterConfigProperty | cdktn.IResolvable | undefined);
        get applicationArn(): string;
        private _instanceArn?;
        get instanceArn(): string;
        set instanceArn(value: string);
        resetInstanceArn(): void;
        get instanceArnInput(): string | undefined;
        private _role?;
        get role(): string;
        set role(value: string);
        resetRole(): void;
        get roleInput(): string | undefined;
    }
    class IdentityCenterConfigPropertyList extends cdktn.ComplexList {
        internalValue?: IdentityCenterConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IdentityCenterConfigPropertyOutputReference;
    }
    interface IdentityProviderDetailsProperty {
        /**
        * identity_center_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_web_app#identity_center_config AwsTransferWebApp#identity_center_config}
        */
        readonly identityCenterConfig?: IdentityCenterConfigProperty[] | cdktn.IResolvable;
    }
    class IdentityProviderDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IdentityProviderDetailsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IdentityProviderDetailsProperty | cdktn.IResolvable | undefined);
        private _identityCenterConfig;
        get identityCenterConfig(): IdentityCenterConfigPropertyList;
        putIdentityCenterConfig(value: IdentityCenterConfigProperty[] | cdktn.IResolvable): void;
        resetIdentityCenterConfig(): void;
        get identityCenterConfigInput(): cdktn.IResolvable | IdentityCenterConfigProperty[] | undefined;
    }
    class IdentityProviderDetailsPropertyList extends cdktn.ComplexList {
        internalValue?: IdentityProviderDetailsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IdentityProviderDetailsPropertyOutputReference;
    }
}
