import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsTransferConnectorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/transfer_connector#id DataAwsTransferConnector#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/transfer_connector#region DataAwsTransferConnector#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/transfer_connector aws_transfer_connector}
*/
export declare class DataAwsTransferConnector extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_transfer_connector";
    /**
    * Generates CDKTN code for importing a DataAwsTransferConnector resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsTransferConnector to import
    * @param importFromId The id of the existing DataAwsTransferConnector that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/transfer_connector#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsTransferConnector to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/transfer_connector aws_transfer_connector} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsTransferConnectorConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsTransferConnectorConfig);
    get accessRole(): string;
    get arn(): string;
    private _as2Config;
    get as2Config(): DataAwsTransferConnector.As2ConfigPropertyList;
    private _egressConfig;
    get egressConfig(): DataAwsTransferConnector.EgressConfigPropertyList;
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    get loggingRole(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get securityPolicyName(): string;
    get serviceManagedEgressIpAddresses(): string[];
    private _sftpConfig;
    get sftpConfig(): DataAwsTransferConnector.SftpConfigPropertyList;
    private _tags;
    get tags(): cdktn.StringMap;
    get url(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsTransferConnectorAs2ConfigPropertyToTerraform(struct?: DataAwsTransferConnector.As2ConfigProperty): any;
export declare function dataAwsTransferConnectorAs2ConfigPropertyToHclTerraform(struct?: DataAwsTransferConnector.As2ConfigProperty): any;
export declare function dataAwsTransferConnectorVpcLatticePropertyToTerraform(struct?: DataAwsTransferConnector.VpcLatticeProperty): any;
export declare function dataAwsTransferConnectorVpcLatticePropertyToHclTerraform(struct?: DataAwsTransferConnector.VpcLatticeProperty): any;
export declare function dataAwsTransferConnectorEgressConfigPropertyToTerraform(struct?: DataAwsTransferConnector.EgressConfigProperty): any;
export declare function dataAwsTransferConnectorEgressConfigPropertyToHclTerraform(struct?: DataAwsTransferConnector.EgressConfigProperty): any;
export declare function dataAwsTransferConnectorSftpConfigPropertyToTerraform(struct?: DataAwsTransferConnector.SftpConfigProperty): any;
export declare function dataAwsTransferConnectorSftpConfigPropertyToHclTerraform(struct?: DataAwsTransferConnector.SftpConfigProperty): any;
export declare namespace DataAwsTransferConnector {
    interface As2ConfigProperty {
    }
    class As2ConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): As2ConfigProperty | undefined;
        set internalValue(value: As2ConfigProperty | undefined);
        get basicAuthSecretId(): string;
        get compression(): string;
        get encryptionAlgorithm(): string;
        get localProfileId(): string;
        get mdnResponse(): string;
        get mdnSigningAlgorithm(): string;
        get messageSubject(): string;
        get partnerProfileId(): string;
        get singingAlgorithm(): string;
    }
    class As2ConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): As2ConfigPropertyOutputReference;
    }
    interface VpcLatticeProperty {
    }
    class VpcLatticePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpcLatticeProperty | undefined;
        set internalValue(value: VpcLatticeProperty | undefined);
        get portNumber(): number;
        get resourceConfigurationArn(): string;
    }
    class VpcLatticePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpcLatticePropertyOutputReference;
    }
    interface EgressConfigProperty {
    }
    class EgressConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EgressConfigProperty | undefined;
        set internalValue(value: EgressConfigProperty | undefined);
        private _vpcLattice;
        get vpcLattice(): VpcLatticePropertyList;
    }
    class EgressConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EgressConfigPropertyOutputReference;
    }
    interface SftpConfigProperty {
    }
    class SftpConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SftpConfigProperty | undefined;
        set internalValue(value: SftpConfigProperty | undefined);
        get trustedHostKeys(): string[];
        get userSecretId(): string;
    }
    class SftpConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SftpConfigPropertyOutputReference;
    }
}
