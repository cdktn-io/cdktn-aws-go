import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsTransferServerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#certificate AwsTransferServer#certificate}
    */
    readonly certificate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#directory_id AwsTransferServer#directory_id}
    */
    readonly directoryId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#domain AwsTransferServer#domain}
    */
    readonly domain?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#endpoint_type AwsTransferServer#endpoint_type}
    */
    readonly endpointType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#force_destroy AwsTransferServer#force_destroy}
    */
    readonly forceDestroy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#function AwsTransferServer#function}
    */
    readonly function?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#host_key AwsTransferServer#host_key}
    */
    readonly hostKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#id AwsTransferServer#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#identity_provider_type AwsTransferServer#identity_provider_type}
    */
    readonly identityProviderType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#invocation_role AwsTransferServer#invocation_role}
    */
    readonly invocationRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#ip_address_type AwsTransferServer#ip_address_type}
    */
    readonly ipAddressType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#logging_role AwsTransferServer#logging_role}
    */
    readonly loggingRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#post_authentication_login_banner AwsTransferServer#post_authentication_login_banner}
    */
    readonly postAuthenticationLoginBanner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#pre_authentication_login_banner AwsTransferServer#pre_authentication_login_banner}
    */
    readonly preAuthenticationLoginBanner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#protocols AwsTransferServer#protocols}
    */
    readonly protocols?: string[];
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#region AwsTransferServer#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#security_policy_name AwsTransferServer#security_policy_name}
    */
    readonly securityPolicyName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#sftp_authentication_methods AwsTransferServer#sftp_authentication_methods}
    */
    readonly sftpAuthenticationMethods?: string;
    /**
    * This is a set of arns of destinations that will receive structured logs from the transfer server
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#structured_log_destinations AwsTransferServer#structured_log_destinations}
    */
    readonly structuredLogDestinations?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#tags AwsTransferServer#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#tags_all AwsTransferServer#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#url AwsTransferServer#url}
    */
    readonly url?: string;
    /**
    * endpoint_details block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#endpoint_details AwsTransferServer#endpoint_details}
    */
    readonly endpointDetails?: AwsTransferServer.EndpointDetailsProperty;
    /**
    * protocol_details block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#protocol_details AwsTransferServer#protocol_details}
    */
    readonly protocolDetails?: AwsTransferServer.ProtocolDetailsProperty;
    /**
    * s3_storage_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#s3_storage_options AwsTransferServer#s3_storage_options}
    */
    readonly s3StorageOptions?: AwsTransferServer.S3StorageOptionsProperty;
    /**
    * workflow_details block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#workflow_details AwsTransferServer#workflow_details}
    */
    readonly workflowDetails?: AwsTransferServer.WorkflowDetailsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server aws_transfer_server}
*/
export declare class AwsTransferServer extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_transfer_server";
    /**
    * Generates CDKTN code for importing a AwsTransferServer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsTransferServer to import
    * @param importFromId The id of the existing AwsTransferServer that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsTransferServer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server aws_transfer_server} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsTransferServerConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsTransferServerConfig);
    get arn(): string;
    private _certificate?;
    get certificate(): string;
    set certificate(value: string);
    resetCertificate(): void;
    get certificateInput(): string | undefined;
    private _directoryId?;
    get directoryId(): string;
    set directoryId(value: string);
    resetDirectoryId(): void;
    get directoryIdInput(): string | undefined;
    private _domain?;
    get domain(): string;
    set domain(value: string);
    resetDomain(): void;
    get domainInput(): string | undefined;
    get endpoint(): string;
    private _endpointType?;
    get endpointType(): string;
    set endpointType(value: string);
    resetEndpointType(): void;
    get endpointTypeInput(): string | undefined;
    private _forceDestroy?;
    get forceDestroy(): boolean | cdktn.IResolvable;
    set forceDestroy(value: boolean | cdktn.IResolvable);
    resetForceDestroy(): void;
    get forceDestroyInput(): boolean | cdktn.IResolvable | undefined;
    private _function?;
    get function(): string;
    set function(value: string);
    resetFunction(): void;
    get functionInput(): string | undefined;
    private _hostKey?;
    get hostKey(): string;
    set hostKey(value: string);
    resetHostKey(): void;
    get hostKeyInput(): string | undefined;
    get hostKeyFingerprint(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identityProviderType?;
    get identityProviderType(): string;
    set identityProviderType(value: string);
    resetIdentityProviderType(): void;
    get identityProviderTypeInput(): string | undefined;
    private _invocationRole?;
    get invocationRole(): string;
    set invocationRole(value: string);
    resetInvocationRole(): void;
    get invocationRoleInput(): string | undefined;
    private _ipAddressType?;
    get ipAddressType(): string;
    set ipAddressType(value: string);
    resetIpAddressType(): void;
    get ipAddressTypeInput(): string | undefined;
    private _loggingRole?;
    get loggingRole(): string;
    set loggingRole(value: string);
    resetLoggingRole(): void;
    get loggingRoleInput(): string | undefined;
    private _postAuthenticationLoginBanner?;
    get postAuthenticationLoginBanner(): string;
    set postAuthenticationLoginBanner(value: string);
    resetPostAuthenticationLoginBanner(): void;
    get postAuthenticationLoginBannerInput(): string | undefined;
    private _preAuthenticationLoginBanner?;
    get preAuthenticationLoginBanner(): string;
    set preAuthenticationLoginBanner(value: string);
    resetPreAuthenticationLoginBanner(): void;
    get preAuthenticationLoginBannerInput(): string | undefined;
    private _protocols?;
    get protocols(): string[];
    set protocols(value: string[]);
    resetProtocols(): void;
    get protocolsInput(): string[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _securityPolicyName?;
    get securityPolicyName(): string;
    set securityPolicyName(value: string);
    resetSecurityPolicyName(): void;
    get securityPolicyNameInput(): string | undefined;
    private _sftpAuthenticationMethods?;
    get sftpAuthenticationMethods(): string;
    set sftpAuthenticationMethods(value: string);
    resetSftpAuthenticationMethods(): void;
    get sftpAuthenticationMethodsInput(): string | undefined;
    private _structuredLogDestinations?;
    get structuredLogDestinations(): string[];
    set structuredLogDestinations(value: string[]);
    resetStructuredLogDestinations(): void;
    get structuredLogDestinationsInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _endpointDetails;
    get endpointDetails(): AwsTransferServer.EndpointDetailsPropertyOutputReference;
    putEndpointDetails(value: AwsTransferServer.EndpointDetailsProperty): void;
    resetEndpointDetails(): void;
    get endpointDetailsInput(): AwsTransferServer.EndpointDetailsProperty | undefined;
    private _protocolDetails;
    get protocolDetails(): AwsTransferServer.ProtocolDetailsPropertyOutputReference;
    putProtocolDetails(value: AwsTransferServer.ProtocolDetailsProperty): void;
    resetProtocolDetails(): void;
    get protocolDetailsInput(): AwsTransferServer.ProtocolDetailsProperty | undefined;
    private _s3StorageOptions;
    get s3StorageOptions(): AwsTransferServer.S3StorageOptionsPropertyOutputReference;
    putS3StorageOptions(value: AwsTransferServer.S3StorageOptionsProperty): void;
    resetS3StorageOptions(): void;
    get s3StorageOptionsInput(): AwsTransferServer.S3StorageOptionsProperty | undefined;
    private _workflowDetails;
    get workflowDetails(): AwsTransferServer.WorkflowDetailsPropertyOutputReference;
    putWorkflowDetails(value: AwsTransferServer.WorkflowDetailsProperty): void;
    resetWorkflowDetails(): void;
    get workflowDetailsInput(): AwsTransferServer.WorkflowDetailsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsTransferServerEndpointDetailsPropertyToTerraform(struct?: AwsTransferServer.EndpointDetailsPropertyOutputReference | AwsTransferServer.EndpointDetailsProperty): any;
export declare function awsTransferServerEndpointDetailsPropertyToHclTerraform(struct?: AwsTransferServer.EndpointDetailsPropertyOutputReference | AwsTransferServer.EndpointDetailsProperty): any;
export declare function awsTransferServerProtocolDetailsPropertyToTerraform(struct?: AwsTransferServer.ProtocolDetailsPropertyOutputReference | AwsTransferServer.ProtocolDetailsProperty): any;
export declare function awsTransferServerProtocolDetailsPropertyToHclTerraform(struct?: AwsTransferServer.ProtocolDetailsPropertyOutputReference | AwsTransferServer.ProtocolDetailsProperty): any;
export declare function awsTransferServerS3StorageOptionsPropertyToTerraform(struct?: AwsTransferServer.S3StorageOptionsPropertyOutputReference | AwsTransferServer.S3StorageOptionsProperty): any;
export declare function awsTransferServerS3StorageOptionsPropertyToHclTerraform(struct?: AwsTransferServer.S3StorageOptionsPropertyOutputReference | AwsTransferServer.S3StorageOptionsProperty): any;
export declare function awsTransferServerOnPartialUploadPropertyToTerraform(struct?: AwsTransferServer.OnPartialUploadPropertyOutputReference | AwsTransferServer.OnPartialUploadProperty): any;
export declare function awsTransferServerOnPartialUploadPropertyToHclTerraform(struct?: AwsTransferServer.OnPartialUploadPropertyOutputReference | AwsTransferServer.OnPartialUploadProperty): any;
export declare function awsTransferServerOnUploadPropertyToTerraform(struct?: AwsTransferServer.OnUploadPropertyOutputReference | AwsTransferServer.OnUploadProperty): any;
export declare function awsTransferServerOnUploadPropertyToHclTerraform(struct?: AwsTransferServer.OnUploadPropertyOutputReference | AwsTransferServer.OnUploadProperty): any;
export declare function awsTransferServerWorkflowDetailsPropertyToTerraform(struct?: AwsTransferServer.WorkflowDetailsPropertyOutputReference | AwsTransferServer.WorkflowDetailsProperty): any;
export declare function awsTransferServerWorkflowDetailsPropertyToHclTerraform(struct?: AwsTransferServer.WorkflowDetailsPropertyOutputReference | AwsTransferServer.WorkflowDetailsProperty): any;
export declare namespace AwsTransferServer {
    interface EndpointDetailsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#address_allocation_ids AwsTransferServer#address_allocation_ids}
        */
        readonly addressAllocationIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#security_group_ids AwsTransferServer#security_group_ids}
        */
        readonly securityGroupIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#subnet_ids AwsTransferServer#subnet_ids}
        */
        readonly subnetIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#vpc_endpoint_id AwsTransferServer#vpc_endpoint_id}
        */
        readonly vpcEndpointId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#vpc_id AwsTransferServer#vpc_id}
        */
        readonly vpcId?: string;
    }
    class EndpointDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EndpointDetailsProperty | undefined;
        set internalValue(value: EndpointDetailsProperty | undefined);
        private _addressAllocationIds?;
        get addressAllocationIds(): string[];
        set addressAllocationIds(value: string[]);
        resetAddressAllocationIds(): void;
        get addressAllocationIdsInput(): string[] | undefined;
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        resetSecurityGroupIds(): void;
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        resetSubnetIds(): void;
        get subnetIdsInput(): string[] | undefined;
        private _vpcEndpointId?;
        get vpcEndpointId(): string;
        set vpcEndpointId(value: string);
        resetVpcEndpointId(): void;
        get vpcEndpointIdInput(): string | undefined;
        private _vpcId?;
        get vpcId(): string;
        set vpcId(value: string);
        resetVpcId(): void;
        get vpcIdInput(): string | undefined;
    }
    interface ProtocolDetailsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#as2_transports AwsTransferServer#as2_transports}
        */
        readonly as2Transports?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#passive_ip AwsTransferServer#passive_ip}
        */
        readonly passiveIp?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#set_stat_option AwsTransferServer#set_stat_option}
        */
        readonly setStatOption?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#tls_session_resumption_mode AwsTransferServer#tls_session_resumption_mode}
        */
        readonly tlsSessionResumptionMode?: string;
    }
    class ProtocolDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ProtocolDetailsProperty | undefined;
        set internalValue(value: ProtocolDetailsProperty | undefined);
        private _as2Transports?;
        get as2Transports(): string[];
        set as2Transports(value: string[]);
        resetAs2Transports(): void;
        get as2TransportsInput(): string[] | undefined;
        private _passiveIp?;
        get passiveIp(): string;
        set passiveIp(value: string);
        resetPassiveIp(): void;
        get passiveIpInput(): string | undefined;
        private _setStatOption?;
        get setStatOption(): string;
        set setStatOption(value: string);
        resetSetStatOption(): void;
        get setStatOptionInput(): string | undefined;
        private _tlsSessionResumptionMode?;
        get tlsSessionResumptionMode(): string;
        set tlsSessionResumptionMode(value: string);
        resetTlsSessionResumptionMode(): void;
        get tlsSessionResumptionModeInput(): string | undefined;
    }
    interface S3StorageOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#directory_listing_optimization AwsTransferServer#directory_listing_optimization}
        */
        readonly directoryListingOptimization?: string;
    }
    class S3StorageOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3StorageOptionsProperty | undefined;
        set internalValue(value: S3StorageOptionsProperty | undefined);
        private _directoryListingOptimization?;
        get directoryListingOptimization(): string;
        set directoryListingOptimization(value: string);
        resetDirectoryListingOptimization(): void;
        get directoryListingOptimizationInput(): string | undefined;
    }
    interface OnPartialUploadProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#execution_role AwsTransferServer#execution_role}
        */
        readonly executionRole: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#workflow_id AwsTransferServer#workflow_id}
        */
        readonly workflowId: string;
    }
    class OnPartialUploadPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OnPartialUploadProperty | undefined;
        set internalValue(value: OnPartialUploadProperty | undefined);
        private _executionRole?;
        get executionRole(): string;
        set executionRole(value: string);
        get executionRoleInput(): string | undefined;
        private _workflowId?;
        get workflowId(): string;
        set workflowId(value: string);
        get workflowIdInput(): string | undefined;
    }
    interface OnUploadProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#execution_role AwsTransferServer#execution_role}
        */
        readonly executionRole: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#workflow_id AwsTransferServer#workflow_id}
        */
        readonly workflowId: string;
    }
    class OnUploadPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OnUploadProperty | undefined;
        set internalValue(value: OnUploadProperty | undefined);
        private _executionRole?;
        get executionRole(): string;
        set executionRole(value: string);
        get executionRoleInput(): string | undefined;
        private _workflowId?;
        get workflowId(): string;
        set workflowId(value: string);
        get workflowIdInput(): string | undefined;
    }
    interface WorkflowDetailsProperty {
        /**
        * on_partial_upload block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#on_partial_upload AwsTransferServer#on_partial_upload}
        */
        readonly onPartialUpload?: OnPartialUploadProperty;
        /**
        * on_upload block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#on_upload AwsTransferServer#on_upload}
        */
        readonly onUpload?: OnUploadProperty;
    }
    class WorkflowDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): WorkflowDetailsProperty | undefined;
        set internalValue(value: WorkflowDetailsProperty | undefined);
        private _onPartialUpload;
        get onPartialUpload(): OnPartialUploadPropertyOutputReference;
        putOnPartialUpload(value: OnPartialUploadProperty): void;
        resetOnPartialUpload(): void;
        get onPartialUploadInput(): OnPartialUploadProperty | undefined;
        private _onUpload;
        get onUpload(): OnUploadPropertyOutputReference;
        putOnUpload(value: OnUploadProperty): void;
        resetOnUpload(): void;
        get onUploadInput(): OnUploadProperty | undefined;
    }
}
