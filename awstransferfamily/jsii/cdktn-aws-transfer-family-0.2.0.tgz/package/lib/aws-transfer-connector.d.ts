import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfConnectorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#access_role TfConnector#access_role}
    */
    readonly accessRole: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#id TfConnector#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#logging_role TfConnector#logging_role}
    */
    readonly loggingRole?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#region TfConnector#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#security_policy_name TfConnector#security_policy_name}
    */
    readonly securityPolicyName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#tags TfConnector#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#tags_all TfConnector#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#url TfConnector#url}
    */
    readonly url?: string;
    /**
    * as2_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#as2_config TfConnector#as2_config}
    */
    readonly as2Config?: TfConnector.As2ConfigProperty;
    /**
    * egress_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#egress_config TfConnector#egress_config}
    */
    readonly egressConfig?: TfConnector.EgressConfigProperty;
    /**
    * sftp_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#sftp_config TfConnector#sftp_config}
    */
    readonly sftpConfig?: TfConnector.SftpConfigProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#timeouts TfConnector#timeouts}
    */
    readonly timeouts?: TfConnector.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector aws_transfer_connector}
*/
export declare class TfConnector extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_transfer_connector";
    /**
    * Generates CDKTN code for importing a TfConnector resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfConnector to import
    * @param importFromId The id of the existing TfConnector that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfConnector to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector aws_transfer_connector} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfConnectorConfig
    */
    constructor(scope: Construct, id: string, config: TfConnectorConfig);
    private _accessRole?;
    get accessRole(): string;
    set accessRole(value: string);
    get accessRoleInput(): string | undefined;
    get arn(): string;
    get connectorId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _loggingRole?;
    get loggingRole(): string;
    set loggingRole(value: string);
    resetLoggingRole(): void;
    get loggingRoleInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _securityPolicyName?;
    get securityPolicyName(): string;
    set securityPolicyName(value: string);
    resetSecurityPolicyName(): void;
    get securityPolicyNameInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _as2Config;
    get as2Config(): TfConnector.As2ConfigPropertyOutputReference;
    putAs2Config(value: TfConnector.As2ConfigProperty): void;
    resetAs2Config(): void;
    get as2ConfigInput(): TfConnector.As2ConfigProperty | undefined;
    private _egressConfig;
    get egressConfig(): TfConnector.EgressConfigPropertyOutputReference;
    putEgressConfig(value: TfConnector.EgressConfigProperty): void;
    resetEgressConfig(): void;
    get egressConfigInput(): TfConnector.EgressConfigProperty | undefined;
    private _sftpConfig;
    get sftpConfig(): TfConnector.SftpConfigPropertyOutputReference;
    putSftpConfig(value: TfConnector.SftpConfigProperty): void;
    resetSftpConfig(): void;
    get sftpConfigInput(): TfConnector.SftpConfigProperty | undefined;
    private _timeouts;
    get timeouts(): TfConnector.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfConnector.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfConnector.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfConnectorAs2ConfigPropertyToTerraform(struct?: TfConnector.As2ConfigPropertyOutputReference | TfConnector.As2ConfigProperty): any;
export declare function tfConnectorAs2ConfigPropertyToHclTerraform(struct?: TfConnector.As2ConfigPropertyOutputReference | TfConnector.As2ConfigProperty): any;
export declare function tfConnectorVpcLatticePropertyToTerraform(struct?: TfConnector.VpcLatticePropertyOutputReference | TfConnector.VpcLatticeProperty): any;
export declare function tfConnectorVpcLatticePropertyToHclTerraform(struct?: TfConnector.VpcLatticePropertyOutputReference | TfConnector.VpcLatticeProperty): any;
export declare function tfConnectorEgressConfigPropertyToTerraform(struct?: TfConnector.EgressConfigPropertyOutputReference | TfConnector.EgressConfigProperty): any;
export declare function tfConnectorEgressConfigPropertyToHclTerraform(struct?: TfConnector.EgressConfigPropertyOutputReference | TfConnector.EgressConfigProperty): any;
export declare function tfConnectorSftpConfigPropertyToTerraform(struct?: TfConnector.SftpConfigPropertyOutputReference | TfConnector.SftpConfigProperty): any;
export declare function tfConnectorSftpConfigPropertyToHclTerraform(struct?: TfConnector.SftpConfigPropertyOutputReference | TfConnector.SftpConfigProperty): any;
export declare function tfConnectorTimeoutsPropertyToTerraform(struct?: TfConnector.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfConnectorTimeoutsPropertyToHclTerraform(struct?: TfConnector.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfConnector {
    interface As2ConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#compression TfConnector#compression}
        */
        readonly compression: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#encryption_algorithm TfConnector#encryption_algorithm}
        */
        readonly encryptionAlgorithm: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#local_profile_id TfConnector#local_profile_id}
        */
        readonly localProfileId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#mdn_response TfConnector#mdn_response}
        */
        readonly mdnResponse: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#mdn_signing_algorithm TfConnector#mdn_signing_algorithm}
        */
        readonly mdnSigningAlgorithm?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#message_subject TfConnector#message_subject}
        */
        readonly messageSubject?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#partner_profile_id TfConnector#partner_profile_id}
        */
        readonly partnerProfileId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#signing_algorithm TfConnector#signing_algorithm}
        */
        readonly signingAlgorithm: string;
    }
    class As2ConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): As2ConfigProperty | undefined;
        set internalValue(value: As2ConfigProperty | undefined);
        private _compression?;
        get compression(): string;
        set compression(value: string);
        get compressionInput(): string | undefined;
        private _encryptionAlgorithm?;
        get encryptionAlgorithm(): string;
        set encryptionAlgorithm(value: string);
        get encryptionAlgorithmInput(): string | undefined;
        private _localProfileId?;
        get localProfileId(): string;
        set localProfileId(value: string);
        get localProfileIdInput(): string | undefined;
        private _mdnResponse?;
        get mdnResponse(): string;
        set mdnResponse(value: string);
        get mdnResponseInput(): string | undefined;
        private _mdnSigningAlgorithm?;
        get mdnSigningAlgorithm(): string;
        set mdnSigningAlgorithm(value: string);
        resetMdnSigningAlgorithm(): void;
        get mdnSigningAlgorithmInput(): string | undefined;
        private _messageSubject?;
        get messageSubject(): string;
        set messageSubject(value: string);
        resetMessageSubject(): void;
        get messageSubjectInput(): string | undefined;
        private _partnerProfileId?;
        get partnerProfileId(): string;
        set partnerProfileId(value: string);
        get partnerProfileIdInput(): string | undefined;
        private _signingAlgorithm?;
        get signingAlgorithm(): string;
        set signingAlgorithm(value: string);
        get signingAlgorithmInput(): string | undefined;
    }
    interface VpcLatticeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#port_number TfConnector#port_number}
        */
        readonly portNumber?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#resource_configuration_arn TfConnector#resource_configuration_arn}
        */
        readonly resourceConfigurationArn: string;
    }
    class VpcLatticePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcLatticeProperty | undefined;
        set internalValue(value: VpcLatticeProperty | undefined);
        private _portNumber?;
        get portNumber(): number;
        set portNumber(value: number);
        resetPortNumber(): void;
        get portNumberInput(): number | undefined;
        private _resourceConfigurationArn?;
        get resourceConfigurationArn(): string;
        set resourceConfigurationArn(value: string);
        get resourceConfigurationArnInput(): string | undefined;
    }
    interface EgressConfigProperty {
        /**
        * vpc_lattice block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#vpc_lattice TfConnector#vpc_lattice}
        */
        readonly vpcLattice?: VpcLatticeProperty;
    }
    class EgressConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EgressConfigProperty | undefined;
        set internalValue(value: EgressConfigProperty | undefined);
        private _vpcLattice;
        get vpcLattice(): VpcLatticePropertyOutputReference;
        putVpcLattice(value: VpcLatticeProperty): void;
        resetVpcLattice(): void;
        get vpcLatticeInput(): VpcLatticeProperty | undefined;
    }
    interface SftpConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#trusted_host_keys TfConnector#trusted_host_keys}
        */
        readonly trustedHostKeys?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#user_secret_id TfConnector#user_secret_id}
        */
        readonly userSecretId?: string;
    }
    class SftpConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SftpConfigProperty | undefined;
        set internalValue(value: SftpConfigProperty | undefined);
        private _trustedHostKeys?;
        get trustedHostKeys(): string[];
        set trustedHostKeys(value: string[]);
        resetTrustedHostKeys(): void;
        get trustedHostKeysInput(): string[] | undefined;
        private _userSecretId?;
        get userSecretId(): string;
        set userSecretId(value: string);
        resetUserSecretId(): void;
        get userSecretIdInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#create TfConnector#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#delete TfConnector#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_connector#update TfConnector#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
