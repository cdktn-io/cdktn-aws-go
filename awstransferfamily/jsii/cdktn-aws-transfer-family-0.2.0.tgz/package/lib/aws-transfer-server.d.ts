import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfServerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#certificate TfServer#certificate}
    */
    readonly certificate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#directory_id TfServer#directory_id}
    */
    readonly directoryId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#domain TfServer#domain}
    */
    readonly domain?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#endpoint_type TfServer#endpoint_type}
    */
    readonly endpointType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#force_destroy TfServer#force_destroy}
    */
    readonly forceDestroy?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#function TfServer#function}
    */
    readonly function?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#host_key TfServer#host_key}
    */
    readonly hostKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#id TfServer#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#identity_provider_type TfServer#identity_provider_type}
    */
    readonly identityProviderType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#invocation_role TfServer#invocation_role}
    */
    readonly invocationRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#ip_address_type TfServer#ip_address_type}
    */
    readonly ipAddressType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#logging_role TfServer#logging_role}
    */
    readonly loggingRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#post_authentication_login_banner TfServer#post_authentication_login_banner}
    */
    readonly postAuthenticationLoginBanner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#pre_authentication_login_banner TfServer#pre_authentication_login_banner}
    */
    readonly preAuthenticationLoginBanner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#protocols TfServer#protocols}
    */
    readonly protocols?: string[];
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#region TfServer#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#security_policy_name TfServer#security_policy_name}
    */
    readonly securityPolicyName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#sftp_authentication_methods TfServer#sftp_authentication_methods}
    */
    readonly sftpAuthenticationMethods?: string;
    /**
    * This is a set of arns of destinations that will receive structured logs from the transfer server
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#structured_log_destinations TfServer#structured_log_destinations}
    */
    readonly structuredLogDestinations?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#tags TfServer#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#tags_all TfServer#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#url TfServer#url}
    */
    readonly url?: string;
    /**
    * endpoint_details block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#endpoint_details TfServer#endpoint_details}
    */
    readonly endpointDetails?: TfServer.EndpointDetailsProperty;
    /**
    * protocol_details block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#protocol_details TfServer#protocol_details}
    */
    readonly protocolDetails?: TfServer.ProtocolDetailsProperty;
    /**
    * s3_storage_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#s3_storage_options TfServer#s3_storage_options}
    */
    readonly s3StorageOptions?: TfServer.S3StorageOptionsProperty;
    /**
    * workflow_details block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#workflow_details TfServer#workflow_details}
    */
    readonly workflowDetails?: TfServer.WorkflowDetailsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server aws_transfer_server}
*/
export declare class TfServer extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_transfer_server";
    /**
    * Generates CDKTN code for importing a TfServer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfServer to import
    * @param importFromId The id of the existing TfServer that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfServer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server aws_transfer_server} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfServerConfig = {}
    */
    constructor(scope: Construct, id: string, config?: TfServerConfig);
    get arn(): string;
    private _certificate?;
    get certificate(): string;
    set certificate(value: string);
    resetCertificate(): void;
    get certificateInput(): string | undefined;
    private _directoryId?;
    get directoryId(): string;
    set directoryId(value: string);
    resetDirectoryId(): void;
    get directoryIdInput(): string | undefined;
    private _domain?;
    get domain(): string;
    set domain(value: string);
    resetDomain(): void;
    get domainInput(): string | undefined;
    get endpoint(): string;
    private _endpointType?;
    get endpointType(): string;
    set endpointType(value: string);
    resetEndpointType(): void;
    get endpointTypeInput(): string | undefined;
    private _forceDestroy?;
    get forceDestroy(): boolean | cdktn.IResolvable;
    set forceDestroy(value: boolean | cdktn.IResolvable);
    resetForceDestroy(): void;
    get forceDestroyInput(): boolean | cdktn.IResolvable | undefined;
    private _function?;
    get function(): string;
    set function(value: string);
    resetFunction(): void;
    get functionInput(): string | undefined;
    private _hostKey?;
    get hostKey(): string;
    set hostKey(value: string);
    resetHostKey(): void;
    get hostKeyInput(): string | undefined;
    get hostKeyFingerprint(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identityProviderType?;
    get identityProviderType(): string;
    set identityProviderType(value: string);
    resetIdentityProviderType(): void;
    get identityProviderTypeInput(): string | undefined;
    private _invocationRole?;
    get invocationRole(): string;
    set invocationRole(value: string);
    resetInvocationRole(): void;
    get invocationRoleInput(): string | undefined;
    private _ipAddressType?;
    get ipAddressType(): string;
    set ipAddressType(value: string);
    resetIpAddressType(): void;
    get ipAddressTypeInput(): string | undefined;
    private _loggingRole?;
    get loggingRole(): string;
    set loggingRole(value: string);
    resetLoggingRole(): void;
    get loggingRoleInput(): string | undefined;
    private _postAuthenticationLoginBanner?;
    get postAuthenticationLoginBanner(): string;
    set postAuthenticationLoginBanner(value: string);
    resetPostAuthenticationLoginBanner(): void;
    get postAuthenticationLoginBannerInput(): string | undefined;
    private _preAuthenticationLoginBanner?;
    get preAuthenticationLoginBanner(): string;
    set preAuthenticationLoginBanner(value: string);
    resetPreAuthenticationLoginBanner(): void;
    get preAuthenticationLoginBannerInput(): string | undefined;
    private _protocols?;
    get protocols(): string[];
    set protocols(value: string[]);
    resetProtocols(): void;
    get protocolsInput(): string[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _securityPolicyName?;
    get securityPolicyName(): string;
    set securityPolicyName(value: string);
    resetSecurityPolicyName(): void;
    get securityPolicyNameInput(): string | undefined;
    private _sftpAuthenticationMethods?;
    get sftpAuthenticationMethods(): string;
    set sftpAuthenticationMethods(value: string);
    resetSftpAuthenticationMethods(): void;
    get sftpAuthenticationMethodsInput(): string | undefined;
    private _structuredLogDestinations?;
    get structuredLogDestinations(): string[];
    set structuredLogDestinations(value: string[]);
    resetStructuredLogDestinations(): void;
    get structuredLogDestinationsInput(): string[] | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _endpointDetails;
    get endpointDetails(): TfServer.EndpointDetailsPropertyOutputReference;
    putEndpointDetails(value: TfServer.EndpointDetailsProperty): void;
    resetEndpointDetails(): void;
    get endpointDetailsInput(): TfServer.EndpointDetailsProperty | undefined;
    private _protocolDetails;
    get protocolDetails(): TfServer.ProtocolDetailsPropertyOutputReference;
    putProtocolDetails(value: TfServer.ProtocolDetailsProperty): void;
    resetProtocolDetails(): void;
    get protocolDetailsInput(): TfServer.ProtocolDetailsProperty | undefined;
    private _s3StorageOptions;
    get s3StorageOptions(): TfServer.S3StorageOptionsPropertyOutputReference;
    putS3StorageOptions(value: TfServer.S3StorageOptionsProperty): void;
    resetS3StorageOptions(): void;
    get s3StorageOptionsInput(): TfServer.S3StorageOptionsProperty | undefined;
    private _workflowDetails;
    get workflowDetails(): TfServer.WorkflowDetailsPropertyOutputReference;
    putWorkflowDetails(value: TfServer.WorkflowDetailsProperty): void;
    resetWorkflowDetails(): void;
    get workflowDetailsInput(): TfServer.WorkflowDetailsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfServerEndpointDetailsPropertyToTerraform(struct?: TfServer.EndpointDetailsPropertyOutputReference | TfServer.EndpointDetailsProperty): any;
export declare function tfServerEndpointDetailsPropertyToHclTerraform(struct?: TfServer.EndpointDetailsPropertyOutputReference | TfServer.EndpointDetailsProperty): any;
export declare function tfServerProtocolDetailsPropertyToTerraform(struct?: TfServer.ProtocolDetailsPropertyOutputReference | TfServer.ProtocolDetailsProperty): any;
export declare function tfServerProtocolDetailsPropertyToHclTerraform(struct?: TfServer.ProtocolDetailsPropertyOutputReference | TfServer.ProtocolDetailsProperty): any;
export declare function tfServerS3StorageOptionsPropertyToTerraform(struct?: TfServer.S3StorageOptionsPropertyOutputReference | TfServer.S3StorageOptionsProperty): any;
export declare function tfServerS3StorageOptionsPropertyToHclTerraform(struct?: TfServer.S3StorageOptionsPropertyOutputReference | TfServer.S3StorageOptionsProperty): any;
export declare function tfServerOnPartialUploadPropertyToTerraform(struct?: TfServer.OnPartialUploadPropertyOutputReference | TfServer.OnPartialUploadProperty): any;
export declare function tfServerOnPartialUploadPropertyToHclTerraform(struct?: TfServer.OnPartialUploadPropertyOutputReference | TfServer.OnPartialUploadProperty): any;
export declare function tfServerOnUploadPropertyToTerraform(struct?: TfServer.OnUploadPropertyOutputReference | TfServer.OnUploadProperty): any;
export declare function tfServerOnUploadPropertyToHclTerraform(struct?: TfServer.OnUploadPropertyOutputReference | TfServer.OnUploadProperty): any;
export declare function tfServerWorkflowDetailsPropertyToTerraform(struct?: TfServer.WorkflowDetailsPropertyOutputReference | TfServer.WorkflowDetailsProperty): any;
export declare function tfServerWorkflowDetailsPropertyToHclTerraform(struct?: TfServer.WorkflowDetailsPropertyOutputReference | TfServer.WorkflowDetailsProperty): any;
export declare namespace TfServer {
    interface EndpointDetailsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#address_allocation_ids TfServer#address_allocation_ids}
        */
        readonly addressAllocationIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#security_group_ids TfServer#security_group_ids}
        */
        readonly securityGroupIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#subnet_ids TfServer#subnet_ids}
        */
        readonly subnetIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#vpc_endpoint_id TfServer#vpc_endpoint_id}
        */
        readonly vpcEndpointId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#vpc_id TfServer#vpc_id}
        */
        readonly vpcId?: string;
    }
    class EndpointDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EndpointDetailsProperty | undefined;
        set internalValue(value: EndpointDetailsProperty | undefined);
        private _addressAllocationIds?;
        get addressAllocationIds(): string[];
        set addressAllocationIds(value: string[]);
        resetAddressAllocationIds(): void;
        get addressAllocationIdsInput(): string[] | undefined;
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        resetSecurityGroupIds(): void;
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        resetSubnetIds(): void;
        get subnetIdsInput(): string[] | undefined;
        private _vpcEndpointId?;
        get vpcEndpointId(): string;
        set vpcEndpointId(value: string);
        resetVpcEndpointId(): void;
        get vpcEndpointIdInput(): string | undefined;
        private _vpcId?;
        get vpcId(): string;
        set vpcId(value: string);
        resetVpcId(): void;
        get vpcIdInput(): string | undefined;
    }
    interface ProtocolDetailsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#as2_transports TfServer#as2_transports}
        */
        readonly as2Transports?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#passive_ip TfServer#passive_ip}
        */
        readonly passiveIp?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#set_stat_option TfServer#set_stat_option}
        */
        readonly setStatOption?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#tls_session_resumption_mode TfServer#tls_session_resumption_mode}
        */
        readonly tlsSessionResumptionMode?: string;
    }
    class ProtocolDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ProtocolDetailsProperty | undefined;
        set internalValue(value: ProtocolDetailsProperty | undefined);
        private _as2Transports?;
        get as2Transports(): string[];
        set as2Transports(value: string[]);
        resetAs2Transports(): void;
        get as2TransportsInput(): string[] | undefined;
        private _passiveIp?;
        get passiveIp(): string;
        set passiveIp(value: string);
        resetPassiveIp(): void;
        get passiveIpInput(): string | undefined;
        private _setStatOption?;
        get setStatOption(): string;
        set setStatOption(value: string);
        resetSetStatOption(): void;
        get setStatOptionInput(): string | undefined;
        private _tlsSessionResumptionMode?;
        get tlsSessionResumptionMode(): string;
        set tlsSessionResumptionMode(value: string);
        resetTlsSessionResumptionMode(): void;
        get tlsSessionResumptionModeInput(): string | undefined;
    }
    interface S3StorageOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#directory_listing_optimization TfServer#directory_listing_optimization}
        */
        readonly directoryListingOptimization?: string;
    }
    class S3StorageOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3StorageOptionsProperty | undefined;
        set internalValue(value: S3StorageOptionsProperty | undefined);
        private _directoryListingOptimization?;
        get directoryListingOptimization(): string;
        set directoryListingOptimization(value: string);
        resetDirectoryListingOptimization(): void;
        get directoryListingOptimizationInput(): string | undefined;
    }
    interface OnPartialUploadProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#execution_role TfServer#execution_role}
        */
        readonly executionRole: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#workflow_id TfServer#workflow_id}
        */
        readonly workflowId: string;
    }
    class OnPartialUploadPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OnPartialUploadProperty | undefined;
        set internalValue(value: OnPartialUploadProperty | undefined);
        private _executionRole?;
        get executionRole(): string;
        set executionRole(value: string);
        get executionRoleInput(): string | undefined;
        private _workflowId?;
        get workflowId(): string;
        set workflowId(value: string);
        get workflowIdInput(): string | undefined;
    }
    interface OnUploadProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#execution_role TfServer#execution_role}
        */
        readonly executionRole: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#workflow_id TfServer#workflow_id}
        */
        readonly workflowId: string;
    }
    class OnUploadPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OnUploadProperty | undefined;
        set internalValue(value: OnUploadProperty | undefined);
        private _executionRole?;
        get executionRole(): string;
        set executionRole(value: string);
        get executionRoleInput(): string | undefined;
        private _workflowId?;
        get workflowId(): string;
        set workflowId(value: string);
        get workflowIdInput(): string | undefined;
    }
    interface WorkflowDetailsProperty {
        /**
        * on_partial_upload block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#on_partial_upload TfServer#on_partial_upload}
        */
        readonly onPartialUpload?: OnPartialUploadProperty;
        /**
        * on_upload block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/transfer_server#on_upload TfServer#on_upload}
        */
        readonly onUpload?: OnUploadProperty;
    }
    class WorkflowDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): WorkflowDetailsProperty | undefined;
        set internalValue(value: WorkflowDetailsProperty | undefined);
        private _onPartialUpload;
        get onPartialUpload(): OnPartialUploadPropertyOutputReference;
        putOnPartialUpload(value: OnPartialUploadProperty): void;
        resetOnPartialUpload(): void;
        get onPartialUploadInput(): OnPartialUploadProperty | undefined;
        private _onUpload;
        get onUpload(): OnUploadPropertyOutputReference;
        putOnUpload(value: OnUploadProperty): void;
        resetOnUpload(): void;
        get onUploadInput(): OnUploadProperty | undefined;
    }
}
