import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfGeoMatchSetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_geo_match_set#id TfGeoMatchSet#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_geo_match_set#name TfGeoMatchSet#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_geo_match_set#region TfGeoMatchSet#region}
    */
    readonly region?: string;
    /**
    * geo_match_constraint block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_geo_match_set#geo_match_constraint TfGeoMatchSet#geo_match_constraint}
    */
    readonly geoMatchConstraint?: TfGeoMatchSet.GeoMatchConstraintProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_geo_match_set aws_wafregional_geo_match_set}
*/
export declare class TfGeoMatchSet extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_wafregional_geo_match_set";
    /**
    * Generates CDKTN code for importing a TfGeoMatchSet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfGeoMatchSet to import
    * @param importFromId The id of the existing TfGeoMatchSet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_geo_match_set#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfGeoMatchSet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_geo_match_set aws_wafregional_geo_match_set} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfGeoMatchSetConfig
    */
    constructor(scope: Construct, id: string, config: TfGeoMatchSetConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _geoMatchConstraint;
    get geoMatchConstraint(): TfGeoMatchSet.GeoMatchConstraintPropertyList;
    putGeoMatchConstraint(value: TfGeoMatchSet.GeoMatchConstraintProperty[] | cdktn.IResolvable): void;
    resetGeoMatchConstraint(): void;
    get geoMatchConstraintInput(): cdktn.IResolvable | TfGeoMatchSet.GeoMatchConstraintProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfGeoMatchSetGeoMatchConstraintPropertyToTerraform(struct?: TfGeoMatchSet.GeoMatchConstraintProperty | cdktn.IResolvable): any;
export declare function tfGeoMatchSetGeoMatchConstraintPropertyToHclTerraform(struct?: TfGeoMatchSet.GeoMatchConstraintProperty | cdktn.IResolvable): any;
export declare namespace TfGeoMatchSet {
    interface GeoMatchConstraintProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_geo_match_set#type TfGeoMatchSet#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_geo_match_set#value TfGeoMatchSet#value}
        */
        readonly value: string;
    }
    class GeoMatchConstraintPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GeoMatchConstraintProperty | cdktn.IResolvable | undefined;
        set internalValue(value: GeoMatchConstraintProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class GeoMatchConstraintPropertyList extends cdktn.ComplexList {
        internalValue?: GeoMatchConstraintProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GeoMatchConstraintPropertyOutputReference;
    }
}
