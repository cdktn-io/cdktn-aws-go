import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfIpsetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_ipset#id TfIpset#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_ipset#name TfIpset#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_ipset#region TfIpset#region}
    */
    readonly region?: string;
    /**
    * ip_set_descriptor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_ipset#ip_set_descriptor TfIpset#ip_set_descriptor}
    */
    readonly ipSetDescriptor?: TfIpset.IpSetDescriptorProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_ipset aws_wafregional_ipset}
*/
export declare class TfIpset extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_wafregional_ipset";
    /**
    * Generates CDKTN code for importing a TfIpset resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfIpset to import
    * @param importFromId The id of the existing TfIpset that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_ipset#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfIpset to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_ipset aws_wafregional_ipset} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfIpsetConfig
    */
    constructor(scope: Construct, id: string, config: TfIpsetConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _ipSetDescriptor;
    get ipSetDescriptor(): TfIpset.IpSetDescriptorPropertyList;
    putIpSetDescriptor(value: TfIpset.IpSetDescriptorProperty[] | cdktn.IResolvable): void;
    resetIpSetDescriptor(): void;
    get ipSetDescriptorInput(): cdktn.IResolvable | TfIpset.IpSetDescriptorProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfIpsetIpSetDescriptorPropertyToTerraform(struct?: TfIpset.IpSetDescriptorProperty | cdktn.IResolvable): any;
export declare function tfIpsetIpSetDescriptorPropertyToHclTerraform(struct?: TfIpset.IpSetDescriptorProperty | cdktn.IResolvable): any;
export declare namespace TfIpset {
    interface IpSetDescriptorProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_ipset#type TfIpset#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_ipset#value TfIpset#value}
        */
        readonly value: string;
    }
    class IpSetDescriptorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IpSetDescriptorProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IpSetDescriptorProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class IpSetDescriptorPropertyList extends cdktn.ComplexList {
        internalValue?: IpSetDescriptorProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IpSetDescriptorPropertyOutputReference;
    }
}
