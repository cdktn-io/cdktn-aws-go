import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfSqlInjectionMatchSetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_sql_injection_match_set#id TfSqlInjectionMatchSet#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_sql_injection_match_set#name TfSqlInjectionMatchSet#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_sql_injection_match_set#region TfSqlInjectionMatchSet#region}
    */
    readonly region?: string;
    /**
    * sql_injection_match_tuple block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_sql_injection_match_set#sql_injection_match_tuple TfSqlInjectionMatchSet#sql_injection_match_tuple}
    */
    readonly sqlInjectionMatchTuple?: TfSqlInjectionMatchSet.SqlInjectionMatchTupleProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_sql_injection_match_set aws_wafregional_sql_injection_match_set}
*/
export declare class TfSqlInjectionMatchSet extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_wafregional_sql_injection_match_set";
    /**
    * Generates CDKTN code for importing a TfSqlInjectionMatchSet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfSqlInjectionMatchSet to import
    * @param importFromId The id of the existing TfSqlInjectionMatchSet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_sql_injection_match_set#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfSqlInjectionMatchSet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_sql_injection_match_set aws_wafregional_sql_injection_match_set} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfSqlInjectionMatchSetConfig
    */
    constructor(scope: Construct, id: string, config: TfSqlInjectionMatchSetConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _sqlInjectionMatchTuple;
    get sqlInjectionMatchTuple(): TfSqlInjectionMatchSet.SqlInjectionMatchTuplePropertyList;
    putSqlInjectionMatchTuple(value: TfSqlInjectionMatchSet.SqlInjectionMatchTupleProperty[] | cdktn.IResolvable): void;
    resetSqlInjectionMatchTuple(): void;
    get sqlInjectionMatchTupleInput(): cdktn.IResolvable | TfSqlInjectionMatchSet.SqlInjectionMatchTupleProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfSqlInjectionMatchSetFieldToMatchPropertyToTerraform(struct?: TfSqlInjectionMatchSet.FieldToMatchPropertyOutputReference | TfSqlInjectionMatchSet.FieldToMatchProperty): any;
export declare function tfSqlInjectionMatchSetFieldToMatchPropertyToHclTerraform(struct?: TfSqlInjectionMatchSet.FieldToMatchPropertyOutputReference | TfSqlInjectionMatchSet.FieldToMatchProperty): any;
export declare function tfSqlInjectionMatchSetSqlInjectionMatchTuplePropertyToTerraform(struct?: TfSqlInjectionMatchSet.SqlInjectionMatchTupleProperty | cdktn.IResolvable): any;
export declare function tfSqlInjectionMatchSetSqlInjectionMatchTuplePropertyToHclTerraform(struct?: TfSqlInjectionMatchSet.SqlInjectionMatchTupleProperty | cdktn.IResolvable): any;
export declare namespace TfSqlInjectionMatchSet {
    interface FieldToMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_sql_injection_match_set#data TfSqlInjectionMatchSet#data}
        */
        readonly data?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_sql_injection_match_set#type TfSqlInjectionMatchSet#type}
        */
        readonly type: string;
    }
    class FieldToMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FieldToMatchProperty | undefined;
        set internalValue(value: FieldToMatchProperty | undefined);
        private _data?;
        get data(): string;
        set data(value: string);
        resetData(): void;
        get dataInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    interface SqlInjectionMatchTupleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_sql_injection_match_set#text_transformation TfSqlInjectionMatchSet#text_transformation}
        */
        readonly textTransformation: string;
        /**
        * field_to_match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_sql_injection_match_set#field_to_match TfSqlInjectionMatchSet#field_to_match}
        */
        readonly fieldToMatch: FieldToMatchProperty;
    }
    class SqlInjectionMatchTuplePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SqlInjectionMatchTupleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SqlInjectionMatchTupleProperty | cdktn.IResolvable | undefined);
        private _textTransformation?;
        get textTransformation(): string;
        set textTransformation(value: string);
        get textTransformationInput(): string | undefined;
        private _fieldToMatch;
        get fieldToMatch(): FieldToMatchPropertyOutputReference;
        putFieldToMatch(value: FieldToMatchProperty): void;
        get fieldToMatchInput(): FieldToMatchProperty | undefined;
    }
    class SqlInjectionMatchTuplePropertyList extends cdktn.ComplexList {
        internalValue?: SqlInjectionMatchTupleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SqlInjectionMatchTuplePropertyOutputReference;
    }
}
