import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsWafregionalWebAclAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_web_acl_association#id AwsWafregionalWebAclAssociation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_web_acl_association#region AwsWafregionalWebAclAssociation#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_web_acl_association#resource_arn AwsWafregionalWebAclAssociation#resource_arn}
    */
    readonly resourceArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_web_acl_association#web_acl_id AwsWafregionalWebAclAssociation#web_acl_id}
    */
    readonly webAclId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_web_acl_association#timeouts AwsWafregionalWebAclAssociation#timeouts}
    */
    readonly timeouts?: AwsWafregionalWebAclAssociation.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_web_acl_association aws_wafregional_web_acl_association}
*/
export declare class AwsWafregionalWebAclAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_wafregional_web_acl_association";
    /**
    * Generates CDKTN code for importing a AwsWafregionalWebAclAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsWafregionalWebAclAssociation to import
    * @param importFromId The id of the existing AwsWafregionalWebAclAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_web_acl_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsWafregionalWebAclAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_web_acl_association aws_wafregional_web_acl_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsWafregionalWebAclAssociationConfig
    */
    constructor(scope: Construct, id: string, config: AwsWafregionalWebAclAssociationConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourceArn?;
    get resourceArn(): string;
    set resourceArn(value: string);
    get resourceArnInput(): string | undefined;
    private _webAclId?;
    get webAclId(): string;
    set webAclId(value: string);
    get webAclIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): AwsWafregionalWebAclAssociation.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsWafregionalWebAclAssociation.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsWafregionalWebAclAssociation.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsWafregionalWebAclAssociationTimeoutsPropertyToTerraform(struct?: AwsWafregionalWebAclAssociation.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsWafregionalWebAclAssociationTimeoutsPropertyToHclTerraform(struct?: AwsWafregionalWebAclAssociation.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsWafregionalWebAclAssociation {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_web_acl_association#create AwsWafregionalWebAclAssociation#create}
        */
        readonly create?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
    }
}
