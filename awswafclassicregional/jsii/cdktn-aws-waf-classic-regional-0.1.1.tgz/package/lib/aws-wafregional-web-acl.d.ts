import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsWafregionalWebAclConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_web_acl#id AwsWafregionalWebAcl#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_web_acl#metric_name AwsWafregionalWebAcl#metric_name}
    */
    readonly metricName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_web_acl#name AwsWafregionalWebAcl#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_web_acl#region AwsWafregionalWebAcl#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_web_acl#tags AwsWafregionalWebAcl#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_web_acl#tags_all AwsWafregionalWebAcl#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * default_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_web_acl#default_action AwsWafregionalWebAcl#default_action}
    */
    readonly defaultAction: AwsWafregionalWebAcl.DefaultActionProperty;
    /**
    * logging_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_web_acl#logging_configuration AwsWafregionalWebAcl#logging_configuration}
    */
    readonly loggingConfiguration?: AwsWafregionalWebAcl.LoggingConfigurationProperty;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_web_acl#rule AwsWafregionalWebAcl#rule}
    */
    readonly rule?: AwsWafregionalWebAcl.RuleProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_web_acl aws_wafregional_web_acl}
*/
export declare class AwsWafregionalWebAcl extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_wafregional_web_acl";
    /**
    * Generates CDKTN code for importing a AwsWafregionalWebAcl resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsWafregionalWebAcl to import
    * @param importFromId The id of the existing AwsWafregionalWebAcl that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_web_acl#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsWafregionalWebAcl to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_web_acl aws_wafregional_web_acl} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsWafregionalWebAclConfig
    */
    constructor(scope: Construct, id: string, config: AwsWafregionalWebAclConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _metricName?;
    get metricName(): string;
    set metricName(value: string);
    get metricNameInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _defaultAction;
    get defaultAction(): AwsWafregionalWebAcl.DefaultActionPropertyOutputReference;
    putDefaultAction(value: AwsWafregionalWebAcl.DefaultActionProperty): void;
    get defaultActionInput(): AwsWafregionalWebAcl.DefaultActionProperty | undefined;
    private _loggingConfiguration;
    get loggingConfiguration(): AwsWafregionalWebAcl.LoggingConfigurationPropertyOutputReference;
    putLoggingConfiguration(value: AwsWafregionalWebAcl.LoggingConfigurationProperty): void;
    resetLoggingConfiguration(): void;
    get loggingConfigurationInput(): AwsWafregionalWebAcl.LoggingConfigurationProperty | undefined;
    private _rule;
    get rule(): AwsWafregionalWebAcl.RulePropertyList;
    putRule(value: AwsWafregionalWebAcl.RuleProperty[] | cdktn.IResolvable): void;
    resetRule(): void;
    get ruleInput(): cdktn.IResolvable | AwsWafregionalWebAcl.RuleProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsWafregionalWebAclDefaultActionPropertyToTerraform(struct?: AwsWafregionalWebAcl.DefaultActionPropertyOutputReference | AwsWafregionalWebAcl.DefaultActionProperty): any;
export declare function awsWafregionalWebAclDefaultActionPropertyToHclTerraform(struct?: AwsWafregionalWebAcl.DefaultActionPropertyOutputReference | AwsWafregionalWebAcl.DefaultActionProperty): any;
export declare function awsWafregionalWebAclFieldToMatchPropertyToTerraform(struct?: AwsWafregionalWebAcl.FieldToMatchProperty | cdktn.IResolvable): any;
export declare function awsWafregionalWebAclFieldToMatchPropertyToHclTerraform(struct?: AwsWafregionalWebAcl.FieldToMatchProperty | cdktn.IResolvable): any;
export declare function awsWafregionalWebAclRedactedFieldsPropertyToTerraform(struct?: AwsWafregionalWebAcl.RedactedFieldsPropertyOutputReference | AwsWafregionalWebAcl.RedactedFieldsProperty): any;
export declare function awsWafregionalWebAclRedactedFieldsPropertyToHclTerraform(struct?: AwsWafregionalWebAcl.RedactedFieldsPropertyOutputReference | AwsWafregionalWebAcl.RedactedFieldsProperty): any;
export declare function awsWafregionalWebAclLoggingConfigurationPropertyToTerraform(struct?: AwsWafregionalWebAcl.LoggingConfigurationPropertyOutputReference | AwsWafregionalWebAcl.LoggingConfigurationProperty): any;
export declare function awsWafregionalWebAclLoggingConfigurationPropertyToHclTerraform(struct?: AwsWafregionalWebAcl.LoggingConfigurationPropertyOutputReference | AwsWafregionalWebAcl.LoggingConfigurationProperty): any;
export declare function awsWafregionalWebAclActionPropertyToTerraform(struct?: AwsWafregionalWebAcl.ActionPropertyOutputReference | AwsWafregionalWebAcl.ActionProperty): any;
export declare function awsWafregionalWebAclActionPropertyToHclTerraform(struct?: AwsWafregionalWebAcl.ActionPropertyOutputReference | AwsWafregionalWebAcl.ActionProperty): any;
export declare function awsWafregionalWebAclOverrideActionPropertyToTerraform(struct?: AwsWafregionalWebAcl.OverrideActionPropertyOutputReference | AwsWafregionalWebAcl.OverrideActionProperty): any;
export declare function awsWafregionalWebAclOverrideActionPropertyToHclTerraform(struct?: AwsWafregionalWebAcl.OverrideActionPropertyOutputReference | AwsWafregionalWebAcl.OverrideActionProperty): any;
export declare function awsWafregionalWebAclRulePropertyToTerraform(struct?: AwsWafregionalWebAcl.RuleProperty | cdktn.IResolvable): any;
export declare function awsWafregionalWebAclRulePropertyToHclTerraform(struct?: AwsWafregionalWebAcl.RuleProperty | cdktn.IResolvable): any;
export declare namespace AwsWafregionalWebAcl {
    interface DefaultActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_web_acl#type AwsWafregionalWebAcl#type}
        */
        readonly type: string;
    }
    class DefaultActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultActionProperty | undefined;
        set internalValue(value: DefaultActionProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    interface FieldToMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_web_acl#data AwsWafregionalWebAcl#data}
        */
        readonly data?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_web_acl#type AwsWafregionalWebAcl#type}
        */
        readonly type: string;
    }
    class FieldToMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FieldToMatchProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FieldToMatchProperty | cdktn.IResolvable | undefined);
        private _data?;
        get data(): string;
        set data(value: string);
        resetData(): void;
        get dataInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class FieldToMatchPropertyList extends cdktn.ComplexList {
        internalValue?: FieldToMatchProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FieldToMatchPropertyOutputReference;
    }
    interface RedactedFieldsProperty {
        /**
        * field_to_match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_web_acl#field_to_match AwsWafregionalWebAcl#field_to_match}
        */
        readonly fieldToMatch: FieldToMatchProperty[] | cdktn.IResolvable;
    }
    class RedactedFieldsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RedactedFieldsProperty | undefined;
        set internalValue(value: RedactedFieldsProperty | undefined);
        private _fieldToMatch;
        get fieldToMatch(): FieldToMatchPropertyList;
        putFieldToMatch(value: FieldToMatchProperty[] | cdktn.IResolvable): void;
        get fieldToMatchInput(): cdktn.IResolvable | FieldToMatchProperty[] | undefined;
    }
    interface LoggingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_web_acl#log_destination AwsWafregionalWebAcl#log_destination}
        */
        readonly logDestination: string;
        /**
        * redacted_fields block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_web_acl#redacted_fields AwsWafregionalWebAcl#redacted_fields}
        */
        readonly redactedFields?: RedactedFieldsProperty;
    }
    class LoggingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LoggingConfigurationProperty | undefined;
        set internalValue(value: LoggingConfigurationProperty | undefined);
        private _logDestination?;
        get logDestination(): string;
        set logDestination(value: string);
        get logDestinationInput(): string | undefined;
        private _redactedFields;
        get redactedFields(): RedactedFieldsPropertyOutputReference;
        putRedactedFields(value: RedactedFieldsProperty): void;
        resetRedactedFields(): void;
        get redactedFieldsInput(): RedactedFieldsProperty | undefined;
    }
    interface ActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_web_acl#type AwsWafregionalWebAcl#type}
        */
        readonly type: string;
    }
    class ActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ActionProperty | undefined;
        set internalValue(value: ActionProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    interface OverrideActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_web_acl#type AwsWafregionalWebAcl#type}
        */
        readonly type: string;
    }
    class OverrideActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OverrideActionProperty | undefined;
        set internalValue(value: OverrideActionProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    interface RuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_web_acl#priority AwsWafregionalWebAcl#priority}
        */
        readonly priority: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_web_acl#rule_id AwsWafregionalWebAcl#rule_id}
        */
        readonly ruleId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_web_acl#type AwsWafregionalWebAcl#type}
        */
        readonly type?: string;
        /**
        * action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_web_acl#action AwsWafregionalWebAcl#action}
        */
        readonly action?: ActionProperty;
        /**
        * override_action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_web_acl#override_action AwsWafregionalWebAcl#override_action}
        */
        readonly overrideAction?: OverrideActionProperty;
    }
    class RulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleProperty | cdktn.IResolvable | undefined);
        private _priority?;
        get priority(): number;
        set priority(value: number);
        get priorityInput(): number | undefined;
        private _ruleId?;
        get ruleId(): string;
        set ruleId(value: string);
        get ruleIdInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
        private _action;
        get action(): ActionPropertyOutputReference;
        putAction(value: ActionProperty): void;
        resetAction(): void;
        get actionInput(): ActionProperty | undefined;
        private _overrideAction;
        get overrideAction(): OverrideActionPropertyOutputReference;
        putOverrideAction(value: OverrideActionProperty): void;
        resetOverrideAction(): void;
        get overrideActionInput(): OverrideActionProperty | undefined;
    }
    class RulePropertyList extends cdktn.ComplexList {
        internalValue?: RuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulePropertyOutputReference;
    }
}
