import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsWafregionalByteMatchSetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_byte_match_set#id AwsWafregionalByteMatchSet#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_byte_match_set#name AwsWafregionalByteMatchSet#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_byte_match_set#region AwsWafregionalByteMatchSet#region}
    */
    readonly region?: string;
    /**
    * byte_match_tuples block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_byte_match_set#byte_match_tuples AwsWafregionalByteMatchSet#byte_match_tuples}
    */
    readonly byteMatchTuples?: AwsWafregionalByteMatchSet.ByteMatchTuplesProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_byte_match_set aws_wafregional_byte_match_set}
*/
export declare class AwsWafregionalByteMatchSet extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_wafregional_byte_match_set";
    /**
    * Generates CDKTN code for importing a AwsWafregionalByteMatchSet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsWafregionalByteMatchSet to import
    * @param importFromId The id of the existing AwsWafregionalByteMatchSet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_byte_match_set#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsWafregionalByteMatchSet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_byte_match_set aws_wafregional_byte_match_set} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsWafregionalByteMatchSetConfig
    */
    constructor(scope: Construct, id: string, config: AwsWafregionalByteMatchSetConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _byteMatchTuples;
    get byteMatchTuples(): AwsWafregionalByteMatchSet.ByteMatchTuplesPropertyList;
    putByteMatchTuples(value: AwsWafregionalByteMatchSet.ByteMatchTuplesProperty[] | cdktn.IResolvable): void;
    resetByteMatchTuples(): void;
    get byteMatchTuplesInput(): cdktn.IResolvable | AwsWafregionalByteMatchSet.ByteMatchTuplesProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsWafregionalByteMatchSetFieldToMatchPropertyToTerraform(struct?: AwsWafregionalByteMatchSet.FieldToMatchPropertyOutputReference | AwsWafregionalByteMatchSet.FieldToMatchProperty): any;
export declare function awsWafregionalByteMatchSetFieldToMatchPropertyToHclTerraform(struct?: AwsWafregionalByteMatchSet.FieldToMatchPropertyOutputReference | AwsWafregionalByteMatchSet.FieldToMatchProperty): any;
export declare function awsWafregionalByteMatchSetByteMatchTuplesPropertyToTerraform(struct?: AwsWafregionalByteMatchSet.ByteMatchTuplesProperty | cdktn.IResolvable): any;
export declare function awsWafregionalByteMatchSetByteMatchTuplesPropertyToHclTerraform(struct?: AwsWafregionalByteMatchSet.ByteMatchTuplesProperty | cdktn.IResolvable): any;
export declare namespace AwsWafregionalByteMatchSet {
    interface FieldToMatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_byte_match_set#data AwsWafregionalByteMatchSet#data}
        */
        readonly data?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_byte_match_set#type AwsWafregionalByteMatchSet#type}
        */
        readonly type: string;
    }
    class FieldToMatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FieldToMatchProperty | undefined;
        set internalValue(value: FieldToMatchProperty | undefined);
        private _data?;
        get data(): string;
        set data(value: string);
        resetData(): void;
        get dataInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    interface ByteMatchTuplesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_byte_match_set#positional_constraint AwsWafregionalByteMatchSet#positional_constraint}
        */
        readonly positionalConstraint: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_byte_match_set#target_string AwsWafregionalByteMatchSet#target_string}
        */
        readonly targetString?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_byte_match_set#text_transformation AwsWafregionalByteMatchSet#text_transformation}
        */
        readonly textTransformation: string;
        /**
        * field_to_match block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/wafregional_byte_match_set#field_to_match AwsWafregionalByteMatchSet#field_to_match}
        */
        readonly fieldToMatch: FieldToMatchProperty;
    }
    class ByteMatchTuplesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ByteMatchTuplesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ByteMatchTuplesProperty | cdktn.IResolvable | undefined);
        private _positionalConstraint?;
        get positionalConstraint(): string;
        set positionalConstraint(value: string);
        get positionalConstraintInput(): string | undefined;
        private _targetString?;
        get targetString(): string;
        set targetString(value: string);
        resetTargetString(): void;
        get targetStringInput(): string | undefined;
        private _textTransformation?;
        get textTransformation(): string;
        set textTransformation(value: string);
        get textTransformationInput(): string | undefined;
        private _fieldToMatch;
        get fieldToMatch(): FieldToMatchPropertyOutputReference;
        putFieldToMatch(value: FieldToMatchProperty): void;
        get fieldToMatchInput(): FieldToMatchProperty | undefined;
    }
    class ByteMatchTuplesPropertyList extends cdktn.ComplexList {
        internalValue?: ByteMatchTuplesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ByteMatchTuplesPropertyOutputReference;
    }
}
