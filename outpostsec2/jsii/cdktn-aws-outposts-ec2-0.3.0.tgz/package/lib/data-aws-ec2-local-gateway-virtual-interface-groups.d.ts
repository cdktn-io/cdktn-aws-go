import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsLocalGatewayVirtualInterfaceGroupsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_local_gateway_virtual_interface_groups#id DataAwsLocalGatewayVirtualInterfaceGroups#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_local_gateway_virtual_interface_groups#region DataAwsLocalGatewayVirtualInterfaceGroups#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_local_gateway_virtual_interface_groups#tags DataAwsLocalGatewayVirtualInterfaceGroups#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_local_gateway_virtual_interface_groups#filter DataAwsLocalGatewayVirtualInterfaceGroups#filter}
    */
    readonly filter?: DataAwsLocalGatewayVirtualInterfaceGroups.FilterProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_local_gateway_virtual_interface_groups#timeouts DataAwsLocalGatewayVirtualInterfaceGroups#timeouts}
    */
    readonly timeouts?: DataAwsLocalGatewayVirtualInterfaceGroups.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_local_gateway_virtual_interface_groups aws_ec2_local_gateway_virtual_interface_groups}
*/
export declare class DataAwsLocalGatewayVirtualInterfaceGroups extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_ec2_local_gateway_virtual_interface_groups";
    /**
    * Generates CDKTN code for importing a DataAwsLocalGatewayVirtualInterfaceGroups resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsLocalGatewayVirtualInterfaceGroups to import
    * @param importFromId The id of the existing DataAwsLocalGatewayVirtualInterfaceGroups that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_local_gateway_virtual_interface_groups#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsLocalGatewayVirtualInterfaceGroups to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_local_gateway_virtual_interface_groups aws_ec2_local_gateway_virtual_interface_groups} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsLocalGatewayVirtualInterfaceGroupsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsLocalGatewayVirtualInterfaceGroupsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ids(): string[];
    get localGatewayVirtualInterfaceIds(): string[];
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _filter;
    get filter(): DataAwsLocalGatewayVirtualInterfaceGroups.FilterPropertyList;
    putFilter(value: DataAwsLocalGatewayVirtualInterfaceGroups.FilterProperty[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataAwsLocalGatewayVirtualInterfaceGroups.FilterProperty[] | undefined;
    private _timeouts;
    get timeouts(): DataAwsLocalGatewayVirtualInterfaceGroups.TimeoutsPropertyOutputReference;
    putTimeouts(value: DataAwsLocalGatewayVirtualInterfaceGroups.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAwsLocalGatewayVirtualInterfaceGroups.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsLocalGatewayVirtualInterfaceGroupsFilterPropertyToTerraform(struct?: DataAwsLocalGatewayVirtualInterfaceGroups.FilterProperty | cdktn.IResolvable): any;
export declare function dataAwsLocalGatewayVirtualInterfaceGroupsFilterPropertyToHclTerraform(struct?: DataAwsLocalGatewayVirtualInterfaceGroups.FilterProperty | cdktn.IResolvable): any;
export declare function dataAwsLocalGatewayVirtualInterfaceGroupsTimeoutsPropertyToTerraform(struct?: DataAwsLocalGatewayVirtualInterfaceGroups.TimeoutsProperty | cdktn.IResolvable): any;
export declare function dataAwsLocalGatewayVirtualInterfaceGroupsTimeoutsPropertyToHclTerraform(struct?: DataAwsLocalGatewayVirtualInterfaceGroups.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace DataAwsLocalGatewayVirtualInterfaceGroups {
    interface FilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_local_gateway_virtual_interface_groups#name DataAwsLocalGatewayVirtualInterfaceGroups#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_local_gateway_virtual_interface_groups#values DataAwsLocalGatewayVirtualInterfaceGroups#values}
        */
        readonly values: string[];
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class FilterPropertyList extends cdktn.ComplexList {
        internalValue?: FilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ec2_local_gateway_virtual_interface_groups#read DataAwsLocalGatewayVirtualInterfaceGroups#read}
        */
        readonly read?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _read?;
        get read(): string;
        set read(value: string);
        resetRead(): void;
        get readInput(): string | undefined;
    }
}
