import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsCloudwatchEventEndpointConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_endpoint#description AwsCloudwatchEventEndpoint#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_endpoint#id AwsCloudwatchEventEndpoint#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_endpoint#name AwsCloudwatchEventEndpoint#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_endpoint#region AwsCloudwatchEventEndpoint#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_endpoint#role_arn AwsCloudwatchEventEndpoint#role_arn}
    */
    readonly roleArn?: string;
    /**
    * event_bus block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_endpoint#event_bus AwsCloudwatchEventEndpoint#event_bus}
    */
    readonly eventBus: AwsCloudwatchEventEndpoint.EventBusProperty[] | cdktn.IResolvable;
    /**
    * replication_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_endpoint#replication_config AwsCloudwatchEventEndpoint#replication_config}
    */
    readonly replicationConfig?: AwsCloudwatchEventEndpoint.ReplicationConfigProperty;
    /**
    * routing_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_endpoint#routing_config AwsCloudwatchEventEndpoint#routing_config}
    */
    readonly routingConfig: AwsCloudwatchEventEndpoint.RoutingConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_endpoint aws_cloudwatch_event_endpoint}
*/
export declare class AwsCloudwatchEventEndpoint extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudwatch_event_endpoint";
    /**
    * Generates CDKTN code for importing a AwsCloudwatchEventEndpoint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCloudwatchEventEndpoint to import
    * @param importFromId The id of the existing AwsCloudwatchEventEndpoint that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_endpoint#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCloudwatchEventEndpoint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_endpoint aws_cloudwatch_event_endpoint} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsCloudwatchEventEndpointConfig
    */
    constructor(scope: Construct, id: string, config: AwsCloudwatchEventEndpointConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get endpointUrl(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
    private _eventBus;
    get eventBus(): AwsCloudwatchEventEndpoint.EventBusPropertyList;
    putEventBus(value: AwsCloudwatchEventEndpoint.EventBusProperty[] | cdktn.IResolvable): void;
    get eventBusInput(): cdktn.IResolvable | AwsCloudwatchEventEndpoint.EventBusProperty[] | undefined;
    private _replicationConfig;
    get replicationConfig(): AwsCloudwatchEventEndpoint.ReplicationConfigPropertyOutputReference;
    putReplicationConfig(value: AwsCloudwatchEventEndpoint.ReplicationConfigProperty): void;
    resetReplicationConfig(): void;
    get replicationConfigInput(): AwsCloudwatchEventEndpoint.ReplicationConfigProperty | undefined;
    private _routingConfig;
    get routingConfig(): AwsCloudwatchEventEndpoint.RoutingConfigPropertyOutputReference;
    putRoutingConfig(value: AwsCloudwatchEventEndpoint.RoutingConfigProperty): void;
    get routingConfigInput(): AwsCloudwatchEventEndpoint.RoutingConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsCloudwatchEventEndpointEventBusPropertyToTerraform(struct?: AwsCloudwatchEventEndpoint.EventBusProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchEventEndpointEventBusPropertyToHclTerraform(struct?: AwsCloudwatchEventEndpoint.EventBusProperty | cdktn.IResolvable): any;
export declare function awsCloudwatchEventEndpointReplicationConfigPropertyToTerraform(struct?: AwsCloudwatchEventEndpoint.ReplicationConfigPropertyOutputReference | AwsCloudwatchEventEndpoint.ReplicationConfigProperty): any;
export declare function awsCloudwatchEventEndpointReplicationConfigPropertyToHclTerraform(struct?: AwsCloudwatchEventEndpoint.ReplicationConfigPropertyOutputReference | AwsCloudwatchEventEndpoint.ReplicationConfigProperty): any;
export declare function awsCloudwatchEventEndpointPrimaryPropertyToTerraform(struct?: AwsCloudwatchEventEndpoint.PrimaryPropertyOutputReference | AwsCloudwatchEventEndpoint.PrimaryProperty): any;
export declare function awsCloudwatchEventEndpointPrimaryPropertyToHclTerraform(struct?: AwsCloudwatchEventEndpoint.PrimaryPropertyOutputReference | AwsCloudwatchEventEndpoint.PrimaryProperty): any;
export declare function awsCloudwatchEventEndpointSecondaryPropertyToTerraform(struct?: AwsCloudwatchEventEndpoint.SecondaryPropertyOutputReference | AwsCloudwatchEventEndpoint.SecondaryProperty): any;
export declare function awsCloudwatchEventEndpointSecondaryPropertyToHclTerraform(struct?: AwsCloudwatchEventEndpoint.SecondaryPropertyOutputReference | AwsCloudwatchEventEndpoint.SecondaryProperty): any;
export declare function awsCloudwatchEventEndpointFailoverConfigPropertyToTerraform(struct?: AwsCloudwatchEventEndpoint.FailoverConfigPropertyOutputReference | AwsCloudwatchEventEndpoint.FailoverConfigProperty): any;
export declare function awsCloudwatchEventEndpointFailoverConfigPropertyToHclTerraform(struct?: AwsCloudwatchEventEndpoint.FailoverConfigPropertyOutputReference | AwsCloudwatchEventEndpoint.FailoverConfigProperty): any;
export declare function awsCloudwatchEventEndpointRoutingConfigPropertyToTerraform(struct?: AwsCloudwatchEventEndpoint.RoutingConfigPropertyOutputReference | AwsCloudwatchEventEndpoint.RoutingConfigProperty): any;
export declare function awsCloudwatchEventEndpointRoutingConfigPropertyToHclTerraform(struct?: AwsCloudwatchEventEndpoint.RoutingConfigPropertyOutputReference | AwsCloudwatchEventEndpoint.RoutingConfigProperty): any;
export declare namespace AwsCloudwatchEventEndpoint {
    interface EventBusProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_endpoint#event_bus_arn AwsCloudwatchEventEndpoint#event_bus_arn}
        */
        readonly eventBusArn: string;
    }
    class EventBusPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EventBusProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EventBusProperty | cdktn.IResolvable | undefined);
        private _eventBusArn?;
        get eventBusArn(): string;
        set eventBusArn(value: string);
        get eventBusArnInput(): string | undefined;
    }
    class EventBusPropertyList extends cdktn.ComplexList {
        internalValue?: EventBusProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EventBusPropertyOutputReference;
    }
    interface ReplicationConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_endpoint#state AwsCloudwatchEventEndpoint#state}
        */
        readonly state?: string;
    }
    class ReplicationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ReplicationConfigProperty | undefined;
        set internalValue(value: ReplicationConfigProperty | undefined);
        private _state?;
        get state(): string;
        set state(value: string);
        resetState(): void;
        get stateInput(): string | undefined;
    }
    interface PrimaryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_endpoint#health_check AwsCloudwatchEventEndpoint#health_check}
        */
        readonly healthCheck?: string;
    }
    class PrimaryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PrimaryProperty | undefined;
        set internalValue(value: PrimaryProperty | undefined);
        private _healthCheck?;
        get healthCheck(): string;
        set healthCheck(value: string);
        resetHealthCheck(): void;
        get healthCheckInput(): string | undefined;
    }
    interface SecondaryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_endpoint#route AwsCloudwatchEventEndpoint#route}
        */
        readonly route?: string;
    }
    class SecondaryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SecondaryProperty | undefined;
        set internalValue(value: SecondaryProperty | undefined);
        private _route?;
        get route(): string;
        set route(value: string);
        resetRoute(): void;
        get routeInput(): string | undefined;
    }
    interface FailoverConfigProperty {
        /**
        * primary block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_endpoint#primary AwsCloudwatchEventEndpoint#primary}
        */
        readonly primary: PrimaryProperty;
        /**
        * secondary block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_endpoint#secondary AwsCloudwatchEventEndpoint#secondary}
        */
        readonly secondary: SecondaryProperty;
    }
    class FailoverConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FailoverConfigProperty | undefined;
        set internalValue(value: FailoverConfigProperty | undefined);
        private _primary;
        get primary(): PrimaryPropertyOutputReference;
        putPrimary(value: PrimaryProperty): void;
        get primaryInput(): PrimaryProperty | undefined;
        private _secondary;
        get secondary(): SecondaryPropertyOutputReference;
        putSecondary(value: SecondaryProperty): void;
        get secondaryInput(): SecondaryProperty | undefined;
    }
    interface RoutingConfigProperty {
        /**
        * failover_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_endpoint#failover_config AwsCloudwatchEventEndpoint#failover_config}
        */
        readonly failoverConfig: FailoverConfigProperty;
    }
    class RoutingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RoutingConfigProperty | undefined;
        set internalValue(value: RoutingConfigProperty | undefined);
        private _failoverConfig;
        get failoverConfig(): FailoverConfigPropertyOutputReference;
        putFailoverConfig(value: FailoverConfigProperty): void;
        get failoverConfigInput(): FailoverConfigProperty | undefined;
    }
}
