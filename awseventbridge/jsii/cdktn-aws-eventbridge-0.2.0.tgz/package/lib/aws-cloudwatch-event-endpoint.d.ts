import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfEndpointConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_endpoint#description TfEndpoint#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_endpoint#id TfEndpoint#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_endpoint#name TfEndpoint#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_endpoint#region TfEndpoint#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_endpoint#role_arn TfEndpoint#role_arn}
    */
    readonly roleArn?: string;
    /**
    * event_bus block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_endpoint#event_bus TfEndpoint#event_bus}
    */
    readonly eventBus: TfEndpoint.EventBusProperty[] | cdktn.IResolvable;
    /**
    * replication_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_endpoint#replication_config TfEndpoint#replication_config}
    */
    readonly replicationConfig?: TfEndpoint.ReplicationConfigProperty;
    /**
    * routing_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_endpoint#routing_config TfEndpoint#routing_config}
    */
    readonly routingConfig: TfEndpoint.RoutingConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_endpoint aws_cloudwatch_event_endpoint}
*/
export declare class TfEndpoint extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudwatch_event_endpoint";
    /**
    * Generates CDKTN code for importing a TfEndpoint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfEndpoint to import
    * @param importFromId The id of the existing TfEndpoint that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_endpoint#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfEndpoint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_endpoint aws_cloudwatch_event_endpoint} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfEndpointConfig
    */
    constructor(scope: Construct, id: string, config: TfEndpointConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get endpointUrl(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
    private _eventBus;
    get eventBus(): TfEndpoint.EventBusPropertyList;
    putEventBus(value: TfEndpoint.EventBusProperty[] | cdktn.IResolvable): void;
    get eventBusInput(): cdktn.IResolvable | TfEndpoint.EventBusProperty[] | undefined;
    private _replicationConfig;
    get replicationConfig(): TfEndpoint.ReplicationConfigPropertyOutputReference;
    putReplicationConfig(value: TfEndpoint.ReplicationConfigProperty): void;
    resetReplicationConfig(): void;
    get replicationConfigInput(): TfEndpoint.ReplicationConfigProperty | undefined;
    private _routingConfig;
    get routingConfig(): TfEndpoint.RoutingConfigPropertyOutputReference;
    putRoutingConfig(value: TfEndpoint.RoutingConfigProperty): void;
    get routingConfigInput(): TfEndpoint.RoutingConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfEndpointEventBusPropertyToTerraform(struct?: TfEndpoint.EventBusProperty | cdktn.IResolvable): any;
export declare function tfEndpointEventBusPropertyToHclTerraform(struct?: TfEndpoint.EventBusProperty | cdktn.IResolvable): any;
export declare function tfEndpointReplicationConfigPropertyToTerraform(struct?: TfEndpoint.ReplicationConfigPropertyOutputReference | TfEndpoint.ReplicationConfigProperty): any;
export declare function tfEndpointReplicationConfigPropertyToHclTerraform(struct?: TfEndpoint.ReplicationConfigPropertyOutputReference | TfEndpoint.ReplicationConfigProperty): any;
export declare function tfEndpointPrimaryPropertyToTerraform(struct?: TfEndpoint.PrimaryPropertyOutputReference | TfEndpoint.PrimaryProperty): any;
export declare function tfEndpointPrimaryPropertyToHclTerraform(struct?: TfEndpoint.PrimaryPropertyOutputReference | TfEndpoint.PrimaryProperty): any;
export declare function tfEndpointSecondaryPropertyToTerraform(struct?: TfEndpoint.SecondaryPropertyOutputReference | TfEndpoint.SecondaryProperty): any;
export declare function tfEndpointSecondaryPropertyToHclTerraform(struct?: TfEndpoint.SecondaryPropertyOutputReference | TfEndpoint.SecondaryProperty): any;
export declare function tfEndpointFailoverConfigPropertyToTerraform(struct?: TfEndpoint.FailoverConfigPropertyOutputReference | TfEndpoint.FailoverConfigProperty): any;
export declare function tfEndpointFailoverConfigPropertyToHclTerraform(struct?: TfEndpoint.FailoverConfigPropertyOutputReference | TfEndpoint.FailoverConfigProperty): any;
export declare function tfEndpointRoutingConfigPropertyToTerraform(struct?: TfEndpoint.RoutingConfigPropertyOutputReference | TfEndpoint.RoutingConfigProperty): any;
export declare function tfEndpointRoutingConfigPropertyToHclTerraform(struct?: TfEndpoint.RoutingConfigPropertyOutputReference | TfEndpoint.RoutingConfigProperty): any;
export declare namespace TfEndpoint {
    interface EventBusProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_endpoint#event_bus_arn TfEndpoint#event_bus_arn}
        */
        readonly eventBusArn: string;
    }
    class EventBusPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EventBusProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EventBusProperty | cdktn.IResolvable | undefined);
        private _eventBusArn?;
        get eventBusArn(): string;
        set eventBusArn(value: string);
        get eventBusArnInput(): string | undefined;
    }
    class EventBusPropertyList extends cdktn.ComplexList {
        internalValue?: EventBusProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EventBusPropertyOutputReference;
    }
    interface ReplicationConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_endpoint#state TfEndpoint#state}
        */
        readonly state?: string;
    }
    class ReplicationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ReplicationConfigProperty | undefined;
        set internalValue(value: ReplicationConfigProperty | undefined);
        private _state?;
        get state(): string;
        set state(value: string);
        resetState(): void;
        get stateInput(): string | undefined;
    }
    interface PrimaryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_endpoint#health_check TfEndpoint#health_check}
        */
        readonly healthCheck?: string;
    }
    class PrimaryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PrimaryProperty | undefined;
        set internalValue(value: PrimaryProperty | undefined);
        private _healthCheck?;
        get healthCheck(): string;
        set healthCheck(value: string);
        resetHealthCheck(): void;
        get healthCheckInput(): string | undefined;
    }
    interface SecondaryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_endpoint#route TfEndpoint#route}
        */
        readonly route?: string;
    }
    class SecondaryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SecondaryProperty | undefined;
        set internalValue(value: SecondaryProperty | undefined);
        private _route?;
        get route(): string;
        set route(value: string);
        resetRoute(): void;
        get routeInput(): string | undefined;
    }
    interface FailoverConfigProperty {
        /**
        * primary block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_endpoint#primary TfEndpoint#primary}
        */
        readonly primary: PrimaryProperty;
        /**
        * secondary block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_endpoint#secondary TfEndpoint#secondary}
        */
        readonly secondary: SecondaryProperty;
    }
    class FailoverConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FailoverConfigProperty | undefined;
        set internalValue(value: FailoverConfigProperty | undefined);
        private _primary;
        get primary(): PrimaryPropertyOutputReference;
        putPrimary(value: PrimaryProperty): void;
        get primaryInput(): PrimaryProperty | undefined;
        private _secondary;
        get secondary(): SecondaryPropertyOutputReference;
        putSecondary(value: SecondaryProperty): void;
        get secondaryInput(): SecondaryProperty | undefined;
    }
    interface RoutingConfigProperty {
        /**
        * failover_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_endpoint#failover_config TfEndpoint#failover_config}
        */
        readonly failoverConfig: FailoverConfigProperty;
    }
    class RoutingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RoutingConfigProperty | undefined;
        set internalValue(value: RoutingConfigProperty | undefined);
        private _failoverConfig;
        get failoverConfig(): FailoverConfigPropertyOutputReference;
        putFailoverConfig(value: FailoverConfigProperty): void;
        get failoverConfigInput(): FailoverConfigProperty | undefined;
    }
}
