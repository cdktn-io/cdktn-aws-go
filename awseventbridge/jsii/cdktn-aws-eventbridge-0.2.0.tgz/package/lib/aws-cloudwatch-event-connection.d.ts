import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfConnectionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#authorization_type TfConnection#authorization_type}
    */
    readonly authorizationType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#description TfConnection#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#id TfConnection#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#kms_key_identifier TfConnection#kms_key_identifier}
    */
    readonly kmsKeyIdentifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#name TfConnection#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#region TfConnection#region}
    */
    readonly region?: string;
    /**
    * auth_parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#auth_parameters TfConnection#auth_parameters}
    */
    readonly authParameters: TfConnection.AuthParametersProperty;
    /**
    * invocation_connectivity_parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#invocation_connectivity_parameters TfConnection#invocation_connectivity_parameters}
    */
    readonly invocationConnectivityParameters?: TfConnection.InvocationConnectivityParametersProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection aws_cloudwatch_event_connection}
*/
export declare class TfConnection extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cloudwatch_event_connection";
    /**
    * Generates CDKTN code for importing a TfConnection resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfConnection to import
    * @param importFromId The id of the existing TfConnection that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfConnection to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection aws_cloudwatch_event_connection} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfConnectionConfig
    */
    constructor(scope: Construct, id: string, config: TfConnectionConfig);
    get arn(): string;
    private _authorizationType?;
    get authorizationType(): string;
    set authorizationType(value: string);
    get authorizationTypeInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _kmsKeyIdentifier?;
    get kmsKeyIdentifier(): string;
    set kmsKeyIdentifier(value: string);
    resetKmsKeyIdentifier(): void;
    get kmsKeyIdentifierInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get secretArn(): string;
    private _authParameters;
    get authParameters(): TfConnection.AuthParametersPropertyOutputReference;
    putAuthParameters(value: TfConnection.AuthParametersProperty): void;
    get authParametersInput(): TfConnection.AuthParametersProperty | undefined;
    private _invocationConnectivityParameters;
    get invocationConnectivityParameters(): TfConnection.InvocationConnectivityParametersPropertyOutputReference;
    putInvocationConnectivityParameters(value: TfConnection.InvocationConnectivityParametersProperty): void;
    resetInvocationConnectivityParameters(): void;
    get invocationConnectivityParametersInput(): TfConnection.InvocationConnectivityParametersProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfConnectionApiKeyPropertyToTerraform(struct?: TfConnection.ApiKeyPropertyOutputReference | TfConnection.ApiKeyProperty): any;
export declare function tfConnectionApiKeyPropertyToHclTerraform(struct?: TfConnection.ApiKeyPropertyOutputReference | TfConnection.ApiKeyProperty): any;
export declare function tfConnectionBasicPropertyToTerraform(struct?: TfConnection.BasicPropertyOutputReference | TfConnection.BasicProperty): any;
export declare function tfConnectionBasicPropertyToHclTerraform(struct?: TfConnection.BasicPropertyOutputReference | TfConnection.BasicProperty): any;
export declare function tfConnectionAuthParametersConnectivityParametersResourceParametersPropertyToTerraform(struct?: TfConnection.AuthParametersConnectivityParametersResourceParametersPropertyOutputReference | TfConnection.AuthParametersConnectivityParametersResourceParametersProperty): any;
export declare function tfConnectionAuthParametersConnectivityParametersResourceParametersPropertyToHclTerraform(struct?: TfConnection.AuthParametersConnectivityParametersResourceParametersPropertyOutputReference | TfConnection.AuthParametersConnectivityParametersResourceParametersProperty): any;
export declare function tfConnectionConnectivityParametersPropertyToTerraform(struct?: TfConnection.ConnectivityParametersPropertyOutputReference | TfConnection.ConnectivityParametersProperty): any;
export declare function tfConnectionConnectivityParametersPropertyToHclTerraform(struct?: TfConnection.ConnectivityParametersPropertyOutputReference | TfConnection.ConnectivityParametersProperty): any;
export declare function tfConnectionAuthParametersInvocationHttpParametersBodyPropertyToTerraform(struct?: TfConnection.AuthParametersInvocationHttpParametersBodyProperty | cdktn.IResolvable): any;
export declare function tfConnectionAuthParametersInvocationHttpParametersBodyPropertyToHclTerraform(struct?: TfConnection.AuthParametersInvocationHttpParametersBodyProperty | cdktn.IResolvable): any;
export declare function tfConnectionAuthParametersInvocationHttpParametersHeaderPropertyToTerraform(struct?: TfConnection.AuthParametersInvocationHttpParametersHeaderProperty | cdktn.IResolvable): any;
export declare function tfConnectionAuthParametersInvocationHttpParametersHeaderPropertyToHclTerraform(struct?: TfConnection.AuthParametersInvocationHttpParametersHeaderProperty | cdktn.IResolvable): any;
export declare function tfConnectionAuthParametersInvocationHttpParametersQueryStringPropertyToTerraform(struct?: TfConnection.AuthParametersInvocationHttpParametersQueryStringProperty | cdktn.IResolvable): any;
export declare function tfConnectionAuthParametersInvocationHttpParametersQueryStringPropertyToHclTerraform(struct?: TfConnection.AuthParametersInvocationHttpParametersQueryStringProperty | cdktn.IResolvable): any;
export declare function tfConnectionInvocationHttpParametersPropertyToTerraform(struct?: TfConnection.InvocationHttpParametersPropertyOutputReference | TfConnection.InvocationHttpParametersProperty): any;
export declare function tfConnectionInvocationHttpParametersPropertyToHclTerraform(struct?: TfConnection.InvocationHttpParametersPropertyOutputReference | TfConnection.InvocationHttpParametersProperty): any;
export declare function tfConnectionClientParametersPropertyToTerraform(struct?: TfConnection.ClientParametersPropertyOutputReference | TfConnection.ClientParametersProperty): any;
export declare function tfConnectionClientParametersPropertyToHclTerraform(struct?: TfConnection.ClientParametersPropertyOutputReference | TfConnection.ClientParametersProperty): any;
export declare function tfConnectionAuthParametersOauthOauthHttpParametersBodyPropertyToTerraform(struct?: TfConnection.AuthParametersOauthOauthHttpParametersBodyProperty | cdktn.IResolvable): any;
export declare function tfConnectionAuthParametersOauthOauthHttpParametersBodyPropertyToHclTerraform(struct?: TfConnection.AuthParametersOauthOauthHttpParametersBodyProperty | cdktn.IResolvable): any;
export declare function tfConnectionAuthParametersOauthOauthHttpParametersHeaderPropertyToTerraform(struct?: TfConnection.AuthParametersOauthOauthHttpParametersHeaderProperty | cdktn.IResolvable): any;
export declare function tfConnectionAuthParametersOauthOauthHttpParametersHeaderPropertyToHclTerraform(struct?: TfConnection.AuthParametersOauthOauthHttpParametersHeaderProperty | cdktn.IResolvable): any;
export declare function tfConnectionAuthParametersOauthOauthHttpParametersQueryStringPropertyToTerraform(struct?: TfConnection.AuthParametersOauthOauthHttpParametersQueryStringProperty | cdktn.IResolvable): any;
export declare function tfConnectionAuthParametersOauthOauthHttpParametersQueryStringPropertyToHclTerraform(struct?: TfConnection.AuthParametersOauthOauthHttpParametersQueryStringProperty | cdktn.IResolvable): any;
export declare function tfConnectionOauthHttpParametersPropertyToTerraform(struct?: TfConnection.OauthHttpParametersPropertyOutputReference | TfConnection.OauthHttpParametersProperty): any;
export declare function tfConnectionOauthHttpParametersPropertyToHclTerraform(struct?: TfConnection.OauthHttpParametersPropertyOutputReference | TfConnection.OauthHttpParametersProperty): any;
export declare function tfConnectionOauthPropertyToTerraform(struct?: TfConnection.OauthPropertyOutputReference | TfConnection.OauthProperty): any;
export declare function tfConnectionOauthPropertyToHclTerraform(struct?: TfConnection.OauthPropertyOutputReference | TfConnection.OauthProperty): any;
export declare function tfConnectionAuthParametersPropertyToTerraform(struct?: TfConnection.AuthParametersPropertyOutputReference | TfConnection.AuthParametersProperty): any;
export declare function tfConnectionAuthParametersPropertyToHclTerraform(struct?: TfConnection.AuthParametersPropertyOutputReference | TfConnection.AuthParametersProperty): any;
export declare function tfConnectionInvocationConnectivityParametersResourceParametersPropertyToTerraform(struct?: TfConnection.InvocationConnectivityParametersResourceParametersPropertyOutputReference | TfConnection.InvocationConnectivityParametersResourceParametersProperty): any;
export declare function tfConnectionInvocationConnectivityParametersResourceParametersPropertyToHclTerraform(struct?: TfConnection.InvocationConnectivityParametersResourceParametersPropertyOutputReference | TfConnection.InvocationConnectivityParametersResourceParametersProperty): any;
export declare function tfConnectionInvocationConnectivityParametersPropertyToTerraform(struct?: TfConnection.InvocationConnectivityParametersPropertyOutputReference | TfConnection.InvocationConnectivityParametersProperty): any;
export declare function tfConnectionInvocationConnectivityParametersPropertyToHclTerraform(struct?: TfConnection.InvocationConnectivityParametersPropertyOutputReference | TfConnection.InvocationConnectivityParametersProperty): any;
export declare namespace TfConnection {
    interface ApiKeyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#key TfConnection#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#value TfConnection#value}
        */
        readonly value: string;
    }
    class ApiKeyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ApiKeyProperty | undefined;
        set internalValue(value: ApiKeyProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    interface BasicProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#password TfConnection#password}
        */
        readonly password: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#username TfConnection#username}
        */
        readonly username: string;
    }
    class BasicPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BasicProperty | undefined;
        set internalValue(value: BasicProperty | undefined);
        private _password?;
        get password(): string;
        set password(value: string);
        get passwordInput(): string | undefined;
        private _username?;
        get username(): string;
        set username(value: string);
        get usernameInput(): string | undefined;
    }
    interface AuthParametersConnectivityParametersResourceParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#resource_configuration_arn TfConnection#resource_configuration_arn}
        */
        readonly resourceConfigurationArn: string;
    }
    class AuthParametersConnectivityParametersResourceParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AuthParametersConnectivityParametersResourceParametersProperty | undefined;
        set internalValue(value: AuthParametersConnectivityParametersResourceParametersProperty | undefined);
        get resourceAssociationArn(): string;
        private _resourceConfigurationArn?;
        get resourceConfigurationArn(): string;
        set resourceConfigurationArn(value: string);
        get resourceConfigurationArnInput(): string | undefined;
    }
    interface ConnectivityParametersProperty {
        /**
        * resource_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#resource_parameters TfConnection#resource_parameters}
        */
        readonly resourceParameters: AuthParametersConnectivityParametersResourceParametersProperty;
    }
    class ConnectivityParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConnectivityParametersProperty | undefined;
        set internalValue(value: ConnectivityParametersProperty | undefined);
        private _resourceParameters;
        get resourceParameters(): AuthParametersConnectivityParametersResourceParametersPropertyOutputReference;
        putResourceParameters(value: AuthParametersConnectivityParametersResourceParametersProperty): void;
        get resourceParametersInput(): AuthParametersConnectivityParametersResourceParametersProperty | undefined;
    }
    interface AuthParametersInvocationHttpParametersBodyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#is_value_secret TfConnection#is_value_secret}
        */
        readonly isValueSecret?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#key TfConnection#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#value TfConnection#value}
        */
        readonly value?: string;
    }
    class AuthParametersInvocationHttpParametersBodyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthParametersInvocationHttpParametersBodyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthParametersInvocationHttpParametersBodyProperty | cdktn.IResolvable | undefined);
        private _isValueSecret?;
        get isValueSecret(): boolean | cdktn.IResolvable;
        set isValueSecret(value: boolean | cdktn.IResolvable);
        resetIsValueSecret(): void;
        get isValueSecretInput(): boolean | cdktn.IResolvable | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
    class AuthParametersInvocationHttpParametersBodyPropertyList extends cdktn.ComplexList {
        internalValue?: AuthParametersInvocationHttpParametersBodyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthParametersInvocationHttpParametersBodyPropertyOutputReference;
    }
    interface AuthParametersInvocationHttpParametersHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#is_value_secret TfConnection#is_value_secret}
        */
        readonly isValueSecret?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#key TfConnection#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#value TfConnection#value}
        */
        readonly value?: string;
    }
    class AuthParametersInvocationHttpParametersHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthParametersInvocationHttpParametersHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthParametersInvocationHttpParametersHeaderProperty | cdktn.IResolvable | undefined);
        private _isValueSecret?;
        get isValueSecret(): boolean | cdktn.IResolvable;
        set isValueSecret(value: boolean | cdktn.IResolvable);
        resetIsValueSecret(): void;
        get isValueSecretInput(): boolean | cdktn.IResolvable | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
    class AuthParametersInvocationHttpParametersHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: AuthParametersInvocationHttpParametersHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthParametersInvocationHttpParametersHeaderPropertyOutputReference;
    }
    interface AuthParametersInvocationHttpParametersQueryStringProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#is_value_secret TfConnection#is_value_secret}
        */
        readonly isValueSecret?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#key TfConnection#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#value TfConnection#value}
        */
        readonly value?: string;
    }
    class AuthParametersInvocationHttpParametersQueryStringPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthParametersInvocationHttpParametersQueryStringProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthParametersInvocationHttpParametersQueryStringProperty | cdktn.IResolvable | undefined);
        private _isValueSecret?;
        get isValueSecret(): boolean | cdktn.IResolvable;
        set isValueSecret(value: boolean | cdktn.IResolvable);
        resetIsValueSecret(): void;
        get isValueSecretInput(): boolean | cdktn.IResolvable | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
    class AuthParametersInvocationHttpParametersQueryStringPropertyList extends cdktn.ComplexList {
        internalValue?: AuthParametersInvocationHttpParametersQueryStringProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthParametersInvocationHttpParametersQueryStringPropertyOutputReference;
    }
    interface InvocationHttpParametersProperty {
        /**
        * body block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#body TfConnection#body}
        */
        readonly body?: AuthParametersInvocationHttpParametersBodyProperty[] | cdktn.IResolvable;
        /**
        * header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#header TfConnection#header}
        */
        readonly header?: AuthParametersInvocationHttpParametersHeaderProperty[] | cdktn.IResolvable;
        /**
        * query_string block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#query_string TfConnection#query_string}
        */
        readonly queryString?: AuthParametersInvocationHttpParametersQueryStringProperty[] | cdktn.IResolvable;
    }
    class InvocationHttpParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InvocationHttpParametersProperty | undefined;
        set internalValue(value: InvocationHttpParametersProperty | undefined);
        private _body;
        get body(): AuthParametersInvocationHttpParametersBodyPropertyList;
        putBody(value: AuthParametersInvocationHttpParametersBodyProperty[] | cdktn.IResolvable): void;
        resetBody(): void;
        get bodyInput(): cdktn.IResolvable | AuthParametersInvocationHttpParametersBodyProperty[] | undefined;
        private _header;
        get header(): AuthParametersInvocationHttpParametersHeaderPropertyList;
        putHeader(value: AuthParametersInvocationHttpParametersHeaderProperty[] | cdktn.IResolvable): void;
        resetHeader(): void;
        get headerInput(): cdktn.IResolvable | AuthParametersInvocationHttpParametersHeaderProperty[] | undefined;
        private _queryString;
        get queryString(): AuthParametersInvocationHttpParametersQueryStringPropertyList;
        putQueryString(value: AuthParametersInvocationHttpParametersQueryStringProperty[] | cdktn.IResolvable): void;
        resetQueryString(): void;
        get queryStringInput(): cdktn.IResolvable | AuthParametersInvocationHttpParametersQueryStringProperty[] | undefined;
    }
    interface ClientParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#client_id TfConnection#client_id}
        */
        readonly clientId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#client_secret TfConnection#client_secret}
        */
        readonly clientSecret: string;
    }
    class ClientParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ClientParametersProperty | undefined;
        set internalValue(value: ClientParametersProperty | undefined);
        private _clientId?;
        get clientId(): string;
        set clientId(value: string);
        get clientIdInput(): string | undefined;
        private _clientSecret?;
        get clientSecret(): string;
        set clientSecret(value: string);
        get clientSecretInput(): string | undefined;
    }
    interface AuthParametersOauthOauthHttpParametersBodyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#is_value_secret TfConnection#is_value_secret}
        */
        readonly isValueSecret?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#key TfConnection#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#value TfConnection#value}
        */
        readonly value?: string;
    }
    class AuthParametersOauthOauthHttpParametersBodyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthParametersOauthOauthHttpParametersBodyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthParametersOauthOauthHttpParametersBodyProperty | cdktn.IResolvable | undefined);
        private _isValueSecret?;
        get isValueSecret(): boolean | cdktn.IResolvable;
        set isValueSecret(value: boolean | cdktn.IResolvable);
        resetIsValueSecret(): void;
        get isValueSecretInput(): boolean | cdktn.IResolvable | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
    class AuthParametersOauthOauthHttpParametersBodyPropertyList extends cdktn.ComplexList {
        internalValue?: AuthParametersOauthOauthHttpParametersBodyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthParametersOauthOauthHttpParametersBodyPropertyOutputReference;
    }
    interface AuthParametersOauthOauthHttpParametersHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#is_value_secret TfConnection#is_value_secret}
        */
        readonly isValueSecret?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#key TfConnection#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#value TfConnection#value}
        */
        readonly value?: string;
    }
    class AuthParametersOauthOauthHttpParametersHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthParametersOauthOauthHttpParametersHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthParametersOauthOauthHttpParametersHeaderProperty | cdktn.IResolvable | undefined);
        private _isValueSecret?;
        get isValueSecret(): boolean | cdktn.IResolvable;
        set isValueSecret(value: boolean | cdktn.IResolvable);
        resetIsValueSecret(): void;
        get isValueSecretInput(): boolean | cdktn.IResolvable | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
    class AuthParametersOauthOauthHttpParametersHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: AuthParametersOauthOauthHttpParametersHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthParametersOauthOauthHttpParametersHeaderPropertyOutputReference;
    }
    interface AuthParametersOauthOauthHttpParametersQueryStringProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#is_value_secret TfConnection#is_value_secret}
        */
        readonly isValueSecret?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#key TfConnection#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#value TfConnection#value}
        */
        readonly value?: string;
    }
    class AuthParametersOauthOauthHttpParametersQueryStringPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthParametersOauthOauthHttpParametersQueryStringProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AuthParametersOauthOauthHttpParametersQueryStringProperty | cdktn.IResolvable | undefined);
        private _isValueSecret?;
        get isValueSecret(): boolean | cdktn.IResolvable;
        set isValueSecret(value: boolean | cdktn.IResolvable);
        resetIsValueSecret(): void;
        get isValueSecretInput(): boolean | cdktn.IResolvable | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
    class AuthParametersOauthOauthHttpParametersQueryStringPropertyList extends cdktn.ComplexList {
        internalValue?: AuthParametersOauthOauthHttpParametersQueryStringProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthParametersOauthOauthHttpParametersQueryStringPropertyOutputReference;
    }
    interface OauthHttpParametersProperty {
        /**
        * body block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#body TfConnection#body}
        */
        readonly body?: AuthParametersOauthOauthHttpParametersBodyProperty[] | cdktn.IResolvable;
        /**
        * header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#header TfConnection#header}
        */
        readonly header?: AuthParametersOauthOauthHttpParametersHeaderProperty[] | cdktn.IResolvable;
        /**
        * query_string block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#query_string TfConnection#query_string}
        */
        readonly queryString?: AuthParametersOauthOauthHttpParametersQueryStringProperty[] | cdktn.IResolvable;
    }
    class OauthHttpParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OauthHttpParametersProperty | undefined;
        set internalValue(value: OauthHttpParametersProperty | undefined);
        private _body;
        get body(): AuthParametersOauthOauthHttpParametersBodyPropertyList;
        putBody(value: AuthParametersOauthOauthHttpParametersBodyProperty[] | cdktn.IResolvable): void;
        resetBody(): void;
        get bodyInput(): cdktn.IResolvable | AuthParametersOauthOauthHttpParametersBodyProperty[] | undefined;
        private _header;
        get header(): AuthParametersOauthOauthHttpParametersHeaderPropertyList;
        putHeader(value: AuthParametersOauthOauthHttpParametersHeaderProperty[] | cdktn.IResolvable): void;
        resetHeader(): void;
        get headerInput(): cdktn.IResolvable | AuthParametersOauthOauthHttpParametersHeaderProperty[] | undefined;
        private _queryString;
        get queryString(): AuthParametersOauthOauthHttpParametersQueryStringPropertyList;
        putQueryString(value: AuthParametersOauthOauthHttpParametersQueryStringProperty[] | cdktn.IResolvable): void;
        resetQueryString(): void;
        get queryStringInput(): cdktn.IResolvable | AuthParametersOauthOauthHttpParametersQueryStringProperty[] | undefined;
    }
    interface OauthProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#authorization_endpoint TfConnection#authorization_endpoint}
        */
        readonly authorizationEndpoint: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#http_method TfConnection#http_method}
        */
        readonly httpMethod: string;
        /**
        * client_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#client_parameters TfConnection#client_parameters}
        */
        readonly clientParameters?: ClientParametersProperty;
        /**
        * oauth_http_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#oauth_http_parameters TfConnection#oauth_http_parameters}
        */
        readonly oauthHttpParameters: OauthHttpParametersProperty;
    }
    class OauthPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OauthProperty | undefined;
        set internalValue(value: OauthProperty | undefined);
        private _authorizationEndpoint?;
        get authorizationEndpoint(): string;
        set authorizationEndpoint(value: string);
        get authorizationEndpointInput(): string | undefined;
        private _httpMethod?;
        get httpMethod(): string;
        set httpMethod(value: string);
        get httpMethodInput(): string | undefined;
        private _clientParameters;
        get clientParameters(): ClientParametersPropertyOutputReference;
        putClientParameters(value: ClientParametersProperty): void;
        resetClientParameters(): void;
        get clientParametersInput(): ClientParametersProperty | undefined;
        private _oauthHttpParameters;
        get oauthHttpParameters(): OauthHttpParametersPropertyOutputReference;
        putOauthHttpParameters(value: OauthHttpParametersProperty): void;
        get oauthHttpParametersInput(): OauthHttpParametersProperty | undefined;
    }
    interface AuthParametersProperty {
        /**
        * api_key block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#api_key TfConnection#api_key}
        */
        readonly apiKey?: ApiKeyProperty;
        /**
        * basic block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#basic TfConnection#basic}
        */
        readonly basic?: BasicProperty;
        /**
        * connectivity_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#connectivity_parameters TfConnection#connectivity_parameters}
        */
        readonly connectivityParameters?: ConnectivityParametersProperty;
        /**
        * invocation_http_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#invocation_http_parameters TfConnection#invocation_http_parameters}
        */
        readonly invocationHttpParameters?: InvocationHttpParametersProperty;
        /**
        * oauth block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#oauth TfConnection#oauth}
        */
        readonly oauth?: OauthProperty;
    }
    class AuthParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AuthParametersProperty | undefined;
        set internalValue(value: AuthParametersProperty | undefined);
        private _apiKey;
        get apiKey(): ApiKeyPropertyOutputReference;
        putApiKey(value: ApiKeyProperty): void;
        resetApiKey(): void;
        get apiKeyInput(): ApiKeyProperty | undefined;
        private _basic;
        get basic(): BasicPropertyOutputReference;
        putBasic(value: BasicProperty): void;
        resetBasic(): void;
        get basicInput(): BasicProperty | undefined;
        private _connectivityParameters;
        get connectivityParameters(): ConnectivityParametersPropertyOutputReference;
        putConnectivityParameters(value: ConnectivityParametersProperty): void;
        resetConnectivityParameters(): void;
        get connectivityParametersInput(): ConnectivityParametersProperty | undefined;
        private _invocationHttpParameters;
        get invocationHttpParameters(): InvocationHttpParametersPropertyOutputReference;
        putInvocationHttpParameters(value: InvocationHttpParametersProperty): void;
        resetInvocationHttpParameters(): void;
        get invocationHttpParametersInput(): InvocationHttpParametersProperty | undefined;
        private _oauth;
        get oauth(): OauthPropertyOutputReference;
        putOauth(value: OauthProperty): void;
        resetOauth(): void;
        get oauthInput(): OauthProperty | undefined;
    }
    interface InvocationConnectivityParametersResourceParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#resource_configuration_arn TfConnection#resource_configuration_arn}
        */
        readonly resourceConfigurationArn: string;
    }
    class InvocationConnectivityParametersResourceParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InvocationConnectivityParametersResourceParametersProperty | undefined;
        set internalValue(value: InvocationConnectivityParametersResourceParametersProperty | undefined);
        get resourceAssociationArn(): string;
        private _resourceConfigurationArn?;
        get resourceConfigurationArn(): string;
        set resourceConfigurationArn(value: string);
        get resourceConfigurationArnInput(): string | undefined;
    }
    interface InvocationConnectivityParametersProperty {
        /**
        * resource_parameters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cloudwatch_event_connection#resource_parameters TfConnection#resource_parameters}
        */
        readonly resourceParameters: InvocationConnectivityParametersResourceParametersProperty;
    }
    class InvocationConnectivityParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InvocationConnectivityParametersProperty | undefined;
        set internalValue(value: InvocationConnectivityParametersProperty | undefined);
        private _resourceParameters;
        get resourceParameters(): InvocationConnectivityParametersResourceParametersPropertyOutputReference;
        putResourceParameters(value: InvocationConnectivityParametersResourceParametersProperty): void;
        get resourceParametersInput(): InvocationConnectivityParametersResourceParametersProperty | undefined;
    }
}
