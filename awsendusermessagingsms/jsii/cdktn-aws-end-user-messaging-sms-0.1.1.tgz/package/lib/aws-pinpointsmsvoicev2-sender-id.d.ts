import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsPinpointsmsvoicev2SenderIdConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_sender_id#deletion_protection_enabled AwsPinpointsmsvoicev2SenderId#deletion_protection_enabled}
    */
    readonly deletionProtectionEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_sender_id#iso_country_code AwsPinpointsmsvoicev2SenderId#iso_country_code}
    */
    readonly isoCountryCode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_sender_id#message_types AwsPinpointsmsvoicev2SenderId#message_types}
    */
    readonly messageTypes?: string[];
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_sender_id#region AwsPinpointsmsvoicev2SenderId#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_sender_id#sender_id AwsPinpointsmsvoicev2SenderId#sender_id}
    */
    readonly senderId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_sender_id#tags AwsPinpointsmsvoicev2SenderId#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_sender_id#timeouts AwsPinpointsmsvoicev2SenderId#timeouts}
    */
    readonly timeouts?: AwsPinpointsmsvoicev2SenderId.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_sender_id aws_pinpointsmsvoicev2_sender_id}
*/
export declare class AwsPinpointsmsvoicev2SenderId extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_pinpointsmsvoicev2_sender_id";
    /**
    * Generates CDKTN code for importing a AwsPinpointsmsvoicev2SenderId resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsPinpointsmsvoicev2SenderId to import
    * @param importFromId The id of the existing AwsPinpointsmsvoicev2SenderId that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_sender_id#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsPinpointsmsvoicev2SenderId to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_sender_id aws_pinpointsmsvoicev2_sender_id} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsPinpointsmsvoicev2SenderIdConfig
    */
    constructor(scope: Construct, id: string, config: AwsPinpointsmsvoicev2SenderIdConfig);
    get arn(): string;
    private _deletionProtectionEnabled?;
    get deletionProtectionEnabled(): boolean | cdktn.IResolvable;
    set deletionProtectionEnabled(value: boolean | cdktn.IResolvable);
    resetDeletionProtectionEnabled(): void;
    get deletionProtectionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _isoCountryCode?;
    get isoCountryCode(): string;
    set isoCountryCode(value: string);
    get isoCountryCodeInput(): string | undefined;
    private _messageTypes?;
    get messageTypes(): string[];
    set messageTypes(value: string[]);
    resetMessageTypes(): void;
    get messageTypesInput(): string[] | undefined;
    get monthlyLeasingPrice(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get registered(): cdktn.IResolvable;
    get registrationId(): string;
    private _senderId?;
    get senderId(): string;
    set senderId(value: string);
    get senderIdInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _timeouts;
    get timeouts(): AwsPinpointsmsvoicev2SenderId.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsPinpointsmsvoicev2SenderId.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsPinpointsmsvoicev2SenderId.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsPinpointsmsvoicev2SenderIdTimeoutsPropertyToTerraform(struct?: AwsPinpointsmsvoicev2SenderId.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsPinpointsmsvoicev2SenderIdTimeoutsPropertyToHclTerraform(struct?: AwsPinpointsmsvoicev2SenderId.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsPinpointsmsvoicev2SenderId {
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_sender_id#create AwsPinpointsmsvoicev2SenderId#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_sender_id#delete AwsPinpointsmsvoicev2SenderId#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_sender_id#update AwsPinpointsmsvoicev2SenderId#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
