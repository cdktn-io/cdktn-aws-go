import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsPinpointsmsvoicev2EventDestinationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Name of the configuration set this event destination belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_event_destination#configuration_set_name AwsPinpointsmsvoicev2EventDestination#configuration_set_name}
    */
    readonly configurationSetName: string;
    /**
    * Whether the event destination is enabled. Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_event_destination#enabled AwsPinpointsmsvoicev2EventDestination#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Name of the event destination.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_event_destination#event_destination_name AwsPinpointsmsvoicev2EventDestination#event_destination_name}
    */
    readonly eventDestinationName: string;
    /**
    * Event types for which the destination receives records.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_event_destination#matching_event_types AwsPinpointsmsvoicev2EventDestination#matching_event_types}
    */
    readonly matchingEventTypes: string[];
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_event_destination#region AwsPinpointsmsvoicev2EventDestination#region}
    */
    readonly region?: string;
    /**
    * cloudwatch_logs_destination block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_event_destination#cloudwatch_logs_destination AwsPinpointsmsvoicev2EventDestination#cloudwatch_logs_destination}
    */
    readonly cloudwatchLogsDestination?: AwsPinpointsmsvoicev2EventDestination.CloudwatchLogsDestinationProperty[] | cdktn.IResolvable;
    /**
    * kinesis_firehose_destination block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_event_destination#kinesis_firehose_destination AwsPinpointsmsvoicev2EventDestination#kinesis_firehose_destination}
    */
    readonly kinesisFirehoseDestination?: AwsPinpointsmsvoicev2EventDestination.KinesisFirehoseDestinationProperty[] | cdktn.IResolvable;
    /**
    * sns_destination block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_event_destination#sns_destination AwsPinpointsmsvoicev2EventDestination#sns_destination}
    */
    readonly snsDestination?: AwsPinpointsmsvoicev2EventDestination.SnsDestinationProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_event_destination aws_pinpointsmsvoicev2_event_destination}
*/
export declare class AwsPinpointsmsvoicev2EventDestination extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_pinpointsmsvoicev2_event_destination";
    /**
    * Generates CDKTN code for importing a AwsPinpointsmsvoicev2EventDestination resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsPinpointsmsvoicev2EventDestination to import
    * @param importFromId The id of the existing AwsPinpointsmsvoicev2EventDestination that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_event_destination#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsPinpointsmsvoicev2EventDestination to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_event_destination aws_pinpointsmsvoicev2_event_destination} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsPinpointsmsvoicev2EventDestinationConfig
    */
    constructor(scope: Construct, id: string, config: AwsPinpointsmsvoicev2EventDestinationConfig);
    get configurationSetArn(): string;
    private _configurationSetName?;
    get configurationSetName(): string;
    set configurationSetName(value: string);
    get configurationSetNameInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _eventDestinationName?;
    get eventDestinationName(): string;
    set eventDestinationName(value: string);
    get eventDestinationNameInput(): string | undefined;
    private _matchingEventTypes?;
    get matchingEventTypes(): string[];
    set matchingEventTypes(value: string[]);
    get matchingEventTypesInput(): string[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _cloudwatchLogsDestination;
    get cloudwatchLogsDestination(): AwsPinpointsmsvoicev2EventDestination.CloudwatchLogsDestinationPropertyList;
    putCloudwatchLogsDestination(value: AwsPinpointsmsvoicev2EventDestination.CloudwatchLogsDestinationProperty[] | cdktn.IResolvable): void;
    resetCloudwatchLogsDestination(): void;
    get cloudwatchLogsDestinationInput(): cdktn.IResolvable | AwsPinpointsmsvoicev2EventDestination.CloudwatchLogsDestinationProperty[] | undefined;
    private _kinesisFirehoseDestination;
    get kinesisFirehoseDestination(): AwsPinpointsmsvoicev2EventDestination.KinesisFirehoseDestinationPropertyList;
    putKinesisFirehoseDestination(value: AwsPinpointsmsvoicev2EventDestination.KinesisFirehoseDestinationProperty[] | cdktn.IResolvable): void;
    resetKinesisFirehoseDestination(): void;
    get kinesisFirehoseDestinationInput(): cdktn.IResolvable | AwsPinpointsmsvoicev2EventDestination.KinesisFirehoseDestinationProperty[] | undefined;
    private _snsDestination;
    get snsDestination(): AwsPinpointsmsvoicev2EventDestination.SnsDestinationPropertyList;
    putSnsDestination(value: AwsPinpointsmsvoicev2EventDestination.SnsDestinationProperty[] | cdktn.IResolvable): void;
    resetSnsDestination(): void;
    get snsDestinationInput(): cdktn.IResolvable | AwsPinpointsmsvoicev2EventDestination.SnsDestinationProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsPinpointsmsvoicev2EventDestinationCloudwatchLogsDestinationPropertyToTerraform(struct?: AwsPinpointsmsvoicev2EventDestination.CloudwatchLogsDestinationProperty | cdktn.IResolvable): any;
export declare function awsPinpointsmsvoicev2EventDestinationCloudwatchLogsDestinationPropertyToHclTerraform(struct?: AwsPinpointsmsvoicev2EventDestination.CloudwatchLogsDestinationProperty | cdktn.IResolvable): any;
export declare function awsPinpointsmsvoicev2EventDestinationKinesisFirehoseDestinationPropertyToTerraform(struct?: AwsPinpointsmsvoicev2EventDestination.KinesisFirehoseDestinationProperty | cdktn.IResolvable): any;
export declare function awsPinpointsmsvoicev2EventDestinationKinesisFirehoseDestinationPropertyToHclTerraform(struct?: AwsPinpointsmsvoicev2EventDestination.KinesisFirehoseDestinationProperty | cdktn.IResolvable): any;
export declare function awsPinpointsmsvoicev2EventDestinationSnsDestinationPropertyToTerraform(struct?: AwsPinpointsmsvoicev2EventDestination.SnsDestinationProperty | cdktn.IResolvable): any;
export declare function awsPinpointsmsvoicev2EventDestinationSnsDestinationPropertyToHclTerraform(struct?: AwsPinpointsmsvoicev2EventDestination.SnsDestinationProperty | cdktn.IResolvable): any;
export declare namespace AwsPinpointsmsvoicev2EventDestination {
    interface CloudwatchLogsDestinationProperty {
        /**
        * ARN of the IAM role that End User Messaging SMS assumes to write to the log group.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_event_destination#iam_role_arn AwsPinpointsmsvoicev2EventDestination#iam_role_arn}
        */
        readonly iamRoleArn: string;
        /**
        * ARN of the Amazon CloudWatch log group that receives the events.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_event_destination#log_group_arn AwsPinpointsmsvoicev2EventDestination#log_group_arn}
        */
        readonly logGroupArn: string;
    }
    class CloudwatchLogsDestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CloudwatchLogsDestinationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CloudwatchLogsDestinationProperty | cdktn.IResolvable | undefined);
        private _iamRoleArn?;
        get iamRoleArn(): string;
        set iamRoleArn(value: string);
        get iamRoleArnInput(): string | undefined;
        private _logGroupArn?;
        get logGroupArn(): string;
        set logGroupArn(value: string);
        get logGroupArnInput(): string | undefined;
    }
    class CloudwatchLogsDestinationPropertyList extends cdktn.ComplexList {
        internalValue?: CloudwatchLogsDestinationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CloudwatchLogsDestinationPropertyOutputReference;
    }
    interface KinesisFirehoseDestinationProperty {
        /**
        * ARN of the Amazon Data Firehose delivery stream that receives the events.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_event_destination#delivery_stream_arn AwsPinpointsmsvoicev2EventDestination#delivery_stream_arn}
        */
        readonly deliveryStreamArn: string;
        /**
        * ARN of the IAM role that End User Messaging SMS assumes to write to the delivery stream.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_event_destination#iam_role_arn AwsPinpointsmsvoicev2EventDestination#iam_role_arn}
        */
        readonly iamRoleArn: string;
    }
    class KinesisFirehoseDestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KinesisFirehoseDestinationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KinesisFirehoseDestinationProperty | cdktn.IResolvable | undefined);
        private _deliveryStreamArn?;
        get deliveryStreamArn(): string;
        set deliveryStreamArn(value: string);
        get deliveryStreamArnInput(): string | undefined;
        private _iamRoleArn?;
        get iamRoleArn(): string;
        set iamRoleArn(value: string);
        get iamRoleArnInput(): string | undefined;
    }
    class KinesisFirehoseDestinationPropertyList extends cdktn.ComplexList {
        internalValue?: KinesisFirehoseDestinationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KinesisFirehoseDestinationPropertyOutputReference;
    }
    interface SnsDestinationProperty {
        /**
        * ARN of the Amazon SNS topic that receives the events.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_event_destination#topic_arn AwsPinpointsmsvoicev2EventDestination#topic_arn}
        */
        readonly topicArn: string;
    }
    class SnsDestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SnsDestinationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SnsDestinationProperty | cdktn.IResolvable | undefined);
        private _topicArn?;
        get topicArn(): string;
        set topicArn(value: string);
        get topicArnInput(): string | undefined;
    }
    class SnsDestinationPropertyList extends cdktn.ComplexList {
        internalValue?: SnsDestinationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SnsDestinationPropertyOutputReference;
    }
}
