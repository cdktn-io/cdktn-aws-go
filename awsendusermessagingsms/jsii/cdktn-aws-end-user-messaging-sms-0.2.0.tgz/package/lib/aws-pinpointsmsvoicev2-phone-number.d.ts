import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfPhoneNumberConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_phone_number#deletion_protection_enabled TfPhoneNumber#deletion_protection_enabled}
    */
    readonly deletionProtectionEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_phone_number#force_disassociate TfPhoneNumber#force_disassociate}
    */
    readonly forceDisassociate?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_phone_number#iso_country_code TfPhoneNumber#iso_country_code}
    */
    readonly isoCountryCode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_phone_number#message_type TfPhoneNumber#message_type}
    */
    readonly messageType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_phone_number#number_capabilities TfPhoneNumber#number_capabilities}
    */
    readonly numberCapabilities: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_phone_number#number_type TfPhoneNumber#number_type}
    */
    readonly numberType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_phone_number#opt_out_list_name TfPhoneNumber#opt_out_list_name}
    */
    readonly optOutListName?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_phone_number#region TfPhoneNumber#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_phone_number#registration_id TfPhoneNumber#registration_id}
    */
    readonly registrationId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_phone_number#self_managed_opt_outs_enabled TfPhoneNumber#self_managed_opt_outs_enabled}
    */
    readonly selfManagedOptOutsEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_phone_number#tags TfPhoneNumber#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_phone_number#two_way_channel_arn TfPhoneNumber#two_way_channel_arn}
    */
    readonly twoWayChannelArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_phone_number#two_way_channel_enabled TfPhoneNumber#two_way_channel_enabled}
    */
    readonly twoWayChannelEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_phone_number#two_way_channel_role TfPhoneNumber#two_way_channel_role}
    */
    readonly twoWayChannelRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_phone_number#wait_for_active TfPhoneNumber#wait_for_active}
    */
    readonly waitForActive?: boolean | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_phone_number#timeouts TfPhoneNumber#timeouts}
    */
    readonly timeouts?: TfPhoneNumber.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_phone_number aws_pinpointsmsvoicev2_phone_number}
*/
export declare class TfPhoneNumber extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_pinpointsmsvoicev2_phone_number";
    /**
    * Generates CDKTN code for importing a TfPhoneNumber resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfPhoneNumber to import
    * @param importFromId The id of the existing TfPhoneNumber that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_phone_number#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfPhoneNumber to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_phone_number aws_pinpointsmsvoicev2_phone_number} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfPhoneNumberConfig
    */
    constructor(scope: Construct, id: string, config: TfPhoneNumberConfig);
    get arn(): string;
    private _deletionProtectionEnabled?;
    get deletionProtectionEnabled(): boolean | cdktn.IResolvable;
    set deletionProtectionEnabled(value: boolean | cdktn.IResolvable);
    resetDeletionProtectionEnabled(): void;
    get deletionProtectionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _forceDisassociate?;
    get forceDisassociate(): boolean | cdktn.IResolvable;
    set forceDisassociate(value: boolean | cdktn.IResolvable);
    resetForceDisassociate(): void;
    get forceDisassociateInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    private _isoCountryCode?;
    get isoCountryCode(): string;
    set isoCountryCode(value: string);
    get isoCountryCodeInput(): string | undefined;
    private _messageType?;
    get messageType(): string;
    set messageType(value: string);
    get messageTypeInput(): string | undefined;
    get monthlyLeasingPrice(): string;
    private _numberCapabilities?;
    get numberCapabilities(): string[];
    set numberCapabilities(value: string[]);
    get numberCapabilitiesInput(): string[] | undefined;
    private _numberType?;
    get numberType(): string;
    set numberType(value: string);
    get numberTypeInput(): string | undefined;
    private _optOutListName?;
    get optOutListName(): string;
    set optOutListName(value: string);
    resetOptOutListName(): void;
    get optOutListNameInput(): string | undefined;
    get phoneNumber(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _registrationId?;
    get registrationId(): string;
    set registrationId(value: string);
    resetRegistrationId(): void;
    get registrationIdInput(): string | undefined;
    private _selfManagedOptOutsEnabled?;
    get selfManagedOptOutsEnabled(): boolean | cdktn.IResolvable;
    set selfManagedOptOutsEnabled(value: boolean | cdktn.IResolvable);
    resetSelfManagedOptOutsEnabled(): void;
    get selfManagedOptOutsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _twoWayChannelArn?;
    get twoWayChannelArn(): string;
    set twoWayChannelArn(value: string);
    resetTwoWayChannelArn(): void;
    get twoWayChannelArnInput(): string | undefined;
    private _twoWayChannelEnabled?;
    get twoWayChannelEnabled(): boolean | cdktn.IResolvable;
    set twoWayChannelEnabled(value: boolean | cdktn.IResolvable);
    resetTwoWayChannelEnabled(): void;
    get twoWayChannelEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _twoWayChannelRole?;
    get twoWayChannelRole(): string;
    set twoWayChannelRole(value: string);
    resetTwoWayChannelRole(): void;
    get twoWayChannelRoleInput(): string | undefined;
    private _waitForActive?;
    get waitForActive(): boolean | cdktn.IResolvable;
    set waitForActive(value: boolean | cdktn.IResolvable);
    resetWaitForActive(): void;
    get waitForActiveInput(): boolean | cdktn.IResolvable | undefined;
    private _timeouts;
    get timeouts(): TfPhoneNumber.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfPhoneNumber.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfPhoneNumber.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfPhoneNumberTimeoutsPropertyToTerraform(struct?: TfPhoneNumber.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfPhoneNumberTimeoutsPropertyToHclTerraform(struct?: TfPhoneNumber.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfPhoneNumber {
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_phone_number#create TfPhoneNumber#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_phone_number#delete TfPhoneNumber#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_phone_number#update TfPhoneNumber#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
