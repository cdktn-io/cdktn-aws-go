import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfKeywordConfig extends cdktn.TerraformMetaArguments {
    /**
    * Keyword to configure. 1-30 characters, upper-case, and cannot start or end with a space.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_keyword#keyword TfKeyword#keyword}
    */
    readonly keyword: string;
    /**
    * Action to perform when the keyword is received.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_keyword#keyword_action TfKeyword#keyword_action}
    */
    readonly keywordAction?: string;
    /**
    * Message to send when the keyword is received.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_keyword#keyword_message TfKeyword#keyword_message}
    */
    readonly keywordMessage: string;
    /**
    * ARN of the origination identity (phone number or pool) to attach the keyword to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_keyword#origination_identity_arn TfKeyword#origination_identity_arn}
    */
    readonly originationIdentityArn: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_keyword#region TfKeyword#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_keyword aws_pinpointsmsvoicev2_keyword}
*/
export declare class TfKeyword extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_pinpointsmsvoicev2_keyword";
    /**
    * Generates CDKTN code for importing a TfKeyword resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfKeyword to import
    * @param importFromId The id of the existing TfKeyword that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_keyword#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfKeyword to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpointsmsvoicev2_keyword aws_pinpointsmsvoicev2_keyword} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfKeywordConfig
    */
    constructor(scope: Construct, id: string, config: TfKeywordConfig);
    private _keyword?;
    get keyword(): string;
    set keyword(value: string);
    get keywordInput(): string | undefined;
    private _keywordAction?;
    get keywordAction(): string;
    set keywordAction(value: string);
    resetKeywordAction(): void;
    get keywordActionInput(): string | undefined;
    private _keywordMessage?;
    get keywordMessage(): string;
    set keywordMessage(value: string);
    get keywordMessageInput(): string | undefined;
    private _originationIdentityArn?;
    get originationIdentityArn(): string;
    set originationIdentityArn(value: string);
    get originationIdentityArnInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
