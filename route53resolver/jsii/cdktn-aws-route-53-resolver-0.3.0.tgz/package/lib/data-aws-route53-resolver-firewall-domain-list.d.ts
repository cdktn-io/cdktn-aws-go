import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsResolverFirewallDomainListConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_resolver_firewall_domain_list#firewall_domain_list_id DataAwsResolverFirewallDomainList#firewall_domain_list_id}
    */
    readonly firewallDomainListId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_resolver_firewall_domain_list#id DataAwsResolverFirewallDomainList#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_resolver_firewall_domain_list#region DataAwsResolverFirewallDomainList#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_resolver_firewall_domain_list aws_route53_resolver_firewall_domain_list}
*/
export declare class DataAwsResolverFirewallDomainList extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_route53_resolver_firewall_domain_list";
    /**
    * Generates CDKTN code for importing a DataAwsResolverFirewallDomainList resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsResolverFirewallDomainList to import
    * @param importFromId The id of the existing DataAwsResolverFirewallDomainList that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_resolver_firewall_domain_list#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsResolverFirewallDomainList to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_resolver_firewall_domain_list aws_route53_resolver_firewall_domain_list} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsResolverFirewallDomainListConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsResolverFirewallDomainListConfig);
    get arn(): string;
    get creationTime(): string;
    get creatorRequestId(): string;
    get domainCount(): number;
    private _firewallDomainListId?;
    get firewallDomainListId(): string;
    set firewallDomainListId(value: string);
    get firewallDomainListIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get managedOwnerName(): string;
    get modificationTime(): string;
    get name(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    get statusMessage(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
