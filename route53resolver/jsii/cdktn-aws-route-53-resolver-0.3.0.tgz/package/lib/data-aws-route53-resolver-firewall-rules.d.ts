import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsResolverFirewallRulesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_resolver_firewall_rules#action DataAwsResolverFirewallRules#action}
    */
    readonly action?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_resolver_firewall_rules#firewall_rule_group_id DataAwsResolverFirewallRules#firewall_rule_group_id}
    */
    readonly firewallRuleGroupId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_resolver_firewall_rules#id DataAwsResolverFirewallRules#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_resolver_firewall_rules#priority DataAwsResolverFirewallRules#priority}
    */
    readonly priority?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_resolver_firewall_rules#region DataAwsResolverFirewallRules#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_resolver_firewall_rules aws_route53_resolver_firewall_rules}
*/
export declare class DataAwsResolverFirewallRules extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_route53_resolver_firewall_rules";
    /**
    * Generates CDKTN code for importing a DataAwsResolverFirewallRules resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsResolverFirewallRules to import
    * @param importFromId The id of the existing DataAwsResolverFirewallRules that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_resolver_firewall_rules#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsResolverFirewallRules to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_resolver_firewall_rules aws_route53_resolver_firewall_rules} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsResolverFirewallRulesConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsResolverFirewallRulesConfig);
    private _action?;
    get action(): string;
    set action(value: string);
    resetAction(): void;
    get actionInput(): string | undefined;
    private _firewallRuleGroupId?;
    get firewallRuleGroupId(): string;
    set firewallRuleGroupId(value: string);
    get firewallRuleGroupIdInput(): string | undefined;
    private _firewallRules;
    get firewallRules(): DataAwsResolverFirewallRules.FirewallRulesPropertyList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    resetPriority(): void;
    get priorityInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsResolverFirewallRulesFirewallRulesPropertyToTerraform(struct?: DataAwsResolverFirewallRules.FirewallRulesProperty): any;
export declare function dataAwsResolverFirewallRulesFirewallRulesPropertyToHclTerraform(struct?: DataAwsResolverFirewallRules.FirewallRulesProperty): any;
export declare namespace DataAwsResolverFirewallRules {
    interface FirewallRulesProperty {
    }
    class FirewallRulesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FirewallRulesProperty | undefined;
        set internalValue(value: FirewallRulesProperty | undefined);
        get action(): string;
        get blockOverrideDnsType(): string;
        get blockOverrideDomain(): string;
        get blockOverrideTtl(): number;
        get blockResponse(): string;
        get confidenceThreshold(): string;
        get creationTime(): string;
        get creatorRequestId(): string;
        get dnsThreatProtection(): string;
        get firewallDomainListId(): string;
        get firewallDomainRedirectionAction(): string;
        get firewallRuleGroupId(): string;
        get firewallThreatProtectionId(): string;
        get modificationTime(): string;
        get name(): string;
        get priority(): number;
        get qType(): string;
    }
    class FirewallRulesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FirewallRulesPropertyOutputReference;
    }
}
