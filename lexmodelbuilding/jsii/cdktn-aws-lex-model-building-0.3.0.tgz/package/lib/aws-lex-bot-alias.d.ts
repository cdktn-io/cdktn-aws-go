import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsBotAliasConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot_alias#bot_name AwsBotAlias#bot_name}
    */
    readonly botName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot_alias#bot_version AwsBotAlias#bot_version}
    */
    readonly botVersion: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot_alias#description AwsBotAlias#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot_alias#id AwsBotAlias#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot_alias#name AwsBotAlias#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot_alias#region AwsBotAlias#region}
    */
    readonly region?: string;
    /**
    * conversation_logs block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot_alias#conversation_logs AwsBotAlias#conversation_logs}
    */
    readonly conversationLogs?: AwsBotAlias.ConversationLogsProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot_alias#timeouts AwsBotAlias#timeouts}
    */
    readonly timeouts?: AwsBotAlias.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot_alias aws_lex_bot_alias}
*/
export declare class AwsBotAlias extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lex_bot_alias";
    /**
    * Generates CDKTN code for importing a AwsBotAlias resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsBotAlias to import
    * @param importFromId The id of the existing AwsBotAlias that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot_alias#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsBotAlias to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot_alias aws_lex_bot_alias} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsBotAliasConfig
    */
    constructor(scope: Construct, id: string, config: AwsBotAliasConfig);
    get arn(): string;
    private _botName?;
    get botName(): string;
    set botName(value: string);
    get botNameInput(): string | undefined;
    private _botVersion?;
    get botVersion(): string;
    set botVersion(value: string);
    get botVersionInput(): string | undefined;
    get checksum(): string;
    get createdDate(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastUpdatedDate(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _conversationLogs;
    get conversationLogs(): AwsBotAlias.ConversationLogsPropertyOutputReference;
    putConversationLogs(value: AwsBotAlias.ConversationLogsProperty): void;
    resetConversationLogs(): void;
    get conversationLogsInput(): AwsBotAlias.ConversationLogsProperty | undefined;
    private _timeouts;
    get timeouts(): AwsBotAlias.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsBotAlias.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): AwsBotAlias.TimeoutsProperty | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsBotAliasLogSettingsPropertyToTerraform(struct?: AwsBotAlias.LogSettingsProperty | cdktn.IResolvable): any;
export declare function awsBotAliasLogSettingsPropertyToHclTerraform(struct?: AwsBotAlias.LogSettingsProperty | cdktn.IResolvable): any;
export declare function awsBotAliasConversationLogsPropertyToTerraform(struct?: AwsBotAlias.ConversationLogsPropertyOutputReference | AwsBotAlias.ConversationLogsProperty): any;
export declare function awsBotAliasConversationLogsPropertyToHclTerraform(struct?: AwsBotAlias.ConversationLogsPropertyOutputReference | AwsBotAlias.ConversationLogsProperty): any;
export declare function awsBotAliasTimeoutsPropertyToTerraform(struct?: AwsBotAlias.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsBotAliasTimeoutsPropertyToHclTerraform(struct?: AwsBotAlias.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsBotAlias {
    interface LogSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot_alias#destination AwsBotAlias#destination}
        */
        readonly destination: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot_alias#kms_key_arn AwsBotAlias#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot_alias#log_type AwsBotAlias#log_type}
        */
        readonly logType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot_alias#resource_arn AwsBotAlias#resource_arn}
        */
        readonly resourceArn: string;
    }
    class LogSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LogSettingsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LogSettingsProperty | cdktn.IResolvable | undefined);
        private _destination?;
        get destination(): string;
        set destination(value: string);
        get destinationInput(): string | undefined;
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
        private _logType?;
        get logType(): string;
        set logType(value: string);
        get logTypeInput(): string | undefined;
        private _resourceArn?;
        get resourceArn(): string;
        set resourceArn(value: string);
        get resourceArnInput(): string | undefined;
        get resourcePrefix(): string;
    }
    class LogSettingsPropertyList extends cdktn.ComplexList {
        internalValue?: LogSettingsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LogSettingsPropertyOutputReference;
    }
    interface ConversationLogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot_alias#iam_role_arn AwsBotAlias#iam_role_arn}
        */
        readonly iamRoleArn: string;
        /**
        * log_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot_alias#log_settings AwsBotAlias#log_settings}
        */
        readonly logSettings?: LogSettingsProperty[] | cdktn.IResolvable;
    }
    class ConversationLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConversationLogsProperty | undefined;
        set internalValue(value: ConversationLogsProperty | undefined);
        private _iamRoleArn?;
        get iamRoleArn(): string;
        set iamRoleArn(value: string);
        get iamRoleArnInput(): string | undefined;
        private _logSettings;
        get logSettings(): LogSettingsPropertyList;
        putLogSettings(value: LogSettingsProperty[] | cdktn.IResolvable): void;
        resetLogSettings(): void;
        get logSettingsInput(): cdktn.IResolvable | LogSettingsProperty[] | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot_alias#create AwsBotAlias#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot_alias#delete AwsBotAlias#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_bot_alias#update AwsBotAlias#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
