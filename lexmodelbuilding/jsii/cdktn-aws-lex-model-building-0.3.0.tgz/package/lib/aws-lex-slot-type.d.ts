import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSlotTypeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_slot_type#create_version AwsSlotType#create_version}
    */
    readonly createVersion?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_slot_type#description AwsSlotType#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_slot_type#id AwsSlotType#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_slot_type#name AwsSlotType#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_slot_type#region AwsSlotType#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_slot_type#value_selection_strategy AwsSlotType#value_selection_strategy}
    */
    readonly valueSelectionStrategy?: string;
    /**
    * enumeration_value block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_slot_type#enumeration_value AwsSlotType#enumeration_value}
    */
    readonly enumerationValue: AwsSlotType.EnumerationValueProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_slot_type#timeouts AwsSlotType#timeouts}
    */
    readonly timeouts?: AwsSlotType.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_slot_type aws_lex_slot_type}
*/
export declare class AwsSlotType extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lex_slot_type";
    /**
    * Generates CDKTN code for importing a AwsSlotType resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSlotType to import
    * @param importFromId The id of the existing AwsSlotType that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_slot_type#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSlotType to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_slot_type aws_lex_slot_type} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSlotTypeConfig
    */
    constructor(scope: Construct, id: string, config: AwsSlotTypeConfig);
    get checksum(): string;
    private _createVersion?;
    get createVersion(): boolean | cdktn.IResolvable;
    set createVersion(value: boolean | cdktn.IResolvable);
    resetCreateVersion(): void;
    get createVersionInput(): boolean | cdktn.IResolvable | undefined;
    get createdDate(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastUpdatedDate(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _valueSelectionStrategy?;
    get valueSelectionStrategy(): string;
    set valueSelectionStrategy(value: string);
    resetValueSelectionStrategy(): void;
    get valueSelectionStrategyInput(): string | undefined;
    get version(): string;
    private _enumerationValue;
    get enumerationValue(): AwsSlotType.EnumerationValuePropertyList;
    putEnumerationValue(value: AwsSlotType.EnumerationValueProperty[] | cdktn.IResolvable): void;
    get enumerationValueInput(): cdktn.IResolvable | AwsSlotType.EnumerationValueProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsSlotType.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsSlotType.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsSlotType.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSlotTypeEnumerationValuePropertyToTerraform(struct?: AwsSlotType.EnumerationValueProperty | cdktn.IResolvable): any;
export declare function awsSlotTypeEnumerationValuePropertyToHclTerraform(struct?: AwsSlotType.EnumerationValueProperty | cdktn.IResolvable): any;
export declare function awsSlotTypeTimeoutsPropertyToTerraform(struct?: AwsSlotType.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsSlotTypeTimeoutsPropertyToHclTerraform(struct?: AwsSlotType.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsSlotType {
    interface EnumerationValueProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_slot_type#synonyms AwsSlotType#synonyms}
        */
        readonly synonyms?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_slot_type#value AwsSlotType#value}
        */
        readonly value: string;
    }
    class EnumerationValuePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EnumerationValueProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EnumerationValueProperty | cdktn.IResolvable | undefined);
        private _synonyms?;
        get synonyms(): string[];
        set synonyms(value: string[]);
        resetSynonyms(): void;
        get synonymsInput(): string[] | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class EnumerationValuePropertyList extends cdktn.ComplexList {
        internalValue?: EnumerationValueProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EnumerationValuePropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_slot_type#create AwsSlotType#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_slot_type#delete AwsSlotType#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lex_slot_type#update AwsSlotType#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
