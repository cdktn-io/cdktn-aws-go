import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsBaselineConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/controltower_baseline#baseline_identifier AwsBaseline#baseline_identifier}
    */
    readonly baselineIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/controltower_baseline#baseline_version AwsBaseline#baseline_version}
    */
    readonly baselineVersion: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/controltower_baseline#region AwsBaseline#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/controltower_baseline#tags AwsBaseline#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/controltower_baseline#target_identifier AwsBaseline#target_identifier}
    */
    readonly targetIdentifier: string;
    /**
    * parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/controltower_baseline#parameters AwsBaseline#parameters}
    */
    readonly parameters?: AwsBaseline.ParametersProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/controltower_baseline#timeouts AwsBaseline#timeouts}
    */
    readonly timeouts?: AwsBaseline.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/controltower_baseline aws_controltower_baseline}
*/
export declare class AwsBaseline extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_controltower_baseline";
    /**
    * Generates CDKTN code for importing a AwsBaseline resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsBaseline to import
    * @param importFromId The id of the existing AwsBaseline that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/controltower_baseline#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsBaseline to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/controltower_baseline aws_controltower_baseline} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsBaselineConfig
    */
    constructor(scope: Construct, id: string, config: AwsBaselineConfig);
    get arn(): string;
    private _baselineIdentifier?;
    get baselineIdentifier(): string;
    set baselineIdentifier(value: string);
    get baselineIdentifierInput(): string | undefined;
    private _baselineVersion?;
    get baselineVersion(): string;
    set baselineVersion(value: string);
    get baselineVersionInput(): string | undefined;
    get operationIdentifier(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _targetIdentifier?;
    get targetIdentifier(): string;
    set targetIdentifier(value: string);
    get targetIdentifierInput(): string | undefined;
    private _parameters;
    get parameters(): AwsBaseline.ParametersPropertyList;
    putParameters(value: AwsBaseline.ParametersProperty[] | cdktn.IResolvable): void;
    resetParameters(): void;
    get parametersInput(): cdktn.IResolvable | AwsBaseline.ParametersProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsBaseline.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsBaseline.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsBaseline.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsBaselineParametersPropertyToTerraform(struct?: AwsBaseline.ParametersProperty | cdktn.IResolvable): any;
export declare function awsBaselineParametersPropertyToHclTerraform(struct?: AwsBaseline.ParametersProperty | cdktn.IResolvable): any;
export declare function awsBaselineTimeoutsPropertyToTerraform(struct?: AwsBaseline.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsBaselineTimeoutsPropertyToHclTerraform(struct?: AwsBaseline.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsBaseline {
    interface ParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/controltower_baseline#key AwsBaseline#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/controltower_baseline#value AwsBaseline#value}
        */
        readonly value: string;
    }
    class ParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ParametersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ParametersProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ParametersPropertyList extends cdktn.ComplexList {
        internalValue?: ParametersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ParametersPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/controltower_baseline#create AwsBaseline#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/controltower_baseline#delete AwsBaseline#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/controltower_baseline#update AwsBaseline#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
