import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#description AwsPolicy#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#kms_key_id AwsPolicy#kms_key_id}
    */
    readonly kmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#name AwsPolicy#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#region AwsPolicy#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#tags AwsPolicy#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * availability_slo block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#availability_slo AwsPolicy#availability_slo}
    */
    readonly availabilitySlo?: AwsPolicy.AvailabilitySloProperty[] | cdktn.IResolvable;
    /**
    * data_recovery block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#data_recovery AwsPolicy#data_recovery}
    */
    readonly dataRecovery?: AwsPolicy.DataRecoveryProperty[] | cdktn.IResolvable;
    /**
    * multi_az block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#multi_az AwsPolicy#multi_az}
    */
    readonly multiAz?: AwsPolicy.MultiAzProperty[] | cdktn.IResolvable;
    /**
    * multi_region block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#multi_region AwsPolicy#multi_region}
    */
    readonly multiRegion?: AwsPolicy.MultiRegionProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy aws_resiliencehubv2_policy}
*/
export declare class AwsPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_resiliencehubv2_policy";
    /**
    * Generates CDKTN code for importing a AwsPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsPolicy to import
    * @param importFromId The id of the existing AwsPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy aws_resiliencehubv2_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsPolicyConfig
    */
    constructor(scope: Construct, id: string, config: AwsPolicyConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    resetKmsKeyId(): void;
    get kmsKeyIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _availabilitySlo;
    get availabilitySlo(): AwsPolicy.AvailabilitySloPropertyList;
    putAvailabilitySlo(value: AwsPolicy.AvailabilitySloProperty[] | cdktn.IResolvable): void;
    resetAvailabilitySlo(): void;
    get availabilitySloInput(): cdktn.IResolvable | AwsPolicy.AvailabilitySloProperty[] | undefined;
    private _dataRecovery;
    get dataRecovery(): AwsPolicy.DataRecoveryPropertyList;
    putDataRecovery(value: AwsPolicy.DataRecoveryProperty[] | cdktn.IResolvable): void;
    resetDataRecovery(): void;
    get dataRecoveryInput(): cdktn.IResolvable | AwsPolicy.DataRecoveryProperty[] | undefined;
    private _multiAz;
    get multiAz(): AwsPolicy.MultiAzPropertyList;
    putMultiAz(value: AwsPolicy.MultiAzProperty[] | cdktn.IResolvable): void;
    resetMultiAz(): void;
    get multiAzInput(): cdktn.IResolvable | AwsPolicy.MultiAzProperty[] | undefined;
    private _multiRegion;
    get multiRegion(): AwsPolicy.MultiRegionPropertyList;
    putMultiRegion(value: AwsPolicy.MultiRegionProperty[] | cdktn.IResolvable): void;
    resetMultiRegion(): void;
    get multiRegionInput(): cdktn.IResolvable | AwsPolicy.MultiRegionProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsPolicyAvailabilitySloPropertyToTerraform(struct?: AwsPolicy.AvailabilitySloProperty | cdktn.IResolvable): any;
export declare function awsPolicyAvailabilitySloPropertyToHclTerraform(struct?: AwsPolicy.AvailabilitySloProperty | cdktn.IResolvable): any;
export declare function awsPolicyDataRecoveryPropertyToTerraform(struct?: AwsPolicy.DataRecoveryProperty | cdktn.IResolvable): any;
export declare function awsPolicyDataRecoveryPropertyToHclTerraform(struct?: AwsPolicy.DataRecoveryProperty | cdktn.IResolvable): any;
export declare function awsPolicyMultiAzPropertyToTerraform(struct?: AwsPolicy.MultiAzProperty | cdktn.IResolvable): any;
export declare function awsPolicyMultiAzPropertyToHclTerraform(struct?: AwsPolicy.MultiAzProperty | cdktn.IResolvable): any;
export declare function awsPolicyMultiRegionPropertyToTerraform(struct?: AwsPolicy.MultiRegionProperty | cdktn.IResolvable): any;
export declare function awsPolicyMultiRegionPropertyToHclTerraform(struct?: AwsPolicy.MultiRegionProperty | cdktn.IResolvable): any;
export declare namespace AwsPolicy {
    interface AvailabilitySloProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#target AwsPolicy#target}
        */
        readonly target: number;
    }
    class AvailabilitySloPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AvailabilitySloProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AvailabilitySloProperty | cdktn.IResolvable | undefined);
        private _target?;
        get target(): number;
        set target(value: number);
        get targetInput(): number | undefined;
    }
    class AvailabilitySloPropertyList extends cdktn.ComplexList {
        internalValue?: AvailabilitySloProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AvailabilitySloPropertyOutputReference;
    }
    interface DataRecoveryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#time_between_backups_in_minutes AwsPolicy#time_between_backups_in_minutes}
        */
        readonly timeBetweenBackupsInMinutes: number;
    }
    class DataRecoveryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DataRecoveryProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DataRecoveryProperty | cdktn.IResolvable | undefined);
        private _timeBetweenBackupsInMinutes?;
        get timeBetweenBackupsInMinutes(): number;
        set timeBetweenBackupsInMinutes(value: number);
        get timeBetweenBackupsInMinutesInput(): number | undefined;
    }
    class DataRecoveryPropertyList extends cdktn.ComplexList {
        internalValue?: DataRecoveryProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DataRecoveryPropertyOutputReference;
    }
    interface MultiAzProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#disaster_recovery_approach AwsPolicy#disaster_recovery_approach}
        */
        readonly disasterRecoveryApproach: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#rpo_in_minutes AwsPolicy#rpo_in_minutes}
        */
        readonly rpoInMinutes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#rto_in_minutes AwsPolicy#rto_in_minutes}
        */
        readonly rtoInMinutes?: number;
    }
    class MultiAzPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MultiAzProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MultiAzProperty | cdktn.IResolvable | undefined);
        private _disasterRecoveryApproach?;
        get disasterRecoveryApproach(): string;
        set disasterRecoveryApproach(value: string);
        get disasterRecoveryApproachInput(): string | undefined;
        private _rpoInMinutes?;
        get rpoInMinutes(): number;
        set rpoInMinutes(value: number);
        resetRpoInMinutes(): void;
        get rpoInMinutesInput(): number | undefined;
        private _rtoInMinutes?;
        get rtoInMinutes(): number;
        set rtoInMinutes(value: number);
        resetRtoInMinutes(): void;
        get rtoInMinutesInput(): number | undefined;
    }
    class MultiAzPropertyList extends cdktn.ComplexList {
        internalValue?: MultiAzProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MultiAzPropertyOutputReference;
    }
    interface MultiRegionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#disaster_recovery_approach AwsPolicy#disaster_recovery_approach}
        */
        readonly disasterRecoveryApproach: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#rpo_in_minutes AwsPolicy#rpo_in_minutes}
        */
        readonly rpoInMinutes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resiliencehubv2_policy#rto_in_minutes AwsPolicy#rto_in_minutes}
        */
        readonly rtoInMinutes?: number;
    }
    class MultiRegionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MultiRegionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MultiRegionProperty | cdktn.IResolvable | undefined);
        private _disasterRecoveryApproach?;
        get disasterRecoveryApproach(): string;
        set disasterRecoveryApproach(value: string);
        get disasterRecoveryApproachInput(): string | undefined;
        private _rpoInMinutes?;
        get rpoInMinutes(): number;
        set rpoInMinutes(value: number);
        resetRpoInMinutes(): void;
        get rpoInMinutesInput(): number | undefined;
        private _rtoInMinutes?;
        get rtoInMinutes(): number;
        set rtoInMinutes(value: number);
        resetRtoInMinutes(): void;
        get rtoInMinutesInput(): number | undefined;
    }
    class MultiRegionPropertyList extends cdktn.ComplexList {
        internalValue?: MultiRegionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MultiRegionPropertyOutputReference;
    }
}
