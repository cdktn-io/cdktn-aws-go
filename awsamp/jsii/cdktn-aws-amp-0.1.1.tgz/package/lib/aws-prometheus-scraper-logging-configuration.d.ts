import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsPrometheusScraperLoggingConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper_logging_configuration#region AwsPrometheusScraperLoggingConfiguration#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper_logging_configuration#scraper_components AwsPrometheusScraperLoggingConfiguration#scraper_components}
    */
    readonly scraperComponents?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper_logging_configuration#scraper_id AwsPrometheusScraperLoggingConfiguration#scraper_id}
    */
    readonly scraperId: string;
    /**
    * logging_destination block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper_logging_configuration#logging_destination AwsPrometheusScraperLoggingConfiguration#logging_destination}
    */
    readonly loggingDestination?: AwsPrometheusScraperLoggingConfiguration.LoggingDestinationProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper_logging_configuration#timeouts AwsPrometheusScraperLoggingConfiguration#timeouts}
    */
    readonly timeouts?: AwsPrometheusScraperLoggingConfiguration.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper_logging_configuration aws_prometheus_scraper_logging_configuration}
*/
export declare class AwsPrometheusScraperLoggingConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_prometheus_scraper_logging_configuration";
    /**
    * Generates CDKTN code for importing a AwsPrometheusScraperLoggingConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsPrometheusScraperLoggingConfiguration to import
    * @param importFromId The id of the existing AwsPrometheusScraperLoggingConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper_logging_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsPrometheusScraperLoggingConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper_logging_configuration aws_prometheus_scraper_logging_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsPrometheusScraperLoggingConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsPrometheusScraperLoggingConfigurationConfig);
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _scraperComponents?;
    get scraperComponents(): string[];
    set scraperComponents(value: string[]);
    resetScraperComponents(): void;
    get scraperComponentsInput(): string[] | undefined;
    private _scraperId?;
    get scraperId(): string;
    set scraperId(value: string);
    get scraperIdInput(): string | undefined;
    private _loggingDestination;
    get loggingDestination(): AwsPrometheusScraperLoggingConfiguration.LoggingDestinationPropertyList;
    putLoggingDestination(value: AwsPrometheusScraperLoggingConfiguration.LoggingDestinationProperty[] | cdktn.IResolvable): void;
    resetLoggingDestination(): void;
    get loggingDestinationInput(): cdktn.IResolvable | AwsPrometheusScraperLoggingConfiguration.LoggingDestinationProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsPrometheusScraperLoggingConfiguration.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsPrometheusScraperLoggingConfiguration.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsPrometheusScraperLoggingConfiguration.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsPrometheusScraperLoggingConfigurationCloudwatchLogsPropertyToTerraform(struct?: AwsPrometheusScraperLoggingConfiguration.CloudwatchLogsProperty | cdktn.IResolvable): any;
export declare function awsPrometheusScraperLoggingConfigurationCloudwatchLogsPropertyToHclTerraform(struct?: AwsPrometheusScraperLoggingConfiguration.CloudwatchLogsProperty | cdktn.IResolvable): any;
export declare function awsPrometheusScraperLoggingConfigurationLoggingDestinationPropertyToTerraform(struct?: AwsPrometheusScraperLoggingConfiguration.LoggingDestinationProperty | cdktn.IResolvable): any;
export declare function awsPrometheusScraperLoggingConfigurationLoggingDestinationPropertyToHclTerraform(struct?: AwsPrometheusScraperLoggingConfiguration.LoggingDestinationProperty | cdktn.IResolvable): any;
export declare function awsPrometheusScraperLoggingConfigurationTimeoutsPropertyToTerraform(struct?: AwsPrometheusScraperLoggingConfiguration.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsPrometheusScraperLoggingConfigurationTimeoutsPropertyToHclTerraform(struct?: AwsPrometheusScraperLoggingConfiguration.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsPrometheusScraperLoggingConfiguration {
    interface CloudwatchLogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper_logging_configuration#log_group_arn AwsPrometheusScraperLoggingConfiguration#log_group_arn}
        */
        readonly logGroupArn: string;
    }
    class CloudwatchLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CloudwatchLogsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CloudwatchLogsProperty | cdktn.IResolvable | undefined);
        private _logGroupArn?;
        get logGroupArn(): string;
        set logGroupArn(value: string);
        get logGroupArnInput(): string | undefined;
    }
    class CloudwatchLogsPropertyList extends cdktn.ComplexList {
        internalValue?: CloudwatchLogsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CloudwatchLogsPropertyOutputReference;
    }
    interface LoggingDestinationProperty {
        /**
        * cloudwatch_logs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper_logging_configuration#cloudwatch_logs AwsPrometheusScraperLoggingConfiguration#cloudwatch_logs}
        */
        readonly cloudwatchLogs?: CloudwatchLogsProperty[] | cdktn.IResolvable;
    }
    class LoggingDestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LoggingDestinationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LoggingDestinationProperty | cdktn.IResolvable | undefined);
        private _cloudwatchLogs;
        get cloudwatchLogs(): CloudwatchLogsPropertyList;
        putCloudwatchLogs(value: CloudwatchLogsProperty[] | cdktn.IResolvable): void;
        resetCloudwatchLogs(): void;
        get cloudwatchLogsInput(): cdktn.IResolvable | CloudwatchLogsProperty[] | undefined;
    }
    class LoggingDestinationPropertyList extends cdktn.ComplexList {
        internalValue?: LoggingDestinationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LoggingDestinationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper_logging_configuration#create AwsPrometheusScraperLoggingConfiguration#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper_logging_configuration#delete AwsPrometheusScraperLoggingConfiguration#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper_logging_configuration#update AwsPrometheusScraperLoggingConfiguration#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
