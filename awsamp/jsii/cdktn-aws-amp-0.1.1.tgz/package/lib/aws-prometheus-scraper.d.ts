import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsPrometheusScraperConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#alias AwsPrometheusScraper#alias}
    */
    readonly alias?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#region AwsPrometheusScraper#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#scrape_configuration AwsPrometheusScraper#scrape_configuration}
    */
    readonly scrapeConfiguration: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#tags AwsPrometheusScraper#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * destination block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#destination AwsPrometheusScraper#destination}
    */
    readonly destination?: AwsPrometheusScraper.DestinationProperty[] | cdktn.IResolvable;
    /**
    * exporter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#exporter AwsPrometheusScraper#exporter}
    */
    readonly exporter?: AwsPrometheusScraper.ExporterProperty[] | cdktn.IResolvable;
    /**
    * role_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#role_configuration AwsPrometheusScraper#role_configuration}
    */
    readonly roleConfiguration?: AwsPrometheusScraper.RoleConfigurationProperty[] | cdktn.IResolvable;
    /**
    * source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#source AwsPrometheusScraper#source}
    */
    readonly source?: AwsPrometheusScraper.SourceProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#timeouts AwsPrometheusScraper#timeouts}
    */
    readonly timeouts?: AwsPrometheusScraper.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper aws_prometheus_scraper}
*/
export declare class AwsPrometheusScraper extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_prometheus_scraper";
    /**
    * Generates CDKTN code for importing a AwsPrometheusScraper resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsPrometheusScraper to import
    * @param importFromId The id of the existing AwsPrometheusScraper that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsPrometheusScraper to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper aws_prometheus_scraper} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsPrometheusScraperConfig
    */
    constructor(scope: Construct, id: string, config: AwsPrometheusScraperConfig);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    get arn(): string;
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get roleArn(): string;
    private _scrapeConfiguration?;
    get scrapeConfiguration(): string;
    set scrapeConfiguration(value: string);
    get scrapeConfigurationInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _destination;
    get destination(): AwsPrometheusScraper.DestinationPropertyList;
    putDestination(value: AwsPrometheusScraper.DestinationProperty[] | cdktn.IResolvable): void;
    resetDestination(): void;
    get destinationInput(): cdktn.IResolvable | AwsPrometheusScraper.DestinationProperty[] | undefined;
    private _exporter;
    get exporter(): AwsPrometheusScraper.ExporterPropertyList;
    putExporter(value: AwsPrometheusScraper.ExporterProperty[] | cdktn.IResolvable): void;
    resetExporter(): void;
    get exporterInput(): cdktn.IResolvable | AwsPrometheusScraper.ExporterProperty[] | undefined;
    private _roleConfiguration;
    get roleConfiguration(): AwsPrometheusScraper.RoleConfigurationPropertyList;
    putRoleConfiguration(value: AwsPrometheusScraper.RoleConfigurationProperty[] | cdktn.IResolvable): void;
    resetRoleConfiguration(): void;
    get roleConfigurationInput(): cdktn.IResolvable | AwsPrometheusScraper.RoleConfigurationProperty[] | undefined;
    private _source;
    get source(): AwsPrometheusScraper.SourcePropertyList;
    putSource(value: AwsPrometheusScraper.SourceProperty[] | cdktn.IResolvable): void;
    resetSource(): void;
    get sourceInput(): cdktn.IResolvable | AwsPrometheusScraper.SourceProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsPrometheusScraper.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsPrometheusScraper.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsPrometheusScraper.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsPrometheusScraperAmpPropertyToTerraform(struct?: AwsPrometheusScraper.AmpProperty | cdktn.IResolvable): any;
export declare function awsPrometheusScraperAmpPropertyToHclTerraform(struct?: AwsPrometheusScraper.AmpProperty | cdktn.IResolvable): any;
export declare function awsPrometheusScraperCloudwatchPropertyToTerraform(struct?: AwsPrometheusScraper.CloudwatchProperty | cdktn.IResolvable): any;
export declare function awsPrometheusScraperCloudwatchPropertyToHclTerraform(struct?: AwsPrometheusScraper.CloudwatchProperty | cdktn.IResolvable): any;
export declare function awsPrometheusScraperDestinationPropertyToTerraform(struct?: AwsPrometheusScraper.DestinationProperty | cdktn.IResolvable): any;
export declare function awsPrometheusScraperDestinationPropertyToHclTerraform(struct?: AwsPrometheusScraper.DestinationProperty | cdktn.IResolvable): any;
export declare function awsPrometheusScraperOpensearchPropertyToTerraform(struct?: AwsPrometheusScraper.OpensearchProperty | cdktn.IResolvable): any;
export declare function awsPrometheusScraperOpensearchPropertyToHclTerraform(struct?: AwsPrometheusScraper.OpensearchProperty | cdktn.IResolvable): any;
export declare function awsPrometheusScraperExporterPropertyToTerraform(struct?: AwsPrometheusScraper.ExporterProperty | cdktn.IResolvable): any;
export declare function awsPrometheusScraperExporterPropertyToHclTerraform(struct?: AwsPrometheusScraper.ExporterProperty | cdktn.IResolvable): any;
export declare function awsPrometheusScraperRoleConfigurationPropertyToTerraform(struct?: AwsPrometheusScraper.RoleConfigurationProperty | cdktn.IResolvable): any;
export declare function awsPrometheusScraperRoleConfigurationPropertyToHclTerraform(struct?: AwsPrometheusScraper.RoleConfigurationProperty | cdktn.IResolvable): any;
export declare function awsPrometheusScraperEksPropertyToTerraform(struct?: AwsPrometheusScraper.EksProperty | cdktn.IResolvable): any;
export declare function awsPrometheusScraperEksPropertyToHclTerraform(struct?: AwsPrometheusScraper.EksProperty | cdktn.IResolvable): any;
export declare function awsPrometheusScraperVpcPropertyToTerraform(struct?: AwsPrometheusScraper.VpcProperty | cdktn.IResolvable): any;
export declare function awsPrometheusScraperVpcPropertyToHclTerraform(struct?: AwsPrometheusScraper.VpcProperty | cdktn.IResolvable): any;
export declare function awsPrometheusScraperSourcePropertyToTerraform(struct?: AwsPrometheusScraper.SourceProperty | cdktn.IResolvable): any;
export declare function awsPrometheusScraperSourcePropertyToHclTerraform(struct?: AwsPrometheusScraper.SourceProperty | cdktn.IResolvable): any;
export declare function awsPrometheusScraperTimeoutsPropertyToTerraform(struct?: AwsPrometheusScraper.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsPrometheusScraperTimeoutsPropertyToHclTerraform(struct?: AwsPrometheusScraper.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsPrometheusScraper {
    interface AmpProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#workspace_arn AwsPrometheusScraper#workspace_arn}
        */
        readonly workspaceArn: string;
    }
    class AmpPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AmpProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AmpProperty | cdktn.IResolvable | undefined);
        private _workspaceArn?;
        get workspaceArn(): string;
        set workspaceArn(value: string);
        get workspaceArnInput(): string | undefined;
    }
    class AmpPropertyList extends cdktn.ComplexList {
        internalValue?: AmpProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AmpPropertyOutputReference;
    }
    interface CloudwatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#dataset_arn AwsPrometheusScraper#dataset_arn}
        */
        readonly datasetArn: string;
    }
    class CloudwatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CloudwatchProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CloudwatchProperty | cdktn.IResolvable | undefined);
        private _datasetArn?;
        get datasetArn(): string;
        set datasetArn(value: string);
        get datasetArnInput(): string | undefined;
    }
    class CloudwatchPropertyList extends cdktn.ComplexList {
        internalValue?: CloudwatchProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CloudwatchPropertyOutputReference;
    }
    interface DestinationProperty {
        /**
        * amp block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#amp AwsPrometheusScraper#amp}
        */
        readonly amp?: AmpProperty[] | cdktn.IResolvable;
        /**
        * cloudwatch block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#cloudwatch AwsPrometheusScraper#cloudwatch}
        */
        readonly cloudwatch?: CloudwatchProperty[] | cdktn.IResolvable;
    }
    class DestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DestinationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DestinationProperty | cdktn.IResolvable | undefined);
        private _amp;
        get amp(): AmpPropertyList;
        putAmp(value: AmpProperty[] | cdktn.IResolvable): void;
        resetAmp(): void;
        get ampInput(): cdktn.IResolvable | AmpProperty[] | undefined;
        private _cloudwatch;
        get cloudwatch(): CloudwatchPropertyList;
        putCloudwatch(value: CloudwatchProperty[] | cdktn.IResolvable): void;
        resetCloudwatch(): void;
        get cloudwatchInput(): cdktn.IResolvable | CloudwatchProperty[] | undefined;
    }
    class DestinationPropertyList extends cdktn.ComplexList {
        internalValue?: DestinationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DestinationPropertyOutputReference;
    }
    interface OpensearchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#domain_arn AwsPrometheusScraper#domain_arn}
        */
        readonly domainArn: string;
    }
    class OpensearchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OpensearchProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OpensearchProperty | cdktn.IResolvable | undefined);
        private _domainArn?;
        get domainArn(): string;
        set domainArn(value: string);
        get domainArnInput(): string | undefined;
    }
    class OpensearchPropertyList extends cdktn.ComplexList {
        internalValue?: OpensearchProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OpensearchPropertyOutputReference;
    }
    interface ExporterProperty {
        /**
        * opensearch block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#opensearch AwsPrometheusScraper#opensearch}
        */
        readonly opensearch?: OpensearchProperty[] | cdktn.IResolvable;
    }
    class ExporterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExporterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ExporterProperty | cdktn.IResolvable | undefined);
        private _opensearch;
        get opensearch(): OpensearchPropertyList;
        putOpensearch(value: OpensearchProperty[] | cdktn.IResolvable): void;
        resetOpensearch(): void;
        get opensearchInput(): cdktn.IResolvable | OpensearchProperty[] | undefined;
    }
    class ExporterPropertyList extends cdktn.ComplexList {
        internalValue?: ExporterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExporterPropertyOutputReference;
    }
    interface RoleConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#source_role_arn AwsPrometheusScraper#source_role_arn}
        */
        readonly sourceRoleArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#target_role_arn AwsPrometheusScraper#target_role_arn}
        */
        readonly targetRoleArn?: string;
    }
    class RoleConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RoleConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RoleConfigurationProperty | cdktn.IResolvable | undefined);
        private _sourceRoleArn?;
        get sourceRoleArn(): string;
        set sourceRoleArn(value: string);
        resetSourceRoleArn(): void;
        get sourceRoleArnInput(): string | undefined;
        private _targetRoleArn?;
        get targetRoleArn(): string;
        set targetRoleArn(value: string);
        resetTargetRoleArn(): void;
        get targetRoleArnInput(): string | undefined;
    }
    class RoleConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: RoleConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RoleConfigurationPropertyOutputReference;
    }
    interface EksProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#cluster_arn AwsPrometheusScraper#cluster_arn}
        */
        readonly clusterArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#security_group_ids AwsPrometheusScraper#security_group_ids}
        */
        readonly securityGroupIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#subnet_ids AwsPrometheusScraper#subnet_ids}
        */
        readonly subnetIds: string[];
    }
    class EksPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EksProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EksProperty | cdktn.IResolvable | undefined);
        private _clusterArn?;
        get clusterArn(): string;
        set clusterArn(value: string);
        get clusterArnInput(): string | undefined;
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        resetSecurityGroupIds(): void;
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
    }
    class EksPropertyList extends cdktn.ComplexList {
        internalValue?: EksProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EksPropertyOutputReference;
    }
    interface VpcProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#security_group_ids AwsPrometheusScraper#security_group_ids}
        */
        readonly securityGroupIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#subnet_ids AwsPrometheusScraper#subnet_ids}
        */
        readonly subnetIds: string[];
    }
    class VpcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpcProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VpcProperty | cdktn.IResolvable | undefined);
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
    }
    class VpcPropertyList extends cdktn.ComplexList {
        internalValue?: VpcProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpcPropertyOutputReference;
    }
    interface SourceProperty {
        /**
        * eks block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#eks AwsPrometheusScraper#eks}
        */
        readonly eks?: EksProperty[] | cdktn.IResolvable;
        /**
        * vpc block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#vpc AwsPrometheusScraper#vpc}
        */
        readonly vpc?: VpcProperty[] | cdktn.IResolvable;
    }
    class SourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SourceProperty | cdktn.IResolvable | undefined);
        private _eks;
        get eks(): EksPropertyList;
        putEks(value: EksProperty[] | cdktn.IResolvable): void;
        resetEks(): void;
        get eksInput(): cdktn.IResolvable | EksProperty[] | undefined;
        private _vpc;
        get vpc(): VpcPropertyList;
        putVpc(value: VpcProperty[] | cdktn.IResolvable): void;
        resetVpc(): void;
        get vpcInput(): cdktn.IResolvable | VpcProperty[] | undefined;
    }
    class SourcePropertyList extends cdktn.ComplexList {
        internalValue?: SourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SourcePropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#create AwsPrometheusScraper#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#delete AwsPrometheusScraper#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#update AwsPrometheusScraper#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
