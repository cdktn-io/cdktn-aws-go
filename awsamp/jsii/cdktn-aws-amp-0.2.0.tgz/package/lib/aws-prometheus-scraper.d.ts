import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfScraperConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#alias TfScraper#alias}
    */
    readonly alias?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#region TfScraper#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#scrape_configuration TfScraper#scrape_configuration}
    */
    readonly scrapeConfiguration: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#tags TfScraper#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * destination block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#destination TfScraper#destination}
    */
    readonly destination?: TfScraper.DestinationProperty[] | cdktn.IResolvable;
    /**
    * exporter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#exporter TfScraper#exporter}
    */
    readonly exporter?: TfScraper.ExporterProperty[] | cdktn.IResolvable;
    /**
    * role_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#role_configuration TfScraper#role_configuration}
    */
    readonly roleConfiguration?: TfScraper.RoleConfigurationProperty[] | cdktn.IResolvable;
    /**
    * source block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#source TfScraper#source}
    */
    readonly source?: TfScraper.SourceProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#timeouts TfScraper#timeouts}
    */
    readonly timeouts?: TfScraper.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper aws_prometheus_scraper}
*/
export declare class TfScraper extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_prometheus_scraper";
    /**
    * Generates CDKTN code for importing a TfScraper resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfScraper to import
    * @param importFromId The id of the existing TfScraper that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfScraper to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper aws_prometheus_scraper} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfScraperConfig
    */
    constructor(scope: Construct, id: string, config: TfScraperConfig);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    get arn(): string;
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get roleArn(): string;
    private _scrapeConfiguration?;
    get scrapeConfiguration(): string;
    set scrapeConfiguration(value: string);
    get scrapeConfigurationInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _destination;
    get destination(): TfScraper.DestinationPropertyList;
    putDestination(value: TfScraper.DestinationProperty[] | cdktn.IResolvable): void;
    resetDestination(): void;
    get destinationInput(): cdktn.IResolvable | TfScraper.DestinationProperty[] | undefined;
    private _exporter;
    get exporter(): TfScraper.ExporterPropertyList;
    putExporter(value: TfScraper.ExporterProperty[] | cdktn.IResolvable): void;
    resetExporter(): void;
    get exporterInput(): cdktn.IResolvable | TfScraper.ExporterProperty[] | undefined;
    private _roleConfiguration;
    get roleConfiguration(): TfScraper.RoleConfigurationPropertyList;
    putRoleConfiguration(value: TfScraper.RoleConfigurationProperty[] | cdktn.IResolvable): void;
    resetRoleConfiguration(): void;
    get roleConfigurationInput(): cdktn.IResolvable | TfScraper.RoleConfigurationProperty[] | undefined;
    private _source;
    get source(): TfScraper.SourcePropertyList;
    putSource(value: TfScraper.SourceProperty[] | cdktn.IResolvable): void;
    resetSource(): void;
    get sourceInput(): cdktn.IResolvable | TfScraper.SourceProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfScraper.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfScraper.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfScraper.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfScraperAmpPropertyToTerraform(struct?: TfScraper.AmpProperty | cdktn.IResolvable): any;
export declare function tfScraperAmpPropertyToHclTerraform(struct?: TfScraper.AmpProperty | cdktn.IResolvable): any;
export declare function tfScraperCloudwatchPropertyToTerraform(struct?: TfScraper.CloudwatchProperty | cdktn.IResolvable): any;
export declare function tfScraperCloudwatchPropertyToHclTerraform(struct?: TfScraper.CloudwatchProperty | cdktn.IResolvable): any;
export declare function tfScraperDestinationPropertyToTerraform(struct?: TfScraper.DestinationProperty | cdktn.IResolvable): any;
export declare function tfScraperDestinationPropertyToHclTerraform(struct?: TfScraper.DestinationProperty | cdktn.IResolvable): any;
export declare function tfScraperOpensearchPropertyToTerraform(struct?: TfScraper.OpensearchProperty | cdktn.IResolvable): any;
export declare function tfScraperOpensearchPropertyToHclTerraform(struct?: TfScraper.OpensearchProperty | cdktn.IResolvable): any;
export declare function tfScraperExporterPropertyToTerraform(struct?: TfScraper.ExporterProperty | cdktn.IResolvable): any;
export declare function tfScraperExporterPropertyToHclTerraform(struct?: TfScraper.ExporterProperty | cdktn.IResolvable): any;
export declare function tfScraperRoleConfigurationPropertyToTerraform(struct?: TfScraper.RoleConfigurationProperty | cdktn.IResolvable): any;
export declare function tfScraperRoleConfigurationPropertyToHclTerraform(struct?: TfScraper.RoleConfigurationProperty | cdktn.IResolvable): any;
export declare function tfScraperEksPropertyToTerraform(struct?: TfScraper.EksProperty | cdktn.IResolvable): any;
export declare function tfScraperEksPropertyToHclTerraform(struct?: TfScraper.EksProperty | cdktn.IResolvable): any;
export declare function tfScraperVpcPropertyToTerraform(struct?: TfScraper.VpcProperty | cdktn.IResolvable): any;
export declare function tfScraperVpcPropertyToHclTerraform(struct?: TfScraper.VpcProperty | cdktn.IResolvable): any;
export declare function tfScraperSourcePropertyToTerraform(struct?: TfScraper.SourceProperty | cdktn.IResolvable): any;
export declare function tfScraperSourcePropertyToHclTerraform(struct?: TfScraper.SourceProperty | cdktn.IResolvable): any;
export declare function tfScraperTimeoutsPropertyToTerraform(struct?: TfScraper.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfScraperTimeoutsPropertyToHclTerraform(struct?: TfScraper.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfScraper {
    interface AmpProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#workspace_arn TfScraper#workspace_arn}
        */
        readonly workspaceArn: string;
    }
    class AmpPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AmpProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AmpProperty | cdktn.IResolvable | undefined);
        private _workspaceArn?;
        get workspaceArn(): string;
        set workspaceArn(value: string);
        get workspaceArnInput(): string | undefined;
    }
    class AmpPropertyList extends cdktn.ComplexList {
        internalValue?: AmpProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AmpPropertyOutputReference;
    }
    interface CloudwatchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#dataset_arn TfScraper#dataset_arn}
        */
        readonly datasetArn: string;
    }
    class CloudwatchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CloudwatchProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CloudwatchProperty | cdktn.IResolvable | undefined);
        private _datasetArn?;
        get datasetArn(): string;
        set datasetArn(value: string);
        get datasetArnInput(): string | undefined;
    }
    class CloudwatchPropertyList extends cdktn.ComplexList {
        internalValue?: CloudwatchProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CloudwatchPropertyOutputReference;
    }
    interface DestinationProperty {
        /**
        * amp block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#amp TfScraper#amp}
        */
        readonly amp?: AmpProperty[] | cdktn.IResolvable;
        /**
        * cloudwatch block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#cloudwatch TfScraper#cloudwatch}
        */
        readonly cloudwatch?: CloudwatchProperty[] | cdktn.IResolvable;
    }
    class DestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DestinationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DestinationProperty | cdktn.IResolvable | undefined);
        private _amp;
        get amp(): AmpPropertyList;
        putAmp(value: AmpProperty[] | cdktn.IResolvable): void;
        resetAmp(): void;
        get ampInput(): cdktn.IResolvable | AmpProperty[] | undefined;
        private _cloudwatch;
        get cloudwatch(): CloudwatchPropertyList;
        putCloudwatch(value: CloudwatchProperty[] | cdktn.IResolvable): void;
        resetCloudwatch(): void;
        get cloudwatchInput(): cdktn.IResolvable | CloudwatchProperty[] | undefined;
    }
    class DestinationPropertyList extends cdktn.ComplexList {
        internalValue?: DestinationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DestinationPropertyOutputReference;
    }
    interface OpensearchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#domain_arn TfScraper#domain_arn}
        */
        readonly domainArn: string;
    }
    class OpensearchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OpensearchProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OpensearchProperty | cdktn.IResolvable | undefined);
        private _domainArn?;
        get domainArn(): string;
        set domainArn(value: string);
        get domainArnInput(): string | undefined;
    }
    class OpensearchPropertyList extends cdktn.ComplexList {
        internalValue?: OpensearchProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OpensearchPropertyOutputReference;
    }
    interface ExporterProperty {
        /**
        * opensearch block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#opensearch TfScraper#opensearch}
        */
        readonly opensearch?: OpensearchProperty[] | cdktn.IResolvable;
    }
    class ExporterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExporterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ExporterProperty | cdktn.IResolvable | undefined);
        private _opensearch;
        get opensearch(): OpensearchPropertyList;
        putOpensearch(value: OpensearchProperty[] | cdktn.IResolvable): void;
        resetOpensearch(): void;
        get opensearchInput(): cdktn.IResolvable | OpensearchProperty[] | undefined;
    }
    class ExporterPropertyList extends cdktn.ComplexList {
        internalValue?: ExporterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExporterPropertyOutputReference;
    }
    interface RoleConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#source_role_arn TfScraper#source_role_arn}
        */
        readonly sourceRoleArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#target_role_arn TfScraper#target_role_arn}
        */
        readonly targetRoleArn?: string;
    }
    class RoleConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RoleConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RoleConfigurationProperty | cdktn.IResolvable | undefined);
        private _sourceRoleArn?;
        get sourceRoleArn(): string;
        set sourceRoleArn(value: string);
        resetSourceRoleArn(): void;
        get sourceRoleArnInput(): string | undefined;
        private _targetRoleArn?;
        get targetRoleArn(): string;
        set targetRoleArn(value: string);
        resetTargetRoleArn(): void;
        get targetRoleArnInput(): string | undefined;
    }
    class RoleConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: RoleConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RoleConfigurationPropertyOutputReference;
    }
    interface EksProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#cluster_arn TfScraper#cluster_arn}
        */
        readonly clusterArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#security_group_ids TfScraper#security_group_ids}
        */
        readonly securityGroupIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#subnet_ids TfScraper#subnet_ids}
        */
        readonly subnetIds: string[];
    }
    class EksPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EksProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EksProperty | cdktn.IResolvable | undefined);
        private _clusterArn?;
        get clusterArn(): string;
        set clusterArn(value: string);
        get clusterArnInput(): string | undefined;
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        resetSecurityGroupIds(): void;
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
    }
    class EksPropertyList extends cdktn.ComplexList {
        internalValue?: EksProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EksPropertyOutputReference;
    }
    interface VpcProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#security_group_ids TfScraper#security_group_ids}
        */
        readonly securityGroupIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#subnet_ids TfScraper#subnet_ids}
        */
        readonly subnetIds: string[];
    }
    class VpcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpcProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VpcProperty | cdktn.IResolvable | undefined);
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
    }
    class VpcPropertyList extends cdktn.ComplexList {
        internalValue?: VpcProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpcPropertyOutputReference;
    }
    interface SourceProperty {
        /**
        * eks block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#eks TfScraper#eks}
        */
        readonly eks?: EksProperty[] | cdktn.IResolvable;
        /**
        * vpc block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#vpc TfScraper#vpc}
        */
        readonly vpc?: VpcProperty[] | cdktn.IResolvable;
    }
    class SourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SourceProperty | cdktn.IResolvable | undefined);
        private _eks;
        get eks(): EksPropertyList;
        putEks(value: EksProperty[] | cdktn.IResolvable): void;
        resetEks(): void;
        get eksInput(): cdktn.IResolvable | EksProperty[] | undefined;
        private _vpc;
        get vpc(): VpcPropertyList;
        putVpc(value: VpcProperty[] | cdktn.IResolvable): void;
        resetVpc(): void;
        get vpcInput(): cdktn.IResolvable | VpcProperty[] | undefined;
    }
    class SourcePropertyList extends cdktn.ComplexList {
        internalValue?: SourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SourcePropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#create TfScraper#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#delete TfScraper#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_scraper#update TfScraper#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
