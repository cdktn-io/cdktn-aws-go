import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsEcrPullTimeUpdateExclusionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_pull_time_update_exclusion#principal_arn AwsEcrPullTimeUpdateExclusion#principal_arn}
    */
    readonly principalArn: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_pull_time_update_exclusion#region AwsEcrPullTimeUpdateExclusion#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_pull_time_update_exclusion aws_ecr_pull_time_update_exclusion}
*/
export declare class AwsEcrPullTimeUpdateExclusion extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ecr_pull_time_update_exclusion";
    /**
    * Generates CDKTN code for importing a AwsEcrPullTimeUpdateExclusion resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsEcrPullTimeUpdateExclusion to import
    * @param importFromId The id of the existing AwsEcrPullTimeUpdateExclusion that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_pull_time_update_exclusion#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsEcrPullTimeUpdateExclusion to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_pull_time_update_exclusion aws_ecr_pull_time_update_exclusion} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsEcrPullTimeUpdateExclusionConfig
    */
    constructor(scope: Construct, id: string, config: AwsEcrPullTimeUpdateExclusionConfig);
    private _principalArn?;
    get principalArn(): string;
    set principalArn(value: string);
    get principalArnInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
