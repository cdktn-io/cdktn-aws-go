import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsEcrRegistryScanningConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_registry_scanning_configuration#id AwsEcrRegistryScanningConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_registry_scanning_configuration#region AwsEcrRegistryScanningConfiguration#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_registry_scanning_configuration#scan_type AwsEcrRegistryScanningConfiguration#scan_type}
    */
    readonly scanType: string;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_registry_scanning_configuration#rule AwsEcrRegistryScanningConfiguration#rule}
    */
    readonly rule?: AwsEcrRegistryScanningConfiguration.RuleProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_registry_scanning_configuration aws_ecr_registry_scanning_configuration}
*/
export declare class AwsEcrRegistryScanningConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ecr_registry_scanning_configuration";
    /**
    * Generates CDKTN code for importing a AwsEcrRegistryScanningConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsEcrRegistryScanningConfiguration to import
    * @param importFromId The id of the existing AwsEcrRegistryScanningConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_registry_scanning_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsEcrRegistryScanningConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_registry_scanning_configuration aws_ecr_registry_scanning_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsEcrRegistryScanningConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsEcrRegistryScanningConfigurationConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get registryId(): string;
    private _scanType?;
    get scanType(): string;
    set scanType(value: string);
    get scanTypeInput(): string | undefined;
    private _rule;
    get rule(): AwsEcrRegistryScanningConfiguration.RulePropertyList;
    putRule(value: AwsEcrRegistryScanningConfiguration.RuleProperty[] | cdktn.IResolvable): void;
    resetRule(): void;
    get ruleInput(): cdktn.IResolvable | AwsEcrRegistryScanningConfiguration.RuleProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsEcrRegistryScanningConfigurationRepositoryFilterPropertyToTerraform(struct?: AwsEcrRegistryScanningConfiguration.RepositoryFilterProperty | cdktn.IResolvable): any;
export declare function awsEcrRegistryScanningConfigurationRepositoryFilterPropertyToHclTerraform(struct?: AwsEcrRegistryScanningConfiguration.RepositoryFilterProperty | cdktn.IResolvable): any;
export declare function awsEcrRegistryScanningConfigurationRulePropertyToTerraform(struct?: AwsEcrRegistryScanningConfiguration.RuleProperty | cdktn.IResolvable): any;
export declare function awsEcrRegistryScanningConfigurationRulePropertyToHclTerraform(struct?: AwsEcrRegistryScanningConfiguration.RuleProperty | cdktn.IResolvable): any;
export declare namespace AwsEcrRegistryScanningConfiguration {
    interface RepositoryFilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_registry_scanning_configuration#filter AwsEcrRegistryScanningConfiguration#filter}
        */
        readonly filter: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_registry_scanning_configuration#filter_type AwsEcrRegistryScanningConfiguration#filter_type}
        */
        readonly filterType: string;
    }
    class RepositoryFilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RepositoryFilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RepositoryFilterProperty | cdktn.IResolvable | undefined);
        private _filter?;
        get filter(): string;
        set filter(value: string);
        get filterInput(): string | undefined;
        private _filterType?;
        get filterType(): string;
        set filterType(value: string);
        get filterTypeInput(): string | undefined;
    }
    class RepositoryFilterPropertyList extends cdktn.ComplexList {
        internalValue?: RepositoryFilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RepositoryFilterPropertyOutputReference;
    }
    interface RuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_registry_scanning_configuration#scan_frequency AwsEcrRegistryScanningConfiguration#scan_frequency}
        */
        readonly scanFrequency: string;
        /**
        * repository_filter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_registry_scanning_configuration#repository_filter AwsEcrRegistryScanningConfiguration#repository_filter}
        */
        readonly repositoryFilter: RepositoryFilterProperty[] | cdktn.IResolvable;
    }
    class RulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleProperty | cdktn.IResolvable | undefined);
        private _scanFrequency?;
        get scanFrequency(): string;
        set scanFrequency(value: string);
        get scanFrequencyInput(): string | undefined;
        private _repositoryFilter;
        get repositoryFilter(): RepositoryFilterPropertyList;
        putRepositoryFilter(value: RepositoryFilterProperty[] | cdktn.IResolvable): void;
        get repositoryFilterInput(): cdktn.IResolvable | RepositoryFilterProperty[] | undefined;
    }
    class RulePropertyList extends cdktn.ComplexList {
        internalValue?: RuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulePropertyOutputReference;
    }
}
