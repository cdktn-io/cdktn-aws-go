import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsEcrPullThroughCacheRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_pull_through_cache_rule#credential_arn AwsEcrPullThroughCacheRule#credential_arn}
    */
    readonly credentialArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_pull_through_cache_rule#custom_role_arn AwsEcrPullThroughCacheRule#custom_role_arn}
    */
    readonly customRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_pull_through_cache_rule#ecr_repository_prefix AwsEcrPullThroughCacheRule#ecr_repository_prefix}
    */
    readonly ecrRepositoryPrefix: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_pull_through_cache_rule#id AwsEcrPullThroughCacheRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_pull_through_cache_rule#region AwsEcrPullThroughCacheRule#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_pull_through_cache_rule#upstream_registry_url AwsEcrPullThroughCacheRule#upstream_registry_url}
    */
    readonly upstreamRegistryUrl: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_pull_through_cache_rule#upstream_repository_prefix AwsEcrPullThroughCacheRule#upstream_repository_prefix}
    */
    readonly upstreamRepositoryPrefix?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_pull_through_cache_rule aws_ecr_pull_through_cache_rule}
*/
export declare class AwsEcrPullThroughCacheRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ecr_pull_through_cache_rule";
    /**
    * Generates CDKTN code for importing a AwsEcrPullThroughCacheRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsEcrPullThroughCacheRule to import
    * @param importFromId The id of the existing AwsEcrPullThroughCacheRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_pull_through_cache_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsEcrPullThroughCacheRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_pull_through_cache_rule aws_ecr_pull_through_cache_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsEcrPullThroughCacheRuleConfig
    */
    constructor(scope: Construct, id: string, config: AwsEcrPullThroughCacheRuleConfig);
    private _credentialArn?;
    get credentialArn(): string;
    set credentialArn(value: string);
    resetCredentialArn(): void;
    get credentialArnInput(): string | undefined;
    private _customRoleArn?;
    get customRoleArn(): string;
    set customRoleArn(value: string);
    resetCustomRoleArn(): void;
    get customRoleArnInput(): string | undefined;
    private _ecrRepositoryPrefix?;
    get ecrRepositoryPrefix(): string;
    set ecrRepositoryPrefix(value: string);
    get ecrRepositoryPrefixInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get registryId(): string;
    private _upstreamRegistryUrl?;
    get upstreamRegistryUrl(): string;
    set upstreamRegistryUrl(value: string);
    get upstreamRegistryUrlInput(): string | undefined;
    private _upstreamRepositoryPrefix?;
    get upstreamRepositoryPrefix(): string;
    set upstreamRepositoryPrefix(value: string);
    resetUpstreamRepositoryPrefix(): void;
    get upstreamRepositoryPrefixInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
