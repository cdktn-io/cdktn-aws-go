import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfPullThroughCacheRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecr_pull_through_cache_rule#ecr_repository_prefix DataTfPullThroughCacheRule#ecr_repository_prefix}
    */
    readonly ecrRepositoryPrefix: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecr_pull_through_cache_rule#id DataTfPullThroughCacheRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecr_pull_through_cache_rule#region DataTfPullThroughCacheRule#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecr_pull_through_cache_rule aws_ecr_pull_through_cache_rule}
*/
export declare class DataTfPullThroughCacheRule extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_ecr_pull_through_cache_rule";
    /**
    * Generates CDKTN code for importing a DataTfPullThroughCacheRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfPullThroughCacheRule to import
    * @param importFromId The id of the existing DataTfPullThroughCacheRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecr_pull_through_cache_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfPullThroughCacheRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecr_pull_through_cache_rule aws_ecr_pull_through_cache_rule} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfPullThroughCacheRuleConfig
    */
    constructor(scope: Construct, id: string, config: DataTfPullThroughCacheRuleConfig);
    get credentialArn(): string;
    get customRoleArn(): string;
    private _ecrRepositoryPrefix?;
    get ecrRepositoryPrefix(): string;
    set ecrRepositoryPrefix(value: string);
    get ecrRepositoryPrefixInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get registryId(): string;
    get upstreamRegistryUrl(): string;
    get upstreamRepositoryPrefix(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
