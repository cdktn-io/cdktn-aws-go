import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfReplicationConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_replication_configuration#id TfReplicationConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_replication_configuration#region TfReplicationConfiguration#region}
    */
    readonly region?: string;
    /**
    * replication_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_replication_configuration#replication_configuration TfReplicationConfiguration#replication_configuration}
    */
    readonly replicationConfiguration?: TfReplicationConfiguration.ReplicationConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_replication_configuration aws_ecr_replication_configuration}
*/
export declare class TfReplicationConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ecr_replication_configuration";
    /**
    * Generates CDKTN code for importing a TfReplicationConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfReplicationConfiguration to import
    * @param importFromId The id of the existing TfReplicationConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_replication_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfReplicationConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_replication_configuration aws_ecr_replication_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfReplicationConfigurationConfig = {}
    */
    constructor(scope: Construct, id: string, config?: TfReplicationConfigurationConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get registryId(): string;
    private _replicationConfiguration;
    get replicationConfiguration(): TfReplicationConfiguration.ReplicationConfigurationPropertyOutputReference;
    putReplicationConfiguration(value: TfReplicationConfiguration.ReplicationConfigurationProperty): void;
    resetReplicationConfiguration(): void;
    get replicationConfigurationInput(): TfReplicationConfiguration.ReplicationConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfReplicationConfigurationDestinationPropertyToTerraform(struct?: TfReplicationConfiguration.DestinationProperty | cdktn.IResolvable): any;
export declare function tfReplicationConfigurationDestinationPropertyToHclTerraform(struct?: TfReplicationConfiguration.DestinationProperty | cdktn.IResolvable): any;
export declare function tfReplicationConfigurationRepositoryFilterPropertyToTerraform(struct?: TfReplicationConfiguration.RepositoryFilterProperty | cdktn.IResolvable): any;
export declare function tfReplicationConfigurationRepositoryFilterPropertyToHclTerraform(struct?: TfReplicationConfiguration.RepositoryFilterProperty | cdktn.IResolvable): any;
export declare function tfReplicationConfigurationRulePropertyToTerraform(struct?: TfReplicationConfiguration.RuleProperty | cdktn.IResolvable): any;
export declare function tfReplicationConfigurationRulePropertyToHclTerraform(struct?: TfReplicationConfiguration.RuleProperty | cdktn.IResolvable): any;
export declare function tfReplicationConfigurationReplicationConfigurationPropertyToTerraform(struct?: TfReplicationConfiguration.ReplicationConfigurationPropertyOutputReference | TfReplicationConfiguration.ReplicationConfigurationProperty): any;
export declare function tfReplicationConfigurationReplicationConfigurationPropertyToHclTerraform(struct?: TfReplicationConfiguration.ReplicationConfigurationPropertyOutputReference | TfReplicationConfiguration.ReplicationConfigurationProperty): any;
export declare namespace TfReplicationConfiguration {
    interface DestinationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_replication_configuration#region TfReplicationConfiguration#region}
        */
        readonly region: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_replication_configuration#registry_id TfReplicationConfiguration#registry_id}
        */
        readonly registryId: string;
    }
    class DestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DestinationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DestinationProperty | cdktn.IResolvable | undefined);
        private _region?;
        get region(): string;
        set region(value: string);
        get regionInput(): string | undefined;
        private _registryId?;
        get registryId(): string;
        set registryId(value: string);
        get registryIdInput(): string | undefined;
    }
    class DestinationPropertyList extends cdktn.ComplexList {
        internalValue?: DestinationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DestinationPropertyOutputReference;
    }
    interface RepositoryFilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_replication_configuration#filter TfReplicationConfiguration#filter}
        */
        readonly filter: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_replication_configuration#filter_type TfReplicationConfiguration#filter_type}
        */
        readonly filterType: string;
    }
    class RepositoryFilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RepositoryFilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RepositoryFilterProperty | cdktn.IResolvable | undefined);
        private _filter?;
        get filter(): string;
        set filter(value: string);
        get filterInput(): string | undefined;
        private _filterType?;
        get filterType(): string;
        set filterType(value: string);
        get filterTypeInput(): string | undefined;
    }
    class RepositoryFilterPropertyList extends cdktn.ComplexList {
        internalValue?: RepositoryFilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RepositoryFilterPropertyOutputReference;
    }
    interface RuleProperty {
        /**
        * destination block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_replication_configuration#destination TfReplicationConfiguration#destination}
        */
        readonly destination: DestinationProperty[] | cdktn.IResolvable;
        /**
        * repository_filter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_replication_configuration#repository_filter TfReplicationConfiguration#repository_filter}
        */
        readonly repositoryFilter?: RepositoryFilterProperty[] | cdktn.IResolvable;
    }
    class RulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleProperty | cdktn.IResolvable | undefined);
        private _destination;
        get destination(): DestinationPropertyList;
        putDestination(value: DestinationProperty[] | cdktn.IResolvable): void;
        get destinationInput(): cdktn.IResolvable | DestinationProperty[] | undefined;
        private _repositoryFilter;
        get repositoryFilter(): RepositoryFilterPropertyList;
        putRepositoryFilter(value: RepositoryFilterProperty[] | cdktn.IResolvable): void;
        resetRepositoryFilter(): void;
        get repositoryFilterInput(): cdktn.IResolvable | RepositoryFilterProperty[] | undefined;
    }
    class RulePropertyList extends cdktn.ComplexList {
        internalValue?: RuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulePropertyOutputReference;
    }
    interface ReplicationConfigurationProperty {
        /**
        * rule block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_replication_configuration#rule TfReplicationConfiguration#rule}
        */
        readonly rule: RuleProperty[] | cdktn.IResolvable;
    }
    class ReplicationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ReplicationConfigurationProperty | undefined;
        set internalValue(value: ReplicationConfigurationProperty | undefined);
        private _rule;
        get rule(): RulePropertyList;
        putRule(value: RuleProperty[] | cdktn.IResolvable): void;
        get ruleInput(): cdktn.IResolvable | RuleProperty[] | undefined;
    }
}
