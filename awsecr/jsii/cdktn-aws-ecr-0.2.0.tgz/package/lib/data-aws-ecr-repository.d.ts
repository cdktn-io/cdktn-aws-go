import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfRepositoryConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecr_repository#id DataTfRepository#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecr_repository#name DataTfRepository#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecr_repository#region DataTfRepository#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecr_repository#registry_id DataTfRepository#registry_id}
    */
    readonly registryId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecr_repository#tags DataTfRepository#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecr_repository aws_ecr_repository}
*/
export declare class DataTfRepository extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_ecr_repository";
    /**
    * Generates CDKTN code for importing a DataTfRepository resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfRepository to import
    * @param importFromId The id of the existing DataTfRepository that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecr_repository#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfRepository to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecr_repository aws_ecr_repository} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfRepositoryConfig
    */
    constructor(scope: Construct, id: string, config: DataTfRepositoryConfig);
    get arn(): string;
    private _encryptionConfiguration;
    get encryptionConfiguration(): DataTfRepository.EncryptionConfigurationPropertyList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _imageScanningConfiguration;
    get imageScanningConfiguration(): DataTfRepository.ImageScanningConfigurationPropertyList;
    get imageTagMutability(): string;
    private _imageTagMutabilityExclusionFilter;
    get imageTagMutabilityExclusionFilter(): DataTfRepository.ImageTagMutabilityExclusionFilterPropertyList;
    get mostRecentImageTags(): string[];
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _registryId?;
    get registryId(): string;
    set registryId(value: string);
    resetRegistryId(): void;
    get registryIdInput(): string | undefined;
    get repositoryUrl(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfRepositoryEncryptionConfigurationPropertyToTerraform(struct?: DataTfRepository.EncryptionConfigurationProperty): any;
export declare function dataTfRepositoryEncryptionConfigurationPropertyToHclTerraform(struct?: DataTfRepository.EncryptionConfigurationProperty): any;
export declare function dataTfRepositoryImageScanningConfigurationPropertyToTerraform(struct?: DataTfRepository.ImageScanningConfigurationProperty): any;
export declare function dataTfRepositoryImageScanningConfigurationPropertyToHclTerraform(struct?: DataTfRepository.ImageScanningConfigurationProperty): any;
export declare function dataTfRepositoryImageTagMutabilityExclusionFilterPropertyToTerraform(struct?: DataTfRepository.ImageTagMutabilityExclusionFilterProperty): any;
export declare function dataTfRepositoryImageTagMutabilityExclusionFilterPropertyToHclTerraform(struct?: DataTfRepository.ImageTagMutabilityExclusionFilterProperty): any;
export declare namespace DataTfRepository {
    interface EncryptionConfigurationProperty {
    }
    class EncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EncryptionConfigurationProperty | undefined;
        set internalValue(value: EncryptionConfigurationProperty | undefined);
        get encryptionType(): string;
        get kmsKey(): string;
    }
    class EncryptionConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EncryptionConfigurationPropertyOutputReference;
    }
    interface ImageScanningConfigurationProperty {
    }
    class ImageScanningConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ImageScanningConfigurationProperty | undefined;
        set internalValue(value: ImageScanningConfigurationProperty | undefined);
        get scanOnPush(): cdktn.IResolvable;
    }
    class ImageScanningConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ImageScanningConfigurationPropertyOutputReference;
    }
    interface ImageTagMutabilityExclusionFilterProperty {
    }
    class ImageTagMutabilityExclusionFilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ImageTagMutabilityExclusionFilterProperty | undefined;
        set internalValue(value: ImageTagMutabilityExclusionFilterProperty | undefined);
        get filter(): string;
        get filterType(): string;
    }
    class ImageTagMutabilityExclusionFilterPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ImageTagMutabilityExclusionFilterPropertyOutputReference;
    }
}
