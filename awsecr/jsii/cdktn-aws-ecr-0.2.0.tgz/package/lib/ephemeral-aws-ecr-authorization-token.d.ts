import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface EphemeralTfAuthorizationTokenConfig extends cdktn.TerraformEphemeralMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/ephemeral-resources/ecr_authorization_token#region EphemeralTfAuthorizationToken#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/ephemeral-resources/ecr_authorization_token aws_ecr_authorization_token}
*/
export declare class EphemeralTfAuthorizationToken extends cdktn.TerraformEphemeralResource {
    static readonly tfResourceType = "aws_ecr_authorization_token";
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/ephemeral-resources/ecr_authorization_token aws_ecr_authorization_token} Ephemeral Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EphemeralTfAuthorizationTokenConfig = {}
    */
    constructor(scope: Construct, id: string, config?: EphemeralTfAuthorizationTokenConfig);
    get authorizationToken(): string;
    get expiresAt(): string;
    get password(): string;
    get proxyEndpoint(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get userName(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
