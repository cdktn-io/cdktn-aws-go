import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfRepositoryCreationTemplateConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_repository_creation_template#applied_for TfRepositoryCreationTemplate#applied_for}
    */
    readonly appliedFor: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_repository_creation_template#custom_role_arn TfRepositoryCreationTemplate#custom_role_arn}
    */
    readonly customRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_repository_creation_template#description TfRepositoryCreationTemplate#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_repository_creation_template#id TfRepositoryCreationTemplate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_repository_creation_template#image_tag_mutability TfRepositoryCreationTemplate#image_tag_mutability}
    */
    readonly imageTagMutability?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_repository_creation_template#lifecycle_policy TfRepositoryCreationTemplate#lifecycle_policy}
    */
    readonly lifecyclePolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_repository_creation_template#prefix TfRepositoryCreationTemplate#prefix}
    */
    readonly prefix: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_repository_creation_template#region TfRepositoryCreationTemplate#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_repository_creation_template#repository_policy TfRepositoryCreationTemplate#repository_policy}
    */
    readonly repositoryPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_repository_creation_template#resource_tags TfRepositoryCreationTemplate#resource_tags}
    */
    readonly resourceTags?: {
        [key: string]: string;
    };
    /**
    * encryption_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_repository_creation_template#encryption_configuration TfRepositoryCreationTemplate#encryption_configuration}
    */
    readonly encryptionConfiguration?: TfRepositoryCreationTemplate.EncryptionConfigurationProperty[] | cdktn.IResolvable;
    /**
    * image_tag_mutability_exclusion_filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_repository_creation_template#image_tag_mutability_exclusion_filter TfRepositoryCreationTemplate#image_tag_mutability_exclusion_filter}
    */
    readonly imageTagMutabilityExclusionFilter?: TfRepositoryCreationTemplate.ImageTagMutabilityExclusionFilterProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_repository_creation_template aws_ecr_repository_creation_template}
*/
export declare class TfRepositoryCreationTemplate extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ecr_repository_creation_template";
    /**
    * Generates CDKTN code for importing a TfRepositoryCreationTemplate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfRepositoryCreationTemplate to import
    * @param importFromId The id of the existing TfRepositoryCreationTemplate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_repository_creation_template#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfRepositoryCreationTemplate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_repository_creation_template aws_ecr_repository_creation_template} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfRepositoryCreationTemplateConfig
    */
    constructor(scope: Construct, id: string, config: TfRepositoryCreationTemplateConfig);
    private _appliedFor?;
    get appliedFor(): string[];
    set appliedFor(value: string[]);
    get appliedForInput(): string[] | undefined;
    private _customRoleArn?;
    get customRoleArn(): string;
    set customRoleArn(value: string);
    resetCustomRoleArn(): void;
    get customRoleArnInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _imageTagMutability?;
    get imageTagMutability(): string;
    set imageTagMutability(value: string);
    resetImageTagMutability(): void;
    get imageTagMutabilityInput(): string | undefined;
    private _lifecyclePolicy?;
    get lifecyclePolicy(): string;
    set lifecyclePolicy(value: string);
    resetLifecyclePolicy(): void;
    get lifecyclePolicyInput(): string | undefined;
    private _prefix?;
    get prefix(): string;
    set prefix(value: string);
    get prefixInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get registryId(): string;
    private _repositoryPolicy?;
    get repositoryPolicy(): string;
    set repositoryPolicy(value: string);
    resetRepositoryPolicy(): void;
    get repositoryPolicyInput(): string | undefined;
    private _resourceTags?;
    get resourceTags(): {
        [key: string]: string;
    };
    set resourceTags(value: {
        [key: string]: string;
    });
    resetResourceTags(): void;
    get resourceTagsInput(): {
        [key: string]: string;
    } | undefined;
    private _encryptionConfiguration;
    get encryptionConfiguration(): TfRepositoryCreationTemplate.EncryptionConfigurationPropertyList;
    putEncryptionConfiguration(value: TfRepositoryCreationTemplate.EncryptionConfigurationProperty[] | cdktn.IResolvable): void;
    resetEncryptionConfiguration(): void;
    get encryptionConfigurationInput(): cdktn.IResolvable | TfRepositoryCreationTemplate.EncryptionConfigurationProperty[] | undefined;
    private _imageTagMutabilityExclusionFilter;
    get imageTagMutabilityExclusionFilter(): TfRepositoryCreationTemplate.ImageTagMutabilityExclusionFilterPropertyList;
    putImageTagMutabilityExclusionFilter(value: TfRepositoryCreationTemplate.ImageTagMutabilityExclusionFilterProperty[] | cdktn.IResolvable): void;
    resetImageTagMutabilityExclusionFilter(): void;
    get imageTagMutabilityExclusionFilterInput(): cdktn.IResolvable | TfRepositoryCreationTemplate.ImageTagMutabilityExclusionFilterProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfRepositoryCreationTemplateEncryptionConfigurationPropertyToTerraform(struct?: TfRepositoryCreationTemplate.EncryptionConfigurationProperty | cdktn.IResolvable): any;
export declare function tfRepositoryCreationTemplateEncryptionConfigurationPropertyToHclTerraform(struct?: TfRepositoryCreationTemplate.EncryptionConfigurationProperty | cdktn.IResolvable): any;
export declare function tfRepositoryCreationTemplateImageTagMutabilityExclusionFilterPropertyToTerraform(struct?: TfRepositoryCreationTemplate.ImageTagMutabilityExclusionFilterProperty | cdktn.IResolvable): any;
export declare function tfRepositoryCreationTemplateImageTagMutabilityExclusionFilterPropertyToHclTerraform(struct?: TfRepositoryCreationTemplate.ImageTagMutabilityExclusionFilterProperty | cdktn.IResolvable): any;
export declare namespace TfRepositoryCreationTemplate {
    interface EncryptionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_repository_creation_template#encryption_type TfRepositoryCreationTemplate#encryption_type}
        */
        readonly encryptionType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_repository_creation_template#kms_key TfRepositoryCreationTemplate#kms_key}
        */
        readonly kmsKey?: string;
    }
    class EncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EncryptionConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EncryptionConfigurationProperty | cdktn.IResolvable | undefined);
        private _encryptionType?;
        get encryptionType(): string;
        set encryptionType(value: string);
        resetEncryptionType(): void;
        get encryptionTypeInput(): string | undefined;
        private _kmsKey?;
        get kmsKey(): string;
        set kmsKey(value: string);
        resetKmsKey(): void;
        get kmsKeyInput(): string | undefined;
    }
    class EncryptionConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: EncryptionConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EncryptionConfigurationPropertyOutputReference;
    }
    interface ImageTagMutabilityExclusionFilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_repository_creation_template#filter TfRepositoryCreationTemplate#filter}
        */
        readonly filter: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ecr_repository_creation_template#filter_type TfRepositoryCreationTemplate#filter_type}
        */
        readonly filterType: string;
    }
    class ImageTagMutabilityExclusionFilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ImageTagMutabilityExclusionFilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ImageTagMutabilityExclusionFilterProperty | cdktn.IResolvable | undefined);
        private _filter?;
        get filter(): string;
        set filter(value: string);
        get filterInput(): string | undefined;
        private _filterType?;
        get filterType(): string;
        set filterType(value: string);
        get filterTypeInput(): string | undefined;
    }
    class ImageTagMutabilityExclusionFilterPropertyList extends cdktn.ComplexList {
        internalValue?: ImageTagMutabilityExclusionFilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ImageTagMutabilityExclusionFilterPropertyOutputReference;
    }
}
