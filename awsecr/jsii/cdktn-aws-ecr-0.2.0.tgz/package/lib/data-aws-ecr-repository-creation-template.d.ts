import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfRepositoryCreationTemplateConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecr_repository_creation_template#id DataTfRepositoryCreationTemplate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecr_repository_creation_template#prefix DataTfRepositoryCreationTemplate#prefix}
    */
    readonly prefix: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecr_repository_creation_template#region DataTfRepositoryCreationTemplate#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecr_repository_creation_template#resource_tags DataTfRepositoryCreationTemplate#resource_tags}
    */
    readonly resourceTags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecr_repository_creation_template aws_ecr_repository_creation_template}
*/
export declare class DataTfRepositoryCreationTemplate extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_ecr_repository_creation_template";
    /**
    * Generates CDKTN code for importing a DataTfRepositoryCreationTemplate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfRepositoryCreationTemplate to import
    * @param importFromId The id of the existing DataTfRepositoryCreationTemplate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecr_repository_creation_template#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfRepositoryCreationTemplate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ecr_repository_creation_template aws_ecr_repository_creation_template} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfRepositoryCreationTemplateConfig
    */
    constructor(scope: Construct, id: string, config: DataTfRepositoryCreationTemplateConfig);
    get appliedFor(): string[];
    get customRoleArn(): string;
    get description(): string;
    private _encryptionConfiguration;
    get encryptionConfiguration(): DataTfRepositoryCreationTemplate.EncryptionConfigurationPropertyList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get imageTagMutability(): string;
    private _imageTagMutabilityExclusionFilter;
    get imageTagMutabilityExclusionFilter(): DataTfRepositoryCreationTemplate.ImageTagMutabilityExclusionFilterPropertyList;
    get lifecyclePolicy(): string;
    private _prefix?;
    get prefix(): string;
    set prefix(value: string);
    get prefixInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get registryId(): string;
    get repositoryPolicy(): string;
    private _resourceTags?;
    get resourceTags(): {
        [key: string]: string;
    };
    set resourceTags(value: {
        [key: string]: string;
    });
    resetResourceTags(): void;
    get resourceTagsInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfRepositoryCreationTemplateEncryptionConfigurationPropertyToTerraform(struct?: DataTfRepositoryCreationTemplate.EncryptionConfigurationProperty): any;
export declare function dataTfRepositoryCreationTemplateEncryptionConfigurationPropertyToHclTerraform(struct?: DataTfRepositoryCreationTemplate.EncryptionConfigurationProperty): any;
export declare function dataTfRepositoryCreationTemplateImageTagMutabilityExclusionFilterPropertyToTerraform(struct?: DataTfRepositoryCreationTemplate.ImageTagMutabilityExclusionFilterProperty): any;
export declare function dataTfRepositoryCreationTemplateImageTagMutabilityExclusionFilterPropertyToHclTerraform(struct?: DataTfRepositoryCreationTemplate.ImageTagMutabilityExclusionFilterProperty): any;
export declare namespace DataTfRepositoryCreationTemplate {
    interface EncryptionConfigurationProperty {
    }
    class EncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EncryptionConfigurationProperty | undefined;
        set internalValue(value: EncryptionConfigurationProperty | undefined);
        get encryptionType(): string;
        get kmsKey(): string;
    }
    class EncryptionConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EncryptionConfigurationPropertyOutputReference;
    }
    interface ImageTagMutabilityExclusionFilterProperty {
    }
    class ImageTagMutabilityExclusionFilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ImageTagMutabilityExclusionFilterProperty | undefined;
        set internalValue(value: ImageTagMutabilityExclusionFilterProperty | undefined);
        get filter(): string;
        get filterType(): string;
    }
    class ImageTagMutabilityExclusionFilterPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ImageTagMutabilityExclusionFilterPropertyOutputReference;
    }
}
