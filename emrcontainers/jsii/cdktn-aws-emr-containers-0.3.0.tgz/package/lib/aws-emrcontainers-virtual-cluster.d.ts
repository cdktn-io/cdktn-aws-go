import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsVirtualClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_virtual_cluster#id AwsVirtualCluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_virtual_cluster#name AwsVirtualCluster#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_virtual_cluster#region AwsVirtualCluster#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_virtual_cluster#tags AwsVirtualCluster#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_virtual_cluster#tags_all AwsVirtualCluster#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * container_provider block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_virtual_cluster#container_provider AwsVirtualCluster#container_provider}
    */
    readonly containerProvider: AwsVirtualCluster.ContainerProviderProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_virtual_cluster#timeouts AwsVirtualCluster#timeouts}
    */
    readonly timeouts?: AwsVirtualCluster.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_virtual_cluster aws_emrcontainers_virtual_cluster}
*/
export declare class AwsVirtualCluster extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_emrcontainers_virtual_cluster";
    /**
    * Generates CDKTN code for importing a AwsVirtualCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsVirtualCluster to import
    * @param importFromId The id of the existing AwsVirtualCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_virtual_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsVirtualCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_virtual_cluster aws_emrcontainers_virtual_cluster} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsVirtualClusterConfig
    */
    constructor(scope: Construct, id: string, config: AwsVirtualClusterConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _containerProvider;
    get containerProvider(): AwsVirtualCluster.ContainerProviderPropertyOutputReference;
    putContainerProvider(value: AwsVirtualCluster.ContainerProviderProperty): void;
    get containerProviderInput(): AwsVirtualCluster.ContainerProviderProperty | undefined;
    private _timeouts;
    get timeouts(): AwsVirtualCluster.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsVirtualCluster.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsVirtualCluster.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsVirtualClusterEksInfoPropertyToTerraform(struct?: AwsVirtualCluster.EksInfoPropertyOutputReference | AwsVirtualCluster.EksInfoProperty): any;
export declare function awsVirtualClusterEksInfoPropertyToHclTerraform(struct?: AwsVirtualCluster.EksInfoPropertyOutputReference | AwsVirtualCluster.EksInfoProperty): any;
export declare function awsVirtualClusterInfoPropertyToTerraform(struct?: AwsVirtualCluster.InfoPropertyOutputReference | AwsVirtualCluster.InfoProperty): any;
export declare function awsVirtualClusterInfoPropertyToHclTerraform(struct?: AwsVirtualCluster.InfoPropertyOutputReference | AwsVirtualCluster.InfoProperty): any;
export declare function awsVirtualClusterContainerProviderPropertyToTerraform(struct?: AwsVirtualCluster.ContainerProviderPropertyOutputReference | AwsVirtualCluster.ContainerProviderProperty): any;
export declare function awsVirtualClusterContainerProviderPropertyToHclTerraform(struct?: AwsVirtualCluster.ContainerProviderPropertyOutputReference | AwsVirtualCluster.ContainerProviderProperty): any;
export declare function awsVirtualClusterTimeoutsPropertyToTerraform(struct?: AwsVirtualCluster.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsVirtualClusterTimeoutsPropertyToHclTerraform(struct?: AwsVirtualCluster.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsVirtualCluster {
    interface EksInfoProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_virtual_cluster#namespace AwsVirtualCluster#namespace}
        */
        readonly namespace?: string;
    }
    class EksInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EksInfoProperty | undefined;
        set internalValue(value: EksInfoProperty | undefined);
        private _namespace?;
        get namespace(): string;
        set namespace(value: string);
        resetNamespace(): void;
        get namespaceInput(): string | undefined;
    }
    interface InfoProperty {
        /**
        * eks_info block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_virtual_cluster#eks_info AwsVirtualCluster#eks_info}
        */
        readonly eksInfo: EksInfoProperty;
    }
    class InfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InfoProperty | undefined;
        set internalValue(value: InfoProperty | undefined);
        private _eksInfo;
        get eksInfo(): EksInfoPropertyOutputReference;
        putEksInfo(value: EksInfoProperty): void;
        get eksInfoInput(): EksInfoProperty | undefined;
    }
    interface ContainerProviderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_virtual_cluster#id AwsVirtualCluster#id}
        *
        * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
        * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
        */
        readonly id: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_virtual_cluster#type AwsVirtualCluster#type}
        */
        readonly type: string;
        /**
        * info block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_virtual_cluster#info AwsVirtualCluster#info}
        */
        readonly info: InfoProperty;
    }
    class ContainerProviderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ContainerProviderProperty | undefined;
        set internalValue(value: ContainerProviderProperty | undefined);
        private _id?;
        get id(): string;
        set id(value: string);
        get idInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _info;
        get info(): InfoPropertyOutputReference;
        putInfo(value: InfoProperty): void;
        get infoInput(): InfoProperty | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrcontainers_virtual_cluster#delete AwsVirtualCluster#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
