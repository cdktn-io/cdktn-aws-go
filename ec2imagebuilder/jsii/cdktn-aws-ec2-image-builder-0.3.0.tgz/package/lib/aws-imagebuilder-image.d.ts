import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsImageConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#container_recipe_arn AwsImage#container_recipe_arn}
    */
    readonly containerRecipeArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#distribution_configuration_arn AwsImage#distribution_configuration_arn}
    */
    readonly distributionConfigurationArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#enhanced_image_metadata_enabled AwsImage#enhanced_image_metadata_enabled}
    */
    readonly enhancedImageMetadataEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#execution_role AwsImage#execution_role}
    */
    readonly executionRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#id AwsImage#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#image_recipe_arn AwsImage#image_recipe_arn}
    */
    readonly imageRecipeArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#infrastructure_configuration_arn AwsImage#infrastructure_configuration_arn}
    */
    readonly infrastructureConfigurationArn: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#region AwsImage#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#tags AwsImage#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#tags_all AwsImage#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * image_scanning_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#image_scanning_configuration AwsImage#image_scanning_configuration}
    */
    readonly imageScanningConfiguration?: AwsImage.ImageScanningConfigurationProperty;
    /**
    * image_tests_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#image_tests_configuration AwsImage#image_tests_configuration}
    */
    readonly imageTestsConfiguration?: AwsImage.ImageTestsConfigurationProperty;
    /**
    * logging_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#logging_configuration AwsImage#logging_configuration}
    */
    readonly loggingConfiguration?: AwsImage.LoggingConfigurationProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#timeouts AwsImage#timeouts}
    */
    readonly timeouts?: AwsImage.TimeoutsProperty;
    /**
    * workflow block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#workflow AwsImage#workflow}
    */
    readonly workflow?: AwsImage.WorkflowProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image aws_imagebuilder_image}
*/
export declare class AwsImage extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_imagebuilder_image";
    /**
    * Generates CDKTN code for importing a AwsImage resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsImage to import
    * @param importFromId The id of the existing AwsImage that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsImage to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image aws_imagebuilder_image} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsImageConfig
    */
    constructor(scope: Construct, id: string, config: AwsImageConfig);
    get arn(): string;
    private _containerRecipeArn?;
    get containerRecipeArn(): string;
    set containerRecipeArn(value: string);
    resetContainerRecipeArn(): void;
    get containerRecipeArnInput(): string | undefined;
    get dateCreated(): string;
    private _distributionConfigurationArn?;
    get distributionConfigurationArn(): string;
    set distributionConfigurationArn(value: string);
    resetDistributionConfigurationArn(): void;
    get distributionConfigurationArnInput(): string | undefined;
    private _enhancedImageMetadataEnabled?;
    get enhancedImageMetadataEnabled(): boolean | cdktn.IResolvable;
    set enhancedImageMetadataEnabled(value: boolean | cdktn.IResolvable);
    resetEnhancedImageMetadataEnabled(): void;
    get enhancedImageMetadataEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _executionRole?;
    get executionRole(): string;
    set executionRole(value: string);
    resetExecutionRole(): void;
    get executionRoleInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _imageRecipeArn?;
    get imageRecipeArn(): string;
    set imageRecipeArn(value: string);
    resetImageRecipeArn(): void;
    get imageRecipeArnInput(): string | undefined;
    private _infrastructureConfigurationArn?;
    get infrastructureConfigurationArn(): string;
    set infrastructureConfigurationArn(value: string);
    get infrastructureConfigurationArnInput(): string | undefined;
    get name(): string;
    get osVersion(): string;
    private _outputResources;
    get outputResources(): AwsImage.OutputResourcesPropertyList;
    get platform(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get version(): string;
    private _imageScanningConfiguration;
    get imageScanningConfiguration(): AwsImage.ImageScanningConfigurationPropertyOutputReference;
    putImageScanningConfiguration(value: AwsImage.ImageScanningConfigurationProperty): void;
    resetImageScanningConfiguration(): void;
    get imageScanningConfigurationInput(): AwsImage.ImageScanningConfigurationProperty | undefined;
    private _imageTestsConfiguration;
    get imageTestsConfiguration(): AwsImage.ImageTestsConfigurationPropertyOutputReference;
    putImageTestsConfiguration(value: AwsImage.ImageTestsConfigurationProperty): void;
    resetImageTestsConfiguration(): void;
    get imageTestsConfigurationInput(): AwsImage.ImageTestsConfigurationProperty | undefined;
    private _loggingConfiguration;
    get loggingConfiguration(): AwsImage.LoggingConfigurationPropertyOutputReference;
    putLoggingConfiguration(value: AwsImage.LoggingConfigurationProperty): void;
    resetLoggingConfiguration(): void;
    get loggingConfigurationInput(): AwsImage.LoggingConfigurationProperty | undefined;
    private _timeouts;
    get timeouts(): AwsImage.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsImage.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsImage.TimeoutsProperty | undefined;
    private _workflow;
    get workflow(): AwsImage.WorkflowPropertyList;
    putWorkflow(value: AwsImage.WorkflowProperty[] | cdktn.IResolvable): void;
    resetWorkflow(): void;
    get workflowInput(): cdktn.IResolvable | AwsImage.WorkflowProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsImageAmisPropertyToTerraform(struct?: AwsImage.AmisProperty): any;
export declare function awsImageAmisPropertyToHclTerraform(struct?: AwsImage.AmisProperty): any;
export declare function awsImageContainersPropertyToTerraform(struct?: AwsImage.ContainersProperty): any;
export declare function awsImageContainersPropertyToHclTerraform(struct?: AwsImage.ContainersProperty): any;
export declare function awsImageOutputResourcesPropertyToTerraform(struct?: AwsImage.OutputResourcesProperty): any;
export declare function awsImageOutputResourcesPropertyToHclTerraform(struct?: AwsImage.OutputResourcesProperty): any;
export declare function awsImageEcrConfigurationPropertyToTerraform(struct?: AwsImage.EcrConfigurationPropertyOutputReference | AwsImage.EcrConfigurationProperty): any;
export declare function awsImageEcrConfigurationPropertyToHclTerraform(struct?: AwsImage.EcrConfigurationPropertyOutputReference | AwsImage.EcrConfigurationProperty): any;
export declare function awsImageImageScanningConfigurationPropertyToTerraform(struct?: AwsImage.ImageScanningConfigurationPropertyOutputReference | AwsImage.ImageScanningConfigurationProperty): any;
export declare function awsImageImageScanningConfigurationPropertyToHclTerraform(struct?: AwsImage.ImageScanningConfigurationPropertyOutputReference | AwsImage.ImageScanningConfigurationProperty): any;
export declare function awsImageImageTestsConfigurationPropertyToTerraform(struct?: AwsImage.ImageTestsConfigurationPropertyOutputReference | AwsImage.ImageTestsConfigurationProperty): any;
export declare function awsImageImageTestsConfigurationPropertyToHclTerraform(struct?: AwsImage.ImageTestsConfigurationPropertyOutputReference | AwsImage.ImageTestsConfigurationProperty): any;
export declare function awsImageLoggingConfigurationPropertyToTerraform(struct?: AwsImage.LoggingConfigurationPropertyOutputReference | AwsImage.LoggingConfigurationProperty): any;
export declare function awsImageLoggingConfigurationPropertyToHclTerraform(struct?: AwsImage.LoggingConfigurationPropertyOutputReference | AwsImage.LoggingConfigurationProperty): any;
export declare function awsImageTimeoutsPropertyToTerraform(struct?: AwsImage.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsImageTimeoutsPropertyToHclTerraform(struct?: AwsImage.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsImageParameterPropertyToTerraform(struct?: AwsImage.ParameterProperty | cdktn.IResolvable): any;
export declare function awsImageParameterPropertyToHclTerraform(struct?: AwsImage.ParameterProperty | cdktn.IResolvable): any;
export declare function awsImageWorkflowPropertyToTerraform(struct?: AwsImage.WorkflowProperty | cdktn.IResolvable): any;
export declare function awsImageWorkflowPropertyToHclTerraform(struct?: AwsImage.WorkflowProperty | cdktn.IResolvable): any;
export declare namespace AwsImage {
    interface AmisProperty {
    }
    class AmisPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AmisProperty | undefined;
        set internalValue(value: AmisProperty | undefined);
        get accountId(): string;
        get description(): string;
        get image(): string;
        get name(): string;
        get region(): string;
    }
    class AmisPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AmisPropertyOutputReference;
    }
    interface ContainersProperty {
    }
    class ContainersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ContainersProperty | undefined;
        set internalValue(value: ContainersProperty | undefined);
        get imageUris(): string[];
        get region(): string;
    }
    class ContainersPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ContainersPropertyOutputReference;
    }
    interface OutputResourcesProperty {
    }
    class OutputResourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OutputResourcesProperty | undefined;
        set internalValue(value: OutputResourcesProperty | undefined);
        private _amis;
        get amis(): AmisPropertyList;
        private _containers;
        get containers(): ContainersPropertyList;
    }
    class OutputResourcesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OutputResourcesPropertyOutputReference;
    }
    interface EcrConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#container_tags AwsImage#container_tags}
        */
        readonly containerTags?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#repository_name AwsImage#repository_name}
        */
        readonly repositoryName?: string;
    }
    class EcrConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EcrConfigurationProperty | undefined;
        set internalValue(value: EcrConfigurationProperty | undefined);
        private _containerTags?;
        get containerTags(): string[];
        set containerTags(value: string[]);
        resetContainerTags(): void;
        get containerTagsInput(): string[] | undefined;
        private _repositoryName?;
        get repositoryName(): string;
        set repositoryName(value: string);
        resetRepositoryName(): void;
        get repositoryNameInput(): string | undefined;
    }
    interface ImageScanningConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#image_scanning_enabled AwsImage#image_scanning_enabled}
        */
        readonly imageScanningEnabled?: boolean | cdktn.IResolvable;
        /**
        * ecr_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#ecr_configuration AwsImage#ecr_configuration}
        */
        readonly ecrConfiguration?: EcrConfigurationProperty;
    }
    class ImageScanningConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ImageScanningConfigurationProperty | undefined;
        set internalValue(value: ImageScanningConfigurationProperty | undefined);
        private _imageScanningEnabled?;
        get imageScanningEnabled(): boolean | cdktn.IResolvable;
        set imageScanningEnabled(value: boolean | cdktn.IResolvable);
        resetImageScanningEnabled(): void;
        get imageScanningEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _ecrConfiguration;
        get ecrConfiguration(): EcrConfigurationPropertyOutputReference;
        putEcrConfiguration(value: EcrConfigurationProperty): void;
        resetEcrConfiguration(): void;
        get ecrConfigurationInput(): EcrConfigurationProperty | undefined;
    }
    interface ImageTestsConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#image_tests_enabled AwsImage#image_tests_enabled}
        */
        readonly imageTestsEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#timeout_minutes AwsImage#timeout_minutes}
        */
        readonly timeoutMinutes?: number;
    }
    class ImageTestsConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ImageTestsConfigurationProperty | undefined;
        set internalValue(value: ImageTestsConfigurationProperty | undefined);
        private _imageTestsEnabled?;
        get imageTestsEnabled(): boolean | cdktn.IResolvable;
        set imageTestsEnabled(value: boolean | cdktn.IResolvable);
        resetImageTestsEnabled(): void;
        get imageTestsEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _timeoutMinutes?;
        get timeoutMinutes(): number;
        set timeoutMinutes(value: number);
        resetTimeoutMinutes(): void;
        get timeoutMinutesInput(): number | undefined;
    }
    interface LoggingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#log_group_name AwsImage#log_group_name}
        */
        readonly logGroupName: string;
    }
    class LoggingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LoggingConfigurationProperty | undefined;
        set internalValue(value: LoggingConfigurationProperty | undefined);
        private _logGroupName?;
        get logGroupName(): string;
        set logGroupName(value: string);
        get logGroupNameInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#create AwsImage#create}
        */
        readonly create?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
    }
    interface ParameterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#name AwsImage#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#value AwsImage#value}
        */
        readonly value: string;
    }
    class ParameterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ParameterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ParameterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ParameterPropertyList extends cdktn.ComplexList {
        internalValue?: ParameterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ParameterPropertyOutputReference;
    }
    interface WorkflowProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#on_failure AwsImage#on_failure}
        */
        readonly onFailure?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#parallel_group AwsImage#parallel_group}
        */
        readonly parallelGroup?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#workflow_arn AwsImage#workflow_arn}
        */
        readonly workflowArn: string;
        /**
        * parameter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_image#parameter AwsImage#parameter}
        */
        readonly parameter?: ParameterProperty[] | cdktn.IResolvable;
    }
    class WorkflowPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkflowProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkflowProperty | cdktn.IResolvable | undefined);
        private _onFailure?;
        get onFailure(): string;
        set onFailure(value: string);
        resetOnFailure(): void;
        get onFailureInput(): string | undefined;
        private _parallelGroup?;
        get parallelGroup(): string;
        set parallelGroup(value: string);
        resetParallelGroup(): void;
        get parallelGroupInput(): string | undefined;
        private _workflowArn?;
        get workflowArn(): string;
        set workflowArn(value: string);
        get workflowArnInput(): string | undefined;
        private _parameter;
        get parameter(): ParameterPropertyList;
        putParameter(value: ParameterProperty[] | cdktn.IResolvable): void;
        resetParameter(): void;
        get parameterInput(): cdktn.IResolvable | ParameterProperty[] | undefined;
    }
    class WorkflowPropertyList extends cdktn.ComplexList {
        internalValue?: WorkflowProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkflowPropertyOutputReference;
    }
}
