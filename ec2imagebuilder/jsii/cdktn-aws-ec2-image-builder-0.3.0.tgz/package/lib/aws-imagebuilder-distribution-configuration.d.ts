import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDistributionConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#description AwsDistributionConfiguration#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#id AwsDistributionConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#name AwsDistributionConfiguration#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#region AwsDistributionConfiguration#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#tags AwsDistributionConfiguration#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#tags_all AwsDistributionConfiguration#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * distribution block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#distribution AwsDistributionConfiguration#distribution}
    */
    readonly distribution: AwsDistributionConfiguration.DistributionProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration aws_imagebuilder_distribution_configuration}
*/
export declare class AwsDistributionConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_imagebuilder_distribution_configuration";
    /**
    * Generates CDKTN code for importing a AwsDistributionConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDistributionConfiguration to import
    * @param importFromId The id of the existing AwsDistributionConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDistributionConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration aws_imagebuilder_distribution_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDistributionConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsDistributionConfigurationConfig);
    get arn(): string;
    get dateCreated(): string;
    get dateUpdated(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _distribution;
    get distribution(): AwsDistributionConfiguration.DistributionPropertyList;
    putDistribution(value: AwsDistributionConfiguration.DistributionProperty[] | cdktn.IResolvable): void;
    get distributionInput(): cdktn.IResolvable | AwsDistributionConfiguration.DistributionProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDistributionConfigurationLaunchPermissionPropertyToTerraform(struct?: AwsDistributionConfiguration.LaunchPermissionPropertyOutputReference | AwsDistributionConfiguration.LaunchPermissionProperty): any;
export declare function awsDistributionConfigurationLaunchPermissionPropertyToHclTerraform(struct?: AwsDistributionConfiguration.LaunchPermissionPropertyOutputReference | AwsDistributionConfiguration.LaunchPermissionProperty): any;
export declare function awsDistributionConfigurationAmiDistributionConfigurationPropertyToTerraform(struct?: AwsDistributionConfiguration.AmiDistributionConfigurationPropertyOutputReference | AwsDistributionConfiguration.AmiDistributionConfigurationProperty): any;
export declare function awsDistributionConfigurationAmiDistributionConfigurationPropertyToHclTerraform(struct?: AwsDistributionConfiguration.AmiDistributionConfigurationPropertyOutputReference | AwsDistributionConfiguration.AmiDistributionConfigurationProperty): any;
export declare function awsDistributionConfigurationTargetRepositoryPropertyToTerraform(struct?: AwsDistributionConfiguration.TargetRepositoryPropertyOutputReference | AwsDistributionConfiguration.TargetRepositoryProperty): any;
export declare function awsDistributionConfigurationTargetRepositoryPropertyToHclTerraform(struct?: AwsDistributionConfiguration.TargetRepositoryPropertyOutputReference | AwsDistributionConfiguration.TargetRepositoryProperty): any;
export declare function awsDistributionConfigurationContainerDistributionConfigurationPropertyToTerraform(struct?: AwsDistributionConfiguration.ContainerDistributionConfigurationPropertyOutputReference | AwsDistributionConfiguration.ContainerDistributionConfigurationProperty): any;
export declare function awsDistributionConfigurationContainerDistributionConfigurationPropertyToHclTerraform(struct?: AwsDistributionConfiguration.ContainerDistributionConfigurationPropertyOutputReference | AwsDistributionConfiguration.ContainerDistributionConfigurationProperty): any;
export declare function awsDistributionConfigurationLaunchTemplatePropertyToTerraform(struct?: AwsDistributionConfiguration.LaunchTemplatePropertyOutputReference | AwsDistributionConfiguration.LaunchTemplateProperty): any;
export declare function awsDistributionConfigurationLaunchTemplatePropertyToHclTerraform(struct?: AwsDistributionConfiguration.LaunchTemplatePropertyOutputReference | AwsDistributionConfiguration.LaunchTemplateProperty): any;
export declare function awsDistributionConfigurationSnapshotConfigurationPropertyToTerraform(struct?: AwsDistributionConfiguration.SnapshotConfigurationPropertyOutputReference | AwsDistributionConfiguration.SnapshotConfigurationProperty): any;
export declare function awsDistributionConfigurationSnapshotConfigurationPropertyToHclTerraform(struct?: AwsDistributionConfiguration.SnapshotConfigurationPropertyOutputReference | AwsDistributionConfiguration.SnapshotConfigurationProperty): any;
export declare function awsDistributionConfigurationFastLaunchConfigurationPropertyToTerraform(struct?: AwsDistributionConfiguration.FastLaunchConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDistributionConfigurationFastLaunchConfigurationPropertyToHclTerraform(struct?: AwsDistributionConfiguration.FastLaunchConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDistributionConfigurationLaunchTemplateConfigurationPropertyToTerraform(struct?: AwsDistributionConfiguration.LaunchTemplateConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDistributionConfigurationLaunchTemplateConfigurationPropertyToHclTerraform(struct?: AwsDistributionConfiguration.LaunchTemplateConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDistributionConfigurationS3ExportConfigurationPropertyToTerraform(struct?: AwsDistributionConfiguration.S3ExportConfigurationPropertyOutputReference | AwsDistributionConfiguration.S3ExportConfigurationProperty): any;
export declare function awsDistributionConfigurationS3ExportConfigurationPropertyToHclTerraform(struct?: AwsDistributionConfiguration.S3ExportConfigurationPropertyOutputReference | AwsDistributionConfiguration.S3ExportConfigurationProperty): any;
export declare function awsDistributionConfigurationSsmParameterConfigurationPropertyToTerraform(struct?: AwsDistributionConfiguration.SsmParameterConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDistributionConfigurationSsmParameterConfigurationPropertyToHclTerraform(struct?: AwsDistributionConfiguration.SsmParameterConfigurationProperty | cdktn.IResolvable): any;
export declare function awsDistributionConfigurationDistributionPropertyToTerraform(struct?: AwsDistributionConfiguration.DistributionProperty | cdktn.IResolvable): any;
export declare function awsDistributionConfigurationDistributionPropertyToHclTerraform(struct?: AwsDistributionConfiguration.DistributionProperty | cdktn.IResolvable): any;
export declare namespace AwsDistributionConfiguration {
    interface LaunchPermissionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#organization_arns AwsDistributionConfiguration#organization_arns}
        */
        readonly organizationArns?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#organizational_unit_arns AwsDistributionConfiguration#organizational_unit_arns}
        */
        readonly organizationalUnitArns?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#user_groups AwsDistributionConfiguration#user_groups}
        */
        readonly userGroups?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#user_ids AwsDistributionConfiguration#user_ids}
        */
        readonly userIds?: string[];
    }
    class LaunchPermissionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LaunchPermissionProperty | undefined;
        set internalValue(value: LaunchPermissionProperty | undefined);
        private _organizationArns?;
        get organizationArns(): string[];
        set organizationArns(value: string[]);
        resetOrganizationArns(): void;
        get organizationArnsInput(): string[] | undefined;
        private _organizationalUnitArns?;
        get organizationalUnitArns(): string[];
        set organizationalUnitArns(value: string[]);
        resetOrganizationalUnitArns(): void;
        get organizationalUnitArnsInput(): string[] | undefined;
        private _userGroups?;
        get userGroups(): string[];
        set userGroups(value: string[]);
        resetUserGroups(): void;
        get userGroupsInput(): string[] | undefined;
        private _userIds?;
        get userIds(): string[];
        set userIds(value: string[]);
        resetUserIds(): void;
        get userIdsInput(): string[] | undefined;
    }
    interface AmiDistributionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#ami_tags AwsDistributionConfiguration#ami_tags}
        */
        readonly amiTags?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#description AwsDistributionConfiguration#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#kms_key_id AwsDistributionConfiguration#kms_key_id}
        */
        readonly kmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#name AwsDistributionConfiguration#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#target_account_ids AwsDistributionConfiguration#target_account_ids}
        */
        readonly targetAccountIds?: string[];
        /**
        * launch_permission block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#launch_permission AwsDistributionConfiguration#launch_permission}
        */
        readonly launchPermission?: LaunchPermissionProperty;
    }
    class AmiDistributionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AmiDistributionConfigurationProperty | undefined;
        set internalValue(value: AmiDistributionConfigurationProperty | undefined);
        private _amiTags?;
        get amiTags(): {
            [key: string]: string;
        };
        set amiTags(value: {
            [key: string]: string;
        });
        resetAmiTags(): void;
        get amiTagsInput(): {
            [key: string]: string;
        } | undefined;
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _targetAccountIds?;
        get targetAccountIds(): string[];
        set targetAccountIds(value: string[]);
        resetTargetAccountIds(): void;
        get targetAccountIdsInput(): string[] | undefined;
        private _launchPermission;
        get launchPermission(): LaunchPermissionPropertyOutputReference;
        putLaunchPermission(value: LaunchPermissionProperty): void;
        resetLaunchPermission(): void;
        get launchPermissionInput(): LaunchPermissionProperty | undefined;
    }
    interface TargetRepositoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#repository_name AwsDistributionConfiguration#repository_name}
        */
        readonly repositoryName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#service AwsDistributionConfiguration#service}
        */
        readonly service: string;
    }
    class TargetRepositoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TargetRepositoryProperty | undefined;
        set internalValue(value: TargetRepositoryProperty | undefined);
        private _repositoryName?;
        get repositoryName(): string;
        set repositoryName(value: string);
        get repositoryNameInput(): string | undefined;
        private _service?;
        get service(): string;
        set service(value: string);
        get serviceInput(): string | undefined;
    }
    interface ContainerDistributionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#container_tags AwsDistributionConfiguration#container_tags}
        */
        readonly containerTags?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#description AwsDistributionConfiguration#description}
        */
        readonly description?: string;
        /**
        * target_repository block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#target_repository AwsDistributionConfiguration#target_repository}
        */
        readonly targetRepository: TargetRepositoryProperty;
    }
    class ContainerDistributionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ContainerDistributionConfigurationProperty | undefined;
        set internalValue(value: ContainerDistributionConfigurationProperty | undefined);
        private _containerTags?;
        get containerTags(): string[];
        set containerTags(value: string[]);
        resetContainerTags(): void;
        get containerTagsInput(): string[] | undefined;
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _targetRepository;
        get targetRepository(): TargetRepositoryPropertyOutputReference;
        putTargetRepository(value: TargetRepositoryProperty): void;
        get targetRepositoryInput(): TargetRepositoryProperty | undefined;
    }
    interface LaunchTemplateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#launch_template_id AwsDistributionConfiguration#launch_template_id}
        */
        readonly launchTemplateId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#launch_template_name AwsDistributionConfiguration#launch_template_name}
        */
        readonly launchTemplateName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#launch_template_version AwsDistributionConfiguration#launch_template_version}
        */
        readonly launchTemplateVersion?: string;
    }
    class LaunchTemplatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LaunchTemplateProperty | undefined;
        set internalValue(value: LaunchTemplateProperty | undefined);
        private _launchTemplateId?;
        get launchTemplateId(): string;
        set launchTemplateId(value: string);
        resetLaunchTemplateId(): void;
        get launchTemplateIdInput(): string | undefined;
        private _launchTemplateName?;
        get launchTemplateName(): string;
        set launchTemplateName(value: string);
        resetLaunchTemplateName(): void;
        get launchTemplateNameInput(): string | undefined;
        private _launchTemplateVersion?;
        get launchTemplateVersion(): string;
        set launchTemplateVersion(value: string);
        resetLaunchTemplateVersion(): void;
        get launchTemplateVersionInput(): string | undefined;
    }
    interface SnapshotConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#target_resource_count AwsDistributionConfiguration#target_resource_count}
        */
        readonly targetResourceCount?: number;
    }
    class SnapshotConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SnapshotConfigurationProperty | undefined;
        set internalValue(value: SnapshotConfigurationProperty | undefined);
        private _targetResourceCount?;
        get targetResourceCount(): number;
        set targetResourceCount(value: number);
        resetTargetResourceCount(): void;
        get targetResourceCountInput(): number | undefined;
    }
    interface FastLaunchConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#account_id AwsDistributionConfiguration#account_id}
        */
        readonly accountId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#enabled AwsDistributionConfiguration#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#max_parallel_launches AwsDistributionConfiguration#max_parallel_launches}
        */
        readonly maxParallelLaunches?: number;
        /**
        * launch_template block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#launch_template AwsDistributionConfiguration#launch_template}
        */
        readonly launchTemplate?: LaunchTemplateProperty;
        /**
        * snapshot_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#snapshot_configuration AwsDistributionConfiguration#snapshot_configuration}
        */
        readonly snapshotConfiguration?: SnapshotConfigurationProperty;
    }
    class FastLaunchConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FastLaunchConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FastLaunchConfigurationProperty | cdktn.IResolvable | undefined);
        private _accountId?;
        get accountId(): string;
        set accountId(value: string);
        get accountIdInput(): string | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _maxParallelLaunches?;
        get maxParallelLaunches(): number;
        set maxParallelLaunches(value: number);
        resetMaxParallelLaunches(): void;
        get maxParallelLaunchesInput(): number | undefined;
        private _launchTemplate;
        get launchTemplate(): LaunchTemplatePropertyOutputReference;
        putLaunchTemplate(value: LaunchTemplateProperty): void;
        resetLaunchTemplate(): void;
        get launchTemplateInput(): LaunchTemplateProperty | undefined;
        private _snapshotConfiguration;
        get snapshotConfiguration(): SnapshotConfigurationPropertyOutputReference;
        putSnapshotConfiguration(value: SnapshotConfigurationProperty): void;
        resetSnapshotConfiguration(): void;
        get snapshotConfigurationInput(): SnapshotConfigurationProperty | undefined;
    }
    class FastLaunchConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: FastLaunchConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FastLaunchConfigurationPropertyOutputReference;
    }
    interface LaunchTemplateConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#account_id AwsDistributionConfiguration#account_id}
        */
        readonly accountId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#default AwsDistributionConfiguration#default}
        */
        readonly default?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#launch_template_id AwsDistributionConfiguration#launch_template_id}
        */
        readonly launchTemplateId: string;
    }
    class LaunchTemplateConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LaunchTemplateConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LaunchTemplateConfigurationProperty | cdktn.IResolvable | undefined);
        private _accountId?;
        get accountId(): string;
        set accountId(value: string);
        resetAccountId(): void;
        get accountIdInput(): string | undefined;
        private _default?;
        get default(): boolean | cdktn.IResolvable;
        set default(value: boolean | cdktn.IResolvable);
        resetDefault(): void;
        get defaultInput(): boolean | cdktn.IResolvable | undefined;
        private _launchTemplateId?;
        get launchTemplateId(): string;
        set launchTemplateId(value: string);
        get launchTemplateIdInput(): string | undefined;
    }
    class LaunchTemplateConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: LaunchTemplateConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LaunchTemplateConfigurationPropertyOutputReference;
    }
    interface S3ExportConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#disk_image_format AwsDistributionConfiguration#disk_image_format}
        */
        readonly diskImageFormat: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#role_name AwsDistributionConfiguration#role_name}
        */
        readonly roleName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#s3_bucket AwsDistributionConfiguration#s3_bucket}
        */
        readonly s3Bucket: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#s3_prefix AwsDistributionConfiguration#s3_prefix}
        */
        readonly s3Prefix?: string;
    }
    class S3ExportConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3ExportConfigurationProperty | undefined;
        set internalValue(value: S3ExportConfigurationProperty | undefined);
        private _diskImageFormat?;
        get diskImageFormat(): string;
        set diskImageFormat(value: string);
        get diskImageFormatInput(): string | undefined;
        private _roleName?;
        get roleName(): string;
        set roleName(value: string);
        get roleNameInput(): string | undefined;
        private _s3Bucket?;
        get s3Bucket(): string;
        set s3Bucket(value: string);
        get s3BucketInput(): string | undefined;
        private _s3Prefix?;
        get s3Prefix(): string;
        set s3Prefix(value: string);
        resetS3Prefix(): void;
        get s3PrefixInput(): string | undefined;
    }
    interface SsmParameterConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#ami_account_id AwsDistributionConfiguration#ami_account_id}
        */
        readonly amiAccountId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#data_type AwsDistributionConfiguration#data_type}
        */
        readonly dataType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#parameter_name AwsDistributionConfiguration#parameter_name}
        */
        readonly parameterName: string;
    }
    class SsmParameterConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SsmParameterConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SsmParameterConfigurationProperty | cdktn.IResolvable | undefined);
        private _amiAccountId?;
        get amiAccountId(): string;
        set amiAccountId(value: string);
        resetAmiAccountId(): void;
        get amiAccountIdInput(): string | undefined;
        private _dataType?;
        get dataType(): string;
        set dataType(value: string);
        resetDataType(): void;
        get dataTypeInput(): string | undefined;
        private _parameterName?;
        get parameterName(): string;
        set parameterName(value: string);
        get parameterNameInput(): string | undefined;
    }
    class SsmParameterConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: SsmParameterConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SsmParameterConfigurationPropertyOutputReference;
    }
    interface DistributionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#license_configuration_arns AwsDistributionConfiguration#license_configuration_arns}
        */
        readonly licenseConfigurationArns?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#region AwsDistributionConfiguration#region}
        */
        readonly region: string;
        /**
        * ami_distribution_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#ami_distribution_configuration AwsDistributionConfiguration#ami_distribution_configuration}
        */
        readonly amiDistributionConfiguration?: AmiDistributionConfigurationProperty;
        /**
        * container_distribution_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#container_distribution_configuration AwsDistributionConfiguration#container_distribution_configuration}
        */
        readonly containerDistributionConfiguration?: ContainerDistributionConfigurationProperty;
        /**
        * fast_launch_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#fast_launch_configuration AwsDistributionConfiguration#fast_launch_configuration}
        */
        readonly fastLaunchConfiguration?: FastLaunchConfigurationProperty[] | cdktn.IResolvable;
        /**
        * launch_template_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#launch_template_configuration AwsDistributionConfiguration#launch_template_configuration}
        */
        readonly launchTemplateConfiguration?: LaunchTemplateConfigurationProperty[] | cdktn.IResolvable;
        /**
        * s3_export_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#s3_export_configuration AwsDistributionConfiguration#s3_export_configuration}
        */
        readonly s3ExportConfiguration?: S3ExportConfigurationProperty;
        /**
        * ssm_parameter_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_distribution_configuration#ssm_parameter_configuration AwsDistributionConfiguration#ssm_parameter_configuration}
        */
        readonly ssmParameterConfiguration?: SsmParameterConfigurationProperty[] | cdktn.IResolvable;
    }
    class DistributionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DistributionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DistributionProperty | cdktn.IResolvable | undefined);
        private _licenseConfigurationArns?;
        get licenseConfigurationArns(): string[];
        set licenseConfigurationArns(value: string[]);
        resetLicenseConfigurationArns(): void;
        get licenseConfigurationArnsInput(): string[] | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        get regionInput(): string | undefined;
        private _amiDistributionConfiguration;
        get amiDistributionConfiguration(): AmiDistributionConfigurationPropertyOutputReference;
        putAmiDistributionConfiguration(value: AmiDistributionConfigurationProperty): void;
        resetAmiDistributionConfiguration(): void;
        get amiDistributionConfigurationInput(): AmiDistributionConfigurationProperty | undefined;
        private _containerDistributionConfiguration;
        get containerDistributionConfiguration(): ContainerDistributionConfigurationPropertyOutputReference;
        putContainerDistributionConfiguration(value: ContainerDistributionConfigurationProperty): void;
        resetContainerDistributionConfiguration(): void;
        get containerDistributionConfigurationInput(): ContainerDistributionConfigurationProperty | undefined;
        private _fastLaunchConfiguration;
        get fastLaunchConfiguration(): FastLaunchConfigurationPropertyList;
        putFastLaunchConfiguration(value: FastLaunchConfigurationProperty[] | cdktn.IResolvable): void;
        resetFastLaunchConfiguration(): void;
        get fastLaunchConfigurationInput(): cdktn.IResolvable | FastLaunchConfigurationProperty[] | undefined;
        private _launchTemplateConfiguration;
        get launchTemplateConfiguration(): LaunchTemplateConfigurationPropertyList;
        putLaunchTemplateConfiguration(value: LaunchTemplateConfigurationProperty[] | cdktn.IResolvable): void;
        resetLaunchTemplateConfiguration(): void;
        get launchTemplateConfigurationInput(): cdktn.IResolvable | LaunchTemplateConfigurationProperty[] | undefined;
        private _s3ExportConfiguration;
        get s3ExportConfiguration(): S3ExportConfigurationPropertyOutputReference;
        putS3ExportConfiguration(value: S3ExportConfigurationProperty): void;
        resetS3ExportConfiguration(): void;
        get s3ExportConfigurationInput(): S3ExportConfigurationProperty | undefined;
        private _ssmParameterConfiguration;
        get ssmParameterConfiguration(): SsmParameterConfigurationPropertyList;
        putSsmParameterConfiguration(value: SsmParameterConfigurationProperty[] | cdktn.IResolvable): void;
        resetSsmParameterConfiguration(): void;
        get ssmParameterConfigurationInput(): cdktn.IResolvable | SsmParameterConfigurationProperty[] | undefined;
    }
    class DistributionPropertyList extends cdktn.ComplexList {
        internalValue?: DistributionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DistributionPropertyOutputReference;
    }
}
