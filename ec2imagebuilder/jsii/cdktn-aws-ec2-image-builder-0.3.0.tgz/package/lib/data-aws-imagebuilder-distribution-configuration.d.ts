import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsDistributionConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/imagebuilder_distribution_configuration#arn DataAwsDistributionConfiguration#arn}
    */
    readonly arn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/imagebuilder_distribution_configuration#id DataAwsDistributionConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/imagebuilder_distribution_configuration#region DataAwsDistributionConfiguration#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/imagebuilder_distribution_configuration#tags DataAwsDistributionConfiguration#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/imagebuilder_distribution_configuration aws_imagebuilder_distribution_configuration}
*/
export declare class DataAwsDistributionConfiguration extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_imagebuilder_distribution_configuration";
    /**
    * Generates CDKTN code for importing a DataAwsDistributionConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsDistributionConfiguration to import
    * @param importFromId The id of the existing DataAwsDistributionConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/imagebuilder_distribution_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsDistributionConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/imagebuilder_distribution_configuration aws_imagebuilder_distribution_configuration} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsDistributionConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsDistributionConfigurationConfig);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    get arnInput(): string | undefined;
    get dateCreated(): string;
    get dateUpdated(): string;
    get description(): string;
    private _distribution;
    get distribution(): DataAwsDistributionConfiguration.DistributionPropertyList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get name(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsDistributionConfigurationLaunchPermissionPropertyToTerraform(struct?: DataAwsDistributionConfiguration.LaunchPermissionProperty): any;
export declare function dataAwsDistributionConfigurationLaunchPermissionPropertyToHclTerraform(struct?: DataAwsDistributionConfiguration.LaunchPermissionProperty): any;
export declare function dataAwsDistributionConfigurationAmiDistributionConfigurationPropertyToTerraform(struct?: DataAwsDistributionConfiguration.AmiDistributionConfigurationProperty): any;
export declare function dataAwsDistributionConfigurationAmiDistributionConfigurationPropertyToHclTerraform(struct?: DataAwsDistributionConfiguration.AmiDistributionConfigurationProperty): any;
export declare function dataAwsDistributionConfigurationTargetRepositoryPropertyToTerraform(struct?: DataAwsDistributionConfiguration.TargetRepositoryProperty): any;
export declare function dataAwsDistributionConfigurationTargetRepositoryPropertyToHclTerraform(struct?: DataAwsDistributionConfiguration.TargetRepositoryProperty): any;
export declare function dataAwsDistributionConfigurationContainerDistributionConfigurationPropertyToTerraform(struct?: DataAwsDistributionConfiguration.ContainerDistributionConfigurationProperty): any;
export declare function dataAwsDistributionConfigurationContainerDistributionConfigurationPropertyToHclTerraform(struct?: DataAwsDistributionConfiguration.ContainerDistributionConfigurationProperty): any;
export declare function dataAwsDistributionConfigurationLaunchTemplatePropertyToTerraform(struct?: DataAwsDistributionConfiguration.LaunchTemplateProperty): any;
export declare function dataAwsDistributionConfigurationLaunchTemplatePropertyToHclTerraform(struct?: DataAwsDistributionConfiguration.LaunchTemplateProperty): any;
export declare function dataAwsDistributionConfigurationSnapshotConfigurationPropertyToTerraform(struct?: DataAwsDistributionConfiguration.SnapshotConfigurationProperty): any;
export declare function dataAwsDistributionConfigurationSnapshotConfigurationPropertyToHclTerraform(struct?: DataAwsDistributionConfiguration.SnapshotConfigurationProperty): any;
export declare function dataAwsDistributionConfigurationFastLaunchConfigurationPropertyToTerraform(struct?: DataAwsDistributionConfiguration.FastLaunchConfigurationProperty): any;
export declare function dataAwsDistributionConfigurationFastLaunchConfigurationPropertyToHclTerraform(struct?: DataAwsDistributionConfiguration.FastLaunchConfigurationProperty): any;
export declare function dataAwsDistributionConfigurationLaunchTemplateConfigurationPropertyToTerraform(struct?: DataAwsDistributionConfiguration.LaunchTemplateConfigurationProperty): any;
export declare function dataAwsDistributionConfigurationLaunchTemplateConfigurationPropertyToHclTerraform(struct?: DataAwsDistributionConfiguration.LaunchTemplateConfigurationProperty): any;
export declare function dataAwsDistributionConfigurationS3ExportConfigurationPropertyToTerraform(struct?: DataAwsDistributionConfiguration.S3ExportConfigurationProperty): any;
export declare function dataAwsDistributionConfigurationS3ExportConfigurationPropertyToHclTerraform(struct?: DataAwsDistributionConfiguration.S3ExportConfigurationProperty): any;
export declare function dataAwsDistributionConfigurationSsmParameterConfigurationPropertyToTerraform(struct?: DataAwsDistributionConfiguration.SsmParameterConfigurationProperty): any;
export declare function dataAwsDistributionConfigurationSsmParameterConfigurationPropertyToHclTerraform(struct?: DataAwsDistributionConfiguration.SsmParameterConfigurationProperty): any;
export declare function dataAwsDistributionConfigurationDistributionPropertyToTerraform(struct?: DataAwsDistributionConfiguration.DistributionProperty): any;
export declare function dataAwsDistributionConfigurationDistributionPropertyToHclTerraform(struct?: DataAwsDistributionConfiguration.DistributionProperty): any;
export declare namespace DataAwsDistributionConfiguration {
    interface LaunchPermissionProperty {
    }
    class LaunchPermissionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LaunchPermissionProperty | undefined;
        set internalValue(value: LaunchPermissionProperty | undefined);
        get organizationArns(): string[];
        get organizationalUnitArns(): string[];
        get userGroups(): string[];
        get userIds(): string[];
    }
    class LaunchPermissionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LaunchPermissionPropertyOutputReference;
    }
    interface AmiDistributionConfigurationProperty {
    }
    class AmiDistributionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AmiDistributionConfigurationProperty | undefined;
        set internalValue(value: AmiDistributionConfigurationProperty | undefined);
        private _amiTags;
        get amiTags(): cdktn.StringMap;
        get description(): string;
        get kmsKeyId(): string;
        private _launchPermission;
        get launchPermission(): LaunchPermissionPropertyList;
        get name(): string;
        get targetAccountIds(): string[];
    }
    class AmiDistributionConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AmiDistributionConfigurationPropertyOutputReference;
    }
    interface TargetRepositoryProperty {
    }
    class TargetRepositoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetRepositoryProperty | undefined;
        set internalValue(value: TargetRepositoryProperty | undefined);
        get repositoryName(): string;
        get service(): string;
    }
    class TargetRepositoryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetRepositoryPropertyOutputReference;
    }
    interface ContainerDistributionConfigurationProperty {
    }
    class ContainerDistributionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ContainerDistributionConfigurationProperty | undefined;
        set internalValue(value: ContainerDistributionConfigurationProperty | undefined);
        get containerTags(): string[];
        get description(): string;
        private _targetRepository;
        get targetRepository(): TargetRepositoryPropertyList;
    }
    class ContainerDistributionConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ContainerDistributionConfigurationPropertyOutputReference;
    }
    interface LaunchTemplateProperty {
    }
    class LaunchTemplatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LaunchTemplateProperty | undefined;
        set internalValue(value: LaunchTemplateProperty | undefined);
        get launchTemplateId(): string;
        get launchTemplateName(): string;
        get launchTemplateVersion(): string;
    }
    class LaunchTemplatePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LaunchTemplatePropertyOutputReference;
    }
    interface SnapshotConfigurationProperty {
    }
    class SnapshotConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SnapshotConfigurationProperty | undefined;
        set internalValue(value: SnapshotConfigurationProperty | undefined);
        get targetResourceCount(): number;
    }
    class SnapshotConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SnapshotConfigurationPropertyOutputReference;
    }
    interface FastLaunchConfigurationProperty {
    }
    class FastLaunchConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FastLaunchConfigurationProperty | undefined;
        set internalValue(value: FastLaunchConfigurationProperty | undefined);
        get accountId(): string;
        get enabled(): cdktn.IResolvable;
        private _launchTemplate;
        get launchTemplate(): LaunchTemplatePropertyList;
        get maxParallelLaunches(): number;
        private _snapshotConfiguration;
        get snapshotConfiguration(): SnapshotConfigurationPropertyList;
    }
    class FastLaunchConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FastLaunchConfigurationPropertyOutputReference;
    }
    interface LaunchTemplateConfigurationProperty {
    }
    class LaunchTemplateConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LaunchTemplateConfigurationProperty | undefined;
        set internalValue(value: LaunchTemplateConfigurationProperty | undefined);
        get accountId(): string;
        get default(): cdktn.IResolvable;
        get launchTemplateId(): string;
    }
    class LaunchTemplateConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LaunchTemplateConfigurationPropertyOutputReference;
    }
    interface S3ExportConfigurationProperty {
    }
    class S3ExportConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3ExportConfigurationProperty | undefined;
        set internalValue(value: S3ExportConfigurationProperty | undefined);
        get diskImageFormat(): string;
        get roleName(): string;
        get s3Bucket(): string;
        get s3Prefix(): string;
    }
    class S3ExportConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3ExportConfigurationPropertyOutputReference;
    }
    interface SsmParameterConfigurationProperty {
    }
    class SsmParameterConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SsmParameterConfigurationProperty | undefined;
        set internalValue(value: SsmParameterConfigurationProperty | undefined);
        get amiAccountId(): string;
        get dataType(): string;
        get parameterName(): string;
    }
    class SsmParameterConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SsmParameterConfigurationPropertyOutputReference;
    }
    interface DistributionProperty {
    }
    class DistributionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DistributionProperty | undefined;
        set internalValue(value: DistributionProperty | undefined);
        private _amiDistributionConfiguration;
        get amiDistributionConfiguration(): AmiDistributionConfigurationPropertyList;
        private _containerDistributionConfiguration;
        get containerDistributionConfiguration(): ContainerDistributionConfigurationPropertyList;
        private _fastLaunchConfiguration;
        get fastLaunchConfiguration(): FastLaunchConfigurationPropertyList;
        private _launchTemplateConfiguration;
        get launchTemplateConfiguration(): LaunchTemplateConfigurationPropertyList;
        get licenseConfigurationArns(): string[];
        get region(): string;
        private _s3ExportConfiguration;
        get s3ExportConfiguration(): S3ExportConfigurationPropertyList;
        private _ssmParameterConfiguration;
        get ssmParameterConfiguration(): SsmParameterConfigurationPropertyList;
    }
    class DistributionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DistributionPropertyOutputReference;
    }
}
