import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsImagePipelineConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/imagebuilder_image_pipeline#arn DataAwsImagePipeline#arn}
    */
    readonly arn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/imagebuilder_image_pipeline#id DataAwsImagePipeline#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/imagebuilder_image_pipeline#region DataAwsImagePipeline#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/imagebuilder_image_pipeline#tags DataAwsImagePipeline#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/imagebuilder_image_pipeline aws_imagebuilder_image_pipeline}
*/
export declare class DataAwsImagePipeline extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_imagebuilder_image_pipeline";
    /**
    * Generates CDKTN code for importing a DataAwsImagePipeline resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsImagePipeline to import
    * @param importFromId The id of the existing DataAwsImagePipeline that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/imagebuilder_image_pipeline#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsImagePipeline to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/imagebuilder_image_pipeline aws_imagebuilder_image_pipeline} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsImagePipelineConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsImagePipelineConfig);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    get arnInput(): string | undefined;
    get containerRecipeArn(): string;
    get dateCreated(): string;
    get dateLastRun(): string;
    get dateNextRun(): string;
    get dateUpdated(): string;
    get description(): string;
    get distributionConfigurationArn(): string;
    get enhancedImageMetadataEnabled(): cdktn.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get imageRecipeArn(): string;
    private _imageScanningConfiguration;
    get imageScanningConfiguration(): DataAwsImagePipeline.ImageScanningConfigurationPropertyList;
    private _imageTestsConfiguration;
    get imageTestsConfiguration(): DataAwsImagePipeline.ImageTestsConfigurationPropertyList;
    get infrastructureConfigurationArn(): string;
    get name(): string;
    get platform(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _schedule;
    get schedule(): DataAwsImagePipeline.SchedulePropertyList;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsImagePipelineEcrConfigurationPropertyToTerraform(struct?: DataAwsImagePipeline.EcrConfigurationProperty): any;
export declare function dataAwsImagePipelineEcrConfigurationPropertyToHclTerraform(struct?: DataAwsImagePipeline.EcrConfigurationProperty): any;
export declare function dataAwsImagePipelineImageScanningConfigurationPropertyToTerraform(struct?: DataAwsImagePipeline.ImageScanningConfigurationProperty): any;
export declare function dataAwsImagePipelineImageScanningConfigurationPropertyToHclTerraform(struct?: DataAwsImagePipeline.ImageScanningConfigurationProperty): any;
export declare function dataAwsImagePipelineImageTestsConfigurationPropertyToTerraform(struct?: DataAwsImagePipeline.ImageTestsConfigurationProperty): any;
export declare function dataAwsImagePipelineImageTestsConfigurationPropertyToHclTerraform(struct?: DataAwsImagePipeline.ImageTestsConfigurationProperty): any;
export declare function dataAwsImagePipelineSchedulePropertyToTerraform(struct?: DataAwsImagePipeline.ScheduleProperty): any;
export declare function dataAwsImagePipelineSchedulePropertyToHclTerraform(struct?: DataAwsImagePipeline.ScheduleProperty): any;
export declare namespace DataAwsImagePipeline {
    interface EcrConfigurationProperty {
    }
    class EcrConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EcrConfigurationProperty | undefined;
        set internalValue(value: EcrConfigurationProperty | undefined);
        get containerTags(): string[];
        get repositoryName(): string;
    }
    class EcrConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EcrConfigurationPropertyOutputReference;
    }
    interface ImageScanningConfigurationProperty {
    }
    class ImageScanningConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ImageScanningConfigurationProperty | undefined;
        set internalValue(value: ImageScanningConfigurationProperty | undefined);
        private _ecrConfiguration;
        get ecrConfiguration(): EcrConfigurationPropertyList;
        get imageScanningEnabled(): cdktn.IResolvable;
    }
    class ImageScanningConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ImageScanningConfigurationPropertyOutputReference;
    }
    interface ImageTestsConfigurationProperty {
    }
    class ImageTestsConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ImageTestsConfigurationProperty | undefined;
        set internalValue(value: ImageTestsConfigurationProperty | undefined);
        get imageTestsEnabled(): cdktn.IResolvable;
        get timeoutMinutes(): number;
    }
    class ImageTestsConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ImageTestsConfigurationPropertyOutputReference;
    }
    interface ScheduleProperty {
    }
    class SchedulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ScheduleProperty | undefined;
        set internalValue(value: ScheduleProperty | undefined);
        get pipelineExecutionStartCondition(): string;
        get scheduleExpression(): string;
    }
    class SchedulePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SchedulePropertyOutputReference;
    }
}
