import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsInfrastructureConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_infrastructure_configuration#description AwsInfrastructureConfiguration#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_infrastructure_configuration#id AwsInfrastructureConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_infrastructure_configuration#instance_profile_name AwsInfrastructureConfiguration#instance_profile_name}
    */
    readonly instanceProfileName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_infrastructure_configuration#instance_types AwsInfrastructureConfiguration#instance_types}
    */
    readonly instanceTypes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_infrastructure_configuration#key_pair AwsInfrastructureConfiguration#key_pair}
    */
    readonly keyPair?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_infrastructure_configuration#name AwsInfrastructureConfiguration#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_infrastructure_configuration#region AwsInfrastructureConfiguration#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_infrastructure_configuration#resource_tags AwsInfrastructureConfiguration#resource_tags}
    */
    readonly resourceTags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_infrastructure_configuration#security_group_ids AwsInfrastructureConfiguration#security_group_ids}
    */
    readonly securityGroupIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_infrastructure_configuration#sns_topic_arn AwsInfrastructureConfiguration#sns_topic_arn}
    */
    readonly snsTopicArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_infrastructure_configuration#subnet_id AwsInfrastructureConfiguration#subnet_id}
    */
    readonly subnetId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_infrastructure_configuration#tags AwsInfrastructureConfiguration#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_infrastructure_configuration#tags_all AwsInfrastructureConfiguration#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_infrastructure_configuration#terminate_instance_on_failure AwsInfrastructureConfiguration#terminate_instance_on_failure}
    */
    readonly terminateInstanceOnFailure?: boolean | cdktn.IResolvable;
    /**
    * instance_metadata_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_infrastructure_configuration#instance_metadata_options AwsInfrastructureConfiguration#instance_metadata_options}
    */
    readonly instanceMetadataOptions?: AwsInfrastructureConfiguration.InstanceMetadataOptionsProperty;
    /**
    * logging block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_infrastructure_configuration#logging AwsInfrastructureConfiguration#logging}
    */
    readonly logging?: AwsInfrastructureConfiguration.LoggingProperty;
    /**
    * placement block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_infrastructure_configuration#placement AwsInfrastructureConfiguration#placement}
    */
    readonly placement?: AwsInfrastructureConfiguration.PlacementProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_infrastructure_configuration aws_imagebuilder_infrastructure_configuration}
*/
export declare class AwsInfrastructureConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_imagebuilder_infrastructure_configuration";
    /**
    * Generates CDKTN code for importing a AwsInfrastructureConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsInfrastructureConfiguration to import
    * @param importFromId The id of the existing AwsInfrastructureConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_infrastructure_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsInfrastructureConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_infrastructure_configuration aws_imagebuilder_infrastructure_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsInfrastructureConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsInfrastructureConfigurationConfig);
    get arn(): string;
    get dateCreated(): string;
    get dateUpdated(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceProfileName?;
    get instanceProfileName(): string;
    set instanceProfileName(value: string);
    get instanceProfileNameInput(): string | undefined;
    private _instanceTypes?;
    get instanceTypes(): string[];
    set instanceTypes(value: string[]);
    resetInstanceTypes(): void;
    get instanceTypesInput(): string[] | undefined;
    private _keyPair?;
    get keyPair(): string;
    set keyPair(value: string);
    resetKeyPair(): void;
    get keyPairInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourceTags?;
    get resourceTags(): {
        [key: string]: string;
    };
    set resourceTags(value: {
        [key: string]: string;
    });
    resetResourceTags(): void;
    get resourceTagsInput(): {
        [key: string]: string;
    } | undefined;
    private _securityGroupIds?;
    get securityGroupIds(): string[];
    set securityGroupIds(value: string[]);
    resetSecurityGroupIds(): void;
    get securityGroupIdsInput(): string[] | undefined;
    private _snsTopicArn?;
    get snsTopicArn(): string;
    set snsTopicArn(value: string);
    resetSnsTopicArn(): void;
    get snsTopicArnInput(): string | undefined;
    private _subnetId?;
    get subnetId(): string;
    set subnetId(value: string);
    resetSubnetId(): void;
    get subnetIdInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _terminateInstanceOnFailure?;
    get terminateInstanceOnFailure(): boolean | cdktn.IResolvable;
    set terminateInstanceOnFailure(value: boolean | cdktn.IResolvable);
    resetTerminateInstanceOnFailure(): void;
    get terminateInstanceOnFailureInput(): boolean | cdktn.IResolvable | undefined;
    private _instanceMetadataOptions;
    get instanceMetadataOptions(): AwsInfrastructureConfiguration.InstanceMetadataOptionsPropertyOutputReference;
    putInstanceMetadataOptions(value: AwsInfrastructureConfiguration.InstanceMetadataOptionsProperty): void;
    resetInstanceMetadataOptions(): void;
    get instanceMetadataOptionsInput(): AwsInfrastructureConfiguration.InstanceMetadataOptionsProperty | undefined;
    private _logging;
    get logging(): AwsInfrastructureConfiguration.LoggingPropertyOutputReference;
    putLogging(value: AwsInfrastructureConfiguration.LoggingProperty): void;
    resetLogging(): void;
    get loggingInput(): AwsInfrastructureConfiguration.LoggingProperty | undefined;
    private _placement;
    get placement(): AwsInfrastructureConfiguration.PlacementPropertyOutputReference;
    putPlacement(value: AwsInfrastructureConfiguration.PlacementProperty): void;
    resetPlacement(): void;
    get placementInput(): AwsInfrastructureConfiguration.PlacementProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsInfrastructureConfigurationInstanceMetadataOptionsPropertyToTerraform(struct?: AwsInfrastructureConfiguration.InstanceMetadataOptionsPropertyOutputReference | AwsInfrastructureConfiguration.InstanceMetadataOptionsProperty): any;
export declare function awsInfrastructureConfigurationInstanceMetadataOptionsPropertyToHclTerraform(struct?: AwsInfrastructureConfiguration.InstanceMetadataOptionsPropertyOutputReference | AwsInfrastructureConfiguration.InstanceMetadataOptionsProperty): any;
export declare function awsInfrastructureConfigurationS3LogsPropertyToTerraform(struct?: AwsInfrastructureConfiguration.S3LogsPropertyOutputReference | AwsInfrastructureConfiguration.S3LogsProperty): any;
export declare function awsInfrastructureConfigurationS3LogsPropertyToHclTerraform(struct?: AwsInfrastructureConfiguration.S3LogsPropertyOutputReference | AwsInfrastructureConfiguration.S3LogsProperty): any;
export declare function awsInfrastructureConfigurationLoggingPropertyToTerraform(struct?: AwsInfrastructureConfiguration.LoggingPropertyOutputReference | AwsInfrastructureConfiguration.LoggingProperty): any;
export declare function awsInfrastructureConfigurationLoggingPropertyToHclTerraform(struct?: AwsInfrastructureConfiguration.LoggingPropertyOutputReference | AwsInfrastructureConfiguration.LoggingProperty): any;
export declare function awsInfrastructureConfigurationPlacementPropertyToTerraform(struct?: AwsInfrastructureConfiguration.PlacementPropertyOutputReference | AwsInfrastructureConfiguration.PlacementProperty): any;
export declare function awsInfrastructureConfigurationPlacementPropertyToHclTerraform(struct?: AwsInfrastructureConfiguration.PlacementPropertyOutputReference | AwsInfrastructureConfiguration.PlacementProperty): any;
export declare namespace AwsInfrastructureConfiguration {
    interface InstanceMetadataOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_infrastructure_configuration#http_put_response_hop_limit AwsInfrastructureConfiguration#http_put_response_hop_limit}
        */
        readonly httpPutResponseHopLimit?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_infrastructure_configuration#http_tokens AwsInfrastructureConfiguration#http_tokens}
        */
        readonly httpTokens?: string;
    }
    class InstanceMetadataOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InstanceMetadataOptionsProperty | undefined;
        set internalValue(value: InstanceMetadataOptionsProperty | undefined);
        private _httpPutResponseHopLimit?;
        get httpPutResponseHopLimit(): number;
        set httpPutResponseHopLimit(value: number);
        resetHttpPutResponseHopLimit(): void;
        get httpPutResponseHopLimitInput(): number | undefined;
        private _httpTokens?;
        get httpTokens(): string;
        set httpTokens(value: string);
        resetHttpTokens(): void;
        get httpTokensInput(): string | undefined;
    }
    interface S3LogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_infrastructure_configuration#s3_bucket_name AwsInfrastructureConfiguration#s3_bucket_name}
        */
        readonly s3BucketName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_infrastructure_configuration#s3_key_prefix AwsInfrastructureConfiguration#s3_key_prefix}
        */
        readonly s3KeyPrefix?: string;
    }
    class S3LogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3LogsProperty | undefined;
        set internalValue(value: S3LogsProperty | undefined);
        private _s3BucketName?;
        get s3BucketName(): string;
        set s3BucketName(value: string);
        get s3BucketNameInput(): string | undefined;
        private _s3KeyPrefix?;
        get s3KeyPrefix(): string;
        set s3KeyPrefix(value: string);
        resetS3KeyPrefix(): void;
        get s3KeyPrefixInput(): string | undefined;
    }
    interface LoggingProperty {
        /**
        * s3_logs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_infrastructure_configuration#s3_logs AwsInfrastructureConfiguration#s3_logs}
        */
        readonly s3Logs: S3LogsProperty;
    }
    class LoggingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LoggingProperty | undefined;
        set internalValue(value: LoggingProperty | undefined);
        private _s3Logs;
        get s3Logs(): S3LogsPropertyOutputReference;
        putS3Logs(value: S3LogsProperty): void;
        get s3LogsInput(): S3LogsProperty | undefined;
    }
    interface PlacementProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_infrastructure_configuration#availability_zone AwsInfrastructureConfiguration#availability_zone}
        */
        readonly availabilityZone?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_infrastructure_configuration#host_id AwsInfrastructureConfiguration#host_id}
        */
        readonly hostId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_infrastructure_configuration#host_resource_group_arn AwsInfrastructureConfiguration#host_resource_group_arn}
        */
        readonly hostResourceGroupArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_infrastructure_configuration#tenancy AwsInfrastructureConfiguration#tenancy}
        */
        readonly tenancy?: string;
    }
    class PlacementPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PlacementProperty | undefined;
        set internalValue(value: PlacementProperty | undefined);
        private _availabilityZone?;
        get availabilityZone(): string;
        set availabilityZone(value: string);
        resetAvailabilityZone(): void;
        get availabilityZoneInput(): string | undefined;
        private _hostId?;
        get hostId(): string;
        set hostId(value: string);
        resetHostId(): void;
        get hostIdInput(): string | undefined;
        private _hostResourceGroupArn?;
        get hostResourceGroupArn(): string;
        set hostResourceGroupArn(value: string);
        resetHostResourceGroupArn(): void;
        get hostResourceGroupArnInput(): string | undefined;
        private _tenancy?;
        get tenancy(): string;
        set tenancy(value: string);
        resetTenancy(): void;
        get tenancyInput(): string | undefined;
    }
}
