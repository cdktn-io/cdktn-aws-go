import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsLifecyclePolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_lifecycle_policy#description AwsLifecyclePolicy#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_lifecycle_policy#execution_role AwsLifecyclePolicy#execution_role}
    */
    readonly executionRole: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_lifecycle_policy#name AwsLifecyclePolicy#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_lifecycle_policy#region AwsLifecyclePolicy#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_lifecycle_policy#resource_type AwsLifecyclePolicy#resource_type}
    */
    readonly resourceType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_lifecycle_policy#status AwsLifecyclePolicy#status}
    */
    readonly status?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_lifecycle_policy#tags AwsLifecyclePolicy#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * policy_detail block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_lifecycle_policy#policy_detail AwsLifecyclePolicy#policy_detail}
    */
    readonly policyDetail?: AwsLifecyclePolicy.PolicyDetailProperty[] | cdktn.IResolvable;
    /**
    * resource_selection block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_lifecycle_policy#resource_selection AwsLifecyclePolicy#resource_selection}
    */
    readonly resourceSelection?: AwsLifecyclePolicy.ResourceSelectionProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_lifecycle_policy aws_imagebuilder_lifecycle_policy}
*/
export declare class AwsLifecyclePolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_imagebuilder_lifecycle_policy";
    /**
    * Generates CDKTN code for importing a AwsLifecyclePolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsLifecyclePolicy to import
    * @param importFromId The id of the existing AwsLifecyclePolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_lifecycle_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsLifecyclePolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_lifecycle_policy aws_imagebuilder_lifecycle_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsLifecyclePolicyConfig
    */
    constructor(scope: Construct, id: string, config: AwsLifecyclePolicyConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _executionRole?;
    get executionRole(): string;
    set executionRole(value: string);
    get executionRoleInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourceType?;
    get resourceType(): string;
    set resourceType(value: string);
    get resourceTypeInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _policyDetail;
    get policyDetail(): AwsLifecyclePolicy.PolicyDetailPropertyList;
    putPolicyDetail(value: AwsLifecyclePolicy.PolicyDetailProperty[] | cdktn.IResolvable): void;
    resetPolicyDetail(): void;
    get policyDetailInput(): cdktn.IResolvable | AwsLifecyclePolicy.PolicyDetailProperty[] | undefined;
    private _resourceSelection;
    get resourceSelection(): AwsLifecyclePolicy.ResourceSelectionPropertyList;
    putResourceSelection(value: AwsLifecyclePolicy.ResourceSelectionProperty[] | cdktn.IResolvable): void;
    resetResourceSelection(): void;
    get resourceSelectionInput(): cdktn.IResolvable | AwsLifecyclePolicy.ResourceSelectionProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsLifecyclePolicyIncludeResourcesPropertyToTerraform(struct?: AwsLifecyclePolicy.IncludeResourcesProperty | cdktn.IResolvable): any;
export declare function awsLifecyclePolicyIncludeResourcesPropertyToHclTerraform(struct?: AwsLifecyclePolicy.IncludeResourcesProperty | cdktn.IResolvable): any;
export declare function awsLifecyclePolicyActionPropertyToTerraform(struct?: AwsLifecyclePolicy.ActionProperty | cdktn.IResolvable): any;
export declare function awsLifecyclePolicyActionPropertyToHclTerraform(struct?: AwsLifecyclePolicy.ActionProperty | cdktn.IResolvable): any;
export declare function awsLifecyclePolicyLastLaunchedPropertyToTerraform(struct?: AwsLifecyclePolicy.LastLaunchedProperty | cdktn.IResolvable): any;
export declare function awsLifecyclePolicyLastLaunchedPropertyToHclTerraform(struct?: AwsLifecyclePolicy.LastLaunchedProperty | cdktn.IResolvable): any;
export declare function awsLifecyclePolicyAmisPropertyToTerraform(struct?: AwsLifecyclePolicy.AmisProperty | cdktn.IResolvable): any;
export declare function awsLifecyclePolicyAmisPropertyToHclTerraform(struct?: AwsLifecyclePolicy.AmisProperty | cdktn.IResolvable): any;
export declare function awsLifecyclePolicyExclusionRulesPropertyToTerraform(struct?: AwsLifecyclePolicy.ExclusionRulesProperty | cdktn.IResolvable): any;
export declare function awsLifecyclePolicyExclusionRulesPropertyToHclTerraform(struct?: AwsLifecyclePolicy.ExclusionRulesProperty | cdktn.IResolvable): any;
export declare function awsLifecyclePolicyFilterPropertyToTerraform(struct?: AwsLifecyclePolicy.FilterProperty | cdktn.IResolvable): any;
export declare function awsLifecyclePolicyFilterPropertyToHclTerraform(struct?: AwsLifecyclePolicy.FilterProperty | cdktn.IResolvable): any;
export declare function awsLifecyclePolicyPolicyDetailPropertyToTerraform(struct?: AwsLifecyclePolicy.PolicyDetailProperty | cdktn.IResolvable): any;
export declare function awsLifecyclePolicyPolicyDetailPropertyToHclTerraform(struct?: AwsLifecyclePolicy.PolicyDetailProperty | cdktn.IResolvable): any;
export declare function awsLifecyclePolicyRecipePropertyToTerraform(struct?: AwsLifecyclePolicy.RecipeProperty | cdktn.IResolvable): any;
export declare function awsLifecyclePolicyRecipePropertyToHclTerraform(struct?: AwsLifecyclePolicy.RecipeProperty | cdktn.IResolvable): any;
export declare function awsLifecyclePolicyResourceSelectionPropertyToTerraform(struct?: AwsLifecyclePolicy.ResourceSelectionProperty | cdktn.IResolvable): any;
export declare function awsLifecyclePolicyResourceSelectionPropertyToHclTerraform(struct?: AwsLifecyclePolicy.ResourceSelectionProperty | cdktn.IResolvable): any;
export declare namespace AwsLifecyclePolicy {
    interface IncludeResourcesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_lifecycle_policy#amis AwsLifecyclePolicy#amis}
        */
        readonly amis?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_lifecycle_policy#containers AwsLifecyclePolicy#containers}
        */
        readonly containers?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_lifecycle_policy#snapshots AwsLifecyclePolicy#snapshots}
        */
        readonly snapshots?: boolean | cdktn.IResolvable;
    }
    class IncludeResourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IncludeResourcesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IncludeResourcesProperty | cdktn.IResolvable | undefined);
        private _amis?;
        get amis(): boolean | cdktn.IResolvable;
        set amis(value: boolean | cdktn.IResolvable);
        resetAmis(): void;
        get amisInput(): boolean | cdktn.IResolvable | undefined;
        private _containers?;
        get containers(): boolean | cdktn.IResolvable;
        set containers(value: boolean | cdktn.IResolvable);
        resetContainers(): void;
        get containersInput(): boolean | cdktn.IResolvable | undefined;
        private _snapshots?;
        get snapshots(): boolean | cdktn.IResolvable;
        set snapshots(value: boolean | cdktn.IResolvable);
        resetSnapshots(): void;
        get snapshotsInput(): boolean | cdktn.IResolvable | undefined;
    }
    class IncludeResourcesPropertyList extends cdktn.ComplexList {
        internalValue?: IncludeResourcesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IncludeResourcesPropertyOutputReference;
    }
    interface ActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_lifecycle_policy#type AwsLifecyclePolicy#type}
        */
        readonly type: string;
        /**
        * include_resources block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_lifecycle_policy#include_resources AwsLifecyclePolicy#include_resources}
        */
        readonly includeResources?: IncludeResourcesProperty[] | cdktn.IResolvable;
    }
    class ActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ActionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ActionProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _includeResources;
        get includeResources(): IncludeResourcesPropertyList;
        putIncludeResources(value: IncludeResourcesProperty[] | cdktn.IResolvable): void;
        resetIncludeResources(): void;
        get includeResourcesInput(): cdktn.IResolvable | IncludeResourcesProperty[] | undefined;
    }
    class ActionPropertyList extends cdktn.ComplexList {
        internalValue?: ActionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ActionPropertyOutputReference;
    }
    interface LastLaunchedProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_lifecycle_policy#unit AwsLifecyclePolicy#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_lifecycle_policy#value AwsLifecyclePolicy#value}
        */
        readonly value: number;
    }
    class LastLaunchedPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LastLaunchedProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LastLaunchedProperty | cdktn.IResolvable | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    class LastLaunchedPropertyList extends cdktn.ComplexList {
        internalValue?: LastLaunchedProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LastLaunchedPropertyOutputReference;
    }
    interface AmisProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_lifecycle_policy#is_public AwsLifecyclePolicy#is_public}
        */
        readonly isPublic?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_lifecycle_policy#regions AwsLifecyclePolicy#regions}
        */
        readonly regions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_lifecycle_policy#shared_accounts AwsLifecyclePolicy#shared_accounts}
        */
        readonly sharedAccounts?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_lifecycle_policy#tag_map AwsLifecyclePolicy#tag_map}
        */
        readonly tagMap?: {
            [key: string]: string;
        };
        /**
        * last_launched block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_lifecycle_policy#last_launched AwsLifecyclePolicy#last_launched}
        */
        readonly lastLaunched?: LastLaunchedProperty[] | cdktn.IResolvable;
    }
    class AmisPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AmisProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AmisProperty | cdktn.IResolvable | undefined);
        private _isPublic?;
        get isPublic(): boolean | cdktn.IResolvable;
        set isPublic(value: boolean | cdktn.IResolvable);
        resetIsPublic(): void;
        get isPublicInput(): boolean | cdktn.IResolvable | undefined;
        private _regions?;
        get regions(): string[];
        set regions(value: string[]);
        resetRegions(): void;
        get regionsInput(): string[] | undefined;
        private _sharedAccounts?;
        get sharedAccounts(): string[];
        set sharedAccounts(value: string[]);
        resetSharedAccounts(): void;
        get sharedAccountsInput(): string[] | undefined;
        private _tagMap?;
        get tagMap(): {
            [key: string]: string;
        };
        set tagMap(value: {
            [key: string]: string;
        });
        resetTagMap(): void;
        get tagMapInput(): {
            [key: string]: string;
        } | undefined;
        private _lastLaunched;
        get lastLaunched(): LastLaunchedPropertyList;
        putLastLaunched(value: LastLaunchedProperty[] | cdktn.IResolvable): void;
        resetLastLaunched(): void;
        get lastLaunchedInput(): cdktn.IResolvable | LastLaunchedProperty[] | undefined;
    }
    class AmisPropertyList extends cdktn.ComplexList {
        internalValue?: AmisProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AmisPropertyOutputReference;
    }
    interface ExclusionRulesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_lifecycle_policy#tag_map AwsLifecyclePolicy#tag_map}
        */
        readonly tagMap?: {
            [key: string]: string;
        };
        /**
        * amis block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_lifecycle_policy#amis AwsLifecyclePolicy#amis}
        */
        readonly amis?: AmisProperty[] | cdktn.IResolvable;
    }
    class ExclusionRulesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExclusionRulesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ExclusionRulesProperty | cdktn.IResolvable | undefined);
        private _tagMap?;
        get tagMap(): {
            [key: string]: string;
        };
        set tagMap(value: {
            [key: string]: string;
        });
        resetTagMap(): void;
        get tagMapInput(): {
            [key: string]: string;
        } | undefined;
        private _amis;
        get amis(): AmisPropertyList;
        putAmis(value: AmisProperty[] | cdktn.IResolvable): void;
        resetAmis(): void;
        get amisInput(): cdktn.IResolvable | AmisProperty[] | undefined;
    }
    class ExclusionRulesPropertyList extends cdktn.ComplexList {
        internalValue?: ExclusionRulesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExclusionRulesPropertyOutputReference;
    }
    interface FilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_lifecycle_policy#retain_at_least AwsLifecyclePolicy#retain_at_least}
        */
        readonly retainAtLeast?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_lifecycle_policy#type AwsLifecyclePolicy#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_lifecycle_policy#unit AwsLifecyclePolicy#unit}
        */
        readonly unit?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_lifecycle_policy#value AwsLifecyclePolicy#value}
        */
        readonly value: number;
    }
    class FilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilterProperty | cdktn.IResolvable | undefined);
        private _retainAtLeast?;
        get retainAtLeast(): number;
        set retainAtLeast(value: number);
        resetRetainAtLeast(): void;
        get retainAtLeastInput(): number | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _unit?;
        get unit(): string;
        set unit(value: string);
        resetUnit(): void;
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    class FilterPropertyList extends cdktn.ComplexList {
        internalValue?: FilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterPropertyOutputReference;
    }
    interface PolicyDetailProperty {
        /**
        * action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_lifecycle_policy#action AwsLifecyclePolicy#action}
        */
        readonly action?: ActionProperty[] | cdktn.IResolvable;
        /**
        * exclusion_rules block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_lifecycle_policy#exclusion_rules AwsLifecyclePolicy#exclusion_rules}
        */
        readonly exclusionRules?: ExclusionRulesProperty[] | cdktn.IResolvable;
        /**
        * filter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_lifecycle_policy#filter AwsLifecyclePolicy#filter}
        */
        readonly filter?: FilterProperty[] | cdktn.IResolvable;
    }
    class PolicyDetailPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PolicyDetailProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PolicyDetailProperty | cdktn.IResolvable | undefined);
        private _action;
        get action(): ActionPropertyList;
        putAction(value: ActionProperty[] | cdktn.IResolvable): void;
        resetAction(): void;
        get actionInput(): cdktn.IResolvable | ActionProperty[] | undefined;
        private _exclusionRules;
        get exclusionRules(): ExclusionRulesPropertyList;
        putExclusionRules(value: ExclusionRulesProperty[] | cdktn.IResolvable): void;
        resetExclusionRules(): void;
        get exclusionRulesInput(): cdktn.IResolvable | ExclusionRulesProperty[] | undefined;
        private _filter;
        get filter(): FilterPropertyList;
        putFilter(value: FilterProperty[] | cdktn.IResolvable): void;
        resetFilter(): void;
        get filterInput(): cdktn.IResolvable | FilterProperty[] | undefined;
    }
    class PolicyDetailPropertyList extends cdktn.ComplexList {
        internalValue?: PolicyDetailProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PolicyDetailPropertyOutputReference;
    }
    interface RecipeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_lifecycle_policy#name AwsLifecyclePolicy#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_lifecycle_policy#semantic_version AwsLifecyclePolicy#semantic_version}
        */
        readonly semanticVersion: string;
    }
    class RecipePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RecipeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RecipeProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _semanticVersion?;
        get semanticVersion(): string;
        set semanticVersion(value: string);
        get semanticVersionInput(): string | undefined;
    }
    class RecipePropertyList extends cdktn.ComplexList {
        internalValue?: RecipeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RecipePropertyOutputReference;
    }
    interface ResourceSelectionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_lifecycle_policy#tag_map AwsLifecyclePolicy#tag_map}
        */
        readonly tagMap?: {
            [key: string]: string;
        };
        /**
        * recipe block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_lifecycle_policy#recipe AwsLifecyclePolicy#recipe}
        */
        readonly recipe?: RecipeProperty[] | cdktn.IResolvable;
    }
    class ResourceSelectionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceSelectionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceSelectionProperty | cdktn.IResolvable | undefined);
        private _tagMap?;
        get tagMap(): {
            [key: string]: string;
        };
        set tagMap(value: {
            [key: string]: string;
        });
        resetTagMap(): void;
        get tagMapInput(): {
            [key: string]: string;
        } | undefined;
        private _recipe;
        get recipe(): RecipePropertyList;
        putRecipe(value: RecipeProperty[] | cdktn.IResolvable): void;
        resetRecipe(): void;
        get recipeInput(): cdktn.IResolvable | RecipeProperty[] | undefined;
    }
    class ResourceSelectionPropertyList extends cdktn.ComplexList {
        internalValue?: ResourceSelectionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceSelectionPropertyOutputReference;
    }
}
