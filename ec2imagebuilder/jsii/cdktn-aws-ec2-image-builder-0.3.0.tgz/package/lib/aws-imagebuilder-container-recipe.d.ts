import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsContainerRecipeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_container_recipe#container_type AwsContainerRecipe#container_type}
    */
    readonly containerType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_container_recipe#description AwsContainerRecipe#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_container_recipe#dockerfile_template_data AwsContainerRecipe#dockerfile_template_data}
    */
    readonly dockerfileTemplateData?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_container_recipe#dockerfile_template_uri AwsContainerRecipe#dockerfile_template_uri}
    */
    readonly dockerfileTemplateUri?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_container_recipe#id AwsContainerRecipe#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_container_recipe#kms_key_id AwsContainerRecipe#kms_key_id}
    */
    readonly kmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_container_recipe#name AwsContainerRecipe#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_container_recipe#parent_image AwsContainerRecipe#parent_image}
    */
    readonly parentImage: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_container_recipe#platform_override AwsContainerRecipe#platform_override}
    */
    readonly platformOverride?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_container_recipe#region AwsContainerRecipe#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_container_recipe#tags AwsContainerRecipe#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_container_recipe#tags_all AwsContainerRecipe#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_container_recipe#version AwsContainerRecipe#version}
    */
    readonly version: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_container_recipe#working_directory AwsContainerRecipe#working_directory}
    */
    readonly workingDirectory?: string;
    /**
    * component block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_container_recipe#component AwsContainerRecipe#component}
    */
    readonly component: AwsContainerRecipe.ComponentProperty[] | cdktn.IResolvable;
    /**
    * instance_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_container_recipe#instance_configuration AwsContainerRecipe#instance_configuration}
    */
    readonly instanceConfiguration?: AwsContainerRecipe.InstanceConfigurationProperty;
    /**
    * target_repository block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_container_recipe#target_repository AwsContainerRecipe#target_repository}
    */
    readonly targetRepository: AwsContainerRecipe.TargetRepositoryProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_container_recipe aws_imagebuilder_container_recipe}
*/
export declare class AwsContainerRecipe extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_imagebuilder_container_recipe";
    /**
    * Generates CDKTN code for importing a AwsContainerRecipe resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsContainerRecipe to import
    * @param importFromId The id of the existing AwsContainerRecipe that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_container_recipe#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsContainerRecipe to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_container_recipe aws_imagebuilder_container_recipe} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsContainerRecipeConfig
    */
    constructor(scope: Construct, id: string, config: AwsContainerRecipeConfig);
    get arn(): string;
    private _containerType?;
    get containerType(): string;
    set containerType(value: string);
    get containerTypeInput(): string | undefined;
    get dateCreated(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _dockerfileTemplateData?;
    get dockerfileTemplateData(): string;
    set dockerfileTemplateData(value: string);
    resetDockerfileTemplateData(): void;
    get dockerfileTemplateDataInput(): string | undefined;
    private _dockerfileTemplateUri?;
    get dockerfileTemplateUri(): string;
    set dockerfileTemplateUri(value: string);
    resetDockerfileTemplateUri(): void;
    get dockerfileTemplateUriInput(): string | undefined;
    get encrypted(): cdktn.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    resetKmsKeyId(): void;
    get kmsKeyIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get owner(): string;
    private _parentImage?;
    get parentImage(): string;
    set parentImage(value: string);
    get parentImageInput(): string | undefined;
    get platform(): string;
    private _platformOverride?;
    get platformOverride(): string;
    set platformOverride(value: string);
    resetPlatformOverride(): void;
    get platformOverrideInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    get versionInput(): string | undefined;
    private _workingDirectory?;
    get workingDirectory(): string;
    set workingDirectory(value: string);
    resetWorkingDirectory(): void;
    get workingDirectoryInput(): string | undefined;
    private _component;
    get component(): AwsContainerRecipe.ComponentPropertyList;
    putComponent(value: AwsContainerRecipe.ComponentProperty[] | cdktn.IResolvable): void;
    get componentInput(): cdktn.IResolvable | AwsContainerRecipe.ComponentProperty[] | undefined;
    private _instanceConfiguration;
    get instanceConfiguration(): AwsContainerRecipe.InstanceConfigurationPropertyOutputReference;
    putInstanceConfiguration(value: AwsContainerRecipe.InstanceConfigurationProperty): void;
    resetInstanceConfiguration(): void;
    get instanceConfigurationInput(): AwsContainerRecipe.InstanceConfigurationProperty | undefined;
    private _targetRepository;
    get targetRepository(): AwsContainerRecipe.TargetRepositoryPropertyOutputReference;
    putTargetRepository(value: AwsContainerRecipe.TargetRepositoryProperty): void;
    get targetRepositoryInput(): AwsContainerRecipe.TargetRepositoryProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsContainerRecipeParameterPropertyToTerraform(struct?: AwsContainerRecipe.ParameterProperty | cdktn.IResolvable): any;
export declare function awsContainerRecipeParameterPropertyToHclTerraform(struct?: AwsContainerRecipe.ParameterProperty | cdktn.IResolvable): any;
export declare function awsContainerRecipeComponentPropertyToTerraform(struct?: AwsContainerRecipe.ComponentProperty | cdktn.IResolvable): any;
export declare function awsContainerRecipeComponentPropertyToHclTerraform(struct?: AwsContainerRecipe.ComponentProperty | cdktn.IResolvable): any;
export declare function awsContainerRecipeEbsPropertyToTerraform(struct?: AwsContainerRecipe.EbsPropertyOutputReference | AwsContainerRecipe.EbsProperty): any;
export declare function awsContainerRecipeEbsPropertyToHclTerraform(struct?: AwsContainerRecipe.EbsPropertyOutputReference | AwsContainerRecipe.EbsProperty): any;
export declare function awsContainerRecipeBlockDeviceMappingPropertyToTerraform(struct?: AwsContainerRecipe.BlockDeviceMappingProperty | cdktn.IResolvable): any;
export declare function awsContainerRecipeBlockDeviceMappingPropertyToHclTerraform(struct?: AwsContainerRecipe.BlockDeviceMappingProperty | cdktn.IResolvable): any;
export declare function awsContainerRecipeInstanceConfigurationPropertyToTerraform(struct?: AwsContainerRecipe.InstanceConfigurationPropertyOutputReference | AwsContainerRecipe.InstanceConfigurationProperty): any;
export declare function awsContainerRecipeInstanceConfigurationPropertyToHclTerraform(struct?: AwsContainerRecipe.InstanceConfigurationPropertyOutputReference | AwsContainerRecipe.InstanceConfigurationProperty): any;
export declare function awsContainerRecipeTargetRepositoryPropertyToTerraform(struct?: AwsContainerRecipe.TargetRepositoryPropertyOutputReference | AwsContainerRecipe.TargetRepositoryProperty): any;
export declare function awsContainerRecipeTargetRepositoryPropertyToHclTerraform(struct?: AwsContainerRecipe.TargetRepositoryPropertyOutputReference | AwsContainerRecipe.TargetRepositoryProperty): any;
export declare namespace AwsContainerRecipe {
    interface ParameterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_container_recipe#name AwsContainerRecipe#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_container_recipe#value AwsContainerRecipe#value}
        */
        readonly value: string;
    }
    class ParameterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ParameterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ParameterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ParameterPropertyList extends cdktn.ComplexList {
        internalValue?: ParameterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ParameterPropertyOutputReference;
    }
    interface ComponentProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_container_recipe#component_arn AwsContainerRecipe#component_arn}
        */
        readonly componentArn: string;
        /**
        * parameter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_container_recipe#parameter AwsContainerRecipe#parameter}
        */
        readonly parameter?: ParameterProperty[] | cdktn.IResolvable;
    }
    class ComponentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ComponentProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ComponentProperty | cdktn.IResolvable | undefined);
        private _componentArn?;
        get componentArn(): string;
        set componentArn(value: string);
        get componentArnInput(): string | undefined;
        private _parameter;
        get parameter(): ParameterPropertyList;
        putParameter(value: ParameterProperty[] | cdktn.IResolvable): void;
        resetParameter(): void;
        get parameterInput(): cdktn.IResolvable | ParameterProperty[] | undefined;
    }
    class ComponentPropertyList extends cdktn.ComplexList {
        internalValue?: ComponentProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ComponentPropertyOutputReference;
    }
    interface EbsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_container_recipe#delete_on_termination AwsContainerRecipe#delete_on_termination}
        */
        readonly deleteOnTermination?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_container_recipe#encrypted AwsContainerRecipe#encrypted}
        */
        readonly encrypted?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_container_recipe#iops AwsContainerRecipe#iops}
        */
        readonly iops?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_container_recipe#kms_key_id AwsContainerRecipe#kms_key_id}
        */
        readonly kmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_container_recipe#snapshot_id AwsContainerRecipe#snapshot_id}
        */
        readonly snapshotId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_container_recipe#throughput AwsContainerRecipe#throughput}
        */
        readonly throughput?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_container_recipe#volume_size AwsContainerRecipe#volume_size}
        */
        readonly volumeSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_container_recipe#volume_type AwsContainerRecipe#volume_type}
        */
        readonly volumeType?: string;
    }
    class EbsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EbsProperty | undefined;
        set internalValue(value: EbsProperty | undefined);
        private _deleteOnTermination?;
        get deleteOnTermination(): string;
        set deleteOnTermination(value: string);
        resetDeleteOnTermination(): void;
        get deleteOnTerminationInput(): string | undefined;
        private _encrypted?;
        get encrypted(): string;
        set encrypted(value: string);
        resetEncrypted(): void;
        get encryptedInput(): string | undefined;
        private _iops?;
        get iops(): number;
        set iops(value: number);
        resetIops(): void;
        get iopsInput(): number | undefined;
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
        private _snapshotId?;
        get snapshotId(): string;
        set snapshotId(value: string);
        resetSnapshotId(): void;
        get snapshotIdInput(): string | undefined;
        private _throughput?;
        get throughput(): number;
        set throughput(value: number);
        resetThroughput(): void;
        get throughputInput(): number | undefined;
        private _volumeSize?;
        get volumeSize(): number;
        set volumeSize(value: number);
        resetVolumeSize(): void;
        get volumeSizeInput(): number | undefined;
        private _volumeType?;
        get volumeType(): string;
        set volumeType(value: string);
        resetVolumeType(): void;
        get volumeTypeInput(): string | undefined;
    }
    interface BlockDeviceMappingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_container_recipe#device_name AwsContainerRecipe#device_name}
        */
        readonly deviceName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_container_recipe#no_device AwsContainerRecipe#no_device}
        */
        readonly noDevice?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_container_recipe#virtual_name AwsContainerRecipe#virtual_name}
        */
        readonly virtualName?: string;
        /**
        * ebs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_container_recipe#ebs AwsContainerRecipe#ebs}
        */
        readonly ebs?: EbsProperty;
    }
    class BlockDeviceMappingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BlockDeviceMappingProperty | cdktn.IResolvable | undefined;
        set internalValue(value: BlockDeviceMappingProperty | cdktn.IResolvable | undefined);
        private _deviceName?;
        get deviceName(): string;
        set deviceName(value: string);
        resetDeviceName(): void;
        get deviceNameInput(): string | undefined;
        private _noDevice?;
        get noDevice(): boolean | cdktn.IResolvable;
        set noDevice(value: boolean | cdktn.IResolvable);
        resetNoDevice(): void;
        get noDeviceInput(): boolean | cdktn.IResolvable | undefined;
        private _virtualName?;
        get virtualName(): string;
        set virtualName(value: string);
        resetVirtualName(): void;
        get virtualNameInput(): string | undefined;
        private _ebs;
        get ebs(): EbsPropertyOutputReference;
        putEbs(value: EbsProperty): void;
        resetEbs(): void;
        get ebsInput(): EbsProperty | undefined;
    }
    class BlockDeviceMappingPropertyList extends cdktn.ComplexList {
        internalValue?: BlockDeviceMappingProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BlockDeviceMappingPropertyOutputReference;
    }
    interface InstanceConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_container_recipe#image AwsContainerRecipe#image}
        */
        readonly image?: string;
        /**
        * block_device_mapping block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_container_recipe#block_device_mapping AwsContainerRecipe#block_device_mapping}
        */
        readonly blockDeviceMapping?: BlockDeviceMappingProperty[] | cdktn.IResolvable;
    }
    class InstanceConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InstanceConfigurationProperty | undefined;
        set internalValue(value: InstanceConfigurationProperty | undefined);
        private _image?;
        get image(): string;
        set image(value: string);
        resetImage(): void;
        get imageInput(): string | undefined;
        private _blockDeviceMapping;
        get blockDeviceMapping(): BlockDeviceMappingPropertyList;
        putBlockDeviceMapping(value: BlockDeviceMappingProperty[] | cdktn.IResolvable): void;
        resetBlockDeviceMapping(): void;
        get blockDeviceMappingInput(): cdktn.IResolvable | BlockDeviceMappingProperty[] | undefined;
    }
    interface TargetRepositoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_container_recipe#repository_name AwsContainerRecipe#repository_name}
        */
        readonly repositoryName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/imagebuilder_container_recipe#service AwsContainerRecipe#service}
        */
        readonly service: string;
    }
    class TargetRepositoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TargetRepositoryProperty | undefined;
        set internalValue(value: TargetRepositoryProperty | undefined);
        private _repositoryName?;
        get repositoryName(): string;
        set repositoryName(value: string);
        get repositoryNameInput(): string | undefined;
        private _service?;
        get service(): string;
        set service(value: string);
        get serviceInput(): string | undefined;
    }
}
