import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsChimeVoiceConnectorTerminationCredentialsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_termination_credentials#id AwsChimeVoiceConnectorTerminationCredentials#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_termination_credentials#region AwsChimeVoiceConnectorTerminationCredentials#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_termination_credentials#voice_connector_id AwsChimeVoiceConnectorTerminationCredentials#voice_connector_id}
    */
    readonly voiceConnectorId: string;
    /**
    * credentials block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_termination_credentials#credentials AwsChimeVoiceConnectorTerminationCredentials#credentials}
    */
    readonly credentials: AwsChimeVoiceConnectorTerminationCredentials.CredentialsProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_termination_credentials aws_chime_voice_connector_termination_credentials}
*/
export declare class AwsChimeVoiceConnectorTerminationCredentials extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_chime_voice_connector_termination_credentials";
    /**
    * Generates CDKTN code for importing a AwsChimeVoiceConnectorTerminationCredentials resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsChimeVoiceConnectorTerminationCredentials to import
    * @param importFromId The id of the existing AwsChimeVoiceConnectorTerminationCredentials that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_termination_credentials#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsChimeVoiceConnectorTerminationCredentials to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_termination_credentials aws_chime_voice_connector_termination_credentials} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsChimeVoiceConnectorTerminationCredentialsConfig
    */
    constructor(scope: Construct, id: string, config: AwsChimeVoiceConnectorTerminationCredentialsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _voiceConnectorId?;
    get voiceConnectorId(): string;
    set voiceConnectorId(value: string);
    get voiceConnectorIdInput(): string | undefined;
    private _credentials;
    get credentials(): AwsChimeVoiceConnectorTerminationCredentials.CredentialsPropertyList;
    putCredentials(value: AwsChimeVoiceConnectorTerminationCredentials.CredentialsProperty[] | cdktn.IResolvable): void;
    get credentialsInput(): cdktn.IResolvable | AwsChimeVoiceConnectorTerminationCredentials.CredentialsProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsChimeVoiceConnectorTerminationCredentialsCredentialsPropertyToTerraform(struct?: AwsChimeVoiceConnectorTerminationCredentials.CredentialsProperty | cdktn.IResolvable): any;
export declare function awsChimeVoiceConnectorTerminationCredentialsCredentialsPropertyToHclTerraform(struct?: AwsChimeVoiceConnectorTerminationCredentials.CredentialsProperty | cdktn.IResolvable): any;
export declare namespace AwsChimeVoiceConnectorTerminationCredentials {
    interface CredentialsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_termination_credentials#password AwsChimeVoiceConnectorTerminationCredentials#password}
        */
        readonly password: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_termination_credentials#username AwsChimeVoiceConnectorTerminationCredentials#username}
        */
        readonly username: string;
    }
    class CredentialsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CredentialsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CredentialsProperty | cdktn.IResolvable | undefined);
        private _password?;
        get password(): string;
        set password(value: string);
        get passwordInput(): string | undefined;
        private _username?;
        get username(): string;
        set username(value: string);
        get usernameInput(): string | undefined;
    }
    class CredentialsPropertyList extends cdktn.ComplexList {
        internalValue?: CredentialsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CredentialsPropertyOutputReference;
    }
}
