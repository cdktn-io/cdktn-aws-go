import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDetectiveOrganizationConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/detective_organization_configuration#auto_enable AwsDetectiveOrganizationConfiguration#auto_enable}
    */
    readonly autoEnable: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/detective_organization_configuration#graph_arn AwsDetectiveOrganizationConfiguration#graph_arn}
    */
    readonly graphArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/detective_organization_configuration#id AwsDetectiveOrganizationConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/detective_organization_configuration#region AwsDetectiveOrganizationConfiguration#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/detective_organization_configuration aws_detective_organization_configuration}
*/
export declare class AwsDetectiveOrganizationConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_detective_organization_configuration";
    /**
    * Generates CDKTN code for importing a AwsDetectiveOrganizationConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDetectiveOrganizationConfiguration to import
    * @param importFromId The id of the existing AwsDetectiveOrganizationConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/detective_organization_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDetectiveOrganizationConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/detective_organization_configuration aws_detective_organization_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDetectiveOrganizationConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsDetectiveOrganizationConfigurationConfig);
    private _autoEnable?;
    get autoEnable(): boolean | cdktn.IResolvable;
    set autoEnable(value: boolean | cdktn.IResolvable);
    get autoEnableInput(): boolean | cdktn.IResolvable | undefined;
    private _graphArn?;
    get graphArn(): string;
    set graphArn(value: string);
    get graphArnInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
