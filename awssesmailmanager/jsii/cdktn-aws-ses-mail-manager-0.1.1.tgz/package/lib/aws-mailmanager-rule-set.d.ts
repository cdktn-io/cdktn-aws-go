import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsMailmanagerRuleSetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#name AwsMailmanagerRuleSet#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#region AwsMailmanagerRuleSet#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#tags AwsMailmanagerRuleSet#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#rule AwsMailmanagerRuleSet#rule}
    */
    readonly rule?: AwsMailmanagerRuleSet.RuleProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set aws_mailmanager_rule_set}
*/
export declare class AwsMailmanagerRuleSet extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_mailmanager_rule_set";
    /**
    * Generates CDKTN code for importing a AwsMailmanagerRuleSet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsMailmanagerRuleSet to import
    * @param importFromId The id of the existing AwsMailmanagerRuleSet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsMailmanagerRuleSet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set aws_mailmanager_rule_set} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsMailmanagerRuleSetConfig
    */
    constructor(scope: Construct, id: string, config: AwsMailmanagerRuleSetConfig);
    get arn(): string;
    get createdDate(): string;
    get id(): string;
    get lastModificationDate(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _rule;
    get rule(): AwsMailmanagerRuleSet.RulePropertyList;
    putRule(value: AwsMailmanagerRuleSet.RuleProperty[] | cdktn.IResolvable): void;
    resetRule(): void;
    get ruleInput(): cdktn.IResolvable | AwsMailmanagerRuleSet.RuleProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsMailmanagerRuleSetAddHeaderPropertyToTerraform(struct?: AwsMailmanagerRuleSet.AddHeaderProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetAddHeaderPropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.AddHeaderProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetArchivePropertyToTerraform(struct?: AwsMailmanagerRuleSet.ArchiveProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetArchivePropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.ArchiveProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetBouncePropertyToTerraform(struct?: AwsMailmanagerRuleSet.BounceProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetBouncePropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.BounceProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetDeliverToMailboxPropertyToTerraform(struct?: AwsMailmanagerRuleSet.DeliverToMailboxProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetDeliverToMailboxPropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.DeliverToMailboxProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetDeliverToQBusinessPropertyToTerraform(struct?: AwsMailmanagerRuleSet.DeliverToQBusinessProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetDeliverToQBusinessPropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.DeliverToQBusinessProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetDropPropertyToTerraform(struct?: AwsMailmanagerRuleSet.DropProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetDropPropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.DropProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetInvokeLambdaPropertyToTerraform(struct?: AwsMailmanagerRuleSet.InvokeLambdaProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetInvokeLambdaPropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.InvokeLambdaProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetPublishToSnsPropertyToTerraform(struct?: AwsMailmanagerRuleSet.PublishToSnsProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetPublishToSnsPropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.PublishToSnsProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRelayPropertyToTerraform(struct?: AwsMailmanagerRuleSet.RelayProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRelayPropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.RelayProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetReplaceRecipientPropertyToTerraform(struct?: AwsMailmanagerRuleSet.ReplaceRecipientProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetReplaceRecipientPropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.ReplaceRecipientProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetSendPropertyToTerraform(struct?: AwsMailmanagerRuleSet.SendProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetSendPropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.SendProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetWriteToS3PropertyToTerraform(struct?: AwsMailmanagerRuleSet.WriteToS3Property | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetWriteToS3PropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.WriteToS3Property | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetActionPropertyToTerraform(struct?: AwsMailmanagerRuleSet.ActionProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetActionPropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.ActionProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleConditionBooleanExpressionEvaluateAnalysisPropertyToTerraform(struct?: AwsMailmanagerRuleSet.RuleConditionBooleanExpressionEvaluateAnalysisProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleConditionBooleanExpressionEvaluateAnalysisPropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.RuleConditionBooleanExpressionEvaluateAnalysisProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleConditionBooleanExpressionEvaluateIsInAddressListPropertyToTerraform(struct?: AwsMailmanagerRuleSet.RuleConditionBooleanExpressionEvaluateIsInAddressListProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleConditionBooleanExpressionEvaluateIsInAddressListPropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.RuleConditionBooleanExpressionEvaluateIsInAddressListProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleConditionBooleanExpressionEvaluatePropertyToTerraform(struct?: AwsMailmanagerRuleSet.RuleConditionBooleanExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleConditionBooleanExpressionEvaluatePropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.RuleConditionBooleanExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleConditionBooleanExpressionPropertyToTerraform(struct?: AwsMailmanagerRuleSet.RuleConditionBooleanExpressionProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleConditionBooleanExpressionPropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.RuleConditionBooleanExpressionProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleConditionDmarcExpressionPropertyToTerraform(struct?: AwsMailmanagerRuleSet.RuleConditionDmarcExpressionProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleConditionDmarcExpressionPropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.RuleConditionDmarcExpressionProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleConditionIpExpressionEvaluatePropertyToTerraform(struct?: AwsMailmanagerRuleSet.RuleConditionIpExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleConditionIpExpressionEvaluatePropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.RuleConditionIpExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleConditionIpExpressionPropertyToTerraform(struct?: AwsMailmanagerRuleSet.RuleConditionIpExpressionProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleConditionIpExpressionPropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.RuleConditionIpExpressionProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleConditionNumberExpressionEvaluatePropertyToTerraform(struct?: AwsMailmanagerRuleSet.RuleConditionNumberExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleConditionNumberExpressionEvaluatePropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.RuleConditionNumberExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleConditionNumberExpressionPropertyToTerraform(struct?: AwsMailmanagerRuleSet.RuleConditionNumberExpressionProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleConditionNumberExpressionPropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.RuleConditionNumberExpressionProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleConditionStringExpressionEvaluateAnalysisPropertyToTerraform(struct?: AwsMailmanagerRuleSet.RuleConditionStringExpressionEvaluateAnalysisProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleConditionStringExpressionEvaluateAnalysisPropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.RuleConditionStringExpressionEvaluateAnalysisProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleConditionStringExpressionEvaluatePropertyToTerraform(struct?: AwsMailmanagerRuleSet.RuleConditionStringExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleConditionStringExpressionEvaluatePropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.RuleConditionStringExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleConditionStringExpressionPropertyToTerraform(struct?: AwsMailmanagerRuleSet.RuleConditionStringExpressionProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleConditionStringExpressionPropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.RuleConditionStringExpressionProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleConditionVerdictExpressionEvaluateAnalysisPropertyToTerraform(struct?: AwsMailmanagerRuleSet.RuleConditionVerdictExpressionEvaluateAnalysisProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleConditionVerdictExpressionEvaluateAnalysisPropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.RuleConditionVerdictExpressionEvaluateAnalysisProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleConditionVerdictExpressionEvaluatePropertyToTerraform(struct?: AwsMailmanagerRuleSet.RuleConditionVerdictExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleConditionVerdictExpressionEvaluatePropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.RuleConditionVerdictExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleConditionVerdictExpressionPropertyToTerraform(struct?: AwsMailmanagerRuleSet.RuleConditionVerdictExpressionProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleConditionVerdictExpressionPropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.RuleConditionVerdictExpressionProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetConditionPropertyToTerraform(struct?: AwsMailmanagerRuleSet.ConditionProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetConditionPropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.ConditionProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleUnlessBooleanExpressionEvaluateAnalysisPropertyToTerraform(struct?: AwsMailmanagerRuleSet.RuleUnlessBooleanExpressionEvaluateAnalysisProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleUnlessBooleanExpressionEvaluateAnalysisPropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.RuleUnlessBooleanExpressionEvaluateAnalysisProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleUnlessBooleanExpressionEvaluateIsInAddressListPropertyToTerraform(struct?: AwsMailmanagerRuleSet.RuleUnlessBooleanExpressionEvaluateIsInAddressListProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleUnlessBooleanExpressionEvaluateIsInAddressListPropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.RuleUnlessBooleanExpressionEvaluateIsInAddressListProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleUnlessBooleanExpressionEvaluatePropertyToTerraform(struct?: AwsMailmanagerRuleSet.RuleUnlessBooleanExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleUnlessBooleanExpressionEvaluatePropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.RuleUnlessBooleanExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleUnlessBooleanExpressionPropertyToTerraform(struct?: AwsMailmanagerRuleSet.RuleUnlessBooleanExpressionProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleUnlessBooleanExpressionPropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.RuleUnlessBooleanExpressionProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleUnlessDmarcExpressionPropertyToTerraform(struct?: AwsMailmanagerRuleSet.RuleUnlessDmarcExpressionProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleUnlessDmarcExpressionPropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.RuleUnlessDmarcExpressionProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleUnlessIpExpressionEvaluatePropertyToTerraform(struct?: AwsMailmanagerRuleSet.RuleUnlessIpExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleUnlessIpExpressionEvaluatePropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.RuleUnlessIpExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleUnlessIpExpressionPropertyToTerraform(struct?: AwsMailmanagerRuleSet.RuleUnlessIpExpressionProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleUnlessIpExpressionPropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.RuleUnlessIpExpressionProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleUnlessNumberExpressionEvaluatePropertyToTerraform(struct?: AwsMailmanagerRuleSet.RuleUnlessNumberExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleUnlessNumberExpressionEvaluatePropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.RuleUnlessNumberExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleUnlessNumberExpressionPropertyToTerraform(struct?: AwsMailmanagerRuleSet.RuleUnlessNumberExpressionProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleUnlessNumberExpressionPropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.RuleUnlessNumberExpressionProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleUnlessStringExpressionEvaluateAnalysisPropertyToTerraform(struct?: AwsMailmanagerRuleSet.RuleUnlessStringExpressionEvaluateAnalysisProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleUnlessStringExpressionEvaluateAnalysisPropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.RuleUnlessStringExpressionEvaluateAnalysisProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleUnlessStringExpressionEvaluatePropertyToTerraform(struct?: AwsMailmanagerRuleSet.RuleUnlessStringExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleUnlessStringExpressionEvaluatePropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.RuleUnlessStringExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleUnlessStringExpressionPropertyToTerraform(struct?: AwsMailmanagerRuleSet.RuleUnlessStringExpressionProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleUnlessStringExpressionPropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.RuleUnlessStringExpressionProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleUnlessVerdictExpressionEvaluateAnalysisPropertyToTerraform(struct?: AwsMailmanagerRuleSet.RuleUnlessVerdictExpressionEvaluateAnalysisProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleUnlessVerdictExpressionEvaluateAnalysisPropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.RuleUnlessVerdictExpressionEvaluateAnalysisProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleUnlessVerdictExpressionEvaluatePropertyToTerraform(struct?: AwsMailmanagerRuleSet.RuleUnlessVerdictExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleUnlessVerdictExpressionEvaluatePropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.RuleUnlessVerdictExpressionEvaluateProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleUnlessVerdictExpressionPropertyToTerraform(struct?: AwsMailmanagerRuleSet.RuleUnlessVerdictExpressionProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRuleUnlessVerdictExpressionPropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.RuleUnlessVerdictExpressionProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetUnlessPropertyToTerraform(struct?: AwsMailmanagerRuleSet.UnlessProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetUnlessPropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.UnlessProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRulePropertyToTerraform(struct?: AwsMailmanagerRuleSet.RuleProperty | cdktn.IResolvable): any;
export declare function awsMailmanagerRuleSetRulePropertyToHclTerraform(struct?: AwsMailmanagerRuleSet.RuleProperty | cdktn.IResolvable): any;
export declare namespace AwsMailmanagerRuleSet {
    interface AddHeaderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#header_name AwsMailmanagerRuleSet#header_name}
        */
        readonly headerName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#header_value AwsMailmanagerRuleSet#header_value}
        */
        readonly headerValue: string;
    }
    class AddHeaderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AddHeaderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AddHeaderProperty | cdktn.IResolvable | undefined);
        private _headerName?;
        get headerName(): string;
        set headerName(value: string);
        get headerNameInput(): string | undefined;
        private _headerValue?;
        get headerValue(): string;
        set headerValue(value: string);
        get headerValueInput(): string | undefined;
    }
    class AddHeaderPropertyList extends cdktn.ComplexList {
        internalValue?: AddHeaderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AddHeaderPropertyOutputReference;
    }
    interface ArchiveProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#action_failure_policy AwsMailmanagerRuleSet#action_failure_policy}
        */
        readonly actionFailurePolicy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#target_archive AwsMailmanagerRuleSet#target_archive}
        */
        readonly targetArchive: string;
    }
    class ArchivePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ArchiveProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ArchiveProperty | cdktn.IResolvable | undefined);
        private _actionFailurePolicy?;
        get actionFailurePolicy(): string;
        set actionFailurePolicy(value: string);
        resetActionFailurePolicy(): void;
        get actionFailurePolicyInput(): string | undefined;
        private _targetArchive?;
        get targetArchive(): string;
        set targetArchive(value: string);
        get targetArchiveInput(): string | undefined;
    }
    class ArchivePropertyList extends cdktn.ComplexList {
        internalValue?: ArchiveProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ArchivePropertyOutputReference;
    }
    interface BounceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#action_failure_policy AwsMailmanagerRuleSet#action_failure_policy}
        */
        readonly actionFailurePolicy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#diagnostic_message AwsMailmanagerRuleSet#diagnostic_message}
        */
        readonly diagnosticMessage: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#message AwsMailmanagerRuleSet#message}
        */
        readonly message?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#role_arn AwsMailmanagerRuleSet#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#sender AwsMailmanagerRuleSet#sender}
        */
        readonly sender: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#smtp_reply_code AwsMailmanagerRuleSet#smtp_reply_code}
        */
        readonly smtpReplyCode: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#status_code AwsMailmanagerRuleSet#status_code}
        */
        readonly statusCode: string;
    }
    class BouncePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BounceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: BounceProperty | cdktn.IResolvable | undefined);
        private _actionFailurePolicy?;
        get actionFailurePolicy(): string;
        set actionFailurePolicy(value: string);
        resetActionFailurePolicy(): void;
        get actionFailurePolicyInput(): string | undefined;
        private _diagnosticMessage?;
        get diagnosticMessage(): string;
        set diagnosticMessage(value: string);
        get diagnosticMessageInput(): string | undefined;
        private _message?;
        get message(): string;
        set message(value: string);
        resetMessage(): void;
        get messageInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _sender?;
        get sender(): string;
        set sender(value: string);
        get senderInput(): string | undefined;
        private _smtpReplyCode?;
        get smtpReplyCode(): string;
        set smtpReplyCode(value: string);
        get smtpReplyCodeInput(): string | undefined;
        private _statusCode?;
        get statusCode(): string;
        set statusCode(value: string);
        get statusCodeInput(): string | undefined;
    }
    class BouncePropertyList extends cdktn.ComplexList {
        internalValue?: BounceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BouncePropertyOutputReference;
    }
    interface DeliverToMailboxProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#action_failure_policy AwsMailmanagerRuleSet#action_failure_policy}
        */
        readonly actionFailurePolicy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#mailbox_arn AwsMailmanagerRuleSet#mailbox_arn}
        */
        readonly mailboxArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#role_arn AwsMailmanagerRuleSet#role_arn}
        */
        readonly roleArn: string;
    }
    class DeliverToMailboxPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DeliverToMailboxProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DeliverToMailboxProperty | cdktn.IResolvable | undefined);
        private _actionFailurePolicy?;
        get actionFailurePolicy(): string;
        set actionFailurePolicy(value: string);
        resetActionFailurePolicy(): void;
        get actionFailurePolicyInput(): string | undefined;
        private _mailboxArn?;
        get mailboxArn(): string;
        set mailboxArn(value: string);
        get mailboxArnInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
    }
    class DeliverToMailboxPropertyList extends cdktn.ComplexList {
        internalValue?: DeliverToMailboxProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DeliverToMailboxPropertyOutputReference;
    }
    interface DeliverToQBusinessProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#action_failure_policy AwsMailmanagerRuleSet#action_failure_policy}
        */
        readonly actionFailurePolicy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#application_id AwsMailmanagerRuleSet#application_id}
        */
        readonly applicationId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#index_id AwsMailmanagerRuleSet#index_id}
        */
        readonly indexId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#role_arn AwsMailmanagerRuleSet#role_arn}
        */
        readonly roleArn: string;
    }
    class DeliverToQBusinessPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DeliverToQBusinessProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DeliverToQBusinessProperty | cdktn.IResolvable | undefined);
        private _actionFailurePolicy?;
        get actionFailurePolicy(): string;
        set actionFailurePolicy(value: string);
        resetActionFailurePolicy(): void;
        get actionFailurePolicyInput(): string | undefined;
        private _applicationId?;
        get applicationId(): string;
        set applicationId(value: string);
        get applicationIdInput(): string | undefined;
        private _indexId?;
        get indexId(): string;
        set indexId(value: string);
        get indexIdInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
    }
    class DeliverToQBusinessPropertyList extends cdktn.ComplexList {
        internalValue?: DeliverToQBusinessProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DeliverToQBusinessPropertyOutputReference;
    }
    interface DropProperty {
    }
    class DropPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DropProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DropProperty | cdktn.IResolvable | undefined);
    }
    class DropPropertyList extends cdktn.ComplexList {
        internalValue?: DropProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DropPropertyOutputReference;
    }
    interface InvokeLambdaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#action_failure_policy AwsMailmanagerRuleSet#action_failure_policy}
        */
        readonly actionFailurePolicy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#function_arn AwsMailmanagerRuleSet#function_arn}
        */
        readonly functionArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#invocation_type AwsMailmanagerRuleSet#invocation_type}
        */
        readonly invocationType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#retry_time_minutes AwsMailmanagerRuleSet#retry_time_minutes}
        */
        readonly retryTimeMinutes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#role_arn AwsMailmanagerRuleSet#role_arn}
        */
        readonly roleArn: string;
    }
    class InvokeLambdaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InvokeLambdaProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InvokeLambdaProperty | cdktn.IResolvable | undefined);
        private _actionFailurePolicy?;
        get actionFailurePolicy(): string;
        set actionFailurePolicy(value: string);
        resetActionFailurePolicy(): void;
        get actionFailurePolicyInput(): string | undefined;
        private _functionArn?;
        get functionArn(): string;
        set functionArn(value: string);
        get functionArnInput(): string | undefined;
        private _invocationType?;
        get invocationType(): string;
        set invocationType(value: string);
        get invocationTypeInput(): string | undefined;
        private _retryTimeMinutes?;
        get retryTimeMinutes(): number;
        set retryTimeMinutes(value: number);
        resetRetryTimeMinutes(): void;
        get retryTimeMinutesInput(): number | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
    }
    class InvokeLambdaPropertyList extends cdktn.ComplexList {
        internalValue?: InvokeLambdaProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InvokeLambdaPropertyOutputReference;
    }
    interface PublishToSnsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#action_failure_policy AwsMailmanagerRuleSet#action_failure_policy}
        */
        readonly actionFailurePolicy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#encoding AwsMailmanagerRuleSet#encoding}
        */
        readonly encoding?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#payload_type AwsMailmanagerRuleSet#payload_type}
        */
        readonly payloadType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#role_arn AwsMailmanagerRuleSet#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#topic_arn AwsMailmanagerRuleSet#topic_arn}
        */
        readonly topicArn: string;
    }
    class PublishToSnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PublishToSnsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PublishToSnsProperty | cdktn.IResolvable | undefined);
        private _actionFailurePolicy?;
        get actionFailurePolicy(): string;
        set actionFailurePolicy(value: string);
        resetActionFailurePolicy(): void;
        get actionFailurePolicyInput(): string | undefined;
        private _encoding?;
        get encoding(): string;
        set encoding(value: string);
        resetEncoding(): void;
        get encodingInput(): string | undefined;
        private _payloadType?;
        get payloadType(): string;
        set payloadType(value: string);
        resetPayloadType(): void;
        get payloadTypeInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _topicArn?;
        get topicArn(): string;
        set topicArn(value: string);
        get topicArnInput(): string | undefined;
    }
    class PublishToSnsPropertyList extends cdktn.ComplexList {
        internalValue?: PublishToSnsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PublishToSnsPropertyOutputReference;
    }
    interface RelayProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#action_failure_policy AwsMailmanagerRuleSet#action_failure_policy}
        */
        readonly actionFailurePolicy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#mail_from AwsMailmanagerRuleSet#mail_from}
        */
        readonly mailFrom?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#relay AwsMailmanagerRuleSet#relay}
        */
        readonly relay: string;
    }
    class RelayPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RelayProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RelayProperty | cdktn.IResolvable | undefined);
        private _actionFailurePolicy?;
        get actionFailurePolicy(): string;
        set actionFailurePolicy(value: string);
        resetActionFailurePolicy(): void;
        get actionFailurePolicyInput(): string | undefined;
        private _mailFrom?;
        get mailFrom(): string;
        set mailFrom(value: string);
        resetMailFrom(): void;
        get mailFromInput(): string | undefined;
        private _relay?;
        get relay(): string;
        set relay(value: string);
        get relayInput(): string | undefined;
    }
    class RelayPropertyList extends cdktn.ComplexList {
        internalValue?: RelayProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RelayPropertyOutputReference;
    }
    interface ReplaceRecipientProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#replace_with AwsMailmanagerRuleSet#replace_with}
        */
        readonly replaceWith?: string[];
    }
    class ReplaceRecipientPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReplaceRecipientProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ReplaceRecipientProperty | cdktn.IResolvable | undefined);
        private _replaceWith?;
        get replaceWith(): string[];
        set replaceWith(value: string[]);
        resetReplaceWith(): void;
        get replaceWithInput(): string[] | undefined;
    }
    class ReplaceRecipientPropertyList extends cdktn.ComplexList {
        internalValue?: ReplaceRecipientProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReplaceRecipientPropertyOutputReference;
    }
    interface SendProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#action_failure_policy AwsMailmanagerRuleSet#action_failure_policy}
        */
        readonly actionFailurePolicy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#role_arn AwsMailmanagerRuleSet#role_arn}
        */
        readonly roleArn: string;
    }
    class SendPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SendProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SendProperty | cdktn.IResolvable | undefined);
        private _actionFailurePolicy?;
        get actionFailurePolicy(): string;
        set actionFailurePolicy(value: string);
        resetActionFailurePolicy(): void;
        get actionFailurePolicyInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
    }
    class SendPropertyList extends cdktn.ComplexList {
        internalValue?: SendProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SendPropertyOutputReference;
    }
    interface WriteToS3Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#action_failure_policy AwsMailmanagerRuleSet#action_failure_policy}
        */
        readonly actionFailurePolicy?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#role_arn AwsMailmanagerRuleSet#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#s3_bucket AwsMailmanagerRuleSet#s3_bucket}
        */
        readonly s3Bucket: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#s3_prefix AwsMailmanagerRuleSet#s3_prefix}
        */
        readonly s3Prefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#s3_sse_kms_key_id AwsMailmanagerRuleSet#s3_sse_kms_key_id}
        */
        readonly s3SseKmsKeyId?: string;
    }
    class WriteToS3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WriteToS3Property | cdktn.IResolvable | undefined;
        set internalValue(value: WriteToS3Property | cdktn.IResolvable | undefined);
        private _actionFailurePolicy?;
        get actionFailurePolicy(): string;
        set actionFailurePolicy(value: string);
        resetActionFailurePolicy(): void;
        get actionFailurePolicyInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _s3Bucket?;
        get s3Bucket(): string;
        set s3Bucket(value: string);
        get s3BucketInput(): string | undefined;
        private _s3Prefix?;
        get s3Prefix(): string;
        set s3Prefix(value: string);
        resetS3Prefix(): void;
        get s3PrefixInput(): string | undefined;
        private _s3SseKmsKeyId?;
        get s3SseKmsKeyId(): string;
        set s3SseKmsKeyId(value: string);
        resetS3SseKmsKeyId(): void;
        get s3SseKmsKeyIdInput(): string | undefined;
    }
    class WriteToS3PropertyList extends cdktn.ComplexList {
        internalValue?: WriteToS3Property[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WriteToS3PropertyOutputReference;
    }
    interface ActionProperty {
        /**
        * add_header block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#add_header AwsMailmanagerRuleSet#add_header}
        */
        readonly addHeader?: AddHeaderProperty[] | cdktn.IResolvable;
        /**
        * archive block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#archive AwsMailmanagerRuleSet#archive}
        */
        readonly archive?: ArchiveProperty[] | cdktn.IResolvable;
        /**
        * bounce block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#bounce AwsMailmanagerRuleSet#bounce}
        */
        readonly bounce?: BounceProperty[] | cdktn.IResolvable;
        /**
        * deliver_to_mailbox block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#deliver_to_mailbox AwsMailmanagerRuleSet#deliver_to_mailbox}
        */
        readonly deliverToMailbox?: DeliverToMailboxProperty[] | cdktn.IResolvable;
        /**
        * deliver_to_q_business block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#deliver_to_q_business AwsMailmanagerRuleSet#deliver_to_q_business}
        */
        readonly deliverToQBusiness?: DeliverToQBusinessProperty[] | cdktn.IResolvable;
        /**
        * drop block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#drop AwsMailmanagerRuleSet#drop}
        */
        readonly drop?: DropProperty[] | cdktn.IResolvable;
        /**
        * invoke_lambda block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#invoke_lambda AwsMailmanagerRuleSet#invoke_lambda}
        */
        readonly invokeLambda?: InvokeLambdaProperty[] | cdktn.IResolvable;
        /**
        * publish_to_sns block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#publish_to_sns AwsMailmanagerRuleSet#publish_to_sns}
        */
        readonly publishToSns?: PublishToSnsProperty[] | cdktn.IResolvable;
        /**
        * relay block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#relay AwsMailmanagerRuleSet#relay}
        */
        readonly relay?: RelayProperty[] | cdktn.IResolvable;
        /**
        * replace_recipient block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#replace_recipient AwsMailmanagerRuleSet#replace_recipient}
        */
        readonly replaceRecipient?: ReplaceRecipientProperty[] | cdktn.IResolvable;
        /**
        * send block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#send AwsMailmanagerRuleSet#send}
        */
        readonly send?: SendProperty[] | cdktn.IResolvable;
        /**
        * write_to_s3 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#write_to_s3 AwsMailmanagerRuleSet#write_to_s3}
        */
        readonly writeToS3?: WriteToS3Property[] | cdktn.IResolvable;
    }
    class ActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ActionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ActionProperty | cdktn.IResolvable | undefined);
        private _addHeader;
        get addHeader(): AddHeaderPropertyList;
        putAddHeader(value: AddHeaderProperty[] | cdktn.IResolvable): void;
        resetAddHeader(): void;
        get addHeaderInput(): cdktn.IResolvable | AddHeaderProperty[] | undefined;
        private _archive;
        get archive(): ArchivePropertyList;
        putArchive(value: ArchiveProperty[] | cdktn.IResolvable): void;
        resetArchive(): void;
        get archiveInput(): cdktn.IResolvable | ArchiveProperty[] | undefined;
        private _bounce;
        get bounce(): BouncePropertyList;
        putBounce(value: BounceProperty[] | cdktn.IResolvable): void;
        resetBounce(): void;
        get bounceInput(): cdktn.IResolvable | BounceProperty[] | undefined;
        private _deliverToMailbox;
        get deliverToMailbox(): DeliverToMailboxPropertyList;
        putDeliverToMailbox(value: DeliverToMailboxProperty[] | cdktn.IResolvable): void;
        resetDeliverToMailbox(): void;
        get deliverToMailboxInput(): cdktn.IResolvable | DeliverToMailboxProperty[] | undefined;
        private _deliverToQBusiness;
        get deliverToQBusiness(): DeliverToQBusinessPropertyList;
        putDeliverToQBusiness(value: DeliverToQBusinessProperty[] | cdktn.IResolvable): void;
        resetDeliverToQBusiness(): void;
        get deliverToQBusinessInput(): cdktn.IResolvable | DeliverToQBusinessProperty[] | undefined;
        private _drop;
        get drop(): DropPropertyList;
        putDrop(value: DropProperty[] | cdktn.IResolvable): void;
        resetDrop(): void;
        get dropInput(): cdktn.IResolvable | DropProperty[] | undefined;
        private _invokeLambda;
        get invokeLambda(): InvokeLambdaPropertyList;
        putInvokeLambda(value: InvokeLambdaProperty[] | cdktn.IResolvable): void;
        resetInvokeLambda(): void;
        get invokeLambdaInput(): cdktn.IResolvable | InvokeLambdaProperty[] | undefined;
        private _publishToSns;
        get publishToSns(): PublishToSnsPropertyList;
        putPublishToSns(value: PublishToSnsProperty[] | cdktn.IResolvable): void;
        resetPublishToSns(): void;
        get publishToSnsInput(): cdktn.IResolvable | PublishToSnsProperty[] | undefined;
        private _relay;
        get relay(): RelayPropertyList;
        putRelay(value: RelayProperty[] | cdktn.IResolvable): void;
        resetRelay(): void;
        get relayInput(): cdktn.IResolvable | RelayProperty[] | undefined;
        private _replaceRecipient;
        get replaceRecipient(): ReplaceRecipientPropertyList;
        putReplaceRecipient(value: ReplaceRecipientProperty[] | cdktn.IResolvable): void;
        resetReplaceRecipient(): void;
        get replaceRecipientInput(): cdktn.IResolvable | ReplaceRecipientProperty[] | undefined;
        private _send;
        get send(): SendPropertyList;
        putSend(value: SendProperty[] | cdktn.IResolvable): void;
        resetSend(): void;
        get sendInput(): cdktn.IResolvable | SendProperty[] | undefined;
        private _writeToS3;
        get writeToS3(): WriteToS3PropertyList;
        putWriteToS3(value: WriteToS3Property[] | cdktn.IResolvable): void;
        resetWriteToS3(): void;
        get writeToS3Input(): cdktn.IResolvable | WriteToS3Property[] | undefined;
    }
    class ActionPropertyList extends cdktn.ComplexList {
        internalValue?: ActionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ActionPropertyOutputReference;
    }
    interface RuleConditionBooleanExpressionEvaluateAnalysisProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#analyzer AwsMailmanagerRuleSet#analyzer}
        */
        readonly analyzer: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#result_field AwsMailmanagerRuleSet#result_field}
        */
        readonly resultField: string;
    }
    class RuleConditionBooleanExpressionEvaluateAnalysisPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleConditionBooleanExpressionEvaluateAnalysisProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleConditionBooleanExpressionEvaluateAnalysisProperty | cdktn.IResolvable | undefined);
        private _analyzer?;
        get analyzer(): string;
        set analyzer(value: string);
        get analyzerInput(): string | undefined;
        private _resultField?;
        get resultField(): string;
        set resultField(value: string);
        get resultFieldInput(): string | undefined;
    }
    class RuleConditionBooleanExpressionEvaluateAnalysisPropertyList extends cdktn.ComplexList {
        internalValue?: RuleConditionBooleanExpressionEvaluateAnalysisProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleConditionBooleanExpressionEvaluateAnalysisPropertyOutputReference;
    }
    interface RuleConditionBooleanExpressionEvaluateIsInAddressListProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#address_lists AwsMailmanagerRuleSet#address_lists}
        */
        readonly addressLists: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#attribute AwsMailmanagerRuleSet#attribute}
        */
        readonly attribute: string;
    }
    class RuleConditionBooleanExpressionEvaluateIsInAddressListPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleConditionBooleanExpressionEvaluateIsInAddressListProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleConditionBooleanExpressionEvaluateIsInAddressListProperty | cdktn.IResolvable | undefined);
        private _addressLists?;
        get addressLists(): string[];
        set addressLists(value: string[]);
        get addressListsInput(): string[] | undefined;
        private _attribute?;
        get attribute(): string;
        set attribute(value: string);
        get attributeInput(): string | undefined;
    }
    class RuleConditionBooleanExpressionEvaluateIsInAddressListPropertyList extends cdktn.ComplexList {
        internalValue?: RuleConditionBooleanExpressionEvaluateIsInAddressListProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleConditionBooleanExpressionEvaluateIsInAddressListPropertyOutputReference;
    }
    interface RuleConditionBooleanExpressionEvaluateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#attribute AwsMailmanagerRuleSet#attribute}
        */
        readonly attribute?: string;
        /**
        * analysis block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#analysis AwsMailmanagerRuleSet#analysis}
        */
        readonly analysis?: RuleConditionBooleanExpressionEvaluateAnalysisProperty[] | cdktn.IResolvable;
        /**
        * is_in_address_list block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#is_in_address_list AwsMailmanagerRuleSet#is_in_address_list}
        */
        readonly isInAddressList?: RuleConditionBooleanExpressionEvaluateIsInAddressListProperty[] | cdktn.IResolvable;
    }
    class RuleConditionBooleanExpressionEvaluatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleConditionBooleanExpressionEvaluateProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleConditionBooleanExpressionEvaluateProperty | cdktn.IResolvable | undefined);
        private _attribute?;
        get attribute(): string;
        set attribute(value: string);
        resetAttribute(): void;
        get attributeInput(): string | undefined;
        private _analysis;
        get analysis(): RuleConditionBooleanExpressionEvaluateAnalysisPropertyList;
        putAnalysis(value: RuleConditionBooleanExpressionEvaluateAnalysisProperty[] | cdktn.IResolvable): void;
        resetAnalysis(): void;
        get analysisInput(): cdktn.IResolvable | RuleConditionBooleanExpressionEvaluateAnalysisProperty[] | undefined;
        private _isInAddressList;
        get isInAddressList(): RuleConditionBooleanExpressionEvaluateIsInAddressListPropertyList;
        putIsInAddressList(value: RuleConditionBooleanExpressionEvaluateIsInAddressListProperty[] | cdktn.IResolvable): void;
        resetIsInAddressList(): void;
        get isInAddressListInput(): cdktn.IResolvable | RuleConditionBooleanExpressionEvaluateIsInAddressListProperty[] | undefined;
    }
    class RuleConditionBooleanExpressionEvaluatePropertyList extends cdktn.ComplexList {
        internalValue?: RuleConditionBooleanExpressionEvaluateProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleConditionBooleanExpressionEvaluatePropertyOutputReference;
    }
    interface RuleConditionBooleanExpressionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#operator AwsMailmanagerRuleSet#operator}
        */
        readonly operator: string;
        /**
        * evaluate block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#evaluate AwsMailmanagerRuleSet#evaluate}
        */
        readonly evaluate?: RuleConditionBooleanExpressionEvaluateProperty[] | cdktn.IResolvable;
    }
    class RuleConditionBooleanExpressionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleConditionBooleanExpressionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleConditionBooleanExpressionProperty | cdktn.IResolvable | undefined);
        private _operator?;
        get operator(): string;
        set operator(value: string);
        get operatorInput(): string | undefined;
        private _evaluate;
        get evaluate(): RuleConditionBooleanExpressionEvaluatePropertyList;
        putEvaluate(value: RuleConditionBooleanExpressionEvaluateProperty[] | cdktn.IResolvable): void;
        resetEvaluate(): void;
        get evaluateInput(): cdktn.IResolvable | RuleConditionBooleanExpressionEvaluateProperty[] | undefined;
    }
    class RuleConditionBooleanExpressionPropertyList extends cdktn.ComplexList {
        internalValue?: RuleConditionBooleanExpressionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleConditionBooleanExpressionPropertyOutputReference;
    }
    interface RuleConditionDmarcExpressionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#operator AwsMailmanagerRuleSet#operator}
        */
        readonly operator: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#values AwsMailmanagerRuleSet#values}
        */
        readonly values: string[];
    }
    class RuleConditionDmarcExpressionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleConditionDmarcExpressionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleConditionDmarcExpressionProperty | cdktn.IResolvable | undefined);
        private _operator?;
        get operator(): string;
        set operator(value: string);
        get operatorInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class RuleConditionDmarcExpressionPropertyList extends cdktn.ComplexList {
        internalValue?: RuleConditionDmarcExpressionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleConditionDmarcExpressionPropertyOutputReference;
    }
    interface RuleConditionIpExpressionEvaluateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#attribute AwsMailmanagerRuleSet#attribute}
        */
        readonly attribute: string;
    }
    class RuleConditionIpExpressionEvaluatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleConditionIpExpressionEvaluateProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleConditionIpExpressionEvaluateProperty | cdktn.IResolvable | undefined);
        private _attribute?;
        get attribute(): string;
        set attribute(value: string);
        get attributeInput(): string | undefined;
    }
    class RuleConditionIpExpressionEvaluatePropertyList extends cdktn.ComplexList {
        internalValue?: RuleConditionIpExpressionEvaluateProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleConditionIpExpressionEvaluatePropertyOutputReference;
    }
    interface RuleConditionIpExpressionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#operator AwsMailmanagerRuleSet#operator}
        */
        readonly operator: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#values AwsMailmanagerRuleSet#values}
        */
        readonly values: string[];
        /**
        * evaluate block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#evaluate AwsMailmanagerRuleSet#evaluate}
        */
        readonly evaluate?: RuleConditionIpExpressionEvaluateProperty[] | cdktn.IResolvable;
    }
    class RuleConditionIpExpressionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleConditionIpExpressionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleConditionIpExpressionProperty | cdktn.IResolvable | undefined);
        private _operator?;
        get operator(): string;
        set operator(value: string);
        get operatorInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
        private _evaluate;
        get evaluate(): RuleConditionIpExpressionEvaluatePropertyList;
        putEvaluate(value: RuleConditionIpExpressionEvaluateProperty[] | cdktn.IResolvable): void;
        resetEvaluate(): void;
        get evaluateInput(): cdktn.IResolvable | RuleConditionIpExpressionEvaluateProperty[] | undefined;
    }
    class RuleConditionIpExpressionPropertyList extends cdktn.ComplexList {
        internalValue?: RuleConditionIpExpressionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleConditionIpExpressionPropertyOutputReference;
    }
    interface RuleConditionNumberExpressionEvaluateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#attribute AwsMailmanagerRuleSet#attribute}
        */
        readonly attribute: string;
    }
    class RuleConditionNumberExpressionEvaluatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleConditionNumberExpressionEvaluateProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleConditionNumberExpressionEvaluateProperty | cdktn.IResolvable | undefined);
        private _attribute?;
        get attribute(): string;
        set attribute(value: string);
        get attributeInput(): string | undefined;
    }
    class RuleConditionNumberExpressionEvaluatePropertyList extends cdktn.ComplexList {
        internalValue?: RuleConditionNumberExpressionEvaluateProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleConditionNumberExpressionEvaluatePropertyOutputReference;
    }
    interface RuleConditionNumberExpressionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#operator AwsMailmanagerRuleSet#operator}
        */
        readonly operator: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#value AwsMailmanagerRuleSet#value}
        */
        readonly value: number;
        /**
        * evaluate block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#evaluate AwsMailmanagerRuleSet#evaluate}
        */
        readonly evaluate?: RuleConditionNumberExpressionEvaluateProperty[] | cdktn.IResolvable;
    }
    class RuleConditionNumberExpressionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleConditionNumberExpressionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleConditionNumberExpressionProperty | cdktn.IResolvable | undefined);
        private _operator?;
        get operator(): string;
        set operator(value: string);
        get operatorInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
        private _evaluate;
        get evaluate(): RuleConditionNumberExpressionEvaluatePropertyList;
        putEvaluate(value: RuleConditionNumberExpressionEvaluateProperty[] | cdktn.IResolvable): void;
        resetEvaluate(): void;
        get evaluateInput(): cdktn.IResolvable | RuleConditionNumberExpressionEvaluateProperty[] | undefined;
    }
    class RuleConditionNumberExpressionPropertyList extends cdktn.ComplexList {
        internalValue?: RuleConditionNumberExpressionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleConditionNumberExpressionPropertyOutputReference;
    }
    interface RuleConditionStringExpressionEvaluateAnalysisProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#analyzer AwsMailmanagerRuleSet#analyzer}
        */
        readonly analyzer: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#result_field AwsMailmanagerRuleSet#result_field}
        */
        readonly resultField: string;
    }
    class RuleConditionStringExpressionEvaluateAnalysisPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleConditionStringExpressionEvaluateAnalysisProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleConditionStringExpressionEvaluateAnalysisProperty | cdktn.IResolvable | undefined);
        private _analyzer?;
        get analyzer(): string;
        set analyzer(value: string);
        get analyzerInput(): string | undefined;
        private _resultField?;
        get resultField(): string;
        set resultField(value: string);
        get resultFieldInput(): string | undefined;
    }
    class RuleConditionStringExpressionEvaluateAnalysisPropertyList extends cdktn.ComplexList {
        internalValue?: RuleConditionStringExpressionEvaluateAnalysisProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleConditionStringExpressionEvaluateAnalysisPropertyOutputReference;
    }
    interface RuleConditionStringExpressionEvaluateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#attribute AwsMailmanagerRuleSet#attribute}
        */
        readonly attribute?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#client_certificate_attribute AwsMailmanagerRuleSet#client_certificate_attribute}
        */
        readonly clientCertificateAttribute?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#mime_header_attribute AwsMailmanagerRuleSet#mime_header_attribute}
        */
        readonly mimeHeaderAttribute?: string;
        /**
        * analysis block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#analysis AwsMailmanagerRuleSet#analysis}
        */
        readonly analysis?: RuleConditionStringExpressionEvaluateAnalysisProperty[] | cdktn.IResolvable;
    }
    class RuleConditionStringExpressionEvaluatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleConditionStringExpressionEvaluateProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleConditionStringExpressionEvaluateProperty | cdktn.IResolvable | undefined);
        private _attribute?;
        get attribute(): string;
        set attribute(value: string);
        resetAttribute(): void;
        get attributeInput(): string | undefined;
        private _clientCertificateAttribute?;
        get clientCertificateAttribute(): string;
        set clientCertificateAttribute(value: string);
        resetClientCertificateAttribute(): void;
        get clientCertificateAttributeInput(): string | undefined;
        private _mimeHeaderAttribute?;
        get mimeHeaderAttribute(): string;
        set mimeHeaderAttribute(value: string);
        resetMimeHeaderAttribute(): void;
        get mimeHeaderAttributeInput(): string | undefined;
        private _analysis;
        get analysis(): RuleConditionStringExpressionEvaluateAnalysisPropertyList;
        putAnalysis(value: RuleConditionStringExpressionEvaluateAnalysisProperty[] | cdktn.IResolvable): void;
        resetAnalysis(): void;
        get analysisInput(): cdktn.IResolvable | RuleConditionStringExpressionEvaluateAnalysisProperty[] | undefined;
    }
    class RuleConditionStringExpressionEvaluatePropertyList extends cdktn.ComplexList {
        internalValue?: RuleConditionStringExpressionEvaluateProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleConditionStringExpressionEvaluatePropertyOutputReference;
    }
    interface RuleConditionStringExpressionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#operator AwsMailmanagerRuleSet#operator}
        */
        readonly operator: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#values AwsMailmanagerRuleSet#values}
        */
        readonly values: string[];
        /**
        * evaluate block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#evaluate AwsMailmanagerRuleSet#evaluate}
        */
        readonly evaluate?: RuleConditionStringExpressionEvaluateProperty[] | cdktn.IResolvable;
    }
    class RuleConditionStringExpressionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleConditionStringExpressionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleConditionStringExpressionProperty | cdktn.IResolvable | undefined);
        private _operator?;
        get operator(): string;
        set operator(value: string);
        get operatorInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
        private _evaluate;
        get evaluate(): RuleConditionStringExpressionEvaluatePropertyList;
        putEvaluate(value: RuleConditionStringExpressionEvaluateProperty[] | cdktn.IResolvable): void;
        resetEvaluate(): void;
        get evaluateInput(): cdktn.IResolvable | RuleConditionStringExpressionEvaluateProperty[] | undefined;
    }
    class RuleConditionStringExpressionPropertyList extends cdktn.ComplexList {
        internalValue?: RuleConditionStringExpressionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleConditionStringExpressionPropertyOutputReference;
    }
    interface RuleConditionVerdictExpressionEvaluateAnalysisProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#analyzer AwsMailmanagerRuleSet#analyzer}
        */
        readonly analyzer: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#result_field AwsMailmanagerRuleSet#result_field}
        */
        readonly resultField: string;
    }
    class RuleConditionVerdictExpressionEvaluateAnalysisPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleConditionVerdictExpressionEvaluateAnalysisProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleConditionVerdictExpressionEvaluateAnalysisProperty | cdktn.IResolvable | undefined);
        private _analyzer?;
        get analyzer(): string;
        set analyzer(value: string);
        get analyzerInput(): string | undefined;
        private _resultField?;
        get resultField(): string;
        set resultField(value: string);
        get resultFieldInput(): string | undefined;
    }
    class RuleConditionVerdictExpressionEvaluateAnalysisPropertyList extends cdktn.ComplexList {
        internalValue?: RuleConditionVerdictExpressionEvaluateAnalysisProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleConditionVerdictExpressionEvaluateAnalysisPropertyOutputReference;
    }
    interface RuleConditionVerdictExpressionEvaluateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#attribute AwsMailmanagerRuleSet#attribute}
        */
        readonly attribute?: string;
        /**
        * analysis block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#analysis AwsMailmanagerRuleSet#analysis}
        */
        readonly analysis?: RuleConditionVerdictExpressionEvaluateAnalysisProperty[] | cdktn.IResolvable;
    }
    class RuleConditionVerdictExpressionEvaluatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleConditionVerdictExpressionEvaluateProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleConditionVerdictExpressionEvaluateProperty | cdktn.IResolvable | undefined);
        private _attribute?;
        get attribute(): string;
        set attribute(value: string);
        resetAttribute(): void;
        get attributeInput(): string | undefined;
        private _analysis;
        get analysis(): RuleConditionVerdictExpressionEvaluateAnalysisPropertyList;
        putAnalysis(value: RuleConditionVerdictExpressionEvaluateAnalysisProperty[] | cdktn.IResolvable): void;
        resetAnalysis(): void;
        get analysisInput(): cdktn.IResolvable | RuleConditionVerdictExpressionEvaluateAnalysisProperty[] | undefined;
    }
    class RuleConditionVerdictExpressionEvaluatePropertyList extends cdktn.ComplexList {
        internalValue?: RuleConditionVerdictExpressionEvaluateProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleConditionVerdictExpressionEvaluatePropertyOutputReference;
    }
    interface RuleConditionVerdictExpressionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#operator AwsMailmanagerRuleSet#operator}
        */
        readonly operator: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#values AwsMailmanagerRuleSet#values}
        */
        readonly values: string[];
        /**
        * evaluate block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#evaluate AwsMailmanagerRuleSet#evaluate}
        */
        readonly evaluate?: RuleConditionVerdictExpressionEvaluateProperty[] | cdktn.IResolvable;
    }
    class RuleConditionVerdictExpressionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleConditionVerdictExpressionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleConditionVerdictExpressionProperty | cdktn.IResolvable | undefined);
        private _operator?;
        get operator(): string;
        set operator(value: string);
        get operatorInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
        private _evaluate;
        get evaluate(): RuleConditionVerdictExpressionEvaluatePropertyList;
        putEvaluate(value: RuleConditionVerdictExpressionEvaluateProperty[] | cdktn.IResolvable): void;
        resetEvaluate(): void;
        get evaluateInput(): cdktn.IResolvable | RuleConditionVerdictExpressionEvaluateProperty[] | undefined;
    }
    class RuleConditionVerdictExpressionPropertyList extends cdktn.ComplexList {
        internalValue?: RuleConditionVerdictExpressionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleConditionVerdictExpressionPropertyOutputReference;
    }
    interface ConditionProperty {
        /**
        * boolean_expression block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#boolean_expression AwsMailmanagerRuleSet#boolean_expression}
        */
        readonly booleanExpression?: RuleConditionBooleanExpressionProperty[] | cdktn.IResolvable;
        /**
        * dmarc_expression block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#dmarc_expression AwsMailmanagerRuleSet#dmarc_expression}
        */
        readonly dmarcExpression?: RuleConditionDmarcExpressionProperty[] | cdktn.IResolvable;
        /**
        * ip_expression block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#ip_expression AwsMailmanagerRuleSet#ip_expression}
        */
        readonly ipExpression?: RuleConditionIpExpressionProperty[] | cdktn.IResolvable;
        /**
        * number_expression block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#number_expression AwsMailmanagerRuleSet#number_expression}
        */
        readonly numberExpression?: RuleConditionNumberExpressionProperty[] | cdktn.IResolvable;
        /**
        * string_expression block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#string_expression AwsMailmanagerRuleSet#string_expression}
        */
        readonly stringExpression?: RuleConditionStringExpressionProperty[] | cdktn.IResolvable;
        /**
        * verdict_expression block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#verdict_expression AwsMailmanagerRuleSet#verdict_expression}
        */
        readonly verdictExpression?: RuleConditionVerdictExpressionProperty[] | cdktn.IResolvable;
    }
    class ConditionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConditionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConditionProperty | cdktn.IResolvable | undefined);
        private _booleanExpression;
        get booleanExpression(): RuleConditionBooleanExpressionPropertyList;
        putBooleanExpression(value: RuleConditionBooleanExpressionProperty[] | cdktn.IResolvable): void;
        resetBooleanExpression(): void;
        get booleanExpressionInput(): cdktn.IResolvable | RuleConditionBooleanExpressionProperty[] | undefined;
        private _dmarcExpression;
        get dmarcExpression(): RuleConditionDmarcExpressionPropertyList;
        putDmarcExpression(value: RuleConditionDmarcExpressionProperty[] | cdktn.IResolvable): void;
        resetDmarcExpression(): void;
        get dmarcExpressionInput(): cdktn.IResolvable | RuleConditionDmarcExpressionProperty[] | undefined;
        private _ipExpression;
        get ipExpression(): RuleConditionIpExpressionPropertyList;
        putIpExpression(value: RuleConditionIpExpressionProperty[] | cdktn.IResolvable): void;
        resetIpExpression(): void;
        get ipExpressionInput(): cdktn.IResolvable | RuleConditionIpExpressionProperty[] | undefined;
        private _numberExpression;
        get numberExpression(): RuleConditionNumberExpressionPropertyList;
        putNumberExpression(value: RuleConditionNumberExpressionProperty[] | cdktn.IResolvable): void;
        resetNumberExpression(): void;
        get numberExpressionInput(): cdktn.IResolvable | RuleConditionNumberExpressionProperty[] | undefined;
        private _stringExpression;
        get stringExpression(): RuleConditionStringExpressionPropertyList;
        putStringExpression(value: RuleConditionStringExpressionProperty[] | cdktn.IResolvable): void;
        resetStringExpression(): void;
        get stringExpressionInput(): cdktn.IResolvable | RuleConditionStringExpressionProperty[] | undefined;
        private _verdictExpression;
        get verdictExpression(): RuleConditionVerdictExpressionPropertyList;
        putVerdictExpression(value: RuleConditionVerdictExpressionProperty[] | cdktn.IResolvable): void;
        resetVerdictExpression(): void;
        get verdictExpressionInput(): cdktn.IResolvable | RuleConditionVerdictExpressionProperty[] | undefined;
    }
    class ConditionPropertyList extends cdktn.ComplexList {
        internalValue?: ConditionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConditionPropertyOutputReference;
    }
    interface RuleUnlessBooleanExpressionEvaluateAnalysisProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#analyzer AwsMailmanagerRuleSet#analyzer}
        */
        readonly analyzer: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#result_field AwsMailmanagerRuleSet#result_field}
        */
        readonly resultField: string;
    }
    class RuleUnlessBooleanExpressionEvaluateAnalysisPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleUnlessBooleanExpressionEvaluateAnalysisProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleUnlessBooleanExpressionEvaluateAnalysisProperty | cdktn.IResolvable | undefined);
        private _analyzer?;
        get analyzer(): string;
        set analyzer(value: string);
        get analyzerInput(): string | undefined;
        private _resultField?;
        get resultField(): string;
        set resultField(value: string);
        get resultFieldInput(): string | undefined;
    }
    class RuleUnlessBooleanExpressionEvaluateAnalysisPropertyList extends cdktn.ComplexList {
        internalValue?: RuleUnlessBooleanExpressionEvaluateAnalysisProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleUnlessBooleanExpressionEvaluateAnalysisPropertyOutputReference;
    }
    interface RuleUnlessBooleanExpressionEvaluateIsInAddressListProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#address_lists AwsMailmanagerRuleSet#address_lists}
        */
        readonly addressLists: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#attribute AwsMailmanagerRuleSet#attribute}
        */
        readonly attribute: string;
    }
    class RuleUnlessBooleanExpressionEvaluateIsInAddressListPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleUnlessBooleanExpressionEvaluateIsInAddressListProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleUnlessBooleanExpressionEvaluateIsInAddressListProperty | cdktn.IResolvable | undefined);
        private _addressLists?;
        get addressLists(): string[];
        set addressLists(value: string[]);
        get addressListsInput(): string[] | undefined;
        private _attribute?;
        get attribute(): string;
        set attribute(value: string);
        get attributeInput(): string | undefined;
    }
    class RuleUnlessBooleanExpressionEvaluateIsInAddressListPropertyList extends cdktn.ComplexList {
        internalValue?: RuleUnlessBooleanExpressionEvaluateIsInAddressListProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleUnlessBooleanExpressionEvaluateIsInAddressListPropertyOutputReference;
    }
    interface RuleUnlessBooleanExpressionEvaluateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#attribute AwsMailmanagerRuleSet#attribute}
        */
        readonly attribute?: string;
        /**
        * analysis block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#analysis AwsMailmanagerRuleSet#analysis}
        */
        readonly analysis?: RuleUnlessBooleanExpressionEvaluateAnalysisProperty[] | cdktn.IResolvable;
        /**
        * is_in_address_list block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#is_in_address_list AwsMailmanagerRuleSet#is_in_address_list}
        */
        readonly isInAddressList?: RuleUnlessBooleanExpressionEvaluateIsInAddressListProperty[] | cdktn.IResolvable;
    }
    class RuleUnlessBooleanExpressionEvaluatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleUnlessBooleanExpressionEvaluateProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleUnlessBooleanExpressionEvaluateProperty | cdktn.IResolvable | undefined);
        private _attribute?;
        get attribute(): string;
        set attribute(value: string);
        resetAttribute(): void;
        get attributeInput(): string | undefined;
        private _analysis;
        get analysis(): RuleUnlessBooleanExpressionEvaluateAnalysisPropertyList;
        putAnalysis(value: RuleUnlessBooleanExpressionEvaluateAnalysisProperty[] | cdktn.IResolvable): void;
        resetAnalysis(): void;
        get analysisInput(): cdktn.IResolvable | RuleUnlessBooleanExpressionEvaluateAnalysisProperty[] | undefined;
        private _isInAddressList;
        get isInAddressList(): RuleUnlessBooleanExpressionEvaluateIsInAddressListPropertyList;
        putIsInAddressList(value: RuleUnlessBooleanExpressionEvaluateIsInAddressListProperty[] | cdktn.IResolvable): void;
        resetIsInAddressList(): void;
        get isInAddressListInput(): cdktn.IResolvable | RuleUnlessBooleanExpressionEvaluateIsInAddressListProperty[] | undefined;
    }
    class RuleUnlessBooleanExpressionEvaluatePropertyList extends cdktn.ComplexList {
        internalValue?: RuleUnlessBooleanExpressionEvaluateProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleUnlessBooleanExpressionEvaluatePropertyOutputReference;
    }
    interface RuleUnlessBooleanExpressionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#operator AwsMailmanagerRuleSet#operator}
        */
        readonly operator: string;
        /**
        * evaluate block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#evaluate AwsMailmanagerRuleSet#evaluate}
        */
        readonly evaluate?: RuleUnlessBooleanExpressionEvaluateProperty[] | cdktn.IResolvable;
    }
    class RuleUnlessBooleanExpressionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleUnlessBooleanExpressionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleUnlessBooleanExpressionProperty | cdktn.IResolvable | undefined);
        private _operator?;
        get operator(): string;
        set operator(value: string);
        get operatorInput(): string | undefined;
        private _evaluate;
        get evaluate(): RuleUnlessBooleanExpressionEvaluatePropertyList;
        putEvaluate(value: RuleUnlessBooleanExpressionEvaluateProperty[] | cdktn.IResolvable): void;
        resetEvaluate(): void;
        get evaluateInput(): cdktn.IResolvable | RuleUnlessBooleanExpressionEvaluateProperty[] | undefined;
    }
    class RuleUnlessBooleanExpressionPropertyList extends cdktn.ComplexList {
        internalValue?: RuleUnlessBooleanExpressionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleUnlessBooleanExpressionPropertyOutputReference;
    }
    interface RuleUnlessDmarcExpressionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#operator AwsMailmanagerRuleSet#operator}
        */
        readonly operator: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#values AwsMailmanagerRuleSet#values}
        */
        readonly values: string[];
    }
    class RuleUnlessDmarcExpressionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleUnlessDmarcExpressionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleUnlessDmarcExpressionProperty | cdktn.IResolvable | undefined);
        private _operator?;
        get operator(): string;
        set operator(value: string);
        get operatorInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class RuleUnlessDmarcExpressionPropertyList extends cdktn.ComplexList {
        internalValue?: RuleUnlessDmarcExpressionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleUnlessDmarcExpressionPropertyOutputReference;
    }
    interface RuleUnlessIpExpressionEvaluateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#attribute AwsMailmanagerRuleSet#attribute}
        */
        readonly attribute: string;
    }
    class RuleUnlessIpExpressionEvaluatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleUnlessIpExpressionEvaluateProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleUnlessIpExpressionEvaluateProperty | cdktn.IResolvable | undefined);
        private _attribute?;
        get attribute(): string;
        set attribute(value: string);
        get attributeInput(): string | undefined;
    }
    class RuleUnlessIpExpressionEvaluatePropertyList extends cdktn.ComplexList {
        internalValue?: RuleUnlessIpExpressionEvaluateProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleUnlessIpExpressionEvaluatePropertyOutputReference;
    }
    interface RuleUnlessIpExpressionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#operator AwsMailmanagerRuleSet#operator}
        */
        readonly operator: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#values AwsMailmanagerRuleSet#values}
        */
        readonly values: string[];
        /**
        * evaluate block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#evaluate AwsMailmanagerRuleSet#evaluate}
        */
        readonly evaluate?: RuleUnlessIpExpressionEvaluateProperty[] | cdktn.IResolvable;
    }
    class RuleUnlessIpExpressionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleUnlessIpExpressionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleUnlessIpExpressionProperty | cdktn.IResolvable | undefined);
        private _operator?;
        get operator(): string;
        set operator(value: string);
        get operatorInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
        private _evaluate;
        get evaluate(): RuleUnlessIpExpressionEvaluatePropertyList;
        putEvaluate(value: RuleUnlessIpExpressionEvaluateProperty[] | cdktn.IResolvable): void;
        resetEvaluate(): void;
        get evaluateInput(): cdktn.IResolvable | RuleUnlessIpExpressionEvaluateProperty[] | undefined;
    }
    class RuleUnlessIpExpressionPropertyList extends cdktn.ComplexList {
        internalValue?: RuleUnlessIpExpressionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleUnlessIpExpressionPropertyOutputReference;
    }
    interface RuleUnlessNumberExpressionEvaluateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#attribute AwsMailmanagerRuleSet#attribute}
        */
        readonly attribute: string;
    }
    class RuleUnlessNumberExpressionEvaluatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleUnlessNumberExpressionEvaluateProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleUnlessNumberExpressionEvaluateProperty | cdktn.IResolvable | undefined);
        private _attribute?;
        get attribute(): string;
        set attribute(value: string);
        get attributeInput(): string | undefined;
    }
    class RuleUnlessNumberExpressionEvaluatePropertyList extends cdktn.ComplexList {
        internalValue?: RuleUnlessNumberExpressionEvaluateProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleUnlessNumberExpressionEvaluatePropertyOutputReference;
    }
    interface RuleUnlessNumberExpressionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#operator AwsMailmanagerRuleSet#operator}
        */
        readonly operator: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#value AwsMailmanagerRuleSet#value}
        */
        readonly value: number;
        /**
        * evaluate block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#evaluate AwsMailmanagerRuleSet#evaluate}
        */
        readonly evaluate?: RuleUnlessNumberExpressionEvaluateProperty[] | cdktn.IResolvable;
    }
    class RuleUnlessNumberExpressionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleUnlessNumberExpressionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleUnlessNumberExpressionProperty | cdktn.IResolvable | undefined);
        private _operator?;
        get operator(): string;
        set operator(value: string);
        get operatorInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
        private _evaluate;
        get evaluate(): RuleUnlessNumberExpressionEvaluatePropertyList;
        putEvaluate(value: RuleUnlessNumberExpressionEvaluateProperty[] | cdktn.IResolvable): void;
        resetEvaluate(): void;
        get evaluateInput(): cdktn.IResolvable | RuleUnlessNumberExpressionEvaluateProperty[] | undefined;
    }
    class RuleUnlessNumberExpressionPropertyList extends cdktn.ComplexList {
        internalValue?: RuleUnlessNumberExpressionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleUnlessNumberExpressionPropertyOutputReference;
    }
    interface RuleUnlessStringExpressionEvaluateAnalysisProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#analyzer AwsMailmanagerRuleSet#analyzer}
        */
        readonly analyzer: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#result_field AwsMailmanagerRuleSet#result_field}
        */
        readonly resultField: string;
    }
    class RuleUnlessStringExpressionEvaluateAnalysisPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleUnlessStringExpressionEvaluateAnalysisProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleUnlessStringExpressionEvaluateAnalysisProperty | cdktn.IResolvable | undefined);
        private _analyzer?;
        get analyzer(): string;
        set analyzer(value: string);
        get analyzerInput(): string | undefined;
        private _resultField?;
        get resultField(): string;
        set resultField(value: string);
        get resultFieldInput(): string | undefined;
    }
    class RuleUnlessStringExpressionEvaluateAnalysisPropertyList extends cdktn.ComplexList {
        internalValue?: RuleUnlessStringExpressionEvaluateAnalysisProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleUnlessStringExpressionEvaluateAnalysisPropertyOutputReference;
    }
    interface RuleUnlessStringExpressionEvaluateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#attribute AwsMailmanagerRuleSet#attribute}
        */
        readonly attribute?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#client_certificate_attribute AwsMailmanagerRuleSet#client_certificate_attribute}
        */
        readonly clientCertificateAttribute?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#mime_header_attribute AwsMailmanagerRuleSet#mime_header_attribute}
        */
        readonly mimeHeaderAttribute?: string;
        /**
        * analysis block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#analysis AwsMailmanagerRuleSet#analysis}
        */
        readonly analysis?: RuleUnlessStringExpressionEvaluateAnalysisProperty[] | cdktn.IResolvable;
    }
    class RuleUnlessStringExpressionEvaluatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleUnlessStringExpressionEvaluateProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleUnlessStringExpressionEvaluateProperty | cdktn.IResolvable | undefined);
        private _attribute?;
        get attribute(): string;
        set attribute(value: string);
        resetAttribute(): void;
        get attributeInput(): string | undefined;
        private _clientCertificateAttribute?;
        get clientCertificateAttribute(): string;
        set clientCertificateAttribute(value: string);
        resetClientCertificateAttribute(): void;
        get clientCertificateAttributeInput(): string | undefined;
        private _mimeHeaderAttribute?;
        get mimeHeaderAttribute(): string;
        set mimeHeaderAttribute(value: string);
        resetMimeHeaderAttribute(): void;
        get mimeHeaderAttributeInput(): string | undefined;
        private _analysis;
        get analysis(): RuleUnlessStringExpressionEvaluateAnalysisPropertyList;
        putAnalysis(value: RuleUnlessStringExpressionEvaluateAnalysisProperty[] | cdktn.IResolvable): void;
        resetAnalysis(): void;
        get analysisInput(): cdktn.IResolvable | RuleUnlessStringExpressionEvaluateAnalysisProperty[] | undefined;
    }
    class RuleUnlessStringExpressionEvaluatePropertyList extends cdktn.ComplexList {
        internalValue?: RuleUnlessStringExpressionEvaluateProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleUnlessStringExpressionEvaluatePropertyOutputReference;
    }
    interface RuleUnlessStringExpressionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#operator AwsMailmanagerRuleSet#operator}
        */
        readonly operator: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#values AwsMailmanagerRuleSet#values}
        */
        readonly values: string[];
        /**
        * evaluate block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#evaluate AwsMailmanagerRuleSet#evaluate}
        */
        readonly evaluate?: RuleUnlessStringExpressionEvaluateProperty[] | cdktn.IResolvable;
    }
    class RuleUnlessStringExpressionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleUnlessStringExpressionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleUnlessStringExpressionProperty | cdktn.IResolvable | undefined);
        private _operator?;
        get operator(): string;
        set operator(value: string);
        get operatorInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
        private _evaluate;
        get evaluate(): RuleUnlessStringExpressionEvaluatePropertyList;
        putEvaluate(value: RuleUnlessStringExpressionEvaluateProperty[] | cdktn.IResolvable): void;
        resetEvaluate(): void;
        get evaluateInput(): cdktn.IResolvable | RuleUnlessStringExpressionEvaluateProperty[] | undefined;
    }
    class RuleUnlessStringExpressionPropertyList extends cdktn.ComplexList {
        internalValue?: RuleUnlessStringExpressionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleUnlessStringExpressionPropertyOutputReference;
    }
    interface RuleUnlessVerdictExpressionEvaluateAnalysisProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#analyzer AwsMailmanagerRuleSet#analyzer}
        */
        readonly analyzer: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#result_field AwsMailmanagerRuleSet#result_field}
        */
        readonly resultField: string;
    }
    class RuleUnlessVerdictExpressionEvaluateAnalysisPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleUnlessVerdictExpressionEvaluateAnalysisProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleUnlessVerdictExpressionEvaluateAnalysisProperty | cdktn.IResolvable | undefined);
        private _analyzer?;
        get analyzer(): string;
        set analyzer(value: string);
        get analyzerInput(): string | undefined;
        private _resultField?;
        get resultField(): string;
        set resultField(value: string);
        get resultFieldInput(): string | undefined;
    }
    class RuleUnlessVerdictExpressionEvaluateAnalysisPropertyList extends cdktn.ComplexList {
        internalValue?: RuleUnlessVerdictExpressionEvaluateAnalysisProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleUnlessVerdictExpressionEvaluateAnalysisPropertyOutputReference;
    }
    interface RuleUnlessVerdictExpressionEvaluateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#attribute AwsMailmanagerRuleSet#attribute}
        */
        readonly attribute?: string;
        /**
        * analysis block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#analysis AwsMailmanagerRuleSet#analysis}
        */
        readonly analysis?: RuleUnlessVerdictExpressionEvaluateAnalysisProperty[] | cdktn.IResolvable;
    }
    class RuleUnlessVerdictExpressionEvaluatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleUnlessVerdictExpressionEvaluateProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleUnlessVerdictExpressionEvaluateProperty | cdktn.IResolvable | undefined);
        private _attribute?;
        get attribute(): string;
        set attribute(value: string);
        resetAttribute(): void;
        get attributeInput(): string | undefined;
        private _analysis;
        get analysis(): RuleUnlessVerdictExpressionEvaluateAnalysisPropertyList;
        putAnalysis(value: RuleUnlessVerdictExpressionEvaluateAnalysisProperty[] | cdktn.IResolvable): void;
        resetAnalysis(): void;
        get analysisInput(): cdktn.IResolvable | RuleUnlessVerdictExpressionEvaluateAnalysisProperty[] | undefined;
    }
    class RuleUnlessVerdictExpressionEvaluatePropertyList extends cdktn.ComplexList {
        internalValue?: RuleUnlessVerdictExpressionEvaluateProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleUnlessVerdictExpressionEvaluatePropertyOutputReference;
    }
    interface RuleUnlessVerdictExpressionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#operator AwsMailmanagerRuleSet#operator}
        */
        readonly operator: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#values AwsMailmanagerRuleSet#values}
        */
        readonly values: string[];
        /**
        * evaluate block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#evaluate AwsMailmanagerRuleSet#evaluate}
        */
        readonly evaluate?: RuleUnlessVerdictExpressionEvaluateProperty[] | cdktn.IResolvable;
    }
    class RuleUnlessVerdictExpressionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleUnlessVerdictExpressionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleUnlessVerdictExpressionProperty | cdktn.IResolvable | undefined);
        private _operator?;
        get operator(): string;
        set operator(value: string);
        get operatorInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
        private _evaluate;
        get evaluate(): RuleUnlessVerdictExpressionEvaluatePropertyList;
        putEvaluate(value: RuleUnlessVerdictExpressionEvaluateProperty[] | cdktn.IResolvable): void;
        resetEvaluate(): void;
        get evaluateInput(): cdktn.IResolvable | RuleUnlessVerdictExpressionEvaluateProperty[] | undefined;
    }
    class RuleUnlessVerdictExpressionPropertyList extends cdktn.ComplexList {
        internalValue?: RuleUnlessVerdictExpressionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleUnlessVerdictExpressionPropertyOutputReference;
    }
    interface UnlessProperty {
        /**
        * boolean_expression block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#boolean_expression AwsMailmanagerRuleSet#boolean_expression}
        */
        readonly booleanExpression?: RuleUnlessBooleanExpressionProperty[] | cdktn.IResolvable;
        /**
        * dmarc_expression block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#dmarc_expression AwsMailmanagerRuleSet#dmarc_expression}
        */
        readonly dmarcExpression?: RuleUnlessDmarcExpressionProperty[] | cdktn.IResolvable;
        /**
        * ip_expression block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#ip_expression AwsMailmanagerRuleSet#ip_expression}
        */
        readonly ipExpression?: RuleUnlessIpExpressionProperty[] | cdktn.IResolvable;
        /**
        * number_expression block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#number_expression AwsMailmanagerRuleSet#number_expression}
        */
        readonly numberExpression?: RuleUnlessNumberExpressionProperty[] | cdktn.IResolvable;
        /**
        * string_expression block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#string_expression AwsMailmanagerRuleSet#string_expression}
        */
        readonly stringExpression?: RuleUnlessStringExpressionProperty[] | cdktn.IResolvable;
        /**
        * verdict_expression block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#verdict_expression AwsMailmanagerRuleSet#verdict_expression}
        */
        readonly verdictExpression?: RuleUnlessVerdictExpressionProperty[] | cdktn.IResolvable;
    }
    class UnlessPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UnlessProperty | cdktn.IResolvable | undefined;
        set internalValue(value: UnlessProperty | cdktn.IResolvable | undefined);
        private _booleanExpression;
        get booleanExpression(): RuleUnlessBooleanExpressionPropertyList;
        putBooleanExpression(value: RuleUnlessBooleanExpressionProperty[] | cdktn.IResolvable): void;
        resetBooleanExpression(): void;
        get booleanExpressionInput(): cdktn.IResolvable | RuleUnlessBooleanExpressionProperty[] | undefined;
        private _dmarcExpression;
        get dmarcExpression(): RuleUnlessDmarcExpressionPropertyList;
        putDmarcExpression(value: RuleUnlessDmarcExpressionProperty[] | cdktn.IResolvable): void;
        resetDmarcExpression(): void;
        get dmarcExpressionInput(): cdktn.IResolvable | RuleUnlessDmarcExpressionProperty[] | undefined;
        private _ipExpression;
        get ipExpression(): RuleUnlessIpExpressionPropertyList;
        putIpExpression(value: RuleUnlessIpExpressionProperty[] | cdktn.IResolvable): void;
        resetIpExpression(): void;
        get ipExpressionInput(): cdktn.IResolvable | RuleUnlessIpExpressionProperty[] | undefined;
        private _numberExpression;
        get numberExpression(): RuleUnlessNumberExpressionPropertyList;
        putNumberExpression(value: RuleUnlessNumberExpressionProperty[] | cdktn.IResolvable): void;
        resetNumberExpression(): void;
        get numberExpressionInput(): cdktn.IResolvable | RuleUnlessNumberExpressionProperty[] | undefined;
        private _stringExpression;
        get stringExpression(): RuleUnlessStringExpressionPropertyList;
        putStringExpression(value: RuleUnlessStringExpressionProperty[] | cdktn.IResolvable): void;
        resetStringExpression(): void;
        get stringExpressionInput(): cdktn.IResolvable | RuleUnlessStringExpressionProperty[] | undefined;
        private _verdictExpression;
        get verdictExpression(): RuleUnlessVerdictExpressionPropertyList;
        putVerdictExpression(value: RuleUnlessVerdictExpressionProperty[] | cdktn.IResolvable): void;
        resetVerdictExpression(): void;
        get verdictExpressionInput(): cdktn.IResolvable | RuleUnlessVerdictExpressionProperty[] | undefined;
    }
    class UnlessPropertyList extends cdktn.ComplexList {
        internalValue?: UnlessProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UnlessPropertyOutputReference;
    }
    interface RuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#name AwsMailmanagerRuleSet#name}
        */
        readonly name?: string;
        /**
        * action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#action AwsMailmanagerRuleSet#action}
        */
        readonly action?: ActionProperty[] | cdktn.IResolvable;
        /**
        * condition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#condition AwsMailmanagerRuleSet#condition}
        */
        readonly condition?: ConditionProperty[] | cdktn.IResolvable;
        /**
        * unless block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mailmanager_rule_set#unless AwsMailmanagerRuleSet#unless}
        */
        readonly unless?: UnlessProperty[] | cdktn.IResolvable;
    }
    class RulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _action;
        get action(): ActionPropertyList;
        putAction(value: ActionProperty[] | cdktn.IResolvable): void;
        resetAction(): void;
        get actionInput(): cdktn.IResolvable | ActionProperty[] | undefined;
        private _condition;
        get condition(): ConditionPropertyList;
        putCondition(value: ConditionProperty[] | cdktn.IResolvable): void;
        resetCondition(): void;
        get conditionInput(): cdktn.IResolvable | ConditionProperty[] | undefined;
        private _unless;
        get unless(): UnlessPropertyList;
        putUnless(value: UnlessProperty[] | cdktn.IResolvable): void;
        resetUnless(): void;
        get unlessInput(): cdktn.IResolvable | UnlessProperty[] | undefined;
    }
    class RulePropertyList extends cdktn.ComplexList {
        internalValue?: RuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulePropertyOutputReference;
    }
}
