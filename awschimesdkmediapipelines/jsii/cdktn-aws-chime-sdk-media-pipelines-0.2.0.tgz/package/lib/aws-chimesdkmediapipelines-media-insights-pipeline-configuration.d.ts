import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfMediaInsightsPipelineConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#name TfMediaInsightsPipelineConfiguration#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#region TfMediaInsightsPipelineConfiguration#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#resource_access_role_arn TfMediaInsightsPipelineConfiguration#resource_access_role_arn}
    */
    readonly resourceAccessRoleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#tags TfMediaInsightsPipelineConfiguration#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#tags_all TfMediaInsightsPipelineConfiguration#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * elements block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#elements TfMediaInsightsPipelineConfiguration#elements}
    */
    readonly elements: TfMediaInsightsPipelineConfiguration.ElementsProperty[] | cdktn.IResolvable;
    /**
    * real_time_alert_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#real_time_alert_configuration TfMediaInsightsPipelineConfiguration#real_time_alert_configuration}
    */
    readonly realTimeAlertConfiguration?: TfMediaInsightsPipelineConfiguration.RealTimeAlertConfigurationProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#timeouts TfMediaInsightsPipelineConfiguration#timeouts}
    */
    readonly timeouts?: TfMediaInsightsPipelineConfiguration.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration aws_chimesdkmediapipelines_media_insights_pipeline_configuration}
*/
export declare class TfMediaInsightsPipelineConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_chimesdkmediapipelines_media_insights_pipeline_configuration";
    /**
    * Generates CDKTN code for importing a TfMediaInsightsPipelineConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfMediaInsightsPipelineConfiguration to import
    * @param importFromId The id of the existing TfMediaInsightsPipelineConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfMediaInsightsPipelineConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration aws_chimesdkmediapipelines_media_insights_pipeline_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfMediaInsightsPipelineConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: TfMediaInsightsPipelineConfigurationConfig);
    get arn(): string;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourceAccessRoleArn?;
    get resourceAccessRoleArn(): string;
    set resourceAccessRoleArn(value: string);
    get resourceAccessRoleArnInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _elements;
    get elements(): TfMediaInsightsPipelineConfiguration.ElementsPropertyList;
    putElements(value: TfMediaInsightsPipelineConfiguration.ElementsProperty[] | cdktn.IResolvable): void;
    get elementsInput(): cdktn.IResolvable | TfMediaInsightsPipelineConfiguration.ElementsProperty[] | undefined;
    private _realTimeAlertConfiguration;
    get realTimeAlertConfiguration(): TfMediaInsightsPipelineConfiguration.RealTimeAlertConfigurationPropertyOutputReference;
    putRealTimeAlertConfiguration(value: TfMediaInsightsPipelineConfiguration.RealTimeAlertConfigurationProperty): void;
    resetRealTimeAlertConfiguration(): void;
    get realTimeAlertConfigurationInput(): TfMediaInsightsPipelineConfiguration.RealTimeAlertConfigurationProperty | undefined;
    private _timeouts;
    get timeouts(): TfMediaInsightsPipelineConfiguration.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfMediaInsightsPipelineConfiguration.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfMediaInsightsPipelineConfiguration.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfMediaInsightsPipelineConfigurationPostCallAnalyticsSettingsPropertyToTerraform(struct?: TfMediaInsightsPipelineConfiguration.PostCallAnalyticsSettingsPropertyOutputReference | TfMediaInsightsPipelineConfiguration.PostCallAnalyticsSettingsProperty): any;
export declare function tfMediaInsightsPipelineConfigurationPostCallAnalyticsSettingsPropertyToHclTerraform(struct?: TfMediaInsightsPipelineConfiguration.PostCallAnalyticsSettingsPropertyOutputReference | TfMediaInsightsPipelineConfiguration.PostCallAnalyticsSettingsProperty): any;
export declare function tfMediaInsightsPipelineConfigurationAmazonTranscribeCallAnalyticsProcessorConfigurationPropertyToTerraform(struct?: TfMediaInsightsPipelineConfiguration.AmazonTranscribeCallAnalyticsProcessorConfigurationPropertyOutputReference | TfMediaInsightsPipelineConfiguration.AmazonTranscribeCallAnalyticsProcessorConfigurationProperty): any;
export declare function tfMediaInsightsPipelineConfigurationAmazonTranscribeCallAnalyticsProcessorConfigurationPropertyToHclTerraform(struct?: TfMediaInsightsPipelineConfiguration.AmazonTranscribeCallAnalyticsProcessorConfigurationPropertyOutputReference | TfMediaInsightsPipelineConfiguration.AmazonTranscribeCallAnalyticsProcessorConfigurationProperty): any;
export declare function tfMediaInsightsPipelineConfigurationAmazonTranscribeProcessorConfigurationPropertyToTerraform(struct?: TfMediaInsightsPipelineConfiguration.AmazonTranscribeProcessorConfigurationPropertyOutputReference | TfMediaInsightsPipelineConfiguration.AmazonTranscribeProcessorConfigurationProperty): any;
export declare function tfMediaInsightsPipelineConfigurationAmazonTranscribeProcessorConfigurationPropertyToHclTerraform(struct?: TfMediaInsightsPipelineConfiguration.AmazonTranscribeProcessorConfigurationPropertyOutputReference | TfMediaInsightsPipelineConfiguration.AmazonTranscribeProcessorConfigurationProperty): any;
export declare function tfMediaInsightsPipelineConfigurationKinesisDataStreamSinkConfigurationPropertyToTerraform(struct?: TfMediaInsightsPipelineConfiguration.KinesisDataStreamSinkConfigurationPropertyOutputReference | TfMediaInsightsPipelineConfiguration.KinesisDataStreamSinkConfigurationProperty): any;
export declare function tfMediaInsightsPipelineConfigurationKinesisDataStreamSinkConfigurationPropertyToHclTerraform(struct?: TfMediaInsightsPipelineConfiguration.KinesisDataStreamSinkConfigurationPropertyOutputReference | TfMediaInsightsPipelineConfiguration.KinesisDataStreamSinkConfigurationProperty): any;
export declare function tfMediaInsightsPipelineConfigurationLambdaFunctionSinkConfigurationPropertyToTerraform(struct?: TfMediaInsightsPipelineConfiguration.LambdaFunctionSinkConfigurationPropertyOutputReference | TfMediaInsightsPipelineConfiguration.LambdaFunctionSinkConfigurationProperty): any;
export declare function tfMediaInsightsPipelineConfigurationLambdaFunctionSinkConfigurationPropertyToHclTerraform(struct?: TfMediaInsightsPipelineConfiguration.LambdaFunctionSinkConfigurationPropertyOutputReference | TfMediaInsightsPipelineConfiguration.LambdaFunctionSinkConfigurationProperty): any;
export declare function tfMediaInsightsPipelineConfigurationS3RecordingSinkConfigurationPropertyToTerraform(struct?: TfMediaInsightsPipelineConfiguration.S3RecordingSinkConfigurationPropertyOutputReference | TfMediaInsightsPipelineConfiguration.S3RecordingSinkConfigurationProperty): any;
export declare function tfMediaInsightsPipelineConfigurationS3RecordingSinkConfigurationPropertyToHclTerraform(struct?: TfMediaInsightsPipelineConfiguration.S3RecordingSinkConfigurationPropertyOutputReference | TfMediaInsightsPipelineConfiguration.S3RecordingSinkConfigurationProperty): any;
export declare function tfMediaInsightsPipelineConfigurationSnsTopicSinkConfigurationPropertyToTerraform(struct?: TfMediaInsightsPipelineConfiguration.SnsTopicSinkConfigurationPropertyOutputReference | TfMediaInsightsPipelineConfiguration.SnsTopicSinkConfigurationProperty): any;
export declare function tfMediaInsightsPipelineConfigurationSnsTopicSinkConfigurationPropertyToHclTerraform(struct?: TfMediaInsightsPipelineConfiguration.SnsTopicSinkConfigurationPropertyOutputReference | TfMediaInsightsPipelineConfiguration.SnsTopicSinkConfigurationProperty): any;
export declare function tfMediaInsightsPipelineConfigurationSqsQueueSinkConfigurationPropertyToTerraform(struct?: TfMediaInsightsPipelineConfiguration.SqsQueueSinkConfigurationPropertyOutputReference | TfMediaInsightsPipelineConfiguration.SqsQueueSinkConfigurationProperty): any;
export declare function tfMediaInsightsPipelineConfigurationSqsQueueSinkConfigurationPropertyToHclTerraform(struct?: TfMediaInsightsPipelineConfiguration.SqsQueueSinkConfigurationPropertyOutputReference | TfMediaInsightsPipelineConfiguration.SqsQueueSinkConfigurationProperty): any;
export declare function tfMediaInsightsPipelineConfigurationVoiceAnalyticsProcessorConfigurationPropertyToTerraform(struct?: TfMediaInsightsPipelineConfiguration.VoiceAnalyticsProcessorConfigurationPropertyOutputReference | TfMediaInsightsPipelineConfiguration.VoiceAnalyticsProcessorConfigurationProperty): any;
export declare function tfMediaInsightsPipelineConfigurationVoiceAnalyticsProcessorConfigurationPropertyToHclTerraform(struct?: TfMediaInsightsPipelineConfiguration.VoiceAnalyticsProcessorConfigurationPropertyOutputReference | TfMediaInsightsPipelineConfiguration.VoiceAnalyticsProcessorConfigurationProperty): any;
export declare function tfMediaInsightsPipelineConfigurationElementsPropertyToTerraform(struct?: TfMediaInsightsPipelineConfiguration.ElementsProperty | cdktn.IResolvable): any;
export declare function tfMediaInsightsPipelineConfigurationElementsPropertyToHclTerraform(struct?: TfMediaInsightsPipelineConfiguration.ElementsProperty | cdktn.IResolvable): any;
export declare function tfMediaInsightsPipelineConfigurationIssueDetectionConfigurationPropertyToTerraform(struct?: TfMediaInsightsPipelineConfiguration.IssueDetectionConfigurationPropertyOutputReference | TfMediaInsightsPipelineConfiguration.IssueDetectionConfigurationProperty): any;
export declare function tfMediaInsightsPipelineConfigurationIssueDetectionConfigurationPropertyToHclTerraform(struct?: TfMediaInsightsPipelineConfiguration.IssueDetectionConfigurationPropertyOutputReference | TfMediaInsightsPipelineConfiguration.IssueDetectionConfigurationProperty): any;
export declare function tfMediaInsightsPipelineConfigurationKeywordMatchConfigurationPropertyToTerraform(struct?: TfMediaInsightsPipelineConfiguration.KeywordMatchConfigurationPropertyOutputReference | TfMediaInsightsPipelineConfiguration.KeywordMatchConfigurationProperty): any;
export declare function tfMediaInsightsPipelineConfigurationKeywordMatchConfigurationPropertyToHclTerraform(struct?: TfMediaInsightsPipelineConfiguration.KeywordMatchConfigurationPropertyOutputReference | TfMediaInsightsPipelineConfiguration.KeywordMatchConfigurationProperty): any;
export declare function tfMediaInsightsPipelineConfigurationSentimentConfigurationPropertyToTerraform(struct?: TfMediaInsightsPipelineConfiguration.SentimentConfigurationPropertyOutputReference | TfMediaInsightsPipelineConfiguration.SentimentConfigurationProperty): any;
export declare function tfMediaInsightsPipelineConfigurationSentimentConfigurationPropertyToHclTerraform(struct?: TfMediaInsightsPipelineConfiguration.SentimentConfigurationPropertyOutputReference | TfMediaInsightsPipelineConfiguration.SentimentConfigurationProperty): any;
export declare function tfMediaInsightsPipelineConfigurationRulesPropertyToTerraform(struct?: TfMediaInsightsPipelineConfiguration.RulesProperty | cdktn.IResolvable): any;
export declare function tfMediaInsightsPipelineConfigurationRulesPropertyToHclTerraform(struct?: TfMediaInsightsPipelineConfiguration.RulesProperty | cdktn.IResolvable): any;
export declare function tfMediaInsightsPipelineConfigurationRealTimeAlertConfigurationPropertyToTerraform(struct?: TfMediaInsightsPipelineConfiguration.RealTimeAlertConfigurationPropertyOutputReference | TfMediaInsightsPipelineConfiguration.RealTimeAlertConfigurationProperty): any;
export declare function tfMediaInsightsPipelineConfigurationRealTimeAlertConfigurationPropertyToHclTerraform(struct?: TfMediaInsightsPipelineConfiguration.RealTimeAlertConfigurationPropertyOutputReference | TfMediaInsightsPipelineConfiguration.RealTimeAlertConfigurationProperty): any;
export declare function tfMediaInsightsPipelineConfigurationTimeoutsPropertyToTerraform(struct?: TfMediaInsightsPipelineConfiguration.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfMediaInsightsPipelineConfigurationTimeoutsPropertyToHclTerraform(struct?: TfMediaInsightsPipelineConfiguration.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfMediaInsightsPipelineConfiguration {
    interface PostCallAnalyticsSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#content_redaction_output TfMediaInsightsPipelineConfiguration#content_redaction_output}
        */
        readonly contentRedactionOutput?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#data_access_role_arn TfMediaInsightsPipelineConfiguration#data_access_role_arn}
        */
        readonly dataAccessRoleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#output_encryption_kms_key_id TfMediaInsightsPipelineConfiguration#output_encryption_kms_key_id}
        */
        readonly outputEncryptionKmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#output_location TfMediaInsightsPipelineConfiguration#output_location}
        */
        readonly outputLocation: string;
    }
    class PostCallAnalyticsSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PostCallAnalyticsSettingsProperty | undefined;
        set internalValue(value: PostCallAnalyticsSettingsProperty | undefined);
        private _contentRedactionOutput?;
        get contentRedactionOutput(): string;
        set contentRedactionOutput(value: string);
        resetContentRedactionOutput(): void;
        get contentRedactionOutputInput(): string | undefined;
        private _dataAccessRoleArn?;
        get dataAccessRoleArn(): string;
        set dataAccessRoleArn(value: string);
        get dataAccessRoleArnInput(): string | undefined;
        private _outputEncryptionKmsKeyId?;
        get outputEncryptionKmsKeyId(): string;
        set outputEncryptionKmsKeyId(value: string);
        resetOutputEncryptionKmsKeyId(): void;
        get outputEncryptionKmsKeyIdInput(): string | undefined;
        private _outputLocation?;
        get outputLocation(): string;
        set outputLocation(value: string);
        get outputLocationInput(): string | undefined;
    }
    interface AmazonTranscribeCallAnalyticsProcessorConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#call_analytics_stream_categories TfMediaInsightsPipelineConfiguration#call_analytics_stream_categories}
        */
        readonly callAnalyticsStreamCategories?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#content_identification_type TfMediaInsightsPipelineConfiguration#content_identification_type}
        */
        readonly contentIdentificationType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#content_redaction_type TfMediaInsightsPipelineConfiguration#content_redaction_type}
        */
        readonly contentRedactionType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#enable_partial_results_stabilization TfMediaInsightsPipelineConfiguration#enable_partial_results_stabilization}
        */
        readonly enablePartialResultsStabilization?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#filter_partial_results TfMediaInsightsPipelineConfiguration#filter_partial_results}
        */
        readonly filterPartialResults?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#language_code TfMediaInsightsPipelineConfiguration#language_code}
        */
        readonly languageCode: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#language_model_name TfMediaInsightsPipelineConfiguration#language_model_name}
        */
        readonly languageModelName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#partial_results_stability TfMediaInsightsPipelineConfiguration#partial_results_stability}
        */
        readonly partialResultsStability?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#pii_entity_types TfMediaInsightsPipelineConfiguration#pii_entity_types}
        */
        readonly piiEntityTypes?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#vocabulary_filter_method TfMediaInsightsPipelineConfiguration#vocabulary_filter_method}
        */
        readonly vocabularyFilterMethod?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#vocabulary_filter_name TfMediaInsightsPipelineConfiguration#vocabulary_filter_name}
        */
        readonly vocabularyFilterName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#vocabulary_name TfMediaInsightsPipelineConfiguration#vocabulary_name}
        */
        readonly vocabularyName?: string;
        /**
        * post_call_analytics_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#post_call_analytics_settings TfMediaInsightsPipelineConfiguration#post_call_analytics_settings}
        */
        readonly postCallAnalyticsSettings?: PostCallAnalyticsSettingsProperty;
    }
    class AmazonTranscribeCallAnalyticsProcessorConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AmazonTranscribeCallAnalyticsProcessorConfigurationProperty | undefined;
        set internalValue(value: AmazonTranscribeCallAnalyticsProcessorConfigurationProperty | undefined);
        private _callAnalyticsStreamCategories?;
        get callAnalyticsStreamCategories(): string[];
        set callAnalyticsStreamCategories(value: string[]);
        resetCallAnalyticsStreamCategories(): void;
        get callAnalyticsStreamCategoriesInput(): string[] | undefined;
        private _contentIdentificationType?;
        get contentIdentificationType(): string;
        set contentIdentificationType(value: string);
        resetContentIdentificationType(): void;
        get contentIdentificationTypeInput(): string | undefined;
        private _contentRedactionType?;
        get contentRedactionType(): string;
        set contentRedactionType(value: string);
        resetContentRedactionType(): void;
        get contentRedactionTypeInput(): string | undefined;
        private _enablePartialResultsStabilization?;
        get enablePartialResultsStabilization(): boolean | cdktn.IResolvable;
        set enablePartialResultsStabilization(value: boolean | cdktn.IResolvable);
        resetEnablePartialResultsStabilization(): void;
        get enablePartialResultsStabilizationInput(): boolean | cdktn.IResolvable | undefined;
        private _filterPartialResults?;
        get filterPartialResults(): boolean | cdktn.IResolvable;
        set filterPartialResults(value: boolean | cdktn.IResolvable);
        resetFilterPartialResults(): void;
        get filterPartialResultsInput(): boolean | cdktn.IResolvable | undefined;
        private _languageCode?;
        get languageCode(): string;
        set languageCode(value: string);
        get languageCodeInput(): string | undefined;
        private _languageModelName?;
        get languageModelName(): string;
        set languageModelName(value: string);
        resetLanguageModelName(): void;
        get languageModelNameInput(): string | undefined;
        private _partialResultsStability?;
        get partialResultsStability(): string;
        set partialResultsStability(value: string);
        resetPartialResultsStability(): void;
        get partialResultsStabilityInput(): string | undefined;
        private _piiEntityTypes?;
        get piiEntityTypes(): string;
        set piiEntityTypes(value: string);
        resetPiiEntityTypes(): void;
        get piiEntityTypesInput(): string | undefined;
        private _vocabularyFilterMethod?;
        get vocabularyFilterMethod(): string;
        set vocabularyFilterMethod(value: string);
        resetVocabularyFilterMethod(): void;
        get vocabularyFilterMethodInput(): string | undefined;
        private _vocabularyFilterName?;
        get vocabularyFilterName(): string;
        set vocabularyFilterName(value: string);
        resetVocabularyFilterName(): void;
        get vocabularyFilterNameInput(): string | undefined;
        private _vocabularyName?;
        get vocabularyName(): string;
        set vocabularyName(value: string);
        resetVocabularyName(): void;
        get vocabularyNameInput(): string | undefined;
        private _postCallAnalyticsSettings;
        get postCallAnalyticsSettings(): PostCallAnalyticsSettingsPropertyOutputReference;
        putPostCallAnalyticsSettings(value: PostCallAnalyticsSettingsProperty): void;
        resetPostCallAnalyticsSettings(): void;
        get postCallAnalyticsSettingsInput(): PostCallAnalyticsSettingsProperty | undefined;
    }
    interface AmazonTranscribeProcessorConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#content_identification_type TfMediaInsightsPipelineConfiguration#content_identification_type}
        */
        readonly contentIdentificationType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#content_redaction_type TfMediaInsightsPipelineConfiguration#content_redaction_type}
        */
        readonly contentRedactionType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#enable_partial_results_stabilization TfMediaInsightsPipelineConfiguration#enable_partial_results_stabilization}
        */
        readonly enablePartialResultsStabilization?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#filter_partial_results TfMediaInsightsPipelineConfiguration#filter_partial_results}
        */
        readonly filterPartialResults?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#language_code TfMediaInsightsPipelineConfiguration#language_code}
        */
        readonly languageCode: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#language_model_name TfMediaInsightsPipelineConfiguration#language_model_name}
        */
        readonly languageModelName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#partial_results_stability TfMediaInsightsPipelineConfiguration#partial_results_stability}
        */
        readonly partialResultsStability?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#pii_entity_types TfMediaInsightsPipelineConfiguration#pii_entity_types}
        */
        readonly piiEntityTypes?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#show_speaker_label TfMediaInsightsPipelineConfiguration#show_speaker_label}
        */
        readonly showSpeakerLabel?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#vocabulary_filter_method TfMediaInsightsPipelineConfiguration#vocabulary_filter_method}
        */
        readonly vocabularyFilterMethod?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#vocabulary_filter_name TfMediaInsightsPipelineConfiguration#vocabulary_filter_name}
        */
        readonly vocabularyFilterName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#vocabulary_name TfMediaInsightsPipelineConfiguration#vocabulary_name}
        */
        readonly vocabularyName?: string;
    }
    class AmazonTranscribeProcessorConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AmazonTranscribeProcessorConfigurationProperty | undefined;
        set internalValue(value: AmazonTranscribeProcessorConfigurationProperty | undefined);
        private _contentIdentificationType?;
        get contentIdentificationType(): string;
        set contentIdentificationType(value: string);
        resetContentIdentificationType(): void;
        get contentIdentificationTypeInput(): string | undefined;
        private _contentRedactionType?;
        get contentRedactionType(): string;
        set contentRedactionType(value: string);
        resetContentRedactionType(): void;
        get contentRedactionTypeInput(): string | undefined;
        private _enablePartialResultsStabilization?;
        get enablePartialResultsStabilization(): boolean | cdktn.IResolvable;
        set enablePartialResultsStabilization(value: boolean | cdktn.IResolvable);
        resetEnablePartialResultsStabilization(): void;
        get enablePartialResultsStabilizationInput(): boolean | cdktn.IResolvable | undefined;
        private _filterPartialResults?;
        get filterPartialResults(): boolean | cdktn.IResolvable;
        set filterPartialResults(value: boolean | cdktn.IResolvable);
        resetFilterPartialResults(): void;
        get filterPartialResultsInput(): boolean | cdktn.IResolvable | undefined;
        private _languageCode?;
        get languageCode(): string;
        set languageCode(value: string);
        get languageCodeInput(): string | undefined;
        private _languageModelName?;
        get languageModelName(): string;
        set languageModelName(value: string);
        resetLanguageModelName(): void;
        get languageModelNameInput(): string | undefined;
        private _partialResultsStability?;
        get partialResultsStability(): string;
        set partialResultsStability(value: string);
        resetPartialResultsStability(): void;
        get partialResultsStabilityInput(): string | undefined;
        private _piiEntityTypes?;
        get piiEntityTypes(): string;
        set piiEntityTypes(value: string);
        resetPiiEntityTypes(): void;
        get piiEntityTypesInput(): string | undefined;
        private _showSpeakerLabel?;
        get showSpeakerLabel(): boolean | cdktn.IResolvable;
        set showSpeakerLabel(value: boolean | cdktn.IResolvable);
        resetShowSpeakerLabel(): void;
        get showSpeakerLabelInput(): boolean | cdktn.IResolvable | undefined;
        private _vocabularyFilterMethod?;
        get vocabularyFilterMethod(): string;
        set vocabularyFilterMethod(value: string);
        resetVocabularyFilterMethod(): void;
        get vocabularyFilterMethodInput(): string | undefined;
        private _vocabularyFilterName?;
        get vocabularyFilterName(): string;
        set vocabularyFilterName(value: string);
        resetVocabularyFilterName(): void;
        get vocabularyFilterNameInput(): string | undefined;
        private _vocabularyName?;
        get vocabularyName(): string;
        set vocabularyName(value: string);
        resetVocabularyName(): void;
        get vocabularyNameInput(): string | undefined;
    }
    interface KinesisDataStreamSinkConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#insights_target TfMediaInsightsPipelineConfiguration#insights_target}
        */
        readonly insightsTarget: string;
    }
    class KinesisDataStreamSinkConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KinesisDataStreamSinkConfigurationProperty | undefined;
        set internalValue(value: KinesisDataStreamSinkConfigurationProperty | undefined);
        private _insightsTarget?;
        get insightsTarget(): string;
        set insightsTarget(value: string);
        get insightsTargetInput(): string | undefined;
    }
    interface LambdaFunctionSinkConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#insights_target TfMediaInsightsPipelineConfiguration#insights_target}
        */
        readonly insightsTarget: string;
    }
    class LambdaFunctionSinkConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LambdaFunctionSinkConfigurationProperty | undefined;
        set internalValue(value: LambdaFunctionSinkConfigurationProperty | undefined);
        private _insightsTarget?;
        get insightsTarget(): string;
        set insightsTarget(value: string);
        get insightsTargetInput(): string | undefined;
    }
    interface S3RecordingSinkConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#destination TfMediaInsightsPipelineConfiguration#destination}
        */
        readonly destination?: string;
    }
    class S3RecordingSinkConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3RecordingSinkConfigurationProperty | undefined;
        set internalValue(value: S3RecordingSinkConfigurationProperty | undefined);
        private _destination?;
        get destination(): string;
        set destination(value: string);
        resetDestination(): void;
        get destinationInput(): string | undefined;
    }
    interface SnsTopicSinkConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#insights_target TfMediaInsightsPipelineConfiguration#insights_target}
        */
        readonly insightsTarget: string;
    }
    class SnsTopicSinkConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SnsTopicSinkConfigurationProperty | undefined;
        set internalValue(value: SnsTopicSinkConfigurationProperty | undefined);
        private _insightsTarget?;
        get insightsTarget(): string;
        set insightsTarget(value: string);
        get insightsTargetInput(): string | undefined;
    }
    interface SqsQueueSinkConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#insights_target TfMediaInsightsPipelineConfiguration#insights_target}
        */
        readonly insightsTarget: string;
    }
    class SqsQueueSinkConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SqsQueueSinkConfigurationProperty | undefined;
        set internalValue(value: SqsQueueSinkConfigurationProperty | undefined);
        private _insightsTarget?;
        get insightsTarget(): string;
        set insightsTarget(value: string);
        get insightsTargetInput(): string | undefined;
    }
    interface VoiceAnalyticsProcessorConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#speaker_search_status TfMediaInsightsPipelineConfiguration#speaker_search_status}
        */
        readonly speakerSearchStatus: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#voice_tone_analysis_status TfMediaInsightsPipelineConfiguration#voice_tone_analysis_status}
        */
        readonly voiceToneAnalysisStatus: string;
    }
    class VoiceAnalyticsProcessorConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VoiceAnalyticsProcessorConfigurationProperty | undefined;
        set internalValue(value: VoiceAnalyticsProcessorConfigurationProperty | undefined);
        private _speakerSearchStatus?;
        get speakerSearchStatus(): string;
        set speakerSearchStatus(value: string);
        get speakerSearchStatusInput(): string | undefined;
        private _voiceToneAnalysisStatus?;
        get voiceToneAnalysisStatus(): string;
        set voiceToneAnalysisStatus(value: string);
        get voiceToneAnalysisStatusInput(): string | undefined;
    }
    interface ElementsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#type TfMediaInsightsPipelineConfiguration#type}
        */
        readonly type: string;
        /**
        * amazon_transcribe_call_analytics_processor_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#amazon_transcribe_call_analytics_processor_configuration TfMediaInsightsPipelineConfiguration#amazon_transcribe_call_analytics_processor_configuration}
        */
        readonly amazonTranscribeCallAnalyticsProcessorConfiguration?: AmazonTranscribeCallAnalyticsProcessorConfigurationProperty;
        /**
        * amazon_transcribe_processor_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#amazon_transcribe_processor_configuration TfMediaInsightsPipelineConfiguration#amazon_transcribe_processor_configuration}
        */
        readonly amazonTranscribeProcessorConfiguration?: AmazonTranscribeProcessorConfigurationProperty;
        /**
        * kinesis_data_stream_sink_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#kinesis_data_stream_sink_configuration TfMediaInsightsPipelineConfiguration#kinesis_data_stream_sink_configuration}
        */
        readonly kinesisDataStreamSinkConfiguration?: KinesisDataStreamSinkConfigurationProperty;
        /**
        * lambda_function_sink_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#lambda_function_sink_configuration TfMediaInsightsPipelineConfiguration#lambda_function_sink_configuration}
        */
        readonly lambdaFunctionSinkConfiguration?: LambdaFunctionSinkConfigurationProperty;
        /**
        * s3_recording_sink_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#s3_recording_sink_configuration TfMediaInsightsPipelineConfiguration#s3_recording_sink_configuration}
        */
        readonly s3RecordingSinkConfiguration?: S3RecordingSinkConfigurationProperty;
        /**
        * sns_topic_sink_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#sns_topic_sink_configuration TfMediaInsightsPipelineConfiguration#sns_topic_sink_configuration}
        */
        readonly snsTopicSinkConfiguration?: SnsTopicSinkConfigurationProperty;
        /**
        * sqs_queue_sink_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#sqs_queue_sink_configuration TfMediaInsightsPipelineConfiguration#sqs_queue_sink_configuration}
        */
        readonly sqsQueueSinkConfiguration?: SqsQueueSinkConfigurationProperty;
        /**
        * voice_analytics_processor_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#voice_analytics_processor_configuration TfMediaInsightsPipelineConfiguration#voice_analytics_processor_configuration}
        */
        readonly voiceAnalyticsProcessorConfiguration?: VoiceAnalyticsProcessorConfigurationProperty;
    }
    class ElementsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ElementsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ElementsProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _amazonTranscribeCallAnalyticsProcessorConfiguration;
        get amazonTranscribeCallAnalyticsProcessorConfiguration(): AmazonTranscribeCallAnalyticsProcessorConfigurationPropertyOutputReference;
        putAmazonTranscribeCallAnalyticsProcessorConfiguration(value: AmazonTranscribeCallAnalyticsProcessorConfigurationProperty): void;
        resetAmazonTranscribeCallAnalyticsProcessorConfiguration(): void;
        get amazonTranscribeCallAnalyticsProcessorConfigurationInput(): AmazonTranscribeCallAnalyticsProcessorConfigurationProperty | undefined;
        private _amazonTranscribeProcessorConfiguration;
        get amazonTranscribeProcessorConfiguration(): AmazonTranscribeProcessorConfigurationPropertyOutputReference;
        putAmazonTranscribeProcessorConfiguration(value: AmazonTranscribeProcessorConfigurationProperty): void;
        resetAmazonTranscribeProcessorConfiguration(): void;
        get amazonTranscribeProcessorConfigurationInput(): AmazonTranscribeProcessorConfigurationProperty | undefined;
        private _kinesisDataStreamSinkConfiguration;
        get kinesisDataStreamSinkConfiguration(): KinesisDataStreamSinkConfigurationPropertyOutputReference;
        putKinesisDataStreamSinkConfiguration(value: KinesisDataStreamSinkConfigurationProperty): void;
        resetKinesisDataStreamSinkConfiguration(): void;
        get kinesisDataStreamSinkConfigurationInput(): KinesisDataStreamSinkConfigurationProperty | undefined;
        private _lambdaFunctionSinkConfiguration;
        get lambdaFunctionSinkConfiguration(): LambdaFunctionSinkConfigurationPropertyOutputReference;
        putLambdaFunctionSinkConfiguration(value: LambdaFunctionSinkConfigurationProperty): void;
        resetLambdaFunctionSinkConfiguration(): void;
        get lambdaFunctionSinkConfigurationInput(): LambdaFunctionSinkConfigurationProperty | undefined;
        private _s3RecordingSinkConfiguration;
        get s3RecordingSinkConfiguration(): S3RecordingSinkConfigurationPropertyOutputReference;
        putS3RecordingSinkConfiguration(value: S3RecordingSinkConfigurationProperty): void;
        resetS3RecordingSinkConfiguration(): void;
        get s3RecordingSinkConfigurationInput(): S3RecordingSinkConfigurationProperty | undefined;
        private _snsTopicSinkConfiguration;
        get snsTopicSinkConfiguration(): SnsTopicSinkConfigurationPropertyOutputReference;
        putSnsTopicSinkConfiguration(value: SnsTopicSinkConfigurationProperty): void;
        resetSnsTopicSinkConfiguration(): void;
        get snsTopicSinkConfigurationInput(): SnsTopicSinkConfigurationProperty | undefined;
        private _sqsQueueSinkConfiguration;
        get sqsQueueSinkConfiguration(): SqsQueueSinkConfigurationPropertyOutputReference;
        putSqsQueueSinkConfiguration(value: SqsQueueSinkConfigurationProperty): void;
        resetSqsQueueSinkConfiguration(): void;
        get sqsQueueSinkConfigurationInput(): SqsQueueSinkConfigurationProperty | undefined;
        private _voiceAnalyticsProcessorConfiguration;
        get voiceAnalyticsProcessorConfiguration(): VoiceAnalyticsProcessorConfigurationPropertyOutputReference;
        putVoiceAnalyticsProcessorConfiguration(value: VoiceAnalyticsProcessorConfigurationProperty): void;
        resetVoiceAnalyticsProcessorConfiguration(): void;
        get voiceAnalyticsProcessorConfigurationInput(): VoiceAnalyticsProcessorConfigurationProperty | undefined;
    }
    class ElementsPropertyList extends cdktn.ComplexList {
        internalValue?: ElementsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ElementsPropertyOutputReference;
    }
    interface IssueDetectionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#rule_name TfMediaInsightsPipelineConfiguration#rule_name}
        */
        readonly ruleName: string;
    }
    class IssueDetectionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IssueDetectionConfigurationProperty | undefined;
        set internalValue(value: IssueDetectionConfigurationProperty | undefined);
        private _ruleName?;
        get ruleName(): string;
        set ruleName(value: string);
        get ruleNameInput(): string | undefined;
    }
    interface KeywordMatchConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#keywords TfMediaInsightsPipelineConfiguration#keywords}
        */
        readonly keywords: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#negate TfMediaInsightsPipelineConfiguration#negate}
        */
        readonly negate?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#rule_name TfMediaInsightsPipelineConfiguration#rule_name}
        */
        readonly ruleName: string;
    }
    class KeywordMatchConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KeywordMatchConfigurationProperty | undefined;
        set internalValue(value: KeywordMatchConfigurationProperty | undefined);
        private _keywords?;
        get keywords(): string[];
        set keywords(value: string[]);
        get keywordsInput(): string[] | undefined;
        private _negate?;
        get negate(): boolean | cdktn.IResolvable;
        set negate(value: boolean | cdktn.IResolvable);
        resetNegate(): void;
        get negateInput(): boolean | cdktn.IResolvable | undefined;
        private _ruleName?;
        get ruleName(): string;
        set ruleName(value: string);
        get ruleNameInput(): string | undefined;
    }
    interface SentimentConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#rule_name TfMediaInsightsPipelineConfiguration#rule_name}
        */
        readonly ruleName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#sentiment_type TfMediaInsightsPipelineConfiguration#sentiment_type}
        */
        readonly sentimentType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#time_period TfMediaInsightsPipelineConfiguration#time_period}
        */
        readonly timePeriod: number;
    }
    class SentimentConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SentimentConfigurationProperty | undefined;
        set internalValue(value: SentimentConfigurationProperty | undefined);
        private _ruleName?;
        get ruleName(): string;
        set ruleName(value: string);
        get ruleNameInput(): string | undefined;
        private _sentimentType?;
        get sentimentType(): string;
        set sentimentType(value: string);
        get sentimentTypeInput(): string | undefined;
        private _timePeriod?;
        get timePeriod(): number;
        set timePeriod(value: number);
        get timePeriodInput(): number | undefined;
    }
    interface RulesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#type TfMediaInsightsPipelineConfiguration#type}
        */
        readonly type: string;
        /**
        * issue_detection_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#issue_detection_configuration TfMediaInsightsPipelineConfiguration#issue_detection_configuration}
        */
        readonly issueDetectionConfiguration?: IssueDetectionConfigurationProperty;
        /**
        * keyword_match_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#keyword_match_configuration TfMediaInsightsPipelineConfiguration#keyword_match_configuration}
        */
        readonly keywordMatchConfiguration?: KeywordMatchConfigurationProperty;
        /**
        * sentiment_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#sentiment_configuration TfMediaInsightsPipelineConfiguration#sentiment_configuration}
        */
        readonly sentimentConfiguration?: SentimentConfigurationProperty;
    }
    class RulesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RulesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RulesProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _issueDetectionConfiguration;
        get issueDetectionConfiguration(): IssueDetectionConfigurationPropertyOutputReference;
        putIssueDetectionConfiguration(value: IssueDetectionConfigurationProperty): void;
        resetIssueDetectionConfiguration(): void;
        get issueDetectionConfigurationInput(): IssueDetectionConfigurationProperty | undefined;
        private _keywordMatchConfiguration;
        get keywordMatchConfiguration(): KeywordMatchConfigurationPropertyOutputReference;
        putKeywordMatchConfiguration(value: KeywordMatchConfigurationProperty): void;
        resetKeywordMatchConfiguration(): void;
        get keywordMatchConfigurationInput(): KeywordMatchConfigurationProperty | undefined;
        private _sentimentConfiguration;
        get sentimentConfiguration(): SentimentConfigurationPropertyOutputReference;
        putSentimentConfiguration(value: SentimentConfigurationProperty): void;
        resetSentimentConfiguration(): void;
        get sentimentConfigurationInput(): SentimentConfigurationProperty | undefined;
    }
    class RulesPropertyList extends cdktn.ComplexList {
        internalValue?: RulesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RulesPropertyOutputReference;
    }
    interface RealTimeAlertConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#disabled TfMediaInsightsPipelineConfiguration#disabled}
        */
        readonly disabled?: boolean | cdktn.IResolvable;
        /**
        * rules block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#rules TfMediaInsightsPipelineConfiguration#rules}
        */
        readonly rules: RulesProperty[] | cdktn.IResolvable;
    }
    class RealTimeAlertConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RealTimeAlertConfigurationProperty | undefined;
        set internalValue(value: RealTimeAlertConfigurationProperty | undefined);
        private _disabled?;
        get disabled(): boolean | cdktn.IResolvable;
        set disabled(value: boolean | cdktn.IResolvable);
        resetDisabled(): void;
        get disabledInput(): boolean | cdktn.IResolvable | undefined;
        private _rules;
        get rules(): RulesPropertyList;
        putRules(value: RulesProperty[] | cdktn.IResolvable): void;
        get rulesInput(): cdktn.IResolvable | RulesProperty[] | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#create TfMediaInsightsPipelineConfiguration#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#delete TfMediaInsightsPipelineConfiguration#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chimesdkmediapipelines_media_insights_pipeline_configuration#update TfMediaInsightsPipelineConfiguration#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
