import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsVoiceConnectorLoggingConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_logging#enable_media_metric_logs AwsVoiceConnectorLogging#enable_media_metric_logs}
    */
    readonly enableMediaMetricLogs?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_logging#enable_sip_logs AwsVoiceConnectorLogging#enable_sip_logs}
    */
    readonly enableSipLogs?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_logging#id AwsVoiceConnectorLogging#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_logging#region AwsVoiceConnectorLogging#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_logging#voice_connector_id AwsVoiceConnectorLogging#voice_connector_id}
    */
    readonly voiceConnectorId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_logging aws_chime_voice_connector_logging}
*/
export declare class AwsVoiceConnectorLogging extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_chime_voice_connector_logging";
    /**
    * Generates CDKTN code for importing a AwsVoiceConnectorLogging resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsVoiceConnectorLogging to import
    * @param importFromId The id of the existing AwsVoiceConnectorLogging that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_logging#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsVoiceConnectorLogging to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_logging aws_chime_voice_connector_logging} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsVoiceConnectorLoggingConfig
    */
    constructor(scope: Construct, id: string, config: AwsVoiceConnectorLoggingConfig);
    private _enableMediaMetricLogs?;
    get enableMediaMetricLogs(): boolean | cdktn.IResolvable;
    set enableMediaMetricLogs(value: boolean | cdktn.IResolvable);
    resetEnableMediaMetricLogs(): void;
    get enableMediaMetricLogsInput(): boolean | cdktn.IResolvable | undefined;
    private _enableSipLogs?;
    get enableSipLogs(): boolean | cdktn.IResolvable;
    set enableSipLogs(value: boolean | cdktn.IResolvable);
    resetEnableSipLogs(): void;
    get enableSipLogsInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _voiceConnectorId?;
    get voiceConnectorId(): string;
    set voiceConnectorId(value: string);
    get voiceConnectorIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
