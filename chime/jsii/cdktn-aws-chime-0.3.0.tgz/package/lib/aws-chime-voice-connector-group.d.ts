import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsVoiceConnectorGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_group#id AwsVoiceConnectorGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_group#name AwsVoiceConnectorGroup#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_group#region AwsVoiceConnectorGroup#region}
    */
    readonly region?: string;
    /**
    * connector block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_group#connector AwsVoiceConnectorGroup#connector}
    */
    readonly connector?: AwsVoiceConnectorGroup.ConnectorProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_group aws_chime_voice_connector_group}
*/
export declare class AwsVoiceConnectorGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_chime_voice_connector_group";
    /**
    * Generates CDKTN code for importing a AwsVoiceConnectorGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsVoiceConnectorGroup to import
    * @param importFromId The id of the existing AwsVoiceConnectorGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsVoiceConnectorGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_group aws_chime_voice_connector_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsVoiceConnectorGroupConfig
    */
    constructor(scope: Construct, id: string, config: AwsVoiceConnectorGroupConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _connector;
    get connector(): AwsVoiceConnectorGroup.ConnectorPropertyList;
    putConnector(value: AwsVoiceConnectorGroup.ConnectorProperty[] | cdktn.IResolvable): void;
    resetConnector(): void;
    get connectorInput(): cdktn.IResolvable | AwsVoiceConnectorGroup.ConnectorProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsVoiceConnectorGroupConnectorPropertyToTerraform(struct?: AwsVoiceConnectorGroup.ConnectorProperty | cdktn.IResolvable): any;
export declare function awsVoiceConnectorGroupConnectorPropertyToHclTerraform(struct?: AwsVoiceConnectorGroup.ConnectorProperty | cdktn.IResolvable): any;
export declare namespace AwsVoiceConnectorGroup {
    interface ConnectorProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_group#priority AwsVoiceConnectorGroup#priority}
        */
        readonly priority: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_group#voice_connector_id AwsVoiceConnectorGroup#voice_connector_id}
        */
        readonly voiceConnectorId: string;
    }
    class ConnectorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConnectorProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConnectorProperty | cdktn.IResolvable | undefined);
        private _priority?;
        get priority(): number;
        set priority(value: number);
        get priorityInput(): number | undefined;
        private _voiceConnectorId?;
        get voiceConnectorId(): string;
        set voiceConnectorId(value: string);
        get voiceConnectorIdInput(): string | undefined;
    }
    class ConnectorPropertyList extends cdktn.ComplexList {
        internalValue?: ConnectorProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConnectorPropertyOutputReference;
    }
}
