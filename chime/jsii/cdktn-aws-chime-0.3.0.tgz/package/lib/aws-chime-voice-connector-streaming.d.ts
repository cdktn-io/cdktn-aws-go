import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsVoiceConnectorStreamingConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_streaming#data_retention AwsVoiceConnectorStreaming#data_retention}
    */
    readonly dataRetention: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_streaming#disabled AwsVoiceConnectorStreaming#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_streaming#id AwsVoiceConnectorStreaming#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_streaming#region AwsVoiceConnectorStreaming#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_streaming#streaming_notification_targets AwsVoiceConnectorStreaming#streaming_notification_targets}
    */
    readonly streamingNotificationTargets?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_streaming#voice_connector_id AwsVoiceConnectorStreaming#voice_connector_id}
    */
    readonly voiceConnectorId: string;
    /**
    * media_insights_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_streaming#media_insights_configuration AwsVoiceConnectorStreaming#media_insights_configuration}
    */
    readonly mediaInsightsConfiguration?: AwsVoiceConnectorStreaming.MediaInsightsConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_streaming aws_chime_voice_connector_streaming}
*/
export declare class AwsVoiceConnectorStreaming extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_chime_voice_connector_streaming";
    /**
    * Generates CDKTN code for importing a AwsVoiceConnectorStreaming resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsVoiceConnectorStreaming to import
    * @param importFromId The id of the existing AwsVoiceConnectorStreaming that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_streaming#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsVoiceConnectorStreaming to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_streaming aws_chime_voice_connector_streaming} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsVoiceConnectorStreamingConfig
    */
    constructor(scope: Construct, id: string, config: AwsVoiceConnectorStreamingConfig);
    private _dataRetention?;
    get dataRetention(): number;
    set dataRetention(value: number);
    get dataRetentionInput(): number | undefined;
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _streamingNotificationTargets?;
    get streamingNotificationTargets(): string[];
    set streamingNotificationTargets(value: string[]);
    resetStreamingNotificationTargets(): void;
    get streamingNotificationTargetsInput(): string[] | undefined;
    private _voiceConnectorId?;
    get voiceConnectorId(): string;
    set voiceConnectorId(value: string);
    get voiceConnectorIdInput(): string | undefined;
    private _mediaInsightsConfiguration;
    get mediaInsightsConfiguration(): AwsVoiceConnectorStreaming.MediaInsightsConfigurationPropertyOutputReference;
    putMediaInsightsConfiguration(value: AwsVoiceConnectorStreaming.MediaInsightsConfigurationProperty): void;
    resetMediaInsightsConfiguration(): void;
    get mediaInsightsConfigurationInput(): AwsVoiceConnectorStreaming.MediaInsightsConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsVoiceConnectorStreamingMediaInsightsConfigurationPropertyToTerraform(struct?: AwsVoiceConnectorStreaming.MediaInsightsConfigurationPropertyOutputReference | AwsVoiceConnectorStreaming.MediaInsightsConfigurationProperty): any;
export declare function awsVoiceConnectorStreamingMediaInsightsConfigurationPropertyToHclTerraform(struct?: AwsVoiceConnectorStreaming.MediaInsightsConfigurationPropertyOutputReference | AwsVoiceConnectorStreaming.MediaInsightsConfigurationProperty): any;
export declare namespace AwsVoiceConnectorStreaming {
    interface MediaInsightsConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_streaming#configuration_arn AwsVoiceConnectorStreaming#configuration_arn}
        */
        readonly configurationArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_streaming#disabled AwsVoiceConnectorStreaming#disabled}
        */
        readonly disabled?: boolean | cdktn.IResolvable;
    }
    class MediaInsightsConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MediaInsightsConfigurationProperty | undefined;
        set internalValue(value: MediaInsightsConfigurationProperty | undefined);
        private _configurationArn?;
        get configurationArn(): string;
        set configurationArn(value: string);
        resetConfigurationArn(): void;
        get configurationArnInput(): string | undefined;
        private _disabled?;
        get disabled(): boolean | cdktn.IResolvable;
        set disabled(value: boolean | cdktn.IResolvable);
        resetDisabled(): void;
        get disabledInput(): boolean | cdktn.IResolvable | undefined;
    }
}
