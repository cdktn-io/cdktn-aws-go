import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsVoiceConnectorTerminationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_termination#calling_regions AwsVoiceConnectorTermination#calling_regions}
    */
    readonly callingRegions: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_termination#cidr_allow_list AwsVoiceConnectorTermination#cidr_allow_list}
    */
    readonly cidrAllowList: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_termination#cps_limit AwsVoiceConnectorTermination#cps_limit}
    */
    readonly cpsLimit?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_termination#default_phone_number AwsVoiceConnectorTermination#default_phone_number}
    */
    readonly defaultPhoneNumber?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_termination#disabled AwsVoiceConnectorTermination#disabled}
    */
    readonly disabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_termination#id AwsVoiceConnectorTermination#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_termination#region AwsVoiceConnectorTermination#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_termination#voice_connector_id AwsVoiceConnectorTermination#voice_connector_id}
    */
    readonly voiceConnectorId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_termination aws_chime_voice_connector_termination}
*/
export declare class AwsVoiceConnectorTermination extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_chime_voice_connector_termination";
    /**
    * Generates CDKTN code for importing a AwsVoiceConnectorTermination resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsVoiceConnectorTermination to import
    * @param importFromId The id of the existing AwsVoiceConnectorTermination that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_termination#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsVoiceConnectorTermination to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/chime_voice_connector_termination aws_chime_voice_connector_termination} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsVoiceConnectorTerminationConfig
    */
    constructor(scope: Construct, id: string, config: AwsVoiceConnectorTerminationConfig);
    private _callingRegions?;
    get callingRegions(): string[];
    set callingRegions(value: string[]);
    get callingRegionsInput(): string[] | undefined;
    private _cidrAllowList?;
    get cidrAllowList(): string[];
    set cidrAllowList(value: string[]);
    get cidrAllowListInput(): string[] | undefined;
    private _cpsLimit?;
    get cpsLimit(): number;
    set cpsLimit(value: number);
    resetCpsLimit(): void;
    get cpsLimitInput(): number | undefined;
    private _defaultPhoneNumber?;
    get defaultPhoneNumber(): string;
    set defaultPhoneNumber(value: string);
    resetDefaultPhoneNumber(): void;
    get defaultPhoneNumberInput(): string | undefined;
    private _disabled?;
    get disabled(): boolean | cdktn.IResolvable;
    set disabled(value: boolean | cdktn.IResolvable);
    resetDisabled(): void;
    get disabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _voiceConnectorId?;
    get voiceConnectorId(): string;
    set voiceConnectorId(value: string);
    get voiceConnectorIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
