import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsCodedeployDeploymentConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_config#compute_platform AwsCodedeployDeploymentConfig#compute_platform}
    */
    readonly computePlatform?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_config#deployment_config_name AwsCodedeployDeploymentConfig#deployment_config_name}
    */
    readonly deploymentConfigName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_config#id AwsCodedeployDeploymentConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_config#region AwsCodedeployDeploymentConfig#region}
    */
    readonly region?: string;
    /**
    * minimum_healthy_hosts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_config#minimum_healthy_hosts AwsCodedeployDeploymentConfig#minimum_healthy_hosts}
    */
    readonly minimumHealthyHosts?: AwsCodedeployDeploymentConfig.MinimumHealthyHostsProperty;
    /**
    * traffic_routing_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_config#traffic_routing_config AwsCodedeployDeploymentConfig#traffic_routing_config}
    */
    readonly trafficRoutingConfig?: AwsCodedeployDeploymentConfig.TrafficRoutingConfigProperty;
    /**
    * zonal_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_config#zonal_config AwsCodedeployDeploymentConfig#zonal_config}
    */
    readonly zonalConfig?: AwsCodedeployDeploymentConfig.ZonalConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_config aws_codedeploy_deployment_config}
*/
export declare class AwsCodedeployDeploymentConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_codedeploy_deployment_config";
    /**
    * Generates CDKTN code for importing a AwsCodedeployDeploymentConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCodedeployDeploymentConfig to import
    * @param importFromId The id of the existing AwsCodedeployDeploymentConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCodedeployDeploymentConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_config aws_codedeploy_deployment_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsCodedeployDeploymentConfigConfig
    */
    constructor(scope: Construct, id: string, config: AwsCodedeployDeploymentConfigConfig);
    get arn(): string;
    private _computePlatform?;
    get computePlatform(): string;
    set computePlatform(value: string);
    resetComputePlatform(): void;
    get computePlatformInput(): string | undefined;
    get deploymentConfigId(): string;
    private _deploymentConfigName?;
    get deploymentConfigName(): string;
    set deploymentConfigName(value: string);
    get deploymentConfigNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _minimumHealthyHosts;
    get minimumHealthyHosts(): AwsCodedeployDeploymentConfig.MinimumHealthyHostsPropertyOutputReference;
    putMinimumHealthyHosts(value: AwsCodedeployDeploymentConfig.MinimumHealthyHostsProperty): void;
    resetMinimumHealthyHosts(): void;
    get minimumHealthyHostsInput(): AwsCodedeployDeploymentConfig.MinimumHealthyHostsProperty | undefined;
    private _trafficRoutingConfig;
    get trafficRoutingConfig(): AwsCodedeployDeploymentConfig.TrafficRoutingConfigPropertyOutputReference;
    putTrafficRoutingConfig(value: AwsCodedeployDeploymentConfig.TrafficRoutingConfigProperty): void;
    resetTrafficRoutingConfig(): void;
    get trafficRoutingConfigInput(): AwsCodedeployDeploymentConfig.TrafficRoutingConfigProperty | undefined;
    private _zonalConfig;
    get zonalConfig(): AwsCodedeployDeploymentConfig.ZonalConfigPropertyOutputReference;
    putZonalConfig(value: AwsCodedeployDeploymentConfig.ZonalConfigProperty): void;
    resetZonalConfig(): void;
    get zonalConfigInput(): AwsCodedeployDeploymentConfig.ZonalConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsCodedeployDeploymentConfigMinimumHealthyHostsPropertyToTerraform(struct?: AwsCodedeployDeploymentConfig.MinimumHealthyHostsPropertyOutputReference | AwsCodedeployDeploymentConfig.MinimumHealthyHostsProperty): any;
export declare function awsCodedeployDeploymentConfigMinimumHealthyHostsPropertyToHclTerraform(struct?: AwsCodedeployDeploymentConfig.MinimumHealthyHostsPropertyOutputReference | AwsCodedeployDeploymentConfig.MinimumHealthyHostsProperty): any;
export declare function awsCodedeployDeploymentConfigTimeBasedCanaryPropertyToTerraform(struct?: AwsCodedeployDeploymentConfig.TimeBasedCanaryPropertyOutputReference | AwsCodedeployDeploymentConfig.TimeBasedCanaryProperty): any;
export declare function awsCodedeployDeploymentConfigTimeBasedCanaryPropertyToHclTerraform(struct?: AwsCodedeployDeploymentConfig.TimeBasedCanaryPropertyOutputReference | AwsCodedeployDeploymentConfig.TimeBasedCanaryProperty): any;
export declare function awsCodedeployDeploymentConfigTimeBasedLinearPropertyToTerraform(struct?: AwsCodedeployDeploymentConfig.TimeBasedLinearPropertyOutputReference | AwsCodedeployDeploymentConfig.TimeBasedLinearProperty): any;
export declare function awsCodedeployDeploymentConfigTimeBasedLinearPropertyToHclTerraform(struct?: AwsCodedeployDeploymentConfig.TimeBasedLinearPropertyOutputReference | AwsCodedeployDeploymentConfig.TimeBasedLinearProperty): any;
export declare function awsCodedeployDeploymentConfigTrafficRoutingConfigPropertyToTerraform(struct?: AwsCodedeployDeploymentConfig.TrafficRoutingConfigPropertyOutputReference | AwsCodedeployDeploymentConfig.TrafficRoutingConfigProperty): any;
export declare function awsCodedeployDeploymentConfigTrafficRoutingConfigPropertyToHclTerraform(struct?: AwsCodedeployDeploymentConfig.TrafficRoutingConfigPropertyOutputReference | AwsCodedeployDeploymentConfig.TrafficRoutingConfigProperty): any;
export declare function awsCodedeployDeploymentConfigMinimumHealthyHostsPerZonePropertyToTerraform(struct?: AwsCodedeployDeploymentConfig.MinimumHealthyHostsPerZonePropertyOutputReference | AwsCodedeployDeploymentConfig.MinimumHealthyHostsPerZoneProperty): any;
export declare function awsCodedeployDeploymentConfigMinimumHealthyHostsPerZonePropertyToHclTerraform(struct?: AwsCodedeployDeploymentConfig.MinimumHealthyHostsPerZonePropertyOutputReference | AwsCodedeployDeploymentConfig.MinimumHealthyHostsPerZoneProperty): any;
export declare function awsCodedeployDeploymentConfigZonalConfigPropertyToTerraform(struct?: AwsCodedeployDeploymentConfig.ZonalConfigPropertyOutputReference | AwsCodedeployDeploymentConfig.ZonalConfigProperty): any;
export declare function awsCodedeployDeploymentConfigZonalConfigPropertyToHclTerraform(struct?: AwsCodedeployDeploymentConfig.ZonalConfigPropertyOutputReference | AwsCodedeployDeploymentConfig.ZonalConfigProperty): any;
export declare namespace AwsCodedeployDeploymentConfig {
    interface MinimumHealthyHostsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_config#type AwsCodedeployDeploymentConfig#type}
        */
        readonly type?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_config#value AwsCodedeployDeploymentConfig#value}
        */
        readonly value?: number;
    }
    class MinimumHealthyHostsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MinimumHealthyHostsProperty | undefined;
        set internalValue(value: MinimumHealthyHostsProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        resetValue(): void;
        get valueInput(): number | undefined;
    }
    interface TimeBasedCanaryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_config#interval AwsCodedeployDeploymentConfig#interval}
        */
        readonly interval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_config#percentage AwsCodedeployDeploymentConfig#percentage}
        */
        readonly percentage?: number;
    }
    class TimeBasedCanaryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeBasedCanaryProperty | undefined;
        set internalValue(value: TimeBasedCanaryProperty | undefined);
        private _interval?;
        get interval(): number;
        set interval(value: number);
        resetInterval(): void;
        get intervalInput(): number | undefined;
        private _percentage?;
        get percentage(): number;
        set percentage(value: number);
        resetPercentage(): void;
        get percentageInput(): number | undefined;
    }
    interface TimeBasedLinearProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_config#interval AwsCodedeployDeploymentConfig#interval}
        */
        readonly interval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_config#percentage AwsCodedeployDeploymentConfig#percentage}
        */
        readonly percentage?: number;
    }
    class TimeBasedLinearPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeBasedLinearProperty | undefined;
        set internalValue(value: TimeBasedLinearProperty | undefined);
        private _interval?;
        get interval(): number;
        set interval(value: number);
        resetInterval(): void;
        get intervalInput(): number | undefined;
        private _percentage?;
        get percentage(): number;
        set percentage(value: number);
        resetPercentage(): void;
        get percentageInput(): number | undefined;
    }
    interface TrafficRoutingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_config#type AwsCodedeployDeploymentConfig#type}
        */
        readonly type?: string;
        /**
        * time_based_canary block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_config#time_based_canary AwsCodedeployDeploymentConfig#time_based_canary}
        */
        readonly timeBasedCanary?: TimeBasedCanaryProperty;
        /**
        * time_based_linear block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_config#time_based_linear AwsCodedeployDeploymentConfig#time_based_linear}
        */
        readonly timeBasedLinear?: TimeBasedLinearProperty;
    }
    class TrafficRoutingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TrafficRoutingConfigProperty | undefined;
        set internalValue(value: TrafficRoutingConfigProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
        private _timeBasedCanary;
        get timeBasedCanary(): TimeBasedCanaryPropertyOutputReference;
        putTimeBasedCanary(value: TimeBasedCanaryProperty): void;
        resetTimeBasedCanary(): void;
        get timeBasedCanaryInput(): TimeBasedCanaryProperty | undefined;
        private _timeBasedLinear;
        get timeBasedLinear(): TimeBasedLinearPropertyOutputReference;
        putTimeBasedLinear(value: TimeBasedLinearProperty): void;
        resetTimeBasedLinear(): void;
        get timeBasedLinearInput(): TimeBasedLinearProperty | undefined;
    }
    interface MinimumHealthyHostsPerZoneProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_config#type AwsCodedeployDeploymentConfig#type}
        */
        readonly type?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_config#value AwsCodedeployDeploymentConfig#value}
        */
        readonly value?: number;
    }
    class MinimumHealthyHostsPerZonePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MinimumHealthyHostsPerZoneProperty | undefined;
        set internalValue(value: MinimumHealthyHostsPerZoneProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        resetValue(): void;
        get valueInput(): number | undefined;
    }
    interface ZonalConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_config#first_zone_monitor_duration_in_seconds AwsCodedeployDeploymentConfig#first_zone_monitor_duration_in_seconds}
        */
        readonly firstZoneMonitorDurationInSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_config#monitor_duration_in_seconds AwsCodedeployDeploymentConfig#monitor_duration_in_seconds}
        */
        readonly monitorDurationInSeconds?: number;
        /**
        * minimum_healthy_hosts_per_zone block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_config#minimum_healthy_hosts_per_zone AwsCodedeployDeploymentConfig#minimum_healthy_hosts_per_zone}
        */
        readonly minimumHealthyHostsPerZone?: MinimumHealthyHostsPerZoneProperty;
    }
    class ZonalConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ZonalConfigProperty | undefined;
        set internalValue(value: ZonalConfigProperty | undefined);
        private _firstZoneMonitorDurationInSeconds?;
        get firstZoneMonitorDurationInSeconds(): number;
        set firstZoneMonitorDurationInSeconds(value: number);
        resetFirstZoneMonitorDurationInSeconds(): void;
        get firstZoneMonitorDurationInSecondsInput(): number | undefined;
        private _monitorDurationInSeconds?;
        get monitorDurationInSeconds(): number;
        set monitorDurationInSeconds(value: number);
        resetMonitorDurationInSeconds(): void;
        get monitorDurationInSecondsInput(): number | undefined;
        private _minimumHealthyHostsPerZone;
        get minimumHealthyHostsPerZone(): MinimumHealthyHostsPerZonePropertyOutputReference;
        putMinimumHealthyHostsPerZone(value: MinimumHealthyHostsPerZoneProperty): void;
        resetMinimumHealthyHostsPerZone(): void;
        get minimumHealthyHostsPerZoneInput(): MinimumHealthyHostsPerZoneProperty | undefined;
    }
}
