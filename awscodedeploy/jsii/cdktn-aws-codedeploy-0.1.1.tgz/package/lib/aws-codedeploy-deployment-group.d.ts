import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsCodedeployDeploymentGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#app_name AwsCodedeployDeploymentGroup#app_name}
    */
    readonly appName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#autoscaling_groups AwsCodedeployDeploymentGroup#autoscaling_groups}
    */
    readonly autoscalingGroups?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#deployment_config_name AwsCodedeployDeploymentGroup#deployment_config_name}
    */
    readonly deploymentConfigName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#deployment_group_name AwsCodedeployDeploymentGroup#deployment_group_name}
    */
    readonly deploymentGroupName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#id AwsCodedeployDeploymentGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#outdated_instances_strategy AwsCodedeployDeploymentGroup#outdated_instances_strategy}
    */
    readonly outdatedInstancesStrategy?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#region AwsCodedeployDeploymentGroup#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#service_role_arn AwsCodedeployDeploymentGroup#service_role_arn}
    */
    readonly serviceRoleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#tags AwsCodedeployDeploymentGroup#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#tags_all AwsCodedeployDeploymentGroup#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#termination_hook_enabled AwsCodedeployDeploymentGroup#termination_hook_enabled}
    */
    readonly terminationHookEnabled?: boolean | cdktn.IResolvable;
    /**
    * alarm_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#alarm_configuration AwsCodedeployDeploymentGroup#alarm_configuration}
    */
    readonly alarmConfiguration?: AwsCodedeployDeploymentGroup.AlarmConfigurationProperty;
    /**
    * auto_rollback_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#auto_rollback_configuration AwsCodedeployDeploymentGroup#auto_rollback_configuration}
    */
    readonly autoRollbackConfiguration?: AwsCodedeployDeploymentGroup.AutoRollbackConfigurationProperty;
    /**
    * blue_green_deployment_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#blue_green_deployment_config AwsCodedeployDeploymentGroup#blue_green_deployment_config}
    */
    readonly blueGreenDeploymentConfig?: AwsCodedeployDeploymentGroup.BlueGreenDeploymentConfigProperty;
    /**
    * deployment_style block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#deployment_style AwsCodedeployDeploymentGroup#deployment_style}
    */
    readonly deploymentStyle?: AwsCodedeployDeploymentGroup.DeploymentStyleProperty;
    /**
    * ec2_tag_filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#ec2_tag_filter AwsCodedeployDeploymentGroup#ec2_tag_filter}
    */
    readonly ec2TagFilter?: AwsCodedeployDeploymentGroup.Ec2TagFilterProperty[] | cdktn.IResolvable;
    /**
    * ec2_tag_set block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#ec2_tag_set AwsCodedeployDeploymentGroup#ec2_tag_set}
    */
    readonly ec2TagSet?: AwsCodedeployDeploymentGroup.Ec2TagSetProperty[] | cdktn.IResolvable;
    /**
    * ecs_service block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#ecs_service AwsCodedeployDeploymentGroup#ecs_service}
    */
    readonly ecsService?: AwsCodedeployDeploymentGroup.EcsServiceProperty;
    /**
    * load_balancer_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#load_balancer_info AwsCodedeployDeploymentGroup#load_balancer_info}
    */
    readonly loadBalancerInfo?: AwsCodedeployDeploymentGroup.LoadBalancerInfoProperty;
    /**
    * on_premises_instance_tag_filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#on_premises_instance_tag_filter AwsCodedeployDeploymentGroup#on_premises_instance_tag_filter}
    */
    readonly onPremisesInstanceTagFilter?: AwsCodedeployDeploymentGroup.OnPremisesInstanceTagFilterProperty[] | cdktn.IResolvable;
    /**
    * trigger_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#trigger_configuration AwsCodedeployDeploymentGroup#trigger_configuration}
    */
    readonly triggerConfiguration?: AwsCodedeployDeploymentGroup.TriggerConfigurationProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group aws_codedeploy_deployment_group}
*/
export declare class AwsCodedeployDeploymentGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_codedeploy_deployment_group";
    /**
    * Generates CDKTN code for importing a AwsCodedeployDeploymentGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCodedeployDeploymentGroup to import
    * @param importFromId The id of the existing AwsCodedeployDeploymentGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCodedeployDeploymentGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group aws_codedeploy_deployment_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsCodedeployDeploymentGroupConfig
    */
    constructor(scope: Construct, id: string, config: AwsCodedeployDeploymentGroupConfig);
    private _appName?;
    get appName(): string;
    set appName(value: string);
    get appNameInput(): string | undefined;
    get arn(): string;
    private _autoscalingGroups?;
    get autoscalingGroups(): string[];
    set autoscalingGroups(value: string[]);
    resetAutoscalingGroups(): void;
    get autoscalingGroupsInput(): string[] | undefined;
    get computePlatform(): string;
    private _deploymentConfigName?;
    get deploymentConfigName(): string;
    set deploymentConfigName(value: string);
    resetDeploymentConfigName(): void;
    get deploymentConfigNameInput(): string | undefined;
    get deploymentGroupId(): string;
    private _deploymentGroupName?;
    get deploymentGroupName(): string;
    set deploymentGroupName(value: string);
    get deploymentGroupNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _outdatedInstancesStrategy?;
    get outdatedInstancesStrategy(): string;
    set outdatedInstancesStrategy(value: string);
    resetOutdatedInstancesStrategy(): void;
    get outdatedInstancesStrategyInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _serviceRoleArn?;
    get serviceRoleArn(): string;
    set serviceRoleArn(value: string);
    get serviceRoleArnInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _terminationHookEnabled?;
    get terminationHookEnabled(): boolean | cdktn.IResolvable;
    set terminationHookEnabled(value: boolean | cdktn.IResolvable);
    resetTerminationHookEnabled(): void;
    get terminationHookEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _alarmConfiguration;
    get alarmConfiguration(): AwsCodedeployDeploymentGroup.AlarmConfigurationPropertyOutputReference;
    putAlarmConfiguration(value: AwsCodedeployDeploymentGroup.AlarmConfigurationProperty): void;
    resetAlarmConfiguration(): void;
    get alarmConfigurationInput(): AwsCodedeployDeploymentGroup.AlarmConfigurationProperty | undefined;
    private _autoRollbackConfiguration;
    get autoRollbackConfiguration(): AwsCodedeployDeploymentGroup.AutoRollbackConfigurationPropertyOutputReference;
    putAutoRollbackConfiguration(value: AwsCodedeployDeploymentGroup.AutoRollbackConfigurationProperty): void;
    resetAutoRollbackConfiguration(): void;
    get autoRollbackConfigurationInput(): AwsCodedeployDeploymentGroup.AutoRollbackConfigurationProperty | undefined;
    private _blueGreenDeploymentConfig;
    get blueGreenDeploymentConfig(): AwsCodedeployDeploymentGroup.BlueGreenDeploymentConfigPropertyOutputReference;
    putBlueGreenDeploymentConfig(value: AwsCodedeployDeploymentGroup.BlueGreenDeploymentConfigProperty): void;
    resetBlueGreenDeploymentConfig(): void;
    get blueGreenDeploymentConfigInput(): AwsCodedeployDeploymentGroup.BlueGreenDeploymentConfigProperty | undefined;
    private _deploymentStyle;
    get deploymentStyle(): AwsCodedeployDeploymentGroup.DeploymentStylePropertyOutputReference;
    putDeploymentStyle(value: AwsCodedeployDeploymentGroup.DeploymentStyleProperty): void;
    resetDeploymentStyle(): void;
    get deploymentStyleInput(): AwsCodedeployDeploymentGroup.DeploymentStyleProperty | undefined;
    private _ec2TagFilter;
    get ec2TagFilter(): AwsCodedeployDeploymentGroup.Ec2TagFilterPropertyList;
    putEc2TagFilter(value: AwsCodedeployDeploymentGroup.Ec2TagFilterProperty[] | cdktn.IResolvable): void;
    resetEc2TagFilter(): void;
    get ec2TagFilterInput(): cdktn.IResolvable | AwsCodedeployDeploymentGroup.Ec2TagFilterProperty[] | undefined;
    private _ec2TagSet;
    get ec2TagSet(): AwsCodedeployDeploymentGroup.Ec2TagSetPropertyList;
    putEc2TagSet(value: AwsCodedeployDeploymentGroup.Ec2TagSetProperty[] | cdktn.IResolvable): void;
    resetEc2TagSet(): void;
    get ec2TagSetInput(): cdktn.IResolvable | AwsCodedeployDeploymentGroup.Ec2TagSetProperty[] | undefined;
    private _ecsService;
    get ecsService(): AwsCodedeployDeploymentGroup.EcsServicePropertyOutputReference;
    putEcsService(value: AwsCodedeployDeploymentGroup.EcsServiceProperty): void;
    resetEcsService(): void;
    get ecsServiceInput(): AwsCodedeployDeploymentGroup.EcsServiceProperty | undefined;
    private _loadBalancerInfo;
    get loadBalancerInfo(): AwsCodedeployDeploymentGroup.LoadBalancerInfoPropertyOutputReference;
    putLoadBalancerInfo(value: AwsCodedeployDeploymentGroup.LoadBalancerInfoProperty): void;
    resetLoadBalancerInfo(): void;
    get loadBalancerInfoInput(): AwsCodedeployDeploymentGroup.LoadBalancerInfoProperty | undefined;
    private _onPremisesInstanceTagFilter;
    get onPremisesInstanceTagFilter(): AwsCodedeployDeploymentGroup.OnPremisesInstanceTagFilterPropertyList;
    putOnPremisesInstanceTagFilter(value: AwsCodedeployDeploymentGroup.OnPremisesInstanceTagFilterProperty[] | cdktn.IResolvable): void;
    resetOnPremisesInstanceTagFilter(): void;
    get onPremisesInstanceTagFilterInput(): cdktn.IResolvable | AwsCodedeployDeploymentGroup.OnPremisesInstanceTagFilterProperty[] | undefined;
    private _triggerConfiguration;
    get triggerConfiguration(): AwsCodedeployDeploymentGroup.TriggerConfigurationPropertyList;
    putTriggerConfiguration(value: AwsCodedeployDeploymentGroup.TriggerConfigurationProperty[] | cdktn.IResolvable): void;
    resetTriggerConfiguration(): void;
    get triggerConfigurationInput(): cdktn.IResolvable | AwsCodedeployDeploymentGroup.TriggerConfigurationProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsCodedeployDeploymentGroupAlarmConfigurationPropertyToTerraform(struct?: AwsCodedeployDeploymentGroup.AlarmConfigurationPropertyOutputReference | AwsCodedeployDeploymentGroup.AlarmConfigurationProperty): any;
export declare function awsCodedeployDeploymentGroupAlarmConfigurationPropertyToHclTerraform(struct?: AwsCodedeployDeploymentGroup.AlarmConfigurationPropertyOutputReference | AwsCodedeployDeploymentGroup.AlarmConfigurationProperty): any;
export declare function awsCodedeployDeploymentGroupAutoRollbackConfigurationPropertyToTerraform(struct?: AwsCodedeployDeploymentGroup.AutoRollbackConfigurationPropertyOutputReference | AwsCodedeployDeploymentGroup.AutoRollbackConfigurationProperty): any;
export declare function awsCodedeployDeploymentGroupAutoRollbackConfigurationPropertyToHclTerraform(struct?: AwsCodedeployDeploymentGroup.AutoRollbackConfigurationPropertyOutputReference | AwsCodedeployDeploymentGroup.AutoRollbackConfigurationProperty): any;
export declare function awsCodedeployDeploymentGroupDeploymentReadyOptionPropertyToTerraform(struct?: AwsCodedeployDeploymentGroup.DeploymentReadyOptionPropertyOutputReference | AwsCodedeployDeploymentGroup.DeploymentReadyOptionProperty): any;
export declare function awsCodedeployDeploymentGroupDeploymentReadyOptionPropertyToHclTerraform(struct?: AwsCodedeployDeploymentGroup.DeploymentReadyOptionPropertyOutputReference | AwsCodedeployDeploymentGroup.DeploymentReadyOptionProperty): any;
export declare function awsCodedeployDeploymentGroupGreenFleetProvisioningOptionPropertyToTerraform(struct?: AwsCodedeployDeploymentGroup.GreenFleetProvisioningOptionPropertyOutputReference | AwsCodedeployDeploymentGroup.GreenFleetProvisioningOptionProperty): any;
export declare function awsCodedeployDeploymentGroupGreenFleetProvisioningOptionPropertyToHclTerraform(struct?: AwsCodedeployDeploymentGroup.GreenFleetProvisioningOptionPropertyOutputReference | AwsCodedeployDeploymentGroup.GreenFleetProvisioningOptionProperty): any;
export declare function awsCodedeployDeploymentGroupTerminateBlueInstancesOnDeploymentSuccessPropertyToTerraform(struct?: AwsCodedeployDeploymentGroup.TerminateBlueInstancesOnDeploymentSuccessPropertyOutputReference | AwsCodedeployDeploymentGroup.TerminateBlueInstancesOnDeploymentSuccessProperty): any;
export declare function awsCodedeployDeploymentGroupTerminateBlueInstancesOnDeploymentSuccessPropertyToHclTerraform(struct?: AwsCodedeployDeploymentGroup.TerminateBlueInstancesOnDeploymentSuccessPropertyOutputReference | AwsCodedeployDeploymentGroup.TerminateBlueInstancesOnDeploymentSuccessProperty): any;
export declare function awsCodedeployDeploymentGroupBlueGreenDeploymentConfigPropertyToTerraform(struct?: AwsCodedeployDeploymentGroup.BlueGreenDeploymentConfigPropertyOutputReference | AwsCodedeployDeploymentGroup.BlueGreenDeploymentConfigProperty): any;
export declare function awsCodedeployDeploymentGroupBlueGreenDeploymentConfigPropertyToHclTerraform(struct?: AwsCodedeployDeploymentGroup.BlueGreenDeploymentConfigPropertyOutputReference | AwsCodedeployDeploymentGroup.BlueGreenDeploymentConfigProperty): any;
export declare function awsCodedeployDeploymentGroupDeploymentStylePropertyToTerraform(struct?: AwsCodedeployDeploymentGroup.DeploymentStylePropertyOutputReference | AwsCodedeployDeploymentGroup.DeploymentStyleProperty): any;
export declare function awsCodedeployDeploymentGroupDeploymentStylePropertyToHclTerraform(struct?: AwsCodedeployDeploymentGroup.DeploymentStylePropertyOutputReference | AwsCodedeployDeploymentGroup.DeploymentStyleProperty): any;
export declare function awsCodedeployDeploymentGroupEc2TagFilterPropertyToTerraform(struct?: AwsCodedeployDeploymentGroup.Ec2TagFilterProperty | cdktn.IResolvable): any;
export declare function awsCodedeployDeploymentGroupEc2TagFilterPropertyToHclTerraform(struct?: AwsCodedeployDeploymentGroup.Ec2TagFilterProperty | cdktn.IResolvable): any;
export declare function awsCodedeployDeploymentGroupEc2TagSetEc2TagFilterPropertyToTerraform(struct?: AwsCodedeployDeploymentGroup.Ec2TagSetEc2TagFilterProperty | cdktn.IResolvable): any;
export declare function awsCodedeployDeploymentGroupEc2TagSetEc2TagFilterPropertyToHclTerraform(struct?: AwsCodedeployDeploymentGroup.Ec2TagSetEc2TagFilterProperty | cdktn.IResolvable): any;
export declare function awsCodedeployDeploymentGroupEc2TagSetPropertyToTerraform(struct?: AwsCodedeployDeploymentGroup.Ec2TagSetProperty | cdktn.IResolvable): any;
export declare function awsCodedeployDeploymentGroupEc2TagSetPropertyToHclTerraform(struct?: AwsCodedeployDeploymentGroup.Ec2TagSetProperty | cdktn.IResolvable): any;
export declare function awsCodedeployDeploymentGroupEcsServicePropertyToTerraform(struct?: AwsCodedeployDeploymentGroup.EcsServicePropertyOutputReference | AwsCodedeployDeploymentGroup.EcsServiceProperty): any;
export declare function awsCodedeployDeploymentGroupEcsServicePropertyToHclTerraform(struct?: AwsCodedeployDeploymentGroup.EcsServicePropertyOutputReference | AwsCodedeployDeploymentGroup.EcsServiceProperty): any;
export declare function awsCodedeployDeploymentGroupElbInfoPropertyToTerraform(struct?: AwsCodedeployDeploymentGroup.ElbInfoProperty | cdktn.IResolvable): any;
export declare function awsCodedeployDeploymentGroupElbInfoPropertyToHclTerraform(struct?: AwsCodedeployDeploymentGroup.ElbInfoProperty | cdktn.IResolvable): any;
export declare function awsCodedeployDeploymentGroupTargetGroupInfoPropertyToTerraform(struct?: AwsCodedeployDeploymentGroup.TargetGroupInfoProperty | cdktn.IResolvable): any;
export declare function awsCodedeployDeploymentGroupTargetGroupInfoPropertyToHclTerraform(struct?: AwsCodedeployDeploymentGroup.TargetGroupInfoProperty | cdktn.IResolvable): any;
export declare function awsCodedeployDeploymentGroupProdTrafficRoutePropertyToTerraform(struct?: AwsCodedeployDeploymentGroup.ProdTrafficRoutePropertyOutputReference | AwsCodedeployDeploymentGroup.ProdTrafficRouteProperty): any;
export declare function awsCodedeployDeploymentGroupProdTrafficRoutePropertyToHclTerraform(struct?: AwsCodedeployDeploymentGroup.ProdTrafficRoutePropertyOutputReference | AwsCodedeployDeploymentGroup.ProdTrafficRouteProperty): any;
export declare function awsCodedeployDeploymentGroupTargetGroupPropertyToTerraform(struct?: AwsCodedeployDeploymentGroup.TargetGroupProperty | cdktn.IResolvable): any;
export declare function awsCodedeployDeploymentGroupTargetGroupPropertyToHclTerraform(struct?: AwsCodedeployDeploymentGroup.TargetGroupProperty | cdktn.IResolvable): any;
export declare function awsCodedeployDeploymentGroupTestTrafficRoutePropertyToTerraform(struct?: AwsCodedeployDeploymentGroup.TestTrafficRoutePropertyOutputReference | AwsCodedeployDeploymentGroup.TestTrafficRouteProperty): any;
export declare function awsCodedeployDeploymentGroupTestTrafficRoutePropertyToHclTerraform(struct?: AwsCodedeployDeploymentGroup.TestTrafficRoutePropertyOutputReference | AwsCodedeployDeploymentGroup.TestTrafficRouteProperty): any;
export declare function awsCodedeployDeploymentGroupTargetGroupPairInfoPropertyToTerraform(struct?: AwsCodedeployDeploymentGroup.TargetGroupPairInfoPropertyOutputReference | AwsCodedeployDeploymentGroup.TargetGroupPairInfoProperty): any;
export declare function awsCodedeployDeploymentGroupTargetGroupPairInfoPropertyToHclTerraform(struct?: AwsCodedeployDeploymentGroup.TargetGroupPairInfoPropertyOutputReference | AwsCodedeployDeploymentGroup.TargetGroupPairInfoProperty): any;
export declare function awsCodedeployDeploymentGroupLoadBalancerInfoPropertyToTerraform(struct?: AwsCodedeployDeploymentGroup.LoadBalancerInfoPropertyOutputReference | AwsCodedeployDeploymentGroup.LoadBalancerInfoProperty): any;
export declare function awsCodedeployDeploymentGroupLoadBalancerInfoPropertyToHclTerraform(struct?: AwsCodedeployDeploymentGroup.LoadBalancerInfoPropertyOutputReference | AwsCodedeployDeploymentGroup.LoadBalancerInfoProperty): any;
export declare function awsCodedeployDeploymentGroupOnPremisesInstanceTagFilterPropertyToTerraform(struct?: AwsCodedeployDeploymentGroup.OnPremisesInstanceTagFilterProperty | cdktn.IResolvable): any;
export declare function awsCodedeployDeploymentGroupOnPremisesInstanceTagFilterPropertyToHclTerraform(struct?: AwsCodedeployDeploymentGroup.OnPremisesInstanceTagFilterProperty | cdktn.IResolvable): any;
export declare function awsCodedeployDeploymentGroupTriggerConfigurationPropertyToTerraform(struct?: AwsCodedeployDeploymentGroup.TriggerConfigurationProperty | cdktn.IResolvable): any;
export declare function awsCodedeployDeploymentGroupTriggerConfigurationPropertyToHclTerraform(struct?: AwsCodedeployDeploymentGroup.TriggerConfigurationProperty | cdktn.IResolvable): any;
export declare namespace AwsCodedeployDeploymentGroup {
    interface AlarmConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#alarms AwsCodedeployDeploymentGroup#alarms}
        */
        readonly alarms?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#enabled AwsCodedeployDeploymentGroup#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#ignore_poll_alarm_failure AwsCodedeployDeploymentGroup#ignore_poll_alarm_failure}
        */
        readonly ignorePollAlarmFailure?: boolean | cdktn.IResolvable;
    }
    class AlarmConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AlarmConfigurationProperty | undefined;
        set internalValue(value: AlarmConfigurationProperty | undefined);
        private _alarms?;
        get alarms(): string[];
        set alarms(value: string[]);
        resetAlarms(): void;
        get alarmsInput(): string[] | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _ignorePollAlarmFailure?;
        get ignorePollAlarmFailure(): boolean | cdktn.IResolvable;
        set ignorePollAlarmFailure(value: boolean | cdktn.IResolvable);
        resetIgnorePollAlarmFailure(): void;
        get ignorePollAlarmFailureInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface AutoRollbackConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#enabled AwsCodedeployDeploymentGroup#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#events AwsCodedeployDeploymentGroup#events}
        */
        readonly events?: string[];
    }
    class AutoRollbackConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AutoRollbackConfigurationProperty | undefined;
        set internalValue(value: AutoRollbackConfigurationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _events?;
        get events(): string[];
        set events(value: string[]);
        resetEvents(): void;
        get eventsInput(): string[] | undefined;
    }
    interface DeploymentReadyOptionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#action_on_timeout AwsCodedeployDeploymentGroup#action_on_timeout}
        */
        readonly actionOnTimeout?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#wait_time_in_minutes AwsCodedeployDeploymentGroup#wait_time_in_minutes}
        */
        readonly waitTimeInMinutes?: number;
    }
    class DeploymentReadyOptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DeploymentReadyOptionProperty | undefined;
        set internalValue(value: DeploymentReadyOptionProperty | undefined);
        private _actionOnTimeout?;
        get actionOnTimeout(): string;
        set actionOnTimeout(value: string);
        resetActionOnTimeout(): void;
        get actionOnTimeoutInput(): string | undefined;
        private _waitTimeInMinutes?;
        get waitTimeInMinutes(): number;
        set waitTimeInMinutes(value: number);
        resetWaitTimeInMinutes(): void;
        get waitTimeInMinutesInput(): number | undefined;
    }
    interface GreenFleetProvisioningOptionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#action AwsCodedeployDeploymentGroup#action}
        */
        readonly action?: string;
    }
    class GreenFleetProvisioningOptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): GreenFleetProvisioningOptionProperty | undefined;
        set internalValue(value: GreenFleetProvisioningOptionProperty | undefined);
        private _action?;
        get action(): string;
        set action(value: string);
        resetAction(): void;
        get actionInput(): string | undefined;
    }
    interface TerminateBlueInstancesOnDeploymentSuccessProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#action AwsCodedeployDeploymentGroup#action}
        */
        readonly action?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#termination_wait_time_in_minutes AwsCodedeployDeploymentGroup#termination_wait_time_in_minutes}
        */
        readonly terminationWaitTimeInMinutes?: number;
    }
    class TerminateBlueInstancesOnDeploymentSuccessPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TerminateBlueInstancesOnDeploymentSuccessProperty | undefined;
        set internalValue(value: TerminateBlueInstancesOnDeploymentSuccessProperty | undefined);
        private _action?;
        get action(): string;
        set action(value: string);
        resetAction(): void;
        get actionInput(): string | undefined;
        private _terminationWaitTimeInMinutes?;
        get terminationWaitTimeInMinutes(): number;
        set terminationWaitTimeInMinutes(value: number);
        resetTerminationWaitTimeInMinutes(): void;
        get terminationWaitTimeInMinutesInput(): number | undefined;
    }
    interface BlueGreenDeploymentConfigProperty {
        /**
        * deployment_ready_option block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#deployment_ready_option AwsCodedeployDeploymentGroup#deployment_ready_option}
        */
        readonly deploymentReadyOption?: DeploymentReadyOptionProperty;
        /**
        * green_fleet_provisioning_option block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#green_fleet_provisioning_option AwsCodedeployDeploymentGroup#green_fleet_provisioning_option}
        */
        readonly greenFleetProvisioningOption?: GreenFleetProvisioningOptionProperty;
        /**
        * terminate_blue_instances_on_deployment_success block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#terminate_blue_instances_on_deployment_success AwsCodedeployDeploymentGroup#terminate_blue_instances_on_deployment_success}
        */
        readonly terminateBlueInstancesOnDeploymentSuccess?: TerminateBlueInstancesOnDeploymentSuccessProperty;
    }
    class BlueGreenDeploymentConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BlueGreenDeploymentConfigProperty | undefined;
        set internalValue(value: BlueGreenDeploymentConfigProperty | undefined);
        private _deploymentReadyOption;
        get deploymentReadyOption(): DeploymentReadyOptionPropertyOutputReference;
        putDeploymentReadyOption(value: DeploymentReadyOptionProperty): void;
        resetDeploymentReadyOption(): void;
        get deploymentReadyOptionInput(): DeploymentReadyOptionProperty | undefined;
        private _greenFleetProvisioningOption;
        get greenFleetProvisioningOption(): GreenFleetProvisioningOptionPropertyOutputReference;
        putGreenFleetProvisioningOption(value: GreenFleetProvisioningOptionProperty): void;
        resetGreenFleetProvisioningOption(): void;
        get greenFleetProvisioningOptionInput(): GreenFleetProvisioningOptionProperty | undefined;
        private _terminateBlueInstancesOnDeploymentSuccess;
        get terminateBlueInstancesOnDeploymentSuccess(): TerminateBlueInstancesOnDeploymentSuccessPropertyOutputReference;
        putTerminateBlueInstancesOnDeploymentSuccess(value: TerminateBlueInstancesOnDeploymentSuccessProperty): void;
        resetTerminateBlueInstancesOnDeploymentSuccess(): void;
        get terminateBlueInstancesOnDeploymentSuccessInput(): TerminateBlueInstancesOnDeploymentSuccessProperty | undefined;
    }
    interface DeploymentStyleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#deployment_option AwsCodedeployDeploymentGroup#deployment_option}
        */
        readonly deploymentOption?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#deployment_type AwsCodedeployDeploymentGroup#deployment_type}
        */
        readonly deploymentType?: string;
    }
    class DeploymentStylePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DeploymentStyleProperty | undefined;
        set internalValue(value: DeploymentStyleProperty | undefined);
        private _deploymentOption?;
        get deploymentOption(): string;
        set deploymentOption(value: string);
        resetDeploymentOption(): void;
        get deploymentOptionInput(): string | undefined;
        private _deploymentType?;
        get deploymentType(): string;
        set deploymentType(value: string);
        resetDeploymentType(): void;
        get deploymentTypeInput(): string | undefined;
    }
    interface Ec2TagFilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#key AwsCodedeployDeploymentGroup#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#type AwsCodedeployDeploymentGroup#type}
        */
        readonly type?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#value AwsCodedeployDeploymentGroup#value}
        */
        readonly value?: string;
    }
    class Ec2TagFilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): Ec2TagFilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: Ec2TagFilterProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
    class Ec2TagFilterPropertyList extends cdktn.ComplexList {
        internalValue?: Ec2TagFilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): Ec2TagFilterPropertyOutputReference;
    }
    interface Ec2TagSetEc2TagFilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#key AwsCodedeployDeploymentGroup#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#type AwsCodedeployDeploymentGroup#type}
        */
        readonly type?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#value AwsCodedeployDeploymentGroup#value}
        */
        readonly value?: string;
    }
    class Ec2TagSetEc2TagFilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): Ec2TagSetEc2TagFilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: Ec2TagSetEc2TagFilterProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
    class Ec2TagSetEc2TagFilterPropertyList extends cdktn.ComplexList {
        internalValue?: Ec2TagSetEc2TagFilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): Ec2TagSetEc2TagFilterPropertyOutputReference;
    }
    interface Ec2TagSetProperty {
        /**
        * ec2_tag_filter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#ec2_tag_filter AwsCodedeployDeploymentGroup#ec2_tag_filter}
        */
        readonly ec2TagFilter?: Ec2TagSetEc2TagFilterProperty[] | cdktn.IResolvable;
    }
    class Ec2TagSetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): Ec2TagSetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: Ec2TagSetProperty | cdktn.IResolvable | undefined);
        private _ec2TagFilter;
        get ec2TagFilter(): Ec2TagSetEc2TagFilterPropertyList;
        putEc2TagFilter(value: Ec2TagSetEc2TagFilterProperty[] | cdktn.IResolvable): void;
        resetEc2TagFilter(): void;
        get ec2TagFilterInput(): cdktn.IResolvable | Ec2TagSetEc2TagFilterProperty[] | undefined;
    }
    class Ec2TagSetPropertyList extends cdktn.ComplexList {
        internalValue?: Ec2TagSetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): Ec2TagSetPropertyOutputReference;
    }
    interface EcsServiceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#cluster_name AwsCodedeployDeploymentGroup#cluster_name}
        */
        readonly clusterName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#service_name AwsCodedeployDeploymentGroup#service_name}
        */
        readonly serviceName: string;
    }
    class EcsServicePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EcsServiceProperty | undefined;
        set internalValue(value: EcsServiceProperty | undefined);
        private _clusterName?;
        get clusterName(): string;
        set clusterName(value: string);
        get clusterNameInput(): string | undefined;
        private _serviceName?;
        get serviceName(): string;
        set serviceName(value: string);
        get serviceNameInput(): string | undefined;
    }
    interface ElbInfoProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#name AwsCodedeployDeploymentGroup#name}
        */
        readonly name?: string;
    }
    class ElbInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ElbInfoProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ElbInfoProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
    }
    class ElbInfoPropertyList extends cdktn.ComplexList {
        internalValue?: ElbInfoProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ElbInfoPropertyOutputReference;
    }
    interface TargetGroupInfoProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#name AwsCodedeployDeploymentGroup#name}
        */
        readonly name?: string;
    }
    class TargetGroupInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetGroupInfoProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetGroupInfoProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
    }
    class TargetGroupInfoPropertyList extends cdktn.ComplexList {
        internalValue?: TargetGroupInfoProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetGroupInfoPropertyOutputReference;
    }
    interface ProdTrafficRouteProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#listener_arns AwsCodedeployDeploymentGroup#listener_arns}
        */
        readonly listenerArns: string[];
    }
    class ProdTrafficRoutePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ProdTrafficRouteProperty | undefined;
        set internalValue(value: ProdTrafficRouteProperty | undefined);
        private _listenerArns?;
        get listenerArns(): string[];
        set listenerArns(value: string[]);
        get listenerArnsInput(): string[] | undefined;
    }
    interface TargetGroupProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#name AwsCodedeployDeploymentGroup#name}
        */
        readonly name: string;
    }
    class TargetGroupPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TargetGroupProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TargetGroupProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    class TargetGroupPropertyList extends cdktn.ComplexList {
        internalValue?: TargetGroupProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TargetGroupPropertyOutputReference;
    }
    interface TestTrafficRouteProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#listener_arns AwsCodedeployDeploymentGroup#listener_arns}
        */
        readonly listenerArns: string[];
    }
    class TestTrafficRoutePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TestTrafficRouteProperty | undefined;
        set internalValue(value: TestTrafficRouteProperty | undefined);
        private _listenerArns?;
        get listenerArns(): string[];
        set listenerArns(value: string[]);
        get listenerArnsInput(): string[] | undefined;
    }
    interface TargetGroupPairInfoProperty {
        /**
        * prod_traffic_route block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#prod_traffic_route AwsCodedeployDeploymentGroup#prod_traffic_route}
        */
        readonly prodTrafficRoute: ProdTrafficRouteProperty;
        /**
        * target_group block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#target_group AwsCodedeployDeploymentGroup#target_group}
        */
        readonly targetGroup: TargetGroupProperty[] | cdktn.IResolvable;
        /**
        * test_traffic_route block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#test_traffic_route AwsCodedeployDeploymentGroup#test_traffic_route}
        */
        readonly testTrafficRoute?: TestTrafficRouteProperty;
    }
    class TargetGroupPairInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TargetGroupPairInfoProperty | undefined;
        set internalValue(value: TargetGroupPairInfoProperty | undefined);
        private _prodTrafficRoute;
        get prodTrafficRoute(): ProdTrafficRoutePropertyOutputReference;
        putProdTrafficRoute(value: ProdTrafficRouteProperty): void;
        get prodTrafficRouteInput(): ProdTrafficRouteProperty | undefined;
        private _targetGroup;
        get targetGroup(): TargetGroupPropertyList;
        putTargetGroup(value: TargetGroupProperty[] | cdktn.IResolvable): void;
        get targetGroupInput(): cdktn.IResolvable | TargetGroupProperty[] | undefined;
        private _testTrafficRoute;
        get testTrafficRoute(): TestTrafficRoutePropertyOutputReference;
        putTestTrafficRoute(value: TestTrafficRouteProperty): void;
        resetTestTrafficRoute(): void;
        get testTrafficRouteInput(): TestTrafficRouteProperty | undefined;
    }
    interface LoadBalancerInfoProperty {
        /**
        * elb_info block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#elb_info AwsCodedeployDeploymentGroup#elb_info}
        */
        readonly elbInfo?: ElbInfoProperty[] | cdktn.IResolvable;
        /**
        * target_group_info block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#target_group_info AwsCodedeployDeploymentGroup#target_group_info}
        */
        readonly targetGroupInfo?: TargetGroupInfoProperty[] | cdktn.IResolvable;
        /**
        * target_group_pair_info block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#target_group_pair_info AwsCodedeployDeploymentGroup#target_group_pair_info}
        */
        readonly targetGroupPairInfo?: TargetGroupPairInfoProperty;
    }
    class LoadBalancerInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LoadBalancerInfoProperty | undefined;
        set internalValue(value: LoadBalancerInfoProperty | undefined);
        private _elbInfo;
        get elbInfo(): ElbInfoPropertyList;
        putElbInfo(value: ElbInfoProperty[] | cdktn.IResolvable): void;
        resetElbInfo(): void;
        get elbInfoInput(): cdktn.IResolvable | ElbInfoProperty[] | undefined;
        private _targetGroupInfo;
        get targetGroupInfo(): TargetGroupInfoPropertyList;
        putTargetGroupInfo(value: TargetGroupInfoProperty[] | cdktn.IResolvable): void;
        resetTargetGroupInfo(): void;
        get targetGroupInfoInput(): cdktn.IResolvable | TargetGroupInfoProperty[] | undefined;
        private _targetGroupPairInfo;
        get targetGroupPairInfo(): TargetGroupPairInfoPropertyOutputReference;
        putTargetGroupPairInfo(value: TargetGroupPairInfoProperty): void;
        resetTargetGroupPairInfo(): void;
        get targetGroupPairInfoInput(): TargetGroupPairInfoProperty | undefined;
    }
    interface OnPremisesInstanceTagFilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#key AwsCodedeployDeploymentGroup#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#type AwsCodedeployDeploymentGroup#type}
        */
        readonly type?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#value AwsCodedeployDeploymentGroup#value}
        */
        readonly value?: string;
    }
    class OnPremisesInstanceTagFilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OnPremisesInstanceTagFilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OnPremisesInstanceTagFilterProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
    class OnPremisesInstanceTagFilterPropertyList extends cdktn.ComplexList {
        internalValue?: OnPremisesInstanceTagFilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OnPremisesInstanceTagFilterPropertyOutputReference;
    }
    interface TriggerConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#trigger_events AwsCodedeployDeploymentGroup#trigger_events}
        */
        readonly triggerEvents: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#trigger_name AwsCodedeployDeploymentGroup#trigger_name}
        */
        readonly triggerName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codedeploy_deployment_group#trigger_target_arn AwsCodedeployDeploymentGroup#trigger_target_arn}
        */
        readonly triggerTargetArn: string;
    }
    class TriggerConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TriggerConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TriggerConfigurationProperty | cdktn.IResolvable | undefined);
        private _triggerEvents?;
        get triggerEvents(): string[];
        set triggerEvents(value: string[]);
        get triggerEventsInput(): string[] | undefined;
        private _triggerName?;
        get triggerName(): string;
        set triggerName(value: string);
        get triggerNameInput(): string | undefined;
        private _triggerTargetArn?;
        get triggerTargetArn(): string;
        set triggerTargetArn(value: string);
        get triggerTargetArnInput(): string | undefined;
    }
    class TriggerConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: TriggerConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TriggerConfigurationPropertyOutputReference;
    }
}
