import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfPoolCidrConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool_cidr#cidr TfPoolCidr#cidr}
    */
    readonly cidr?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool_cidr#id TfPoolCidr#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool_cidr#ipam_pool_id TfPoolCidr#ipam_pool_id}
    */
    readonly ipamPoolId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool_cidr#netmask_length TfPoolCidr#netmask_length}
    */
    readonly netmaskLength?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool_cidr#region TfPoolCidr#region}
    */
    readonly region?: string;
    /**
    * cidr_authorization_context block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool_cidr#cidr_authorization_context TfPoolCidr#cidr_authorization_context}
    */
    readonly cidrAuthorizationContext?: TfPoolCidr.CidrAuthorizationContextProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool_cidr#timeouts TfPoolCidr#timeouts}
    */
    readonly timeouts?: TfPoolCidr.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool_cidr aws_vpc_ipam_pool_cidr}
*/
export declare class TfPoolCidr extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_vpc_ipam_pool_cidr";
    /**
    * Generates CDKTN code for importing a TfPoolCidr resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfPoolCidr to import
    * @param importFromId The id of the existing TfPoolCidr that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool_cidr#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfPoolCidr to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool_cidr aws_vpc_ipam_pool_cidr} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfPoolCidrConfig
    */
    constructor(scope: Construct, id: string, config: TfPoolCidrConfig);
    private _cidr?;
    get cidr(): string;
    set cidr(value: string);
    resetCidr(): void;
    get cidrInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ipamPoolCidrId(): string;
    private _ipamPoolId?;
    get ipamPoolId(): string;
    set ipamPoolId(value: string);
    get ipamPoolIdInput(): string | undefined;
    private _netmaskLength?;
    get netmaskLength(): number;
    set netmaskLength(value: number);
    resetNetmaskLength(): void;
    get netmaskLengthInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _cidrAuthorizationContext;
    get cidrAuthorizationContext(): TfPoolCidr.CidrAuthorizationContextPropertyOutputReference;
    putCidrAuthorizationContext(value: TfPoolCidr.CidrAuthorizationContextProperty): void;
    resetCidrAuthorizationContext(): void;
    get cidrAuthorizationContextInput(): TfPoolCidr.CidrAuthorizationContextProperty | undefined;
    private _timeouts;
    get timeouts(): TfPoolCidr.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfPoolCidr.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): TfPoolCidr.TimeoutsProperty | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfPoolCidrCidrAuthorizationContextPropertyToTerraform(struct?: TfPoolCidr.CidrAuthorizationContextPropertyOutputReference | TfPoolCidr.CidrAuthorizationContextProperty): any;
export declare function tfPoolCidrCidrAuthorizationContextPropertyToHclTerraform(struct?: TfPoolCidr.CidrAuthorizationContextPropertyOutputReference | TfPoolCidr.CidrAuthorizationContextProperty): any;
export declare function tfPoolCidrTimeoutsPropertyToTerraform(struct?: TfPoolCidr.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfPoolCidrTimeoutsPropertyToHclTerraform(struct?: TfPoolCidr.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfPoolCidr {
    interface CidrAuthorizationContextProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool_cidr#message TfPoolCidr#message}
        */
        readonly message?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool_cidr#signature TfPoolCidr#signature}
        */
        readonly signature?: string;
    }
    class CidrAuthorizationContextPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CidrAuthorizationContextProperty | undefined;
        set internalValue(value: CidrAuthorizationContextProperty | undefined);
        private _message?;
        get message(): string;
        set message(value: string);
        resetMessage(): void;
        get messageInput(): string | undefined;
        private _signature?;
        get signature(): string;
        set signature(value: string);
        resetSignature(): void;
        get signatureInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool_cidr#create TfPoolCidr#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool_cidr#delete TfPoolCidr#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
