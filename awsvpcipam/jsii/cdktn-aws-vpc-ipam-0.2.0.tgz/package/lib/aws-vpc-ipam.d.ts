import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfVpcIpamConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam#cascade TfVpcIpam#cascade}
    */
    readonly cascade?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam#description TfVpcIpam#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam#enable_private_gua TfVpcIpam#enable_private_gua}
    */
    readonly enablePrivateGua?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam#id TfVpcIpam#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam#metered_account TfVpcIpam#metered_account}
    */
    readonly meteredAccount?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam#region TfVpcIpam#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam#tags TfVpcIpam#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam#tags_all TfVpcIpam#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam#tier TfVpcIpam#tier}
    */
    readonly tier?: string;
    /**
    * operating_regions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam#operating_regions TfVpcIpam#operating_regions}
    */
    readonly operatingRegions: TfVpcIpam.OperatingRegionsProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam#timeouts TfVpcIpam#timeouts}
    */
    readonly timeouts?: TfVpcIpam.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam aws_vpc_ipam}
*/
export declare class TfVpcIpam extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_vpc_ipam";
    /**
    * Generates CDKTN code for importing a TfVpcIpam resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfVpcIpam to import
    * @param importFromId The id of the existing TfVpcIpam that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfVpcIpam to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam aws_vpc_ipam} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfVpcIpamConfig
    */
    constructor(scope: Construct, id: string, config: TfVpcIpamConfig);
    get arn(): string;
    private _cascade?;
    get cascade(): boolean | cdktn.IResolvable;
    set cascade(value: boolean | cdktn.IResolvable);
    resetCascade(): void;
    get cascadeInput(): boolean | cdktn.IResolvable | undefined;
    get defaultResourceDiscoveryAssociationId(): string;
    get defaultResourceDiscoveryId(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enablePrivateGua?;
    get enablePrivateGua(): boolean | cdktn.IResolvable;
    set enablePrivateGua(value: boolean | cdktn.IResolvable);
    resetEnablePrivateGua(): void;
    get enablePrivateGuaInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _meteredAccount?;
    get meteredAccount(): string;
    set meteredAccount(value: string);
    resetMeteredAccount(): void;
    get meteredAccountInput(): string | undefined;
    get privateDefaultScopeId(): string;
    get publicDefaultScopeId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get scopeCount(): number;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _tier?;
    get tier(): string;
    set tier(value: string);
    resetTier(): void;
    get tierInput(): string | undefined;
    private _operatingRegions;
    get operatingRegions(): TfVpcIpam.OperatingRegionsPropertyList;
    putOperatingRegions(value: TfVpcIpam.OperatingRegionsProperty[] | cdktn.IResolvable): void;
    get operatingRegionsInput(): cdktn.IResolvable | TfVpcIpam.OperatingRegionsProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfVpcIpam.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfVpcIpam.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfVpcIpam.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfVpcIpamOperatingRegionsPropertyToTerraform(struct?: TfVpcIpam.OperatingRegionsProperty | cdktn.IResolvable): any;
export declare function tfVpcIpamOperatingRegionsPropertyToHclTerraform(struct?: TfVpcIpam.OperatingRegionsProperty | cdktn.IResolvable): any;
export declare function tfVpcIpamTimeoutsPropertyToTerraform(struct?: TfVpcIpam.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfVpcIpamTimeoutsPropertyToHclTerraform(struct?: TfVpcIpam.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfVpcIpam {
    interface OperatingRegionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam#region_name TfVpcIpam#region_name}
        */
        readonly regionName: string;
    }
    class OperatingRegionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OperatingRegionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OperatingRegionsProperty | cdktn.IResolvable | undefined);
        private _regionName?;
        get regionName(): string;
        set regionName(value: string);
        get regionNameInput(): string | undefined;
    }
    class OperatingRegionsPropertyList extends cdktn.ComplexList {
        internalValue?: OperatingRegionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OperatingRegionsPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam#create TfVpcIpam#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam#delete TfVpcIpam#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam#update TfVpcIpam#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
