import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsVpcIpamPoolCidrConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool_cidr#cidr AwsVpcIpamPoolCidr#cidr}
    */
    readonly cidr?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool_cidr#id AwsVpcIpamPoolCidr#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool_cidr#ipam_pool_id AwsVpcIpamPoolCidr#ipam_pool_id}
    */
    readonly ipamPoolId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool_cidr#netmask_length AwsVpcIpamPoolCidr#netmask_length}
    */
    readonly netmaskLength?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool_cidr#region AwsVpcIpamPoolCidr#region}
    */
    readonly region?: string;
    /**
    * cidr_authorization_context block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool_cidr#cidr_authorization_context AwsVpcIpamPoolCidr#cidr_authorization_context}
    */
    readonly cidrAuthorizationContext?: AwsVpcIpamPoolCidr.CidrAuthorizationContextProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool_cidr#timeouts AwsVpcIpamPoolCidr#timeouts}
    */
    readonly timeouts?: AwsVpcIpamPoolCidr.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool_cidr aws_vpc_ipam_pool_cidr}
*/
export declare class AwsVpcIpamPoolCidr extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_vpc_ipam_pool_cidr";
    /**
    * Generates CDKTN code for importing a AwsVpcIpamPoolCidr resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsVpcIpamPoolCidr to import
    * @param importFromId The id of the existing AwsVpcIpamPoolCidr that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool_cidr#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsVpcIpamPoolCidr to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool_cidr aws_vpc_ipam_pool_cidr} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsVpcIpamPoolCidrConfig
    */
    constructor(scope: Construct, id: string, config: AwsVpcIpamPoolCidrConfig);
    private _cidr?;
    get cidr(): string;
    set cidr(value: string);
    resetCidr(): void;
    get cidrInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ipamPoolCidrId(): string;
    private _ipamPoolId?;
    get ipamPoolId(): string;
    set ipamPoolId(value: string);
    get ipamPoolIdInput(): string | undefined;
    private _netmaskLength?;
    get netmaskLength(): number;
    set netmaskLength(value: number);
    resetNetmaskLength(): void;
    get netmaskLengthInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _cidrAuthorizationContext;
    get cidrAuthorizationContext(): AwsVpcIpamPoolCidr.CidrAuthorizationContextPropertyOutputReference;
    putCidrAuthorizationContext(value: AwsVpcIpamPoolCidr.CidrAuthorizationContextProperty): void;
    resetCidrAuthorizationContext(): void;
    get cidrAuthorizationContextInput(): AwsVpcIpamPoolCidr.CidrAuthorizationContextProperty | undefined;
    private _timeouts;
    get timeouts(): AwsVpcIpamPoolCidr.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsVpcIpamPoolCidr.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): AwsVpcIpamPoolCidr.TimeoutsProperty | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsVpcIpamPoolCidrCidrAuthorizationContextPropertyToTerraform(struct?: AwsVpcIpamPoolCidr.CidrAuthorizationContextPropertyOutputReference | AwsVpcIpamPoolCidr.CidrAuthorizationContextProperty): any;
export declare function awsVpcIpamPoolCidrCidrAuthorizationContextPropertyToHclTerraform(struct?: AwsVpcIpamPoolCidr.CidrAuthorizationContextPropertyOutputReference | AwsVpcIpamPoolCidr.CidrAuthorizationContextProperty): any;
export declare function awsVpcIpamPoolCidrTimeoutsPropertyToTerraform(struct?: AwsVpcIpamPoolCidr.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsVpcIpamPoolCidrTimeoutsPropertyToHclTerraform(struct?: AwsVpcIpamPoolCidr.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsVpcIpamPoolCidr {
    interface CidrAuthorizationContextProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool_cidr#message AwsVpcIpamPoolCidr#message}
        */
        readonly message?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool_cidr#signature AwsVpcIpamPoolCidr#signature}
        */
        readonly signature?: string;
    }
    class CidrAuthorizationContextPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CidrAuthorizationContextProperty | undefined;
        set internalValue(value: CidrAuthorizationContextProperty | undefined);
        private _message?;
        get message(): string;
        set message(value: string);
        resetMessage(): void;
        get messageInput(): string | undefined;
        private _signature?;
        get signature(): string;
        set signature(value: string);
        resetSignature(): void;
        get signatureInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool_cidr#create AwsVpcIpamPoolCidr#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_pool_cidr#delete AwsVpcIpamPoolCidr#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
