import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsVpcIpamOrganizationAdminAccountConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_organization_admin_account#delegated_admin_account_id AwsVpcIpamOrganizationAdminAccount#delegated_admin_account_id}
    */
    readonly delegatedAdminAccountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_organization_admin_account#id AwsVpcIpamOrganizationAdminAccount#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_organization_admin_account aws_vpc_ipam_organization_admin_account}
*/
export declare class AwsVpcIpamOrganizationAdminAccount extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_vpc_ipam_organization_admin_account";
    /**
    * Generates CDKTN code for importing a AwsVpcIpamOrganizationAdminAccount resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsVpcIpamOrganizationAdminAccount to import
    * @param importFromId The id of the existing AwsVpcIpamOrganizationAdminAccount that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_organization_admin_account#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsVpcIpamOrganizationAdminAccount to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_organization_admin_account aws_vpc_ipam_organization_admin_account} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsVpcIpamOrganizationAdminAccountConfig
    */
    constructor(scope: Construct, id: string, config: AwsVpcIpamOrganizationAdminAccountConfig);
    get arn(): string;
    private _delegatedAdminAccountId?;
    get delegatedAdminAccountId(): string;
    set delegatedAdminAccountId(value: string);
    get delegatedAdminAccountIdInput(): string | undefined;
    get email(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get name(): string;
    get servicePrincipal(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
