import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsVpcIpamResourceDiscoveryConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_resource_discovery#description AwsVpcIpamResourceDiscovery#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_resource_discovery#id AwsVpcIpamResourceDiscovery#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_resource_discovery#region AwsVpcIpamResourceDiscovery#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_resource_discovery#tags AwsVpcIpamResourceDiscovery#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_resource_discovery#tags_all AwsVpcIpamResourceDiscovery#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * operating_regions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_resource_discovery#operating_regions AwsVpcIpamResourceDiscovery#operating_regions}
    */
    readonly operatingRegions: AwsVpcIpamResourceDiscovery.OperatingRegionsProperty[] | cdktn.IResolvable;
    /**
    * organizational_unit_exclusion block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_resource_discovery#organizational_unit_exclusion AwsVpcIpamResourceDiscovery#organizational_unit_exclusion}
    */
    readonly organizationalUnitExclusion?: AwsVpcIpamResourceDiscovery.OrganizationalUnitExclusionProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_resource_discovery#timeouts AwsVpcIpamResourceDiscovery#timeouts}
    */
    readonly timeouts?: AwsVpcIpamResourceDiscovery.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_resource_discovery aws_vpc_ipam_resource_discovery}
*/
export declare class AwsVpcIpamResourceDiscovery extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_vpc_ipam_resource_discovery";
    /**
    * Generates CDKTN code for importing a AwsVpcIpamResourceDiscovery resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsVpcIpamResourceDiscovery to import
    * @param importFromId The id of the existing AwsVpcIpamResourceDiscovery that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_resource_discovery#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsVpcIpamResourceDiscovery to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_resource_discovery aws_vpc_ipam_resource_discovery} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsVpcIpamResourceDiscoveryConfig
    */
    constructor(scope: Construct, id: string, config: AwsVpcIpamResourceDiscoveryConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ipamResourceDiscoveryRegion(): string;
    get isDefault(): cdktn.IResolvable;
    get ownerId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _operatingRegions;
    get operatingRegions(): AwsVpcIpamResourceDiscovery.OperatingRegionsPropertyList;
    putOperatingRegions(value: AwsVpcIpamResourceDiscovery.OperatingRegionsProperty[] | cdktn.IResolvable): void;
    get operatingRegionsInput(): cdktn.IResolvable | AwsVpcIpamResourceDiscovery.OperatingRegionsProperty[] | undefined;
    private _organizationalUnitExclusion;
    get organizationalUnitExclusion(): AwsVpcIpamResourceDiscovery.OrganizationalUnitExclusionPropertyList;
    putOrganizationalUnitExclusion(value: AwsVpcIpamResourceDiscovery.OrganizationalUnitExclusionProperty[] | cdktn.IResolvable): void;
    resetOrganizationalUnitExclusion(): void;
    get organizationalUnitExclusionInput(): cdktn.IResolvable | AwsVpcIpamResourceDiscovery.OrganizationalUnitExclusionProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsVpcIpamResourceDiscovery.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsVpcIpamResourceDiscovery.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsVpcIpamResourceDiscovery.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsVpcIpamResourceDiscoveryOperatingRegionsPropertyToTerraform(struct?: AwsVpcIpamResourceDiscovery.OperatingRegionsProperty | cdktn.IResolvable): any;
export declare function awsVpcIpamResourceDiscoveryOperatingRegionsPropertyToHclTerraform(struct?: AwsVpcIpamResourceDiscovery.OperatingRegionsProperty | cdktn.IResolvable): any;
export declare function awsVpcIpamResourceDiscoveryOrganizationalUnitExclusionPropertyToTerraform(struct?: AwsVpcIpamResourceDiscovery.OrganizationalUnitExclusionProperty | cdktn.IResolvable): any;
export declare function awsVpcIpamResourceDiscoveryOrganizationalUnitExclusionPropertyToHclTerraform(struct?: AwsVpcIpamResourceDiscovery.OrganizationalUnitExclusionProperty | cdktn.IResolvable): any;
export declare function awsVpcIpamResourceDiscoveryTimeoutsPropertyToTerraform(struct?: AwsVpcIpamResourceDiscovery.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsVpcIpamResourceDiscoveryTimeoutsPropertyToHclTerraform(struct?: AwsVpcIpamResourceDiscovery.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsVpcIpamResourceDiscovery {
    interface OperatingRegionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_resource_discovery#region_name AwsVpcIpamResourceDiscovery#region_name}
        */
        readonly regionName: string;
    }
    class OperatingRegionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OperatingRegionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OperatingRegionsProperty | cdktn.IResolvable | undefined);
        private _regionName?;
        get regionName(): string;
        set regionName(value: string);
        get regionNameInput(): string | undefined;
    }
    class OperatingRegionsPropertyList extends cdktn.ComplexList {
        internalValue?: OperatingRegionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OperatingRegionsPropertyOutputReference;
    }
    interface OrganizationalUnitExclusionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_resource_discovery#organizations_entity_path AwsVpcIpamResourceDiscovery#organizations_entity_path}
        */
        readonly organizationsEntityPath: string;
    }
    class OrganizationalUnitExclusionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OrganizationalUnitExclusionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OrganizationalUnitExclusionProperty | cdktn.IResolvable | undefined);
        private _organizationsEntityPath?;
        get organizationsEntityPath(): string;
        set organizationsEntityPath(value: string);
        get organizationsEntityPathInput(): string | undefined;
    }
    class OrganizationalUnitExclusionPropertyList extends cdktn.ComplexList {
        internalValue?: OrganizationalUnitExclusionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OrganizationalUnitExclusionPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_resource_discovery#create AwsVpcIpamResourceDiscovery#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_resource_discovery#delete AwsVpcIpamResourceDiscovery#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/vpc_ipam_resource_discovery#update AwsVpcIpamResourceDiscovery#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
