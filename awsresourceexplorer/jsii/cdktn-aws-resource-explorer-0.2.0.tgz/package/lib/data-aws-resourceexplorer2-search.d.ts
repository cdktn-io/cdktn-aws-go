import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfSearchConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/resourceexplorer2_search#query_string DataTfSearch#query_string}
    */
    readonly queryString: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/resourceexplorer2_search#region DataTfSearch#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/resourceexplorer2_search#view_arn DataTfSearch#view_arn}
    */
    readonly viewArn?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/resourceexplorer2_search aws_resourceexplorer2_search}
*/
export declare class DataTfSearch extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_resourceexplorer2_search";
    /**
    * Generates CDKTN code for importing a DataTfSearch resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfSearch to import
    * @param importFromId The id of the existing DataTfSearch that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/resourceexplorer2_search#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfSearch to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/resourceexplorer2_search aws_resourceexplorer2_search} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfSearchConfig
    */
    constructor(scope: Construct, id: string, config: DataTfSearchConfig);
    get id(): string;
    private _queryString?;
    get queryString(): string;
    set queryString(value: string);
    get queryStringInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourceCount;
    get resourceCount(): DataTfSearch.ResourceCountPropertyList;
    private _resources;
    get resources(): DataTfSearch.ResourcesPropertyList;
    private _viewArn?;
    get viewArn(): string;
    set viewArn(value: string);
    resetViewArn(): void;
    get viewArnInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfSearchResourceCountPropertyToTerraform(struct?: DataTfSearch.ResourceCountProperty): any;
export declare function dataTfSearchResourceCountPropertyToHclTerraform(struct?: DataTfSearch.ResourceCountProperty): any;
export declare function dataTfSearchPropertiesPropertyToTerraform(struct?: DataTfSearch.PropertiesProperty): any;
export declare function dataTfSearchPropertiesPropertyToHclTerraform(struct?: DataTfSearch.PropertiesProperty): any;
export declare function dataTfSearchResourcesPropertyToTerraform(struct?: DataTfSearch.ResourcesProperty): any;
export declare function dataTfSearchResourcesPropertyToHclTerraform(struct?: DataTfSearch.ResourcesProperty): any;
export declare namespace DataTfSearch {
    interface ResourceCountProperty {
    }
    class ResourceCountPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceCountProperty | undefined;
        set internalValue(value: ResourceCountProperty | undefined);
        get complete(): cdktn.IResolvable;
        get totalResources(): number;
    }
    class ResourceCountPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceCountPropertyOutputReference;
    }
    interface PropertiesProperty {
    }
    class PropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PropertiesProperty | undefined;
        set internalValue(value: PropertiesProperty | undefined);
        get data(): string;
        get lastReportedAt(): string;
        get name(): string;
    }
    class PropertiesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PropertiesPropertyOutputReference;
    }
    interface ResourcesProperty {
    }
    class ResourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourcesProperty | undefined;
        set internalValue(value: ResourcesProperty | undefined);
        get arn(): string;
        get lastReportedAt(): string;
        get owningAccountId(): string;
        private _properties;
        get properties(): PropertiesPropertyList;
        get region(): string;
        get resourceType(): string;
        get service(): string;
    }
    class ResourcesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourcesPropertyOutputReference;
    }
}
