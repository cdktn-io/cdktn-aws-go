import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsResourceexplorer2ViewConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resourceexplorer2_view#default_view AwsResourceexplorer2View#default_view}
    */
    readonly defaultView?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resourceexplorer2_view#name AwsResourceexplorer2View#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resourceexplorer2_view#region AwsResourceexplorer2View#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resourceexplorer2_view#scope AwsResourceexplorer2View#scope}
    */
    readonly scope?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resourceexplorer2_view#tags AwsResourceexplorer2View#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * filters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resourceexplorer2_view#filters AwsResourceexplorer2View#filters}
    */
    readonly filters?: AwsResourceexplorer2View.FiltersProperty[] | cdktn.IResolvable;
    /**
    * included_property block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resourceexplorer2_view#included_property AwsResourceexplorer2View#included_property}
    */
    readonly includedProperty?: AwsResourceexplorer2View.IncludedPropertyProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resourceexplorer2_view aws_resourceexplorer2_view}
*/
export declare class AwsResourceexplorer2View extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_resourceexplorer2_view";
    /**
    * Generates CDKTN code for importing a AwsResourceexplorer2View resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsResourceexplorer2View to import
    * @param importFromId The id of the existing AwsResourceexplorer2View that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resourceexplorer2_view#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsResourceexplorer2View to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resourceexplorer2_view aws_resourceexplorer2_view} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsResourceexplorer2ViewConfig
    */
    constructor(scope: Construct, id: string, config: AwsResourceexplorer2ViewConfig);
    get arn(): string;
    private _defaultView?;
    get defaultView(): boolean | cdktn.IResolvable;
    set defaultView(value: boolean | cdktn.IResolvable);
    resetDefaultView(): void;
    get defaultViewInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    resetScope(): void;
    get scopeInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _filters;
    get filters(): AwsResourceexplorer2View.FiltersPropertyList;
    putFilters(value: AwsResourceexplorer2View.FiltersProperty[] | cdktn.IResolvable): void;
    resetFilters(): void;
    get filtersInput(): cdktn.IResolvable | AwsResourceexplorer2View.FiltersProperty[] | undefined;
    private _includedProperty;
    get includedProperty(): AwsResourceexplorer2View.IncludedPropertyPropertyList;
    putIncludedProperty(value: AwsResourceexplorer2View.IncludedPropertyProperty[] | cdktn.IResolvable): void;
    resetIncludedProperty(): void;
    get includedPropertyInput(): cdktn.IResolvable | AwsResourceexplorer2View.IncludedPropertyProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsResourceexplorer2ViewFiltersPropertyToTerraform(struct?: AwsResourceexplorer2View.FiltersProperty | cdktn.IResolvable): any;
export declare function awsResourceexplorer2ViewFiltersPropertyToHclTerraform(struct?: AwsResourceexplorer2View.FiltersProperty | cdktn.IResolvable): any;
export declare function awsResourceexplorer2ViewIncludedPropertyPropertyToTerraform(struct?: AwsResourceexplorer2View.IncludedPropertyProperty | cdktn.IResolvable): any;
export declare function awsResourceexplorer2ViewIncludedPropertyPropertyToHclTerraform(struct?: AwsResourceexplorer2View.IncludedPropertyProperty | cdktn.IResolvable): any;
export declare namespace AwsResourceexplorer2View {
    interface FiltersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resourceexplorer2_view#filter_string AwsResourceexplorer2View#filter_string}
        */
        readonly filterString: string;
    }
    class FiltersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FiltersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FiltersProperty | cdktn.IResolvable | undefined);
        private _filterString?;
        get filterString(): string;
        set filterString(value: string);
        get filterStringInput(): string | undefined;
    }
    class FiltersPropertyList extends cdktn.ComplexList {
        internalValue?: FiltersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FiltersPropertyOutputReference;
    }
    interface IncludedPropertyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/resourceexplorer2_view#name AwsResourceexplorer2View#name}
        */
        readonly name: string;
    }
    class IncludedPropertyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IncludedPropertyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IncludedPropertyProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    class IncludedPropertyPropertyList extends cdktn.ComplexList {
        internalValue?: IncludedPropertyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IncludedPropertyPropertyOutputReference;
    }
}
