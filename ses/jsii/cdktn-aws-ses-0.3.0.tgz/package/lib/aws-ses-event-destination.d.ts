import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsEventDestinationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_event_destination#configuration_set_name AwsEventDestination#configuration_set_name}
    */
    readonly configurationSetName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_event_destination#enabled AwsEventDestination#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_event_destination#id AwsEventDestination#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_event_destination#matching_types AwsEventDestination#matching_types}
    */
    readonly matchingTypes: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_event_destination#name AwsEventDestination#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_event_destination#region AwsEventDestination#region}
    */
    readonly region?: string;
    /**
    * cloudwatch_destination block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_event_destination#cloudwatch_destination AwsEventDestination#cloudwatch_destination}
    */
    readonly cloudwatchDestination?: AwsEventDestination.CloudwatchDestinationProperty[] | cdktn.IResolvable;
    /**
    * kinesis_destination block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_event_destination#kinesis_destination AwsEventDestination#kinesis_destination}
    */
    readonly kinesisDestination?: AwsEventDestination.KinesisDestinationProperty;
    /**
    * sns_destination block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_event_destination#sns_destination AwsEventDestination#sns_destination}
    */
    readonly snsDestination?: AwsEventDestination.SnsDestinationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_event_destination aws_ses_event_destination}
*/
export declare class AwsEventDestination extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ses_event_destination";
    /**
    * Generates CDKTN code for importing a AwsEventDestination resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsEventDestination to import
    * @param importFromId The id of the existing AwsEventDestination that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_event_destination#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsEventDestination to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_event_destination aws_ses_event_destination} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsEventDestinationConfig
    */
    constructor(scope: Construct, id: string, config: AwsEventDestinationConfig);
    get arn(): string;
    private _configurationSetName?;
    get configurationSetName(): string;
    set configurationSetName(value: string);
    get configurationSetNameInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _matchingTypes?;
    get matchingTypes(): string[];
    set matchingTypes(value: string[]);
    get matchingTypesInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _cloudwatchDestination;
    get cloudwatchDestination(): AwsEventDestination.CloudwatchDestinationPropertyList;
    putCloudwatchDestination(value: AwsEventDestination.CloudwatchDestinationProperty[] | cdktn.IResolvable): void;
    resetCloudwatchDestination(): void;
    get cloudwatchDestinationInput(): cdktn.IResolvable | AwsEventDestination.CloudwatchDestinationProperty[] | undefined;
    private _kinesisDestination;
    get kinesisDestination(): AwsEventDestination.KinesisDestinationPropertyOutputReference;
    putKinesisDestination(value: AwsEventDestination.KinesisDestinationProperty): void;
    resetKinesisDestination(): void;
    get kinesisDestinationInput(): AwsEventDestination.KinesisDestinationProperty | undefined;
    private _snsDestination;
    get snsDestination(): AwsEventDestination.SnsDestinationPropertyOutputReference;
    putSnsDestination(value: AwsEventDestination.SnsDestinationProperty): void;
    resetSnsDestination(): void;
    get snsDestinationInput(): AwsEventDestination.SnsDestinationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsEventDestinationCloudwatchDestinationPropertyToTerraform(struct?: AwsEventDestination.CloudwatchDestinationProperty | cdktn.IResolvable): any;
export declare function awsEventDestinationCloudwatchDestinationPropertyToHclTerraform(struct?: AwsEventDestination.CloudwatchDestinationProperty | cdktn.IResolvable): any;
export declare function awsEventDestinationKinesisDestinationPropertyToTerraform(struct?: AwsEventDestination.KinesisDestinationPropertyOutputReference | AwsEventDestination.KinesisDestinationProperty): any;
export declare function awsEventDestinationKinesisDestinationPropertyToHclTerraform(struct?: AwsEventDestination.KinesisDestinationPropertyOutputReference | AwsEventDestination.KinesisDestinationProperty): any;
export declare function awsEventDestinationSnsDestinationPropertyToTerraform(struct?: AwsEventDestination.SnsDestinationPropertyOutputReference | AwsEventDestination.SnsDestinationProperty): any;
export declare function awsEventDestinationSnsDestinationPropertyToHclTerraform(struct?: AwsEventDestination.SnsDestinationPropertyOutputReference | AwsEventDestination.SnsDestinationProperty): any;
export declare namespace AwsEventDestination {
    interface CloudwatchDestinationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_event_destination#default_value AwsEventDestination#default_value}
        */
        readonly defaultValue: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_event_destination#dimension_name AwsEventDestination#dimension_name}
        */
        readonly dimensionName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_event_destination#value_source AwsEventDestination#value_source}
        */
        readonly valueSource: string;
    }
    class CloudwatchDestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CloudwatchDestinationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CloudwatchDestinationProperty | cdktn.IResolvable | undefined);
        private _defaultValue?;
        get defaultValue(): string;
        set defaultValue(value: string);
        get defaultValueInput(): string | undefined;
        private _dimensionName?;
        get dimensionName(): string;
        set dimensionName(value: string);
        get dimensionNameInput(): string | undefined;
        private _valueSource?;
        get valueSource(): string;
        set valueSource(value: string);
        get valueSourceInput(): string | undefined;
    }
    class CloudwatchDestinationPropertyList extends cdktn.ComplexList {
        internalValue?: CloudwatchDestinationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CloudwatchDestinationPropertyOutputReference;
    }
    interface KinesisDestinationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_event_destination#role_arn AwsEventDestination#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_event_destination#stream_arn AwsEventDestination#stream_arn}
        */
        readonly streamArn: string;
    }
    class KinesisDestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KinesisDestinationProperty | undefined;
        set internalValue(value: KinesisDestinationProperty | undefined);
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _streamArn?;
        get streamArn(): string;
        set streamArn(value: string);
        get streamArnInput(): string | undefined;
    }
    interface SnsDestinationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_event_destination#topic_arn AwsEventDestination#topic_arn}
        */
        readonly topicArn: string;
    }
    class SnsDestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SnsDestinationProperty | undefined;
        set internalValue(value: SnsDestinationProperty | undefined);
        private _topicArn?;
        get topicArn(): string;
        set topicArn(value: string);
        get topicArnInput(): string | undefined;
    }
}
