import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsReceiptRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#after AwsReceiptRule#after}
    */
    readonly after?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#enabled AwsReceiptRule#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#id AwsReceiptRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#name AwsReceiptRule#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#recipients AwsReceiptRule#recipients}
    */
    readonly recipients?: string[];
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#region AwsReceiptRule#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#rule_set_name AwsReceiptRule#rule_set_name}
    */
    readonly ruleSetName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#scan_enabled AwsReceiptRule#scan_enabled}
    */
    readonly scanEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#tls_policy AwsReceiptRule#tls_policy}
    */
    readonly tlsPolicy?: string;
    /**
    * add_header_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#add_header_action AwsReceiptRule#add_header_action}
    */
    readonly addHeaderAction?: AwsReceiptRule.AddHeaderActionProperty[] | cdktn.IResolvable;
    /**
    * bounce_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#bounce_action AwsReceiptRule#bounce_action}
    */
    readonly bounceAction?: AwsReceiptRule.BounceActionProperty[] | cdktn.IResolvable;
    /**
    * lambda_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#lambda_action AwsReceiptRule#lambda_action}
    */
    readonly lambdaAction?: AwsReceiptRule.LambdaActionProperty[] | cdktn.IResolvable;
    /**
    * s3_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#s3_action AwsReceiptRule#s3_action}
    */
    readonly s3Action?: AwsReceiptRule.S3ActionProperty[] | cdktn.IResolvable;
    /**
    * sns_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#sns_action AwsReceiptRule#sns_action}
    */
    readonly snsAction?: AwsReceiptRule.SnsActionProperty[] | cdktn.IResolvable;
    /**
    * stop_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#stop_action AwsReceiptRule#stop_action}
    */
    readonly stopAction?: AwsReceiptRule.StopActionProperty[] | cdktn.IResolvable;
    /**
    * workmail_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#workmail_action AwsReceiptRule#workmail_action}
    */
    readonly workmailAction?: AwsReceiptRule.WorkmailActionProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule aws_ses_receipt_rule}
*/
export declare class AwsReceiptRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ses_receipt_rule";
    /**
    * Generates CDKTN code for importing a AwsReceiptRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsReceiptRule to import
    * @param importFromId The id of the existing AwsReceiptRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsReceiptRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule aws_ses_receipt_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsReceiptRuleConfig
    */
    constructor(scope: Construct, id: string, config: AwsReceiptRuleConfig);
    private _after?;
    get after(): string;
    set after(value: string);
    resetAfter(): void;
    get afterInput(): string | undefined;
    get arn(): string;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _recipients?;
    get recipients(): string[];
    set recipients(value: string[]);
    resetRecipients(): void;
    get recipientsInput(): string[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _ruleSetName?;
    get ruleSetName(): string;
    set ruleSetName(value: string);
    get ruleSetNameInput(): string | undefined;
    private _scanEnabled?;
    get scanEnabled(): boolean | cdktn.IResolvable;
    set scanEnabled(value: boolean | cdktn.IResolvable);
    resetScanEnabled(): void;
    get scanEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _tlsPolicy?;
    get tlsPolicy(): string;
    set tlsPolicy(value: string);
    resetTlsPolicy(): void;
    get tlsPolicyInput(): string | undefined;
    private _addHeaderAction;
    get addHeaderAction(): AwsReceiptRule.AddHeaderActionPropertyList;
    putAddHeaderAction(value: AwsReceiptRule.AddHeaderActionProperty[] | cdktn.IResolvable): void;
    resetAddHeaderAction(): void;
    get addHeaderActionInput(): cdktn.IResolvable | AwsReceiptRule.AddHeaderActionProperty[] | undefined;
    private _bounceAction;
    get bounceAction(): AwsReceiptRule.BounceActionPropertyList;
    putBounceAction(value: AwsReceiptRule.BounceActionProperty[] | cdktn.IResolvable): void;
    resetBounceAction(): void;
    get bounceActionInput(): cdktn.IResolvable | AwsReceiptRule.BounceActionProperty[] | undefined;
    private _lambdaAction;
    get lambdaAction(): AwsReceiptRule.LambdaActionPropertyList;
    putLambdaAction(value: AwsReceiptRule.LambdaActionProperty[] | cdktn.IResolvable): void;
    resetLambdaAction(): void;
    get lambdaActionInput(): cdktn.IResolvable | AwsReceiptRule.LambdaActionProperty[] | undefined;
    private _s3Action;
    get s3Action(): AwsReceiptRule.S3ActionPropertyList;
    putS3Action(value: AwsReceiptRule.S3ActionProperty[] | cdktn.IResolvable): void;
    resetS3Action(): void;
    get s3ActionInput(): cdktn.IResolvable | AwsReceiptRule.S3ActionProperty[] | undefined;
    private _snsAction;
    get snsAction(): AwsReceiptRule.SnsActionPropertyList;
    putSnsAction(value: AwsReceiptRule.SnsActionProperty[] | cdktn.IResolvable): void;
    resetSnsAction(): void;
    get snsActionInput(): cdktn.IResolvable | AwsReceiptRule.SnsActionProperty[] | undefined;
    private _stopAction;
    get stopAction(): AwsReceiptRule.StopActionPropertyList;
    putStopAction(value: AwsReceiptRule.StopActionProperty[] | cdktn.IResolvable): void;
    resetStopAction(): void;
    get stopActionInput(): cdktn.IResolvable | AwsReceiptRule.StopActionProperty[] | undefined;
    private _workmailAction;
    get workmailAction(): AwsReceiptRule.WorkmailActionPropertyList;
    putWorkmailAction(value: AwsReceiptRule.WorkmailActionProperty[] | cdktn.IResolvable): void;
    resetWorkmailAction(): void;
    get workmailActionInput(): cdktn.IResolvable | AwsReceiptRule.WorkmailActionProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsReceiptRuleAddHeaderActionPropertyToTerraform(struct?: AwsReceiptRule.AddHeaderActionProperty | cdktn.IResolvable): any;
export declare function awsReceiptRuleAddHeaderActionPropertyToHclTerraform(struct?: AwsReceiptRule.AddHeaderActionProperty | cdktn.IResolvable): any;
export declare function awsReceiptRuleBounceActionPropertyToTerraform(struct?: AwsReceiptRule.BounceActionProperty | cdktn.IResolvable): any;
export declare function awsReceiptRuleBounceActionPropertyToHclTerraform(struct?: AwsReceiptRule.BounceActionProperty | cdktn.IResolvable): any;
export declare function awsReceiptRuleLambdaActionPropertyToTerraform(struct?: AwsReceiptRule.LambdaActionProperty | cdktn.IResolvable): any;
export declare function awsReceiptRuleLambdaActionPropertyToHclTerraform(struct?: AwsReceiptRule.LambdaActionProperty | cdktn.IResolvable): any;
export declare function awsReceiptRuleS3ActionPropertyToTerraform(struct?: AwsReceiptRule.S3ActionProperty | cdktn.IResolvable): any;
export declare function awsReceiptRuleS3ActionPropertyToHclTerraform(struct?: AwsReceiptRule.S3ActionProperty | cdktn.IResolvable): any;
export declare function awsReceiptRuleSnsActionPropertyToTerraform(struct?: AwsReceiptRule.SnsActionProperty | cdktn.IResolvable): any;
export declare function awsReceiptRuleSnsActionPropertyToHclTerraform(struct?: AwsReceiptRule.SnsActionProperty | cdktn.IResolvable): any;
export declare function awsReceiptRuleStopActionPropertyToTerraform(struct?: AwsReceiptRule.StopActionProperty | cdktn.IResolvable): any;
export declare function awsReceiptRuleStopActionPropertyToHclTerraform(struct?: AwsReceiptRule.StopActionProperty | cdktn.IResolvable): any;
export declare function awsReceiptRuleWorkmailActionPropertyToTerraform(struct?: AwsReceiptRule.WorkmailActionProperty | cdktn.IResolvable): any;
export declare function awsReceiptRuleWorkmailActionPropertyToHclTerraform(struct?: AwsReceiptRule.WorkmailActionProperty | cdktn.IResolvable): any;
export declare namespace AwsReceiptRule {
    interface AddHeaderActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#header_name AwsReceiptRule#header_name}
        */
        readonly headerName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#header_value AwsReceiptRule#header_value}
        */
        readonly headerValue: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#position AwsReceiptRule#position}
        */
        readonly position: number;
    }
    class AddHeaderActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AddHeaderActionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AddHeaderActionProperty | cdktn.IResolvable | undefined);
        private _headerName?;
        get headerName(): string;
        set headerName(value: string);
        get headerNameInput(): string | undefined;
        private _headerValue?;
        get headerValue(): string;
        set headerValue(value: string);
        get headerValueInput(): string | undefined;
        private _position?;
        get position(): number;
        set position(value: number);
        get positionInput(): number | undefined;
    }
    class AddHeaderActionPropertyList extends cdktn.ComplexList {
        internalValue?: AddHeaderActionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AddHeaderActionPropertyOutputReference;
    }
    interface BounceActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#message AwsReceiptRule#message}
        */
        readonly message: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#position AwsReceiptRule#position}
        */
        readonly position: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#sender AwsReceiptRule#sender}
        */
        readonly sender: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#smtp_reply_code AwsReceiptRule#smtp_reply_code}
        */
        readonly smtpReplyCode: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#status_code AwsReceiptRule#status_code}
        */
        readonly statusCode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#topic_arn AwsReceiptRule#topic_arn}
        */
        readonly topicArn?: string;
    }
    class BounceActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BounceActionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: BounceActionProperty | cdktn.IResolvable | undefined);
        private _message?;
        get message(): string;
        set message(value: string);
        get messageInput(): string | undefined;
        private _position?;
        get position(): number;
        set position(value: number);
        get positionInput(): number | undefined;
        private _sender?;
        get sender(): string;
        set sender(value: string);
        get senderInput(): string | undefined;
        private _smtpReplyCode?;
        get smtpReplyCode(): string;
        set smtpReplyCode(value: string);
        get smtpReplyCodeInput(): string | undefined;
        private _statusCode?;
        get statusCode(): string;
        set statusCode(value: string);
        resetStatusCode(): void;
        get statusCodeInput(): string | undefined;
        private _topicArn?;
        get topicArn(): string;
        set topicArn(value: string);
        resetTopicArn(): void;
        get topicArnInput(): string | undefined;
    }
    class BounceActionPropertyList extends cdktn.ComplexList {
        internalValue?: BounceActionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BounceActionPropertyOutputReference;
    }
    interface LambdaActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#function_arn AwsReceiptRule#function_arn}
        */
        readonly functionArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#invocation_type AwsReceiptRule#invocation_type}
        */
        readonly invocationType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#position AwsReceiptRule#position}
        */
        readonly position: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#topic_arn AwsReceiptRule#topic_arn}
        */
        readonly topicArn?: string;
    }
    class LambdaActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LambdaActionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LambdaActionProperty | cdktn.IResolvable | undefined);
        private _functionArn?;
        get functionArn(): string;
        set functionArn(value: string);
        get functionArnInput(): string | undefined;
        private _invocationType?;
        get invocationType(): string;
        set invocationType(value: string);
        resetInvocationType(): void;
        get invocationTypeInput(): string | undefined;
        private _position?;
        get position(): number;
        set position(value: number);
        get positionInput(): number | undefined;
        private _topicArn?;
        get topicArn(): string;
        set topicArn(value: string);
        resetTopicArn(): void;
        get topicArnInput(): string | undefined;
    }
    class LambdaActionPropertyList extends cdktn.ComplexList {
        internalValue?: LambdaActionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LambdaActionPropertyOutputReference;
    }
    interface S3ActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#bucket_name AwsReceiptRule#bucket_name}
        */
        readonly bucketName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#iam_role_arn AwsReceiptRule#iam_role_arn}
        */
        readonly iamRoleArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#kms_key_arn AwsReceiptRule#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#object_key_prefix AwsReceiptRule#object_key_prefix}
        */
        readonly objectKeyPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#position AwsReceiptRule#position}
        */
        readonly position: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#topic_arn AwsReceiptRule#topic_arn}
        */
        readonly topicArn?: string;
    }
    class S3ActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3ActionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3ActionProperty | cdktn.IResolvable | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        get bucketNameInput(): string | undefined;
        private _iamRoleArn?;
        get iamRoleArn(): string;
        set iamRoleArn(value: string);
        resetIamRoleArn(): void;
        get iamRoleArnInput(): string | undefined;
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
        private _objectKeyPrefix?;
        get objectKeyPrefix(): string;
        set objectKeyPrefix(value: string);
        resetObjectKeyPrefix(): void;
        get objectKeyPrefixInput(): string | undefined;
        private _position?;
        get position(): number;
        set position(value: number);
        get positionInput(): number | undefined;
        private _topicArn?;
        get topicArn(): string;
        set topicArn(value: string);
        resetTopicArn(): void;
        get topicArnInput(): string | undefined;
    }
    class S3ActionPropertyList extends cdktn.ComplexList {
        internalValue?: S3ActionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3ActionPropertyOutputReference;
    }
    interface SnsActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#encoding AwsReceiptRule#encoding}
        */
        readonly encoding?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#position AwsReceiptRule#position}
        */
        readonly position: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#topic_arn AwsReceiptRule#topic_arn}
        */
        readonly topicArn: string;
    }
    class SnsActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SnsActionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SnsActionProperty | cdktn.IResolvable | undefined);
        private _encoding?;
        get encoding(): string;
        set encoding(value: string);
        resetEncoding(): void;
        get encodingInput(): string | undefined;
        private _position?;
        get position(): number;
        set position(value: number);
        get positionInput(): number | undefined;
        private _topicArn?;
        get topicArn(): string;
        set topicArn(value: string);
        get topicArnInput(): string | undefined;
    }
    class SnsActionPropertyList extends cdktn.ComplexList {
        internalValue?: SnsActionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SnsActionPropertyOutputReference;
    }
    interface StopActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#position AwsReceiptRule#position}
        */
        readonly position: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#scope AwsReceiptRule#scope}
        */
        readonly scope: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#topic_arn AwsReceiptRule#topic_arn}
        */
        readonly topicArn?: string;
    }
    class StopActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StopActionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StopActionProperty | cdktn.IResolvable | undefined);
        private _position?;
        get position(): number;
        set position(value: number);
        get positionInput(): number | undefined;
        private _scope?;
        get scope(): string;
        set scope(value: string);
        get scopeInput(): string | undefined;
        private _topicArn?;
        get topicArn(): string;
        set topicArn(value: string);
        resetTopicArn(): void;
        get topicArnInput(): string | undefined;
    }
    class StopActionPropertyList extends cdktn.ComplexList {
        internalValue?: StopActionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StopActionPropertyOutputReference;
    }
    interface WorkmailActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#organization_arn AwsReceiptRule#organization_arn}
        */
        readonly organizationArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#position AwsReceiptRule#position}
        */
        readonly position: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ses_receipt_rule#topic_arn AwsReceiptRule#topic_arn}
        */
        readonly topicArn?: string;
    }
    class WorkmailActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WorkmailActionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: WorkmailActionProperty | cdktn.IResolvable | undefined);
        private _organizationArn?;
        get organizationArn(): string;
        set organizationArn(value: string);
        get organizationArnInput(): string | undefined;
        private _position?;
        get position(): number;
        set position(value: number);
        get positionInput(): number | undefined;
        private _topicArn?;
        get topicArn(): string;
        set topicArn(value: string);
        resetTopicArn(): void;
        get topicArnInput(): string | undefined;
    }
    class WorkmailActionPropertyList extends cdktn.ComplexList {
        internalValue?: WorkmailActionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WorkmailActionPropertyOutputReference;
    }
}
