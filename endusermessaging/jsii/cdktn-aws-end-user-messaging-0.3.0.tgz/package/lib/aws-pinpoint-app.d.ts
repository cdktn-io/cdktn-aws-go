import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAppConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpoint_app#id AwsApp#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpoint_app#name AwsApp#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpoint_app#name_prefix AwsApp#name_prefix}
    */
    readonly namePrefix?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpoint_app#region AwsApp#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpoint_app#tags AwsApp#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpoint_app#tags_all AwsApp#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * campaign_hook block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpoint_app#campaign_hook AwsApp#campaign_hook}
    */
    readonly campaignHook?: AwsApp.CampaignHookProperty;
    /**
    * limits block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpoint_app#limits AwsApp#limits}
    */
    readonly limits?: AwsApp.LimitsProperty;
    /**
    * quiet_time block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpoint_app#quiet_time AwsApp#quiet_time}
    */
    readonly quietTime?: AwsApp.QuietTimeProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpoint_app aws_pinpoint_app}
*/
export declare class AwsApp extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_pinpoint_app";
    /**
    * Generates CDKTN code for importing a AwsApp resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsApp to import
    * @param importFromId The id of the existing AwsApp that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpoint_app#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsApp to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpoint_app aws_pinpoint_app} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAppConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsAppConfig);
    get applicationId(): string;
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namePrefix?;
    get namePrefix(): string;
    set namePrefix(value: string);
    resetNamePrefix(): void;
    get namePrefixInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _campaignHook;
    get campaignHook(): AwsApp.CampaignHookPropertyOutputReference;
    putCampaignHook(value: AwsApp.CampaignHookProperty): void;
    resetCampaignHook(): void;
    get campaignHookInput(): AwsApp.CampaignHookProperty | undefined;
    private _limits;
    get limits(): AwsApp.LimitsPropertyOutputReference;
    putLimits(value: AwsApp.LimitsProperty): void;
    resetLimits(): void;
    get limitsInput(): AwsApp.LimitsProperty | undefined;
    private _quietTime;
    get quietTime(): AwsApp.QuietTimePropertyOutputReference;
    putQuietTime(value: AwsApp.QuietTimeProperty): void;
    resetQuietTime(): void;
    get quietTimeInput(): AwsApp.QuietTimeProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsAppCampaignHookPropertyToTerraform(struct?: AwsApp.CampaignHookPropertyOutputReference | AwsApp.CampaignHookProperty): any;
export declare function awsAppCampaignHookPropertyToHclTerraform(struct?: AwsApp.CampaignHookPropertyOutputReference | AwsApp.CampaignHookProperty): any;
export declare function awsAppLimitsPropertyToTerraform(struct?: AwsApp.LimitsPropertyOutputReference | AwsApp.LimitsProperty): any;
export declare function awsAppLimitsPropertyToHclTerraform(struct?: AwsApp.LimitsPropertyOutputReference | AwsApp.LimitsProperty): any;
export declare function awsAppQuietTimePropertyToTerraform(struct?: AwsApp.QuietTimePropertyOutputReference | AwsApp.QuietTimeProperty): any;
export declare function awsAppQuietTimePropertyToHclTerraform(struct?: AwsApp.QuietTimePropertyOutputReference | AwsApp.QuietTimeProperty): any;
export declare namespace AwsApp {
    interface CampaignHookProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpoint_app#lambda_function_name AwsApp#lambda_function_name}
        */
        readonly lambdaFunctionName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpoint_app#mode AwsApp#mode}
        */
        readonly mode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpoint_app#web_url AwsApp#web_url}
        */
        readonly webUrl?: string;
    }
    class CampaignHookPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CampaignHookProperty | undefined;
        set internalValue(value: CampaignHookProperty | undefined);
        private _lambdaFunctionName?;
        get lambdaFunctionName(): string;
        set lambdaFunctionName(value: string);
        resetLambdaFunctionName(): void;
        get lambdaFunctionNameInput(): string | undefined;
        private _mode?;
        get mode(): string;
        set mode(value: string);
        resetMode(): void;
        get modeInput(): string | undefined;
        private _webUrl?;
        get webUrl(): string;
        set webUrl(value: string);
        resetWebUrl(): void;
        get webUrlInput(): string | undefined;
    }
    interface LimitsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpoint_app#daily AwsApp#daily}
        */
        readonly daily?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpoint_app#maximum_duration AwsApp#maximum_duration}
        */
        readonly maximumDuration?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpoint_app#messages_per_second AwsApp#messages_per_second}
        */
        readonly messagesPerSecond?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpoint_app#total AwsApp#total}
        */
        readonly total?: number;
    }
    class LimitsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LimitsProperty | undefined;
        set internalValue(value: LimitsProperty | undefined);
        private _daily?;
        get daily(): number;
        set daily(value: number);
        resetDaily(): void;
        get dailyInput(): number | undefined;
        private _maximumDuration?;
        get maximumDuration(): number;
        set maximumDuration(value: number);
        resetMaximumDuration(): void;
        get maximumDurationInput(): number | undefined;
        private _messagesPerSecond?;
        get messagesPerSecond(): number;
        set messagesPerSecond(value: number);
        resetMessagesPerSecond(): void;
        get messagesPerSecondInput(): number | undefined;
        private _total?;
        get total(): number;
        set total(value: number);
        resetTotal(): void;
        get totalInput(): number | undefined;
    }
    interface QuietTimeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpoint_app#end AwsApp#end}
        */
        readonly end?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/pinpoint_app#start AwsApp#start}
        */
        readonly start?: string;
    }
    class QuietTimePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): QuietTimeProperty | undefined;
        set internalValue(value: QuietTimeProperty | undefined);
        private _end?;
        get end(): string;
        set end(value: string);
        resetEnd(): void;
        get endInput(): string | undefined;
        private _start?;
        get start(): string;
        set start(value: string);
        resetStart(): void;
        get startInput(): string | undefined;
    }
}
