export * from './data-aws-resourcegroupstaggingapi-required-tags';
export * from './data-aws-resourcegroupstaggingapi-resources';
