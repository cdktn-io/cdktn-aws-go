import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsRegionsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/account_regions#account_id DataAwsRegions#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/account_regions#region_opt_status_contains DataAwsRegions#region_opt_status_contains}
    */
    readonly regionOptStatusContains?: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/account_regions aws_account_regions}
*/
export declare class DataAwsRegions extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_account_regions";
    /**
    * Generates CDKTN code for importing a DataAwsRegions resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsRegions to import
    * @param importFromId The id of the existing DataAwsRegions that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/account_regions#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsRegions to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/account_regions aws_account_regions} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsRegionsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsRegionsConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    private _regionOptStatusContains?;
    get regionOptStatusContains(): string[];
    set regionOptStatusContains(value: string[]);
    resetRegionOptStatusContains(): void;
    get regionOptStatusContainsInput(): string[] | undefined;
    private _regions;
    get regions(): DataAwsRegions.RegionsPropertyList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsRegionsRegionsPropertyToTerraform(struct?: DataAwsRegions.RegionsProperty): any;
export declare function dataAwsRegionsRegionsPropertyToHclTerraform(struct?: DataAwsRegions.RegionsProperty): any;
export declare namespace DataAwsRegions {
    interface RegionsProperty {
    }
    class RegionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RegionsProperty | undefined;
        set internalValue(value: RegionsProperty | undefined);
        get regionName(): string;
        get regionOptStatus(): string;
    }
    class RegionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RegionsPropertyOutputReference;
    }
}
