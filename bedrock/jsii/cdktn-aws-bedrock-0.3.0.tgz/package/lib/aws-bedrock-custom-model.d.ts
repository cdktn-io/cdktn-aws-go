import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsCustomModelConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#base_model_identifier AwsCustomModel#base_model_identifier}
    */
    readonly baseModelIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#custom_model_kms_key_id AwsCustomModel#custom_model_kms_key_id}
    */
    readonly customModelKmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#custom_model_name AwsCustomModel#custom_model_name}
    */
    readonly customModelName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#customization_type AwsCustomModel#customization_type}
    */
    readonly customizationType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#hyperparameters AwsCustomModel#hyperparameters}
    */
    readonly hyperparameters: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#job_name AwsCustomModel#job_name}
    */
    readonly jobName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#region AwsCustomModel#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#role_arn AwsCustomModel#role_arn}
    */
    readonly roleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#tags AwsCustomModel#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * output_data_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#output_data_config AwsCustomModel#output_data_config}
    */
    readonly outputDataConfig?: AwsCustomModel.OutputDataConfigProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#timeouts AwsCustomModel#timeouts}
    */
    readonly timeouts?: AwsCustomModel.TimeoutsProperty;
    /**
    * training_data_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#training_data_config AwsCustomModel#training_data_config}
    */
    readonly trainingDataConfig?: AwsCustomModel.TrainingDataConfigProperty[] | cdktn.IResolvable;
    /**
    * validation_data_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#validation_data_config AwsCustomModel#validation_data_config}
    */
    readonly validationDataConfig?: AwsCustomModel.ValidationDataConfigProperty[] | cdktn.IResolvable;
    /**
    * vpc_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#vpc_config AwsCustomModel#vpc_config}
    */
    readonly vpcConfig?: AwsCustomModel.VpcConfigProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model aws_bedrock_custom_model}
*/
export declare class AwsCustomModel extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrock_custom_model";
    /**
    * Generates CDKTN code for importing a AwsCustomModel resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCustomModel to import
    * @param importFromId The id of the existing AwsCustomModel that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCustomModel to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model aws_bedrock_custom_model} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsCustomModelConfig
    */
    constructor(scope: Construct, id: string, config: AwsCustomModelConfig);
    private _baseModelIdentifier?;
    get baseModelIdentifier(): string;
    set baseModelIdentifier(value: string);
    get baseModelIdentifierInput(): string | undefined;
    get customModelArn(): string;
    private _customModelKmsKeyId?;
    get customModelKmsKeyId(): string;
    set customModelKmsKeyId(value: string);
    resetCustomModelKmsKeyId(): void;
    get customModelKmsKeyIdInput(): string | undefined;
    private _customModelName?;
    get customModelName(): string;
    set customModelName(value: string);
    get customModelNameInput(): string | undefined;
    private _customizationType?;
    get customizationType(): string;
    set customizationType(value: string);
    resetCustomizationType(): void;
    get customizationTypeInput(): string | undefined;
    private _hyperparameters?;
    get hyperparameters(): {
        [key: string]: string;
    };
    set hyperparameters(value: {
        [key: string]: string;
    });
    get hyperparametersInput(): {
        [key: string]: string;
    } | undefined;
    get id(): string;
    get jobArn(): string;
    private _jobName?;
    get jobName(): string;
    set jobName(value: string);
    get jobNameInput(): string | undefined;
    get jobStatus(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    get roleArnInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _trainingMetrics;
    get trainingMetrics(): AwsCustomModel.TrainingMetricsPropertyList;
    private _validationMetrics;
    get validationMetrics(): AwsCustomModel.ValidationMetricsPropertyList;
    private _outputDataConfig;
    get outputDataConfig(): AwsCustomModel.OutputDataConfigPropertyList;
    putOutputDataConfig(value: AwsCustomModel.OutputDataConfigProperty[] | cdktn.IResolvable): void;
    resetOutputDataConfig(): void;
    get outputDataConfigInput(): cdktn.IResolvable | AwsCustomModel.OutputDataConfigProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsCustomModel.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsCustomModel.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsCustomModel.TimeoutsProperty | undefined;
    private _trainingDataConfig;
    get trainingDataConfig(): AwsCustomModel.TrainingDataConfigPropertyList;
    putTrainingDataConfig(value: AwsCustomModel.TrainingDataConfigProperty[] | cdktn.IResolvable): void;
    resetTrainingDataConfig(): void;
    get trainingDataConfigInput(): cdktn.IResolvable | AwsCustomModel.TrainingDataConfigProperty[] | undefined;
    private _validationDataConfig;
    get validationDataConfig(): AwsCustomModel.ValidationDataConfigPropertyList;
    putValidationDataConfig(value: AwsCustomModel.ValidationDataConfigProperty[] | cdktn.IResolvable): void;
    resetValidationDataConfig(): void;
    get validationDataConfigInput(): cdktn.IResolvable | AwsCustomModel.ValidationDataConfigProperty[] | undefined;
    private _vpcConfig;
    get vpcConfig(): AwsCustomModel.VpcConfigPropertyList;
    putVpcConfig(value: AwsCustomModel.VpcConfigProperty[] | cdktn.IResolvable): void;
    resetVpcConfig(): void;
    get vpcConfigInput(): cdktn.IResolvable | AwsCustomModel.VpcConfigProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsCustomModelTrainingMetricsPropertyToTerraform(struct?: AwsCustomModel.TrainingMetricsProperty): any;
export declare function awsCustomModelTrainingMetricsPropertyToHclTerraform(struct?: AwsCustomModel.TrainingMetricsProperty): any;
export declare function awsCustomModelValidationMetricsPropertyToTerraform(struct?: AwsCustomModel.ValidationMetricsProperty): any;
export declare function awsCustomModelValidationMetricsPropertyToHclTerraform(struct?: AwsCustomModel.ValidationMetricsProperty): any;
export declare function awsCustomModelOutputDataConfigPropertyToTerraform(struct?: AwsCustomModel.OutputDataConfigProperty | cdktn.IResolvable): any;
export declare function awsCustomModelOutputDataConfigPropertyToHclTerraform(struct?: AwsCustomModel.OutputDataConfigProperty | cdktn.IResolvable): any;
export declare function awsCustomModelTimeoutsPropertyToTerraform(struct?: AwsCustomModel.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsCustomModelTimeoutsPropertyToHclTerraform(struct?: AwsCustomModel.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsCustomModelTrainingDataConfigPropertyToTerraform(struct?: AwsCustomModel.TrainingDataConfigProperty | cdktn.IResolvable): any;
export declare function awsCustomModelTrainingDataConfigPropertyToHclTerraform(struct?: AwsCustomModel.TrainingDataConfigProperty | cdktn.IResolvable): any;
export declare function awsCustomModelValidatorPropertyToTerraform(struct?: AwsCustomModel.ValidatorProperty | cdktn.IResolvable): any;
export declare function awsCustomModelValidatorPropertyToHclTerraform(struct?: AwsCustomModel.ValidatorProperty | cdktn.IResolvable): any;
export declare function awsCustomModelValidationDataConfigPropertyToTerraform(struct?: AwsCustomModel.ValidationDataConfigProperty | cdktn.IResolvable): any;
export declare function awsCustomModelValidationDataConfigPropertyToHclTerraform(struct?: AwsCustomModel.ValidationDataConfigProperty | cdktn.IResolvable): any;
export declare function awsCustomModelVpcConfigPropertyToTerraform(struct?: AwsCustomModel.VpcConfigProperty | cdktn.IResolvable): any;
export declare function awsCustomModelVpcConfigPropertyToHclTerraform(struct?: AwsCustomModel.VpcConfigProperty | cdktn.IResolvable): any;
export declare namespace AwsCustomModel {
    interface TrainingMetricsProperty {
    }
    class TrainingMetricsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingMetricsProperty | undefined;
        set internalValue(value: TrainingMetricsProperty | undefined);
        get trainingLoss(): number;
    }
    class TrainingMetricsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingMetricsPropertyOutputReference;
    }
    interface ValidationMetricsProperty {
    }
    class ValidationMetricsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ValidationMetricsProperty | undefined;
        set internalValue(value: ValidationMetricsProperty | undefined);
        get validationLoss(): number;
    }
    class ValidationMetricsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ValidationMetricsPropertyOutputReference;
    }
    interface OutputDataConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#s3_uri AwsCustomModel#s3_uri}
        */
        readonly s3Uri: string;
    }
    class OutputDataConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OutputDataConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OutputDataConfigProperty | cdktn.IResolvable | undefined);
        private _s3Uri?;
        get s3Uri(): string;
        set s3Uri(value: string);
        get s3UriInput(): string | undefined;
    }
    class OutputDataConfigPropertyList extends cdktn.ComplexList {
        internalValue?: OutputDataConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OutputDataConfigPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#create AwsCustomModel#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#delete AwsCustomModel#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
    interface TrainingDataConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#s3_uri AwsCustomModel#s3_uri}
        */
        readonly s3Uri: string;
    }
    class TrainingDataConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrainingDataConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrainingDataConfigProperty | cdktn.IResolvable | undefined);
        private _s3Uri?;
        get s3Uri(): string;
        set s3Uri(value: string);
        get s3UriInput(): string | undefined;
    }
    class TrainingDataConfigPropertyList extends cdktn.ComplexList {
        internalValue?: TrainingDataConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrainingDataConfigPropertyOutputReference;
    }
    interface ValidatorProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#s3_uri AwsCustomModel#s3_uri}
        */
        readonly s3Uri: string;
    }
    class ValidatorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ValidatorProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ValidatorProperty | cdktn.IResolvable | undefined);
        private _s3Uri?;
        get s3Uri(): string;
        set s3Uri(value: string);
        get s3UriInput(): string | undefined;
    }
    class ValidatorPropertyList extends cdktn.ComplexList {
        internalValue?: ValidatorProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ValidatorPropertyOutputReference;
    }
    interface ValidationDataConfigProperty {
        /**
        * validator block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#validator AwsCustomModel#validator}
        */
        readonly validator?: ValidatorProperty[] | cdktn.IResolvable;
    }
    class ValidationDataConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ValidationDataConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ValidationDataConfigProperty | cdktn.IResolvable | undefined);
        private _validator;
        get validator(): ValidatorPropertyList;
        putValidator(value: ValidatorProperty[] | cdktn.IResolvable): void;
        resetValidator(): void;
        get validatorInput(): cdktn.IResolvable | ValidatorProperty[] | undefined;
    }
    class ValidationDataConfigPropertyList extends cdktn.ComplexList {
        internalValue?: ValidationDataConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ValidationDataConfigPropertyOutputReference;
    }
    interface VpcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#security_group_ids AwsCustomModel#security_group_ids}
        */
        readonly securityGroupIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_custom_model#subnet_ids AwsCustomModel#subnet_ids}
        */
        readonly subnetIds: string[];
    }
    class VpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpcConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VpcConfigProperty | cdktn.IResolvable | undefined);
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
    }
    class VpcConfigPropertyList extends cdktn.ComplexList {
        internalValue?: VpcConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpcConfigPropertyOutputReference;
    }
}
