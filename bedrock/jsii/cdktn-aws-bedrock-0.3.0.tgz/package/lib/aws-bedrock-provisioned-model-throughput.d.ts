import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsProvisionedModelThroughputConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_provisioned_model_throughput#commitment_duration AwsProvisionedModelThroughput#commitment_duration}
    */
    readonly commitmentDuration?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_provisioned_model_throughput#model_arn AwsProvisionedModelThroughput#model_arn}
    */
    readonly modelArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_provisioned_model_throughput#model_units AwsProvisionedModelThroughput#model_units}
    */
    readonly modelUnits: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_provisioned_model_throughput#provisioned_model_name AwsProvisionedModelThroughput#provisioned_model_name}
    */
    readonly provisionedModelName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_provisioned_model_throughput#region AwsProvisionedModelThroughput#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_provisioned_model_throughput#tags AwsProvisionedModelThroughput#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_provisioned_model_throughput#timeouts AwsProvisionedModelThroughput#timeouts}
    */
    readonly timeouts?: AwsProvisionedModelThroughput.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_provisioned_model_throughput aws_bedrock_provisioned_model_throughput}
*/
export declare class AwsProvisionedModelThroughput extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_bedrock_provisioned_model_throughput";
    /**
    * Generates CDKTN code for importing a AwsProvisionedModelThroughput resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsProvisionedModelThroughput to import
    * @param importFromId The id of the existing AwsProvisionedModelThroughput that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_provisioned_model_throughput#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsProvisionedModelThroughput to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_provisioned_model_throughput aws_bedrock_provisioned_model_throughput} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsProvisionedModelThroughputConfig
    */
    constructor(scope: Construct, id: string, config: AwsProvisionedModelThroughputConfig);
    private _commitmentDuration?;
    get commitmentDuration(): string;
    set commitmentDuration(value: string);
    resetCommitmentDuration(): void;
    get commitmentDurationInput(): string | undefined;
    get id(): string;
    private _modelArn?;
    get modelArn(): string;
    set modelArn(value: string);
    get modelArnInput(): string | undefined;
    private _modelUnits?;
    get modelUnits(): number;
    set modelUnits(value: number);
    get modelUnitsInput(): number | undefined;
    get provisionedModelArn(): string;
    private _provisionedModelName?;
    get provisionedModelName(): string;
    set provisionedModelName(value: string);
    get provisionedModelNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _timeouts;
    get timeouts(): AwsProvisionedModelThroughput.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsProvisionedModelThroughput.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsProvisionedModelThroughput.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsProvisionedModelThroughputTimeoutsPropertyToTerraform(struct?: AwsProvisionedModelThroughput.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsProvisionedModelThroughputTimeoutsPropertyToHclTerraform(struct?: AwsProvisionedModelThroughput.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsProvisionedModelThroughput {
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/bedrock_provisioned_model_throughput#create AwsProvisionedModelThroughput#create}
        */
        readonly create?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
    }
}
