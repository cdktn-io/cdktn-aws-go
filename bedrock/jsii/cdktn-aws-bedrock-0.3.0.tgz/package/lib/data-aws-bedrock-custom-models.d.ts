import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsCustomModelsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/bedrock_custom_models#region DataAwsCustomModels#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/bedrock_custom_models aws_bedrock_custom_models}
*/
export declare class DataAwsCustomModels extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_bedrock_custom_models";
    /**
    * Generates CDKTN code for importing a DataAwsCustomModels resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsCustomModels to import
    * @param importFromId The id of the existing DataAwsCustomModels that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/bedrock_custom_models#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsCustomModels to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/bedrock_custom_models aws_bedrock_custom_models} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsCustomModelsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsCustomModelsConfig);
    get id(): string;
    private _modelSummaries;
    get modelSummaries(): DataAwsCustomModels.ModelSummariesPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsCustomModelsModelSummariesPropertyToTerraform(struct?: DataAwsCustomModels.ModelSummariesProperty): any;
export declare function dataAwsCustomModelsModelSummariesPropertyToHclTerraform(struct?: DataAwsCustomModels.ModelSummariesProperty): any;
export declare namespace DataAwsCustomModels {
    interface ModelSummariesProperty {
    }
    class ModelSummariesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ModelSummariesProperty | undefined;
        set internalValue(value: ModelSummariesProperty | undefined);
        get creationTime(): string;
        get modelArn(): string;
        get modelName(): string;
    }
    class ModelSummariesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ModelSummariesPropertyOutputReference;
    }
}
