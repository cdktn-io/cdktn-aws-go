import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsNotificationscontactsEmailContactConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/notificationscontacts_email_contact#email_address AwsNotificationscontactsEmailContact#email_address}
    */
    readonly emailAddress: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/notificationscontacts_email_contact#name AwsNotificationscontactsEmailContact#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/notificationscontacts_email_contact#tags AwsNotificationscontactsEmailContact#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/notificationscontacts_email_contact aws_notificationscontacts_email_contact}
*/
export declare class AwsNotificationscontactsEmailContact extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_notificationscontacts_email_contact";
    /**
    * Generates CDKTN code for importing a AwsNotificationscontactsEmailContact resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsNotificationscontactsEmailContact to import
    * @param importFromId The id of the existing AwsNotificationscontactsEmailContact that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/notificationscontacts_email_contact#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsNotificationscontactsEmailContact to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/notificationscontacts_email_contact aws_notificationscontacts_email_contact} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsNotificationscontactsEmailContactConfig
    */
    constructor(scope: Construct, id: string, config: AwsNotificationscontactsEmailContactConfig);
    get arn(): string;
    private _emailAddress?;
    get emailAddress(): string;
    set emailAddress(value: string);
    get emailAddressInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
