import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsWorkspaceConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_workspace_configuration#out_of_order_time_window_in_seconds AwsWorkspaceConfiguration#out_of_order_time_window_in_seconds}
    */
    readonly outOfOrderTimeWindowInSeconds?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_workspace_configuration#region AwsWorkspaceConfiguration#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_workspace_configuration#retention_period_in_days AwsWorkspaceConfiguration#retention_period_in_days}
    */
    readonly retentionPeriodInDays?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_workspace_configuration#rule_query_offset_in_seconds AwsWorkspaceConfiguration#rule_query_offset_in_seconds}
    */
    readonly ruleQueryOffsetInSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_workspace_configuration#workspace_id AwsWorkspaceConfiguration#workspace_id}
    */
    readonly workspaceId: string;
    /**
    * limits_per_label_set block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_workspace_configuration#limits_per_label_set AwsWorkspaceConfiguration#limits_per_label_set}
    */
    readonly limitsPerLabelSet?: AwsWorkspaceConfiguration.LimitsPerLabelSetProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_workspace_configuration#timeouts AwsWorkspaceConfiguration#timeouts}
    */
    readonly timeouts?: AwsWorkspaceConfiguration.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_workspace_configuration aws_prometheus_workspace_configuration}
*/
export declare class AwsWorkspaceConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_prometheus_workspace_configuration";
    /**
    * Generates CDKTN code for importing a AwsWorkspaceConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsWorkspaceConfiguration to import
    * @param importFromId The id of the existing AwsWorkspaceConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_workspace_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsWorkspaceConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_workspace_configuration aws_prometheus_workspace_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsWorkspaceConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsWorkspaceConfigurationConfig);
    private _outOfOrderTimeWindowInSeconds?;
    get outOfOrderTimeWindowInSeconds(): number;
    set outOfOrderTimeWindowInSeconds(value: number);
    resetOutOfOrderTimeWindowInSeconds(): void;
    get outOfOrderTimeWindowInSecondsInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _retentionPeriodInDays?;
    get retentionPeriodInDays(): number;
    set retentionPeriodInDays(value: number);
    resetRetentionPeriodInDays(): void;
    get retentionPeriodInDaysInput(): number | undefined;
    private _ruleQueryOffsetInSeconds?;
    get ruleQueryOffsetInSeconds(): number;
    set ruleQueryOffsetInSeconds(value: number);
    resetRuleQueryOffsetInSeconds(): void;
    get ruleQueryOffsetInSecondsInput(): number | undefined;
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
    private _limitsPerLabelSet;
    get limitsPerLabelSet(): AwsWorkspaceConfiguration.LimitsPerLabelSetPropertyList;
    putLimitsPerLabelSet(value: AwsWorkspaceConfiguration.LimitsPerLabelSetProperty[] | cdktn.IResolvable): void;
    resetLimitsPerLabelSet(): void;
    get limitsPerLabelSetInput(): cdktn.IResolvable | AwsWorkspaceConfiguration.LimitsPerLabelSetProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsWorkspaceConfiguration.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsWorkspaceConfiguration.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsWorkspaceConfiguration.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsWorkspaceConfigurationLimitsPropertyToTerraform(struct?: AwsWorkspaceConfiguration.LimitsProperty | cdktn.IResolvable): any;
export declare function awsWorkspaceConfigurationLimitsPropertyToHclTerraform(struct?: AwsWorkspaceConfiguration.LimitsProperty | cdktn.IResolvable): any;
export declare function awsWorkspaceConfigurationLimitsPerLabelSetPropertyToTerraform(struct?: AwsWorkspaceConfiguration.LimitsPerLabelSetProperty | cdktn.IResolvable): any;
export declare function awsWorkspaceConfigurationLimitsPerLabelSetPropertyToHclTerraform(struct?: AwsWorkspaceConfiguration.LimitsPerLabelSetProperty | cdktn.IResolvable): any;
export declare function awsWorkspaceConfigurationTimeoutsPropertyToTerraform(struct?: AwsWorkspaceConfiguration.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsWorkspaceConfigurationTimeoutsPropertyToHclTerraform(struct?: AwsWorkspaceConfiguration.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsWorkspaceConfiguration {
    interface LimitsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_workspace_configuration#max_series AwsWorkspaceConfiguration#max_series}
        */
        readonly maxSeries: number;
    }
    class LimitsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LimitsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LimitsProperty | cdktn.IResolvable | undefined);
        private _maxSeries?;
        get maxSeries(): number;
        set maxSeries(value: number);
        get maxSeriesInput(): number | undefined;
    }
    class LimitsPropertyList extends cdktn.ComplexList {
        internalValue?: LimitsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LimitsPropertyOutputReference;
    }
    interface LimitsPerLabelSetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_workspace_configuration#label_set AwsWorkspaceConfiguration#label_set}
        */
        readonly labelSet: {
            [key: string]: string;
        };
        /**
        * limits block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_workspace_configuration#limits AwsWorkspaceConfiguration#limits}
        */
        readonly limits?: LimitsProperty[] | cdktn.IResolvable;
    }
    class LimitsPerLabelSetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LimitsPerLabelSetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LimitsPerLabelSetProperty | cdktn.IResolvable | undefined);
        private _labelSet?;
        get labelSet(): {
            [key: string]: string;
        };
        set labelSet(value: {
            [key: string]: string;
        });
        get labelSetInput(): {
            [key: string]: string;
        } | undefined;
        private _limits;
        get limits(): LimitsPropertyList;
        putLimits(value: LimitsProperty[] | cdktn.IResolvable): void;
        resetLimits(): void;
        get limitsInput(): cdktn.IResolvable | LimitsProperty[] | undefined;
    }
    class LimitsPerLabelSetPropertyList extends cdktn.ComplexList {
        internalValue?: LimitsPerLabelSetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LimitsPerLabelSetPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_workspace_configuration#create AwsWorkspaceConfiguration#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_workspace_configuration#update AwsWorkspaceConfiguration#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
