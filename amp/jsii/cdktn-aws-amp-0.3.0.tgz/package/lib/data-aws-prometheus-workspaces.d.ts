import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsWorkspacesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/prometheus_workspaces#alias_prefix DataAwsWorkspaces#alias_prefix}
    */
    readonly aliasPrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/prometheus_workspaces#id DataAwsWorkspaces#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/prometheus_workspaces#region DataAwsWorkspaces#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/prometheus_workspaces aws_prometheus_workspaces}
*/
export declare class DataAwsWorkspaces extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_prometheus_workspaces";
    /**
    * Generates CDKTN code for importing a DataAwsWorkspaces resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsWorkspaces to import
    * @param importFromId The id of the existing DataAwsWorkspaces that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/prometheus_workspaces#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsWorkspaces to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/prometheus_workspaces aws_prometheus_workspaces} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsWorkspacesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsWorkspacesConfig);
    private _aliasPrefix?;
    get aliasPrefix(): string;
    set aliasPrefix(value: string);
    resetAliasPrefix(): void;
    get aliasPrefixInput(): string | undefined;
    get aliases(): string[];
    get arns(): string[];
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get workspaceIds(): string[];
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
