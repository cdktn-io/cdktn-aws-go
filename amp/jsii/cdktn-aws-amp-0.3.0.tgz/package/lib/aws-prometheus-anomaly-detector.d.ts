import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAnomalyDetectorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_anomaly_detector#alias AwsAnomalyDetector#alias}
    */
    readonly alias: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_anomaly_detector#evaluation_interval_in_seconds AwsAnomalyDetector#evaluation_interval_in_seconds}
    */
    readonly evaluationIntervalInSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_anomaly_detector#labels AwsAnomalyDetector#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_anomaly_detector#region AwsAnomalyDetector#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_anomaly_detector#tags AwsAnomalyDetector#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_anomaly_detector#workspace_id AwsAnomalyDetector#workspace_id}
    */
    readonly workspaceId: string;
    /**
    * configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_anomaly_detector#configuration AwsAnomalyDetector#configuration}
    */
    readonly configuration?: AwsAnomalyDetector.ConfigurationProperty[] | cdktn.IResolvable;
    /**
    * missing_data_action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_anomaly_detector#missing_data_action AwsAnomalyDetector#missing_data_action}
    */
    readonly missingDataAction?: AwsAnomalyDetector.MissingDataActionProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_anomaly_detector#timeouts AwsAnomalyDetector#timeouts}
    */
    readonly timeouts?: AwsAnomalyDetector.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_anomaly_detector aws_prometheus_anomaly_detector}
*/
export declare class AwsAnomalyDetector extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_prometheus_anomaly_detector";
    /**
    * Generates CDKTN code for importing a AwsAnomalyDetector resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAnomalyDetector to import
    * @param importFromId The id of the existing AwsAnomalyDetector that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_anomaly_detector#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAnomalyDetector to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_anomaly_detector aws_prometheus_anomaly_detector} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAnomalyDetectorConfig
    */
    constructor(scope: Construct, id: string, config: AwsAnomalyDetectorConfig);
    private _alias?;
    get alias(): string;
    set alias(value: string);
    get aliasInput(): string | undefined;
    get arn(): string;
    get createdAt(): string;
    private _evaluationIntervalInSeconds?;
    get evaluationIntervalInSeconds(): number;
    set evaluationIntervalInSeconds(value: number);
    resetEvaluationIntervalInSeconds(): void;
    get evaluationIntervalInSecondsInput(): number | undefined;
    get id(): string;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
    private _configuration;
    get configuration(): AwsAnomalyDetector.ConfigurationPropertyList;
    putConfiguration(value: AwsAnomalyDetector.ConfigurationProperty[] | cdktn.IResolvable): void;
    resetConfiguration(): void;
    get configurationInput(): cdktn.IResolvable | AwsAnomalyDetector.ConfigurationProperty[] | undefined;
    private _missingDataAction;
    get missingDataAction(): AwsAnomalyDetector.MissingDataActionPropertyList;
    putMissingDataAction(value: AwsAnomalyDetector.MissingDataActionProperty[] | cdktn.IResolvable): void;
    resetMissingDataAction(): void;
    get missingDataActionInput(): cdktn.IResolvable | AwsAnomalyDetector.MissingDataActionProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsAnomalyDetector.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsAnomalyDetector.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsAnomalyDetector.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsAnomalyDetectorIgnoreNearExpectedFromAbovePropertyToTerraform(struct?: AwsAnomalyDetector.IgnoreNearExpectedFromAboveProperty | cdktn.IResolvable): any;
export declare function awsAnomalyDetectorIgnoreNearExpectedFromAbovePropertyToHclTerraform(struct?: AwsAnomalyDetector.IgnoreNearExpectedFromAboveProperty | cdktn.IResolvable): any;
export declare function awsAnomalyDetectorIgnoreNearExpectedFromBelowPropertyToTerraform(struct?: AwsAnomalyDetector.IgnoreNearExpectedFromBelowProperty | cdktn.IResolvable): any;
export declare function awsAnomalyDetectorIgnoreNearExpectedFromBelowPropertyToHclTerraform(struct?: AwsAnomalyDetector.IgnoreNearExpectedFromBelowProperty | cdktn.IResolvable): any;
export declare function awsAnomalyDetectorRandomCutForestPropertyToTerraform(struct?: AwsAnomalyDetector.RandomCutForestProperty | cdktn.IResolvable): any;
export declare function awsAnomalyDetectorRandomCutForestPropertyToHclTerraform(struct?: AwsAnomalyDetector.RandomCutForestProperty | cdktn.IResolvable): any;
export declare function awsAnomalyDetectorConfigurationPropertyToTerraform(struct?: AwsAnomalyDetector.ConfigurationProperty | cdktn.IResolvable): any;
export declare function awsAnomalyDetectorConfigurationPropertyToHclTerraform(struct?: AwsAnomalyDetector.ConfigurationProperty | cdktn.IResolvable): any;
export declare function awsAnomalyDetectorMissingDataActionPropertyToTerraform(struct?: AwsAnomalyDetector.MissingDataActionProperty | cdktn.IResolvable): any;
export declare function awsAnomalyDetectorMissingDataActionPropertyToHclTerraform(struct?: AwsAnomalyDetector.MissingDataActionProperty | cdktn.IResolvable): any;
export declare function awsAnomalyDetectorTimeoutsPropertyToTerraform(struct?: AwsAnomalyDetector.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsAnomalyDetectorTimeoutsPropertyToHclTerraform(struct?: AwsAnomalyDetector.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsAnomalyDetector {
    interface IgnoreNearExpectedFromAboveProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_anomaly_detector#amount AwsAnomalyDetector#amount}
        */
        readonly amount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_anomaly_detector#ratio AwsAnomalyDetector#ratio}
        */
        readonly ratio?: number;
    }
    class IgnoreNearExpectedFromAbovePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IgnoreNearExpectedFromAboveProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IgnoreNearExpectedFromAboveProperty | cdktn.IResolvable | undefined);
        private _amount?;
        get amount(): number;
        set amount(value: number);
        resetAmount(): void;
        get amountInput(): number | undefined;
        private _ratio?;
        get ratio(): number;
        set ratio(value: number);
        resetRatio(): void;
        get ratioInput(): number | undefined;
    }
    class IgnoreNearExpectedFromAbovePropertyList extends cdktn.ComplexList {
        internalValue?: IgnoreNearExpectedFromAboveProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IgnoreNearExpectedFromAbovePropertyOutputReference;
    }
    interface IgnoreNearExpectedFromBelowProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_anomaly_detector#amount AwsAnomalyDetector#amount}
        */
        readonly amount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_anomaly_detector#ratio AwsAnomalyDetector#ratio}
        */
        readonly ratio?: number;
    }
    class IgnoreNearExpectedFromBelowPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IgnoreNearExpectedFromBelowProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IgnoreNearExpectedFromBelowProperty | cdktn.IResolvable | undefined);
        private _amount?;
        get amount(): number;
        set amount(value: number);
        resetAmount(): void;
        get amountInput(): number | undefined;
        private _ratio?;
        get ratio(): number;
        set ratio(value: number);
        resetRatio(): void;
        get ratioInput(): number | undefined;
    }
    class IgnoreNearExpectedFromBelowPropertyList extends cdktn.ComplexList {
        internalValue?: IgnoreNearExpectedFromBelowProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IgnoreNearExpectedFromBelowPropertyOutputReference;
    }
    interface RandomCutForestProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_anomaly_detector#query AwsAnomalyDetector#query}
        */
        readonly query: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_anomaly_detector#sample_size AwsAnomalyDetector#sample_size}
        */
        readonly sampleSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_anomaly_detector#shingle_size AwsAnomalyDetector#shingle_size}
        */
        readonly shingleSize?: number;
        /**
        * ignore_near_expected_from_above block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_anomaly_detector#ignore_near_expected_from_above AwsAnomalyDetector#ignore_near_expected_from_above}
        */
        readonly ignoreNearExpectedFromAbove?: IgnoreNearExpectedFromAboveProperty[] | cdktn.IResolvable;
        /**
        * ignore_near_expected_from_below block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_anomaly_detector#ignore_near_expected_from_below AwsAnomalyDetector#ignore_near_expected_from_below}
        */
        readonly ignoreNearExpectedFromBelow?: IgnoreNearExpectedFromBelowProperty[] | cdktn.IResolvable;
    }
    class RandomCutForestPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RandomCutForestProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RandomCutForestProperty | cdktn.IResolvable | undefined);
        private _query?;
        get query(): string;
        set query(value: string);
        get queryInput(): string | undefined;
        private _sampleSize?;
        get sampleSize(): number;
        set sampleSize(value: number);
        resetSampleSize(): void;
        get sampleSizeInput(): number | undefined;
        private _shingleSize?;
        get shingleSize(): number;
        set shingleSize(value: number);
        resetShingleSize(): void;
        get shingleSizeInput(): number | undefined;
        private _ignoreNearExpectedFromAbove;
        get ignoreNearExpectedFromAbove(): IgnoreNearExpectedFromAbovePropertyList;
        putIgnoreNearExpectedFromAbove(value: IgnoreNearExpectedFromAboveProperty[] | cdktn.IResolvable): void;
        resetIgnoreNearExpectedFromAbove(): void;
        get ignoreNearExpectedFromAboveInput(): cdktn.IResolvable | IgnoreNearExpectedFromAboveProperty[] | undefined;
        private _ignoreNearExpectedFromBelow;
        get ignoreNearExpectedFromBelow(): IgnoreNearExpectedFromBelowPropertyList;
        putIgnoreNearExpectedFromBelow(value: IgnoreNearExpectedFromBelowProperty[] | cdktn.IResolvable): void;
        resetIgnoreNearExpectedFromBelow(): void;
        get ignoreNearExpectedFromBelowInput(): cdktn.IResolvable | IgnoreNearExpectedFromBelowProperty[] | undefined;
    }
    class RandomCutForestPropertyList extends cdktn.ComplexList {
        internalValue?: RandomCutForestProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RandomCutForestPropertyOutputReference;
    }
    interface ConfigurationProperty {
        /**
        * random_cut_forest block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_anomaly_detector#random_cut_forest AwsAnomalyDetector#random_cut_forest}
        */
        readonly randomCutForest?: RandomCutForestProperty[] | cdktn.IResolvable;
    }
    class ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConfigurationProperty | cdktn.IResolvable | undefined);
        private _randomCutForest;
        get randomCutForest(): RandomCutForestPropertyList;
        putRandomCutForest(value: RandomCutForestProperty[] | cdktn.IResolvable): void;
        resetRandomCutForest(): void;
        get randomCutForestInput(): cdktn.IResolvable | RandomCutForestProperty[] | undefined;
    }
    class ConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConfigurationPropertyOutputReference;
    }
    interface MissingDataActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_anomaly_detector#mark_as_anomaly AwsAnomalyDetector#mark_as_anomaly}
        */
        readonly markAsAnomaly?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_anomaly_detector#skip AwsAnomalyDetector#skip}
        */
        readonly skip?: boolean | cdktn.IResolvable;
    }
    class MissingDataActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MissingDataActionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MissingDataActionProperty | cdktn.IResolvable | undefined);
        private _markAsAnomaly?;
        get markAsAnomaly(): boolean | cdktn.IResolvable;
        set markAsAnomaly(value: boolean | cdktn.IResolvable);
        resetMarkAsAnomaly(): void;
        get markAsAnomalyInput(): boolean | cdktn.IResolvable | undefined;
        private _skip?;
        get skip(): boolean | cdktn.IResolvable;
        set skip(value: boolean | cdktn.IResolvable);
        resetSkip(): void;
        get skipInput(): boolean | cdktn.IResolvable | undefined;
    }
    class MissingDataActionPropertyList extends cdktn.ComplexList {
        internalValue?: MissingDataActionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MissingDataActionPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_anomaly_detector#create AwsAnomalyDetector#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_anomaly_detector#delete AwsAnomalyDetector#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_anomaly_detector#update AwsAnomalyDetector#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
