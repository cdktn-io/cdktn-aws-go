import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsQueryLoggingConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_query_logging_configuration#region AwsQueryLoggingConfiguration#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_query_logging_configuration#workspace_id AwsQueryLoggingConfiguration#workspace_id}
    */
    readonly workspaceId: string;
    /**
    * destination block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_query_logging_configuration#destination AwsQueryLoggingConfiguration#destination}
    */
    readonly destination?: AwsQueryLoggingConfiguration.DestinationProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_query_logging_configuration#timeouts AwsQueryLoggingConfiguration#timeouts}
    */
    readonly timeouts?: AwsQueryLoggingConfiguration.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_query_logging_configuration aws_prometheus_query_logging_configuration}
*/
export declare class AwsQueryLoggingConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_prometheus_query_logging_configuration";
    /**
    * Generates CDKTN code for importing a AwsQueryLoggingConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsQueryLoggingConfiguration to import
    * @param importFromId The id of the existing AwsQueryLoggingConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_query_logging_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsQueryLoggingConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_query_logging_configuration aws_prometheus_query_logging_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsQueryLoggingConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsQueryLoggingConfigurationConfig);
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
    private _destination;
    get destination(): AwsQueryLoggingConfiguration.DestinationPropertyList;
    putDestination(value: AwsQueryLoggingConfiguration.DestinationProperty[] | cdktn.IResolvable): void;
    resetDestination(): void;
    get destinationInput(): cdktn.IResolvable | AwsQueryLoggingConfiguration.DestinationProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsQueryLoggingConfiguration.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsQueryLoggingConfiguration.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsQueryLoggingConfiguration.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsQueryLoggingConfigurationCloudwatchLogsPropertyToTerraform(struct?: AwsQueryLoggingConfiguration.CloudwatchLogsProperty | cdktn.IResolvable): any;
export declare function awsQueryLoggingConfigurationCloudwatchLogsPropertyToHclTerraform(struct?: AwsQueryLoggingConfiguration.CloudwatchLogsProperty | cdktn.IResolvable): any;
export declare function awsQueryLoggingConfigurationFiltersPropertyToTerraform(struct?: AwsQueryLoggingConfiguration.FiltersProperty | cdktn.IResolvable): any;
export declare function awsQueryLoggingConfigurationFiltersPropertyToHclTerraform(struct?: AwsQueryLoggingConfiguration.FiltersProperty | cdktn.IResolvable): any;
export declare function awsQueryLoggingConfigurationDestinationPropertyToTerraform(struct?: AwsQueryLoggingConfiguration.DestinationProperty | cdktn.IResolvable): any;
export declare function awsQueryLoggingConfigurationDestinationPropertyToHclTerraform(struct?: AwsQueryLoggingConfiguration.DestinationProperty | cdktn.IResolvable): any;
export declare function awsQueryLoggingConfigurationTimeoutsPropertyToTerraform(struct?: AwsQueryLoggingConfiguration.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsQueryLoggingConfigurationTimeoutsPropertyToHclTerraform(struct?: AwsQueryLoggingConfiguration.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsQueryLoggingConfiguration {
    interface CloudwatchLogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_query_logging_configuration#log_group_arn AwsQueryLoggingConfiguration#log_group_arn}
        */
        readonly logGroupArn: string;
    }
    class CloudwatchLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CloudwatchLogsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CloudwatchLogsProperty | cdktn.IResolvable | undefined);
        private _logGroupArn?;
        get logGroupArn(): string;
        set logGroupArn(value: string);
        get logGroupArnInput(): string | undefined;
    }
    class CloudwatchLogsPropertyList extends cdktn.ComplexList {
        internalValue?: CloudwatchLogsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CloudwatchLogsPropertyOutputReference;
    }
    interface FiltersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_query_logging_configuration#qsp_threshold AwsQueryLoggingConfiguration#qsp_threshold}
        */
        readonly qspThreshold: number;
    }
    class FiltersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FiltersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FiltersProperty | cdktn.IResolvable | undefined);
        private _qspThreshold?;
        get qspThreshold(): number;
        set qspThreshold(value: number);
        get qspThresholdInput(): number | undefined;
    }
    class FiltersPropertyList extends cdktn.ComplexList {
        internalValue?: FiltersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FiltersPropertyOutputReference;
    }
    interface DestinationProperty {
        /**
        * cloudwatch_logs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_query_logging_configuration#cloudwatch_logs AwsQueryLoggingConfiguration#cloudwatch_logs}
        */
        readonly cloudwatchLogs?: CloudwatchLogsProperty[] | cdktn.IResolvable;
        /**
        * filters block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_query_logging_configuration#filters AwsQueryLoggingConfiguration#filters}
        */
        readonly filters?: FiltersProperty[] | cdktn.IResolvable;
    }
    class DestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DestinationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DestinationProperty | cdktn.IResolvable | undefined);
        private _cloudwatchLogs;
        get cloudwatchLogs(): CloudwatchLogsPropertyList;
        putCloudwatchLogs(value: CloudwatchLogsProperty[] | cdktn.IResolvable): void;
        resetCloudwatchLogs(): void;
        get cloudwatchLogsInput(): cdktn.IResolvable | CloudwatchLogsProperty[] | undefined;
        private _filters;
        get filters(): FiltersPropertyList;
        putFilters(value: FiltersProperty[] | cdktn.IResolvable): void;
        resetFilters(): void;
        get filtersInput(): cdktn.IResolvable | FiltersProperty[] | undefined;
    }
    class DestinationPropertyList extends cdktn.ComplexList {
        internalValue?: DestinationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DestinationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_query_logging_configuration#create AwsQueryLoggingConfiguration#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_query_logging_configuration#delete AwsQueryLoggingConfiguration#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/prometheus_query_logging_configuration#update AwsQueryLoggingConfiguration#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
