import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsMacie2OrganizationConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether to enable Amazon Macie automatically for accounts that are added to the organization in AWS Organizations
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_organization_configuration#auto_enable AwsMacie2OrganizationConfiguration#auto_enable}
    */
    readonly autoEnable: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_organization_configuration#region AwsMacie2OrganizationConfiguration#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_organization_configuration aws_macie2_organization_configuration}
*/
export declare class AwsMacie2OrganizationConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_macie2_organization_configuration";
    /**
    * Generates CDKTN code for importing a AwsMacie2OrganizationConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsMacie2OrganizationConfiguration to import
    * @param importFromId The id of the existing AwsMacie2OrganizationConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_organization_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsMacie2OrganizationConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_organization_configuration aws_macie2_organization_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsMacie2OrganizationConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsMacie2OrganizationConfigurationConfig);
    private _autoEnable?;
    get autoEnable(): boolean | cdktn.IResolvable;
    set autoEnable(value: boolean | cdktn.IResolvable);
    get autoEnableInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
