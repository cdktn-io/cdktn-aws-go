import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsMacie2ClassificationExportConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_export_configuration#id AwsMacie2ClassificationExportConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_export_configuration#region AwsMacie2ClassificationExportConfiguration#region}
    */
    readonly region?: string;
    /**
    * s3_destination block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_export_configuration#s3_destination AwsMacie2ClassificationExportConfiguration#s3_destination}
    */
    readonly s3Destination: AwsMacie2ClassificationExportConfiguration.S3DestinationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_export_configuration aws_macie2_classification_export_configuration}
*/
export declare class AwsMacie2ClassificationExportConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_macie2_classification_export_configuration";
    /**
    * Generates CDKTN code for importing a AwsMacie2ClassificationExportConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsMacie2ClassificationExportConfiguration to import
    * @param importFromId The id of the existing AwsMacie2ClassificationExportConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_export_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsMacie2ClassificationExportConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_export_configuration aws_macie2_classification_export_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsMacie2ClassificationExportConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsMacie2ClassificationExportConfigurationConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _s3Destination;
    get s3Destination(): AwsMacie2ClassificationExportConfiguration.S3DestinationPropertyOutputReference;
    putS3Destination(value: AwsMacie2ClassificationExportConfiguration.S3DestinationProperty): void;
    get s3DestinationInput(): AwsMacie2ClassificationExportConfiguration.S3DestinationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsMacie2ClassificationExportConfigurationS3DestinationPropertyToTerraform(struct?: AwsMacie2ClassificationExportConfiguration.S3DestinationPropertyOutputReference | AwsMacie2ClassificationExportConfiguration.S3DestinationProperty): any;
export declare function awsMacie2ClassificationExportConfigurationS3DestinationPropertyToHclTerraform(struct?: AwsMacie2ClassificationExportConfiguration.S3DestinationPropertyOutputReference | AwsMacie2ClassificationExportConfiguration.S3DestinationProperty): any;
export declare namespace AwsMacie2ClassificationExportConfiguration {
    interface S3DestinationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_export_configuration#bucket_name AwsMacie2ClassificationExportConfiguration#bucket_name}
        */
        readonly bucketName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_export_configuration#key_prefix AwsMacie2ClassificationExportConfiguration#key_prefix}
        */
        readonly keyPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_export_configuration#kms_key_arn AwsMacie2ClassificationExportConfiguration#kms_key_arn}
        */
        readonly kmsKeyArn: string;
    }
    class S3DestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3DestinationProperty | undefined;
        set internalValue(value: S3DestinationProperty | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        get bucketNameInput(): string | undefined;
        private _keyPrefix?;
        get keyPrefix(): string;
        set keyPrefix(value: string);
        resetKeyPrefix(): void;
        get keyPrefixInput(): string | undefined;
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        get kmsKeyArnInput(): string | undefined;
    }
}
