import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsMacie2ClassificationJobConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#custom_data_identifier_ids AwsMacie2ClassificationJob#custom_data_identifier_ids}
    */
    readonly customDataIdentifierIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#description AwsMacie2ClassificationJob#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#id AwsMacie2ClassificationJob#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#initial_run AwsMacie2ClassificationJob#initial_run}
    */
    readonly initialRun?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#job_status AwsMacie2ClassificationJob#job_status}
    */
    readonly jobStatus?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#job_type AwsMacie2ClassificationJob#job_type}
    */
    readonly jobType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#name AwsMacie2ClassificationJob#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#name_prefix AwsMacie2ClassificationJob#name_prefix}
    */
    readonly namePrefix?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#region AwsMacie2ClassificationJob#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#sampling_percentage AwsMacie2ClassificationJob#sampling_percentage}
    */
    readonly samplingPercentage?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#tags AwsMacie2ClassificationJob#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#tags_all AwsMacie2ClassificationJob#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * s3_job_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#s3_job_definition AwsMacie2ClassificationJob#s3_job_definition}
    */
    readonly s3JobDefinition: AwsMacie2ClassificationJob.S3JobDefinitionProperty;
    /**
    * schedule_frequency block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#schedule_frequency AwsMacie2ClassificationJob#schedule_frequency}
    */
    readonly scheduleFrequency?: AwsMacie2ClassificationJob.ScheduleFrequencyProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#timeouts AwsMacie2ClassificationJob#timeouts}
    */
    readonly timeouts?: AwsMacie2ClassificationJob.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job aws_macie2_classification_job}
*/
export declare class AwsMacie2ClassificationJob extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_macie2_classification_job";
    /**
    * Generates CDKTN code for importing a AwsMacie2ClassificationJob resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsMacie2ClassificationJob to import
    * @param importFromId The id of the existing AwsMacie2ClassificationJob that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsMacie2ClassificationJob to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job aws_macie2_classification_job} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsMacie2ClassificationJobConfig
    */
    constructor(scope: Construct, id: string, config: AwsMacie2ClassificationJobConfig);
    get createdAt(): string;
    private _customDataIdentifierIds?;
    get customDataIdentifierIds(): string[];
    set customDataIdentifierIds(value: string[]);
    resetCustomDataIdentifierIds(): void;
    get customDataIdentifierIdsInput(): string[] | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _initialRun?;
    get initialRun(): boolean | cdktn.IResolvable;
    set initialRun(value: boolean | cdktn.IResolvable);
    resetInitialRun(): void;
    get initialRunInput(): boolean | cdktn.IResolvable | undefined;
    get jobArn(): string;
    get jobId(): string;
    private _jobStatus?;
    get jobStatus(): string;
    set jobStatus(value: string);
    resetJobStatus(): void;
    get jobStatusInput(): string | undefined;
    private _jobType?;
    get jobType(): string;
    set jobType(value: string);
    get jobTypeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namePrefix?;
    get namePrefix(): string;
    set namePrefix(value: string);
    resetNamePrefix(): void;
    get namePrefixInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _samplingPercentage?;
    get samplingPercentage(): number;
    set samplingPercentage(value: number);
    resetSamplingPercentage(): void;
    get samplingPercentageInput(): number | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _userPausedDetails;
    get userPausedDetails(): AwsMacie2ClassificationJob.UserPausedDetailsPropertyList;
    private _s3JobDefinition;
    get s3JobDefinition(): AwsMacie2ClassificationJob.S3JobDefinitionPropertyOutputReference;
    putS3JobDefinition(value: AwsMacie2ClassificationJob.S3JobDefinitionProperty): void;
    get s3JobDefinitionInput(): AwsMacie2ClassificationJob.S3JobDefinitionProperty | undefined;
    private _scheduleFrequency;
    get scheduleFrequency(): AwsMacie2ClassificationJob.ScheduleFrequencyPropertyOutputReference;
    putScheduleFrequency(value: AwsMacie2ClassificationJob.ScheduleFrequencyProperty): void;
    resetScheduleFrequency(): void;
    get scheduleFrequencyInput(): AwsMacie2ClassificationJob.ScheduleFrequencyProperty | undefined;
    private _timeouts;
    get timeouts(): AwsMacie2ClassificationJob.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsMacie2ClassificationJob.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsMacie2ClassificationJob.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsMacie2ClassificationJobUserPausedDetailsPropertyToTerraform(struct?: AwsMacie2ClassificationJob.UserPausedDetailsProperty): any;
export declare function awsMacie2ClassificationJobUserPausedDetailsPropertyToHclTerraform(struct?: AwsMacie2ClassificationJob.UserPausedDetailsProperty): any;
export declare function awsMacie2ClassificationJobS3JobDefinitionBucketCriteriaExcludesAndSimpleCriterionPropertyToTerraform(struct?: AwsMacie2ClassificationJob.S3JobDefinitionBucketCriteriaExcludesAndSimpleCriterionPropertyOutputReference | AwsMacie2ClassificationJob.S3JobDefinitionBucketCriteriaExcludesAndSimpleCriterionProperty): any;
export declare function awsMacie2ClassificationJobS3JobDefinitionBucketCriteriaExcludesAndSimpleCriterionPropertyToHclTerraform(struct?: AwsMacie2ClassificationJob.S3JobDefinitionBucketCriteriaExcludesAndSimpleCriterionPropertyOutputReference | AwsMacie2ClassificationJob.S3JobDefinitionBucketCriteriaExcludesAndSimpleCriterionProperty): any;
export declare function awsMacie2ClassificationJobS3JobDefinitionBucketCriteriaExcludesAndTagCriterionTagValuesPropertyToTerraform(struct?: AwsMacie2ClassificationJob.S3JobDefinitionBucketCriteriaExcludesAndTagCriterionTagValuesProperty | cdktn.IResolvable): any;
export declare function awsMacie2ClassificationJobS3JobDefinitionBucketCriteriaExcludesAndTagCriterionTagValuesPropertyToHclTerraform(struct?: AwsMacie2ClassificationJob.S3JobDefinitionBucketCriteriaExcludesAndTagCriterionTagValuesProperty | cdktn.IResolvable): any;
export declare function awsMacie2ClassificationJobS3JobDefinitionBucketCriteriaExcludesAndTagCriterionPropertyToTerraform(struct?: AwsMacie2ClassificationJob.S3JobDefinitionBucketCriteriaExcludesAndTagCriterionPropertyOutputReference | AwsMacie2ClassificationJob.S3JobDefinitionBucketCriteriaExcludesAndTagCriterionProperty): any;
export declare function awsMacie2ClassificationJobS3JobDefinitionBucketCriteriaExcludesAndTagCriterionPropertyToHclTerraform(struct?: AwsMacie2ClassificationJob.S3JobDefinitionBucketCriteriaExcludesAndTagCriterionPropertyOutputReference | AwsMacie2ClassificationJob.S3JobDefinitionBucketCriteriaExcludesAndTagCriterionProperty): any;
export declare function awsMacie2ClassificationJobS3JobDefinitionBucketCriteriaExcludesAndPropertyToTerraform(struct?: AwsMacie2ClassificationJob.S3JobDefinitionBucketCriteriaExcludesAndProperty | cdktn.IResolvable): any;
export declare function awsMacie2ClassificationJobS3JobDefinitionBucketCriteriaExcludesAndPropertyToHclTerraform(struct?: AwsMacie2ClassificationJob.S3JobDefinitionBucketCriteriaExcludesAndProperty | cdktn.IResolvable): any;
export declare function awsMacie2ClassificationJobS3JobDefinitionBucketCriteriaExcludesPropertyToTerraform(struct?: AwsMacie2ClassificationJob.S3JobDefinitionBucketCriteriaExcludesPropertyOutputReference | AwsMacie2ClassificationJob.S3JobDefinitionBucketCriteriaExcludesProperty): any;
export declare function awsMacie2ClassificationJobS3JobDefinitionBucketCriteriaExcludesPropertyToHclTerraform(struct?: AwsMacie2ClassificationJob.S3JobDefinitionBucketCriteriaExcludesPropertyOutputReference | AwsMacie2ClassificationJob.S3JobDefinitionBucketCriteriaExcludesProperty): any;
export declare function awsMacie2ClassificationJobS3JobDefinitionBucketCriteriaIncludesAndSimpleCriterionPropertyToTerraform(struct?: AwsMacie2ClassificationJob.S3JobDefinitionBucketCriteriaIncludesAndSimpleCriterionPropertyOutputReference | AwsMacie2ClassificationJob.S3JobDefinitionBucketCriteriaIncludesAndSimpleCriterionProperty): any;
export declare function awsMacie2ClassificationJobS3JobDefinitionBucketCriteriaIncludesAndSimpleCriterionPropertyToHclTerraform(struct?: AwsMacie2ClassificationJob.S3JobDefinitionBucketCriteriaIncludesAndSimpleCriterionPropertyOutputReference | AwsMacie2ClassificationJob.S3JobDefinitionBucketCriteriaIncludesAndSimpleCriterionProperty): any;
export declare function awsMacie2ClassificationJobS3JobDefinitionBucketCriteriaIncludesAndTagCriterionTagValuesPropertyToTerraform(struct?: AwsMacie2ClassificationJob.S3JobDefinitionBucketCriteriaIncludesAndTagCriterionTagValuesProperty | cdktn.IResolvable): any;
export declare function awsMacie2ClassificationJobS3JobDefinitionBucketCriteriaIncludesAndTagCriterionTagValuesPropertyToHclTerraform(struct?: AwsMacie2ClassificationJob.S3JobDefinitionBucketCriteriaIncludesAndTagCriterionTagValuesProperty | cdktn.IResolvable): any;
export declare function awsMacie2ClassificationJobS3JobDefinitionBucketCriteriaIncludesAndTagCriterionPropertyToTerraform(struct?: AwsMacie2ClassificationJob.S3JobDefinitionBucketCriteriaIncludesAndTagCriterionPropertyOutputReference | AwsMacie2ClassificationJob.S3JobDefinitionBucketCriteriaIncludesAndTagCriterionProperty): any;
export declare function awsMacie2ClassificationJobS3JobDefinitionBucketCriteriaIncludesAndTagCriterionPropertyToHclTerraform(struct?: AwsMacie2ClassificationJob.S3JobDefinitionBucketCriteriaIncludesAndTagCriterionPropertyOutputReference | AwsMacie2ClassificationJob.S3JobDefinitionBucketCriteriaIncludesAndTagCriterionProperty): any;
export declare function awsMacie2ClassificationJobS3JobDefinitionBucketCriteriaIncludesAndPropertyToTerraform(struct?: AwsMacie2ClassificationJob.S3JobDefinitionBucketCriteriaIncludesAndProperty | cdktn.IResolvable): any;
export declare function awsMacie2ClassificationJobS3JobDefinitionBucketCriteriaIncludesAndPropertyToHclTerraform(struct?: AwsMacie2ClassificationJob.S3JobDefinitionBucketCriteriaIncludesAndProperty | cdktn.IResolvable): any;
export declare function awsMacie2ClassificationJobS3JobDefinitionBucketCriteriaIncludesPropertyToTerraform(struct?: AwsMacie2ClassificationJob.S3JobDefinitionBucketCriteriaIncludesPropertyOutputReference | AwsMacie2ClassificationJob.S3JobDefinitionBucketCriteriaIncludesProperty): any;
export declare function awsMacie2ClassificationJobS3JobDefinitionBucketCriteriaIncludesPropertyToHclTerraform(struct?: AwsMacie2ClassificationJob.S3JobDefinitionBucketCriteriaIncludesPropertyOutputReference | AwsMacie2ClassificationJob.S3JobDefinitionBucketCriteriaIncludesProperty): any;
export declare function awsMacie2ClassificationJobBucketCriteriaPropertyToTerraform(struct?: AwsMacie2ClassificationJob.BucketCriteriaPropertyOutputReference | AwsMacie2ClassificationJob.BucketCriteriaProperty): any;
export declare function awsMacie2ClassificationJobBucketCriteriaPropertyToHclTerraform(struct?: AwsMacie2ClassificationJob.BucketCriteriaPropertyOutputReference | AwsMacie2ClassificationJob.BucketCriteriaProperty): any;
export declare function awsMacie2ClassificationJobBucketDefinitionsPropertyToTerraform(struct?: AwsMacie2ClassificationJob.BucketDefinitionsProperty | cdktn.IResolvable): any;
export declare function awsMacie2ClassificationJobBucketDefinitionsPropertyToHclTerraform(struct?: AwsMacie2ClassificationJob.BucketDefinitionsProperty | cdktn.IResolvable): any;
export declare function awsMacie2ClassificationJobS3JobDefinitionScopingExcludesAndSimpleScopeTermPropertyToTerraform(struct?: AwsMacie2ClassificationJob.S3JobDefinitionScopingExcludesAndSimpleScopeTermPropertyOutputReference | AwsMacie2ClassificationJob.S3JobDefinitionScopingExcludesAndSimpleScopeTermProperty): any;
export declare function awsMacie2ClassificationJobS3JobDefinitionScopingExcludesAndSimpleScopeTermPropertyToHclTerraform(struct?: AwsMacie2ClassificationJob.S3JobDefinitionScopingExcludesAndSimpleScopeTermPropertyOutputReference | AwsMacie2ClassificationJob.S3JobDefinitionScopingExcludesAndSimpleScopeTermProperty): any;
export declare function awsMacie2ClassificationJobS3JobDefinitionScopingExcludesAndTagScopeTermTagValuesPropertyToTerraform(struct?: AwsMacie2ClassificationJob.S3JobDefinitionScopingExcludesAndTagScopeTermTagValuesProperty | cdktn.IResolvable): any;
export declare function awsMacie2ClassificationJobS3JobDefinitionScopingExcludesAndTagScopeTermTagValuesPropertyToHclTerraform(struct?: AwsMacie2ClassificationJob.S3JobDefinitionScopingExcludesAndTagScopeTermTagValuesProperty | cdktn.IResolvable): any;
export declare function awsMacie2ClassificationJobS3JobDefinitionScopingExcludesAndTagScopeTermPropertyToTerraform(struct?: AwsMacie2ClassificationJob.S3JobDefinitionScopingExcludesAndTagScopeTermPropertyOutputReference | AwsMacie2ClassificationJob.S3JobDefinitionScopingExcludesAndTagScopeTermProperty): any;
export declare function awsMacie2ClassificationJobS3JobDefinitionScopingExcludesAndTagScopeTermPropertyToHclTerraform(struct?: AwsMacie2ClassificationJob.S3JobDefinitionScopingExcludesAndTagScopeTermPropertyOutputReference | AwsMacie2ClassificationJob.S3JobDefinitionScopingExcludesAndTagScopeTermProperty): any;
export declare function awsMacie2ClassificationJobS3JobDefinitionScopingExcludesAndPropertyToTerraform(struct?: AwsMacie2ClassificationJob.S3JobDefinitionScopingExcludesAndProperty | cdktn.IResolvable): any;
export declare function awsMacie2ClassificationJobS3JobDefinitionScopingExcludesAndPropertyToHclTerraform(struct?: AwsMacie2ClassificationJob.S3JobDefinitionScopingExcludesAndProperty | cdktn.IResolvable): any;
export declare function awsMacie2ClassificationJobS3JobDefinitionScopingExcludesPropertyToTerraform(struct?: AwsMacie2ClassificationJob.S3JobDefinitionScopingExcludesPropertyOutputReference | AwsMacie2ClassificationJob.S3JobDefinitionScopingExcludesProperty): any;
export declare function awsMacie2ClassificationJobS3JobDefinitionScopingExcludesPropertyToHclTerraform(struct?: AwsMacie2ClassificationJob.S3JobDefinitionScopingExcludesPropertyOutputReference | AwsMacie2ClassificationJob.S3JobDefinitionScopingExcludesProperty): any;
export declare function awsMacie2ClassificationJobS3JobDefinitionScopingIncludesAndSimpleScopeTermPropertyToTerraform(struct?: AwsMacie2ClassificationJob.S3JobDefinitionScopingIncludesAndSimpleScopeTermPropertyOutputReference | AwsMacie2ClassificationJob.S3JobDefinitionScopingIncludesAndSimpleScopeTermProperty): any;
export declare function awsMacie2ClassificationJobS3JobDefinitionScopingIncludesAndSimpleScopeTermPropertyToHclTerraform(struct?: AwsMacie2ClassificationJob.S3JobDefinitionScopingIncludesAndSimpleScopeTermPropertyOutputReference | AwsMacie2ClassificationJob.S3JobDefinitionScopingIncludesAndSimpleScopeTermProperty): any;
export declare function awsMacie2ClassificationJobS3JobDefinitionScopingIncludesAndTagScopeTermTagValuesPropertyToTerraform(struct?: AwsMacie2ClassificationJob.S3JobDefinitionScopingIncludesAndTagScopeTermTagValuesProperty | cdktn.IResolvable): any;
export declare function awsMacie2ClassificationJobS3JobDefinitionScopingIncludesAndTagScopeTermTagValuesPropertyToHclTerraform(struct?: AwsMacie2ClassificationJob.S3JobDefinitionScopingIncludesAndTagScopeTermTagValuesProperty | cdktn.IResolvable): any;
export declare function awsMacie2ClassificationJobS3JobDefinitionScopingIncludesAndTagScopeTermPropertyToTerraform(struct?: AwsMacie2ClassificationJob.S3JobDefinitionScopingIncludesAndTagScopeTermPropertyOutputReference | AwsMacie2ClassificationJob.S3JobDefinitionScopingIncludesAndTagScopeTermProperty): any;
export declare function awsMacie2ClassificationJobS3JobDefinitionScopingIncludesAndTagScopeTermPropertyToHclTerraform(struct?: AwsMacie2ClassificationJob.S3JobDefinitionScopingIncludesAndTagScopeTermPropertyOutputReference | AwsMacie2ClassificationJob.S3JobDefinitionScopingIncludesAndTagScopeTermProperty): any;
export declare function awsMacie2ClassificationJobS3JobDefinitionScopingIncludesAndPropertyToTerraform(struct?: AwsMacie2ClassificationJob.S3JobDefinitionScopingIncludesAndProperty | cdktn.IResolvable): any;
export declare function awsMacie2ClassificationJobS3JobDefinitionScopingIncludesAndPropertyToHclTerraform(struct?: AwsMacie2ClassificationJob.S3JobDefinitionScopingIncludesAndProperty | cdktn.IResolvable): any;
export declare function awsMacie2ClassificationJobS3JobDefinitionScopingIncludesPropertyToTerraform(struct?: AwsMacie2ClassificationJob.S3JobDefinitionScopingIncludesPropertyOutputReference | AwsMacie2ClassificationJob.S3JobDefinitionScopingIncludesProperty): any;
export declare function awsMacie2ClassificationJobS3JobDefinitionScopingIncludesPropertyToHclTerraform(struct?: AwsMacie2ClassificationJob.S3JobDefinitionScopingIncludesPropertyOutputReference | AwsMacie2ClassificationJob.S3JobDefinitionScopingIncludesProperty): any;
export declare function awsMacie2ClassificationJobScopingPropertyToTerraform(struct?: AwsMacie2ClassificationJob.ScopingPropertyOutputReference | AwsMacie2ClassificationJob.ScopingProperty): any;
export declare function awsMacie2ClassificationJobScopingPropertyToHclTerraform(struct?: AwsMacie2ClassificationJob.ScopingPropertyOutputReference | AwsMacie2ClassificationJob.ScopingProperty): any;
export declare function awsMacie2ClassificationJobS3JobDefinitionPropertyToTerraform(struct?: AwsMacie2ClassificationJob.S3JobDefinitionPropertyOutputReference | AwsMacie2ClassificationJob.S3JobDefinitionProperty): any;
export declare function awsMacie2ClassificationJobS3JobDefinitionPropertyToHclTerraform(struct?: AwsMacie2ClassificationJob.S3JobDefinitionPropertyOutputReference | AwsMacie2ClassificationJob.S3JobDefinitionProperty): any;
export declare function awsMacie2ClassificationJobScheduleFrequencyPropertyToTerraform(struct?: AwsMacie2ClassificationJob.ScheduleFrequencyPropertyOutputReference | AwsMacie2ClassificationJob.ScheduleFrequencyProperty): any;
export declare function awsMacie2ClassificationJobScheduleFrequencyPropertyToHclTerraform(struct?: AwsMacie2ClassificationJob.ScheduleFrequencyPropertyOutputReference | AwsMacie2ClassificationJob.ScheduleFrequencyProperty): any;
export declare function awsMacie2ClassificationJobTimeoutsPropertyToTerraform(struct?: AwsMacie2ClassificationJob.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsMacie2ClassificationJobTimeoutsPropertyToHclTerraform(struct?: AwsMacie2ClassificationJob.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsMacie2ClassificationJob {
    interface UserPausedDetailsProperty {
    }
    class UserPausedDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UserPausedDetailsProperty | undefined;
        set internalValue(value: UserPausedDetailsProperty | undefined);
        get jobExpiresAt(): string;
        get jobImminentExpirationHealthEventArn(): string;
        get jobPausedAt(): string;
    }
    class UserPausedDetailsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UserPausedDetailsPropertyOutputReference;
    }
    interface S3JobDefinitionBucketCriteriaExcludesAndSimpleCriterionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#comparator AwsMacie2ClassificationJob#comparator}
        */
        readonly comparator?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#key AwsMacie2ClassificationJob#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#values AwsMacie2ClassificationJob#values}
        */
        readonly values?: string[];
    }
    class S3JobDefinitionBucketCriteriaExcludesAndSimpleCriterionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3JobDefinitionBucketCriteriaExcludesAndSimpleCriterionProperty | undefined;
        set internalValue(value: S3JobDefinitionBucketCriteriaExcludesAndSimpleCriterionProperty | undefined);
        private _comparator?;
        get comparator(): string;
        set comparator(value: string);
        resetComparator(): void;
        get comparatorInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface S3JobDefinitionBucketCriteriaExcludesAndTagCriterionTagValuesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#key AwsMacie2ClassificationJob#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#value AwsMacie2ClassificationJob#value}
        */
        readonly value?: string;
    }
    class S3JobDefinitionBucketCriteriaExcludesAndTagCriterionTagValuesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3JobDefinitionBucketCriteriaExcludesAndTagCriterionTagValuesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3JobDefinitionBucketCriteriaExcludesAndTagCriterionTagValuesProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
    class S3JobDefinitionBucketCriteriaExcludesAndTagCriterionTagValuesPropertyList extends cdktn.ComplexList {
        internalValue?: S3JobDefinitionBucketCriteriaExcludesAndTagCriterionTagValuesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3JobDefinitionBucketCriteriaExcludesAndTagCriterionTagValuesPropertyOutputReference;
    }
    interface S3JobDefinitionBucketCriteriaExcludesAndTagCriterionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#comparator AwsMacie2ClassificationJob#comparator}
        */
        readonly comparator?: string;
        /**
        * tag_values block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#tag_values AwsMacie2ClassificationJob#tag_values}
        */
        readonly tagValues?: S3JobDefinitionBucketCriteriaExcludesAndTagCriterionTagValuesProperty[] | cdktn.IResolvable;
    }
    class S3JobDefinitionBucketCriteriaExcludesAndTagCriterionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3JobDefinitionBucketCriteriaExcludesAndTagCriterionProperty | undefined;
        set internalValue(value: S3JobDefinitionBucketCriteriaExcludesAndTagCriterionProperty | undefined);
        private _comparator?;
        get comparator(): string;
        set comparator(value: string);
        resetComparator(): void;
        get comparatorInput(): string | undefined;
        private _tagValues;
        get tagValues(): S3JobDefinitionBucketCriteriaExcludesAndTagCriterionTagValuesPropertyList;
        putTagValues(value: S3JobDefinitionBucketCriteriaExcludesAndTagCriterionTagValuesProperty[] | cdktn.IResolvable): void;
        resetTagValues(): void;
        get tagValuesInput(): cdktn.IResolvable | S3JobDefinitionBucketCriteriaExcludesAndTagCriterionTagValuesProperty[] | undefined;
    }
    interface S3JobDefinitionBucketCriteriaExcludesAndProperty {
        /**
        * simple_criterion block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#simple_criterion AwsMacie2ClassificationJob#simple_criterion}
        */
        readonly simpleCriterion?: S3JobDefinitionBucketCriteriaExcludesAndSimpleCriterionProperty;
        /**
        * tag_criterion block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#tag_criterion AwsMacie2ClassificationJob#tag_criterion}
        */
        readonly tagCriterion?: S3JobDefinitionBucketCriteriaExcludesAndTagCriterionProperty;
    }
    class S3JobDefinitionBucketCriteriaExcludesAndPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3JobDefinitionBucketCriteriaExcludesAndProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3JobDefinitionBucketCriteriaExcludesAndProperty | cdktn.IResolvable | undefined);
        private _simpleCriterion;
        get simpleCriterion(): S3JobDefinitionBucketCriteriaExcludesAndSimpleCriterionPropertyOutputReference;
        putSimpleCriterion(value: S3JobDefinitionBucketCriteriaExcludesAndSimpleCriterionProperty): void;
        resetSimpleCriterion(): void;
        get simpleCriterionInput(): S3JobDefinitionBucketCriteriaExcludesAndSimpleCriterionProperty | undefined;
        private _tagCriterion;
        get tagCriterion(): S3JobDefinitionBucketCriteriaExcludesAndTagCriterionPropertyOutputReference;
        putTagCriterion(value: S3JobDefinitionBucketCriteriaExcludesAndTagCriterionProperty): void;
        resetTagCriterion(): void;
        get tagCriterionInput(): S3JobDefinitionBucketCriteriaExcludesAndTagCriterionProperty | undefined;
    }
    class S3JobDefinitionBucketCriteriaExcludesAndPropertyList extends cdktn.ComplexList {
        internalValue?: S3JobDefinitionBucketCriteriaExcludesAndProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3JobDefinitionBucketCriteriaExcludesAndPropertyOutputReference;
    }
    interface S3JobDefinitionBucketCriteriaExcludesProperty {
        /**
        * and block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#and AwsMacie2ClassificationJob#and}
        */
        readonly and?: S3JobDefinitionBucketCriteriaExcludesAndProperty[] | cdktn.IResolvable;
    }
    class S3JobDefinitionBucketCriteriaExcludesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3JobDefinitionBucketCriteriaExcludesProperty | undefined;
        set internalValue(value: S3JobDefinitionBucketCriteriaExcludesProperty | undefined);
        private _and;
        get and(): S3JobDefinitionBucketCriteriaExcludesAndPropertyList;
        putAnd(value: S3JobDefinitionBucketCriteriaExcludesAndProperty[] | cdktn.IResolvable): void;
        resetAnd(): void;
        get andInput(): cdktn.IResolvable | S3JobDefinitionBucketCriteriaExcludesAndProperty[] | undefined;
    }
    interface S3JobDefinitionBucketCriteriaIncludesAndSimpleCriterionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#comparator AwsMacie2ClassificationJob#comparator}
        */
        readonly comparator?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#key AwsMacie2ClassificationJob#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#values AwsMacie2ClassificationJob#values}
        */
        readonly values?: string[];
    }
    class S3JobDefinitionBucketCriteriaIncludesAndSimpleCriterionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3JobDefinitionBucketCriteriaIncludesAndSimpleCriterionProperty | undefined;
        set internalValue(value: S3JobDefinitionBucketCriteriaIncludesAndSimpleCriterionProperty | undefined);
        private _comparator?;
        get comparator(): string;
        set comparator(value: string);
        resetComparator(): void;
        get comparatorInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface S3JobDefinitionBucketCriteriaIncludesAndTagCriterionTagValuesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#key AwsMacie2ClassificationJob#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#value AwsMacie2ClassificationJob#value}
        */
        readonly value?: string;
    }
    class S3JobDefinitionBucketCriteriaIncludesAndTagCriterionTagValuesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3JobDefinitionBucketCriteriaIncludesAndTagCriterionTagValuesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3JobDefinitionBucketCriteriaIncludesAndTagCriterionTagValuesProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
    class S3JobDefinitionBucketCriteriaIncludesAndTagCriterionTagValuesPropertyList extends cdktn.ComplexList {
        internalValue?: S3JobDefinitionBucketCriteriaIncludesAndTagCriterionTagValuesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3JobDefinitionBucketCriteriaIncludesAndTagCriterionTagValuesPropertyOutputReference;
    }
    interface S3JobDefinitionBucketCriteriaIncludesAndTagCriterionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#comparator AwsMacie2ClassificationJob#comparator}
        */
        readonly comparator?: string;
        /**
        * tag_values block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#tag_values AwsMacie2ClassificationJob#tag_values}
        */
        readonly tagValues?: S3JobDefinitionBucketCriteriaIncludesAndTagCriterionTagValuesProperty[] | cdktn.IResolvable;
    }
    class S3JobDefinitionBucketCriteriaIncludesAndTagCriterionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3JobDefinitionBucketCriteriaIncludesAndTagCriterionProperty | undefined;
        set internalValue(value: S3JobDefinitionBucketCriteriaIncludesAndTagCriterionProperty | undefined);
        private _comparator?;
        get comparator(): string;
        set comparator(value: string);
        resetComparator(): void;
        get comparatorInput(): string | undefined;
        private _tagValues;
        get tagValues(): S3JobDefinitionBucketCriteriaIncludesAndTagCriterionTagValuesPropertyList;
        putTagValues(value: S3JobDefinitionBucketCriteriaIncludesAndTagCriterionTagValuesProperty[] | cdktn.IResolvable): void;
        resetTagValues(): void;
        get tagValuesInput(): cdktn.IResolvable | S3JobDefinitionBucketCriteriaIncludesAndTagCriterionTagValuesProperty[] | undefined;
    }
    interface S3JobDefinitionBucketCriteriaIncludesAndProperty {
        /**
        * simple_criterion block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#simple_criterion AwsMacie2ClassificationJob#simple_criterion}
        */
        readonly simpleCriterion?: S3JobDefinitionBucketCriteriaIncludesAndSimpleCriterionProperty;
        /**
        * tag_criterion block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#tag_criterion AwsMacie2ClassificationJob#tag_criterion}
        */
        readonly tagCriterion?: S3JobDefinitionBucketCriteriaIncludesAndTagCriterionProperty;
    }
    class S3JobDefinitionBucketCriteriaIncludesAndPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3JobDefinitionBucketCriteriaIncludesAndProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3JobDefinitionBucketCriteriaIncludesAndProperty | cdktn.IResolvable | undefined);
        private _simpleCriterion;
        get simpleCriterion(): S3JobDefinitionBucketCriteriaIncludesAndSimpleCriterionPropertyOutputReference;
        putSimpleCriterion(value: S3JobDefinitionBucketCriteriaIncludesAndSimpleCriterionProperty): void;
        resetSimpleCriterion(): void;
        get simpleCriterionInput(): S3JobDefinitionBucketCriteriaIncludesAndSimpleCriterionProperty | undefined;
        private _tagCriterion;
        get tagCriterion(): S3JobDefinitionBucketCriteriaIncludesAndTagCriterionPropertyOutputReference;
        putTagCriterion(value: S3JobDefinitionBucketCriteriaIncludesAndTagCriterionProperty): void;
        resetTagCriterion(): void;
        get tagCriterionInput(): S3JobDefinitionBucketCriteriaIncludesAndTagCriterionProperty | undefined;
    }
    class S3JobDefinitionBucketCriteriaIncludesAndPropertyList extends cdktn.ComplexList {
        internalValue?: S3JobDefinitionBucketCriteriaIncludesAndProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3JobDefinitionBucketCriteriaIncludesAndPropertyOutputReference;
    }
    interface S3JobDefinitionBucketCriteriaIncludesProperty {
        /**
        * and block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#and AwsMacie2ClassificationJob#and}
        */
        readonly and?: S3JobDefinitionBucketCriteriaIncludesAndProperty[] | cdktn.IResolvable;
    }
    class S3JobDefinitionBucketCriteriaIncludesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3JobDefinitionBucketCriteriaIncludesProperty | undefined;
        set internalValue(value: S3JobDefinitionBucketCriteriaIncludesProperty | undefined);
        private _and;
        get and(): S3JobDefinitionBucketCriteriaIncludesAndPropertyList;
        putAnd(value: S3JobDefinitionBucketCriteriaIncludesAndProperty[] | cdktn.IResolvable): void;
        resetAnd(): void;
        get andInput(): cdktn.IResolvable | S3JobDefinitionBucketCriteriaIncludesAndProperty[] | undefined;
    }
    interface BucketCriteriaProperty {
        /**
        * excludes block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#excludes AwsMacie2ClassificationJob#excludes}
        */
        readonly excludes?: S3JobDefinitionBucketCriteriaExcludesProperty;
        /**
        * includes block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#includes AwsMacie2ClassificationJob#includes}
        */
        readonly includes?: S3JobDefinitionBucketCriteriaIncludesProperty;
    }
    class BucketCriteriaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BucketCriteriaProperty | undefined;
        set internalValue(value: BucketCriteriaProperty | undefined);
        private _excludes;
        get excludes(): S3JobDefinitionBucketCriteriaExcludesPropertyOutputReference;
        putExcludes(value: S3JobDefinitionBucketCriteriaExcludesProperty): void;
        resetExcludes(): void;
        get excludesInput(): S3JobDefinitionBucketCriteriaExcludesProperty | undefined;
        private _includes;
        get includes(): S3JobDefinitionBucketCriteriaIncludesPropertyOutputReference;
        putIncludes(value: S3JobDefinitionBucketCriteriaIncludesProperty): void;
        resetIncludes(): void;
        get includesInput(): S3JobDefinitionBucketCriteriaIncludesProperty | undefined;
    }
    interface BucketDefinitionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#account_id AwsMacie2ClassificationJob#account_id}
        */
        readonly accountId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#buckets AwsMacie2ClassificationJob#buckets}
        */
        readonly buckets: string[];
    }
    class BucketDefinitionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BucketDefinitionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: BucketDefinitionsProperty | cdktn.IResolvable | undefined);
        private _accountId?;
        get accountId(): string;
        set accountId(value: string);
        get accountIdInput(): string | undefined;
        private _buckets?;
        get buckets(): string[];
        set buckets(value: string[]);
        get bucketsInput(): string[] | undefined;
    }
    class BucketDefinitionsPropertyList extends cdktn.ComplexList {
        internalValue?: BucketDefinitionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BucketDefinitionsPropertyOutputReference;
    }
    interface S3JobDefinitionScopingExcludesAndSimpleScopeTermProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#comparator AwsMacie2ClassificationJob#comparator}
        */
        readonly comparator?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#key AwsMacie2ClassificationJob#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#values AwsMacie2ClassificationJob#values}
        */
        readonly values?: string[];
    }
    class S3JobDefinitionScopingExcludesAndSimpleScopeTermPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3JobDefinitionScopingExcludesAndSimpleScopeTermProperty | undefined;
        set internalValue(value: S3JobDefinitionScopingExcludesAndSimpleScopeTermProperty | undefined);
        private _comparator?;
        get comparator(): string;
        set comparator(value: string);
        resetComparator(): void;
        get comparatorInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface S3JobDefinitionScopingExcludesAndTagScopeTermTagValuesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#key AwsMacie2ClassificationJob#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#value AwsMacie2ClassificationJob#value}
        */
        readonly value?: string;
    }
    class S3JobDefinitionScopingExcludesAndTagScopeTermTagValuesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3JobDefinitionScopingExcludesAndTagScopeTermTagValuesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3JobDefinitionScopingExcludesAndTagScopeTermTagValuesProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
    class S3JobDefinitionScopingExcludesAndTagScopeTermTagValuesPropertyList extends cdktn.ComplexList {
        internalValue?: S3JobDefinitionScopingExcludesAndTagScopeTermTagValuesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3JobDefinitionScopingExcludesAndTagScopeTermTagValuesPropertyOutputReference;
    }
    interface S3JobDefinitionScopingExcludesAndTagScopeTermProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#comparator AwsMacie2ClassificationJob#comparator}
        */
        readonly comparator?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#key AwsMacie2ClassificationJob#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#target AwsMacie2ClassificationJob#target}
        */
        readonly target?: string;
        /**
        * tag_values block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#tag_values AwsMacie2ClassificationJob#tag_values}
        */
        readonly tagValues?: S3JobDefinitionScopingExcludesAndTagScopeTermTagValuesProperty[] | cdktn.IResolvable;
    }
    class S3JobDefinitionScopingExcludesAndTagScopeTermPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3JobDefinitionScopingExcludesAndTagScopeTermProperty | undefined;
        set internalValue(value: S3JobDefinitionScopingExcludesAndTagScopeTermProperty | undefined);
        private _comparator?;
        get comparator(): string;
        set comparator(value: string);
        resetComparator(): void;
        get comparatorInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _target?;
        get target(): string;
        set target(value: string);
        resetTarget(): void;
        get targetInput(): string | undefined;
        private _tagValues;
        get tagValues(): S3JobDefinitionScopingExcludesAndTagScopeTermTagValuesPropertyList;
        putTagValues(value: S3JobDefinitionScopingExcludesAndTagScopeTermTagValuesProperty[] | cdktn.IResolvable): void;
        resetTagValues(): void;
        get tagValuesInput(): cdktn.IResolvable | S3JobDefinitionScopingExcludesAndTagScopeTermTagValuesProperty[] | undefined;
    }
    interface S3JobDefinitionScopingExcludesAndProperty {
        /**
        * simple_scope_term block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#simple_scope_term AwsMacie2ClassificationJob#simple_scope_term}
        */
        readonly simpleScopeTerm?: S3JobDefinitionScopingExcludesAndSimpleScopeTermProperty;
        /**
        * tag_scope_term block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#tag_scope_term AwsMacie2ClassificationJob#tag_scope_term}
        */
        readonly tagScopeTerm?: S3JobDefinitionScopingExcludesAndTagScopeTermProperty;
    }
    class S3JobDefinitionScopingExcludesAndPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3JobDefinitionScopingExcludesAndProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3JobDefinitionScopingExcludesAndProperty | cdktn.IResolvable | undefined);
        private _simpleScopeTerm;
        get simpleScopeTerm(): S3JobDefinitionScopingExcludesAndSimpleScopeTermPropertyOutputReference;
        putSimpleScopeTerm(value: S3JobDefinitionScopingExcludesAndSimpleScopeTermProperty): void;
        resetSimpleScopeTerm(): void;
        get simpleScopeTermInput(): S3JobDefinitionScopingExcludesAndSimpleScopeTermProperty | undefined;
        private _tagScopeTerm;
        get tagScopeTerm(): S3JobDefinitionScopingExcludesAndTagScopeTermPropertyOutputReference;
        putTagScopeTerm(value: S3JobDefinitionScopingExcludesAndTagScopeTermProperty): void;
        resetTagScopeTerm(): void;
        get tagScopeTermInput(): S3JobDefinitionScopingExcludesAndTagScopeTermProperty | undefined;
    }
    class S3JobDefinitionScopingExcludesAndPropertyList extends cdktn.ComplexList {
        internalValue?: S3JobDefinitionScopingExcludesAndProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3JobDefinitionScopingExcludesAndPropertyOutputReference;
    }
    interface S3JobDefinitionScopingExcludesProperty {
        /**
        * and block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#and AwsMacie2ClassificationJob#and}
        */
        readonly and?: S3JobDefinitionScopingExcludesAndProperty[] | cdktn.IResolvable;
    }
    class S3JobDefinitionScopingExcludesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3JobDefinitionScopingExcludesProperty | undefined;
        set internalValue(value: S3JobDefinitionScopingExcludesProperty | undefined);
        private _and;
        get and(): S3JobDefinitionScopingExcludesAndPropertyList;
        putAnd(value: S3JobDefinitionScopingExcludesAndProperty[] | cdktn.IResolvable): void;
        resetAnd(): void;
        get andInput(): cdktn.IResolvable | S3JobDefinitionScopingExcludesAndProperty[] | undefined;
    }
    interface S3JobDefinitionScopingIncludesAndSimpleScopeTermProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#comparator AwsMacie2ClassificationJob#comparator}
        */
        readonly comparator?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#key AwsMacie2ClassificationJob#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#values AwsMacie2ClassificationJob#values}
        */
        readonly values?: string[];
    }
    class S3JobDefinitionScopingIncludesAndSimpleScopeTermPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3JobDefinitionScopingIncludesAndSimpleScopeTermProperty | undefined;
        set internalValue(value: S3JobDefinitionScopingIncludesAndSimpleScopeTermProperty | undefined);
        private _comparator?;
        get comparator(): string;
        set comparator(value: string);
        resetComparator(): void;
        get comparatorInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface S3JobDefinitionScopingIncludesAndTagScopeTermTagValuesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#key AwsMacie2ClassificationJob#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#value AwsMacie2ClassificationJob#value}
        */
        readonly value?: string;
    }
    class S3JobDefinitionScopingIncludesAndTagScopeTermTagValuesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3JobDefinitionScopingIncludesAndTagScopeTermTagValuesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3JobDefinitionScopingIncludesAndTagScopeTermTagValuesProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
    class S3JobDefinitionScopingIncludesAndTagScopeTermTagValuesPropertyList extends cdktn.ComplexList {
        internalValue?: S3JobDefinitionScopingIncludesAndTagScopeTermTagValuesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3JobDefinitionScopingIncludesAndTagScopeTermTagValuesPropertyOutputReference;
    }
    interface S3JobDefinitionScopingIncludesAndTagScopeTermProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#comparator AwsMacie2ClassificationJob#comparator}
        */
        readonly comparator?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#key AwsMacie2ClassificationJob#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#target AwsMacie2ClassificationJob#target}
        */
        readonly target?: string;
        /**
        * tag_values block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#tag_values AwsMacie2ClassificationJob#tag_values}
        */
        readonly tagValues?: S3JobDefinitionScopingIncludesAndTagScopeTermTagValuesProperty[] | cdktn.IResolvable;
    }
    class S3JobDefinitionScopingIncludesAndTagScopeTermPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3JobDefinitionScopingIncludesAndTagScopeTermProperty | undefined;
        set internalValue(value: S3JobDefinitionScopingIncludesAndTagScopeTermProperty | undefined);
        private _comparator?;
        get comparator(): string;
        set comparator(value: string);
        resetComparator(): void;
        get comparatorInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _target?;
        get target(): string;
        set target(value: string);
        resetTarget(): void;
        get targetInput(): string | undefined;
        private _tagValues;
        get tagValues(): S3JobDefinitionScopingIncludesAndTagScopeTermTagValuesPropertyList;
        putTagValues(value: S3JobDefinitionScopingIncludesAndTagScopeTermTagValuesProperty[] | cdktn.IResolvable): void;
        resetTagValues(): void;
        get tagValuesInput(): cdktn.IResolvable | S3JobDefinitionScopingIncludesAndTagScopeTermTagValuesProperty[] | undefined;
    }
    interface S3JobDefinitionScopingIncludesAndProperty {
        /**
        * simple_scope_term block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#simple_scope_term AwsMacie2ClassificationJob#simple_scope_term}
        */
        readonly simpleScopeTerm?: S3JobDefinitionScopingIncludesAndSimpleScopeTermProperty;
        /**
        * tag_scope_term block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#tag_scope_term AwsMacie2ClassificationJob#tag_scope_term}
        */
        readonly tagScopeTerm?: S3JobDefinitionScopingIncludesAndTagScopeTermProperty;
    }
    class S3JobDefinitionScopingIncludesAndPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3JobDefinitionScopingIncludesAndProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3JobDefinitionScopingIncludesAndProperty | cdktn.IResolvable | undefined);
        private _simpleScopeTerm;
        get simpleScopeTerm(): S3JobDefinitionScopingIncludesAndSimpleScopeTermPropertyOutputReference;
        putSimpleScopeTerm(value: S3JobDefinitionScopingIncludesAndSimpleScopeTermProperty): void;
        resetSimpleScopeTerm(): void;
        get simpleScopeTermInput(): S3JobDefinitionScopingIncludesAndSimpleScopeTermProperty | undefined;
        private _tagScopeTerm;
        get tagScopeTerm(): S3JobDefinitionScopingIncludesAndTagScopeTermPropertyOutputReference;
        putTagScopeTerm(value: S3JobDefinitionScopingIncludesAndTagScopeTermProperty): void;
        resetTagScopeTerm(): void;
        get tagScopeTermInput(): S3JobDefinitionScopingIncludesAndTagScopeTermProperty | undefined;
    }
    class S3JobDefinitionScopingIncludesAndPropertyList extends cdktn.ComplexList {
        internalValue?: S3JobDefinitionScopingIncludesAndProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3JobDefinitionScopingIncludesAndPropertyOutputReference;
    }
    interface S3JobDefinitionScopingIncludesProperty {
        /**
        * and block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#and AwsMacie2ClassificationJob#and}
        */
        readonly and?: S3JobDefinitionScopingIncludesAndProperty[] | cdktn.IResolvable;
    }
    class S3JobDefinitionScopingIncludesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3JobDefinitionScopingIncludesProperty | undefined;
        set internalValue(value: S3JobDefinitionScopingIncludesProperty | undefined);
        private _and;
        get and(): S3JobDefinitionScopingIncludesAndPropertyList;
        putAnd(value: S3JobDefinitionScopingIncludesAndProperty[] | cdktn.IResolvable): void;
        resetAnd(): void;
        get andInput(): cdktn.IResolvable | S3JobDefinitionScopingIncludesAndProperty[] | undefined;
    }
    interface ScopingProperty {
        /**
        * excludes block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#excludes AwsMacie2ClassificationJob#excludes}
        */
        readonly excludes?: S3JobDefinitionScopingExcludesProperty;
        /**
        * includes block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#includes AwsMacie2ClassificationJob#includes}
        */
        readonly includes?: S3JobDefinitionScopingIncludesProperty;
    }
    class ScopingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ScopingProperty | undefined;
        set internalValue(value: ScopingProperty | undefined);
        private _excludes;
        get excludes(): S3JobDefinitionScopingExcludesPropertyOutputReference;
        putExcludes(value: S3JobDefinitionScopingExcludesProperty): void;
        resetExcludes(): void;
        get excludesInput(): S3JobDefinitionScopingExcludesProperty | undefined;
        private _includes;
        get includes(): S3JobDefinitionScopingIncludesPropertyOutputReference;
        putIncludes(value: S3JobDefinitionScopingIncludesProperty): void;
        resetIncludes(): void;
        get includesInput(): S3JobDefinitionScopingIncludesProperty | undefined;
    }
    interface S3JobDefinitionProperty {
        /**
        * bucket_criteria block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#bucket_criteria AwsMacie2ClassificationJob#bucket_criteria}
        */
        readonly bucketCriteria?: BucketCriteriaProperty;
        /**
        * bucket_definitions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#bucket_definitions AwsMacie2ClassificationJob#bucket_definitions}
        */
        readonly bucketDefinitions?: BucketDefinitionsProperty[] | cdktn.IResolvable;
        /**
        * scoping block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#scoping AwsMacie2ClassificationJob#scoping}
        */
        readonly scoping?: ScopingProperty;
    }
    class S3JobDefinitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3JobDefinitionProperty | undefined;
        set internalValue(value: S3JobDefinitionProperty | undefined);
        private _bucketCriteria;
        get bucketCriteria(): BucketCriteriaPropertyOutputReference;
        putBucketCriteria(value: BucketCriteriaProperty): void;
        resetBucketCriteria(): void;
        get bucketCriteriaInput(): BucketCriteriaProperty | undefined;
        private _bucketDefinitions;
        get bucketDefinitions(): BucketDefinitionsPropertyList;
        putBucketDefinitions(value: BucketDefinitionsProperty[] | cdktn.IResolvable): void;
        resetBucketDefinitions(): void;
        get bucketDefinitionsInput(): cdktn.IResolvable | BucketDefinitionsProperty[] | undefined;
        private _scoping;
        get scoping(): ScopingPropertyOutputReference;
        putScoping(value: ScopingProperty): void;
        resetScoping(): void;
        get scopingInput(): ScopingProperty | undefined;
    }
    interface ScheduleFrequencyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#daily_schedule AwsMacie2ClassificationJob#daily_schedule}
        */
        readonly dailySchedule?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#monthly_schedule AwsMacie2ClassificationJob#monthly_schedule}
        */
        readonly monthlySchedule?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#weekly_schedule AwsMacie2ClassificationJob#weekly_schedule}
        */
        readonly weeklySchedule?: string;
    }
    class ScheduleFrequencyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ScheduleFrequencyProperty | undefined;
        set internalValue(value: ScheduleFrequencyProperty | undefined);
        private _dailySchedule?;
        get dailySchedule(): boolean | cdktn.IResolvable;
        set dailySchedule(value: boolean | cdktn.IResolvable);
        resetDailySchedule(): void;
        get dailyScheduleInput(): boolean | cdktn.IResolvable | undefined;
        private _monthlySchedule?;
        get monthlySchedule(): number;
        set monthlySchedule(value: number);
        resetMonthlySchedule(): void;
        get monthlyScheduleInput(): number | undefined;
        private _weeklySchedule?;
        get weeklySchedule(): string;
        set weeklySchedule(value: string);
        resetWeeklySchedule(): void;
        get weeklyScheduleInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#create AwsMacie2ClassificationJob#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#update AwsMacie2ClassificationJob#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
