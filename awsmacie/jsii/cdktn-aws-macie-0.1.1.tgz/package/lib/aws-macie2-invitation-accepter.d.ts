import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsMacie2InvitationAccepterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_invitation_accepter#administrator_account_id AwsMacie2InvitationAccepter#administrator_account_id}
    */
    readonly administratorAccountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_invitation_accepter#id AwsMacie2InvitationAccepter#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_invitation_accepter#region AwsMacie2InvitationAccepter#region}
    */
    readonly region?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_invitation_accepter#timeouts AwsMacie2InvitationAccepter#timeouts}
    */
    readonly timeouts?: AwsMacie2InvitationAccepter.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_invitation_accepter aws_macie2_invitation_accepter}
*/
export declare class AwsMacie2InvitationAccepter extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_macie2_invitation_accepter";
    /**
    * Generates CDKTN code for importing a AwsMacie2InvitationAccepter resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsMacie2InvitationAccepter to import
    * @param importFromId The id of the existing AwsMacie2InvitationAccepter that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_invitation_accepter#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsMacie2InvitationAccepter to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_invitation_accepter aws_macie2_invitation_accepter} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsMacie2InvitationAccepterConfig
    */
    constructor(scope: Construct, id: string, config: AwsMacie2InvitationAccepterConfig);
    private _administratorAccountId?;
    get administratorAccountId(): string;
    set administratorAccountId(value: string);
    get administratorAccountIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get invitationId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _timeouts;
    get timeouts(): AwsMacie2InvitationAccepter.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsMacie2InvitationAccepter.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsMacie2InvitationAccepter.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsMacie2InvitationAccepterTimeoutsPropertyToTerraform(struct?: AwsMacie2InvitationAccepter.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsMacie2InvitationAccepterTimeoutsPropertyToHclTerraform(struct?: AwsMacie2InvitationAccepter.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsMacie2InvitationAccepter {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_invitation_accepter#create AwsMacie2InvitationAccepter#create}
        */
        readonly create?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
    }
}
