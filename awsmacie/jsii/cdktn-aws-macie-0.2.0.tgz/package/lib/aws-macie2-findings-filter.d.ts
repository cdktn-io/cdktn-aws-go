import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfFindingsFilterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_findings_filter#action TfFindingsFilter#action}
    */
    readonly action: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_findings_filter#description TfFindingsFilter#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_findings_filter#id TfFindingsFilter#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_findings_filter#name TfFindingsFilter#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_findings_filter#name_prefix TfFindingsFilter#name_prefix}
    */
    readonly namePrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_findings_filter#position TfFindingsFilter#position}
    */
    readonly position?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_findings_filter#region TfFindingsFilter#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_findings_filter#tags TfFindingsFilter#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_findings_filter#tags_all TfFindingsFilter#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * finding_criteria block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_findings_filter#finding_criteria TfFindingsFilter#finding_criteria}
    */
    readonly findingCriteria: TfFindingsFilter.FindingCriteriaProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_findings_filter#timeouts TfFindingsFilter#timeouts}
    */
    readonly timeouts?: TfFindingsFilter.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_findings_filter aws_macie2_findings_filter}
*/
export declare class TfFindingsFilter extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_macie2_findings_filter";
    /**
    * Generates CDKTN code for importing a TfFindingsFilter resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfFindingsFilter to import
    * @param importFromId The id of the existing TfFindingsFilter that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_findings_filter#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfFindingsFilter to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_findings_filter aws_macie2_findings_filter} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfFindingsFilterConfig
    */
    constructor(scope: Construct, id: string, config: TfFindingsFilterConfig);
    private _action?;
    get action(): string;
    set action(value: string);
    get actionInput(): string | undefined;
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namePrefix?;
    get namePrefix(): string;
    set namePrefix(value: string);
    resetNamePrefix(): void;
    get namePrefixInput(): string | undefined;
    private _position?;
    get position(): number;
    set position(value: number);
    resetPosition(): void;
    get positionInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _findingCriteria;
    get findingCriteria(): TfFindingsFilter.FindingCriteriaPropertyOutputReference;
    putFindingCriteria(value: TfFindingsFilter.FindingCriteriaProperty): void;
    get findingCriteriaInput(): TfFindingsFilter.FindingCriteriaProperty | undefined;
    private _timeouts;
    get timeouts(): TfFindingsFilter.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfFindingsFilter.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfFindingsFilter.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfFindingsFilterCriterionPropertyToTerraform(struct?: TfFindingsFilter.CriterionProperty | cdktn.IResolvable): any;
export declare function tfFindingsFilterCriterionPropertyToHclTerraform(struct?: TfFindingsFilter.CriterionProperty | cdktn.IResolvable): any;
export declare function tfFindingsFilterFindingCriteriaPropertyToTerraform(struct?: TfFindingsFilter.FindingCriteriaPropertyOutputReference | TfFindingsFilter.FindingCriteriaProperty): any;
export declare function tfFindingsFilterFindingCriteriaPropertyToHclTerraform(struct?: TfFindingsFilter.FindingCriteriaPropertyOutputReference | TfFindingsFilter.FindingCriteriaProperty): any;
export declare function tfFindingsFilterTimeoutsPropertyToTerraform(struct?: TfFindingsFilter.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfFindingsFilterTimeoutsPropertyToHclTerraform(struct?: TfFindingsFilter.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfFindingsFilter {
    interface CriterionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_findings_filter#eq TfFindingsFilter#eq}
        */
        readonly eq?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_findings_filter#eq_exact_match TfFindingsFilter#eq_exact_match}
        */
        readonly eqExactMatch?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_findings_filter#field TfFindingsFilter#field}
        */
        readonly field: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_findings_filter#gt TfFindingsFilter#gt}
        */
        readonly gt?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_findings_filter#gte TfFindingsFilter#gte}
        */
        readonly gte?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_findings_filter#lt TfFindingsFilter#lt}
        */
        readonly lt?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_findings_filter#lte TfFindingsFilter#lte}
        */
        readonly lte?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_findings_filter#neq TfFindingsFilter#neq}
        */
        readonly neq?: string[];
    }
    class CriterionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CriterionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CriterionProperty | cdktn.IResolvable | undefined);
        private _eq?;
        get eq(): string[];
        set eq(value: string[]);
        resetEq(): void;
        get eqInput(): string[] | undefined;
        private _eqExactMatch?;
        get eqExactMatch(): string[];
        set eqExactMatch(value: string[]);
        resetEqExactMatch(): void;
        get eqExactMatchInput(): string[] | undefined;
        private _field?;
        get field(): string;
        set field(value: string);
        get fieldInput(): string | undefined;
        private _gt?;
        get gt(): string;
        set gt(value: string);
        resetGt(): void;
        get gtInput(): string | undefined;
        private _gte?;
        get gte(): string;
        set gte(value: string);
        resetGte(): void;
        get gteInput(): string | undefined;
        private _lt?;
        get lt(): string;
        set lt(value: string);
        resetLt(): void;
        get ltInput(): string | undefined;
        private _lte?;
        get lte(): string;
        set lte(value: string);
        resetLte(): void;
        get lteInput(): string | undefined;
        private _neq?;
        get neq(): string[];
        set neq(value: string[]);
        resetNeq(): void;
        get neqInput(): string[] | undefined;
    }
    class CriterionPropertyList extends cdktn.ComplexList {
        internalValue?: CriterionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CriterionPropertyOutputReference;
    }
    interface FindingCriteriaProperty {
        /**
        * criterion block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_findings_filter#criterion TfFindingsFilter#criterion}
        */
        readonly criterion?: CriterionProperty[] | cdktn.IResolvable;
    }
    class FindingCriteriaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FindingCriteriaProperty | undefined;
        set internalValue(value: FindingCriteriaProperty | undefined);
        private _criterion;
        get criterion(): CriterionPropertyList;
        putCriterion(value: CriterionProperty[] | cdktn.IResolvable): void;
        resetCriterion(): void;
        get criterionInput(): cdktn.IResolvable | CriterionProperty[] | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_findings_filter#create TfFindingsFilter#create}
        */
        readonly create?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
    }
}
