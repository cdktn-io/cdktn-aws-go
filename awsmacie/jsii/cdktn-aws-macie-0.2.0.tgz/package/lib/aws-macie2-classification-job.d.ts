import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfClassificationJobConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#custom_data_identifier_ids TfClassificationJob#custom_data_identifier_ids}
    */
    readonly customDataIdentifierIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#description TfClassificationJob#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#id TfClassificationJob#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#initial_run TfClassificationJob#initial_run}
    */
    readonly initialRun?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#job_status TfClassificationJob#job_status}
    */
    readonly jobStatus?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#job_type TfClassificationJob#job_type}
    */
    readonly jobType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#name TfClassificationJob#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#name_prefix TfClassificationJob#name_prefix}
    */
    readonly namePrefix?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#region TfClassificationJob#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#sampling_percentage TfClassificationJob#sampling_percentage}
    */
    readonly samplingPercentage?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#tags TfClassificationJob#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#tags_all TfClassificationJob#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * s3_job_definition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#s3_job_definition TfClassificationJob#s3_job_definition}
    */
    readonly s3JobDefinition: TfClassificationJob.S3JobDefinitionProperty;
    /**
    * schedule_frequency block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#schedule_frequency TfClassificationJob#schedule_frequency}
    */
    readonly scheduleFrequency?: TfClassificationJob.ScheduleFrequencyProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#timeouts TfClassificationJob#timeouts}
    */
    readonly timeouts?: TfClassificationJob.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job aws_macie2_classification_job}
*/
export declare class TfClassificationJob extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_macie2_classification_job";
    /**
    * Generates CDKTN code for importing a TfClassificationJob resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfClassificationJob to import
    * @param importFromId The id of the existing TfClassificationJob that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfClassificationJob to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job aws_macie2_classification_job} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfClassificationJobConfig
    */
    constructor(scope: Construct, id: string, config: TfClassificationJobConfig);
    get createdAt(): string;
    private _customDataIdentifierIds?;
    get customDataIdentifierIds(): string[];
    set customDataIdentifierIds(value: string[]);
    resetCustomDataIdentifierIds(): void;
    get customDataIdentifierIdsInput(): string[] | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _initialRun?;
    get initialRun(): boolean | cdktn.IResolvable;
    set initialRun(value: boolean | cdktn.IResolvable);
    resetInitialRun(): void;
    get initialRunInput(): boolean | cdktn.IResolvable | undefined;
    get jobArn(): string;
    get jobId(): string;
    private _jobStatus?;
    get jobStatus(): string;
    set jobStatus(value: string);
    resetJobStatus(): void;
    get jobStatusInput(): string | undefined;
    private _jobType?;
    get jobType(): string;
    set jobType(value: string);
    get jobTypeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namePrefix?;
    get namePrefix(): string;
    set namePrefix(value: string);
    resetNamePrefix(): void;
    get namePrefixInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _samplingPercentage?;
    get samplingPercentage(): number;
    set samplingPercentage(value: number);
    resetSamplingPercentage(): void;
    get samplingPercentageInput(): number | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _userPausedDetails;
    get userPausedDetails(): TfClassificationJob.UserPausedDetailsPropertyList;
    private _s3JobDefinition;
    get s3JobDefinition(): TfClassificationJob.S3JobDefinitionPropertyOutputReference;
    putS3JobDefinition(value: TfClassificationJob.S3JobDefinitionProperty): void;
    get s3JobDefinitionInput(): TfClassificationJob.S3JobDefinitionProperty | undefined;
    private _scheduleFrequency;
    get scheduleFrequency(): TfClassificationJob.ScheduleFrequencyPropertyOutputReference;
    putScheduleFrequency(value: TfClassificationJob.ScheduleFrequencyProperty): void;
    resetScheduleFrequency(): void;
    get scheduleFrequencyInput(): TfClassificationJob.ScheduleFrequencyProperty | undefined;
    private _timeouts;
    get timeouts(): TfClassificationJob.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfClassificationJob.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfClassificationJob.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfClassificationJobUserPausedDetailsPropertyToTerraform(struct?: TfClassificationJob.UserPausedDetailsProperty): any;
export declare function tfClassificationJobUserPausedDetailsPropertyToHclTerraform(struct?: TfClassificationJob.UserPausedDetailsProperty): any;
export declare function tfClassificationJobS3JobDefinitionBucketCriteriaExcludesAndSimpleCriterionPropertyToTerraform(struct?: TfClassificationJob.S3JobDefinitionBucketCriteriaExcludesAndSimpleCriterionPropertyOutputReference | TfClassificationJob.S3JobDefinitionBucketCriteriaExcludesAndSimpleCriterionProperty): any;
export declare function tfClassificationJobS3JobDefinitionBucketCriteriaExcludesAndSimpleCriterionPropertyToHclTerraform(struct?: TfClassificationJob.S3JobDefinitionBucketCriteriaExcludesAndSimpleCriterionPropertyOutputReference | TfClassificationJob.S3JobDefinitionBucketCriteriaExcludesAndSimpleCriterionProperty): any;
export declare function tfClassificationJobS3JobDefinitionBucketCriteriaExcludesAndTagCriterionTagValuesPropertyToTerraform(struct?: TfClassificationJob.S3JobDefinitionBucketCriteriaExcludesAndTagCriterionTagValuesProperty | cdktn.IResolvable): any;
export declare function tfClassificationJobS3JobDefinitionBucketCriteriaExcludesAndTagCriterionTagValuesPropertyToHclTerraform(struct?: TfClassificationJob.S3JobDefinitionBucketCriteriaExcludesAndTagCriterionTagValuesProperty | cdktn.IResolvable): any;
export declare function tfClassificationJobS3JobDefinitionBucketCriteriaExcludesAndTagCriterionPropertyToTerraform(struct?: TfClassificationJob.S3JobDefinitionBucketCriteriaExcludesAndTagCriterionPropertyOutputReference | TfClassificationJob.S3JobDefinitionBucketCriteriaExcludesAndTagCriterionProperty): any;
export declare function tfClassificationJobS3JobDefinitionBucketCriteriaExcludesAndTagCriterionPropertyToHclTerraform(struct?: TfClassificationJob.S3JobDefinitionBucketCriteriaExcludesAndTagCriterionPropertyOutputReference | TfClassificationJob.S3JobDefinitionBucketCriteriaExcludesAndTagCriterionProperty): any;
export declare function tfClassificationJobS3JobDefinitionBucketCriteriaExcludesAndPropertyToTerraform(struct?: TfClassificationJob.S3JobDefinitionBucketCriteriaExcludesAndProperty | cdktn.IResolvable): any;
export declare function tfClassificationJobS3JobDefinitionBucketCriteriaExcludesAndPropertyToHclTerraform(struct?: TfClassificationJob.S3JobDefinitionBucketCriteriaExcludesAndProperty | cdktn.IResolvable): any;
export declare function tfClassificationJobS3JobDefinitionBucketCriteriaExcludesPropertyToTerraform(struct?: TfClassificationJob.S3JobDefinitionBucketCriteriaExcludesPropertyOutputReference | TfClassificationJob.S3JobDefinitionBucketCriteriaExcludesProperty): any;
export declare function tfClassificationJobS3JobDefinitionBucketCriteriaExcludesPropertyToHclTerraform(struct?: TfClassificationJob.S3JobDefinitionBucketCriteriaExcludesPropertyOutputReference | TfClassificationJob.S3JobDefinitionBucketCriteriaExcludesProperty): any;
export declare function tfClassificationJobS3JobDefinitionBucketCriteriaIncludesAndSimpleCriterionPropertyToTerraform(struct?: TfClassificationJob.S3JobDefinitionBucketCriteriaIncludesAndSimpleCriterionPropertyOutputReference | TfClassificationJob.S3JobDefinitionBucketCriteriaIncludesAndSimpleCriterionProperty): any;
export declare function tfClassificationJobS3JobDefinitionBucketCriteriaIncludesAndSimpleCriterionPropertyToHclTerraform(struct?: TfClassificationJob.S3JobDefinitionBucketCriteriaIncludesAndSimpleCriterionPropertyOutputReference | TfClassificationJob.S3JobDefinitionBucketCriteriaIncludesAndSimpleCriterionProperty): any;
export declare function tfClassificationJobS3JobDefinitionBucketCriteriaIncludesAndTagCriterionTagValuesPropertyToTerraform(struct?: TfClassificationJob.S3JobDefinitionBucketCriteriaIncludesAndTagCriterionTagValuesProperty | cdktn.IResolvable): any;
export declare function tfClassificationJobS3JobDefinitionBucketCriteriaIncludesAndTagCriterionTagValuesPropertyToHclTerraform(struct?: TfClassificationJob.S3JobDefinitionBucketCriteriaIncludesAndTagCriterionTagValuesProperty | cdktn.IResolvable): any;
export declare function tfClassificationJobS3JobDefinitionBucketCriteriaIncludesAndTagCriterionPropertyToTerraform(struct?: TfClassificationJob.S3JobDefinitionBucketCriteriaIncludesAndTagCriterionPropertyOutputReference | TfClassificationJob.S3JobDefinitionBucketCriteriaIncludesAndTagCriterionProperty): any;
export declare function tfClassificationJobS3JobDefinitionBucketCriteriaIncludesAndTagCriterionPropertyToHclTerraform(struct?: TfClassificationJob.S3JobDefinitionBucketCriteriaIncludesAndTagCriterionPropertyOutputReference | TfClassificationJob.S3JobDefinitionBucketCriteriaIncludesAndTagCriterionProperty): any;
export declare function tfClassificationJobS3JobDefinitionBucketCriteriaIncludesAndPropertyToTerraform(struct?: TfClassificationJob.S3JobDefinitionBucketCriteriaIncludesAndProperty | cdktn.IResolvable): any;
export declare function tfClassificationJobS3JobDefinitionBucketCriteriaIncludesAndPropertyToHclTerraform(struct?: TfClassificationJob.S3JobDefinitionBucketCriteriaIncludesAndProperty | cdktn.IResolvable): any;
export declare function tfClassificationJobS3JobDefinitionBucketCriteriaIncludesPropertyToTerraform(struct?: TfClassificationJob.S3JobDefinitionBucketCriteriaIncludesPropertyOutputReference | TfClassificationJob.S3JobDefinitionBucketCriteriaIncludesProperty): any;
export declare function tfClassificationJobS3JobDefinitionBucketCriteriaIncludesPropertyToHclTerraform(struct?: TfClassificationJob.S3JobDefinitionBucketCriteriaIncludesPropertyOutputReference | TfClassificationJob.S3JobDefinitionBucketCriteriaIncludesProperty): any;
export declare function tfClassificationJobBucketCriteriaPropertyToTerraform(struct?: TfClassificationJob.BucketCriteriaPropertyOutputReference | TfClassificationJob.BucketCriteriaProperty): any;
export declare function tfClassificationJobBucketCriteriaPropertyToHclTerraform(struct?: TfClassificationJob.BucketCriteriaPropertyOutputReference | TfClassificationJob.BucketCriteriaProperty): any;
export declare function tfClassificationJobBucketDefinitionsPropertyToTerraform(struct?: TfClassificationJob.BucketDefinitionsProperty | cdktn.IResolvable): any;
export declare function tfClassificationJobBucketDefinitionsPropertyToHclTerraform(struct?: TfClassificationJob.BucketDefinitionsProperty | cdktn.IResolvable): any;
export declare function tfClassificationJobS3JobDefinitionScopingExcludesAndSimpleScopeTermPropertyToTerraform(struct?: TfClassificationJob.S3JobDefinitionScopingExcludesAndSimpleScopeTermPropertyOutputReference | TfClassificationJob.S3JobDefinitionScopingExcludesAndSimpleScopeTermProperty): any;
export declare function tfClassificationJobS3JobDefinitionScopingExcludesAndSimpleScopeTermPropertyToHclTerraform(struct?: TfClassificationJob.S3JobDefinitionScopingExcludesAndSimpleScopeTermPropertyOutputReference | TfClassificationJob.S3JobDefinitionScopingExcludesAndSimpleScopeTermProperty): any;
export declare function tfClassificationJobS3JobDefinitionScopingExcludesAndTagScopeTermTagValuesPropertyToTerraform(struct?: TfClassificationJob.S3JobDefinitionScopingExcludesAndTagScopeTermTagValuesProperty | cdktn.IResolvable): any;
export declare function tfClassificationJobS3JobDefinitionScopingExcludesAndTagScopeTermTagValuesPropertyToHclTerraform(struct?: TfClassificationJob.S3JobDefinitionScopingExcludesAndTagScopeTermTagValuesProperty | cdktn.IResolvable): any;
export declare function tfClassificationJobS3JobDefinitionScopingExcludesAndTagScopeTermPropertyToTerraform(struct?: TfClassificationJob.S3JobDefinitionScopingExcludesAndTagScopeTermPropertyOutputReference | TfClassificationJob.S3JobDefinitionScopingExcludesAndTagScopeTermProperty): any;
export declare function tfClassificationJobS3JobDefinitionScopingExcludesAndTagScopeTermPropertyToHclTerraform(struct?: TfClassificationJob.S3JobDefinitionScopingExcludesAndTagScopeTermPropertyOutputReference | TfClassificationJob.S3JobDefinitionScopingExcludesAndTagScopeTermProperty): any;
export declare function tfClassificationJobS3JobDefinitionScopingExcludesAndPropertyToTerraform(struct?: TfClassificationJob.S3JobDefinitionScopingExcludesAndProperty | cdktn.IResolvable): any;
export declare function tfClassificationJobS3JobDefinitionScopingExcludesAndPropertyToHclTerraform(struct?: TfClassificationJob.S3JobDefinitionScopingExcludesAndProperty | cdktn.IResolvable): any;
export declare function tfClassificationJobS3JobDefinitionScopingExcludesPropertyToTerraform(struct?: TfClassificationJob.S3JobDefinitionScopingExcludesPropertyOutputReference | TfClassificationJob.S3JobDefinitionScopingExcludesProperty): any;
export declare function tfClassificationJobS3JobDefinitionScopingExcludesPropertyToHclTerraform(struct?: TfClassificationJob.S3JobDefinitionScopingExcludesPropertyOutputReference | TfClassificationJob.S3JobDefinitionScopingExcludesProperty): any;
export declare function tfClassificationJobS3JobDefinitionScopingIncludesAndSimpleScopeTermPropertyToTerraform(struct?: TfClassificationJob.S3JobDefinitionScopingIncludesAndSimpleScopeTermPropertyOutputReference | TfClassificationJob.S3JobDefinitionScopingIncludesAndSimpleScopeTermProperty): any;
export declare function tfClassificationJobS3JobDefinitionScopingIncludesAndSimpleScopeTermPropertyToHclTerraform(struct?: TfClassificationJob.S3JobDefinitionScopingIncludesAndSimpleScopeTermPropertyOutputReference | TfClassificationJob.S3JobDefinitionScopingIncludesAndSimpleScopeTermProperty): any;
export declare function tfClassificationJobS3JobDefinitionScopingIncludesAndTagScopeTermTagValuesPropertyToTerraform(struct?: TfClassificationJob.S3JobDefinitionScopingIncludesAndTagScopeTermTagValuesProperty | cdktn.IResolvable): any;
export declare function tfClassificationJobS3JobDefinitionScopingIncludesAndTagScopeTermTagValuesPropertyToHclTerraform(struct?: TfClassificationJob.S3JobDefinitionScopingIncludesAndTagScopeTermTagValuesProperty | cdktn.IResolvable): any;
export declare function tfClassificationJobS3JobDefinitionScopingIncludesAndTagScopeTermPropertyToTerraform(struct?: TfClassificationJob.S3JobDefinitionScopingIncludesAndTagScopeTermPropertyOutputReference | TfClassificationJob.S3JobDefinitionScopingIncludesAndTagScopeTermProperty): any;
export declare function tfClassificationJobS3JobDefinitionScopingIncludesAndTagScopeTermPropertyToHclTerraform(struct?: TfClassificationJob.S3JobDefinitionScopingIncludesAndTagScopeTermPropertyOutputReference | TfClassificationJob.S3JobDefinitionScopingIncludesAndTagScopeTermProperty): any;
export declare function tfClassificationJobS3JobDefinitionScopingIncludesAndPropertyToTerraform(struct?: TfClassificationJob.S3JobDefinitionScopingIncludesAndProperty | cdktn.IResolvable): any;
export declare function tfClassificationJobS3JobDefinitionScopingIncludesAndPropertyToHclTerraform(struct?: TfClassificationJob.S3JobDefinitionScopingIncludesAndProperty | cdktn.IResolvable): any;
export declare function tfClassificationJobS3JobDefinitionScopingIncludesPropertyToTerraform(struct?: TfClassificationJob.S3JobDefinitionScopingIncludesPropertyOutputReference | TfClassificationJob.S3JobDefinitionScopingIncludesProperty): any;
export declare function tfClassificationJobS3JobDefinitionScopingIncludesPropertyToHclTerraform(struct?: TfClassificationJob.S3JobDefinitionScopingIncludesPropertyOutputReference | TfClassificationJob.S3JobDefinitionScopingIncludesProperty): any;
export declare function tfClassificationJobScopingPropertyToTerraform(struct?: TfClassificationJob.ScopingPropertyOutputReference | TfClassificationJob.ScopingProperty): any;
export declare function tfClassificationJobScopingPropertyToHclTerraform(struct?: TfClassificationJob.ScopingPropertyOutputReference | TfClassificationJob.ScopingProperty): any;
export declare function tfClassificationJobS3JobDefinitionPropertyToTerraform(struct?: TfClassificationJob.S3JobDefinitionPropertyOutputReference | TfClassificationJob.S3JobDefinitionProperty): any;
export declare function tfClassificationJobS3JobDefinitionPropertyToHclTerraform(struct?: TfClassificationJob.S3JobDefinitionPropertyOutputReference | TfClassificationJob.S3JobDefinitionProperty): any;
export declare function tfClassificationJobScheduleFrequencyPropertyToTerraform(struct?: TfClassificationJob.ScheduleFrequencyPropertyOutputReference | TfClassificationJob.ScheduleFrequencyProperty): any;
export declare function tfClassificationJobScheduleFrequencyPropertyToHclTerraform(struct?: TfClassificationJob.ScheduleFrequencyPropertyOutputReference | TfClassificationJob.ScheduleFrequencyProperty): any;
export declare function tfClassificationJobTimeoutsPropertyToTerraform(struct?: TfClassificationJob.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfClassificationJobTimeoutsPropertyToHclTerraform(struct?: TfClassificationJob.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfClassificationJob {
    interface UserPausedDetailsProperty {
    }
    class UserPausedDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UserPausedDetailsProperty | undefined;
        set internalValue(value: UserPausedDetailsProperty | undefined);
        get jobExpiresAt(): string;
        get jobImminentExpirationHealthEventArn(): string;
        get jobPausedAt(): string;
    }
    class UserPausedDetailsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UserPausedDetailsPropertyOutputReference;
    }
    interface S3JobDefinitionBucketCriteriaExcludesAndSimpleCriterionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#comparator TfClassificationJob#comparator}
        */
        readonly comparator?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#key TfClassificationJob#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#values TfClassificationJob#values}
        */
        readonly values?: string[];
    }
    class S3JobDefinitionBucketCriteriaExcludesAndSimpleCriterionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3JobDefinitionBucketCriteriaExcludesAndSimpleCriterionProperty | undefined;
        set internalValue(value: S3JobDefinitionBucketCriteriaExcludesAndSimpleCriterionProperty | undefined);
        private _comparator?;
        get comparator(): string;
        set comparator(value: string);
        resetComparator(): void;
        get comparatorInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface S3JobDefinitionBucketCriteriaExcludesAndTagCriterionTagValuesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#key TfClassificationJob#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#value TfClassificationJob#value}
        */
        readonly value?: string;
    }
    class S3JobDefinitionBucketCriteriaExcludesAndTagCriterionTagValuesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3JobDefinitionBucketCriteriaExcludesAndTagCriterionTagValuesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3JobDefinitionBucketCriteriaExcludesAndTagCriterionTagValuesProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
    class S3JobDefinitionBucketCriteriaExcludesAndTagCriterionTagValuesPropertyList extends cdktn.ComplexList {
        internalValue?: S3JobDefinitionBucketCriteriaExcludesAndTagCriterionTagValuesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3JobDefinitionBucketCriteriaExcludesAndTagCriterionTagValuesPropertyOutputReference;
    }
    interface S3JobDefinitionBucketCriteriaExcludesAndTagCriterionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#comparator TfClassificationJob#comparator}
        */
        readonly comparator?: string;
        /**
        * tag_values block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#tag_values TfClassificationJob#tag_values}
        */
        readonly tagValues?: S3JobDefinitionBucketCriteriaExcludesAndTagCriterionTagValuesProperty[] | cdktn.IResolvable;
    }
    class S3JobDefinitionBucketCriteriaExcludesAndTagCriterionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3JobDefinitionBucketCriteriaExcludesAndTagCriterionProperty | undefined;
        set internalValue(value: S3JobDefinitionBucketCriteriaExcludesAndTagCriterionProperty | undefined);
        private _comparator?;
        get comparator(): string;
        set comparator(value: string);
        resetComparator(): void;
        get comparatorInput(): string | undefined;
        private _tagValues;
        get tagValues(): S3JobDefinitionBucketCriteriaExcludesAndTagCriterionTagValuesPropertyList;
        putTagValues(value: S3JobDefinitionBucketCriteriaExcludesAndTagCriterionTagValuesProperty[] | cdktn.IResolvable): void;
        resetTagValues(): void;
        get tagValuesInput(): cdktn.IResolvable | S3JobDefinitionBucketCriteriaExcludesAndTagCriterionTagValuesProperty[] | undefined;
    }
    interface S3JobDefinitionBucketCriteriaExcludesAndProperty {
        /**
        * simple_criterion block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#simple_criterion TfClassificationJob#simple_criterion}
        */
        readonly simpleCriterion?: S3JobDefinitionBucketCriteriaExcludesAndSimpleCriterionProperty;
        /**
        * tag_criterion block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#tag_criterion TfClassificationJob#tag_criterion}
        */
        readonly tagCriterion?: S3JobDefinitionBucketCriteriaExcludesAndTagCriterionProperty;
    }
    class S3JobDefinitionBucketCriteriaExcludesAndPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3JobDefinitionBucketCriteriaExcludesAndProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3JobDefinitionBucketCriteriaExcludesAndProperty | cdktn.IResolvable | undefined);
        private _simpleCriterion;
        get simpleCriterion(): S3JobDefinitionBucketCriteriaExcludesAndSimpleCriterionPropertyOutputReference;
        putSimpleCriterion(value: S3JobDefinitionBucketCriteriaExcludesAndSimpleCriterionProperty): void;
        resetSimpleCriterion(): void;
        get simpleCriterionInput(): S3JobDefinitionBucketCriteriaExcludesAndSimpleCriterionProperty | undefined;
        private _tagCriterion;
        get tagCriterion(): S3JobDefinitionBucketCriteriaExcludesAndTagCriterionPropertyOutputReference;
        putTagCriterion(value: S3JobDefinitionBucketCriteriaExcludesAndTagCriterionProperty): void;
        resetTagCriterion(): void;
        get tagCriterionInput(): S3JobDefinitionBucketCriteriaExcludesAndTagCriterionProperty | undefined;
    }
    class S3JobDefinitionBucketCriteriaExcludesAndPropertyList extends cdktn.ComplexList {
        internalValue?: S3JobDefinitionBucketCriteriaExcludesAndProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3JobDefinitionBucketCriteriaExcludesAndPropertyOutputReference;
    }
    interface S3JobDefinitionBucketCriteriaExcludesProperty {
        /**
        * and block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#and TfClassificationJob#and}
        */
        readonly and?: S3JobDefinitionBucketCriteriaExcludesAndProperty[] | cdktn.IResolvable;
    }
    class S3JobDefinitionBucketCriteriaExcludesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3JobDefinitionBucketCriteriaExcludesProperty | undefined;
        set internalValue(value: S3JobDefinitionBucketCriteriaExcludesProperty | undefined);
        private _and;
        get and(): S3JobDefinitionBucketCriteriaExcludesAndPropertyList;
        putAnd(value: S3JobDefinitionBucketCriteriaExcludesAndProperty[] | cdktn.IResolvable): void;
        resetAnd(): void;
        get andInput(): cdktn.IResolvable | S3JobDefinitionBucketCriteriaExcludesAndProperty[] | undefined;
    }
    interface S3JobDefinitionBucketCriteriaIncludesAndSimpleCriterionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#comparator TfClassificationJob#comparator}
        */
        readonly comparator?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#key TfClassificationJob#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#values TfClassificationJob#values}
        */
        readonly values?: string[];
    }
    class S3JobDefinitionBucketCriteriaIncludesAndSimpleCriterionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3JobDefinitionBucketCriteriaIncludesAndSimpleCriterionProperty | undefined;
        set internalValue(value: S3JobDefinitionBucketCriteriaIncludesAndSimpleCriterionProperty | undefined);
        private _comparator?;
        get comparator(): string;
        set comparator(value: string);
        resetComparator(): void;
        get comparatorInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface S3JobDefinitionBucketCriteriaIncludesAndTagCriterionTagValuesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#key TfClassificationJob#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#value TfClassificationJob#value}
        */
        readonly value?: string;
    }
    class S3JobDefinitionBucketCriteriaIncludesAndTagCriterionTagValuesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3JobDefinitionBucketCriteriaIncludesAndTagCriterionTagValuesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3JobDefinitionBucketCriteriaIncludesAndTagCriterionTagValuesProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
    class S3JobDefinitionBucketCriteriaIncludesAndTagCriterionTagValuesPropertyList extends cdktn.ComplexList {
        internalValue?: S3JobDefinitionBucketCriteriaIncludesAndTagCriterionTagValuesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3JobDefinitionBucketCriteriaIncludesAndTagCriterionTagValuesPropertyOutputReference;
    }
    interface S3JobDefinitionBucketCriteriaIncludesAndTagCriterionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#comparator TfClassificationJob#comparator}
        */
        readonly comparator?: string;
        /**
        * tag_values block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#tag_values TfClassificationJob#tag_values}
        */
        readonly tagValues?: S3JobDefinitionBucketCriteriaIncludesAndTagCriterionTagValuesProperty[] | cdktn.IResolvable;
    }
    class S3JobDefinitionBucketCriteriaIncludesAndTagCriterionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3JobDefinitionBucketCriteriaIncludesAndTagCriterionProperty | undefined;
        set internalValue(value: S3JobDefinitionBucketCriteriaIncludesAndTagCriterionProperty | undefined);
        private _comparator?;
        get comparator(): string;
        set comparator(value: string);
        resetComparator(): void;
        get comparatorInput(): string | undefined;
        private _tagValues;
        get tagValues(): S3JobDefinitionBucketCriteriaIncludesAndTagCriterionTagValuesPropertyList;
        putTagValues(value: S3JobDefinitionBucketCriteriaIncludesAndTagCriterionTagValuesProperty[] | cdktn.IResolvable): void;
        resetTagValues(): void;
        get tagValuesInput(): cdktn.IResolvable | S3JobDefinitionBucketCriteriaIncludesAndTagCriterionTagValuesProperty[] | undefined;
    }
    interface S3JobDefinitionBucketCriteriaIncludesAndProperty {
        /**
        * simple_criterion block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#simple_criterion TfClassificationJob#simple_criterion}
        */
        readonly simpleCriterion?: S3JobDefinitionBucketCriteriaIncludesAndSimpleCriterionProperty;
        /**
        * tag_criterion block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#tag_criterion TfClassificationJob#tag_criterion}
        */
        readonly tagCriterion?: S3JobDefinitionBucketCriteriaIncludesAndTagCriterionProperty;
    }
    class S3JobDefinitionBucketCriteriaIncludesAndPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3JobDefinitionBucketCriteriaIncludesAndProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3JobDefinitionBucketCriteriaIncludesAndProperty | cdktn.IResolvable | undefined);
        private _simpleCriterion;
        get simpleCriterion(): S3JobDefinitionBucketCriteriaIncludesAndSimpleCriterionPropertyOutputReference;
        putSimpleCriterion(value: S3JobDefinitionBucketCriteriaIncludesAndSimpleCriterionProperty): void;
        resetSimpleCriterion(): void;
        get simpleCriterionInput(): S3JobDefinitionBucketCriteriaIncludesAndSimpleCriterionProperty | undefined;
        private _tagCriterion;
        get tagCriterion(): S3JobDefinitionBucketCriteriaIncludesAndTagCriterionPropertyOutputReference;
        putTagCriterion(value: S3JobDefinitionBucketCriteriaIncludesAndTagCriterionProperty): void;
        resetTagCriterion(): void;
        get tagCriterionInput(): S3JobDefinitionBucketCriteriaIncludesAndTagCriterionProperty | undefined;
    }
    class S3JobDefinitionBucketCriteriaIncludesAndPropertyList extends cdktn.ComplexList {
        internalValue?: S3JobDefinitionBucketCriteriaIncludesAndProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3JobDefinitionBucketCriteriaIncludesAndPropertyOutputReference;
    }
    interface S3JobDefinitionBucketCriteriaIncludesProperty {
        /**
        * and block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#and TfClassificationJob#and}
        */
        readonly and?: S3JobDefinitionBucketCriteriaIncludesAndProperty[] | cdktn.IResolvable;
    }
    class S3JobDefinitionBucketCriteriaIncludesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3JobDefinitionBucketCriteriaIncludesProperty | undefined;
        set internalValue(value: S3JobDefinitionBucketCriteriaIncludesProperty | undefined);
        private _and;
        get and(): S3JobDefinitionBucketCriteriaIncludesAndPropertyList;
        putAnd(value: S3JobDefinitionBucketCriteriaIncludesAndProperty[] | cdktn.IResolvable): void;
        resetAnd(): void;
        get andInput(): cdktn.IResolvable | S3JobDefinitionBucketCriteriaIncludesAndProperty[] | undefined;
    }
    interface BucketCriteriaProperty {
        /**
        * excludes block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#excludes TfClassificationJob#excludes}
        */
        readonly excludes?: S3JobDefinitionBucketCriteriaExcludesProperty;
        /**
        * includes block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#includes TfClassificationJob#includes}
        */
        readonly includes?: S3JobDefinitionBucketCriteriaIncludesProperty;
    }
    class BucketCriteriaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BucketCriteriaProperty | undefined;
        set internalValue(value: BucketCriteriaProperty | undefined);
        private _excludes;
        get excludes(): S3JobDefinitionBucketCriteriaExcludesPropertyOutputReference;
        putExcludes(value: S3JobDefinitionBucketCriteriaExcludesProperty): void;
        resetExcludes(): void;
        get excludesInput(): S3JobDefinitionBucketCriteriaExcludesProperty | undefined;
        private _includes;
        get includes(): S3JobDefinitionBucketCriteriaIncludesPropertyOutputReference;
        putIncludes(value: S3JobDefinitionBucketCriteriaIncludesProperty): void;
        resetIncludes(): void;
        get includesInput(): S3JobDefinitionBucketCriteriaIncludesProperty | undefined;
    }
    interface BucketDefinitionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#account_id TfClassificationJob#account_id}
        */
        readonly accountId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#buckets TfClassificationJob#buckets}
        */
        readonly buckets: string[];
    }
    class BucketDefinitionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BucketDefinitionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: BucketDefinitionsProperty | cdktn.IResolvable | undefined);
        private _accountId?;
        get accountId(): string;
        set accountId(value: string);
        get accountIdInput(): string | undefined;
        private _buckets?;
        get buckets(): string[];
        set buckets(value: string[]);
        get bucketsInput(): string[] | undefined;
    }
    class BucketDefinitionsPropertyList extends cdktn.ComplexList {
        internalValue?: BucketDefinitionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BucketDefinitionsPropertyOutputReference;
    }
    interface S3JobDefinitionScopingExcludesAndSimpleScopeTermProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#comparator TfClassificationJob#comparator}
        */
        readonly comparator?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#key TfClassificationJob#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#values TfClassificationJob#values}
        */
        readonly values?: string[];
    }
    class S3JobDefinitionScopingExcludesAndSimpleScopeTermPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3JobDefinitionScopingExcludesAndSimpleScopeTermProperty | undefined;
        set internalValue(value: S3JobDefinitionScopingExcludesAndSimpleScopeTermProperty | undefined);
        private _comparator?;
        get comparator(): string;
        set comparator(value: string);
        resetComparator(): void;
        get comparatorInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface S3JobDefinitionScopingExcludesAndTagScopeTermTagValuesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#key TfClassificationJob#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#value TfClassificationJob#value}
        */
        readonly value?: string;
    }
    class S3JobDefinitionScopingExcludesAndTagScopeTermTagValuesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3JobDefinitionScopingExcludesAndTagScopeTermTagValuesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3JobDefinitionScopingExcludesAndTagScopeTermTagValuesProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
    class S3JobDefinitionScopingExcludesAndTagScopeTermTagValuesPropertyList extends cdktn.ComplexList {
        internalValue?: S3JobDefinitionScopingExcludesAndTagScopeTermTagValuesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3JobDefinitionScopingExcludesAndTagScopeTermTagValuesPropertyOutputReference;
    }
    interface S3JobDefinitionScopingExcludesAndTagScopeTermProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#comparator TfClassificationJob#comparator}
        */
        readonly comparator?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#key TfClassificationJob#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#target TfClassificationJob#target}
        */
        readonly target?: string;
        /**
        * tag_values block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#tag_values TfClassificationJob#tag_values}
        */
        readonly tagValues?: S3JobDefinitionScopingExcludesAndTagScopeTermTagValuesProperty[] | cdktn.IResolvable;
    }
    class S3JobDefinitionScopingExcludesAndTagScopeTermPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3JobDefinitionScopingExcludesAndTagScopeTermProperty | undefined;
        set internalValue(value: S3JobDefinitionScopingExcludesAndTagScopeTermProperty | undefined);
        private _comparator?;
        get comparator(): string;
        set comparator(value: string);
        resetComparator(): void;
        get comparatorInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _target?;
        get target(): string;
        set target(value: string);
        resetTarget(): void;
        get targetInput(): string | undefined;
        private _tagValues;
        get tagValues(): S3JobDefinitionScopingExcludesAndTagScopeTermTagValuesPropertyList;
        putTagValues(value: S3JobDefinitionScopingExcludesAndTagScopeTermTagValuesProperty[] | cdktn.IResolvable): void;
        resetTagValues(): void;
        get tagValuesInput(): cdktn.IResolvable | S3JobDefinitionScopingExcludesAndTagScopeTermTagValuesProperty[] | undefined;
    }
    interface S3JobDefinitionScopingExcludesAndProperty {
        /**
        * simple_scope_term block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#simple_scope_term TfClassificationJob#simple_scope_term}
        */
        readonly simpleScopeTerm?: S3JobDefinitionScopingExcludesAndSimpleScopeTermProperty;
        /**
        * tag_scope_term block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#tag_scope_term TfClassificationJob#tag_scope_term}
        */
        readonly tagScopeTerm?: S3JobDefinitionScopingExcludesAndTagScopeTermProperty;
    }
    class S3JobDefinitionScopingExcludesAndPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3JobDefinitionScopingExcludesAndProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3JobDefinitionScopingExcludesAndProperty | cdktn.IResolvable | undefined);
        private _simpleScopeTerm;
        get simpleScopeTerm(): S3JobDefinitionScopingExcludesAndSimpleScopeTermPropertyOutputReference;
        putSimpleScopeTerm(value: S3JobDefinitionScopingExcludesAndSimpleScopeTermProperty): void;
        resetSimpleScopeTerm(): void;
        get simpleScopeTermInput(): S3JobDefinitionScopingExcludesAndSimpleScopeTermProperty | undefined;
        private _tagScopeTerm;
        get tagScopeTerm(): S3JobDefinitionScopingExcludesAndTagScopeTermPropertyOutputReference;
        putTagScopeTerm(value: S3JobDefinitionScopingExcludesAndTagScopeTermProperty): void;
        resetTagScopeTerm(): void;
        get tagScopeTermInput(): S3JobDefinitionScopingExcludesAndTagScopeTermProperty | undefined;
    }
    class S3JobDefinitionScopingExcludesAndPropertyList extends cdktn.ComplexList {
        internalValue?: S3JobDefinitionScopingExcludesAndProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3JobDefinitionScopingExcludesAndPropertyOutputReference;
    }
    interface S3JobDefinitionScopingExcludesProperty {
        /**
        * and block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#and TfClassificationJob#and}
        */
        readonly and?: S3JobDefinitionScopingExcludesAndProperty[] | cdktn.IResolvable;
    }
    class S3JobDefinitionScopingExcludesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3JobDefinitionScopingExcludesProperty | undefined;
        set internalValue(value: S3JobDefinitionScopingExcludesProperty | undefined);
        private _and;
        get and(): S3JobDefinitionScopingExcludesAndPropertyList;
        putAnd(value: S3JobDefinitionScopingExcludesAndProperty[] | cdktn.IResolvable): void;
        resetAnd(): void;
        get andInput(): cdktn.IResolvable | S3JobDefinitionScopingExcludesAndProperty[] | undefined;
    }
    interface S3JobDefinitionScopingIncludesAndSimpleScopeTermProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#comparator TfClassificationJob#comparator}
        */
        readonly comparator?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#key TfClassificationJob#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#values TfClassificationJob#values}
        */
        readonly values?: string[];
    }
    class S3JobDefinitionScopingIncludesAndSimpleScopeTermPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3JobDefinitionScopingIncludesAndSimpleScopeTermProperty | undefined;
        set internalValue(value: S3JobDefinitionScopingIncludesAndSimpleScopeTermProperty | undefined);
        private _comparator?;
        get comparator(): string;
        set comparator(value: string);
        resetComparator(): void;
        get comparatorInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface S3JobDefinitionScopingIncludesAndTagScopeTermTagValuesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#key TfClassificationJob#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#value TfClassificationJob#value}
        */
        readonly value?: string;
    }
    class S3JobDefinitionScopingIncludesAndTagScopeTermTagValuesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3JobDefinitionScopingIncludesAndTagScopeTermTagValuesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3JobDefinitionScopingIncludesAndTagScopeTermTagValuesProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
    class S3JobDefinitionScopingIncludesAndTagScopeTermTagValuesPropertyList extends cdktn.ComplexList {
        internalValue?: S3JobDefinitionScopingIncludesAndTagScopeTermTagValuesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3JobDefinitionScopingIncludesAndTagScopeTermTagValuesPropertyOutputReference;
    }
    interface S3JobDefinitionScopingIncludesAndTagScopeTermProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#comparator TfClassificationJob#comparator}
        */
        readonly comparator?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#key TfClassificationJob#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#target TfClassificationJob#target}
        */
        readonly target?: string;
        /**
        * tag_values block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#tag_values TfClassificationJob#tag_values}
        */
        readonly tagValues?: S3JobDefinitionScopingIncludesAndTagScopeTermTagValuesProperty[] | cdktn.IResolvable;
    }
    class S3JobDefinitionScopingIncludesAndTagScopeTermPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3JobDefinitionScopingIncludesAndTagScopeTermProperty | undefined;
        set internalValue(value: S3JobDefinitionScopingIncludesAndTagScopeTermProperty | undefined);
        private _comparator?;
        get comparator(): string;
        set comparator(value: string);
        resetComparator(): void;
        get comparatorInput(): string | undefined;
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _target?;
        get target(): string;
        set target(value: string);
        resetTarget(): void;
        get targetInput(): string | undefined;
        private _tagValues;
        get tagValues(): S3JobDefinitionScopingIncludesAndTagScopeTermTagValuesPropertyList;
        putTagValues(value: S3JobDefinitionScopingIncludesAndTagScopeTermTagValuesProperty[] | cdktn.IResolvable): void;
        resetTagValues(): void;
        get tagValuesInput(): cdktn.IResolvable | S3JobDefinitionScopingIncludesAndTagScopeTermTagValuesProperty[] | undefined;
    }
    interface S3JobDefinitionScopingIncludesAndProperty {
        /**
        * simple_scope_term block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#simple_scope_term TfClassificationJob#simple_scope_term}
        */
        readonly simpleScopeTerm?: S3JobDefinitionScopingIncludesAndSimpleScopeTermProperty;
        /**
        * tag_scope_term block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#tag_scope_term TfClassificationJob#tag_scope_term}
        */
        readonly tagScopeTerm?: S3JobDefinitionScopingIncludesAndTagScopeTermProperty;
    }
    class S3JobDefinitionScopingIncludesAndPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): S3JobDefinitionScopingIncludesAndProperty | cdktn.IResolvable | undefined;
        set internalValue(value: S3JobDefinitionScopingIncludesAndProperty | cdktn.IResolvable | undefined);
        private _simpleScopeTerm;
        get simpleScopeTerm(): S3JobDefinitionScopingIncludesAndSimpleScopeTermPropertyOutputReference;
        putSimpleScopeTerm(value: S3JobDefinitionScopingIncludesAndSimpleScopeTermProperty): void;
        resetSimpleScopeTerm(): void;
        get simpleScopeTermInput(): S3JobDefinitionScopingIncludesAndSimpleScopeTermProperty | undefined;
        private _tagScopeTerm;
        get tagScopeTerm(): S3JobDefinitionScopingIncludesAndTagScopeTermPropertyOutputReference;
        putTagScopeTerm(value: S3JobDefinitionScopingIncludesAndTagScopeTermProperty): void;
        resetTagScopeTerm(): void;
        get tagScopeTermInput(): S3JobDefinitionScopingIncludesAndTagScopeTermProperty | undefined;
    }
    class S3JobDefinitionScopingIncludesAndPropertyList extends cdktn.ComplexList {
        internalValue?: S3JobDefinitionScopingIncludesAndProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): S3JobDefinitionScopingIncludesAndPropertyOutputReference;
    }
    interface S3JobDefinitionScopingIncludesProperty {
        /**
        * and block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#and TfClassificationJob#and}
        */
        readonly and?: S3JobDefinitionScopingIncludesAndProperty[] | cdktn.IResolvable;
    }
    class S3JobDefinitionScopingIncludesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3JobDefinitionScopingIncludesProperty | undefined;
        set internalValue(value: S3JobDefinitionScopingIncludesProperty | undefined);
        private _and;
        get and(): S3JobDefinitionScopingIncludesAndPropertyList;
        putAnd(value: S3JobDefinitionScopingIncludesAndProperty[] | cdktn.IResolvable): void;
        resetAnd(): void;
        get andInput(): cdktn.IResolvable | S3JobDefinitionScopingIncludesAndProperty[] | undefined;
    }
    interface ScopingProperty {
        /**
        * excludes block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#excludes TfClassificationJob#excludes}
        */
        readonly excludes?: S3JobDefinitionScopingExcludesProperty;
        /**
        * includes block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#includes TfClassificationJob#includes}
        */
        readonly includes?: S3JobDefinitionScopingIncludesProperty;
    }
    class ScopingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ScopingProperty | undefined;
        set internalValue(value: ScopingProperty | undefined);
        private _excludes;
        get excludes(): S3JobDefinitionScopingExcludesPropertyOutputReference;
        putExcludes(value: S3JobDefinitionScopingExcludesProperty): void;
        resetExcludes(): void;
        get excludesInput(): S3JobDefinitionScopingExcludesProperty | undefined;
        private _includes;
        get includes(): S3JobDefinitionScopingIncludesPropertyOutputReference;
        putIncludes(value: S3JobDefinitionScopingIncludesProperty): void;
        resetIncludes(): void;
        get includesInput(): S3JobDefinitionScopingIncludesProperty | undefined;
    }
    interface S3JobDefinitionProperty {
        /**
        * bucket_criteria block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#bucket_criteria TfClassificationJob#bucket_criteria}
        */
        readonly bucketCriteria?: BucketCriteriaProperty;
        /**
        * bucket_definitions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#bucket_definitions TfClassificationJob#bucket_definitions}
        */
        readonly bucketDefinitions?: BucketDefinitionsProperty[] | cdktn.IResolvable;
        /**
        * scoping block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#scoping TfClassificationJob#scoping}
        */
        readonly scoping?: ScopingProperty;
    }
    class S3JobDefinitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3JobDefinitionProperty | undefined;
        set internalValue(value: S3JobDefinitionProperty | undefined);
        private _bucketCriteria;
        get bucketCriteria(): BucketCriteriaPropertyOutputReference;
        putBucketCriteria(value: BucketCriteriaProperty): void;
        resetBucketCriteria(): void;
        get bucketCriteriaInput(): BucketCriteriaProperty | undefined;
        private _bucketDefinitions;
        get bucketDefinitions(): BucketDefinitionsPropertyList;
        putBucketDefinitions(value: BucketDefinitionsProperty[] | cdktn.IResolvable): void;
        resetBucketDefinitions(): void;
        get bucketDefinitionsInput(): cdktn.IResolvable | BucketDefinitionsProperty[] | undefined;
        private _scoping;
        get scoping(): ScopingPropertyOutputReference;
        putScoping(value: ScopingProperty): void;
        resetScoping(): void;
        get scopingInput(): ScopingProperty | undefined;
    }
    interface ScheduleFrequencyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#daily_schedule TfClassificationJob#daily_schedule}
        */
        readonly dailySchedule?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#monthly_schedule TfClassificationJob#monthly_schedule}
        */
        readonly monthlySchedule?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#weekly_schedule TfClassificationJob#weekly_schedule}
        */
        readonly weeklySchedule?: string;
    }
    class ScheduleFrequencyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ScheduleFrequencyProperty | undefined;
        set internalValue(value: ScheduleFrequencyProperty | undefined);
        private _dailySchedule?;
        get dailySchedule(): boolean | cdktn.IResolvable;
        set dailySchedule(value: boolean | cdktn.IResolvable);
        resetDailySchedule(): void;
        get dailyScheduleInput(): boolean | cdktn.IResolvable | undefined;
        private _monthlySchedule?;
        get monthlySchedule(): number;
        set monthlySchedule(value: number);
        resetMonthlySchedule(): void;
        get monthlyScheduleInput(): number | undefined;
        private _weeklySchedule?;
        get weeklySchedule(): string;
        set weeklySchedule(value: string);
        resetWeeklySchedule(): void;
        get weeklyScheduleInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#create TfClassificationJob#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/macie2_classification_job#update TfClassificationJob#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
