import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsInstanceProfileConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_instance_profile#description AwsInstanceProfile#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_instance_profile#exclude_app_packages_from_cleanup AwsInstanceProfile#exclude_app_packages_from_cleanup}
    */
    readonly excludeAppPackagesFromCleanup?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_instance_profile#id AwsInstanceProfile#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_instance_profile#name AwsInstanceProfile#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_instance_profile#package_cleanup AwsInstanceProfile#package_cleanup}
    */
    readonly packageCleanup?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_instance_profile#reboot_after_use AwsInstanceProfile#reboot_after_use}
    */
    readonly rebootAfterUse?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_instance_profile#region AwsInstanceProfile#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_instance_profile#tags AwsInstanceProfile#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_instance_profile#tags_all AwsInstanceProfile#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_instance_profile aws_devicefarm_instance_profile}
*/
export declare class AwsInstanceProfile extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_devicefarm_instance_profile";
    /**
    * Generates CDKTN code for importing a AwsInstanceProfile resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsInstanceProfile to import
    * @param importFromId The id of the existing AwsInstanceProfile that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_instance_profile#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsInstanceProfile to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/devicefarm_instance_profile aws_devicefarm_instance_profile} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsInstanceProfileConfig
    */
    constructor(scope: Construct, id: string, config: AwsInstanceProfileConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _excludeAppPackagesFromCleanup?;
    get excludeAppPackagesFromCleanup(): string[];
    set excludeAppPackagesFromCleanup(value: string[]);
    resetExcludeAppPackagesFromCleanup(): void;
    get excludeAppPackagesFromCleanupInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _packageCleanup?;
    get packageCleanup(): boolean | cdktn.IResolvable;
    set packageCleanup(value: boolean | cdktn.IResolvable);
    resetPackageCleanup(): void;
    get packageCleanupInput(): boolean | cdktn.IResolvable | undefined;
    private _rebootAfterUse?;
    get rebootAfterUse(): boolean | cdktn.IResolvable;
    set rebootAfterUse(value: boolean | cdktn.IResolvable);
    resetRebootAfterUse(): void;
    get rebootAfterUseInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
