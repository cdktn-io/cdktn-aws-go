import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfNotificationHubConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/notifications_notification_hub#notification_hub_region TfNotificationHub#notification_hub_region}
    */
    readonly notificationHubRegion: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/notifications_notification_hub#timeouts TfNotificationHub#timeouts}
    */
    readonly timeouts?: TfNotificationHub.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/notifications_notification_hub aws_notifications_notification_hub}
*/
export declare class TfNotificationHub extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_notifications_notification_hub";
    /**
    * Generates CDKTN code for importing a TfNotificationHub resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfNotificationHub to import
    * @param importFromId The id of the existing TfNotificationHub that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/notifications_notification_hub#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfNotificationHub to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/notifications_notification_hub aws_notifications_notification_hub} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfNotificationHubConfig
    */
    constructor(scope: Construct, id: string, config: TfNotificationHubConfig);
    private _notificationHubRegion?;
    get notificationHubRegion(): string;
    set notificationHubRegion(value: string);
    get notificationHubRegionInput(): string | undefined;
    private _timeouts;
    get timeouts(): TfNotificationHub.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfNotificationHub.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfNotificationHub.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfNotificationHubTimeoutsPropertyToTerraform(struct?: TfNotificationHub.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfNotificationHubTimeoutsPropertyToHclTerraform(struct?: TfNotificationHub.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfNotificationHub {
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/notifications_notification_hub#create TfNotificationHub#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/notifications_notification_hub#delete TfNotificationHub#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
