import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfManagedNotificationAdditionalChannelAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/notifications_managed_notification_additional_channel_association#channel_arn TfManagedNotificationAdditionalChannelAssociation#channel_arn}
    */
    readonly channelArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/notifications_managed_notification_additional_channel_association#managed_notification_arn TfManagedNotificationAdditionalChannelAssociation#managed_notification_arn}
    */
    readonly managedNotificationArn: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/notifications_managed_notification_additional_channel_association aws_notifications_managed_notification_additional_channel_association}
*/
export declare class TfManagedNotificationAdditionalChannelAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_notifications_managed_notification_additional_channel_association";
    /**
    * Generates CDKTN code for importing a TfManagedNotificationAdditionalChannelAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfManagedNotificationAdditionalChannelAssociation to import
    * @param importFromId The id of the existing TfManagedNotificationAdditionalChannelAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/notifications_managed_notification_additional_channel_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfManagedNotificationAdditionalChannelAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/notifications_managed_notification_additional_channel_association aws_notifications_managed_notification_additional_channel_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfManagedNotificationAdditionalChannelAssociationConfig
    */
    constructor(scope: Construct, id: string, config: TfManagedNotificationAdditionalChannelAssociationConfig);
    private _channelArn?;
    get channelArn(): string;
    set channelArn(value: string);
    get channelArnInput(): string | undefined;
    private _managedNotificationArn?;
    get managedNotificationArn(): string;
    set managedNotificationArn(value: string);
    get managedNotificationArnInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
