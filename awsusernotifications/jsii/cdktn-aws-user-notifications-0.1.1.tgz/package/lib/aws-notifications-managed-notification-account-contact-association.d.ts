import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsNotificationsManagedNotificationAccountContactAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/notifications_managed_notification_account_contact_association#contact_identifier AwsNotificationsManagedNotificationAccountContactAssociation#contact_identifier}
    */
    readonly contactIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/notifications_managed_notification_account_contact_association#managed_notification_configuration_arn AwsNotificationsManagedNotificationAccountContactAssociation#managed_notification_configuration_arn}
    */
    readonly managedNotificationConfigurationArn: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/notifications_managed_notification_account_contact_association aws_notifications_managed_notification_account_contact_association}
*/
export declare class AwsNotificationsManagedNotificationAccountContactAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_notifications_managed_notification_account_contact_association";
    /**
    * Generates CDKTN code for importing a AwsNotificationsManagedNotificationAccountContactAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsNotificationsManagedNotificationAccountContactAssociation to import
    * @param importFromId The id of the existing AwsNotificationsManagedNotificationAccountContactAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/notifications_managed_notification_account_contact_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsNotificationsManagedNotificationAccountContactAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/notifications_managed_notification_account_contact_association aws_notifications_managed_notification_account_contact_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsNotificationsManagedNotificationAccountContactAssociationConfig
    */
    constructor(scope: Construct, id: string, config: AwsNotificationsManagedNotificationAccountContactAssociationConfig);
    private _contactIdentifier?;
    get contactIdentifier(): string;
    set contactIdentifier(value: string);
    get contactIdentifierInput(): string | undefined;
    private _managedNotificationConfigurationArn?;
    get managedNotificationConfigurationArn(): string;
    set managedNotificationConfigurationArn(value: string);
    get managedNotificationConfigurationArnInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
