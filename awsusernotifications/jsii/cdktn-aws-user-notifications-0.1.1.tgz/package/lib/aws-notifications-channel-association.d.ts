import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsNotificationsChannelAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/notifications_channel_association#arn AwsNotificationsChannelAssociation#arn}
    */
    readonly arn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/notifications_channel_association#notification_configuration_arn AwsNotificationsChannelAssociation#notification_configuration_arn}
    */
    readonly notificationConfigurationArn: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/notifications_channel_association aws_notifications_channel_association}
*/
export declare class AwsNotificationsChannelAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_notifications_channel_association";
    /**
    * Generates CDKTN code for importing a AwsNotificationsChannelAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsNotificationsChannelAssociation to import
    * @param importFromId The id of the existing AwsNotificationsChannelAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/notifications_channel_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsNotificationsChannelAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/notifications_channel_association aws_notifications_channel_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsNotificationsChannelAssociationConfig
    */
    constructor(scope: Construct, id: string, config: AwsNotificationsChannelAssociationConfig);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    get arnInput(): string | undefined;
    private _notificationConfigurationArn?;
    get notificationConfigurationArn(): string;
    set notificationConfigurationArn(value: string);
    get notificationConfigurationArnInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
