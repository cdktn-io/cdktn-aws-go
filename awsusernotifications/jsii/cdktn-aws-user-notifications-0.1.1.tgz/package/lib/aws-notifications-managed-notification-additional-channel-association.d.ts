import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsNotificationsManagedNotificationAdditionalChannelAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/notifications_managed_notification_additional_channel_association#channel_arn AwsNotificationsManagedNotificationAdditionalChannelAssociation#channel_arn}
    */
    readonly channelArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/notifications_managed_notification_additional_channel_association#managed_notification_arn AwsNotificationsManagedNotificationAdditionalChannelAssociation#managed_notification_arn}
    */
    readonly managedNotificationArn: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/notifications_managed_notification_additional_channel_association aws_notifications_managed_notification_additional_channel_association}
*/
export declare class AwsNotificationsManagedNotificationAdditionalChannelAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_notifications_managed_notification_additional_channel_association";
    /**
    * Generates CDKTN code for importing a AwsNotificationsManagedNotificationAdditionalChannelAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsNotificationsManagedNotificationAdditionalChannelAssociation to import
    * @param importFromId The id of the existing AwsNotificationsManagedNotificationAdditionalChannelAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/notifications_managed_notification_additional_channel_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsNotificationsManagedNotificationAdditionalChannelAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/notifications_managed_notification_additional_channel_association aws_notifications_managed_notification_additional_channel_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsNotificationsManagedNotificationAdditionalChannelAssociationConfig
    */
    constructor(scope: Construct, id: string, config: AwsNotificationsManagedNotificationAdditionalChannelAssociationConfig);
    private _channelArn?;
    get channelArn(): string;
    set channelArn(value: string);
    get channelArnInput(): string | undefined;
    private _managedNotificationArn?;
    get managedNotificationArn(): string;
    set managedNotificationArn(value: string);
    get managedNotificationArnInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
