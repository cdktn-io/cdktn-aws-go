import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAmplifyAppConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_app#access_token AwsAmplifyApp#access_token}
    */
    readonly accessToken?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_app#auto_branch_creation_patterns AwsAmplifyApp#auto_branch_creation_patterns}
    */
    readonly autoBranchCreationPatterns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_app#basic_auth_credentials AwsAmplifyApp#basic_auth_credentials}
    */
    readonly basicAuthCredentials?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_app#build_spec AwsAmplifyApp#build_spec}
    */
    readonly buildSpec?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_app#compute_role_arn AwsAmplifyApp#compute_role_arn}
    */
    readonly computeRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_app#custom_headers AwsAmplifyApp#custom_headers}
    */
    readonly customHeaders?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_app#description AwsAmplifyApp#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_app#enable_auto_branch_creation AwsAmplifyApp#enable_auto_branch_creation}
    */
    readonly enableAutoBranchCreation?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_app#enable_basic_auth AwsAmplifyApp#enable_basic_auth}
    */
    readonly enableBasicAuth?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_app#enable_branch_auto_build AwsAmplifyApp#enable_branch_auto_build}
    */
    readonly enableBranchAutoBuild?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_app#enable_branch_auto_deletion AwsAmplifyApp#enable_branch_auto_deletion}
    */
    readonly enableBranchAutoDeletion?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_app#environment_variables AwsAmplifyApp#environment_variables}
    */
    readonly environmentVariables?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_app#iam_service_role_arn AwsAmplifyApp#iam_service_role_arn}
    */
    readonly iamServiceRoleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_app#id AwsAmplifyApp#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_app#name AwsAmplifyApp#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_app#oauth_token AwsAmplifyApp#oauth_token}
    */
    readonly oauthToken?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_app#platform AwsAmplifyApp#platform}
    */
    readonly platform?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_app#region AwsAmplifyApp#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_app#repository AwsAmplifyApp#repository}
    */
    readonly repository?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_app#tags AwsAmplifyApp#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_app#tags_all AwsAmplifyApp#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * auto_branch_creation_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_app#auto_branch_creation_config AwsAmplifyApp#auto_branch_creation_config}
    */
    readonly autoBranchCreationConfig?: AwsAmplifyApp.AutoBranchCreationConfigProperty;
    /**
    * cache_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_app#cache_config AwsAmplifyApp#cache_config}
    */
    readonly cacheConfig?: AwsAmplifyApp.CacheConfigProperty;
    /**
    * custom_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_app#custom_rule AwsAmplifyApp#custom_rule}
    */
    readonly customRule?: AwsAmplifyApp.CustomRuleProperty[] | cdktn.IResolvable;
    /**
    * job_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_app#job_config AwsAmplifyApp#job_config}
    */
    readonly jobConfig?: AwsAmplifyApp.JobConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_app aws_amplify_app}
*/
export declare class AwsAmplifyApp extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_amplify_app";
    /**
    * Generates CDKTN code for importing a AwsAmplifyApp resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAmplifyApp to import
    * @param importFromId The id of the existing AwsAmplifyApp that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_app#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAmplifyApp to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_app aws_amplify_app} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAmplifyAppConfig
    */
    constructor(scope: Construct, id: string, config: AwsAmplifyAppConfig);
    private _accessToken?;
    get accessToken(): string;
    set accessToken(value: string);
    resetAccessToken(): void;
    get accessTokenInput(): string | undefined;
    get arn(): string;
    private _autoBranchCreationPatterns?;
    get autoBranchCreationPatterns(): string[];
    set autoBranchCreationPatterns(value: string[]);
    resetAutoBranchCreationPatterns(): void;
    get autoBranchCreationPatternsInput(): string[] | undefined;
    private _basicAuthCredentials?;
    get basicAuthCredentials(): string;
    set basicAuthCredentials(value: string);
    resetBasicAuthCredentials(): void;
    get basicAuthCredentialsInput(): string | undefined;
    private _buildSpec?;
    get buildSpec(): string;
    set buildSpec(value: string);
    resetBuildSpec(): void;
    get buildSpecInput(): string | undefined;
    private _computeRoleArn?;
    get computeRoleArn(): string;
    set computeRoleArn(value: string);
    resetComputeRoleArn(): void;
    get computeRoleArnInput(): string | undefined;
    private _customHeaders?;
    get customHeaders(): string;
    set customHeaders(value: string);
    resetCustomHeaders(): void;
    get customHeadersInput(): string | undefined;
    get defaultDomain(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enableAutoBranchCreation?;
    get enableAutoBranchCreation(): boolean | cdktn.IResolvable;
    set enableAutoBranchCreation(value: boolean | cdktn.IResolvable);
    resetEnableAutoBranchCreation(): void;
    get enableAutoBranchCreationInput(): boolean | cdktn.IResolvable | undefined;
    private _enableBasicAuth?;
    get enableBasicAuth(): boolean | cdktn.IResolvable;
    set enableBasicAuth(value: boolean | cdktn.IResolvable);
    resetEnableBasicAuth(): void;
    get enableBasicAuthInput(): boolean | cdktn.IResolvable | undefined;
    private _enableBranchAutoBuild?;
    get enableBranchAutoBuild(): boolean | cdktn.IResolvable;
    set enableBranchAutoBuild(value: boolean | cdktn.IResolvable);
    resetEnableBranchAutoBuild(): void;
    get enableBranchAutoBuildInput(): boolean | cdktn.IResolvable | undefined;
    private _enableBranchAutoDeletion?;
    get enableBranchAutoDeletion(): boolean | cdktn.IResolvable;
    set enableBranchAutoDeletion(value: boolean | cdktn.IResolvable);
    resetEnableBranchAutoDeletion(): void;
    get enableBranchAutoDeletionInput(): boolean | cdktn.IResolvable | undefined;
    private _environmentVariables?;
    get environmentVariables(): {
        [key: string]: string;
    };
    set environmentVariables(value: {
        [key: string]: string;
    });
    resetEnvironmentVariables(): void;
    get environmentVariablesInput(): {
        [key: string]: string;
    } | undefined;
    private _iamServiceRoleArn?;
    get iamServiceRoleArn(): string;
    set iamServiceRoleArn(value: string);
    resetIamServiceRoleArn(): void;
    get iamServiceRoleArnInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _oauthToken?;
    get oauthToken(): string;
    set oauthToken(value: string);
    resetOauthToken(): void;
    get oauthTokenInput(): string | undefined;
    private _platform?;
    get platform(): string;
    set platform(value: string);
    resetPlatform(): void;
    get platformInput(): string | undefined;
    private _productionBranch;
    get productionBranch(): AwsAmplifyApp.ProductionBranchPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _repository?;
    get repository(): string;
    set repository(value: string);
    resetRepository(): void;
    get repositoryInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _autoBranchCreationConfig;
    get autoBranchCreationConfig(): AwsAmplifyApp.AutoBranchCreationConfigPropertyOutputReference;
    putAutoBranchCreationConfig(value: AwsAmplifyApp.AutoBranchCreationConfigProperty): void;
    resetAutoBranchCreationConfig(): void;
    get autoBranchCreationConfigInput(): AwsAmplifyApp.AutoBranchCreationConfigProperty | undefined;
    private _cacheConfig;
    get cacheConfig(): AwsAmplifyApp.CacheConfigPropertyOutputReference;
    putCacheConfig(value: AwsAmplifyApp.CacheConfigProperty): void;
    resetCacheConfig(): void;
    get cacheConfigInput(): AwsAmplifyApp.CacheConfigProperty | undefined;
    private _customRule;
    get customRule(): AwsAmplifyApp.CustomRulePropertyList;
    putCustomRule(value: AwsAmplifyApp.CustomRuleProperty[] | cdktn.IResolvable): void;
    resetCustomRule(): void;
    get customRuleInput(): cdktn.IResolvable | AwsAmplifyApp.CustomRuleProperty[] | undefined;
    private _jobConfig;
    get jobConfig(): AwsAmplifyApp.JobConfigPropertyOutputReference;
    putJobConfig(value: AwsAmplifyApp.JobConfigProperty): void;
    resetJobConfig(): void;
    get jobConfigInput(): AwsAmplifyApp.JobConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsAmplifyAppProductionBranchPropertyToTerraform(struct?: AwsAmplifyApp.ProductionBranchProperty): any;
export declare function awsAmplifyAppProductionBranchPropertyToHclTerraform(struct?: AwsAmplifyApp.ProductionBranchProperty): any;
export declare function awsAmplifyAppAutoBranchCreationConfigPropertyToTerraform(struct?: AwsAmplifyApp.AutoBranchCreationConfigPropertyOutputReference | AwsAmplifyApp.AutoBranchCreationConfigProperty): any;
export declare function awsAmplifyAppAutoBranchCreationConfigPropertyToHclTerraform(struct?: AwsAmplifyApp.AutoBranchCreationConfigPropertyOutputReference | AwsAmplifyApp.AutoBranchCreationConfigProperty): any;
export declare function awsAmplifyAppCacheConfigPropertyToTerraform(struct?: AwsAmplifyApp.CacheConfigPropertyOutputReference | AwsAmplifyApp.CacheConfigProperty): any;
export declare function awsAmplifyAppCacheConfigPropertyToHclTerraform(struct?: AwsAmplifyApp.CacheConfigPropertyOutputReference | AwsAmplifyApp.CacheConfigProperty): any;
export declare function awsAmplifyAppCustomRulePropertyToTerraform(struct?: AwsAmplifyApp.CustomRuleProperty | cdktn.IResolvable): any;
export declare function awsAmplifyAppCustomRulePropertyToHclTerraform(struct?: AwsAmplifyApp.CustomRuleProperty | cdktn.IResolvable): any;
export declare function awsAmplifyAppJobConfigPropertyToTerraform(struct?: AwsAmplifyApp.JobConfigPropertyOutputReference | AwsAmplifyApp.JobConfigProperty): any;
export declare function awsAmplifyAppJobConfigPropertyToHclTerraform(struct?: AwsAmplifyApp.JobConfigPropertyOutputReference | AwsAmplifyApp.JobConfigProperty): any;
export declare namespace AwsAmplifyApp {
    interface ProductionBranchProperty {
    }
    class ProductionBranchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ProductionBranchProperty | undefined;
        set internalValue(value: ProductionBranchProperty | undefined);
        get branchName(): string;
        get lastDeployTime(): string;
        get status(): string;
        get thumbnailUrl(): string;
    }
    class ProductionBranchPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ProductionBranchPropertyOutputReference;
    }
    interface AutoBranchCreationConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_app#basic_auth_credentials AwsAmplifyApp#basic_auth_credentials}
        */
        readonly basicAuthCredentials?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_app#build_spec AwsAmplifyApp#build_spec}
        */
        readonly buildSpec?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_app#enable_auto_build AwsAmplifyApp#enable_auto_build}
        */
        readonly enableAutoBuild?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_app#enable_basic_auth AwsAmplifyApp#enable_basic_auth}
        */
        readonly enableBasicAuth?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_app#enable_performance_mode AwsAmplifyApp#enable_performance_mode}
        */
        readonly enablePerformanceMode?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_app#enable_pull_request_preview AwsAmplifyApp#enable_pull_request_preview}
        */
        readonly enablePullRequestPreview?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_app#environment_variables AwsAmplifyApp#environment_variables}
        */
        readonly environmentVariables?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_app#framework AwsAmplifyApp#framework}
        */
        readonly framework?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_app#pull_request_environment_name AwsAmplifyApp#pull_request_environment_name}
        */
        readonly pullRequestEnvironmentName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_app#stage AwsAmplifyApp#stage}
        */
        readonly stage?: string;
    }
    class AutoBranchCreationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AutoBranchCreationConfigProperty | undefined;
        set internalValue(value: AutoBranchCreationConfigProperty | undefined);
        private _basicAuthCredentials?;
        get basicAuthCredentials(): string;
        set basicAuthCredentials(value: string);
        resetBasicAuthCredentials(): void;
        get basicAuthCredentialsInput(): string | undefined;
        private _buildSpec?;
        get buildSpec(): string;
        set buildSpec(value: string);
        resetBuildSpec(): void;
        get buildSpecInput(): string | undefined;
        private _enableAutoBuild?;
        get enableAutoBuild(): boolean | cdktn.IResolvable;
        set enableAutoBuild(value: boolean | cdktn.IResolvable);
        resetEnableAutoBuild(): void;
        get enableAutoBuildInput(): boolean | cdktn.IResolvable | undefined;
        private _enableBasicAuth?;
        get enableBasicAuth(): boolean | cdktn.IResolvable;
        set enableBasicAuth(value: boolean | cdktn.IResolvable);
        resetEnableBasicAuth(): void;
        get enableBasicAuthInput(): boolean | cdktn.IResolvable | undefined;
        private _enablePerformanceMode?;
        get enablePerformanceMode(): boolean | cdktn.IResolvable;
        set enablePerformanceMode(value: boolean | cdktn.IResolvable);
        resetEnablePerformanceMode(): void;
        get enablePerformanceModeInput(): boolean | cdktn.IResolvable | undefined;
        private _enablePullRequestPreview?;
        get enablePullRequestPreview(): boolean | cdktn.IResolvable;
        set enablePullRequestPreview(value: boolean | cdktn.IResolvable);
        resetEnablePullRequestPreview(): void;
        get enablePullRequestPreviewInput(): boolean | cdktn.IResolvable | undefined;
        private _environmentVariables?;
        get environmentVariables(): {
            [key: string]: string;
        };
        set environmentVariables(value: {
            [key: string]: string;
        });
        resetEnvironmentVariables(): void;
        get environmentVariablesInput(): {
            [key: string]: string;
        } | undefined;
        private _framework?;
        get framework(): string;
        set framework(value: string);
        resetFramework(): void;
        get frameworkInput(): string | undefined;
        private _pullRequestEnvironmentName?;
        get pullRequestEnvironmentName(): string;
        set pullRequestEnvironmentName(value: string);
        resetPullRequestEnvironmentName(): void;
        get pullRequestEnvironmentNameInput(): string | undefined;
        private _stage?;
        get stage(): string;
        set stage(value: string);
        resetStage(): void;
        get stageInput(): string | undefined;
    }
    interface CacheConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_app#type AwsAmplifyApp#type}
        */
        readonly type: string;
    }
    class CacheConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CacheConfigProperty | undefined;
        set internalValue(value: CacheConfigProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    interface CustomRuleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_app#condition AwsAmplifyApp#condition}
        */
        readonly condition?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_app#source AwsAmplifyApp#source}
        */
        readonly source: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_app#status AwsAmplifyApp#status}
        */
        readonly status?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_app#target AwsAmplifyApp#target}
        */
        readonly target: string;
    }
    class CustomRulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomRuleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CustomRuleProperty | cdktn.IResolvable | undefined);
        private _condition?;
        get condition(): string;
        set condition(value: string);
        resetCondition(): void;
        get conditionInput(): string | undefined;
        private _source?;
        get source(): string;
        set source(value: string);
        get sourceInput(): string | undefined;
        private _status?;
        get status(): string;
        set status(value: string);
        resetStatus(): void;
        get statusInput(): string | undefined;
        private _target?;
        get target(): string;
        set target(value: string);
        get targetInput(): string | undefined;
    }
    class CustomRulePropertyList extends cdktn.ComplexList {
        internalValue?: CustomRuleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomRulePropertyOutputReference;
    }
    interface JobConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_app#build_compute_type AwsAmplifyApp#build_compute_type}
        */
        readonly buildComputeType?: string;
    }
    class JobConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): JobConfigProperty | undefined;
        set internalValue(value: JobConfigProperty | undefined);
        private _buildComputeType?;
        get buildComputeType(): string;
        set buildComputeType(value: string);
        resetBuildComputeType(): void;
        get buildComputeTypeInput(): string | undefined;
    }
}
