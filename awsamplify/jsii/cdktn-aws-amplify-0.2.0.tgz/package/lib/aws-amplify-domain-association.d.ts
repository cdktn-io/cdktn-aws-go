import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfDomainAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_domain_association#app_id TfDomainAssociation#app_id}
    */
    readonly appId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_domain_association#domain_name TfDomainAssociation#domain_name}
    */
    readonly domainName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_domain_association#enable_auto_sub_domain TfDomainAssociation#enable_auto_sub_domain}
    */
    readonly enableAutoSubDomain?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_domain_association#id TfDomainAssociation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_domain_association#region TfDomainAssociation#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_domain_association#wait_for_verification TfDomainAssociation#wait_for_verification}
    */
    readonly waitForVerification?: boolean | cdktn.IResolvable;
    /**
    * certificate_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_domain_association#certificate_settings TfDomainAssociation#certificate_settings}
    */
    readonly certificateSettings?: TfDomainAssociation.CertificateSettingsProperty;
    /**
    * sub_domain block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_domain_association#sub_domain TfDomainAssociation#sub_domain}
    */
    readonly subDomain: TfDomainAssociation.SubDomainProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_domain_association aws_amplify_domain_association}
*/
export declare class TfDomainAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_amplify_domain_association";
    /**
    * Generates CDKTN code for importing a TfDomainAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfDomainAssociation to import
    * @param importFromId The id of the existing TfDomainAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_domain_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfDomainAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_domain_association aws_amplify_domain_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfDomainAssociationConfig
    */
    constructor(scope: Construct, id: string, config: TfDomainAssociationConfig);
    private _appId?;
    get appId(): string;
    set appId(value: string);
    get appIdInput(): string | undefined;
    get arn(): string;
    get certificateVerificationDnsRecord(): string;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    private _enableAutoSubDomain?;
    get enableAutoSubDomain(): boolean | cdktn.IResolvable;
    set enableAutoSubDomain(value: boolean | cdktn.IResolvable);
    resetEnableAutoSubDomain(): void;
    get enableAutoSubDomainInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _waitForVerification?;
    get waitForVerification(): boolean | cdktn.IResolvable;
    set waitForVerification(value: boolean | cdktn.IResolvable);
    resetWaitForVerification(): void;
    get waitForVerificationInput(): boolean | cdktn.IResolvable | undefined;
    private _certificateSettings;
    get certificateSettings(): TfDomainAssociation.CertificateSettingsPropertyOutputReference;
    putCertificateSettings(value: TfDomainAssociation.CertificateSettingsProperty): void;
    resetCertificateSettings(): void;
    get certificateSettingsInput(): TfDomainAssociation.CertificateSettingsProperty | undefined;
    private _subDomain;
    get subDomain(): TfDomainAssociation.SubDomainPropertyList;
    putSubDomain(value: TfDomainAssociation.SubDomainProperty[] | cdktn.IResolvable): void;
    get subDomainInput(): cdktn.IResolvable | TfDomainAssociation.SubDomainProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfDomainAssociationCertificateSettingsPropertyToTerraform(struct?: TfDomainAssociation.CertificateSettingsPropertyOutputReference | TfDomainAssociation.CertificateSettingsProperty): any;
export declare function tfDomainAssociationCertificateSettingsPropertyToHclTerraform(struct?: TfDomainAssociation.CertificateSettingsPropertyOutputReference | TfDomainAssociation.CertificateSettingsProperty): any;
export declare function tfDomainAssociationSubDomainPropertyToTerraform(struct?: TfDomainAssociation.SubDomainProperty | cdktn.IResolvable): any;
export declare function tfDomainAssociationSubDomainPropertyToHclTerraform(struct?: TfDomainAssociation.SubDomainProperty | cdktn.IResolvable): any;
export declare namespace TfDomainAssociation {
    interface CertificateSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_domain_association#custom_certificate_arn TfDomainAssociation#custom_certificate_arn}
        */
        readonly customCertificateArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_domain_association#type TfDomainAssociation#type}
        */
        readonly type: string;
    }
    class CertificateSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CertificateSettingsProperty | undefined;
        set internalValue(value: CertificateSettingsProperty | undefined);
        get certificateVerificationDnsRecord(): string;
        private _customCertificateArn?;
        get customCertificateArn(): string;
        set customCertificateArn(value: string);
        resetCustomCertificateArn(): void;
        get customCertificateArnInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    interface SubDomainProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_domain_association#branch_name TfDomainAssociation#branch_name}
        */
        readonly branchName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/amplify_domain_association#prefix TfDomainAssociation#prefix}
        */
        readonly prefix: string;
    }
    class SubDomainPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SubDomainProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SubDomainProperty | cdktn.IResolvable | undefined);
        private _branchName?;
        get branchName(): string;
        set branchName(value: string);
        get branchNameInput(): string | undefined;
        get dnsRecord(): string;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        get prefixInput(): string | undefined;
        get verified(): cdktn.IResolvable;
    }
    class SubDomainPropertyList extends cdktn.ComplexList {
        internalValue?: SubDomainProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SubDomainPropertyOutputReference;
    }
}
