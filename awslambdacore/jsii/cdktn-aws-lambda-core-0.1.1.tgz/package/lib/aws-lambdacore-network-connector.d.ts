import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsLambdacoreNetworkConnectorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambdacore_network_connector#name AwsLambdacoreNetworkConnector#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambdacore_network_connector#operator_role AwsLambdacoreNetworkConnector#operator_role}
    */
    readonly operatorRole: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambdacore_network_connector#region AwsLambdacoreNetworkConnector#region}
    */
    readonly region?: string;
    /**
    * configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambdacore_network_connector#configuration AwsLambdacoreNetworkConnector#configuration}
    */
    readonly configuration?: AwsLambdacoreNetworkConnector.ConfigurationProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambdacore_network_connector#timeouts AwsLambdacoreNetworkConnector#timeouts}
    */
    readonly timeouts?: AwsLambdacoreNetworkConnector.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambdacore_network_connector aws_lambdacore_network_connector}
*/
export declare class AwsLambdacoreNetworkConnector extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_lambdacore_network_connector";
    /**
    * Generates CDKTN code for importing a AwsLambdacoreNetworkConnector resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsLambdacoreNetworkConnector to import
    * @param importFromId The id of the existing AwsLambdacoreNetworkConnector that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambdacore_network_connector#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsLambdacoreNetworkConnector to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambdacore_network_connector aws_lambdacore_network_connector} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsLambdacoreNetworkConnectorConfig
    */
    constructor(scope: Construct, id: string, config: AwsLambdacoreNetworkConnectorConfig);
    get arn(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _operatorRole?;
    get operatorRole(): string;
    set operatorRole(value: string);
    get operatorRoleInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _configuration;
    get configuration(): AwsLambdacoreNetworkConnector.ConfigurationPropertyList;
    putConfiguration(value: AwsLambdacoreNetworkConnector.ConfigurationProperty[] | cdktn.IResolvable): void;
    resetConfiguration(): void;
    get configurationInput(): cdktn.IResolvable | AwsLambdacoreNetworkConnector.ConfigurationProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsLambdacoreNetworkConnector.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsLambdacoreNetworkConnector.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsLambdacoreNetworkConnector.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsLambdacoreNetworkConnectorVpcEgressConfigurationPropertyToTerraform(struct?: AwsLambdacoreNetworkConnector.VpcEgressConfigurationProperty | cdktn.IResolvable): any;
export declare function awsLambdacoreNetworkConnectorVpcEgressConfigurationPropertyToHclTerraform(struct?: AwsLambdacoreNetworkConnector.VpcEgressConfigurationProperty | cdktn.IResolvable): any;
export declare function awsLambdacoreNetworkConnectorConfigurationPropertyToTerraform(struct?: AwsLambdacoreNetworkConnector.ConfigurationProperty | cdktn.IResolvable): any;
export declare function awsLambdacoreNetworkConnectorConfigurationPropertyToHclTerraform(struct?: AwsLambdacoreNetworkConnector.ConfigurationProperty | cdktn.IResolvable): any;
export declare function awsLambdacoreNetworkConnectorTimeoutsPropertyToTerraform(struct?: AwsLambdacoreNetworkConnector.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsLambdacoreNetworkConnectorTimeoutsPropertyToHclTerraform(struct?: AwsLambdacoreNetworkConnector.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsLambdacoreNetworkConnector {
    interface VpcEgressConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambdacore_network_connector#associated_compute_resource_types AwsLambdacoreNetworkConnector#associated_compute_resource_types}
        */
        readonly associatedComputeResourceTypes: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambdacore_network_connector#network_protocol AwsLambdacoreNetworkConnector#network_protocol}
        */
        readonly networkProtocol?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambdacore_network_connector#security_group_ids AwsLambdacoreNetworkConnector#security_group_ids}
        */
        readonly securityGroupIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambdacore_network_connector#subnet_ids AwsLambdacoreNetworkConnector#subnet_ids}
        */
        readonly subnetIds: string[];
    }
    class VpcEgressConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpcEgressConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: VpcEgressConfigurationProperty | cdktn.IResolvable | undefined);
        private _associatedComputeResourceTypes?;
        get associatedComputeResourceTypes(): string[];
        set associatedComputeResourceTypes(value: string[]);
        get associatedComputeResourceTypesInput(): string[] | undefined;
        private _networkProtocol?;
        get networkProtocol(): string;
        set networkProtocol(value: string);
        resetNetworkProtocol(): void;
        get networkProtocolInput(): string | undefined;
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        get subnetIdsInput(): string[] | undefined;
    }
    class VpcEgressConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: VpcEgressConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpcEgressConfigurationPropertyOutputReference;
    }
    interface ConfigurationProperty {
        /**
        * vpc_egress_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambdacore_network_connector#vpc_egress_configuration AwsLambdacoreNetworkConnector#vpc_egress_configuration}
        */
        readonly vpcEgressConfiguration?: VpcEgressConfigurationProperty[] | cdktn.IResolvable;
    }
    class ConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConfigurationProperty | cdktn.IResolvable | undefined);
        private _vpcEgressConfiguration;
        get vpcEgressConfiguration(): VpcEgressConfigurationPropertyList;
        putVpcEgressConfiguration(value: VpcEgressConfigurationProperty[] | cdktn.IResolvable): void;
        resetVpcEgressConfiguration(): void;
        get vpcEgressConfigurationInput(): cdktn.IResolvable | VpcEgressConfigurationProperty[] | undefined;
    }
    class ConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConfigurationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambdacore_network_connector#create AwsLambdacoreNetworkConnector#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambdacore_network_connector#delete AwsLambdacoreNetworkConnector#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/lambdacore_network_connector#update AwsLambdacoreNetworkConnector#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
