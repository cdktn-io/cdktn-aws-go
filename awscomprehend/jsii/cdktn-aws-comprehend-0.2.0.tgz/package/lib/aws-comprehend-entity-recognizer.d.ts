import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfEntityRecognizerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_entity_recognizer#data_access_role_arn TfEntityRecognizer#data_access_role_arn}
    */
    readonly dataAccessRoleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_entity_recognizer#id TfEntityRecognizer#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_entity_recognizer#language_code TfEntityRecognizer#language_code}
    */
    readonly languageCode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_entity_recognizer#model_kms_key_id TfEntityRecognizer#model_kms_key_id}
    */
    readonly modelKmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_entity_recognizer#name TfEntityRecognizer#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_entity_recognizer#region TfEntityRecognizer#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_entity_recognizer#tags TfEntityRecognizer#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_entity_recognizer#tags_all TfEntityRecognizer#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_entity_recognizer#version_name TfEntityRecognizer#version_name}
    */
    readonly versionName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_entity_recognizer#version_name_prefix TfEntityRecognizer#version_name_prefix}
    */
    readonly versionNamePrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_entity_recognizer#volume_kms_key_id TfEntityRecognizer#volume_kms_key_id}
    */
    readonly volumeKmsKeyId?: string;
    /**
    * input_data_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_entity_recognizer#input_data_config TfEntityRecognizer#input_data_config}
    */
    readonly inputDataConfig: TfEntityRecognizer.InputDataConfigProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_entity_recognizer#timeouts TfEntityRecognizer#timeouts}
    */
    readonly timeouts?: TfEntityRecognizer.TimeoutsProperty;
    /**
    * vpc_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_entity_recognizer#vpc_config TfEntityRecognizer#vpc_config}
    */
    readonly vpcConfig?: TfEntityRecognizer.VpcConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_entity_recognizer aws_comprehend_entity_recognizer}
*/
export declare class TfEntityRecognizer extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_comprehend_entity_recognizer";
    /**
    * Generates CDKTN code for importing a TfEntityRecognizer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfEntityRecognizer to import
    * @param importFromId The id of the existing TfEntityRecognizer that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_entity_recognizer#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfEntityRecognizer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_entity_recognizer aws_comprehend_entity_recognizer} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfEntityRecognizerConfig
    */
    constructor(scope: Construct, id: string, config: TfEntityRecognizerConfig);
    get arn(): string;
    private _dataAccessRoleArn?;
    get dataAccessRoleArn(): string;
    set dataAccessRoleArn(value: string);
    get dataAccessRoleArnInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _languageCode?;
    get languageCode(): string;
    set languageCode(value: string);
    get languageCodeInput(): string | undefined;
    private _modelKmsKeyId?;
    get modelKmsKeyId(): string;
    set modelKmsKeyId(value: string);
    resetModelKmsKeyId(): void;
    get modelKmsKeyIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _versionName?;
    get versionName(): string;
    set versionName(value: string);
    resetVersionName(): void;
    get versionNameInput(): string | undefined;
    private _versionNamePrefix?;
    get versionNamePrefix(): string;
    set versionNamePrefix(value: string);
    resetVersionNamePrefix(): void;
    get versionNamePrefixInput(): string | undefined;
    private _volumeKmsKeyId?;
    get volumeKmsKeyId(): string;
    set volumeKmsKeyId(value: string);
    resetVolumeKmsKeyId(): void;
    get volumeKmsKeyIdInput(): string | undefined;
    private _inputDataConfig;
    get inputDataConfig(): TfEntityRecognizer.InputDataConfigPropertyOutputReference;
    putInputDataConfig(value: TfEntityRecognizer.InputDataConfigProperty): void;
    get inputDataConfigInput(): TfEntityRecognizer.InputDataConfigProperty | undefined;
    private _timeouts;
    get timeouts(): TfEntityRecognizer.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfEntityRecognizer.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfEntityRecognizer.TimeoutsProperty | undefined;
    private _vpcConfig;
    get vpcConfig(): TfEntityRecognizer.VpcConfigPropertyOutputReference;
    putVpcConfig(value: TfEntityRecognizer.VpcConfigProperty): void;
    resetVpcConfig(): void;
    get vpcConfigInput(): TfEntityRecognizer.VpcConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfEntityRecognizerAnnotationsPropertyToTerraform(struct?: TfEntityRecognizer.AnnotationsPropertyOutputReference | TfEntityRecognizer.AnnotationsProperty): any;
export declare function tfEntityRecognizerAnnotationsPropertyToHclTerraform(struct?: TfEntityRecognizer.AnnotationsPropertyOutputReference | TfEntityRecognizer.AnnotationsProperty): any;
export declare function tfEntityRecognizerAugmentedManifestsPropertyToTerraform(struct?: TfEntityRecognizer.AugmentedManifestsProperty | cdktn.IResolvable): any;
export declare function tfEntityRecognizerAugmentedManifestsPropertyToHclTerraform(struct?: TfEntityRecognizer.AugmentedManifestsProperty | cdktn.IResolvable): any;
export declare function tfEntityRecognizerDocumentsPropertyToTerraform(struct?: TfEntityRecognizer.DocumentsPropertyOutputReference | TfEntityRecognizer.DocumentsProperty): any;
export declare function tfEntityRecognizerDocumentsPropertyToHclTerraform(struct?: TfEntityRecognizer.DocumentsPropertyOutputReference | TfEntityRecognizer.DocumentsProperty): any;
export declare function tfEntityRecognizerEntityListPropertyToTerraform(struct?: TfEntityRecognizer.EntityListPropertyOutputReference | TfEntityRecognizer.EntityListProperty): any;
export declare function tfEntityRecognizerEntityListPropertyToHclTerraform(struct?: TfEntityRecognizer.EntityListPropertyOutputReference | TfEntityRecognizer.EntityListProperty): any;
export declare function tfEntityRecognizerEntityTypesPropertyToTerraform(struct?: TfEntityRecognizer.EntityTypesProperty | cdktn.IResolvable): any;
export declare function tfEntityRecognizerEntityTypesPropertyToHclTerraform(struct?: TfEntityRecognizer.EntityTypesProperty | cdktn.IResolvable): any;
export declare function tfEntityRecognizerInputDataConfigPropertyToTerraform(struct?: TfEntityRecognizer.InputDataConfigPropertyOutputReference | TfEntityRecognizer.InputDataConfigProperty): any;
export declare function tfEntityRecognizerInputDataConfigPropertyToHclTerraform(struct?: TfEntityRecognizer.InputDataConfigPropertyOutputReference | TfEntityRecognizer.InputDataConfigProperty): any;
export declare function tfEntityRecognizerTimeoutsPropertyToTerraform(struct?: TfEntityRecognizer.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfEntityRecognizerTimeoutsPropertyToHclTerraform(struct?: TfEntityRecognizer.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfEntityRecognizerVpcConfigPropertyToTerraform(struct?: TfEntityRecognizer.VpcConfigPropertyOutputReference | TfEntityRecognizer.VpcConfigProperty): any;
export declare function tfEntityRecognizerVpcConfigPropertyToHclTerraform(struct?: TfEntityRecognizer.VpcConfigPropertyOutputReference | TfEntityRecognizer.VpcConfigProperty): any;
export declare namespace TfEntityRecognizer {
    interface AnnotationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_entity_recognizer#s3_uri TfEntityRecognizer#s3_uri}
        */
        readonly s3Uri: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_entity_recognizer#test_s3_uri TfEntityRecognizer#test_s3_uri}
        */
        readonly testS3Uri?: string;
    }
    class AnnotationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AnnotationsProperty | undefined;
        set internalValue(value: AnnotationsProperty | undefined);
        private _s3Uri?;
        get s3Uri(): string;
        set s3Uri(value: string);
        get s3UriInput(): string | undefined;
        private _testS3Uri?;
        get testS3Uri(): string;
        set testS3Uri(value: string);
        resetTestS3Uri(): void;
        get testS3UriInput(): string | undefined;
    }
    interface AugmentedManifestsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_entity_recognizer#annotation_data_s3_uri TfEntityRecognizer#annotation_data_s3_uri}
        */
        readonly annotationDataS3Uri?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_entity_recognizer#attribute_names TfEntityRecognizer#attribute_names}
        */
        readonly attributeNames: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_entity_recognizer#document_type TfEntityRecognizer#document_type}
        */
        readonly documentType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_entity_recognizer#s3_uri TfEntityRecognizer#s3_uri}
        */
        readonly s3Uri: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_entity_recognizer#source_documents_s3_uri TfEntityRecognizer#source_documents_s3_uri}
        */
        readonly sourceDocumentsS3Uri?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_entity_recognizer#split TfEntityRecognizer#split}
        */
        readonly split?: string;
    }
    class AugmentedManifestsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AugmentedManifestsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AugmentedManifestsProperty | cdktn.IResolvable | undefined);
        private _annotationDataS3Uri?;
        get annotationDataS3Uri(): string;
        set annotationDataS3Uri(value: string);
        resetAnnotationDataS3Uri(): void;
        get annotationDataS3UriInput(): string | undefined;
        private _attributeNames?;
        get attributeNames(): string[];
        set attributeNames(value: string[]);
        get attributeNamesInput(): string[] | undefined;
        private _documentType?;
        get documentType(): string;
        set documentType(value: string);
        resetDocumentType(): void;
        get documentTypeInput(): string | undefined;
        private _s3Uri?;
        get s3Uri(): string;
        set s3Uri(value: string);
        get s3UriInput(): string | undefined;
        private _sourceDocumentsS3Uri?;
        get sourceDocumentsS3Uri(): string;
        set sourceDocumentsS3Uri(value: string);
        resetSourceDocumentsS3Uri(): void;
        get sourceDocumentsS3UriInput(): string | undefined;
        private _split?;
        get split(): string;
        set split(value: string);
        resetSplit(): void;
        get splitInput(): string | undefined;
    }
    class AugmentedManifestsPropertyList extends cdktn.ComplexList {
        internalValue?: AugmentedManifestsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AugmentedManifestsPropertyOutputReference;
    }
    interface DocumentsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_entity_recognizer#input_format TfEntityRecognizer#input_format}
        */
        readonly inputFormat?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_entity_recognizer#s3_uri TfEntityRecognizer#s3_uri}
        */
        readonly s3Uri: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_entity_recognizer#test_s3_uri TfEntityRecognizer#test_s3_uri}
        */
        readonly testS3Uri?: string;
    }
    class DocumentsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DocumentsProperty | undefined;
        set internalValue(value: DocumentsProperty | undefined);
        private _inputFormat?;
        get inputFormat(): string;
        set inputFormat(value: string);
        resetInputFormat(): void;
        get inputFormatInput(): string | undefined;
        private _s3Uri?;
        get s3Uri(): string;
        set s3Uri(value: string);
        get s3UriInput(): string | undefined;
        private _testS3Uri?;
        get testS3Uri(): string;
        set testS3Uri(value: string);
        resetTestS3Uri(): void;
        get testS3UriInput(): string | undefined;
    }
    interface EntityListProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_entity_recognizer#s3_uri TfEntityRecognizer#s3_uri}
        */
        readonly s3Uri: string;
    }
    class EntityListPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EntityListProperty | undefined;
        set internalValue(value: EntityListProperty | undefined);
        private _s3Uri?;
        get s3Uri(): string;
        set s3Uri(value: string);
        get s3UriInput(): string | undefined;
    }
    interface EntityTypesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_entity_recognizer#type TfEntityRecognizer#type}
        */
        readonly type: string;
    }
    class EntityTypesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EntityTypesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EntityTypesProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    class EntityTypesPropertyList extends cdktn.ComplexList {
        internalValue?: EntityTypesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EntityTypesPropertyOutputReference;
    }
    interface InputDataConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_entity_recognizer#data_format TfEntityRecognizer#data_format}
        */
        readonly dataFormat?: string;
        /**
        * annotations block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_entity_recognizer#annotations TfEntityRecognizer#annotations}
        */
        readonly annotations?: AnnotationsProperty;
        /**
        * augmented_manifests block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_entity_recognizer#augmented_manifests TfEntityRecognizer#augmented_manifests}
        */
        readonly augmentedManifests?: AugmentedManifestsProperty[] | cdktn.IResolvable;
        /**
        * documents block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_entity_recognizer#documents TfEntityRecognizer#documents}
        */
        readonly documents?: DocumentsProperty;
        /**
        * entity_list block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_entity_recognizer#entity_list TfEntityRecognizer#entity_list}
        */
        readonly entityList?: EntityListProperty;
        /**
        * entity_types block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_entity_recognizer#entity_types TfEntityRecognizer#entity_types}
        */
        readonly entityTypes: EntityTypesProperty[] | cdktn.IResolvable;
    }
    class InputDataConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InputDataConfigProperty | undefined;
        set internalValue(value: InputDataConfigProperty | undefined);
        private _dataFormat?;
        get dataFormat(): string;
        set dataFormat(value: string);
        resetDataFormat(): void;
        get dataFormatInput(): string | undefined;
        private _annotations;
        get annotations(): AnnotationsPropertyOutputReference;
        putAnnotations(value: AnnotationsProperty): void;
        resetAnnotations(): void;
        get annotationsInput(): AnnotationsProperty | undefined;
        private _augmentedManifests;
        get augmentedManifests(): AugmentedManifestsPropertyList;
        putAugmentedManifests(value: AugmentedManifestsProperty[] | cdktn.IResolvable): void;
        resetAugmentedManifests(): void;
        get augmentedManifestsInput(): cdktn.IResolvable | AugmentedManifestsProperty[] | undefined;
        private _documents;
        get documents(): DocumentsPropertyOutputReference;
        putDocuments(value: DocumentsProperty): void;
        resetDocuments(): void;
        get documentsInput(): DocumentsProperty | undefined;
        private _entityList;
        get entityList(): EntityListPropertyOutputReference;
        putEntityList(value: EntityListProperty): void;
        resetEntityList(): void;
        get entityListInput(): EntityListProperty | undefined;
        private _entityTypes;
        get entityTypes(): EntityTypesPropertyList;
        putEntityTypes(value: EntityTypesProperty[] | cdktn.IResolvable): void;
        get entityTypesInput(): cdktn.IResolvable | EntityTypesProperty[] | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_entity_recognizer#create TfEntityRecognizer#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_entity_recognizer#delete TfEntityRecognizer#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_entity_recognizer#update TfEntityRecognizer#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface VpcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_entity_recognizer#security_group_ids TfEntityRecognizer#security_group_ids}
        */
        readonly securityGroupIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_entity_recognizer#subnets TfEntityRecognizer#subnets}
        */
        readonly subnets: string[];
    }
    class VpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcConfigProperty | undefined;
        set internalValue(value: VpcConfigProperty | undefined);
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        get securityGroupIdsInput(): string[] | undefined;
        private _subnets?;
        get subnets(): string[];
        set subnets(value: string[]);
        get subnetsInput(): string[] | undefined;
    }
}
