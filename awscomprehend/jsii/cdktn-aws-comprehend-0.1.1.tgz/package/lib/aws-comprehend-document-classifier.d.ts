import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsComprehendDocumentClassifierConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_document_classifier#data_access_role_arn AwsComprehendDocumentClassifier#data_access_role_arn}
    */
    readonly dataAccessRoleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_document_classifier#id AwsComprehendDocumentClassifier#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_document_classifier#language_code AwsComprehendDocumentClassifier#language_code}
    */
    readonly languageCode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_document_classifier#mode AwsComprehendDocumentClassifier#mode}
    */
    readonly mode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_document_classifier#model_kms_key_id AwsComprehendDocumentClassifier#model_kms_key_id}
    */
    readonly modelKmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_document_classifier#name AwsComprehendDocumentClassifier#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_document_classifier#region AwsComprehendDocumentClassifier#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_document_classifier#tags AwsComprehendDocumentClassifier#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_document_classifier#tags_all AwsComprehendDocumentClassifier#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_document_classifier#version_name AwsComprehendDocumentClassifier#version_name}
    */
    readonly versionName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_document_classifier#version_name_prefix AwsComprehendDocumentClassifier#version_name_prefix}
    */
    readonly versionNamePrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_document_classifier#volume_kms_key_id AwsComprehendDocumentClassifier#volume_kms_key_id}
    */
    readonly volumeKmsKeyId?: string;
    /**
    * input_data_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_document_classifier#input_data_config AwsComprehendDocumentClassifier#input_data_config}
    */
    readonly inputDataConfig: AwsComprehendDocumentClassifier.InputDataConfigProperty;
    /**
    * output_data_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_document_classifier#output_data_config AwsComprehendDocumentClassifier#output_data_config}
    */
    readonly outputDataConfig?: AwsComprehendDocumentClassifier.OutputDataConfigProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_document_classifier#timeouts AwsComprehendDocumentClassifier#timeouts}
    */
    readonly timeouts?: AwsComprehendDocumentClassifier.TimeoutsProperty;
    /**
    * vpc_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_document_classifier#vpc_config AwsComprehendDocumentClassifier#vpc_config}
    */
    readonly vpcConfig?: AwsComprehendDocumentClassifier.VpcConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_document_classifier aws_comprehend_document_classifier}
*/
export declare class AwsComprehendDocumentClassifier extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_comprehend_document_classifier";
    /**
    * Generates CDKTN code for importing a AwsComprehendDocumentClassifier resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsComprehendDocumentClassifier to import
    * @param importFromId The id of the existing AwsComprehendDocumentClassifier that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_document_classifier#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsComprehendDocumentClassifier to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_document_classifier aws_comprehend_document_classifier} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsComprehendDocumentClassifierConfig
    */
    constructor(scope: Construct, id: string, config: AwsComprehendDocumentClassifierConfig);
    get arn(): string;
    private _dataAccessRoleArn?;
    get dataAccessRoleArn(): string;
    set dataAccessRoleArn(value: string);
    get dataAccessRoleArnInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _languageCode?;
    get languageCode(): string;
    set languageCode(value: string);
    get languageCodeInput(): string | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    resetMode(): void;
    get modeInput(): string | undefined;
    private _modelKmsKeyId?;
    get modelKmsKeyId(): string;
    set modelKmsKeyId(value: string);
    resetModelKmsKeyId(): void;
    get modelKmsKeyIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _versionName?;
    get versionName(): string;
    set versionName(value: string);
    resetVersionName(): void;
    get versionNameInput(): string | undefined;
    private _versionNamePrefix?;
    get versionNamePrefix(): string;
    set versionNamePrefix(value: string);
    resetVersionNamePrefix(): void;
    get versionNamePrefixInput(): string | undefined;
    private _volumeKmsKeyId?;
    get volumeKmsKeyId(): string;
    set volumeKmsKeyId(value: string);
    resetVolumeKmsKeyId(): void;
    get volumeKmsKeyIdInput(): string | undefined;
    private _inputDataConfig;
    get inputDataConfig(): AwsComprehendDocumentClassifier.InputDataConfigPropertyOutputReference;
    putInputDataConfig(value: AwsComprehendDocumentClassifier.InputDataConfigProperty): void;
    get inputDataConfigInput(): AwsComprehendDocumentClassifier.InputDataConfigProperty | undefined;
    private _outputDataConfig;
    get outputDataConfig(): AwsComprehendDocumentClassifier.OutputDataConfigPropertyOutputReference;
    putOutputDataConfig(value: AwsComprehendDocumentClassifier.OutputDataConfigProperty): void;
    resetOutputDataConfig(): void;
    get outputDataConfigInput(): AwsComprehendDocumentClassifier.OutputDataConfigProperty | undefined;
    private _timeouts;
    get timeouts(): AwsComprehendDocumentClassifier.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsComprehendDocumentClassifier.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): AwsComprehendDocumentClassifier.TimeoutsProperty | cdktn.IResolvable | undefined;
    private _vpcConfig;
    get vpcConfig(): AwsComprehendDocumentClassifier.VpcConfigPropertyOutputReference;
    putVpcConfig(value: AwsComprehendDocumentClassifier.VpcConfigProperty): void;
    resetVpcConfig(): void;
    get vpcConfigInput(): AwsComprehendDocumentClassifier.VpcConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsComprehendDocumentClassifierAugmentedManifestsPropertyToTerraform(struct?: AwsComprehendDocumentClassifier.AugmentedManifestsProperty | cdktn.IResolvable): any;
export declare function awsComprehendDocumentClassifierAugmentedManifestsPropertyToHclTerraform(struct?: AwsComprehendDocumentClassifier.AugmentedManifestsProperty | cdktn.IResolvable): any;
export declare function awsComprehendDocumentClassifierInputDataConfigPropertyToTerraform(struct?: AwsComprehendDocumentClassifier.InputDataConfigPropertyOutputReference | AwsComprehendDocumentClassifier.InputDataConfigProperty): any;
export declare function awsComprehendDocumentClassifierInputDataConfigPropertyToHclTerraform(struct?: AwsComprehendDocumentClassifier.InputDataConfigPropertyOutputReference | AwsComprehendDocumentClassifier.InputDataConfigProperty): any;
export declare function awsComprehendDocumentClassifierOutputDataConfigPropertyToTerraform(struct?: AwsComprehendDocumentClassifier.OutputDataConfigPropertyOutputReference | AwsComprehendDocumentClassifier.OutputDataConfigProperty): any;
export declare function awsComprehendDocumentClassifierOutputDataConfigPropertyToHclTerraform(struct?: AwsComprehendDocumentClassifier.OutputDataConfigPropertyOutputReference | AwsComprehendDocumentClassifier.OutputDataConfigProperty): any;
export declare function awsComprehendDocumentClassifierTimeoutsPropertyToTerraform(struct?: AwsComprehendDocumentClassifier.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsComprehendDocumentClassifierTimeoutsPropertyToHclTerraform(struct?: AwsComprehendDocumentClassifier.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsComprehendDocumentClassifierVpcConfigPropertyToTerraform(struct?: AwsComprehendDocumentClassifier.VpcConfigPropertyOutputReference | AwsComprehendDocumentClassifier.VpcConfigProperty): any;
export declare function awsComprehendDocumentClassifierVpcConfigPropertyToHclTerraform(struct?: AwsComprehendDocumentClassifier.VpcConfigPropertyOutputReference | AwsComprehendDocumentClassifier.VpcConfigProperty): any;
export declare namespace AwsComprehendDocumentClassifier {
    interface AugmentedManifestsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_document_classifier#annotation_data_s3_uri AwsComprehendDocumentClassifier#annotation_data_s3_uri}
        */
        readonly annotationDataS3Uri?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_document_classifier#attribute_names AwsComprehendDocumentClassifier#attribute_names}
        */
        readonly attributeNames: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_document_classifier#document_type AwsComprehendDocumentClassifier#document_type}
        */
        readonly documentType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_document_classifier#s3_uri AwsComprehendDocumentClassifier#s3_uri}
        */
        readonly s3Uri: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_document_classifier#source_documents_s3_uri AwsComprehendDocumentClassifier#source_documents_s3_uri}
        */
        readonly sourceDocumentsS3Uri?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_document_classifier#split AwsComprehendDocumentClassifier#split}
        */
        readonly split?: string;
    }
    class AugmentedManifestsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AugmentedManifestsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AugmentedManifestsProperty | cdktn.IResolvable | undefined);
        private _annotationDataS3Uri?;
        get annotationDataS3Uri(): string;
        set annotationDataS3Uri(value: string);
        resetAnnotationDataS3Uri(): void;
        get annotationDataS3UriInput(): string | undefined;
        private _attributeNames?;
        get attributeNames(): string[];
        set attributeNames(value: string[]);
        get attributeNamesInput(): string[] | undefined;
        private _documentType?;
        get documentType(): string;
        set documentType(value: string);
        resetDocumentType(): void;
        get documentTypeInput(): string | undefined;
        private _s3Uri?;
        get s3Uri(): string;
        set s3Uri(value: string);
        get s3UriInput(): string | undefined;
        private _sourceDocumentsS3Uri?;
        get sourceDocumentsS3Uri(): string;
        set sourceDocumentsS3Uri(value: string);
        resetSourceDocumentsS3Uri(): void;
        get sourceDocumentsS3UriInput(): string | undefined;
        private _split?;
        get split(): string;
        set split(value: string);
        resetSplit(): void;
        get splitInput(): string | undefined;
    }
    class AugmentedManifestsPropertyList extends cdktn.ComplexList {
        internalValue?: AugmentedManifestsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AugmentedManifestsPropertyOutputReference;
    }
    interface InputDataConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_document_classifier#data_format AwsComprehendDocumentClassifier#data_format}
        */
        readonly dataFormat?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_document_classifier#label_delimiter AwsComprehendDocumentClassifier#label_delimiter}
        */
        readonly labelDelimiter?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_document_classifier#s3_uri AwsComprehendDocumentClassifier#s3_uri}
        */
        readonly s3Uri?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_document_classifier#test_s3_uri AwsComprehendDocumentClassifier#test_s3_uri}
        */
        readonly testS3Uri?: string;
        /**
        * augmented_manifests block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_document_classifier#augmented_manifests AwsComprehendDocumentClassifier#augmented_manifests}
        */
        readonly augmentedManifests?: AugmentedManifestsProperty[] | cdktn.IResolvable;
    }
    class InputDataConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InputDataConfigProperty | undefined;
        set internalValue(value: InputDataConfigProperty | undefined);
        private _dataFormat?;
        get dataFormat(): string;
        set dataFormat(value: string);
        resetDataFormat(): void;
        get dataFormatInput(): string | undefined;
        private _labelDelimiter?;
        get labelDelimiter(): string;
        set labelDelimiter(value: string);
        resetLabelDelimiter(): void;
        get labelDelimiterInput(): string | undefined;
        private _s3Uri?;
        get s3Uri(): string;
        set s3Uri(value: string);
        resetS3Uri(): void;
        get s3UriInput(): string | undefined;
        private _testS3Uri?;
        get testS3Uri(): string;
        set testS3Uri(value: string);
        resetTestS3Uri(): void;
        get testS3UriInput(): string | undefined;
        private _augmentedManifests;
        get augmentedManifests(): AugmentedManifestsPropertyList;
        putAugmentedManifests(value: AugmentedManifestsProperty[] | cdktn.IResolvable): void;
        resetAugmentedManifests(): void;
        get augmentedManifestsInput(): cdktn.IResolvable | AugmentedManifestsProperty[] | undefined;
    }
    interface OutputDataConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_document_classifier#kms_key_id AwsComprehendDocumentClassifier#kms_key_id}
        */
        readonly kmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_document_classifier#s3_uri AwsComprehendDocumentClassifier#s3_uri}
        */
        readonly s3Uri: string;
    }
    class OutputDataConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OutputDataConfigProperty | undefined;
        set internalValue(value: OutputDataConfigProperty | undefined);
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
        get outputS3Uri(): string;
        private _s3Uri?;
        get s3Uri(): string;
        set s3Uri(value: string);
        get s3UriInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_document_classifier#create AwsComprehendDocumentClassifier#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_document_classifier#delete AwsComprehendDocumentClassifier#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_document_classifier#update AwsComprehendDocumentClassifier#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface VpcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_document_classifier#security_group_ids AwsComprehendDocumentClassifier#security_group_ids}
        */
        readonly securityGroupIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/comprehend_document_classifier#subnets AwsComprehendDocumentClassifier#subnets}
        */
        readonly subnets: string[];
    }
    class VpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcConfigProperty | undefined;
        set internalValue(value: VpcConfigProperty | undefined);
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        get securityGroupIdsInput(): string[] | undefined;
        private _subnets?;
        get subnets(): string[];
        set subnets(value: string[]);
        get subnetsInput(): string[] | undefined;
    }
}
