import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsInspector2OrganizationConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration#id AwsInspector2OrganizationConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration#region AwsInspector2OrganizationConfiguration#region}
    */
    readonly region?: string;
    /**
    * auto_enable block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration#auto_enable AwsInspector2OrganizationConfiguration#auto_enable}
    */
    readonly autoEnable: AwsInspector2OrganizationConfiguration.AutoEnableProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration#timeouts AwsInspector2OrganizationConfiguration#timeouts}
    */
    readonly timeouts?: AwsInspector2OrganizationConfiguration.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration aws_inspector2_organization_configuration}
*/
export declare class AwsInspector2OrganizationConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_inspector2_organization_configuration";
    /**
    * Generates CDKTN code for importing a AwsInspector2OrganizationConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsInspector2OrganizationConfiguration to import
    * @param importFromId The id of the existing AwsInspector2OrganizationConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsInspector2OrganizationConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration aws_inspector2_organization_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsInspector2OrganizationConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsInspector2OrganizationConfigurationConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get maxAccountLimitReached(): cdktn.IResolvable;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _autoEnable;
    get autoEnable(): AwsInspector2OrganizationConfiguration.AutoEnablePropertyOutputReference;
    putAutoEnable(value: AwsInspector2OrganizationConfiguration.AutoEnableProperty): void;
    get autoEnableInput(): AwsInspector2OrganizationConfiguration.AutoEnableProperty | undefined;
    private _timeouts;
    get timeouts(): AwsInspector2OrganizationConfiguration.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsInspector2OrganizationConfiguration.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsInspector2OrganizationConfiguration.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsInspector2OrganizationConfigurationAutoEnablePropertyToTerraform(struct?: AwsInspector2OrganizationConfiguration.AutoEnablePropertyOutputReference | AwsInspector2OrganizationConfiguration.AutoEnableProperty): any;
export declare function awsInspector2OrganizationConfigurationAutoEnablePropertyToHclTerraform(struct?: AwsInspector2OrganizationConfiguration.AutoEnablePropertyOutputReference | AwsInspector2OrganizationConfiguration.AutoEnableProperty): any;
export declare function awsInspector2OrganizationConfigurationTimeoutsPropertyToTerraform(struct?: AwsInspector2OrganizationConfiguration.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsInspector2OrganizationConfigurationTimeoutsPropertyToHclTerraform(struct?: AwsInspector2OrganizationConfiguration.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsInspector2OrganizationConfiguration {
    interface AutoEnableProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration#code_repository AwsInspector2OrganizationConfiguration#code_repository}
        */
        readonly codeRepository?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration#ec2 AwsInspector2OrganizationConfiguration#ec2}
        */
        readonly ec2: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration#ecr AwsInspector2OrganizationConfiguration#ecr}
        */
        readonly ecr: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration#lambda AwsInspector2OrganizationConfiguration#lambda}
        */
        readonly lambda?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration#lambda_code AwsInspector2OrganizationConfiguration#lambda_code}
        */
        readonly lambdaCode?: boolean | cdktn.IResolvable;
    }
    class AutoEnablePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AutoEnableProperty | undefined;
        set internalValue(value: AutoEnableProperty | undefined);
        private _codeRepository?;
        get codeRepository(): boolean | cdktn.IResolvable;
        set codeRepository(value: boolean | cdktn.IResolvable);
        resetCodeRepository(): void;
        get codeRepositoryInput(): boolean | cdktn.IResolvable | undefined;
        private _ec2?;
        get ec2(): boolean | cdktn.IResolvable;
        set ec2(value: boolean | cdktn.IResolvable);
        get ec2Input(): boolean | cdktn.IResolvable | undefined;
        private _ecr?;
        get ecr(): boolean | cdktn.IResolvable;
        set ecr(value: boolean | cdktn.IResolvable);
        get ecrInput(): boolean | cdktn.IResolvable | undefined;
        private _lambda?;
        get lambda(): boolean | cdktn.IResolvable;
        set lambda(value: boolean | cdktn.IResolvable);
        resetLambda(): void;
        get lambdaInput(): boolean | cdktn.IResolvable | undefined;
        private _lambdaCode?;
        get lambdaCode(): boolean | cdktn.IResolvable;
        set lambdaCode(value: boolean | cdktn.IResolvable);
        resetLambdaCode(): void;
        get lambdaCodeInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration#create AwsInspector2OrganizationConfiguration#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration#delete AwsInspector2OrganizationConfiguration#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration#update AwsInspector2OrganizationConfiguration#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
