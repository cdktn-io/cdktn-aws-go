import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfDelegatedAdminAccountConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_delegated_admin_account#account_id TfDelegatedAdminAccount#account_id}
    */
    readonly accountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_delegated_admin_account#id TfDelegatedAdminAccount#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_delegated_admin_account#region TfDelegatedAdminAccount#region}
    */
    readonly region?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_delegated_admin_account#timeouts TfDelegatedAdminAccount#timeouts}
    */
    readonly timeouts?: TfDelegatedAdminAccount.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_delegated_admin_account aws_inspector2_delegated_admin_account}
*/
export declare class TfDelegatedAdminAccount extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_inspector2_delegated_admin_account";
    /**
    * Generates CDKTN code for importing a TfDelegatedAdminAccount resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfDelegatedAdminAccount to import
    * @param importFromId The id of the existing TfDelegatedAdminAccount that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_delegated_admin_account#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfDelegatedAdminAccount to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_delegated_admin_account aws_inspector2_delegated_admin_account} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfDelegatedAdminAccountConfig
    */
    constructor(scope: Construct, id: string, config: TfDelegatedAdminAccountConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get relationshipStatus(): string;
    private _timeouts;
    get timeouts(): TfDelegatedAdminAccount.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfDelegatedAdminAccount.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): TfDelegatedAdminAccount.TimeoutsProperty | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfDelegatedAdminAccountTimeoutsPropertyToTerraform(struct?: TfDelegatedAdminAccount.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfDelegatedAdminAccountTimeoutsPropertyToHclTerraform(struct?: TfDelegatedAdminAccount.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfDelegatedAdminAccount {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_delegated_admin_account#create TfDelegatedAdminAccount#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_delegated_admin_account#delete TfDelegatedAdminAccount#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
