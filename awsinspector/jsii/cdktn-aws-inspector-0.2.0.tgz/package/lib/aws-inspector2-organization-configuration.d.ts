import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfOrganizationConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration#id TfOrganizationConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration#region TfOrganizationConfiguration#region}
    */
    readonly region?: string;
    /**
    * auto_enable block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration#auto_enable TfOrganizationConfiguration#auto_enable}
    */
    readonly autoEnable: TfOrganizationConfiguration.AutoEnableProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration#timeouts TfOrganizationConfiguration#timeouts}
    */
    readonly timeouts?: TfOrganizationConfiguration.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration aws_inspector2_organization_configuration}
*/
export declare class TfOrganizationConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_inspector2_organization_configuration";
    /**
    * Generates CDKTN code for importing a TfOrganizationConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfOrganizationConfiguration to import
    * @param importFromId The id of the existing TfOrganizationConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfOrganizationConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration aws_inspector2_organization_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfOrganizationConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: TfOrganizationConfigurationConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get maxAccountLimitReached(): cdktn.IResolvable;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _autoEnable;
    get autoEnable(): TfOrganizationConfiguration.AutoEnablePropertyOutputReference;
    putAutoEnable(value: TfOrganizationConfiguration.AutoEnableProperty): void;
    get autoEnableInput(): TfOrganizationConfiguration.AutoEnableProperty | undefined;
    private _timeouts;
    get timeouts(): TfOrganizationConfiguration.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfOrganizationConfiguration.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfOrganizationConfiguration.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfOrganizationConfigurationAutoEnablePropertyToTerraform(struct?: TfOrganizationConfiguration.AutoEnablePropertyOutputReference | TfOrganizationConfiguration.AutoEnableProperty): any;
export declare function tfOrganizationConfigurationAutoEnablePropertyToHclTerraform(struct?: TfOrganizationConfiguration.AutoEnablePropertyOutputReference | TfOrganizationConfiguration.AutoEnableProperty): any;
export declare function tfOrganizationConfigurationTimeoutsPropertyToTerraform(struct?: TfOrganizationConfiguration.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfOrganizationConfigurationTimeoutsPropertyToHclTerraform(struct?: TfOrganizationConfiguration.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfOrganizationConfiguration {
    interface AutoEnableProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration#code_repository TfOrganizationConfiguration#code_repository}
        */
        readonly codeRepository?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration#ec2 TfOrganizationConfiguration#ec2}
        */
        readonly ec2: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration#ecr TfOrganizationConfiguration#ecr}
        */
        readonly ecr: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration#lambda TfOrganizationConfiguration#lambda}
        */
        readonly lambda?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration#lambda_code TfOrganizationConfiguration#lambda_code}
        */
        readonly lambdaCode?: boolean | cdktn.IResolvable;
    }
    class AutoEnablePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AutoEnableProperty | undefined;
        set internalValue(value: AutoEnableProperty | undefined);
        private _codeRepository?;
        get codeRepository(): boolean | cdktn.IResolvable;
        set codeRepository(value: boolean | cdktn.IResolvable);
        resetCodeRepository(): void;
        get codeRepositoryInput(): boolean | cdktn.IResolvable | undefined;
        private _ec2?;
        get ec2(): boolean | cdktn.IResolvable;
        set ec2(value: boolean | cdktn.IResolvable);
        get ec2Input(): boolean | cdktn.IResolvable | undefined;
        private _ecr?;
        get ecr(): boolean | cdktn.IResolvable;
        set ecr(value: boolean | cdktn.IResolvable);
        get ecrInput(): boolean | cdktn.IResolvable | undefined;
        private _lambda?;
        get lambda(): boolean | cdktn.IResolvable;
        set lambda(value: boolean | cdktn.IResolvable);
        resetLambda(): void;
        get lambdaInput(): boolean | cdktn.IResolvable | undefined;
        private _lambdaCode?;
        get lambdaCode(): boolean | cdktn.IResolvable;
        set lambdaCode(value: boolean | cdktn.IResolvable);
        resetLambdaCode(): void;
        get lambdaCodeInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration#create TfOrganizationConfiguration#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration#delete TfOrganizationConfiguration#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/inspector2_organization_configuration#update TfOrganizationConfiguration#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
