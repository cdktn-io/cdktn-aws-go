import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsXrayGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/xray_group#filter_expression AwsXrayGroup#filter_expression}
    */
    readonly filterExpression: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/xray_group#group_name AwsXrayGroup#group_name}
    */
    readonly groupName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/xray_group#id AwsXrayGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/xray_group#region AwsXrayGroup#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/xray_group#tags AwsXrayGroup#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/xray_group#tags_all AwsXrayGroup#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * insights_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/xray_group#insights_configuration AwsXrayGroup#insights_configuration}
    */
    readonly insightsConfiguration?: AwsXrayGroup.InsightsConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/xray_group aws_xray_group}
*/
export declare class AwsXrayGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_xray_group";
    /**
    * Generates CDKTN code for importing a AwsXrayGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsXrayGroup to import
    * @param importFromId The id of the existing AwsXrayGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/xray_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsXrayGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/xray_group aws_xray_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsXrayGroupConfig
    */
    constructor(scope: Construct, id: string, config: AwsXrayGroupConfig);
    get arn(): string;
    private _filterExpression?;
    get filterExpression(): string;
    set filterExpression(value: string);
    get filterExpressionInput(): string | undefined;
    private _groupName?;
    get groupName(): string;
    set groupName(value: string);
    get groupNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _insightsConfiguration;
    get insightsConfiguration(): AwsXrayGroup.InsightsConfigurationPropertyOutputReference;
    putInsightsConfiguration(value: AwsXrayGroup.InsightsConfigurationProperty): void;
    resetInsightsConfiguration(): void;
    get insightsConfigurationInput(): AwsXrayGroup.InsightsConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsXrayGroupInsightsConfigurationPropertyToTerraform(struct?: AwsXrayGroup.InsightsConfigurationPropertyOutputReference | AwsXrayGroup.InsightsConfigurationProperty): any;
export declare function awsXrayGroupInsightsConfigurationPropertyToHclTerraform(struct?: AwsXrayGroup.InsightsConfigurationPropertyOutputReference | AwsXrayGroup.InsightsConfigurationProperty): any;
export declare namespace AwsXrayGroup {
    interface InsightsConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/xray_group#insights_enabled AwsXrayGroup#insights_enabled}
        */
        readonly insightsEnabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/xray_group#notifications_enabled AwsXrayGroup#notifications_enabled}
        */
        readonly notificationsEnabled?: boolean | cdktn.IResolvable;
    }
    class InsightsConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InsightsConfigurationProperty | undefined;
        set internalValue(value: InsightsConfigurationProperty | undefined);
        private _insightsEnabled?;
        get insightsEnabled(): boolean | cdktn.IResolvable;
        set insightsEnabled(value: boolean | cdktn.IResolvable);
        get insightsEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _notificationsEnabled?;
        get notificationsEnabled(): boolean | cdktn.IResolvable;
        set notificationsEnabled(value: boolean | cdktn.IResolvable);
        resetNotificationsEnabled(): void;
        get notificationsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    }
}
