import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsXrayTraceSegmentDestinationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/xray_trace_segment_destination#destination AwsXrayTraceSegmentDestination#destination}
    */
    readonly destination: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/xray_trace_segment_destination#region AwsXrayTraceSegmentDestination#region}
    */
    readonly region?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/xray_trace_segment_destination#timeouts AwsXrayTraceSegmentDestination#timeouts}
    */
    readonly timeouts?: AwsXrayTraceSegmentDestination.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/xray_trace_segment_destination aws_xray_trace_segment_destination}
*/
export declare class AwsXrayTraceSegmentDestination extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_xray_trace_segment_destination";
    /**
    * Generates CDKTN code for importing a AwsXrayTraceSegmentDestination resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsXrayTraceSegmentDestination to import
    * @param importFromId The id of the existing AwsXrayTraceSegmentDestination that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/xray_trace_segment_destination#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsXrayTraceSegmentDestination to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/xray_trace_segment_destination aws_xray_trace_segment_destination} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsXrayTraceSegmentDestinationConfig
    */
    constructor(scope: Construct, id: string, config: AwsXrayTraceSegmentDestinationConfig);
    private _destination?;
    get destination(): string;
    set destination(value: string);
    get destinationInput(): string | undefined;
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _timeouts;
    get timeouts(): AwsXrayTraceSegmentDestination.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsXrayTraceSegmentDestination.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsXrayTraceSegmentDestination.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsXrayTraceSegmentDestinationTimeoutsPropertyToTerraform(struct?: AwsXrayTraceSegmentDestination.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsXrayTraceSegmentDestinationTimeoutsPropertyToHclTerraform(struct?: AwsXrayTraceSegmentDestination.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsXrayTraceSegmentDestination {
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/xray_trace_segment_destination#create AwsXrayTraceSegmentDestination#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/xray_trace_segment_destination#update AwsXrayTraceSegmentDestination#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
