import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsXrayResourcePolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/xray_resource_policy#bypass_policy_lockout_check AwsXrayResourcePolicy#bypass_policy_lockout_check}
    */
    readonly bypassPolicyLockoutCheck?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/xray_resource_policy#policy_document AwsXrayResourcePolicy#policy_document}
    */
    readonly policyDocument: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/xray_resource_policy#policy_name AwsXrayResourcePolicy#policy_name}
    */
    readonly policyName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/xray_resource_policy#policy_revision_id AwsXrayResourcePolicy#policy_revision_id}
    */
    readonly policyRevisionId?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/xray_resource_policy#region AwsXrayResourcePolicy#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/xray_resource_policy aws_xray_resource_policy}
*/
export declare class AwsXrayResourcePolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_xray_resource_policy";
    /**
    * Generates CDKTN code for importing a AwsXrayResourcePolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsXrayResourcePolicy to import
    * @param importFromId The id of the existing AwsXrayResourcePolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/xray_resource_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsXrayResourcePolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/xray_resource_policy aws_xray_resource_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsXrayResourcePolicyConfig
    */
    constructor(scope: Construct, id: string, config: AwsXrayResourcePolicyConfig);
    private _bypassPolicyLockoutCheck?;
    get bypassPolicyLockoutCheck(): boolean | cdktn.IResolvable;
    set bypassPolicyLockoutCheck(value: boolean | cdktn.IResolvable);
    resetBypassPolicyLockoutCheck(): void;
    get bypassPolicyLockoutCheckInput(): boolean | cdktn.IResolvable | undefined;
    get lastUpdatedTime(): string;
    private _policyDocument?;
    get policyDocument(): string;
    set policyDocument(value: string);
    get policyDocumentInput(): string | undefined;
    private _policyName?;
    get policyName(): string;
    set policyName(value: string);
    get policyNameInput(): string | undefined;
    private _policyRevisionId?;
    get policyRevisionId(): string;
    set policyRevisionId(value: string);
    resetPolicyRevisionId(): void;
    get policyRevisionIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
