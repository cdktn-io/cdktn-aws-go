export * from './aws-comprehend-document-classifier';
export * from './aws-comprehend-entity-recognizer';
