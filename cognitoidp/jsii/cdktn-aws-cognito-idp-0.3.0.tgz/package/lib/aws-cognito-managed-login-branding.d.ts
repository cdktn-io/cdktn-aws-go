import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsManagedLoginBrandingConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_login_branding#client_id AwsManagedLoginBranding#client_id}
    */
    readonly clientId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_login_branding#region AwsManagedLoginBranding#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_login_branding#settings AwsManagedLoginBranding#settings}
    */
    readonly settings?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_login_branding#use_cognito_provided_values AwsManagedLoginBranding#use_cognito_provided_values}
    */
    readonly useCognitoProvidedValues?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_login_branding#user_pool_id AwsManagedLoginBranding#user_pool_id}
    */
    readonly userPoolId: string;
    /**
    * asset block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_login_branding#asset AwsManagedLoginBranding#asset}
    */
    readonly asset?: AwsManagedLoginBranding.AssetProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_login_branding aws_cognito_managed_login_branding}
*/
export declare class AwsManagedLoginBranding extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cognito_managed_login_branding";
    /**
    * Generates CDKTN code for importing a AwsManagedLoginBranding resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsManagedLoginBranding to import
    * @param importFromId The id of the existing AwsManagedLoginBranding that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_login_branding#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsManagedLoginBranding to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_login_branding aws_cognito_managed_login_branding} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsManagedLoginBrandingConfig
    */
    constructor(scope: Construct, id: string, config: AwsManagedLoginBrandingConfig);
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    get clientIdInput(): string | undefined;
    get managedLoginBrandingId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _settings?;
    get settings(): string;
    set settings(value: string);
    resetSettings(): void;
    get settingsInput(): string | undefined;
    get settingsAll(): string;
    private _useCognitoProvidedValues?;
    get useCognitoProvidedValues(): boolean | cdktn.IResolvable;
    set useCognitoProvidedValues(value: boolean | cdktn.IResolvable);
    resetUseCognitoProvidedValues(): void;
    get useCognitoProvidedValuesInput(): boolean | cdktn.IResolvable | undefined;
    private _userPoolId?;
    get userPoolId(): string;
    set userPoolId(value: string);
    get userPoolIdInput(): string | undefined;
    private _asset;
    get asset(): AwsManagedLoginBranding.AssetPropertyList;
    putAsset(value: AwsManagedLoginBranding.AssetProperty[] | cdktn.IResolvable): void;
    resetAsset(): void;
    get assetInput(): cdktn.IResolvable | AwsManagedLoginBranding.AssetProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsManagedLoginBrandingAssetPropertyToTerraform(struct?: AwsManagedLoginBranding.AssetProperty | cdktn.IResolvable): any;
export declare function awsManagedLoginBrandingAssetPropertyToHclTerraform(struct?: AwsManagedLoginBranding.AssetProperty | cdktn.IResolvable): any;
export declare namespace AwsManagedLoginBranding {
    interface AssetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_login_branding#bytes AwsManagedLoginBranding#bytes}
        */
        readonly bytes?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_login_branding#category AwsManagedLoginBranding#category}
        */
        readonly category: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_login_branding#color_mode AwsManagedLoginBranding#color_mode}
        */
        readonly colorMode: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_login_branding#extension AwsManagedLoginBranding#extension}
        */
        readonly extension: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_managed_login_branding#resource_id AwsManagedLoginBranding#resource_id}
        */
        readonly resourceId?: string;
    }
    class AssetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AssetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AssetProperty | cdktn.IResolvable | undefined);
        private _bytes?;
        get bytes(): string;
        set bytes(value: string);
        resetBytes(): void;
        get bytesInput(): string | undefined;
        private _category?;
        get category(): string;
        set category(value: string);
        get categoryInput(): string | undefined;
        private _colorMode?;
        get colorMode(): string;
        set colorMode(value: string);
        get colorModeInput(): string | undefined;
        private _extension?;
        get extension(): string;
        set extension(value: string);
        get extensionInput(): string | undefined;
        private _resourceId?;
        get resourceId(): string;
        set resourceId(value: string);
        resetResourceId(): void;
        get resourceIdInput(): string | undefined;
    }
    class AssetPropertyList extends cdktn.ComplexList {
        internalValue?: AssetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AssetPropertyOutputReference;
    }
}
