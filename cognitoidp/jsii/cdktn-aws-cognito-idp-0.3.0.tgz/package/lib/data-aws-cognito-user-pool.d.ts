import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsUserPoolConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cognito_user_pool#region DataAwsUserPool#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cognito_user_pool#user_pool_id DataAwsUserPool#user_pool_id}
    */
    readonly userPoolId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cognito_user_pool aws_cognito_user_pool}
*/
export declare class DataAwsUserPool extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_cognito_user_pool";
    /**
    * Generates CDKTN code for importing a DataAwsUserPool resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsUserPool to import
    * @param importFromId The id of the existing DataAwsUserPool that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cognito_user_pool#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsUserPool to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/cognito_user_pool aws_cognito_user_pool} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsUserPoolConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsUserPoolConfig);
    private _accountRecoverySetting;
    get accountRecoverySetting(): DataAwsUserPool.AccountRecoverySettingPropertyList;
    private _adminCreateUserConfig;
    get adminCreateUserConfig(): DataAwsUserPool.AdminCreateUserConfigPropertyList;
    get arn(): string;
    get autoVerifiedAttributes(): string[];
    get creationDate(): string;
    get customDomain(): string;
    get deletionProtection(): string;
    private _deviceConfiguration;
    get deviceConfiguration(): DataAwsUserPool.DeviceConfigurationPropertyList;
    get domain(): string;
    private _emailConfiguration;
    get emailConfiguration(): DataAwsUserPool.EmailConfigurationPropertyList;
    get estimatedNumberOfUsers(): number;
    get id(): string;
    private _lambdaConfig;
    get lambdaConfig(): DataAwsUserPool.LambdaConfigPropertyList;
    get lastModifiedDate(): string;
    get mfaConfiguration(): string;
    get name(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _schemaAttributes;
    get schemaAttributes(): DataAwsUserPool.SchemaAttributesPropertyList;
    get smsAuthenticationMessage(): string;
    get smsConfigurationFailure(): string;
    get smsVerificationMessage(): string;
    private _tags;
    get tags(): cdktn.StringMap;
    private _userPoolAddOns;
    get userPoolAddOns(): DataAwsUserPool.UserPoolAddOnsPropertyList;
    private _userPoolId?;
    get userPoolId(): string;
    set userPoolId(value: string);
    get userPoolIdInput(): string | undefined;
    private _userPoolTags;
    get userPoolTags(): cdktn.StringMap;
    get usernameAttributes(): string[];
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsUserPoolRecoveryMechanismPropertyToTerraform(struct?: DataAwsUserPool.RecoveryMechanismProperty): any;
export declare function dataAwsUserPoolRecoveryMechanismPropertyToHclTerraform(struct?: DataAwsUserPool.RecoveryMechanismProperty): any;
export declare function dataAwsUserPoolAccountRecoverySettingPropertyToTerraform(struct?: DataAwsUserPool.AccountRecoverySettingProperty): any;
export declare function dataAwsUserPoolAccountRecoverySettingPropertyToHclTerraform(struct?: DataAwsUserPool.AccountRecoverySettingProperty): any;
export declare function dataAwsUserPoolInviteMessageTemplatePropertyToTerraform(struct?: DataAwsUserPool.InviteMessageTemplateProperty): any;
export declare function dataAwsUserPoolInviteMessageTemplatePropertyToHclTerraform(struct?: DataAwsUserPool.InviteMessageTemplateProperty): any;
export declare function dataAwsUserPoolAdminCreateUserConfigPropertyToTerraform(struct?: DataAwsUserPool.AdminCreateUserConfigProperty): any;
export declare function dataAwsUserPoolAdminCreateUserConfigPropertyToHclTerraform(struct?: DataAwsUserPool.AdminCreateUserConfigProperty): any;
export declare function dataAwsUserPoolDeviceConfigurationPropertyToTerraform(struct?: DataAwsUserPool.DeviceConfigurationProperty): any;
export declare function dataAwsUserPoolDeviceConfigurationPropertyToHclTerraform(struct?: DataAwsUserPool.DeviceConfigurationProperty): any;
export declare function dataAwsUserPoolEmailConfigurationPropertyToTerraform(struct?: DataAwsUserPool.EmailConfigurationProperty): any;
export declare function dataAwsUserPoolEmailConfigurationPropertyToHclTerraform(struct?: DataAwsUserPool.EmailConfigurationProperty): any;
export declare function dataAwsUserPoolCustomEmailSenderPropertyToTerraform(struct?: DataAwsUserPool.CustomEmailSenderProperty): any;
export declare function dataAwsUserPoolCustomEmailSenderPropertyToHclTerraform(struct?: DataAwsUserPool.CustomEmailSenderProperty): any;
export declare function dataAwsUserPoolCustomSmsSenderPropertyToTerraform(struct?: DataAwsUserPool.CustomSmsSenderProperty): any;
export declare function dataAwsUserPoolCustomSmsSenderPropertyToHclTerraform(struct?: DataAwsUserPool.CustomSmsSenderProperty): any;
export declare function dataAwsUserPoolPreTokenGenerationConfigPropertyToTerraform(struct?: DataAwsUserPool.PreTokenGenerationConfigProperty): any;
export declare function dataAwsUserPoolPreTokenGenerationConfigPropertyToHclTerraform(struct?: DataAwsUserPool.PreTokenGenerationConfigProperty): any;
export declare function dataAwsUserPoolLambdaConfigPropertyToTerraform(struct?: DataAwsUserPool.LambdaConfigProperty): any;
export declare function dataAwsUserPoolLambdaConfigPropertyToHclTerraform(struct?: DataAwsUserPool.LambdaConfigProperty): any;
export declare function dataAwsUserPoolNumberAttributeConstraintsPropertyToTerraform(struct?: DataAwsUserPool.NumberAttributeConstraintsProperty): any;
export declare function dataAwsUserPoolNumberAttributeConstraintsPropertyToHclTerraform(struct?: DataAwsUserPool.NumberAttributeConstraintsProperty): any;
export declare function dataAwsUserPoolStringAttributeConstraintsPropertyToTerraform(struct?: DataAwsUserPool.StringAttributeConstraintsProperty): any;
export declare function dataAwsUserPoolStringAttributeConstraintsPropertyToHclTerraform(struct?: DataAwsUserPool.StringAttributeConstraintsProperty): any;
export declare function dataAwsUserPoolSchemaAttributesPropertyToTerraform(struct?: DataAwsUserPool.SchemaAttributesProperty): any;
export declare function dataAwsUserPoolSchemaAttributesPropertyToHclTerraform(struct?: DataAwsUserPool.SchemaAttributesProperty): any;
export declare function dataAwsUserPoolAdvancedSecurityAdditionalFlowsPropertyToTerraform(struct?: DataAwsUserPool.AdvancedSecurityAdditionalFlowsProperty): any;
export declare function dataAwsUserPoolAdvancedSecurityAdditionalFlowsPropertyToHclTerraform(struct?: DataAwsUserPool.AdvancedSecurityAdditionalFlowsProperty): any;
export declare function dataAwsUserPoolUserPoolAddOnsPropertyToTerraform(struct?: DataAwsUserPool.UserPoolAddOnsProperty): any;
export declare function dataAwsUserPoolUserPoolAddOnsPropertyToHclTerraform(struct?: DataAwsUserPool.UserPoolAddOnsProperty): any;
export declare namespace DataAwsUserPool {
    interface RecoveryMechanismProperty {
    }
    class RecoveryMechanismPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RecoveryMechanismProperty | undefined;
        set internalValue(value: RecoveryMechanismProperty | undefined);
        get name(): string;
        get priority(): number;
    }
    class RecoveryMechanismPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RecoveryMechanismPropertyOutputReference;
    }
    interface AccountRecoverySettingProperty {
    }
    class AccountRecoverySettingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AccountRecoverySettingProperty | undefined;
        set internalValue(value: AccountRecoverySettingProperty | undefined);
        private _recoveryMechanism;
        get recoveryMechanism(): RecoveryMechanismPropertyList;
    }
    class AccountRecoverySettingPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AccountRecoverySettingPropertyOutputReference;
    }
    interface InviteMessageTemplateProperty {
    }
    class InviteMessageTemplatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InviteMessageTemplateProperty | undefined;
        set internalValue(value: InviteMessageTemplateProperty | undefined);
        get emailMessage(): string;
        get emailSubject(): string;
        get smsMessage(): string;
    }
    class InviteMessageTemplatePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InviteMessageTemplatePropertyOutputReference;
    }
    interface AdminCreateUserConfigProperty {
    }
    class AdminCreateUserConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AdminCreateUserConfigProperty | undefined;
        set internalValue(value: AdminCreateUserConfigProperty | undefined);
        get allowAdminCreateUserOnly(): cdktn.IResolvable;
        private _inviteMessageTemplate;
        get inviteMessageTemplate(): InviteMessageTemplatePropertyList;
        get unusedAccountValidityDays(): number;
    }
    class AdminCreateUserConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AdminCreateUserConfigPropertyOutputReference;
    }
    interface DeviceConfigurationProperty {
    }
    class DeviceConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DeviceConfigurationProperty | undefined;
        set internalValue(value: DeviceConfigurationProperty | undefined);
        get challengeRequiredOnNewDevice(): cdktn.IResolvable;
        get deviceOnlyRememberedOnUserPrompt(): cdktn.IResolvable;
    }
    class DeviceConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DeviceConfigurationPropertyOutputReference;
    }
    interface EmailConfigurationProperty {
    }
    class EmailConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EmailConfigurationProperty | undefined;
        set internalValue(value: EmailConfigurationProperty | undefined);
        get configurationSet(): string;
        get emailSendingAccount(): string;
        get from(): string;
        get replyToEmailAddress(): string;
        get sourceArn(): string;
    }
    class EmailConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EmailConfigurationPropertyOutputReference;
    }
    interface CustomEmailSenderProperty {
    }
    class CustomEmailSenderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomEmailSenderProperty | undefined;
        set internalValue(value: CustomEmailSenderProperty | undefined);
        get lambdaArn(): string;
        get lambdaVersion(): string;
    }
    class CustomEmailSenderPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomEmailSenderPropertyOutputReference;
    }
    interface CustomSmsSenderProperty {
    }
    class CustomSmsSenderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomSmsSenderProperty | undefined;
        set internalValue(value: CustomSmsSenderProperty | undefined);
        get lambdaArn(): string;
        get lambdaVersion(): string;
    }
    class CustomSmsSenderPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomSmsSenderPropertyOutputReference;
    }
    interface PreTokenGenerationConfigProperty {
    }
    class PreTokenGenerationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PreTokenGenerationConfigProperty | undefined;
        set internalValue(value: PreTokenGenerationConfigProperty | undefined);
        get lambdaArn(): string;
        get lambdaVersion(): string;
    }
    class PreTokenGenerationConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PreTokenGenerationConfigPropertyOutputReference;
    }
    interface LambdaConfigProperty {
    }
    class LambdaConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LambdaConfigProperty | undefined;
        set internalValue(value: LambdaConfigProperty | undefined);
        get createAuthChallenge(): string;
        private _customEmailSender;
        get customEmailSender(): CustomEmailSenderPropertyList;
        get customMessage(): string;
        private _customSmsSender;
        get customSmsSender(): CustomSmsSenderPropertyList;
        get defineAuthChallenge(): string;
        get kmsKeyId(): string;
        get postAuthentication(): string;
        get postConfirmation(): string;
        get preAuthentication(): string;
        get preSignUp(): string;
        get preTokenGeneration(): string;
        private _preTokenGenerationConfig;
        get preTokenGenerationConfig(): PreTokenGenerationConfigPropertyList;
        get userMigration(): string;
        get verifyAuthChallengeResponse(): string;
    }
    class LambdaConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LambdaConfigPropertyOutputReference;
    }
    interface NumberAttributeConstraintsProperty {
    }
    class NumberAttributeConstraintsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NumberAttributeConstraintsProperty | undefined;
        set internalValue(value: NumberAttributeConstraintsProperty | undefined);
        get maxValue(): string;
        get minValue(): string;
    }
    class NumberAttributeConstraintsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NumberAttributeConstraintsPropertyOutputReference;
    }
    interface StringAttributeConstraintsProperty {
    }
    class StringAttributeConstraintsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StringAttributeConstraintsProperty | undefined;
        set internalValue(value: StringAttributeConstraintsProperty | undefined);
        get maxLength(): string;
        get minLength(): string;
    }
    class StringAttributeConstraintsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StringAttributeConstraintsPropertyOutputReference;
    }
    interface SchemaAttributesProperty {
    }
    class SchemaAttributesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SchemaAttributesProperty | undefined;
        set internalValue(value: SchemaAttributesProperty | undefined);
        get attributeDataType(): string;
        get developerOnlyAttribute(): cdktn.IResolvable;
        get mutable(): cdktn.IResolvable;
        get name(): string;
        private _numberAttributeConstraints;
        get numberAttributeConstraints(): NumberAttributeConstraintsPropertyList;
        get required(): cdktn.IResolvable;
        private _stringAttributeConstraints;
        get stringAttributeConstraints(): StringAttributeConstraintsPropertyList;
    }
    class SchemaAttributesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SchemaAttributesPropertyOutputReference;
    }
    interface AdvancedSecurityAdditionalFlowsProperty {
    }
    class AdvancedSecurityAdditionalFlowsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AdvancedSecurityAdditionalFlowsProperty | undefined;
        set internalValue(value: AdvancedSecurityAdditionalFlowsProperty | undefined);
        get customAuthMode(): string;
    }
    class AdvancedSecurityAdditionalFlowsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AdvancedSecurityAdditionalFlowsPropertyOutputReference;
    }
    interface UserPoolAddOnsProperty {
    }
    class UserPoolAddOnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UserPoolAddOnsProperty | undefined;
        set internalValue(value: UserPoolAddOnsProperty | undefined);
        private _advancedSecurityAdditionalFlows;
        get advancedSecurityAdditionalFlows(): AdvancedSecurityAdditionalFlowsPropertyList;
        get advancedSecurityMode(): string;
    }
    class UserPoolAddOnsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UserPoolAddOnsPropertyOutputReference;
    }
}
