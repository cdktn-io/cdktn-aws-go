import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsUserPoolConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#alias_attributes AwsUserPool#alias_attributes}
    */
    readonly aliasAttributes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#auto_verified_attributes AwsUserPool#auto_verified_attributes}
    */
    readonly autoVerifiedAttributes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#deletion_protection AwsUserPool#deletion_protection}
    */
    readonly deletionProtection?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#email_verification_message AwsUserPool#email_verification_message}
    */
    readonly emailVerificationMessage?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#email_verification_subject AwsUserPool#email_verification_subject}
    */
    readonly emailVerificationSubject?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#id AwsUserPool#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#mfa_configuration AwsUserPool#mfa_configuration}
    */
    readonly mfaConfiguration?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#name AwsUserPool#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#region AwsUserPool#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#sms_authentication_message AwsUserPool#sms_authentication_message}
    */
    readonly smsAuthenticationMessage?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#sms_verification_message AwsUserPool#sms_verification_message}
    */
    readonly smsVerificationMessage?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#tags AwsUserPool#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#tags_all AwsUserPool#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#user_pool_tier AwsUserPool#user_pool_tier}
    */
    readonly userPoolTier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#username_attributes AwsUserPool#username_attributes}
    */
    readonly usernameAttributes?: string[];
    /**
    * account_recovery_setting block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#account_recovery_setting AwsUserPool#account_recovery_setting}
    */
    readonly accountRecoverySetting?: AwsUserPool.AccountRecoverySettingProperty;
    /**
    * admin_create_user_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#admin_create_user_config AwsUserPool#admin_create_user_config}
    */
    readonly adminCreateUserConfig?: AwsUserPool.AdminCreateUserConfigProperty;
    /**
    * device_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#device_configuration AwsUserPool#device_configuration}
    */
    readonly deviceConfiguration?: AwsUserPool.DeviceConfigurationProperty;
    /**
    * email_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#email_configuration AwsUserPool#email_configuration}
    */
    readonly emailConfiguration?: AwsUserPool.EmailConfigurationProperty;
    /**
    * email_mfa_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#email_mfa_configuration AwsUserPool#email_mfa_configuration}
    */
    readonly emailMfaConfiguration?: AwsUserPool.EmailMfaConfigurationProperty;
    /**
    * lambda_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#lambda_config AwsUserPool#lambda_config}
    */
    readonly lambdaConfig?: AwsUserPool.LambdaConfigProperty;
    /**
    * password_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#password_policy AwsUserPool#password_policy}
    */
    readonly passwordPolicy?: AwsUserPool.PasswordPolicyProperty;
    /**
    * schema block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#schema AwsUserPool#schema}
    */
    readonly schema?: AwsUserPool.SchemaProperty[] | cdktn.IResolvable;
    /**
    * sign_in_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#sign_in_policy AwsUserPool#sign_in_policy}
    */
    readonly signInPolicy?: AwsUserPool.SignInPolicyProperty;
    /**
    * sms_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#sms_configuration AwsUserPool#sms_configuration}
    */
    readonly smsConfiguration?: AwsUserPool.SmsConfigurationProperty;
    /**
    * software_token_mfa_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#software_token_mfa_configuration AwsUserPool#software_token_mfa_configuration}
    */
    readonly softwareTokenMfaConfiguration?: AwsUserPool.SoftwareTokenMfaConfigurationProperty;
    /**
    * user_attribute_update_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#user_attribute_update_settings AwsUserPool#user_attribute_update_settings}
    */
    readonly userAttributeUpdateSettings?: AwsUserPool.UserAttributeUpdateSettingsProperty;
    /**
    * user_pool_add_ons block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#user_pool_add_ons AwsUserPool#user_pool_add_ons}
    */
    readonly userPoolAddOns?: AwsUserPool.UserPoolAddOnsProperty;
    /**
    * username_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#username_configuration AwsUserPool#username_configuration}
    */
    readonly usernameConfiguration?: AwsUserPool.UsernameConfigurationProperty;
    /**
    * verification_message_template block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#verification_message_template AwsUserPool#verification_message_template}
    */
    readonly verificationMessageTemplate?: AwsUserPool.VerificationMessageTemplateProperty;
    /**
    * web_authn_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#web_authn_configuration AwsUserPool#web_authn_configuration}
    */
    readonly webAuthnConfiguration?: AwsUserPool.WebAuthnConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool aws_cognito_user_pool}
*/
export declare class AwsUserPool extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_cognito_user_pool";
    /**
    * Generates CDKTN code for importing a AwsUserPool resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsUserPool to import
    * @param importFromId The id of the existing AwsUserPool that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsUserPool to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool aws_cognito_user_pool} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsUserPoolConfig
    */
    constructor(scope: Construct, id: string, config: AwsUserPoolConfig);
    private _aliasAttributes?;
    get aliasAttributes(): string[];
    set aliasAttributes(value: string[]);
    resetAliasAttributes(): void;
    get aliasAttributesInput(): string[] | undefined;
    get arn(): string;
    private _autoVerifiedAttributes?;
    get autoVerifiedAttributes(): string[];
    set autoVerifiedAttributes(value: string[]);
    resetAutoVerifiedAttributes(): void;
    get autoVerifiedAttributesInput(): string[] | undefined;
    get creationDate(): string;
    get customDomain(): string;
    private _deletionProtection?;
    get deletionProtection(): string;
    set deletionProtection(value: string);
    resetDeletionProtection(): void;
    get deletionProtectionInput(): string | undefined;
    get domain(): string;
    private _emailVerificationMessage?;
    get emailVerificationMessage(): string;
    set emailVerificationMessage(value: string);
    resetEmailVerificationMessage(): void;
    get emailVerificationMessageInput(): string | undefined;
    private _emailVerificationSubject?;
    get emailVerificationSubject(): string;
    set emailVerificationSubject(value: string);
    resetEmailVerificationSubject(): void;
    get emailVerificationSubjectInput(): string | undefined;
    get endpoint(): string;
    get estimatedNumberOfUsers(): number;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastModifiedDate(): string;
    private _mfaConfiguration?;
    get mfaConfiguration(): string;
    set mfaConfiguration(value: string);
    resetMfaConfiguration(): void;
    get mfaConfigurationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _smsAuthenticationMessage?;
    get smsAuthenticationMessage(): string;
    set smsAuthenticationMessage(value: string);
    resetSmsAuthenticationMessage(): void;
    get smsAuthenticationMessageInput(): string | undefined;
    private _smsVerificationMessage?;
    get smsVerificationMessage(): string;
    set smsVerificationMessage(value: string);
    resetSmsVerificationMessage(): void;
    get smsVerificationMessageInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _userPoolTier?;
    get userPoolTier(): string;
    set userPoolTier(value: string);
    resetUserPoolTier(): void;
    get userPoolTierInput(): string | undefined;
    private _usernameAttributes?;
    get usernameAttributes(): string[];
    set usernameAttributes(value: string[]);
    resetUsernameAttributes(): void;
    get usernameAttributesInput(): string[] | undefined;
    private _accountRecoverySetting;
    get accountRecoverySetting(): AwsUserPool.AccountRecoverySettingPropertyOutputReference;
    putAccountRecoverySetting(value: AwsUserPool.AccountRecoverySettingProperty): void;
    resetAccountRecoverySetting(): void;
    get accountRecoverySettingInput(): AwsUserPool.AccountRecoverySettingProperty | undefined;
    private _adminCreateUserConfig;
    get adminCreateUserConfig(): AwsUserPool.AdminCreateUserConfigPropertyOutputReference;
    putAdminCreateUserConfig(value: AwsUserPool.AdminCreateUserConfigProperty): void;
    resetAdminCreateUserConfig(): void;
    get adminCreateUserConfigInput(): AwsUserPool.AdminCreateUserConfigProperty | undefined;
    private _deviceConfiguration;
    get deviceConfiguration(): AwsUserPool.DeviceConfigurationPropertyOutputReference;
    putDeviceConfiguration(value: AwsUserPool.DeviceConfigurationProperty): void;
    resetDeviceConfiguration(): void;
    get deviceConfigurationInput(): AwsUserPool.DeviceConfigurationProperty | undefined;
    private _emailConfiguration;
    get emailConfiguration(): AwsUserPool.EmailConfigurationPropertyOutputReference;
    putEmailConfiguration(value: AwsUserPool.EmailConfigurationProperty): void;
    resetEmailConfiguration(): void;
    get emailConfigurationInput(): AwsUserPool.EmailConfigurationProperty | undefined;
    private _emailMfaConfiguration;
    get emailMfaConfiguration(): AwsUserPool.EmailMfaConfigurationPropertyOutputReference;
    putEmailMfaConfiguration(value: AwsUserPool.EmailMfaConfigurationProperty): void;
    resetEmailMfaConfiguration(): void;
    get emailMfaConfigurationInput(): AwsUserPool.EmailMfaConfigurationProperty | undefined;
    private _lambdaConfig;
    get lambdaConfig(): AwsUserPool.LambdaConfigPropertyOutputReference;
    putLambdaConfig(value: AwsUserPool.LambdaConfigProperty): void;
    resetLambdaConfig(): void;
    get lambdaConfigInput(): AwsUserPool.LambdaConfigProperty | undefined;
    private _passwordPolicy;
    get passwordPolicy(): AwsUserPool.PasswordPolicyPropertyOutputReference;
    putPasswordPolicy(value: AwsUserPool.PasswordPolicyProperty): void;
    resetPasswordPolicy(): void;
    get passwordPolicyInput(): AwsUserPool.PasswordPolicyProperty | undefined;
    private _schema;
    get schema(): AwsUserPool.SchemaPropertyList;
    putSchema(value: AwsUserPool.SchemaProperty[] | cdktn.IResolvable): void;
    resetSchema(): void;
    get schemaInput(): cdktn.IResolvable | AwsUserPool.SchemaProperty[] | undefined;
    private _signInPolicy;
    get signInPolicy(): AwsUserPool.SignInPolicyPropertyOutputReference;
    putSignInPolicy(value: AwsUserPool.SignInPolicyProperty): void;
    resetSignInPolicy(): void;
    get signInPolicyInput(): AwsUserPool.SignInPolicyProperty | undefined;
    private _smsConfiguration;
    get smsConfiguration(): AwsUserPool.SmsConfigurationPropertyOutputReference;
    putSmsConfiguration(value: AwsUserPool.SmsConfigurationProperty): void;
    resetSmsConfiguration(): void;
    get smsConfigurationInput(): AwsUserPool.SmsConfigurationProperty | undefined;
    private _softwareTokenMfaConfiguration;
    get softwareTokenMfaConfiguration(): AwsUserPool.SoftwareTokenMfaConfigurationPropertyOutputReference;
    putSoftwareTokenMfaConfiguration(value: AwsUserPool.SoftwareTokenMfaConfigurationProperty): void;
    resetSoftwareTokenMfaConfiguration(): void;
    get softwareTokenMfaConfigurationInput(): AwsUserPool.SoftwareTokenMfaConfigurationProperty | undefined;
    private _userAttributeUpdateSettings;
    get userAttributeUpdateSettings(): AwsUserPool.UserAttributeUpdateSettingsPropertyOutputReference;
    putUserAttributeUpdateSettings(value: AwsUserPool.UserAttributeUpdateSettingsProperty): void;
    resetUserAttributeUpdateSettings(): void;
    get userAttributeUpdateSettingsInput(): AwsUserPool.UserAttributeUpdateSettingsProperty | undefined;
    private _userPoolAddOns;
    get userPoolAddOns(): AwsUserPool.UserPoolAddOnsPropertyOutputReference;
    putUserPoolAddOns(value: AwsUserPool.UserPoolAddOnsProperty): void;
    resetUserPoolAddOns(): void;
    get userPoolAddOnsInput(): AwsUserPool.UserPoolAddOnsProperty | undefined;
    private _usernameConfiguration;
    get usernameConfiguration(): AwsUserPool.UsernameConfigurationPropertyOutputReference;
    putUsernameConfiguration(value: AwsUserPool.UsernameConfigurationProperty): void;
    resetUsernameConfiguration(): void;
    get usernameConfigurationInput(): AwsUserPool.UsernameConfigurationProperty | undefined;
    private _verificationMessageTemplate;
    get verificationMessageTemplate(): AwsUserPool.VerificationMessageTemplatePropertyOutputReference;
    putVerificationMessageTemplate(value: AwsUserPool.VerificationMessageTemplateProperty): void;
    resetVerificationMessageTemplate(): void;
    get verificationMessageTemplateInput(): AwsUserPool.VerificationMessageTemplateProperty | undefined;
    private _webAuthnConfiguration;
    get webAuthnConfiguration(): AwsUserPool.WebAuthnConfigurationPropertyOutputReference;
    putWebAuthnConfiguration(value: AwsUserPool.WebAuthnConfigurationProperty): void;
    resetWebAuthnConfiguration(): void;
    get webAuthnConfigurationInput(): AwsUserPool.WebAuthnConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsUserPoolRecoveryMechanismPropertyToTerraform(struct?: AwsUserPool.RecoveryMechanismProperty | cdktn.IResolvable): any;
export declare function awsUserPoolRecoveryMechanismPropertyToHclTerraform(struct?: AwsUserPool.RecoveryMechanismProperty | cdktn.IResolvable): any;
export declare function awsUserPoolAccountRecoverySettingPropertyToTerraform(struct?: AwsUserPool.AccountRecoverySettingPropertyOutputReference | AwsUserPool.AccountRecoverySettingProperty): any;
export declare function awsUserPoolAccountRecoverySettingPropertyToHclTerraform(struct?: AwsUserPool.AccountRecoverySettingPropertyOutputReference | AwsUserPool.AccountRecoverySettingProperty): any;
export declare function awsUserPoolInviteMessageTemplatePropertyToTerraform(struct?: AwsUserPool.InviteMessageTemplatePropertyOutputReference | AwsUserPool.InviteMessageTemplateProperty): any;
export declare function awsUserPoolInviteMessageTemplatePropertyToHclTerraform(struct?: AwsUserPool.InviteMessageTemplatePropertyOutputReference | AwsUserPool.InviteMessageTemplateProperty): any;
export declare function awsUserPoolAdminCreateUserConfigPropertyToTerraform(struct?: AwsUserPool.AdminCreateUserConfigPropertyOutputReference | AwsUserPool.AdminCreateUserConfigProperty): any;
export declare function awsUserPoolAdminCreateUserConfigPropertyToHclTerraform(struct?: AwsUserPool.AdminCreateUserConfigPropertyOutputReference | AwsUserPool.AdminCreateUserConfigProperty): any;
export declare function awsUserPoolDeviceConfigurationPropertyToTerraform(struct?: AwsUserPool.DeviceConfigurationPropertyOutputReference | AwsUserPool.DeviceConfigurationProperty): any;
export declare function awsUserPoolDeviceConfigurationPropertyToHclTerraform(struct?: AwsUserPool.DeviceConfigurationPropertyOutputReference | AwsUserPool.DeviceConfigurationProperty): any;
export declare function awsUserPoolEmailConfigurationPropertyToTerraform(struct?: AwsUserPool.EmailConfigurationPropertyOutputReference | AwsUserPool.EmailConfigurationProperty): any;
export declare function awsUserPoolEmailConfigurationPropertyToHclTerraform(struct?: AwsUserPool.EmailConfigurationPropertyOutputReference | AwsUserPool.EmailConfigurationProperty): any;
export declare function awsUserPoolEmailMfaConfigurationPropertyToTerraform(struct?: AwsUserPool.EmailMfaConfigurationPropertyOutputReference | AwsUserPool.EmailMfaConfigurationProperty): any;
export declare function awsUserPoolEmailMfaConfigurationPropertyToHclTerraform(struct?: AwsUserPool.EmailMfaConfigurationPropertyOutputReference | AwsUserPool.EmailMfaConfigurationProperty): any;
export declare function awsUserPoolCustomEmailSenderPropertyToTerraform(struct?: AwsUserPool.CustomEmailSenderPropertyOutputReference | AwsUserPool.CustomEmailSenderProperty): any;
export declare function awsUserPoolCustomEmailSenderPropertyToHclTerraform(struct?: AwsUserPool.CustomEmailSenderPropertyOutputReference | AwsUserPool.CustomEmailSenderProperty): any;
export declare function awsUserPoolCustomSmsSenderPropertyToTerraform(struct?: AwsUserPool.CustomSmsSenderPropertyOutputReference | AwsUserPool.CustomSmsSenderProperty): any;
export declare function awsUserPoolCustomSmsSenderPropertyToHclTerraform(struct?: AwsUserPool.CustomSmsSenderPropertyOutputReference | AwsUserPool.CustomSmsSenderProperty): any;
export declare function awsUserPoolPreTokenGenerationConfigPropertyToTerraform(struct?: AwsUserPool.PreTokenGenerationConfigPropertyOutputReference | AwsUserPool.PreTokenGenerationConfigProperty): any;
export declare function awsUserPoolPreTokenGenerationConfigPropertyToHclTerraform(struct?: AwsUserPool.PreTokenGenerationConfigPropertyOutputReference | AwsUserPool.PreTokenGenerationConfigProperty): any;
export declare function awsUserPoolLambdaConfigPropertyToTerraform(struct?: AwsUserPool.LambdaConfigPropertyOutputReference | AwsUserPool.LambdaConfigProperty): any;
export declare function awsUserPoolLambdaConfigPropertyToHclTerraform(struct?: AwsUserPool.LambdaConfigPropertyOutputReference | AwsUserPool.LambdaConfigProperty): any;
export declare function awsUserPoolPasswordPolicyPropertyToTerraform(struct?: AwsUserPool.PasswordPolicyPropertyOutputReference | AwsUserPool.PasswordPolicyProperty): any;
export declare function awsUserPoolPasswordPolicyPropertyToHclTerraform(struct?: AwsUserPool.PasswordPolicyPropertyOutputReference | AwsUserPool.PasswordPolicyProperty): any;
export declare function awsUserPoolNumberAttributeConstraintsPropertyToTerraform(struct?: AwsUserPool.NumberAttributeConstraintsPropertyOutputReference | AwsUserPool.NumberAttributeConstraintsProperty): any;
export declare function awsUserPoolNumberAttributeConstraintsPropertyToHclTerraform(struct?: AwsUserPool.NumberAttributeConstraintsPropertyOutputReference | AwsUserPool.NumberAttributeConstraintsProperty): any;
export declare function awsUserPoolStringAttributeConstraintsPropertyToTerraform(struct?: AwsUserPool.StringAttributeConstraintsPropertyOutputReference | AwsUserPool.StringAttributeConstraintsProperty): any;
export declare function awsUserPoolStringAttributeConstraintsPropertyToHclTerraform(struct?: AwsUserPool.StringAttributeConstraintsPropertyOutputReference | AwsUserPool.StringAttributeConstraintsProperty): any;
export declare function awsUserPoolSchemaPropertyToTerraform(struct?: AwsUserPool.SchemaProperty | cdktn.IResolvable): any;
export declare function awsUserPoolSchemaPropertyToHclTerraform(struct?: AwsUserPool.SchemaProperty | cdktn.IResolvable): any;
export declare function awsUserPoolSignInPolicyPropertyToTerraform(struct?: AwsUserPool.SignInPolicyPropertyOutputReference | AwsUserPool.SignInPolicyProperty): any;
export declare function awsUserPoolSignInPolicyPropertyToHclTerraform(struct?: AwsUserPool.SignInPolicyPropertyOutputReference | AwsUserPool.SignInPolicyProperty): any;
export declare function awsUserPoolSmsConfigurationPropertyToTerraform(struct?: AwsUserPool.SmsConfigurationPropertyOutputReference | AwsUserPool.SmsConfigurationProperty): any;
export declare function awsUserPoolSmsConfigurationPropertyToHclTerraform(struct?: AwsUserPool.SmsConfigurationPropertyOutputReference | AwsUserPool.SmsConfigurationProperty): any;
export declare function awsUserPoolSoftwareTokenMfaConfigurationPropertyToTerraform(struct?: AwsUserPool.SoftwareTokenMfaConfigurationPropertyOutputReference | AwsUserPool.SoftwareTokenMfaConfigurationProperty): any;
export declare function awsUserPoolSoftwareTokenMfaConfigurationPropertyToHclTerraform(struct?: AwsUserPool.SoftwareTokenMfaConfigurationPropertyOutputReference | AwsUserPool.SoftwareTokenMfaConfigurationProperty): any;
export declare function awsUserPoolUserAttributeUpdateSettingsPropertyToTerraform(struct?: AwsUserPool.UserAttributeUpdateSettingsPropertyOutputReference | AwsUserPool.UserAttributeUpdateSettingsProperty): any;
export declare function awsUserPoolUserAttributeUpdateSettingsPropertyToHclTerraform(struct?: AwsUserPool.UserAttributeUpdateSettingsPropertyOutputReference | AwsUserPool.UserAttributeUpdateSettingsProperty): any;
export declare function awsUserPoolAdvancedSecurityAdditionalFlowsPropertyToTerraform(struct?: AwsUserPool.AdvancedSecurityAdditionalFlowsPropertyOutputReference | AwsUserPool.AdvancedSecurityAdditionalFlowsProperty): any;
export declare function awsUserPoolAdvancedSecurityAdditionalFlowsPropertyToHclTerraform(struct?: AwsUserPool.AdvancedSecurityAdditionalFlowsPropertyOutputReference | AwsUserPool.AdvancedSecurityAdditionalFlowsProperty): any;
export declare function awsUserPoolUserPoolAddOnsPropertyToTerraform(struct?: AwsUserPool.UserPoolAddOnsPropertyOutputReference | AwsUserPool.UserPoolAddOnsProperty): any;
export declare function awsUserPoolUserPoolAddOnsPropertyToHclTerraform(struct?: AwsUserPool.UserPoolAddOnsPropertyOutputReference | AwsUserPool.UserPoolAddOnsProperty): any;
export declare function awsUserPoolUsernameConfigurationPropertyToTerraform(struct?: AwsUserPool.UsernameConfigurationPropertyOutputReference | AwsUserPool.UsernameConfigurationProperty): any;
export declare function awsUserPoolUsernameConfigurationPropertyToHclTerraform(struct?: AwsUserPool.UsernameConfigurationPropertyOutputReference | AwsUserPool.UsernameConfigurationProperty): any;
export declare function awsUserPoolVerificationMessageTemplatePropertyToTerraform(struct?: AwsUserPool.VerificationMessageTemplatePropertyOutputReference | AwsUserPool.VerificationMessageTemplateProperty): any;
export declare function awsUserPoolVerificationMessageTemplatePropertyToHclTerraform(struct?: AwsUserPool.VerificationMessageTemplatePropertyOutputReference | AwsUserPool.VerificationMessageTemplateProperty): any;
export declare function awsUserPoolWebAuthnConfigurationPropertyToTerraform(struct?: AwsUserPool.WebAuthnConfigurationPropertyOutputReference | AwsUserPool.WebAuthnConfigurationProperty): any;
export declare function awsUserPoolWebAuthnConfigurationPropertyToHclTerraform(struct?: AwsUserPool.WebAuthnConfigurationPropertyOutputReference | AwsUserPool.WebAuthnConfigurationProperty): any;
export declare namespace AwsUserPool {
    interface RecoveryMechanismProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#name AwsUserPool#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#priority AwsUserPool#priority}
        */
        readonly priority: number;
    }
    class RecoveryMechanismPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RecoveryMechanismProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RecoveryMechanismProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _priority?;
        get priority(): number;
        set priority(value: number);
        get priorityInput(): number | undefined;
    }
    class RecoveryMechanismPropertyList extends cdktn.ComplexList {
        internalValue?: RecoveryMechanismProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RecoveryMechanismPropertyOutputReference;
    }
    interface AccountRecoverySettingProperty {
        /**
        * recovery_mechanism block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#recovery_mechanism AwsUserPool#recovery_mechanism}
        */
        readonly recoveryMechanism?: RecoveryMechanismProperty[] | cdktn.IResolvable;
    }
    class AccountRecoverySettingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AccountRecoverySettingProperty | undefined;
        set internalValue(value: AccountRecoverySettingProperty | undefined);
        private _recoveryMechanism;
        get recoveryMechanism(): RecoveryMechanismPropertyList;
        putRecoveryMechanism(value: RecoveryMechanismProperty[] | cdktn.IResolvable): void;
        resetRecoveryMechanism(): void;
        get recoveryMechanismInput(): cdktn.IResolvable | RecoveryMechanismProperty[] | undefined;
    }
    interface InviteMessageTemplateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#email_message AwsUserPool#email_message}
        */
        readonly emailMessage?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#email_subject AwsUserPool#email_subject}
        */
        readonly emailSubject?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#sms_message AwsUserPool#sms_message}
        */
        readonly smsMessage?: string;
    }
    class InviteMessageTemplatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InviteMessageTemplateProperty | undefined;
        set internalValue(value: InviteMessageTemplateProperty | undefined);
        private _emailMessage?;
        get emailMessage(): string;
        set emailMessage(value: string);
        resetEmailMessage(): void;
        get emailMessageInput(): string | undefined;
        private _emailSubject?;
        get emailSubject(): string;
        set emailSubject(value: string);
        resetEmailSubject(): void;
        get emailSubjectInput(): string | undefined;
        private _smsMessage?;
        get smsMessage(): string;
        set smsMessage(value: string);
        resetSmsMessage(): void;
        get smsMessageInput(): string | undefined;
    }
    interface AdminCreateUserConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#allow_admin_create_user_only AwsUserPool#allow_admin_create_user_only}
        */
        readonly allowAdminCreateUserOnly?: boolean | cdktn.IResolvable;
        /**
        * invite_message_template block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#invite_message_template AwsUserPool#invite_message_template}
        */
        readonly inviteMessageTemplate?: InviteMessageTemplateProperty;
    }
    class AdminCreateUserConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AdminCreateUserConfigProperty | undefined;
        set internalValue(value: AdminCreateUserConfigProperty | undefined);
        private _allowAdminCreateUserOnly?;
        get allowAdminCreateUserOnly(): boolean | cdktn.IResolvable;
        set allowAdminCreateUserOnly(value: boolean | cdktn.IResolvable);
        resetAllowAdminCreateUserOnly(): void;
        get allowAdminCreateUserOnlyInput(): boolean | cdktn.IResolvable | undefined;
        private _inviteMessageTemplate;
        get inviteMessageTemplate(): InviteMessageTemplatePropertyOutputReference;
        putInviteMessageTemplate(value: InviteMessageTemplateProperty): void;
        resetInviteMessageTemplate(): void;
        get inviteMessageTemplateInput(): InviteMessageTemplateProperty | undefined;
    }
    interface DeviceConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#challenge_required_on_new_device AwsUserPool#challenge_required_on_new_device}
        */
        readonly challengeRequiredOnNewDevice?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#device_only_remembered_on_user_prompt AwsUserPool#device_only_remembered_on_user_prompt}
        */
        readonly deviceOnlyRememberedOnUserPrompt?: boolean | cdktn.IResolvable;
    }
    class DeviceConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DeviceConfigurationProperty | undefined;
        set internalValue(value: DeviceConfigurationProperty | undefined);
        private _challengeRequiredOnNewDevice?;
        get challengeRequiredOnNewDevice(): boolean | cdktn.IResolvable;
        set challengeRequiredOnNewDevice(value: boolean | cdktn.IResolvable);
        resetChallengeRequiredOnNewDevice(): void;
        get challengeRequiredOnNewDeviceInput(): boolean | cdktn.IResolvable | undefined;
        private _deviceOnlyRememberedOnUserPrompt?;
        get deviceOnlyRememberedOnUserPrompt(): boolean | cdktn.IResolvable;
        set deviceOnlyRememberedOnUserPrompt(value: boolean | cdktn.IResolvable);
        resetDeviceOnlyRememberedOnUserPrompt(): void;
        get deviceOnlyRememberedOnUserPromptInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface EmailConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#configuration_set AwsUserPool#configuration_set}
        */
        readonly configurationSet?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#email_sending_account AwsUserPool#email_sending_account}
        */
        readonly emailSendingAccount?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#from_email_address AwsUserPool#from_email_address}
        */
        readonly fromEmailAddress?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#reply_to_email_address AwsUserPool#reply_to_email_address}
        */
        readonly replyToEmailAddress?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#source_arn AwsUserPool#source_arn}
        */
        readonly sourceArn?: string;
    }
    class EmailConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EmailConfigurationProperty | undefined;
        set internalValue(value: EmailConfigurationProperty | undefined);
        private _configurationSet?;
        get configurationSet(): string;
        set configurationSet(value: string);
        resetConfigurationSet(): void;
        get configurationSetInput(): string | undefined;
        private _emailSendingAccount?;
        get emailSendingAccount(): string;
        set emailSendingAccount(value: string);
        resetEmailSendingAccount(): void;
        get emailSendingAccountInput(): string | undefined;
        private _fromEmailAddress?;
        get fromEmailAddress(): string;
        set fromEmailAddress(value: string);
        resetFromEmailAddress(): void;
        get fromEmailAddressInput(): string | undefined;
        private _replyToEmailAddress?;
        get replyToEmailAddress(): string;
        set replyToEmailAddress(value: string);
        resetReplyToEmailAddress(): void;
        get replyToEmailAddressInput(): string | undefined;
        private _sourceArn?;
        get sourceArn(): string;
        set sourceArn(value: string);
        resetSourceArn(): void;
        get sourceArnInput(): string | undefined;
    }
    interface EmailMfaConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#message AwsUserPool#message}
        */
        readonly message?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#subject AwsUserPool#subject}
        */
        readonly subject?: string;
    }
    class EmailMfaConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EmailMfaConfigurationProperty | undefined;
        set internalValue(value: EmailMfaConfigurationProperty | undefined);
        private _message?;
        get message(): string;
        set message(value: string);
        resetMessage(): void;
        get messageInput(): string | undefined;
        private _subject?;
        get subject(): string;
        set subject(value: string);
        resetSubject(): void;
        get subjectInput(): string | undefined;
    }
    interface CustomEmailSenderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#lambda_arn AwsUserPool#lambda_arn}
        */
        readonly lambdaArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#lambda_version AwsUserPool#lambda_version}
        */
        readonly lambdaVersion: string;
    }
    class CustomEmailSenderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CustomEmailSenderProperty | undefined;
        set internalValue(value: CustomEmailSenderProperty | undefined);
        private _lambdaArn?;
        get lambdaArn(): string;
        set lambdaArn(value: string);
        get lambdaArnInput(): string | undefined;
        private _lambdaVersion?;
        get lambdaVersion(): string;
        set lambdaVersion(value: string);
        get lambdaVersionInput(): string | undefined;
    }
    interface CustomSmsSenderProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#lambda_arn AwsUserPool#lambda_arn}
        */
        readonly lambdaArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#lambda_version AwsUserPool#lambda_version}
        */
        readonly lambdaVersion: string;
    }
    class CustomSmsSenderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CustomSmsSenderProperty | undefined;
        set internalValue(value: CustomSmsSenderProperty | undefined);
        private _lambdaArn?;
        get lambdaArn(): string;
        set lambdaArn(value: string);
        get lambdaArnInput(): string | undefined;
        private _lambdaVersion?;
        get lambdaVersion(): string;
        set lambdaVersion(value: string);
        get lambdaVersionInput(): string | undefined;
    }
    interface PreTokenGenerationConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#lambda_arn AwsUserPool#lambda_arn}
        */
        readonly lambdaArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#lambda_version AwsUserPool#lambda_version}
        */
        readonly lambdaVersion: string;
    }
    class PreTokenGenerationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PreTokenGenerationConfigProperty | undefined;
        set internalValue(value: PreTokenGenerationConfigProperty | undefined);
        private _lambdaArn?;
        get lambdaArn(): string;
        set lambdaArn(value: string);
        get lambdaArnInput(): string | undefined;
        private _lambdaVersion?;
        get lambdaVersion(): string;
        set lambdaVersion(value: string);
        get lambdaVersionInput(): string | undefined;
    }
    interface LambdaConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#create_auth_challenge AwsUserPool#create_auth_challenge}
        */
        readonly createAuthChallenge?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#custom_message AwsUserPool#custom_message}
        */
        readonly customMessage?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#define_auth_challenge AwsUserPool#define_auth_challenge}
        */
        readonly defineAuthChallenge?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#kms_key_id AwsUserPool#kms_key_id}
        */
        readonly kmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#post_authentication AwsUserPool#post_authentication}
        */
        readonly postAuthentication?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#post_confirmation AwsUserPool#post_confirmation}
        */
        readonly postConfirmation?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#pre_authentication AwsUserPool#pre_authentication}
        */
        readonly preAuthentication?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#pre_sign_up AwsUserPool#pre_sign_up}
        */
        readonly preSignUp?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#pre_token_generation AwsUserPool#pre_token_generation}
        */
        readonly preTokenGeneration?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#user_migration AwsUserPool#user_migration}
        */
        readonly userMigration?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#verify_auth_challenge_response AwsUserPool#verify_auth_challenge_response}
        */
        readonly verifyAuthChallengeResponse?: string;
        /**
        * custom_email_sender block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#custom_email_sender AwsUserPool#custom_email_sender}
        */
        readonly customEmailSender?: CustomEmailSenderProperty;
        /**
        * custom_sms_sender block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#custom_sms_sender AwsUserPool#custom_sms_sender}
        */
        readonly customSmsSender?: CustomSmsSenderProperty;
        /**
        * pre_token_generation_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#pre_token_generation_config AwsUserPool#pre_token_generation_config}
        */
        readonly preTokenGenerationConfig?: PreTokenGenerationConfigProperty;
    }
    class LambdaConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LambdaConfigProperty | undefined;
        set internalValue(value: LambdaConfigProperty | undefined);
        private _createAuthChallenge?;
        get createAuthChallenge(): string;
        set createAuthChallenge(value: string);
        resetCreateAuthChallenge(): void;
        get createAuthChallengeInput(): string | undefined;
        private _customMessage?;
        get customMessage(): string;
        set customMessage(value: string);
        resetCustomMessage(): void;
        get customMessageInput(): string | undefined;
        private _defineAuthChallenge?;
        get defineAuthChallenge(): string;
        set defineAuthChallenge(value: string);
        resetDefineAuthChallenge(): void;
        get defineAuthChallengeInput(): string | undefined;
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
        private _postAuthentication?;
        get postAuthentication(): string;
        set postAuthentication(value: string);
        resetPostAuthentication(): void;
        get postAuthenticationInput(): string | undefined;
        private _postConfirmation?;
        get postConfirmation(): string;
        set postConfirmation(value: string);
        resetPostConfirmation(): void;
        get postConfirmationInput(): string | undefined;
        private _preAuthentication?;
        get preAuthentication(): string;
        set preAuthentication(value: string);
        resetPreAuthentication(): void;
        get preAuthenticationInput(): string | undefined;
        private _preSignUp?;
        get preSignUp(): string;
        set preSignUp(value: string);
        resetPreSignUp(): void;
        get preSignUpInput(): string | undefined;
        private _preTokenGeneration?;
        get preTokenGeneration(): string;
        set preTokenGeneration(value: string);
        resetPreTokenGeneration(): void;
        get preTokenGenerationInput(): string | undefined;
        private _userMigration?;
        get userMigration(): string;
        set userMigration(value: string);
        resetUserMigration(): void;
        get userMigrationInput(): string | undefined;
        private _verifyAuthChallengeResponse?;
        get verifyAuthChallengeResponse(): string;
        set verifyAuthChallengeResponse(value: string);
        resetVerifyAuthChallengeResponse(): void;
        get verifyAuthChallengeResponseInput(): string | undefined;
        private _customEmailSender;
        get customEmailSender(): CustomEmailSenderPropertyOutputReference;
        putCustomEmailSender(value: CustomEmailSenderProperty): void;
        resetCustomEmailSender(): void;
        get customEmailSenderInput(): CustomEmailSenderProperty | undefined;
        private _customSmsSender;
        get customSmsSender(): CustomSmsSenderPropertyOutputReference;
        putCustomSmsSender(value: CustomSmsSenderProperty): void;
        resetCustomSmsSender(): void;
        get customSmsSenderInput(): CustomSmsSenderProperty | undefined;
        private _preTokenGenerationConfig;
        get preTokenGenerationConfig(): PreTokenGenerationConfigPropertyOutputReference;
        putPreTokenGenerationConfig(value: PreTokenGenerationConfigProperty): void;
        resetPreTokenGenerationConfig(): void;
        get preTokenGenerationConfigInput(): PreTokenGenerationConfigProperty | undefined;
    }
    interface PasswordPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#minimum_length AwsUserPool#minimum_length}
        */
        readonly minimumLength?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#password_history_size AwsUserPool#password_history_size}
        */
        readonly passwordHistorySize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#require_lowercase AwsUserPool#require_lowercase}
        */
        readonly requireLowercase?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#require_numbers AwsUserPool#require_numbers}
        */
        readonly requireNumbers?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#require_symbols AwsUserPool#require_symbols}
        */
        readonly requireSymbols?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#require_uppercase AwsUserPool#require_uppercase}
        */
        readonly requireUppercase?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#temporary_password_validity_days AwsUserPool#temporary_password_validity_days}
        */
        readonly temporaryPasswordValidityDays?: number;
    }
    class PasswordPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PasswordPolicyProperty | undefined;
        set internalValue(value: PasswordPolicyProperty | undefined);
        private _minimumLength?;
        get minimumLength(): number;
        set minimumLength(value: number);
        resetMinimumLength(): void;
        get minimumLengthInput(): number | undefined;
        private _passwordHistorySize?;
        get passwordHistorySize(): number;
        set passwordHistorySize(value: number);
        resetPasswordHistorySize(): void;
        get passwordHistorySizeInput(): number | undefined;
        private _requireLowercase?;
        get requireLowercase(): boolean | cdktn.IResolvable;
        set requireLowercase(value: boolean | cdktn.IResolvable);
        resetRequireLowercase(): void;
        get requireLowercaseInput(): boolean | cdktn.IResolvable | undefined;
        private _requireNumbers?;
        get requireNumbers(): boolean | cdktn.IResolvable;
        set requireNumbers(value: boolean | cdktn.IResolvable);
        resetRequireNumbers(): void;
        get requireNumbersInput(): boolean | cdktn.IResolvable | undefined;
        private _requireSymbols?;
        get requireSymbols(): boolean | cdktn.IResolvable;
        set requireSymbols(value: boolean | cdktn.IResolvable);
        resetRequireSymbols(): void;
        get requireSymbolsInput(): boolean | cdktn.IResolvable | undefined;
        private _requireUppercase?;
        get requireUppercase(): boolean | cdktn.IResolvable;
        set requireUppercase(value: boolean | cdktn.IResolvable);
        resetRequireUppercase(): void;
        get requireUppercaseInput(): boolean | cdktn.IResolvable | undefined;
        private _temporaryPasswordValidityDays?;
        get temporaryPasswordValidityDays(): number;
        set temporaryPasswordValidityDays(value: number);
        resetTemporaryPasswordValidityDays(): void;
        get temporaryPasswordValidityDaysInput(): number | undefined;
    }
    interface NumberAttributeConstraintsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#max_value AwsUserPool#max_value}
        */
        readonly maxValue?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#min_value AwsUserPool#min_value}
        */
        readonly minValue?: string;
    }
    class NumberAttributeConstraintsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NumberAttributeConstraintsProperty | undefined;
        set internalValue(value: NumberAttributeConstraintsProperty | undefined);
        private _maxValue?;
        get maxValue(): string;
        set maxValue(value: string);
        resetMaxValue(): void;
        get maxValueInput(): string | undefined;
        private _minValue?;
        get minValue(): string;
        set minValue(value: string);
        resetMinValue(): void;
        get minValueInput(): string | undefined;
    }
    interface StringAttributeConstraintsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#max_length AwsUserPool#max_length}
        */
        readonly maxLength?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#min_length AwsUserPool#min_length}
        */
        readonly minLength?: string;
    }
    class StringAttributeConstraintsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StringAttributeConstraintsProperty | undefined;
        set internalValue(value: StringAttributeConstraintsProperty | undefined);
        private _maxLength?;
        get maxLength(): string;
        set maxLength(value: string);
        resetMaxLength(): void;
        get maxLengthInput(): string | undefined;
        private _minLength?;
        get minLength(): string;
        set minLength(value: string);
        resetMinLength(): void;
        get minLengthInput(): string | undefined;
    }
    interface SchemaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#attribute_data_type AwsUserPool#attribute_data_type}
        */
        readonly attributeDataType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#developer_only_attribute AwsUserPool#developer_only_attribute}
        */
        readonly developerOnlyAttribute?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#mutable AwsUserPool#mutable}
        */
        readonly mutable?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#name AwsUserPool#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#required AwsUserPool#required}
        */
        readonly required?: boolean | cdktn.IResolvable;
        /**
        * number_attribute_constraints block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#number_attribute_constraints AwsUserPool#number_attribute_constraints}
        */
        readonly numberAttributeConstraints?: NumberAttributeConstraintsProperty;
        /**
        * string_attribute_constraints block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#string_attribute_constraints AwsUserPool#string_attribute_constraints}
        */
        readonly stringAttributeConstraints?: StringAttributeConstraintsProperty;
    }
    class SchemaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SchemaProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SchemaProperty | cdktn.IResolvable | undefined);
        private _attributeDataType?;
        get attributeDataType(): string;
        set attributeDataType(value: string);
        get attributeDataTypeInput(): string | undefined;
        private _developerOnlyAttribute?;
        get developerOnlyAttribute(): boolean | cdktn.IResolvable;
        set developerOnlyAttribute(value: boolean | cdktn.IResolvable);
        resetDeveloperOnlyAttribute(): void;
        get developerOnlyAttributeInput(): boolean | cdktn.IResolvable | undefined;
        private _mutable?;
        get mutable(): boolean | cdktn.IResolvable;
        set mutable(value: boolean | cdktn.IResolvable);
        resetMutable(): void;
        get mutableInput(): boolean | cdktn.IResolvable | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _required?;
        get required(): boolean | cdktn.IResolvable;
        set required(value: boolean | cdktn.IResolvable);
        resetRequired(): void;
        get requiredInput(): boolean | cdktn.IResolvable | undefined;
        private _numberAttributeConstraints;
        get numberAttributeConstraints(): NumberAttributeConstraintsPropertyOutputReference;
        putNumberAttributeConstraints(value: NumberAttributeConstraintsProperty): void;
        resetNumberAttributeConstraints(): void;
        get numberAttributeConstraintsInput(): NumberAttributeConstraintsProperty | undefined;
        private _stringAttributeConstraints;
        get stringAttributeConstraints(): StringAttributeConstraintsPropertyOutputReference;
        putStringAttributeConstraints(value: StringAttributeConstraintsProperty): void;
        resetStringAttributeConstraints(): void;
        get stringAttributeConstraintsInput(): StringAttributeConstraintsProperty | undefined;
    }
    class SchemaPropertyList extends cdktn.ComplexList {
        internalValue?: SchemaProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SchemaPropertyOutputReference;
    }
    interface SignInPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#allowed_first_auth_factors AwsUserPool#allowed_first_auth_factors}
        */
        readonly allowedFirstAuthFactors?: string[];
    }
    class SignInPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SignInPolicyProperty | undefined;
        set internalValue(value: SignInPolicyProperty | undefined);
        private _allowedFirstAuthFactors?;
        get allowedFirstAuthFactors(): string[];
        set allowedFirstAuthFactors(value: string[]);
        resetAllowedFirstAuthFactors(): void;
        get allowedFirstAuthFactorsInput(): string[] | undefined;
    }
    interface SmsConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#external_id AwsUserPool#external_id}
        */
        readonly externalId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#sns_caller_arn AwsUserPool#sns_caller_arn}
        */
        readonly snsCallerArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#sns_region AwsUserPool#sns_region}
        */
        readonly snsRegion?: string;
    }
    class SmsConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SmsConfigurationProperty | undefined;
        set internalValue(value: SmsConfigurationProperty | undefined);
        private _externalId?;
        get externalId(): string;
        set externalId(value: string);
        get externalIdInput(): string | undefined;
        private _snsCallerArn?;
        get snsCallerArn(): string;
        set snsCallerArn(value: string);
        get snsCallerArnInput(): string | undefined;
        private _snsRegion?;
        get snsRegion(): string;
        set snsRegion(value: string);
        resetSnsRegion(): void;
        get snsRegionInput(): string | undefined;
    }
    interface SoftwareTokenMfaConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#enabled AwsUserPool#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
    }
    class SoftwareTokenMfaConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SoftwareTokenMfaConfigurationProperty | undefined;
        set internalValue(value: SoftwareTokenMfaConfigurationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface UserAttributeUpdateSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#attributes_require_verification_before_update AwsUserPool#attributes_require_verification_before_update}
        */
        readonly attributesRequireVerificationBeforeUpdate: string[];
    }
    class UserAttributeUpdateSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UserAttributeUpdateSettingsProperty | undefined;
        set internalValue(value: UserAttributeUpdateSettingsProperty | undefined);
        private _attributesRequireVerificationBeforeUpdate?;
        get attributesRequireVerificationBeforeUpdate(): string[];
        set attributesRequireVerificationBeforeUpdate(value: string[]);
        get attributesRequireVerificationBeforeUpdateInput(): string[] | undefined;
    }
    interface AdvancedSecurityAdditionalFlowsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#custom_auth_mode AwsUserPool#custom_auth_mode}
        */
        readonly customAuthMode?: string;
    }
    class AdvancedSecurityAdditionalFlowsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AdvancedSecurityAdditionalFlowsProperty | undefined;
        set internalValue(value: AdvancedSecurityAdditionalFlowsProperty | undefined);
        private _customAuthMode?;
        get customAuthMode(): string;
        set customAuthMode(value: string);
        resetCustomAuthMode(): void;
        get customAuthModeInput(): string | undefined;
    }
    interface UserPoolAddOnsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#advanced_security_mode AwsUserPool#advanced_security_mode}
        */
        readonly advancedSecurityMode: string;
        /**
        * advanced_security_additional_flows block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#advanced_security_additional_flows AwsUserPool#advanced_security_additional_flows}
        */
        readonly advancedSecurityAdditionalFlows?: AdvancedSecurityAdditionalFlowsProperty;
    }
    class UserPoolAddOnsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UserPoolAddOnsProperty | undefined;
        set internalValue(value: UserPoolAddOnsProperty | undefined);
        private _advancedSecurityMode?;
        get advancedSecurityMode(): string;
        set advancedSecurityMode(value: string);
        get advancedSecurityModeInput(): string | undefined;
        private _advancedSecurityAdditionalFlows;
        get advancedSecurityAdditionalFlows(): AdvancedSecurityAdditionalFlowsPropertyOutputReference;
        putAdvancedSecurityAdditionalFlows(value: AdvancedSecurityAdditionalFlowsProperty): void;
        resetAdvancedSecurityAdditionalFlows(): void;
        get advancedSecurityAdditionalFlowsInput(): AdvancedSecurityAdditionalFlowsProperty | undefined;
    }
    interface UsernameConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#case_sensitive AwsUserPool#case_sensitive}
        */
        readonly caseSensitive?: boolean | cdktn.IResolvable;
    }
    class UsernameConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UsernameConfigurationProperty | undefined;
        set internalValue(value: UsernameConfigurationProperty | undefined);
        private _caseSensitive?;
        get caseSensitive(): boolean | cdktn.IResolvable;
        set caseSensitive(value: boolean | cdktn.IResolvable);
        resetCaseSensitive(): void;
        get caseSensitiveInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface VerificationMessageTemplateProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#default_email_option AwsUserPool#default_email_option}
        */
        readonly defaultEmailOption?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#email_message AwsUserPool#email_message}
        */
        readonly emailMessage?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#email_message_by_link AwsUserPool#email_message_by_link}
        */
        readonly emailMessageByLink?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#email_subject AwsUserPool#email_subject}
        */
        readonly emailSubject?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#email_subject_by_link AwsUserPool#email_subject_by_link}
        */
        readonly emailSubjectByLink?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#sms_message AwsUserPool#sms_message}
        */
        readonly smsMessage?: string;
    }
    class VerificationMessageTemplatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VerificationMessageTemplateProperty | undefined;
        set internalValue(value: VerificationMessageTemplateProperty | undefined);
        private _defaultEmailOption?;
        get defaultEmailOption(): string;
        set defaultEmailOption(value: string);
        resetDefaultEmailOption(): void;
        get defaultEmailOptionInput(): string | undefined;
        private _emailMessage?;
        get emailMessage(): string;
        set emailMessage(value: string);
        resetEmailMessage(): void;
        get emailMessageInput(): string | undefined;
        private _emailMessageByLink?;
        get emailMessageByLink(): string;
        set emailMessageByLink(value: string);
        resetEmailMessageByLink(): void;
        get emailMessageByLinkInput(): string | undefined;
        private _emailSubject?;
        get emailSubject(): string;
        set emailSubject(value: string);
        resetEmailSubject(): void;
        get emailSubjectInput(): string | undefined;
        private _emailSubjectByLink?;
        get emailSubjectByLink(): string;
        set emailSubjectByLink(value: string);
        resetEmailSubjectByLink(): void;
        get emailSubjectByLinkInput(): string | undefined;
        private _smsMessage?;
        get smsMessage(): string;
        set smsMessage(value: string);
        resetSmsMessage(): void;
        get smsMessageInput(): string | undefined;
    }
    interface WebAuthnConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#relying_party_id AwsUserPool#relying_party_id}
        */
        readonly relyingPartyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/cognito_user_pool#user_verification AwsUserPool#user_verification}
        */
        readonly userVerification?: string;
    }
    class WebAuthnConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): WebAuthnConfigurationProperty | undefined;
        set internalValue(value: WebAuthnConfigurationProperty | undefined);
        private _relyingPartyId?;
        get relyingPartyId(): string;
        set relyingPartyId(value: string);
        resetRelyingPartyId(): void;
        get relyingPartyIdInput(): string | undefined;
        private _userVerification?;
        get userVerification(): string;
        set userVerification(value: string);
        resetUserVerification(): void;
        get userVerificationInput(): string | undefined;
    }
}
