import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfOutboundConnectionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_outbound_connection#accept_connection TfOutboundConnection#accept_connection}
    */
    readonly acceptConnection?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_outbound_connection#connection_alias TfOutboundConnection#connection_alias}
    */
    readonly connectionAlias: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_outbound_connection#connection_mode TfOutboundConnection#connection_mode}
    */
    readonly connectionMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_outbound_connection#id TfOutboundConnection#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_outbound_connection#region TfOutboundConnection#region}
    */
    readonly region?: string;
    /**
    * connection_properties block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_outbound_connection#connection_properties TfOutboundConnection#connection_properties}
    */
    readonly connectionProperties?: TfOutboundConnection.ConnectionPropertiesProperty;
    /**
    * local_domain_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_outbound_connection#local_domain_info TfOutboundConnection#local_domain_info}
    */
    readonly localDomainInfo: TfOutboundConnection.LocalDomainInfoProperty;
    /**
    * remote_domain_info block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_outbound_connection#remote_domain_info TfOutboundConnection#remote_domain_info}
    */
    readonly remoteDomainInfo: TfOutboundConnection.RemoteDomainInfoProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_outbound_connection#timeouts TfOutboundConnection#timeouts}
    */
    readonly timeouts?: TfOutboundConnection.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_outbound_connection aws_opensearch_outbound_connection}
*/
export declare class TfOutboundConnection extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_opensearch_outbound_connection";
    /**
    * Generates CDKTN code for importing a TfOutboundConnection resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfOutboundConnection to import
    * @param importFromId The id of the existing TfOutboundConnection that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_outbound_connection#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfOutboundConnection to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_outbound_connection aws_opensearch_outbound_connection} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfOutboundConnectionConfig
    */
    constructor(scope: Construct, id: string, config: TfOutboundConnectionConfig);
    private _acceptConnection?;
    get acceptConnection(): boolean | cdktn.IResolvable;
    set acceptConnection(value: boolean | cdktn.IResolvable);
    resetAcceptConnection(): void;
    get acceptConnectionInput(): boolean | cdktn.IResolvable | undefined;
    private _connectionAlias?;
    get connectionAlias(): string;
    set connectionAlias(value: string);
    get connectionAliasInput(): string | undefined;
    private _connectionMode?;
    get connectionMode(): string;
    set connectionMode(value: string);
    resetConnectionMode(): void;
    get connectionModeInput(): string | undefined;
    get connectionStatus(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _connectionProperties;
    get connectionProperties(): TfOutboundConnection.ConnectionPropertiesPropertyOutputReference;
    putConnectionProperties(value: TfOutboundConnection.ConnectionPropertiesProperty): void;
    resetConnectionProperties(): void;
    get connectionPropertiesInput(): TfOutboundConnection.ConnectionPropertiesProperty | undefined;
    private _localDomainInfo;
    get localDomainInfo(): TfOutboundConnection.LocalDomainInfoPropertyOutputReference;
    putLocalDomainInfo(value: TfOutboundConnection.LocalDomainInfoProperty): void;
    get localDomainInfoInput(): TfOutboundConnection.LocalDomainInfoProperty | undefined;
    private _remoteDomainInfo;
    get remoteDomainInfo(): TfOutboundConnection.RemoteDomainInfoPropertyOutputReference;
    putRemoteDomainInfo(value: TfOutboundConnection.RemoteDomainInfoProperty): void;
    get remoteDomainInfoInput(): TfOutboundConnection.RemoteDomainInfoProperty | undefined;
    private _timeouts;
    get timeouts(): TfOutboundConnection.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfOutboundConnection.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfOutboundConnection.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfOutboundConnectionCrossClusterSearchPropertyToTerraform(struct?: TfOutboundConnection.CrossClusterSearchPropertyOutputReference | TfOutboundConnection.CrossClusterSearchProperty): any;
export declare function tfOutboundConnectionCrossClusterSearchPropertyToHclTerraform(struct?: TfOutboundConnection.CrossClusterSearchPropertyOutputReference | TfOutboundConnection.CrossClusterSearchProperty): any;
export declare function tfOutboundConnectionConnectionPropertiesPropertyToTerraform(struct?: TfOutboundConnection.ConnectionPropertiesPropertyOutputReference | TfOutboundConnection.ConnectionPropertiesProperty): any;
export declare function tfOutboundConnectionConnectionPropertiesPropertyToHclTerraform(struct?: TfOutboundConnection.ConnectionPropertiesPropertyOutputReference | TfOutboundConnection.ConnectionPropertiesProperty): any;
export declare function tfOutboundConnectionLocalDomainInfoPropertyToTerraform(struct?: TfOutboundConnection.LocalDomainInfoPropertyOutputReference | TfOutboundConnection.LocalDomainInfoProperty): any;
export declare function tfOutboundConnectionLocalDomainInfoPropertyToHclTerraform(struct?: TfOutboundConnection.LocalDomainInfoPropertyOutputReference | TfOutboundConnection.LocalDomainInfoProperty): any;
export declare function tfOutboundConnectionRemoteDomainInfoPropertyToTerraform(struct?: TfOutboundConnection.RemoteDomainInfoPropertyOutputReference | TfOutboundConnection.RemoteDomainInfoProperty): any;
export declare function tfOutboundConnectionRemoteDomainInfoPropertyToHclTerraform(struct?: TfOutboundConnection.RemoteDomainInfoPropertyOutputReference | TfOutboundConnection.RemoteDomainInfoProperty): any;
export declare function tfOutboundConnectionTimeoutsPropertyToTerraform(struct?: TfOutboundConnection.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfOutboundConnectionTimeoutsPropertyToHclTerraform(struct?: TfOutboundConnection.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfOutboundConnection {
    interface CrossClusterSearchProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_outbound_connection#skip_unavailable TfOutboundConnection#skip_unavailable}
        */
        readonly skipUnavailable?: string;
    }
    class CrossClusterSearchPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CrossClusterSearchProperty | undefined;
        set internalValue(value: CrossClusterSearchProperty | undefined);
        private _skipUnavailable?;
        get skipUnavailable(): string;
        set skipUnavailable(value: string);
        resetSkipUnavailable(): void;
        get skipUnavailableInput(): string | undefined;
    }
    interface ConnectionPropertiesProperty {
        /**
        * cross_cluster_search block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_outbound_connection#cross_cluster_search TfOutboundConnection#cross_cluster_search}
        */
        readonly crossClusterSearch?: CrossClusterSearchProperty;
    }
    class ConnectionPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ConnectionPropertiesProperty | undefined;
        set internalValue(value: ConnectionPropertiesProperty | undefined);
        get endpoint(): string;
        private _crossClusterSearch;
        get crossClusterSearch(): CrossClusterSearchPropertyOutputReference;
        putCrossClusterSearch(value: CrossClusterSearchProperty): void;
        resetCrossClusterSearch(): void;
        get crossClusterSearchInput(): CrossClusterSearchProperty | undefined;
    }
    interface LocalDomainInfoProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_outbound_connection#domain_name TfOutboundConnection#domain_name}
        */
        readonly domainName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_outbound_connection#owner_id TfOutboundConnection#owner_id}
        */
        readonly ownerId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_outbound_connection#region TfOutboundConnection#region}
        */
        readonly region: string;
    }
    class LocalDomainInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LocalDomainInfoProperty | undefined;
        set internalValue(value: LocalDomainInfoProperty | undefined);
        private _domainName?;
        get domainName(): string;
        set domainName(value: string);
        get domainNameInput(): string | undefined;
        private _ownerId?;
        get ownerId(): string;
        set ownerId(value: string);
        get ownerIdInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        get regionInput(): string | undefined;
    }
    interface RemoteDomainInfoProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_outbound_connection#domain_name TfOutboundConnection#domain_name}
        */
        readonly domainName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_outbound_connection#owner_id TfOutboundConnection#owner_id}
        */
        readonly ownerId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_outbound_connection#region TfOutboundConnection#region}
        */
        readonly region: string;
    }
    class RemoteDomainInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RemoteDomainInfoProperty | undefined;
        set internalValue(value: RemoteDomainInfoProperty | undefined);
        private _domainName?;
        get domainName(): string;
        set domainName(value: string);
        get domainNameInput(): string | undefined;
        private _ownerId?;
        get ownerId(): string;
        set ownerId(value: string);
        get ownerIdInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        get regionInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_outbound_connection#create TfOutboundConnection#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_outbound_connection#delete TfOutboundConnection#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
