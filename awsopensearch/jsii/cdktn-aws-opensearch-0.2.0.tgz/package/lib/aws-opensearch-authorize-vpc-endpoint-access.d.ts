import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfAuthorizeVpcEndpointAccessConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_authorize_vpc_endpoint_access#account TfAuthorizeVpcEndpointAccess#account}
    */
    readonly account: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_authorize_vpc_endpoint_access#domain_name TfAuthorizeVpcEndpointAccess#domain_name}
    */
    readonly domainName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_authorize_vpc_endpoint_access#region TfAuthorizeVpcEndpointAccess#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_authorize_vpc_endpoint_access aws_opensearch_authorize_vpc_endpoint_access}
*/
export declare class TfAuthorizeVpcEndpointAccess extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_opensearch_authorize_vpc_endpoint_access";
    /**
    * Generates CDKTN code for importing a TfAuthorizeVpcEndpointAccess resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfAuthorizeVpcEndpointAccess to import
    * @param importFromId The id of the existing TfAuthorizeVpcEndpointAccess that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_authorize_vpc_endpoint_access#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfAuthorizeVpcEndpointAccess to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_authorize_vpc_endpoint_access aws_opensearch_authorize_vpc_endpoint_access} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfAuthorizeVpcEndpointAccessConfig
    */
    constructor(scope: Construct, id: string, config: TfAuthorizeVpcEndpointAccessConfig);
    private _account?;
    get account(): string;
    set account(value: string);
    get accountInput(): string | undefined;
    private _authorizedPrincipal;
    get authorizedPrincipal(): TfAuthorizeVpcEndpointAccess.AuthorizedPrincipalPropertyList;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfAuthorizeVpcEndpointAccessAuthorizedPrincipalPropertyToTerraform(struct?: TfAuthorizeVpcEndpointAccess.AuthorizedPrincipalProperty): any;
export declare function tfAuthorizeVpcEndpointAccessAuthorizedPrincipalPropertyToHclTerraform(struct?: TfAuthorizeVpcEndpointAccess.AuthorizedPrincipalProperty): any;
export declare namespace TfAuthorizeVpcEndpointAccess {
    interface AuthorizedPrincipalProperty {
    }
    class AuthorizedPrincipalPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AuthorizedPrincipalProperty | undefined;
        set internalValue(value: AuthorizedPrincipalProperty | undefined);
        get principal(): string;
        get principalType(): string;
    }
    class AuthorizedPrincipalPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AuthorizedPrincipalPropertyOutputReference;
    }
}
