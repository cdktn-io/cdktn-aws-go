import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfPackageAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_package_association#domain_name TfPackageAssociation#domain_name}
    */
    readonly domainName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_package_association#id TfPackageAssociation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_package_association#package_id TfPackageAssociation#package_id}
    */
    readonly packageId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_package_association#region TfPackageAssociation#region}
    */
    readonly region?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_package_association#timeouts TfPackageAssociation#timeouts}
    */
    readonly timeouts?: TfPackageAssociation.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_package_association aws_opensearch_package_association}
*/
export declare class TfPackageAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_opensearch_package_association";
    /**
    * Generates CDKTN code for importing a TfPackageAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfPackageAssociation to import
    * @param importFromId The id of the existing TfPackageAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_package_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfPackageAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_package_association aws_opensearch_package_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfPackageAssociationConfig
    */
    constructor(scope: Construct, id: string, config: TfPackageAssociationConfig);
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _packageId?;
    get packageId(): string;
    set packageId(value: string);
    get packageIdInput(): string | undefined;
    get referencePath(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _timeouts;
    get timeouts(): TfPackageAssociation.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfPackageAssociation.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfPackageAssociation.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfPackageAssociationTimeoutsPropertyToTerraform(struct?: TfPackageAssociation.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfPackageAssociationTimeoutsPropertyToHclTerraform(struct?: TfPackageAssociation.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfPackageAssociation {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_package_association#create TfPackageAssociation#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_package_association#delete TfPackageAssociation#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
