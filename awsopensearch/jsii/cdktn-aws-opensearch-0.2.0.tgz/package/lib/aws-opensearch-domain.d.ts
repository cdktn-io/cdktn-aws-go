import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfDomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#access_policies TfDomain#access_policies}
    */
    readonly accessPolicies?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#advanced_options TfDomain#advanced_options}
    */
    readonly advancedOptions?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#domain_name TfDomain#domain_name}
    */
    readonly domainName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#engine_version TfDomain#engine_version}
    */
    readonly engineVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#id TfDomain#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#ip_address_type TfDomain#ip_address_type}
    */
    readonly ipAddressType?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#region TfDomain#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#tags TfDomain#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#tags_all TfDomain#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * advanced_security_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#advanced_security_options TfDomain#advanced_security_options}
    */
    readonly advancedSecurityOptions?: TfDomain.AdvancedSecurityOptionsProperty;
    /**
    * aiml_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#aiml_options TfDomain#aiml_options}
    */
    readonly aimlOptions?: TfDomain.AimlOptionsProperty;
    /**
    * auto_tune_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#auto_tune_options TfDomain#auto_tune_options}
    */
    readonly autoTuneOptions?: TfDomain.AutoTuneOptionsProperty;
    /**
    * cluster_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#cluster_config TfDomain#cluster_config}
    */
    readonly clusterConfig?: TfDomain.ClusterConfigProperty;
    /**
    * cognito_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#cognito_options TfDomain#cognito_options}
    */
    readonly cognitoOptions?: TfDomain.CognitoOptionsProperty;
    /**
    * deployment_strategy_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#deployment_strategy_options TfDomain#deployment_strategy_options}
    */
    readonly deploymentStrategyOptions?: TfDomain.DeploymentStrategyOptionsProperty;
    /**
    * domain_endpoint_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#domain_endpoint_options TfDomain#domain_endpoint_options}
    */
    readonly domainEndpointOptions?: TfDomain.DomainEndpointOptionsProperty;
    /**
    * ebs_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#ebs_options TfDomain#ebs_options}
    */
    readonly ebsOptions?: TfDomain.EbsOptionsProperty;
    /**
    * encrypt_at_rest block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#encrypt_at_rest TfDomain#encrypt_at_rest}
    */
    readonly encryptAtRest?: TfDomain.EncryptAtRestProperty;
    /**
    * identity_center_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#identity_center_options TfDomain#identity_center_options}
    */
    readonly identityCenterOptions?: TfDomain.IdentityCenterOptionsProperty;
    /**
    * log_publishing_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#log_publishing_options TfDomain#log_publishing_options}
    */
    readonly logPublishingOptions?: TfDomain.LogPublishingOptionsProperty[] | cdktn.IResolvable;
    /**
    * node_to_node_encryption block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#node_to_node_encryption TfDomain#node_to_node_encryption}
    */
    readonly nodeToNodeEncryption?: TfDomain.NodeToNodeEncryptionProperty;
    /**
    * off_peak_window_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#off_peak_window_options TfDomain#off_peak_window_options}
    */
    readonly offPeakWindowOptions?: TfDomain.OffPeakWindowOptionsProperty;
    /**
    * snapshot_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#snapshot_options TfDomain#snapshot_options}
    */
    readonly snapshotOptions?: TfDomain.SnapshotOptionsProperty;
    /**
    * software_update_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#software_update_options TfDomain#software_update_options}
    */
    readonly softwareUpdateOptions?: TfDomain.SoftwareUpdateOptionsProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#timeouts TfDomain#timeouts}
    */
    readonly timeouts?: TfDomain.TimeoutsProperty;
    /**
    * vpc_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#vpc_options TfDomain#vpc_options}
    */
    readonly vpcOptions?: TfDomain.VpcOptionsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain aws_opensearch_domain}
*/
export declare class TfDomain extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_opensearch_domain";
    /**
    * Generates CDKTN code for importing a TfDomain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfDomain to import
    * @param importFromId The id of the existing TfDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain aws_opensearch_domain} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfDomainConfig
    */
    constructor(scope: Construct, id: string, config: TfDomainConfig);
    private _accessPolicies?;
    get accessPolicies(): string;
    set accessPolicies(value: string);
    resetAccessPolicies(): void;
    get accessPoliciesInput(): string | undefined;
    private _advancedOptions?;
    get advancedOptions(): {
        [key: string]: string;
    };
    set advancedOptions(value: {
        [key: string]: string;
    });
    resetAdvancedOptions(): void;
    get advancedOptionsInput(): {
        [key: string]: string;
    } | undefined;
    get arn(): string;
    get dashboardEndpoint(): string;
    get dashboardEndpointV2(): string;
    get domainEndpointV2HostedZoneId(): string;
    get domainId(): string;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    get endpoint(): string;
    get endpointV2(): string;
    private _engineVersion?;
    get engineVersion(): string;
    set engineVersion(value: string);
    resetEngineVersion(): void;
    get engineVersionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipAddressType?;
    get ipAddressType(): string;
    set ipAddressType(value: string);
    resetIpAddressType(): void;
    get ipAddressTypeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _advancedSecurityOptions;
    get advancedSecurityOptions(): TfDomain.AdvancedSecurityOptionsPropertyOutputReference;
    putAdvancedSecurityOptions(value: TfDomain.AdvancedSecurityOptionsProperty): void;
    resetAdvancedSecurityOptions(): void;
    get advancedSecurityOptionsInput(): TfDomain.AdvancedSecurityOptionsProperty | undefined;
    private _aimlOptions;
    get aimlOptions(): TfDomain.AimlOptionsPropertyOutputReference;
    putAimlOptions(value: TfDomain.AimlOptionsProperty): void;
    resetAimlOptions(): void;
    get aimlOptionsInput(): TfDomain.AimlOptionsProperty | undefined;
    private _autoTuneOptions;
    get autoTuneOptions(): TfDomain.AutoTuneOptionsPropertyOutputReference;
    putAutoTuneOptions(value: TfDomain.AutoTuneOptionsProperty): void;
    resetAutoTuneOptions(): void;
    get autoTuneOptionsInput(): TfDomain.AutoTuneOptionsProperty | undefined;
    private _clusterConfig;
    get clusterConfig(): TfDomain.ClusterConfigPropertyOutputReference;
    putClusterConfig(value: TfDomain.ClusterConfigProperty): void;
    resetClusterConfig(): void;
    get clusterConfigInput(): TfDomain.ClusterConfigProperty | undefined;
    private _cognitoOptions;
    get cognitoOptions(): TfDomain.CognitoOptionsPropertyOutputReference;
    putCognitoOptions(value: TfDomain.CognitoOptionsProperty): void;
    resetCognitoOptions(): void;
    get cognitoOptionsInput(): TfDomain.CognitoOptionsProperty | undefined;
    private _deploymentStrategyOptions;
    get deploymentStrategyOptions(): TfDomain.DeploymentStrategyOptionsPropertyOutputReference;
    putDeploymentStrategyOptions(value: TfDomain.DeploymentStrategyOptionsProperty): void;
    resetDeploymentStrategyOptions(): void;
    get deploymentStrategyOptionsInput(): TfDomain.DeploymentStrategyOptionsProperty | undefined;
    private _domainEndpointOptions;
    get domainEndpointOptions(): TfDomain.DomainEndpointOptionsPropertyOutputReference;
    putDomainEndpointOptions(value: TfDomain.DomainEndpointOptionsProperty): void;
    resetDomainEndpointOptions(): void;
    get domainEndpointOptionsInput(): TfDomain.DomainEndpointOptionsProperty | undefined;
    private _ebsOptions;
    get ebsOptions(): TfDomain.EbsOptionsPropertyOutputReference;
    putEbsOptions(value: TfDomain.EbsOptionsProperty): void;
    resetEbsOptions(): void;
    get ebsOptionsInput(): TfDomain.EbsOptionsProperty | undefined;
    private _encryptAtRest;
    get encryptAtRest(): TfDomain.EncryptAtRestPropertyOutputReference;
    putEncryptAtRest(value: TfDomain.EncryptAtRestProperty): void;
    resetEncryptAtRest(): void;
    get encryptAtRestInput(): TfDomain.EncryptAtRestProperty | undefined;
    private _identityCenterOptions;
    get identityCenterOptions(): TfDomain.IdentityCenterOptionsPropertyOutputReference;
    putIdentityCenterOptions(value: TfDomain.IdentityCenterOptionsProperty): void;
    resetIdentityCenterOptions(): void;
    get identityCenterOptionsInput(): TfDomain.IdentityCenterOptionsProperty | undefined;
    private _logPublishingOptions;
    get logPublishingOptions(): TfDomain.LogPublishingOptionsPropertyList;
    putLogPublishingOptions(value: TfDomain.LogPublishingOptionsProperty[] | cdktn.IResolvable): void;
    resetLogPublishingOptions(): void;
    get logPublishingOptionsInput(): cdktn.IResolvable | TfDomain.LogPublishingOptionsProperty[] | undefined;
    private _nodeToNodeEncryption;
    get nodeToNodeEncryption(): TfDomain.NodeToNodeEncryptionPropertyOutputReference;
    putNodeToNodeEncryption(value: TfDomain.NodeToNodeEncryptionProperty): void;
    resetNodeToNodeEncryption(): void;
    get nodeToNodeEncryptionInput(): TfDomain.NodeToNodeEncryptionProperty | undefined;
    private _offPeakWindowOptions;
    get offPeakWindowOptions(): TfDomain.OffPeakWindowOptionsPropertyOutputReference;
    putOffPeakWindowOptions(value: TfDomain.OffPeakWindowOptionsProperty): void;
    resetOffPeakWindowOptions(): void;
    get offPeakWindowOptionsInput(): TfDomain.OffPeakWindowOptionsProperty | undefined;
    private _snapshotOptions;
    get snapshotOptions(): TfDomain.SnapshotOptionsPropertyOutputReference;
    putSnapshotOptions(value: TfDomain.SnapshotOptionsProperty): void;
    resetSnapshotOptions(): void;
    get snapshotOptionsInput(): TfDomain.SnapshotOptionsProperty | undefined;
    private _softwareUpdateOptions;
    get softwareUpdateOptions(): TfDomain.SoftwareUpdateOptionsPropertyOutputReference;
    putSoftwareUpdateOptions(value: TfDomain.SoftwareUpdateOptionsProperty): void;
    resetSoftwareUpdateOptions(): void;
    get softwareUpdateOptionsInput(): TfDomain.SoftwareUpdateOptionsProperty | undefined;
    private _timeouts;
    get timeouts(): TfDomain.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfDomain.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfDomain.TimeoutsProperty | undefined;
    private _vpcOptions;
    get vpcOptions(): TfDomain.VpcOptionsPropertyOutputReference;
    putVpcOptions(value: TfDomain.VpcOptionsProperty): void;
    resetVpcOptions(): void;
    get vpcOptionsInput(): TfDomain.VpcOptionsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfDomainJwtOptionsPropertyToTerraform(struct?: TfDomain.JwtOptionsPropertyOutputReference | TfDomain.JwtOptionsProperty): any;
export declare function tfDomainJwtOptionsPropertyToHclTerraform(struct?: TfDomain.JwtOptionsPropertyOutputReference | TfDomain.JwtOptionsProperty): any;
export declare function tfDomainMasterUserOptionsPropertyToTerraform(struct?: TfDomain.MasterUserOptionsPropertyOutputReference | TfDomain.MasterUserOptionsProperty): any;
export declare function tfDomainMasterUserOptionsPropertyToHclTerraform(struct?: TfDomain.MasterUserOptionsPropertyOutputReference | TfDomain.MasterUserOptionsProperty): any;
export declare function tfDomainAdvancedSecurityOptionsPropertyToTerraform(struct?: TfDomain.AdvancedSecurityOptionsPropertyOutputReference | TfDomain.AdvancedSecurityOptionsProperty): any;
export declare function tfDomainAdvancedSecurityOptionsPropertyToHclTerraform(struct?: TfDomain.AdvancedSecurityOptionsPropertyOutputReference | TfDomain.AdvancedSecurityOptionsProperty): any;
export declare function tfDomainNaturalLanguageQueryGenerationOptionsPropertyToTerraform(struct?: TfDomain.NaturalLanguageQueryGenerationOptionsPropertyOutputReference | TfDomain.NaturalLanguageQueryGenerationOptionsProperty): any;
export declare function tfDomainNaturalLanguageQueryGenerationOptionsPropertyToHclTerraform(struct?: TfDomain.NaturalLanguageQueryGenerationOptionsPropertyOutputReference | TfDomain.NaturalLanguageQueryGenerationOptionsProperty): any;
export declare function tfDomainS3VectorsEnginePropertyToTerraform(struct?: TfDomain.S3VectorsEnginePropertyOutputReference | TfDomain.S3VectorsEngineProperty): any;
export declare function tfDomainS3VectorsEnginePropertyToHclTerraform(struct?: TfDomain.S3VectorsEnginePropertyOutputReference | TfDomain.S3VectorsEngineProperty): any;
export declare function tfDomainServerlessVectorAccelerationPropertyToTerraform(struct?: TfDomain.ServerlessVectorAccelerationPropertyOutputReference | TfDomain.ServerlessVectorAccelerationProperty): any;
export declare function tfDomainServerlessVectorAccelerationPropertyToHclTerraform(struct?: TfDomain.ServerlessVectorAccelerationPropertyOutputReference | TfDomain.ServerlessVectorAccelerationProperty): any;
export declare function tfDomainAimlOptionsPropertyToTerraform(struct?: TfDomain.AimlOptionsPropertyOutputReference | TfDomain.AimlOptionsProperty): any;
export declare function tfDomainAimlOptionsPropertyToHclTerraform(struct?: TfDomain.AimlOptionsPropertyOutputReference | TfDomain.AimlOptionsProperty): any;
export declare function tfDomainDurationPropertyToTerraform(struct?: TfDomain.DurationPropertyOutputReference | TfDomain.DurationProperty): any;
export declare function tfDomainDurationPropertyToHclTerraform(struct?: TfDomain.DurationPropertyOutputReference | TfDomain.DurationProperty): any;
export declare function tfDomainMaintenanceSchedulePropertyToTerraform(struct?: TfDomain.MaintenanceScheduleProperty | cdktn.IResolvable): any;
export declare function tfDomainMaintenanceSchedulePropertyToHclTerraform(struct?: TfDomain.MaintenanceScheduleProperty | cdktn.IResolvable): any;
export declare function tfDomainAutoTuneOptionsPropertyToTerraform(struct?: TfDomain.AutoTuneOptionsPropertyOutputReference | TfDomain.AutoTuneOptionsProperty): any;
export declare function tfDomainAutoTuneOptionsPropertyToHclTerraform(struct?: TfDomain.AutoTuneOptionsPropertyOutputReference | TfDomain.AutoTuneOptionsProperty): any;
export declare function tfDomainColdStorageOptionsPropertyToTerraform(struct?: TfDomain.ColdStorageOptionsPropertyOutputReference | TfDomain.ColdStorageOptionsProperty): any;
export declare function tfDomainColdStorageOptionsPropertyToHclTerraform(struct?: TfDomain.ColdStorageOptionsPropertyOutputReference | TfDomain.ColdStorageOptionsProperty): any;
export declare function tfDomainNodeConfigPropertyToTerraform(struct?: TfDomain.NodeConfigPropertyOutputReference | TfDomain.NodeConfigProperty): any;
export declare function tfDomainNodeConfigPropertyToHclTerraform(struct?: TfDomain.NodeConfigPropertyOutputReference | TfDomain.NodeConfigProperty): any;
export declare function tfDomainNodeOptionsPropertyToTerraform(struct?: TfDomain.NodeOptionsProperty | cdktn.IResolvable): any;
export declare function tfDomainNodeOptionsPropertyToHclTerraform(struct?: TfDomain.NodeOptionsProperty | cdktn.IResolvable): any;
export declare function tfDomainZoneAwarenessConfigPropertyToTerraform(struct?: TfDomain.ZoneAwarenessConfigPropertyOutputReference | TfDomain.ZoneAwarenessConfigProperty): any;
export declare function tfDomainZoneAwarenessConfigPropertyToHclTerraform(struct?: TfDomain.ZoneAwarenessConfigPropertyOutputReference | TfDomain.ZoneAwarenessConfigProperty): any;
export declare function tfDomainClusterConfigPropertyToTerraform(struct?: TfDomain.ClusterConfigPropertyOutputReference | TfDomain.ClusterConfigProperty): any;
export declare function tfDomainClusterConfigPropertyToHclTerraform(struct?: TfDomain.ClusterConfigPropertyOutputReference | TfDomain.ClusterConfigProperty): any;
export declare function tfDomainCognitoOptionsPropertyToTerraform(struct?: TfDomain.CognitoOptionsPropertyOutputReference | TfDomain.CognitoOptionsProperty): any;
export declare function tfDomainCognitoOptionsPropertyToHclTerraform(struct?: TfDomain.CognitoOptionsPropertyOutputReference | TfDomain.CognitoOptionsProperty): any;
export declare function tfDomainDeploymentStrategyOptionsPropertyToTerraform(struct?: TfDomain.DeploymentStrategyOptionsPropertyOutputReference | TfDomain.DeploymentStrategyOptionsProperty): any;
export declare function tfDomainDeploymentStrategyOptionsPropertyToHclTerraform(struct?: TfDomain.DeploymentStrategyOptionsPropertyOutputReference | TfDomain.DeploymentStrategyOptionsProperty): any;
export declare function tfDomainDomainEndpointOptionsPropertyToTerraform(struct?: TfDomain.DomainEndpointOptionsPropertyOutputReference | TfDomain.DomainEndpointOptionsProperty): any;
export declare function tfDomainDomainEndpointOptionsPropertyToHclTerraform(struct?: TfDomain.DomainEndpointOptionsPropertyOutputReference | TfDomain.DomainEndpointOptionsProperty): any;
export declare function tfDomainEbsOptionsPropertyToTerraform(struct?: TfDomain.EbsOptionsPropertyOutputReference | TfDomain.EbsOptionsProperty): any;
export declare function tfDomainEbsOptionsPropertyToHclTerraform(struct?: TfDomain.EbsOptionsPropertyOutputReference | TfDomain.EbsOptionsProperty): any;
export declare function tfDomainEncryptAtRestPropertyToTerraform(struct?: TfDomain.EncryptAtRestPropertyOutputReference | TfDomain.EncryptAtRestProperty): any;
export declare function tfDomainEncryptAtRestPropertyToHclTerraform(struct?: TfDomain.EncryptAtRestPropertyOutputReference | TfDomain.EncryptAtRestProperty): any;
export declare function tfDomainIdentityCenterOptionsPropertyToTerraform(struct?: TfDomain.IdentityCenterOptionsPropertyOutputReference | TfDomain.IdentityCenterOptionsProperty): any;
export declare function tfDomainIdentityCenterOptionsPropertyToHclTerraform(struct?: TfDomain.IdentityCenterOptionsPropertyOutputReference | TfDomain.IdentityCenterOptionsProperty): any;
export declare function tfDomainLogPublishingOptionsPropertyToTerraform(struct?: TfDomain.LogPublishingOptionsProperty | cdktn.IResolvable): any;
export declare function tfDomainLogPublishingOptionsPropertyToHclTerraform(struct?: TfDomain.LogPublishingOptionsProperty | cdktn.IResolvable): any;
export declare function tfDomainNodeToNodeEncryptionPropertyToTerraform(struct?: TfDomain.NodeToNodeEncryptionPropertyOutputReference | TfDomain.NodeToNodeEncryptionProperty): any;
export declare function tfDomainNodeToNodeEncryptionPropertyToHclTerraform(struct?: TfDomain.NodeToNodeEncryptionPropertyOutputReference | TfDomain.NodeToNodeEncryptionProperty): any;
export declare function tfDomainWindowStartTimePropertyToTerraform(struct?: TfDomain.WindowStartTimePropertyOutputReference | TfDomain.WindowStartTimeProperty): any;
export declare function tfDomainWindowStartTimePropertyToHclTerraform(struct?: TfDomain.WindowStartTimePropertyOutputReference | TfDomain.WindowStartTimeProperty): any;
export declare function tfDomainOffPeakWindowPropertyToTerraform(struct?: TfDomain.OffPeakWindowPropertyOutputReference | TfDomain.OffPeakWindowProperty): any;
export declare function tfDomainOffPeakWindowPropertyToHclTerraform(struct?: TfDomain.OffPeakWindowPropertyOutputReference | TfDomain.OffPeakWindowProperty): any;
export declare function tfDomainOffPeakWindowOptionsPropertyToTerraform(struct?: TfDomain.OffPeakWindowOptionsPropertyOutputReference | TfDomain.OffPeakWindowOptionsProperty): any;
export declare function tfDomainOffPeakWindowOptionsPropertyToHclTerraform(struct?: TfDomain.OffPeakWindowOptionsPropertyOutputReference | TfDomain.OffPeakWindowOptionsProperty): any;
export declare function tfDomainSnapshotOptionsPropertyToTerraform(struct?: TfDomain.SnapshotOptionsPropertyOutputReference | TfDomain.SnapshotOptionsProperty): any;
export declare function tfDomainSnapshotOptionsPropertyToHclTerraform(struct?: TfDomain.SnapshotOptionsPropertyOutputReference | TfDomain.SnapshotOptionsProperty): any;
export declare function tfDomainSoftwareUpdateOptionsPropertyToTerraform(struct?: TfDomain.SoftwareUpdateOptionsPropertyOutputReference | TfDomain.SoftwareUpdateOptionsProperty): any;
export declare function tfDomainSoftwareUpdateOptionsPropertyToHclTerraform(struct?: TfDomain.SoftwareUpdateOptionsPropertyOutputReference | TfDomain.SoftwareUpdateOptionsProperty): any;
export declare function tfDomainTimeoutsPropertyToTerraform(struct?: TfDomain.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfDomainTimeoutsPropertyToHclTerraform(struct?: TfDomain.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfDomainVpcOptionsPropertyToTerraform(struct?: TfDomain.VpcOptionsPropertyOutputReference | TfDomain.VpcOptionsProperty): any;
export declare function tfDomainVpcOptionsPropertyToHclTerraform(struct?: TfDomain.VpcOptionsPropertyOutputReference | TfDomain.VpcOptionsProperty): any;
export declare namespace TfDomain {
    interface JwtOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#enabled TfDomain#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#jwks_url TfDomain#jwks_url}
        */
        readonly jwksUrl?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#public_key TfDomain#public_key}
        */
        readonly publicKey?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#roles_key TfDomain#roles_key}
        */
        readonly rolesKey?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#subject_key TfDomain#subject_key}
        */
        readonly subjectKey?: string;
    }
    class JwtOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): JwtOptionsProperty | undefined;
        set internalValue(value: JwtOptionsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _jwksUrl?;
        get jwksUrl(): string;
        set jwksUrl(value: string);
        resetJwksUrl(): void;
        get jwksUrlInput(): string | undefined;
        private _publicKey?;
        get publicKey(): string;
        set publicKey(value: string);
        resetPublicKey(): void;
        get publicKeyInput(): string | undefined;
        private _rolesKey?;
        get rolesKey(): string;
        set rolesKey(value: string);
        resetRolesKey(): void;
        get rolesKeyInput(): string | undefined;
        private _subjectKey?;
        get subjectKey(): string;
        set subjectKey(value: string);
        resetSubjectKey(): void;
        get subjectKeyInput(): string | undefined;
    }
    interface MasterUserOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#master_user_arn TfDomain#master_user_arn}
        */
        readonly masterUserArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#master_user_name TfDomain#master_user_name}
        */
        readonly masterUserName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#master_user_password TfDomain#master_user_password}
        */
        readonly masterUserPassword?: string;
    }
    class MasterUserOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MasterUserOptionsProperty | undefined;
        set internalValue(value: MasterUserOptionsProperty | undefined);
        private _masterUserArn?;
        get masterUserArn(): string;
        set masterUserArn(value: string);
        resetMasterUserArn(): void;
        get masterUserArnInput(): string | undefined;
        private _masterUserName?;
        get masterUserName(): string;
        set masterUserName(value: string);
        resetMasterUserName(): void;
        get masterUserNameInput(): string | undefined;
        private _masterUserPassword?;
        get masterUserPassword(): string;
        set masterUserPassword(value: string);
        resetMasterUserPassword(): void;
        get masterUserPasswordInput(): string | undefined;
    }
    interface AdvancedSecurityOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#anonymous_auth_enabled TfDomain#anonymous_auth_enabled}
        */
        readonly anonymousAuthEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#enabled TfDomain#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#internal_user_database_enabled TfDomain#internal_user_database_enabled}
        */
        readonly internalUserDatabaseEnabled?: boolean | cdktn.IResolvable;
        /**
        * jwt_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#jwt_options TfDomain#jwt_options}
        */
        readonly jwtOptions?: JwtOptionsProperty;
        /**
        * master_user_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#master_user_options TfDomain#master_user_options}
        */
        readonly masterUserOptions?: MasterUserOptionsProperty;
    }
    class AdvancedSecurityOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AdvancedSecurityOptionsProperty | undefined;
        set internalValue(value: AdvancedSecurityOptionsProperty | undefined);
        private _anonymousAuthEnabled?;
        get anonymousAuthEnabled(): boolean | cdktn.IResolvable;
        set anonymousAuthEnabled(value: boolean | cdktn.IResolvable);
        resetAnonymousAuthEnabled(): void;
        get anonymousAuthEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _internalUserDatabaseEnabled?;
        get internalUserDatabaseEnabled(): boolean | cdktn.IResolvable;
        set internalUserDatabaseEnabled(value: boolean | cdktn.IResolvable);
        resetInternalUserDatabaseEnabled(): void;
        get internalUserDatabaseEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _jwtOptions;
        get jwtOptions(): JwtOptionsPropertyOutputReference;
        putJwtOptions(value: JwtOptionsProperty): void;
        resetJwtOptions(): void;
        get jwtOptionsInput(): JwtOptionsProperty | undefined;
        private _masterUserOptions;
        get masterUserOptions(): MasterUserOptionsPropertyOutputReference;
        putMasterUserOptions(value: MasterUserOptionsProperty): void;
        resetMasterUserOptions(): void;
        get masterUserOptionsInput(): MasterUserOptionsProperty | undefined;
    }
    interface NaturalLanguageQueryGenerationOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#desired_state TfDomain#desired_state}
        */
        readonly desiredState?: string;
    }
    class NaturalLanguageQueryGenerationOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NaturalLanguageQueryGenerationOptionsProperty | undefined;
        set internalValue(value: NaturalLanguageQueryGenerationOptionsProperty | undefined);
        private _desiredState?;
        get desiredState(): string;
        set desiredState(value: string);
        resetDesiredState(): void;
        get desiredStateInput(): string | undefined;
    }
    interface S3VectorsEngineProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#enabled TfDomain#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class S3VectorsEnginePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3VectorsEngineProperty | undefined;
        set internalValue(value: S3VectorsEngineProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface ServerlessVectorAccelerationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#enabled TfDomain#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class ServerlessVectorAccelerationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ServerlessVectorAccelerationProperty | undefined;
        set internalValue(value: ServerlessVectorAccelerationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface AimlOptionsProperty {
        /**
        * natural_language_query_generation_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#natural_language_query_generation_options TfDomain#natural_language_query_generation_options}
        */
        readonly naturalLanguageQueryGenerationOptions?: NaturalLanguageQueryGenerationOptionsProperty;
        /**
        * s3_vectors_engine block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#s3_vectors_engine TfDomain#s3_vectors_engine}
        */
        readonly s3VectorsEngine?: S3VectorsEngineProperty;
        /**
        * serverless_vector_acceleration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#serverless_vector_acceleration TfDomain#serverless_vector_acceleration}
        */
        readonly serverlessVectorAcceleration?: ServerlessVectorAccelerationProperty;
    }
    class AimlOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AimlOptionsProperty | undefined;
        set internalValue(value: AimlOptionsProperty | undefined);
        private _naturalLanguageQueryGenerationOptions;
        get naturalLanguageQueryGenerationOptions(): NaturalLanguageQueryGenerationOptionsPropertyOutputReference;
        putNaturalLanguageQueryGenerationOptions(value: NaturalLanguageQueryGenerationOptionsProperty): void;
        resetNaturalLanguageQueryGenerationOptions(): void;
        get naturalLanguageQueryGenerationOptionsInput(): NaturalLanguageQueryGenerationOptionsProperty | undefined;
        private _s3VectorsEngine;
        get s3VectorsEngine(): S3VectorsEnginePropertyOutputReference;
        putS3VectorsEngine(value: S3VectorsEngineProperty): void;
        resetS3VectorsEngine(): void;
        get s3VectorsEngineInput(): S3VectorsEngineProperty | undefined;
        private _serverlessVectorAcceleration;
        get serverlessVectorAcceleration(): ServerlessVectorAccelerationPropertyOutputReference;
        putServerlessVectorAcceleration(value: ServerlessVectorAccelerationProperty): void;
        resetServerlessVectorAcceleration(): void;
        get serverlessVectorAccelerationInput(): ServerlessVectorAccelerationProperty | undefined;
    }
    interface DurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#unit TfDomain#unit}
        */
        readonly unit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#value TfDomain#value}
        */
        readonly value: number;
    }
    class DurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DurationProperty | undefined;
        set internalValue(value: DurationProperty | undefined);
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface MaintenanceScheduleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#cron_expression_for_recurrence TfDomain#cron_expression_for_recurrence}
        */
        readonly cronExpressionForRecurrence: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#start_at TfDomain#start_at}
        */
        readonly startAt: string;
        /**
        * duration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#duration TfDomain#duration}
        */
        readonly duration: DurationProperty;
    }
    class MaintenanceSchedulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MaintenanceScheduleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: MaintenanceScheduleProperty | cdktn.IResolvable | undefined);
        private _cronExpressionForRecurrence?;
        get cronExpressionForRecurrence(): string;
        set cronExpressionForRecurrence(value: string);
        get cronExpressionForRecurrenceInput(): string | undefined;
        private _startAt?;
        get startAt(): string;
        set startAt(value: string);
        get startAtInput(): string | undefined;
        private _duration;
        get duration(): DurationPropertyOutputReference;
        putDuration(value: DurationProperty): void;
        get durationInput(): DurationProperty | undefined;
    }
    class MaintenanceSchedulePropertyList extends cdktn.ComplexList {
        internalValue?: MaintenanceScheduleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MaintenanceSchedulePropertyOutputReference;
    }
    interface AutoTuneOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#desired_state TfDomain#desired_state}
        */
        readonly desiredState: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#rollback_on_disable TfDomain#rollback_on_disable}
        */
        readonly rollbackOnDisable?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#use_off_peak_window TfDomain#use_off_peak_window}
        */
        readonly useOffPeakWindow?: boolean | cdktn.IResolvable;
        /**
        * maintenance_schedule block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#maintenance_schedule TfDomain#maintenance_schedule}
        */
        readonly maintenanceSchedule?: MaintenanceScheduleProperty[] | cdktn.IResolvable;
    }
    class AutoTuneOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AutoTuneOptionsProperty | undefined;
        set internalValue(value: AutoTuneOptionsProperty | undefined);
        private _desiredState?;
        get desiredState(): string;
        set desiredState(value: string);
        get desiredStateInput(): string | undefined;
        private _rollbackOnDisable?;
        get rollbackOnDisable(): string;
        set rollbackOnDisable(value: string);
        resetRollbackOnDisable(): void;
        get rollbackOnDisableInput(): string | undefined;
        private _useOffPeakWindow?;
        get useOffPeakWindow(): boolean | cdktn.IResolvable;
        set useOffPeakWindow(value: boolean | cdktn.IResolvable);
        resetUseOffPeakWindow(): void;
        get useOffPeakWindowInput(): boolean | cdktn.IResolvable | undefined;
        private _maintenanceSchedule;
        get maintenanceSchedule(): MaintenanceSchedulePropertyList;
        putMaintenanceSchedule(value: MaintenanceScheduleProperty[] | cdktn.IResolvable): void;
        resetMaintenanceSchedule(): void;
        get maintenanceScheduleInput(): cdktn.IResolvable | MaintenanceScheduleProperty[] | undefined;
    }
    interface ColdStorageOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#enabled TfDomain#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class ColdStorageOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ColdStorageOptionsProperty | undefined;
        set internalValue(value: ColdStorageOptionsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface NodeConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#count TfDomain#count}
        */
        readonly count?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#enabled TfDomain#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#type TfDomain#type}
        */
        readonly type?: string;
    }
    class NodeConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NodeConfigProperty | undefined;
        set internalValue(value: NodeConfigProperty | undefined);
        private _count?;
        get count(): number;
        set count(value: number);
        resetCount(): void;
        get countInput(): number | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
    }
    interface NodeOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#node_type TfDomain#node_type}
        */
        readonly nodeType?: string;
        /**
        * node_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#node_config TfDomain#node_config}
        */
        readonly nodeConfig?: NodeConfigProperty;
    }
    class NodeOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NodeOptionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NodeOptionsProperty | cdktn.IResolvable | undefined);
        private _nodeType?;
        get nodeType(): string;
        set nodeType(value: string);
        resetNodeType(): void;
        get nodeTypeInput(): string | undefined;
        private _nodeConfig;
        get nodeConfig(): NodeConfigPropertyOutputReference;
        putNodeConfig(value: NodeConfigProperty): void;
        resetNodeConfig(): void;
        get nodeConfigInput(): NodeConfigProperty | undefined;
    }
    class NodeOptionsPropertyList extends cdktn.ComplexList {
        internalValue?: NodeOptionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NodeOptionsPropertyOutputReference;
    }
    interface ZoneAwarenessConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#availability_zone_count TfDomain#availability_zone_count}
        */
        readonly availabilityZoneCount?: number;
    }
    class ZoneAwarenessConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ZoneAwarenessConfigProperty | undefined;
        set internalValue(value: ZoneAwarenessConfigProperty | undefined);
        private _availabilityZoneCount?;
        get availabilityZoneCount(): number;
        set availabilityZoneCount(value: number);
        resetAvailabilityZoneCount(): void;
        get availabilityZoneCountInput(): number | undefined;
    }
    interface ClusterConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#dedicated_master_count TfDomain#dedicated_master_count}
        */
        readonly dedicatedMasterCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#dedicated_master_enabled TfDomain#dedicated_master_enabled}
        */
        readonly dedicatedMasterEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#dedicated_master_type TfDomain#dedicated_master_type}
        */
        readonly dedicatedMasterType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#instance_count TfDomain#instance_count}
        */
        readonly instanceCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#instance_type TfDomain#instance_type}
        */
        readonly instanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#multi_az_with_standby_enabled TfDomain#multi_az_with_standby_enabled}
        */
        readonly multiAzWithStandbyEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#warm_count TfDomain#warm_count}
        */
        readonly warmCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#warm_enabled TfDomain#warm_enabled}
        */
        readonly warmEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#warm_type TfDomain#warm_type}
        */
        readonly warmType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#zone_awareness_enabled TfDomain#zone_awareness_enabled}
        */
        readonly zoneAwarenessEnabled?: boolean | cdktn.IResolvable;
        /**
        * cold_storage_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#cold_storage_options TfDomain#cold_storage_options}
        */
        readonly coldStorageOptions?: ColdStorageOptionsProperty;
        /**
        * node_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#node_options TfDomain#node_options}
        */
        readonly nodeOptions?: NodeOptionsProperty[] | cdktn.IResolvable;
        /**
        * zone_awareness_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#zone_awareness_config TfDomain#zone_awareness_config}
        */
        readonly zoneAwarenessConfig?: ZoneAwarenessConfigProperty;
    }
    class ClusterConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ClusterConfigProperty | undefined;
        set internalValue(value: ClusterConfigProperty | undefined);
        private _dedicatedMasterCount?;
        get dedicatedMasterCount(): number;
        set dedicatedMasterCount(value: number);
        resetDedicatedMasterCount(): void;
        get dedicatedMasterCountInput(): number | undefined;
        private _dedicatedMasterEnabled?;
        get dedicatedMasterEnabled(): boolean | cdktn.IResolvable;
        set dedicatedMasterEnabled(value: boolean | cdktn.IResolvable);
        resetDedicatedMasterEnabled(): void;
        get dedicatedMasterEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _dedicatedMasterType?;
        get dedicatedMasterType(): string;
        set dedicatedMasterType(value: string);
        resetDedicatedMasterType(): void;
        get dedicatedMasterTypeInput(): string | undefined;
        private _instanceCount?;
        get instanceCount(): number;
        set instanceCount(value: number);
        resetInstanceCount(): void;
        get instanceCountInput(): number | undefined;
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _multiAzWithStandbyEnabled?;
        get multiAzWithStandbyEnabled(): boolean | cdktn.IResolvable;
        set multiAzWithStandbyEnabled(value: boolean | cdktn.IResolvable);
        resetMultiAzWithStandbyEnabled(): void;
        get multiAzWithStandbyEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _warmCount?;
        get warmCount(): number;
        set warmCount(value: number);
        resetWarmCount(): void;
        get warmCountInput(): number | undefined;
        private _warmEnabled?;
        get warmEnabled(): boolean | cdktn.IResolvable;
        set warmEnabled(value: boolean | cdktn.IResolvable);
        resetWarmEnabled(): void;
        get warmEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _warmType?;
        get warmType(): string;
        set warmType(value: string);
        resetWarmType(): void;
        get warmTypeInput(): string | undefined;
        private _zoneAwarenessEnabled?;
        get zoneAwarenessEnabled(): boolean | cdktn.IResolvable;
        set zoneAwarenessEnabled(value: boolean | cdktn.IResolvable);
        resetZoneAwarenessEnabled(): void;
        get zoneAwarenessEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _coldStorageOptions;
        get coldStorageOptions(): ColdStorageOptionsPropertyOutputReference;
        putColdStorageOptions(value: ColdStorageOptionsProperty): void;
        resetColdStorageOptions(): void;
        get coldStorageOptionsInput(): ColdStorageOptionsProperty | undefined;
        private _nodeOptions;
        get nodeOptions(): NodeOptionsPropertyList;
        putNodeOptions(value: NodeOptionsProperty[] | cdktn.IResolvable): void;
        resetNodeOptions(): void;
        get nodeOptionsInput(): cdktn.IResolvable | NodeOptionsProperty[] | undefined;
        private _zoneAwarenessConfig;
        get zoneAwarenessConfig(): ZoneAwarenessConfigPropertyOutputReference;
        putZoneAwarenessConfig(value: ZoneAwarenessConfigProperty): void;
        resetZoneAwarenessConfig(): void;
        get zoneAwarenessConfigInput(): ZoneAwarenessConfigProperty | undefined;
    }
    interface CognitoOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#enabled TfDomain#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#identity_pool_id TfDomain#identity_pool_id}
        */
        readonly identityPoolId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#role_arn TfDomain#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#user_pool_id TfDomain#user_pool_id}
        */
        readonly userPoolId: string;
    }
    class CognitoOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CognitoOptionsProperty | undefined;
        set internalValue(value: CognitoOptionsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _identityPoolId?;
        get identityPoolId(): string;
        set identityPoolId(value: string);
        get identityPoolIdInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _userPoolId?;
        get userPoolId(): string;
        set userPoolId(value: string);
        get userPoolIdInput(): string | undefined;
    }
    interface DeploymentStrategyOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#deployment_strategy TfDomain#deployment_strategy}
        */
        readonly deploymentStrategy: string;
    }
    class DeploymentStrategyOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DeploymentStrategyOptionsProperty | undefined;
        set internalValue(value: DeploymentStrategyOptionsProperty | undefined);
        private _deploymentStrategy?;
        get deploymentStrategy(): string;
        set deploymentStrategy(value: string);
        get deploymentStrategyInput(): string | undefined;
    }
    interface DomainEndpointOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#custom_endpoint TfDomain#custom_endpoint}
        */
        readonly customEndpoint?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#custom_endpoint_certificate_arn TfDomain#custom_endpoint_certificate_arn}
        */
        readonly customEndpointCertificateArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#custom_endpoint_enabled TfDomain#custom_endpoint_enabled}
        */
        readonly customEndpointEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#enforce_https TfDomain#enforce_https}
        */
        readonly enforceHttps?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#tls_security_policy TfDomain#tls_security_policy}
        */
        readonly tlsSecurityPolicy?: string;
    }
    class DomainEndpointOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DomainEndpointOptionsProperty | undefined;
        set internalValue(value: DomainEndpointOptionsProperty | undefined);
        private _customEndpoint?;
        get customEndpoint(): string;
        set customEndpoint(value: string);
        resetCustomEndpoint(): void;
        get customEndpointInput(): string | undefined;
        private _customEndpointCertificateArn?;
        get customEndpointCertificateArn(): string;
        set customEndpointCertificateArn(value: string);
        resetCustomEndpointCertificateArn(): void;
        get customEndpointCertificateArnInput(): string | undefined;
        private _customEndpointEnabled?;
        get customEndpointEnabled(): boolean | cdktn.IResolvable;
        set customEndpointEnabled(value: boolean | cdktn.IResolvable);
        resetCustomEndpointEnabled(): void;
        get customEndpointEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _enforceHttps?;
        get enforceHttps(): boolean | cdktn.IResolvable;
        set enforceHttps(value: boolean | cdktn.IResolvable);
        resetEnforceHttps(): void;
        get enforceHttpsInput(): boolean | cdktn.IResolvable | undefined;
        private _tlsSecurityPolicy?;
        get tlsSecurityPolicy(): string;
        set tlsSecurityPolicy(value: string);
        resetTlsSecurityPolicy(): void;
        get tlsSecurityPolicyInput(): string | undefined;
    }
    interface EbsOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#ebs_enabled TfDomain#ebs_enabled}
        */
        readonly ebsEnabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#iops TfDomain#iops}
        */
        readonly iops?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#throughput TfDomain#throughput}
        */
        readonly throughput?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#volume_size TfDomain#volume_size}
        */
        readonly volumeSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#volume_type TfDomain#volume_type}
        */
        readonly volumeType?: string;
    }
    class EbsOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EbsOptionsProperty | undefined;
        set internalValue(value: EbsOptionsProperty | undefined);
        private _ebsEnabled?;
        get ebsEnabled(): boolean | cdktn.IResolvable;
        set ebsEnabled(value: boolean | cdktn.IResolvable);
        get ebsEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _iops?;
        get iops(): number;
        set iops(value: number);
        resetIops(): void;
        get iopsInput(): number | undefined;
        private _throughput?;
        get throughput(): number;
        set throughput(value: number);
        resetThroughput(): void;
        get throughputInput(): number | undefined;
        private _volumeSize?;
        get volumeSize(): number;
        set volumeSize(value: number);
        resetVolumeSize(): void;
        get volumeSizeInput(): number | undefined;
        private _volumeType?;
        get volumeType(): string;
        set volumeType(value: string);
        resetVolumeType(): void;
        get volumeTypeInput(): string | undefined;
    }
    interface EncryptAtRestProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#enabled TfDomain#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#kms_key_id TfDomain#kms_key_id}
        */
        readonly kmsKeyId?: string;
    }
    class EncryptAtRestPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncryptAtRestProperty | undefined;
        set internalValue(value: EncryptAtRestProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
    }
    interface IdentityCenterOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#enabled_api_access TfDomain#enabled_api_access}
        */
        readonly enabledApiAccess?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#identity_center_instance_arn TfDomain#identity_center_instance_arn}
        */
        readonly identityCenterInstanceArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#roles_key TfDomain#roles_key}
        */
        readonly rolesKey?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#subject_key TfDomain#subject_key}
        */
        readonly subjectKey?: string;
    }
    class IdentityCenterOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IdentityCenterOptionsProperty | undefined;
        set internalValue(value: IdentityCenterOptionsProperty | undefined);
        private _enabledApiAccess?;
        get enabledApiAccess(): boolean | cdktn.IResolvable;
        set enabledApiAccess(value: boolean | cdktn.IResolvable);
        resetEnabledApiAccess(): void;
        get enabledApiAccessInput(): boolean | cdktn.IResolvable | undefined;
        private _identityCenterInstanceArn?;
        get identityCenterInstanceArn(): string;
        set identityCenterInstanceArn(value: string);
        resetIdentityCenterInstanceArn(): void;
        get identityCenterInstanceArnInput(): string | undefined;
        private _rolesKey?;
        get rolesKey(): string;
        set rolesKey(value: string);
        resetRolesKey(): void;
        get rolesKeyInput(): string | undefined;
        private _subjectKey?;
        get subjectKey(): string;
        set subjectKey(value: string);
        resetSubjectKey(): void;
        get subjectKeyInput(): string | undefined;
    }
    interface LogPublishingOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#cloudwatch_log_group_arn TfDomain#cloudwatch_log_group_arn}
        */
        readonly cloudwatchLogGroupArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#enabled TfDomain#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#log_type TfDomain#log_type}
        */
        readonly logType: string;
    }
    class LogPublishingOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LogPublishingOptionsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LogPublishingOptionsProperty | cdktn.IResolvable | undefined);
        private _cloudwatchLogGroupArn?;
        get cloudwatchLogGroupArn(): string;
        set cloudwatchLogGroupArn(value: string);
        get cloudwatchLogGroupArnInput(): string | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _logType?;
        get logType(): string;
        set logType(value: string);
        get logTypeInput(): string | undefined;
    }
    class LogPublishingOptionsPropertyList extends cdktn.ComplexList {
        internalValue?: LogPublishingOptionsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LogPublishingOptionsPropertyOutputReference;
    }
    interface NodeToNodeEncryptionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#enabled TfDomain#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
    }
    class NodeToNodeEncryptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NodeToNodeEncryptionProperty | undefined;
        set internalValue(value: NodeToNodeEncryptionProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface WindowStartTimeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#hours TfDomain#hours}
        */
        readonly hours?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#minutes TfDomain#minutes}
        */
        readonly minutes?: number;
    }
    class WindowStartTimePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): WindowStartTimeProperty | undefined;
        set internalValue(value: WindowStartTimeProperty | undefined);
        private _hours?;
        get hours(): number;
        set hours(value: number);
        resetHours(): void;
        get hoursInput(): number | undefined;
        private _minutes?;
        get minutes(): number;
        set minutes(value: number);
        resetMinutes(): void;
        get minutesInput(): number | undefined;
    }
    interface OffPeakWindowProperty {
        /**
        * window_start_time block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#window_start_time TfDomain#window_start_time}
        */
        readonly windowStartTime?: WindowStartTimeProperty;
    }
    class OffPeakWindowPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OffPeakWindowProperty | undefined;
        set internalValue(value: OffPeakWindowProperty | undefined);
        private _windowStartTime;
        get windowStartTime(): WindowStartTimePropertyOutputReference;
        putWindowStartTime(value: WindowStartTimeProperty): void;
        resetWindowStartTime(): void;
        get windowStartTimeInput(): WindowStartTimeProperty | undefined;
    }
    interface OffPeakWindowOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#enabled TfDomain#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * off_peak_window block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#off_peak_window TfDomain#off_peak_window}
        */
        readonly offPeakWindow?: OffPeakWindowProperty;
    }
    class OffPeakWindowOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OffPeakWindowOptionsProperty | undefined;
        set internalValue(value: OffPeakWindowOptionsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _offPeakWindow;
        get offPeakWindow(): OffPeakWindowPropertyOutputReference;
        putOffPeakWindow(value: OffPeakWindowProperty): void;
        resetOffPeakWindow(): void;
        get offPeakWindowInput(): OffPeakWindowProperty | undefined;
    }
    interface SnapshotOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#automated_snapshot_start_hour TfDomain#automated_snapshot_start_hour}
        */
        readonly automatedSnapshotStartHour: number;
    }
    class SnapshotOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SnapshotOptionsProperty | undefined;
        set internalValue(value: SnapshotOptionsProperty | undefined);
        private _automatedSnapshotStartHour?;
        get automatedSnapshotStartHour(): number;
        set automatedSnapshotStartHour(value: number);
        get automatedSnapshotStartHourInput(): number | undefined;
    }
    interface SoftwareUpdateOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#auto_software_update_enabled TfDomain#auto_software_update_enabled}
        */
        readonly autoSoftwareUpdateEnabled?: boolean | cdktn.IResolvable;
    }
    class SoftwareUpdateOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SoftwareUpdateOptionsProperty | undefined;
        set internalValue(value: SoftwareUpdateOptionsProperty | undefined);
        private _autoSoftwareUpdateEnabled?;
        get autoSoftwareUpdateEnabled(): boolean | cdktn.IResolvable;
        set autoSoftwareUpdateEnabled(value: boolean | cdktn.IResolvable);
        resetAutoSoftwareUpdateEnabled(): void;
        get autoSoftwareUpdateEnabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#create TfDomain#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#delete TfDomain#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#update TfDomain#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface VpcOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#security_group_ids TfDomain#security_group_ids}
        */
        readonly securityGroupIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain#subnet_ids TfDomain#subnet_ids}
        */
        readonly subnetIds?: string[];
    }
    class VpcOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcOptionsProperty | undefined;
        set internalValue(value: VpcOptionsProperty | undefined);
        get availabilityZones(): string[];
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        resetSecurityGroupIds(): void;
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        resetSubnetIds(): void;
        get subnetIdsInput(): string[] | undefined;
        get vpcId(): string;
    }
}
