import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfDomainSamlOptionsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain_saml_options#domain_name TfDomainSamlOptions#domain_name}
    */
    readonly domainName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain_saml_options#id TfDomainSamlOptions#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain_saml_options#region TfDomainSamlOptions#region}
    */
    readonly region?: string;
    /**
    * saml_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain_saml_options#saml_options TfDomainSamlOptions#saml_options}
    */
    readonly samlOptions?: TfDomainSamlOptions.SamlOptionsProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain_saml_options#timeouts TfDomainSamlOptions#timeouts}
    */
    readonly timeouts?: TfDomainSamlOptions.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain_saml_options aws_opensearch_domain_saml_options}
*/
export declare class TfDomainSamlOptions extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_opensearch_domain_saml_options";
    /**
    * Generates CDKTN code for importing a TfDomainSamlOptions resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfDomainSamlOptions to import
    * @param importFromId The id of the existing TfDomainSamlOptions that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain_saml_options#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfDomainSamlOptions to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain_saml_options aws_opensearch_domain_saml_options} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfDomainSamlOptionsConfig
    */
    constructor(scope: Construct, id: string, config: TfDomainSamlOptionsConfig);
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _samlOptions;
    get samlOptions(): TfDomainSamlOptions.SamlOptionsPropertyOutputReference;
    putSamlOptions(value: TfDomainSamlOptions.SamlOptionsProperty): void;
    resetSamlOptions(): void;
    get samlOptionsInput(): TfDomainSamlOptions.SamlOptionsProperty | undefined;
    private _timeouts;
    get timeouts(): TfDomainSamlOptions.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfDomainSamlOptions.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfDomainSamlOptions.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfDomainSamlOptionsIdpPropertyToTerraform(struct?: TfDomainSamlOptions.IdpPropertyOutputReference | TfDomainSamlOptions.IdpProperty): any;
export declare function tfDomainSamlOptionsIdpPropertyToHclTerraform(struct?: TfDomainSamlOptions.IdpPropertyOutputReference | TfDomainSamlOptions.IdpProperty): any;
export declare function tfDomainSamlOptionsSamlOptionsPropertyToTerraform(struct?: TfDomainSamlOptions.SamlOptionsPropertyOutputReference | TfDomainSamlOptions.SamlOptionsProperty): any;
export declare function tfDomainSamlOptionsSamlOptionsPropertyToHclTerraform(struct?: TfDomainSamlOptions.SamlOptionsPropertyOutputReference | TfDomainSamlOptions.SamlOptionsProperty): any;
export declare function tfDomainSamlOptionsTimeoutsPropertyToTerraform(struct?: TfDomainSamlOptions.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfDomainSamlOptionsTimeoutsPropertyToHclTerraform(struct?: TfDomainSamlOptions.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfDomainSamlOptions {
    interface IdpProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain_saml_options#entity_id TfDomainSamlOptions#entity_id}
        */
        readonly entityId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain_saml_options#metadata_content TfDomainSamlOptions#metadata_content}
        */
        readonly metadataContent: string;
    }
    class IdpPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IdpProperty | undefined;
        set internalValue(value: IdpProperty | undefined);
        private _entityId?;
        get entityId(): string;
        set entityId(value: string);
        get entityIdInput(): string | undefined;
        private _metadataContent?;
        get metadataContent(): string;
        set metadataContent(value: string);
        get metadataContentInput(): string | undefined;
    }
    interface SamlOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain_saml_options#enabled TfDomainSamlOptions#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain_saml_options#master_backend_role TfDomainSamlOptions#master_backend_role}
        */
        readonly masterBackendRole?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain_saml_options#master_user_name TfDomainSamlOptions#master_user_name}
        */
        readonly masterUserName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain_saml_options#roles_key TfDomainSamlOptions#roles_key}
        */
        readonly rolesKey?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain_saml_options#session_timeout_minutes TfDomainSamlOptions#session_timeout_minutes}
        */
        readonly sessionTimeoutMinutes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain_saml_options#subject_key TfDomainSamlOptions#subject_key}
        */
        readonly subjectKey?: string;
        /**
        * idp block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain_saml_options#idp TfDomainSamlOptions#idp}
        */
        readonly idp?: IdpProperty;
    }
    class SamlOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SamlOptionsProperty | undefined;
        set internalValue(value: SamlOptionsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _masterBackendRole?;
        get masterBackendRole(): string;
        set masterBackendRole(value: string);
        resetMasterBackendRole(): void;
        get masterBackendRoleInput(): string | undefined;
        private _masterUserName?;
        get masterUserName(): string;
        set masterUserName(value: string);
        resetMasterUserName(): void;
        get masterUserNameInput(): string | undefined;
        private _rolesKey?;
        get rolesKey(): string;
        set rolesKey(value: string);
        resetRolesKey(): void;
        get rolesKeyInput(): string | undefined;
        private _sessionTimeoutMinutes?;
        get sessionTimeoutMinutes(): number;
        set sessionTimeoutMinutes(value: number);
        resetSessionTimeoutMinutes(): void;
        get sessionTimeoutMinutesInput(): number | undefined;
        private _subjectKey?;
        get subjectKey(): string;
        set subjectKey(value: string);
        resetSubjectKey(): void;
        get subjectKeyInput(): string | undefined;
        private _idp;
        get idp(): IdpPropertyOutputReference;
        putIdp(value: IdpProperty): void;
        resetIdp(): void;
        get idpInput(): IdpProperty | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain_saml_options#delete TfDomainSamlOptions#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/opensearch_domain_saml_options#update TfDomainSamlOptions#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
