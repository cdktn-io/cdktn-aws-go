import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsOpensearchDomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/opensearch_domain#domain_name DataAwsOpensearchDomain#domain_name}
    */
    readonly domainName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/opensearch_domain#id DataAwsOpensearchDomain#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/opensearch_domain#region DataAwsOpensearchDomain#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/opensearch_domain#tags DataAwsOpensearchDomain#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/opensearch_domain aws_opensearch_domain}
*/
export declare class DataAwsOpensearchDomain extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_opensearch_domain";
    /**
    * Generates CDKTN code for importing a DataAwsOpensearchDomain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsOpensearchDomain to import
    * @param importFromId The id of the existing DataAwsOpensearchDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/opensearch_domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsOpensearchDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/opensearch_domain aws_opensearch_domain} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsOpensearchDomainConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsOpensearchDomainConfig);
    get accessPolicies(): string;
    private _advancedOptions;
    get advancedOptions(): cdktn.StringMap;
    private _advancedSecurityOptions;
    get advancedSecurityOptions(): DataAwsOpensearchDomain.AdvancedSecurityOptionsPropertyList;
    get arn(): string;
    private _autoTuneOptions;
    get autoTuneOptions(): DataAwsOpensearchDomain.AutoTuneOptionsPropertyList;
    private _clusterConfig;
    get clusterConfig(): DataAwsOpensearchDomain.ClusterConfigPropertyList;
    private _cognitoOptions;
    get cognitoOptions(): DataAwsOpensearchDomain.CognitoOptionsPropertyList;
    get created(): cdktn.IResolvable;
    get dashboardEndpoint(): string;
    get dashboardEndpointV2(): string;
    get deleted(): cdktn.IResolvable;
    private _deploymentStrategyOptions;
    get deploymentStrategyOptions(): DataAwsOpensearchDomain.DeploymentStrategyOptionsPropertyList;
    get domainEndpointV2HostedZoneId(): string;
    get domainId(): string;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    private _ebsOptions;
    get ebsOptions(): DataAwsOpensearchDomain.EbsOptionsPropertyList;
    private _encryptionAtRest;
    get encryptionAtRest(): DataAwsOpensearchDomain.EncryptionAtRestPropertyList;
    get endpoint(): string;
    get endpointV2(): string;
    get engineVersion(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identityCenterOptions;
    get identityCenterOptions(): DataAwsOpensearchDomain.IdentityCenterOptionsPropertyList;
    get ipAddressType(): string;
    private _logPublishingOptions;
    get logPublishingOptions(): DataAwsOpensearchDomain.LogPublishingOptionsPropertyList;
    private _nodeToNodeEncryption;
    get nodeToNodeEncryption(): DataAwsOpensearchDomain.NodeToNodeEncryptionPropertyList;
    private _offPeakWindowOptions;
    get offPeakWindowOptions(): DataAwsOpensearchDomain.OffPeakWindowOptionsPropertyList;
    get processing(): cdktn.IResolvable;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _snapshotOptions;
    get snapshotOptions(): DataAwsOpensearchDomain.SnapshotOptionsPropertyList;
    private _softwareUpdateOptions;
    get softwareUpdateOptions(): DataAwsOpensearchDomain.SoftwareUpdateOptionsPropertyList;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _vpcOptions;
    get vpcOptions(): DataAwsOpensearchDomain.VpcOptionsPropertyList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsOpensearchDomainJwtOptionsPropertyToTerraform(struct?: DataAwsOpensearchDomain.JwtOptionsProperty): any;
export declare function dataAwsOpensearchDomainJwtOptionsPropertyToHclTerraform(struct?: DataAwsOpensearchDomain.JwtOptionsProperty): any;
export declare function dataAwsOpensearchDomainAdvancedSecurityOptionsPropertyToTerraform(struct?: DataAwsOpensearchDomain.AdvancedSecurityOptionsProperty): any;
export declare function dataAwsOpensearchDomainAdvancedSecurityOptionsPropertyToHclTerraform(struct?: DataAwsOpensearchDomain.AdvancedSecurityOptionsProperty): any;
export declare function dataAwsOpensearchDomainDurationPropertyToTerraform(struct?: DataAwsOpensearchDomain.DurationProperty): any;
export declare function dataAwsOpensearchDomainDurationPropertyToHclTerraform(struct?: DataAwsOpensearchDomain.DurationProperty): any;
export declare function dataAwsOpensearchDomainMaintenanceSchedulePropertyToTerraform(struct?: DataAwsOpensearchDomain.MaintenanceScheduleProperty): any;
export declare function dataAwsOpensearchDomainMaintenanceSchedulePropertyToHclTerraform(struct?: DataAwsOpensearchDomain.MaintenanceScheduleProperty): any;
export declare function dataAwsOpensearchDomainAutoTuneOptionsPropertyToTerraform(struct?: DataAwsOpensearchDomain.AutoTuneOptionsProperty): any;
export declare function dataAwsOpensearchDomainAutoTuneOptionsPropertyToHclTerraform(struct?: DataAwsOpensearchDomain.AutoTuneOptionsProperty): any;
export declare function dataAwsOpensearchDomainColdStorageOptionsPropertyToTerraform(struct?: DataAwsOpensearchDomain.ColdStorageOptionsProperty): any;
export declare function dataAwsOpensearchDomainColdStorageOptionsPropertyToHclTerraform(struct?: DataAwsOpensearchDomain.ColdStorageOptionsProperty): any;
export declare function dataAwsOpensearchDomainNodeConfigPropertyToTerraform(struct?: DataAwsOpensearchDomain.NodeConfigProperty): any;
export declare function dataAwsOpensearchDomainNodeConfigPropertyToHclTerraform(struct?: DataAwsOpensearchDomain.NodeConfigProperty): any;
export declare function dataAwsOpensearchDomainNodeOptionsPropertyToTerraform(struct?: DataAwsOpensearchDomain.NodeOptionsProperty): any;
export declare function dataAwsOpensearchDomainNodeOptionsPropertyToHclTerraform(struct?: DataAwsOpensearchDomain.NodeOptionsProperty): any;
export declare function dataAwsOpensearchDomainZoneAwarenessConfigPropertyToTerraform(struct?: DataAwsOpensearchDomain.ZoneAwarenessConfigProperty): any;
export declare function dataAwsOpensearchDomainZoneAwarenessConfigPropertyToHclTerraform(struct?: DataAwsOpensearchDomain.ZoneAwarenessConfigProperty): any;
export declare function dataAwsOpensearchDomainClusterConfigPropertyToTerraform(struct?: DataAwsOpensearchDomain.ClusterConfigProperty): any;
export declare function dataAwsOpensearchDomainClusterConfigPropertyToHclTerraform(struct?: DataAwsOpensearchDomain.ClusterConfigProperty): any;
export declare function dataAwsOpensearchDomainCognitoOptionsPropertyToTerraform(struct?: DataAwsOpensearchDomain.CognitoOptionsProperty): any;
export declare function dataAwsOpensearchDomainCognitoOptionsPropertyToHclTerraform(struct?: DataAwsOpensearchDomain.CognitoOptionsProperty): any;
export declare function dataAwsOpensearchDomainDeploymentStrategyOptionsPropertyToTerraform(struct?: DataAwsOpensearchDomain.DeploymentStrategyOptionsProperty): any;
export declare function dataAwsOpensearchDomainDeploymentStrategyOptionsPropertyToHclTerraform(struct?: DataAwsOpensearchDomain.DeploymentStrategyOptionsProperty): any;
export declare function dataAwsOpensearchDomainEbsOptionsPropertyToTerraform(struct?: DataAwsOpensearchDomain.EbsOptionsProperty): any;
export declare function dataAwsOpensearchDomainEbsOptionsPropertyToHclTerraform(struct?: DataAwsOpensearchDomain.EbsOptionsProperty): any;
export declare function dataAwsOpensearchDomainEncryptionAtRestPropertyToTerraform(struct?: DataAwsOpensearchDomain.EncryptionAtRestProperty): any;
export declare function dataAwsOpensearchDomainEncryptionAtRestPropertyToHclTerraform(struct?: DataAwsOpensearchDomain.EncryptionAtRestProperty): any;
export declare function dataAwsOpensearchDomainIdentityCenterOptionsPropertyToTerraform(struct?: DataAwsOpensearchDomain.IdentityCenterOptionsProperty): any;
export declare function dataAwsOpensearchDomainIdentityCenterOptionsPropertyToHclTerraform(struct?: DataAwsOpensearchDomain.IdentityCenterOptionsProperty): any;
export declare function dataAwsOpensearchDomainLogPublishingOptionsPropertyToTerraform(struct?: DataAwsOpensearchDomain.LogPublishingOptionsProperty): any;
export declare function dataAwsOpensearchDomainLogPublishingOptionsPropertyToHclTerraform(struct?: DataAwsOpensearchDomain.LogPublishingOptionsProperty): any;
export declare function dataAwsOpensearchDomainNodeToNodeEncryptionPropertyToTerraform(struct?: DataAwsOpensearchDomain.NodeToNodeEncryptionProperty): any;
export declare function dataAwsOpensearchDomainNodeToNodeEncryptionPropertyToHclTerraform(struct?: DataAwsOpensearchDomain.NodeToNodeEncryptionProperty): any;
export declare function dataAwsOpensearchDomainWindowStartTimePropertyToTerraform(struct?: DataAwsOpensearchDomain.WindowStartTimeProperty): any;
export declare function dataAwsOpensearchDomainWindowStartTimePropertyToHclTerraform(struct?: DataAwsOpensearchDomain.WindowStartTimeProperty): any;
export declare function dataAwsOpensearchDomainOffPeakWindowPropertyToTerraform(struct?: DataAwsOpensearchDomain.OffPeakWindowProperty): any;
export declare function dataAwsOpensearchDomainOffPeakWindowPropertyToHclTerraform(struct?: DataAwsOpensearchDomain.OffPeakWindowProperty): any;
export declare function dataAwsOpensearchDomainOffPeakWindowOptionsPropertyToTerraform(struct?: DataAwsOpensearchDomain.OffPeakWindowOptionsProperty): any;
export declare function dataAwsOpensearchDomainOffPeakWindowOptionsPropertyToHclTerraform(struct?: DataAwsOpensearchDomain.OffPeakWindowOptionsProperty): any;
export declare function dataAwsOpensearchDomainSnapshotOptionsPropertyToTerraform(struct?: DataAwsOpensearchDomain.SnapshotOptionsProperty): any;
export declare function dataAwsOpensearchDomainSnapshotOptionsPropertyToHclTerraform(struct?: DataAwsOpensearchDomain.SnapshotOptionsProperty): any;
export declare function dataAwsOpensearchDomainSoftwareUpdateOptionsPropertyToTerraform(struct?: DataAwsOpensearchDomain.SoftwareUpdateOptionsProperty): any;
export declare function dataAwsOpensearchDomainSoftwareUpdateOptionsPropertyToHclTerraform(struct?: DataAwsOpensearchDomain.SoftwareUpdateOptionsProperty): any;
export declare function dataAwsOpensearchDomainVpcOptionsPropertyToTerraform(struct?: DataAwsOpensearchDomain.VpcOptionsProperty): any;
export declare function dataAwsOpensearchDomainVpcOptionsPropertyToHclTerraform(struct?: DataAwsOpensearchDomain.VpcOptionsProperty): any;
export declare namespace DataAwsOpensearchDomain {
    interface JwtOptionsProperty {
    }
    class JwtOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): JwtOptionsProperty | undefined;
        set internalValue(value: JwtOptionsProperty | undefined);
        get enabled(): cdktn.IResolvable;
        get jwksUrl(): string;
        get publicKey(): string;
        get rolesKey(): string;
        get subjectKey(): string;
    }
    class JwtOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): JwtOptionsPropertyOutputReference;
    }
    interface AdvancedSecurityOptionsProperty {
    }
    class AdvancedSecurityOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AdvancedSecurityOptionsProperty | undefined;
        set internalValue(value: AdvancedSecurityOptionsProperty | undefined);
        get anonymousAuthEnabled(): cdktn.IResolvable;
        get enabled(): cdktn.IResolvable;
        get internalUserDatabaseEnabled(): cdktn.IResolvable;
        private _jwtOptions;
        get jwtOptions(): JwtOptionsPropertyList;
    }
    class AdvancedSecurityOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AdvancedSecurityOptionsPropertyOutputReference;
    }
    interface DurationProperty {
    }
    class DurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DurationProperty | undefined;
        set internalValue(value: DurationProperty | undefined);
        get unit(): string;
        get value(): number;
    }
    class DurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DurationPropertyOutputReference;
    }
    interface MaintenanceScheduleProperty {
    }
    class MaintenanceSchedulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MaintenanceScheduleProperty | undefined;
        set internalValue(value: MaintenanceScheduleProperty | undefined);
        get cronExpressionForRecurrence(): string;
        private _duration;
        get duration(): DurationPropertyList;
        get startAt(): string;
    }
    class MaintenanceSchedulePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MaintenanceSchedulePropertyOutputReference;
    }
    interface AutoTuneOptionsProperty {
    }
    class AutoTuneOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AutoTuneOptionsProperty | undefined;
        set internalValue(value: AutoTuneOptionsProperty | undefined);
        get desiredState(): string;
        private _maintenanceSchedule;
        get maintenanceSchedule(): MaintenanceSchedulePropertyList;
        get rollbackOnDisable(): string;
        get useOffPeakWindow(): cdktn.IResolvable;
    }
    class AutoTuneOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AutoTuneOptionsPropertyOutputReference;
    }
    interface ColdStorageOptionsProperty {
    }
    class ColdStorageOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ColdStorageOptionsProperty | undefined;
        set internalValue(value: ColdStorageOptionsProperty | undefined);
        get enabled(): cdktn.IResolvable;
    }
    class ColdStorageOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ColdStorageOptionsPropertyOutputReference;
    }
    interface NodeConfigProperty {
    }
    class NodeConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NodeConfigProperty | undefined;
        set internalValue(value: NodeConfigProperty | undefined);
        get count(): number;
        get enabled(): cdktn.IResolvable;
        get type(): string;
    }
    class NodeConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NodeConfigPropertyOutputReference;
    }
    interface NodeOptionsProperty {
    }
    class NodeOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NodeOptionsProperty | undefined;
        set internalValue(value: NodeOptionsProperty | undefined);
        private _nodeConfig;
        get nodeConfig(): NodeConfigPropertyList;
        get nodeType(): string;
    }
    class NodeOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NodeOptionsPropertyOutputReference;
    }
    interface ZoneAwarenessConfigProperty {
    }
    class ZoneAwarenessConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ZoneAwarenessConfigProperty | undefined;
        set internalValue(value: ZoneAwarenessConfigProperty | undefined);
        get availabilityZoneCount(): number;
    }
    class ZoneAwarenessConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ZoneAwarenessConfigPropertyOutputReference;
    }
    interface ClusterConfigProperty {
    }
    class ClusterConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ClusterConfigProperty | undefined;
        set internalValue(value: ClusterConfigProperty | undefined);
        private _coldStorageOptions;
        get coldStorageOptions(): ColdStorageOptionsPropertyList;
        get dedicatedMasterCount(): number;
        get dedicatedMasterEnabled(): cdktn.IResolvable;
        get dedicatedMasterType(): string;
        get instanceCount(): number;
        get instanceType(): string;
        get multiAzWithStandbyEnabled(): cdktn.IResolvable;
        private _nodeOptions;
        get nodeOptions(): NodeOptionsPropertyList;
        get warmCount(): number;
        get warmEnabled(): cdktn.IResolvable;
        get warmType(): string;
        private _zoneAwarenessConfig;
        get zoneAwarenessConfig(): ZoneAwarenessConfigPropertyList;
        get zoneAwarenessEnabled(): cdktn.IResolvable;
    }
    class ClusterConfigPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ClusterConfigPropertyOutputReference;
    }
    interface CognitoOptionsProperty {
    }
    class CognitoOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CognitoOptionsProperty | undefined;
        set internalValue(value: CognitoOptionsProperty | undefined);
        get enabled(): cdktn.IResolvable;
        get identityPoolId(): string;
        get roleArn(): string;
        get userPoolId(): string;
    }
    class CognitoOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CognitoOptionsPropertyOutputReference;
    }
    interface DeploymentStrategyOptionsProperty {
    }
    class DeploymentStrategyOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DeploymentStrategyOptionsProperty | undefined;
        set internalValue(value: DeploymentStrategyOptionsProperty | undefined);
        get deploymentStrategy(): string;
    }
    class DeploymentStrategyOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DeploymentStrategyOptionsPropertyOutputReference;
    }
    interface EbsOptionsProperty {
    }
    class EbsOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EbsOptionsProperty | undefined;
        set internalValue(value: EbsOptionsProperty | undefined);
        get ebsEnabled(): cdktn.IResolvable;
        get iops(): number;
        get throughput(): number;
        get volumeSize(): number;
        get volumeType(): string;
    }
    class EbsOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EbsOptionsPropertyOutputReference;
    }
    interface EncryptionAtRestProperty {
    }
    class EncryptionAtRestPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EncryptionAtRestProperty | undefined;
        set internalValue(value: EncryptionAtRestProperty | undefined);
        get enabled(): cdktn.IResolvable;
        get kmsKeyId(): string;
    }
    class EncryptionAtRestPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EncryptionAtRestPropertyOutputReference;
    }
    interface IdentityCenterOptionsProperty {
    }
    class IdentityCenterOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IdentityCenterOptionsProperty | undefined;
        set internalValue(value: IdentityCenterOptionsProperty | undefined);
        get enabledApiAccess(): cdktn.IResolvable;
        get identityCenterInstanceArn(): string;
        get rolesKey(): string;
        get subjectKey(): string;
    }
    class IdentityCenterOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IdentityCenterOptionsPropertyOutputReference;
    }
    interface LogPublishingOptionsProperty {
    }
    class LogPublishingOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LogPublishingOptionsProperty | undefined;
        set internalValue(value: LogPublishingOptionsProperty | undefined);
        get cloudwatchLogGroupArn(): string;
        get enabled(): cdktn.IResolvable;
        get logType(): string;
    }
    class LogPublishingOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LogPublishingOptionsPropertyOutputReference;
    }
    interface NodeToNodeEncryptionProperty {
    }
    class NodeToNodeEncryptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NodeToNodeEncryptionProperty | undefined;
        set internalValue(value: NodeToNodeEncryptionProperty | undefined);
        get enabled(): cdktn.IResolvable;
    }
    class NodeToNodeEncryptionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NodeToNodeEncryptionPropertyOutputReference;
    }
    interface WindowStartTimeProperty {
    }
    class WindowStartTimePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): WindowStartTimeProperty | undefined;
        set internalValue(value: WindowStartTimeProperty | undefined);
        get hours(): number;
        get minutes(): number;
    }
    class WindowStartTimePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): WindowStartTimePropertyOutputReference;
    }
    interface OffPeakWindowProperty {
    }
    class OffPeakWindowPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OffPeakWindowProperty | undefined;
        set internalValue(value: OffPeakWindowProperty | undefined);
        private _windowStartTime;
        get windowStartTime(): WindowStartTimePropertyList;
    }
    class OffPeakWindowPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OffPeakWindowPropertyOutputReference;
    }
    interface OffPeakWindowOptionsProperty {
    }
    class OffPeakWindowOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OffPeakWindowOptionsProperty | undefined;
        set internalValue(value: OffPeakWindowOptionsProperty | undefined);
        get enabled(): cdktn.IResolvable;
        private _offPeakWindow;
        get offPeakWindow(): OffPeakWindowPropertyList;
    }
    class OffPeakWindowOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OffPeakWindowOptionsPropertyOutputReference;
    }
    interface SnapshotOptionsProperty {
    }
    class SnapshotOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SnapshotOptionsProperty | undefined;
        set internalValue(value: SnapshotOptionsProperty | undefined);
        get automatedSnapshotStartHour(): number;
    }
    class SnapshotOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SnapshotOptionsPropertyOutputReference;
    }
    interface SoftwareUpdateOptionsProperty {
    }
    class SoftwareUpdateOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SoftwareUpdateOptionsProperty | undefined;
        set internalValue(value: SoftwareUpdateOptionsProperty | undefined);
        get autoSoftwareUpdateEnabled(): cdktn.IResolvable;
    }
    class SoftwareUpdateOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SoftwareUpdateOptionsPropertyOutputReference;
    }
    interface VpcOptionsProperty {
    }
    class VpcOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpcOptionsProperty | undefined;
        set internalValue(value: VpcOptionsProperty | undefined);
        get availabilityZones(): string[];
        get securityGroupIds(): string[];
        get subnetIds(): string[];
        get vpcId(): string;
    }
    class VpcOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpcOptionsPropertyOutputReference;
    }
}
