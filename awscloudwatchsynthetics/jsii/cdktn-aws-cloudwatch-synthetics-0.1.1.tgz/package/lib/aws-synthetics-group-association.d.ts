import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSyntheticsGroupAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_group_association#canary_arn AwsSyntheticsGroupAssociation#canary_arn}
    */
    readonly canaryArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_group_association#group_name AwsSyntheticsGroupAssociation#group_name}
    */
    readonly groupName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_group_association#id AwsSyntheticsGroupAssociation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_group_association#region AwsSyntheticsGroupAssociation#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_group_association aws_synthetics_group_association}
*/
export declare class AwsSyntheticsGroupAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_synthetics_group_association";
    /**
    * Generates CDKTN code for importing a AwsSyntheticsGroupAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSyntheticsGroupAssociation to import
    * @param importFromId The id of the existing AwsSyntheticsGroupAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_group_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSyntheticsGroupAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_group_association aws_synthetics_group_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSyntheticsGroupAssociationConfig
    */
    constructor(scope: Construct, id: string, config: AwsSyntheticsGroupAssociationConfig);
    private _canaryArn?;
    get canaryArn(): string;
    set canaryArn(value: string);
    get canaryArnInput(): string | undefined;
    get groupArn(): string;
    get groupId(): string;
    private _groupName?;
    get groupName(): string;
    set groupName(value: string);
    get groupNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
