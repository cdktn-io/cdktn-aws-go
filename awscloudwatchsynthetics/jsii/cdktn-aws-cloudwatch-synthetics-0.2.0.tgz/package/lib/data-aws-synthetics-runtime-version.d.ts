import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfRuntimeVersionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/synthetics_runtime_version#latest DataTfRuntimeVersion#latest}
    */
    readonly latest?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/synthetics_runtime_version#prefix DataTfRuntimeVersion#prefix}
    */
    readonly prefix: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/synthetics_runtime_version#region DataTfRuntimeVersion#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/synthetics_runtime_version#version DataTfRuntimeVersion#version}
    */
    readonly version?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/synthetics_runtime_version aws_synthetics_runtime_version}
*/
export declare class DataTfRuntimeVersion extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_synthetics_runtime_version";
    /**
    * Generates CDKTN code for importing a DataTfRuntimeVersion resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfRuntimeVersion to import
    * @param importFromId The id of the existing DataTfRuntimeVersion that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/synthetics_runtime_version#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfRuntimeVersion to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/synthetics_runtime_version aws_synthetics_runtime_version} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfRuntimeVersionConfig
    */
    constructor(scope: Construct, id: string, config: DataTfRuntimeVersionConfig);
    get deprecationDate(): string;
    get description(): string;
    get id(): string;
    private _latest?;
    get latest(): boolean | cdktn.IResolvable;
    set latest(value: boolean | cdktn.IResolvable);
    resetLatest(): void;
    get latestInput(): boolean | cdktn.IResolvable | undefined;
    private _prefix?;
    get prefix(): string;
    set prefix(value: string);
    get prefixInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get releaseDate(): string;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
    get versionName(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
