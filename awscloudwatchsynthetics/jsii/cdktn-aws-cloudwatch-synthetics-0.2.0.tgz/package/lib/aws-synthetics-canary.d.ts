import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfCanaryConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_canary#artifact_s3_location TfCanary#artifact_s3_location}
    */
    readonly artifactS3Location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_canary#delete_lambda TfCanary#delete_lambda}
    */
    readonly deleteLambda?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_canary#execution_role_arn TfCanary#execution_role_arn}
    */
    readonly executionRoleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_canary#failure_retention_period TfCanary#failure_retention_period}
    */
    readonly failureRetentionPeriod?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_canary#handler TfCanary#handler}
    */
    readonly handler: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_canary#id TfCanary#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_canary#name TfCanary#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_canary#region TfCanary#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_canary#runtime_version TfCanary#runtime_version}
    */
    readonly runtimeVersion: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_canary#s3_bucket TfCanary#s3_bucket}
    */
    readonly s3Bucket?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_canary#s3_key TfCanary#s3_key}
    */
    readonly s3Key?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_canary#s3_version TfCanary#s3_version}
    */
    readonly s3Version?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_canary#start_canary TfCanary#start_canary}
    */
    readonly startCanary?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_canary#success_retention_period TfCanary#success_retention_period}
    */
    readonly successRetentionPeriod?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_canary#tags TfCanary#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_canary#tags_all TfCanary#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_canary#zip_file TfCanary#zip_file}
    */
    readonly zipFile?: string;
    /**
    * artifact_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_canary#artifact_config TfCanary#artifact_config}
    */
    readonly artifactConfig?: TfCanary.ArtifactConfigProperty;
    /**
    * run_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_canary#run_config TfCanary#run_config}
    */
    readonly runConfig?: TfCanary.RunConfigProperty;
    /**
    * schedule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_canary#schedule TfCanary#schedule}
    */
    readonly schedule: TfCanary.ScheduleProperty;
    /**
    * vpc_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_canary#vpc_config TfCanary#vpc_config}
    */
    readonly vpcConfig?: TfCanary.VpcConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_canary aws_synthetics_canary}
*/
export declare class TfCanary extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_synthetics_canary";
    /**
    * Generates CDKTN code for importing a TfCanary resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfCanary to import
    * @param importFromId The id of the existing TfCanary that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_canary#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfCanary to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_canary aws_synthetics_canary} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfCanaryConfig
    */
    constructor(scope: Construct, id: string, config: TfCanaryConfig);
    get arn(): string;
    private _artifactS3Location?;
    get artifactS3Location(): string;
    set artifactS3Location(value: string);
    get artifactS3LocationInput(): string | undefined;
    private _deleteLambda?;
    get deleteLambda(): boolean | cdktn.IResolvable;
    set deleteLambda(value: boolean | cdktn.IResolvable);
    resetDeleteLambda(): void;
    get deleteLambdaInput(): boolean | cdktn.IResolvable | undefined;
    get engineArn(): string;
    private _executionRoleArn?;
    get executionRoleArn(): string;
    set executionRoleArn(value: string);
    get executionRoleArnInput(): string | undefined;
    private _failureRetentionPeriod?;
    get failureRetentionPeriod(): number;
    set failureRetentionPeriod(value: number);
    resetFailureRetentionPeriod(): void;
    get failureRetentionPeriodInput(): number | undefined;
    private _handler?;
    get handler(): string;
    set handler(value: string);
    get handlerInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _runtimeVersion?;
    get runtimeVersion(): string;
    set runtimeVersion(value: string);
    get runtimeVersionInput(): string | undefined;
    private _s3Bucket?;
    get s3Bucket(): string;
    set s3Bucket(value: string);
    resetS3Bucket(): void;
    get s3BucketInput(): string | undefined;
    private _s3Key?;
    get s3Key(): string;
    set s3Key(value: string);
    resetS3Key(): void;
    get s3KeyInput(): string | undefined;
    private _s3Version?;
    get s3Version(): string;
    set s3Version(value: string);
    resetS3Version(): void;
    get s3VersionInput(): string | undefined;
    get sourceLocationArn(): string;
    private _startCanary?;
    get startCanary(): boolean | cdktn.IResolvable;
    set startCanary(value: boolean | cdktn.IResolvable);
    resetStartCanary(): void;
    get startCanaryInput(): boolean | cdktn.IResolvable | undefined;
    get status(): string;
    private _successRetentionPeriod?;
    get successRetentionPeriod(): number;
    set successRetentionPeriod(value: number);
    resetSuccessRetentionPeriod(): void;
    get successRetentionPeriodInput(): number | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _timeline;
    get timeline(): TfCanary.TimelinePropertyList;
    private _zipFile?;
    get zipFile(): string;
    set zipFile(value: string);
    resetZipFile(): void;
    get zipFileInput(): string | undefined;
    private _artifactConfig;
    get artifactConfig(): TfCanary.ArtifactConfigPropertyOutputReference;
    putArtifactConfig(value: TfCanary.ArtifactConfigProperty): void;
    resetArtifactConfig(): void;
    get artifactConfigInput(): TfCanary.ArtifactConfigProperty | undefined;
    private _runConfig;
    get runConfig(): TfCanary.RunConfigPropertyOutputReference;
    putRunConfig(value: TfCanary.RunConfigProperty): void;
    resetRunConfig(): void;
    get runConfigInput(): TfCanary.RunConfigProperty | undefined;
    private _schedule;
    get schedule(): TfCanary.SchedulePropertyOutputReference;
    putSchedule(value: TfCanary.ScheduleProperty): void;
    get scheduleInput(): TfCanary.ScheduleProperty | undefined;
    private _vpcConfig;
    get vpcConfig(): TfCanary.VpcConfigPropertyOutputReference;
    putVpcConfig(value: TfCanary.VpcConfigProperty): void;
    resetVpcConfig(): void;
    get vpcConfigInput(): TfCanary.VpcConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfCanaryTimelinePropertyToTerraform(struct?: TfCanary.TimelineProperty): any;
export declare function tfCanaryTimelinePropertyToHclTerraform(struct?: TfCanary.TimelineProperty): any;
export declare function tfCanaryS3EncryptionPropertyToTerraform(struct?: TfCanary.S3EncryptionPropertyOutputReference | TfCanary.S3EncryptionProperty): any;
export declare function tfCanaryS3EncryptionPropertyToHclTerraform(struct?: TfCanary.S3EncryptionPropertyOutputReference | TfCanary.S3EncryptionProperty): any;
export declare function tfCanaryArtifactConfigPropertyToTerraform(struct?: TfCanary.ArtifactConfigPropertyOutputReference | TfCanary.ArtifactConfigProperty): any;
export declare function tfCanaryArtifactConfigPropertyToHclTerraform(struct?: TfCanary.ArtifactConfigPropertyOutputReference | TfCanary.ArtifactConfigProperty): any;
export declare function tfCanaryRunConfigPropertyToTerraform(struct?: TfCanary.RunConfigPropertyOutputReference | TfCanary.RunConfigProperty): any;
export declare function tfCanaryRunConfigPropertyToHclTerraform(struct?: TfCanary.RunConfigPropertyOutputReference | TfCanary.RunConfigProperty): any;
export declare function tfCanaryRetryConfigPropertyToTerraform(struct?: TfCanary.RetryConfigPropertyOutputReference | TfCanary.RetryConfigProperty): any;
export declare function tfCanaryRetryConfigPropertyToHclTerraform(struct?: TfCanary.RetryConfigPropertyOutputReference | TfCanary.RetryConfigProperty): any;
export declare function tfCanarySchedulePropertyToTerraform(struct?: TfCanary.SchedulePropertyOutputReference | TfCanary.ScheduleProperty): any;
export declare function tfCanarySchedulePropertyToHclTerraform(struct?: TfCanary.SchedulePropertyOutputReference | TfCanary.ScheduleProperty): any;
export declare function tfCanaryVpcConfigPropertyToTerraform(struct?: TfCanary.VpcConfigPropertyOutputReference | TfCanary.VpcConfigProperty): any;
export declare function tfCanaryVpcConfigPropertyToHclTerraform(struct?: TfCanary.VpcConfigPropertyOutputReference | TfCanary.VpcConfigProperty): any;
export declare namespace TfCanary {
    interface TimelineProperty {
    }
    class TimelinePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TimelineProperty | undefined;
        set internalValue(value: TimelineProperty | undefined);
        get created(): string;
        get lastModified(): string;
        get lastStarted(): string;
        get lastStopped(): string;
    }
    class TimelinePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TimelinePropertyOutputReference;
    }
    interface S3EncryptionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_canary#encryption_mode TfCanary#encryption_mode}
        */
        readonly encryptionMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_canary#kms_key_arn TfCanary#kms_key_arn}
        */
        readonly kmsKeyArn?: string;
    }
    class S3EncryptionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3EncryptionProperty | undefined;
        set internalValue(value: S3EncryptionProperty | undefined);
        private _encryptionMode?;
        get encryptionMode(): string;
        set encryptionMode(value: string);
        resetEncryptionMode(): void;
        get encryptionModeInput(): string | undefined;
        private _kmsKeyArn?;
        get kmsKeyArn(): string;
        set kmsKeyArn(value: string);
        resetKmsKeyArn(): void;
        get kmsKeyArnInput(): string | undefined;
    }
    interface ArtifactConfigProperty {
        /**
        * s3_encryption block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_canary#s3_encryption TfCanary#s3_encryption}
        */
        readonly s3Encryption?: S3EncryptionProperty;
    }
    class ArtifactConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ArtifactConfigProperty | undefined;
        set internalValue(value: ArtifactConfigProperty | undefined);
        private _s3Encryption;
        get s3Encryption(): S3EncryptionPropertyOutputReference;
        putS3Encryption(value: S3EncryptionProperty): void;
        resetS3Encryption(): void;
        get s3EncryptionInput(): S3EncryptionProperty | undefined;
    }
    interface RunConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_canary#active_tracing TfCanary#active_tracing}
        */
        readonly activeTracing?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_canary#environment_variables TfCanary#environment_variables}
        */
        readonly environmentVariables?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_canary#ephemeral_storage TfCanary#ephemeral_storage}
        */
        readonly ephemeralStorage?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_canary#memory_in_mb TfCanary#memory_in_mb}
        */
        readonly memoryInMb?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_canary#timeout_in_seconds TfCanary#timeout_in_seconds}
        */
        readonly timeoutInSeconds?: number;
    }
    class RunConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RunConfigProperty | undefined;
        set internalValue(value: RunConfigProperty | undefined);
        private _activeTracing?;
        get activeTracing(): boolean | cdktn.IResolvable;
        set activeTracing(value: boolean | cdktn.IResolvable);
        resetActiveTracing(): void;
        get activeTracingInput(): boolean | cdktn.IResolvable | undefined;
        private _environmentVariables?;
        get environmentVariables(): {
            [key: string]: string;
        };
        set environmentVariables(value: {
            [key: string]: string;
        });
        resetEnvironmentVariables(): void;
        get environmentVariablesInput(): {
            [key: string]: string;
        } | undefined;
        private _ephemeralStorage?;
        get ephemeralStorage(): number;
        set ephemeralStorage(value: number);
        resetEphemeralStorage(): void;
        get ephemeralStorageInput(): number | undefined;
        private _memoryInMb?;
        get memoryInMb(): number;
        set memoryInMb(value: number);
        resetMemoryInMb(): void;
        get memoryInMbInput(): number | undefined;
        private _timeoutInSeconds?;
        get timeoutInSeconds(): number;
        set timeoutInSeconds(value: number);
        resetTimeoutInSeconds(): void;
        get timeoutInSecondsInput(): number | undefined;
    }
    interface RetryConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_canary#max_retries TfCanary#max_retries}
        */
        readonly maxRetries: number;
    }
    class RetryConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RetryConfigProperty | undefined;
        set internalValue(value: RetryConfigProperty | undefined);
        private _maxRetries?;
        get maxRetries(): number;
        set maxRetries(value: number);
        get maxRetriesInput(): number | undefined;
    }
    interface ScheduleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_canary#duration_in_seconds TfCanary#duration_in_seconds}
        */
        readonly durationInSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_canary#expression TfCanary#expression}
        */
        readonly expression: string;
        /**
        * retry_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_canary#retry_config TfCanary#retry_config}
        */
        readonly retryConfig?: RetryConfigProperty;
    }
    class SchedulePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ScheduleProperty | undefined;
        set internalValue(value: ScheduleProperty | undefined);
        private _durationInSeconds?;
        get durationInSeconds(): number;
        set durationInSeconds(value: number);
        resetDurationInSeconds(): void;
        get durationInSecondsInput(): number | undefined;
        private _expression?;
        get expression(): string;
        set expression(value: string);
        get expressionInput(): string | undefined;
        private _retryConfig;
        get retryConfig(): RetryConfigPropertyOutputReference;
        putRetryConfig(value: RetryConfigProperty): void;
        resetRetryConfig(): void;
        get retryConfigInput(): RetryConfigProperty | undefined;
    }
    interface VpcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_canary#ipv6_allowed_for_dual_stack TfCanary#ipv6_allowed_for_dual_stack}
        */
        readonly ipv6AllowedForDualStack?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_canary#security_group_ids TfCanary#security_group_ids}
        */
        readonly securityGroupIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/synthetics_canary#subnet_ids TfCanary#subnet_ids}
        */
        readonly subnetIds?: string[];
    }
    class VpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcConfigProperty | undefined;
        set internalValue(value: VpcConfigProperty | undefined);
        private _ipv6AllowedForDualStack?;
        get ipv6AllowedForDualStack(): boolean | cdktn.IResolvable;
        set ipv6AllowedForDualStack(value: boolean | cdktn.IResolvable);
        resetIpv6AllowedForDualStack(): void;
        get ipv6AllowedForDualStackInput(): boolean | cdktn.IResolvable | undefined;
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        resetSecurityGroupIds(): void;
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        resetSubnetIds(): void;
        get subnetIdsInput(): string[] | undefined;
        get vpcId(): string;
    }
}
