import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsConfigurationSetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#configuration_set_name AwsConfigurationSet#configuration_set_name}
    */
    readonly configurationSetName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#id AwsConfigurationSet#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#region AwsConfigurationSet#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#tags AwsConfigurationSet#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#tags_all AwsConfigurationSet#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * delivery_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#delivery_options AwsConfigurationSet#delivery_options}
    */
    readonly deliveryOptions?: AwsConfigurationSet.DeliveryOptionsProperty;
    /**
    * reputation_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#reputation_options AwsConfigurationSet#reputation_options}
    */
    readonly reputationOptions?: AwsConfigurationSet.ReputationOptionsProperty;
    /**
    * sending_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#sending_options AwsConfigurationSet#sending_options}
    */
    readonly sendingOptions?: AwsConfigurationSet.SendingOptionsProperty;
    /**
    * suppression_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#suppression_options AwsConfigurationSet#suppression_options}
    */
    readonly suppressionOptions?: AwsConfigurationSet.SuppressionOptionsProperty;
    /**
    * tracking_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#tracking_options AwsConfigurationSet#tracking_options}
    */
    readonly trackingOptions?: AwsConfigurationSet.TrackingOptionsProperty;
    /**
    * vdm_options block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#vdm_options AwsConfigurationSet#vdm_options}
    */
    readonly vdmOptions?: AwsConfigurationSet.VdmOptionsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set aws_sesv2_configuration_set}
*/
export declare class AwsConfigurationSet extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sesv2_configuration_set";
    /**
    * Generates CDKTN code for importing a AwsConfigurationSet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsConfigurationSet to import
    * @param importFromId The id of the existing AwsConfigurationSet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsConfigurationSet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set aws_sesv2_configuration_set} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsConfigurationSetConfig
    */
    constructor(scope: Construct, id: string, config: AwsConfigurationSetConfig);
    get arn(): string;
    private _configurationSetName?;
    get configurationSetName(): string;
    set configurationSetName(value: string);
    get configurationSetNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _deliveryOptions;
    get deliveryOptions(): AwsConfigurationSet.DeliveryOptionsPropertyOutputReference;
    putDeliveryOptions(value: AwsConfigurationSet.DeliveryOptionsProperty): void;
    resetDeliveryOptions(): void;
    get deliveryOptionsInput(): AwsConfigurationSet.DeliveryOptionsProperty | undefined;
    private _reputationOptions;
    get reputationOptions(): AwsConfigurationSet.ReputationOptionsPropertyOutputReference;
    putReputationOptions(value: AwsConfigurationSet.ReputationOptionsProperty): void;
    resetReputationOptions(): void;
    get reputationOptionsInput(): AwsConfigurationSet.ReputationOptionsProperty | undefined;
    private _sendingOptions;
    get sendingOptions(): AwsConfigurationSet.SendingOptionsPropertyOutputReference;
    putSendingOptions(value: AwsConfigurationSet.SendingOptionsProperty): void;
    resetSendingOptions(): void;
    get sendingOptionsInput(): AwsConfigurationSet.SendingOptionsProperty | undefined;
    private _suppressionOptions;
    get suppressionOptions(): AwsConfigurationSet.SuppressionOptionsPropertyOutputReference;
    putSuppressionOptions(value: AwsConfigurationSet.SuppressionOptionsProperty): void;
    resetSuppressionOptions(): void;
    get suppressionOptionsInput(): AwsConfigurationSet.SuppressionOptionsProperty | undefined;
    private _trackingOptions;
    get trackingOptions(): AwsConfigurationSet.TrackingOptionsPropertyOutputReference;
    putTrackingOptions(value: AwsConfigurationSet.TrackingOptionsProperty): void;
    resetTrackingOptions(): void;
    get trackingOptionsInput(): AwsConfigurationSet.TrackingOptionsProperty | undefined;
    private _vdmOptions;
    get vdmOptions(): AwsConfigurationSet.VdmOptionsPropertyOutputReference;
    putVdmOptions(value: AwsConfigurationSet.VdmOptionsProperty): void;
    resetVdmOptions(): void;
    get vdmOptionsInput(): AwsConfigurationSet.VdmOptionsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsConfigurationSetDeliveryOptionsPropertyToTerraform(struct?: AwsConfigurationSet.DeliveryOptionsPropertyOutputReference | AwsConfigurationSet.DeliveryOptionsProperty): any;
export declare function awsConfigurationSetDeliveryOptionsPropertyToHclTerraform(struct?: AwsConfigurationSet.DeliveryOptionsPropertyOutputReference | AwsConfigurationSet.DeliveryOptionsProperty): any;
export declare function awsConfigurationSetReputationOptionsPropertyToTerraform(struct?: AwsConfigurationSet.ReputationOptionsPropertyOutputReference | AwsConfigurationSet.ReputationOptionsProperty): any;
export declare function awsConfigurationSetReputationOptionsPropertyToHclTerraform(struct?: AwsConfigurationSet.ReputationOptionsPropertyOutputReference | AwsConfigurationSet.ReputationOptionsProperty): any;
export declare function awsConfigurationSetSendingOptionsPropertyToTerraform(struct?: AwsConfigurationSet.SendingOptionsPropertyOutputReference | AwsConfigurationSet.SendingOptionsProperty): any;
export declare function awsConfigurationSetSendingOptionsPropertyToHclTerraform(struct?: AwsConfigurationSet.SendingOptionsPropertyOutputReference | AwsConfigurationSet.SendingOptionsProperty): any;
export declare function awsConfigurationSetSuppressionOptionsPropertyToTerraform(struct?: AwsConfigurationSet.SuppressionOptionsPropertyOutputReference | AwsConfigurationSet.SuppressionOptionsProperty): any;
export declare function awsConfigurationSetSuppressionOptionsPropertyToHclTerraform(struct?: AwsConfigurationSet.SuppressionOptionsPropertyOutputReference | AwsConfigurationSet.SuppressionOptionsProperty): any;
export declare function awsConfigurationSetTrackingOptionsPropertyToTerraform(struct?: AwsConfigurationSet.TrackingOptionsPropertyOutputReference | AwsConfigurationSet.TrackingOptionsProperty): any;
export declare function awsConfigurationSetTrackingOptionsPropertyToHclTerraform(struct?: AwsConfigurationSet.TrackingOptionsPropertyOutputReference | AwsConfigurationSet.TrackingOptionsProperty): any;
export declare function awsConfigurationSetDashboardOptionsPropertyToTerraform(struct?: AwsConfigurationSet.DashboardOptionsPropertyOutputReference | AwsConfigurationSet.DashboardOptionsProperty): any;
export declare function awsConfigurationSetDashboardOptionsPropertyToHclTerraform(struct?: AwsConfigurationSet.DashboardOptionsPropertyOutputReference | AwsConfigurationSet.DashboardOptionsProperty): any;
export declare function awsConfigurationSetGuardianOptionsPropertyToTerraform(struct?: AwsConfigurationSet.GuardianOptionsPropertyOutputReference | AwsConfigurationSet.GuardianOptionsProperty): any;
export declare function awsConfigurationSetGuardianOptionsPropertyToHclTerraform(struct?: AwsConfigurationSet.GuardianOptionsPropertyOutputReference | AwsConfigurationSet.GuardianOptionsProperty): any;
export declare function awsConfigurationSetVdmOptionsPropertyToTerraform(struct?: AwsConfigurationSet.VdmOptionsPropertyOutputReference | AwsConfigurationSet.VdmOptionsProperty): any;
export declare function awsConfigurationSetVdmOptionsPropertyToHclTerraform(struct?: AwsConfigurationSet.VdmOptionsPropertyOutputReference | AwsConfigurationSet.VdmOptionsProperty): any;
export declare namespace AwsConfigurationSet {
    interface DeliveryOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#max_delivery_seconds AwsConfigurationSet#max_delivery_seconds}
        */
        readonly maxDeliverySeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#sending_pool_name AwsConfigurationSet#sending_pool_name}
        */
        readonly sendingPoolName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#tls_policy AwsConfigurationSet#tls_policy}
        */
        readonly tlsPolicy?: string;
    }
    class DeliveryOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DeliveryOptionsProperty | undefined;
        set internalValue(value: DeliveryOptionsProperty | undefined);
        private _maxDeliverySeconds?;
        get maxDeliverySeconds(): number;
        set maxDeliverySeconds(value: number);
        resetMaxDeliverySeconds(): void;
        get maxDeliverySecondsInput(): number | undefined;
        private _sendingPoolName?;
        get sendingPoolName(): string;
        set sendingPoolName(value: string);
        resetSendingPoolName(): void;
        get sendingPoolNameInput(): string | undefined;
        private _tlsPolicy?;
        get tlsPolicy(): string;
        set tlsPolicy(value: string);
        resetTlsPolicy(): void;
        get tlsPolicyInput(): string | undefined;
    }
    interface ReputationOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#reputation_metrics_enabled AwsConfigurationSet#reputation_metrics_enabled}
        */
        readonly reputationMetricsEnabled?: boolean | cdktn.IResolvable;
    }
    class ReputationOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ReputationOptionsProperty | undefined;
        set internalValue(value: ReputationOptionsProperty | undefined);
        get lastFreshStart(): string;
        private _reputationMetricsEnabled?;
        get reputationMetricsEnabled(): boolean | cdktn.IResolvable;
        set reputationMetricsEnabled(value: boolean | cdktn.IResolvable);
        resetReputationMetricsEnabled(): void;
        get reputationMetricsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface SendingOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#sending_enabled AwsConfigurationSet#sending_enabled}
        */
        readonly sendingEnabled?: boolean | cdktn.IResolvable;
    }
    class SendingOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SendingOptionsProperty | undefined;
        set internalValue(value: SendingOptionsProperty | undefined);
        private _sendingEnabled?;
        get sendingEnabled(): boolean | cdktn.IResolvable;
        set sendingEnabled(value: boolean | cdktn.IResolvable);
        resetSendingEnabled(): void;
        get sendingEnabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface SuppressionOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#suppressed_reasons AwsConfigurationSet#suppressed_reasons}
        */
        readonly suppressedReasons?: string[];
    }
    class SuppressionOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SuppressionOptionsProperty | undefined;
        set internalValue(value: SuppressionOptionsProperty | undefined);
        private _suppressedReasons?;
        get suppressedReasons(): string[];
        set suppressedReasons(value: string[]);
        resetSuppressedReasons(): void;
        get suppressedReasonsInput(): string[] | undefined;
    }
    interface TrackingOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#custom_redirect_domain AwsConfigurationSet#custom_redirect_domain}
        */
        readonly customRedirectDomain: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#https_policy AwsConfigurationSet#https_policy}
        */
        readonly httpsPolicy?: string;
    }
    class TrackingOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TrackingOptionsProperty | undefined;
        set internalValue(value: TrackingOptionsProperty | undefined);
        private _customRedirectDomain?;
        get customRedirectDomain(): string;
        set customRedirectDomain(value: string);
        get customRedirectDomainInput(): string | undefined;
        private _httpsPolicy?;
        get httpsPolicy(): string;
        set httpsPolicy(value: string);
        resetHttpsPolicy(): void;
        get httpsPolicyInput(): string | undefined;
    }
    interface DashboardOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#engagement_metrics AwsConfigurationSet#engagement_metrics}
        */
        readonly engagementMetrics?: string;
    }
    class DashboardOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DashboardOptionsProperty | undefined;
        set internalValue(value: DashboardOptionsProperty | undefined);
        private _engagementMetrics?;
        get engagementMetrics(): string;
        set engagementMetrics(value: string);
        resetEngagementMetrics(): void;
        get engagementMetricsInput(): string | undefined;
    }
    interface GuardianOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#optimized_shared_delivery AwsConfigurationSet#optimized_shared_delivery}
        */
        readonly optimizedSharedDelivery?: string;
    }
    class GuardianOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): GuardianOptionsProperty | undefined;
        set internalValue(value: GuardianOptionsProperty | undefined);
        private _optimizedSharedDelivery?;
        get optimizedSharedDelivery(): string;
        set optimizedSharedDelivery(value: string);
        resetOptimizedSharedDelivery(): void;
        get optimizedSharedDeliveryInput(): string | undefined;
    }
    interface VdmOptionsProperty {
        /**
        * dashboard_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#dashboard_options AwsConfigurationSet#dashboard_options}
        */
        readonly dashboardOptions?: DashboardOptionsProperty;
        /**
        * guardian_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_configuration_set#guardian_options AwsConfigurationSet#guardian_options}
        */
        readonly guardianOptions?: GuardianOptionsProperty;
    }
    class VdmOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VdmOptionsProperty | undefined;
        set internalValue(value: VdmOptionsProperty | undefined);
        private _dashboardOptions;
        get dashboardOptions(): DashboardOptionsPropertyOutputReference;
        putDashboardOptions(value: DashboardOptionsProperty): void;
        resetDashboardOptions(): void;
        get dashboardOptionsInput(): DashboardOptionsProperty | undefined;
        private _guardianOptions;
        get guardianOptions(): GuardianOptionsPropertyOutputReference;
        putGuardianOptions(value: GuardianOptionsProperty): void;
        resetGuardianOptions(): void;
        get guardianOptionsInput(): GuardianOptionsProperty | undefined;
    }
}
