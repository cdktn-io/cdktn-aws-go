import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsContactListConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_contact_list#contact_list_name AwsContactList#contact_list_name}
    */
    readonly contactListName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_contact_list#description AwsContactList#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_contact_list#id AwsContactList#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_contact_list#region AwsContactList#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_contact_list#tags AwsContactList#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_contact_list#tags_all AwsContactList#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * topic block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_contact_list#topic AwsContactList#topic}
    */
    readonly topic?: AwsContactList.TopicProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_contact_list aws_sesv2_contact_list}
*/
export declare class AwsContactList extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sesv2_contact_list";
    /**
    * Generates CDKTN code for importing a AwsContactList resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsContactList to import
    * @param importFromId The id of the existing AwsContactList that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_contact_list#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsContactList to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_contact_list aws_sesv2_contact_list} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsContactListConfig
    */
    constructor(scope: Construct, id: string, config: AwsContactListConfig);
    get arn(): string;
    private _contactListName?;
    get contactListName(): string;
    set contactListName(value: string);
    get contactListNameInput(): string | undefined;
    get createdTimestamp(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastUpdatedTimestamp(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _topic;
    get topic(): AwsContactList.TopicPropertyList;
    putTopic(value: AwsContactList.TopicProperty[] | cdktn.IResolvable): void;
    resetTopic(): void;
    get topicInput(): cdktn.IResolvable | AwsContactList.TopicProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsContactListTopicPropertyToTerraform(struct?: AwsContactList.TopicProperty | cdktn.IResolvable): any;
export declare function awsContactListTopicPropertyToHclTerraform(struct?: AwsContactList.TopicProperty | cdktn.IResolvable): any;
export declare namespace AwsContactList {
    interface TopicProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_contact_list#default_subscription_status AwsContactList#default_subscription_status}
        */
        readonly defaultSubscriptionStatus: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_contact_list#description AwsContactList#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_contact_list#display_name AwsContactList#display_name}
        */
        readonly displayName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_contact_list#topic_name AwsContactList#topic_name}
        */
        readonly topicName: string;
    }
    class TopicPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TopicProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TopicProperty | cdktn.IResolvable | undefined);
        private _defaultSubscriptionStatus?;
        get defaultSubscriptionStatus(): string;
        set defaultSubscriptionStatus(value: string);
        get defaultSubscriptionStatusInput(): string | undefined;
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _displayName?;
        get displayName(): string;
        set displayName(value: string);
        get displayNameInput(): string | undefined;
        private _topicName?;
        get topicName(): string;
        set topicName(value: string);
        get topicNameInput(): string | undefined;
    }
    class TopicPropertyList extends cdktn.ComplexList {
        internalValue?: TopicProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TopicPropertyOutputReference;
    }
}
