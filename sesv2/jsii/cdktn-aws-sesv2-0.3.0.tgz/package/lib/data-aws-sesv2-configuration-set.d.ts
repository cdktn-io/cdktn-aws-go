import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsConfigurationSetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/sesv2_configuration_set#configuration_set_name DataAwsConfigurationSet#configuration_set_name}
    */
    readonly configurationSetName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/sesv2_configuration_set#id DataAwsConfigurationSet#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/sesv2_configuration_set#region DataAwsConfigurationSet#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/sesv2_configuration_set#tags DataAwsConfigurationSet#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/sesv2_configuration_set aws_sesv2_configuration_set}
*/
export declare class DataAwsConfigurationSet extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_sesv2_configuration_set";
    /**
    * Generates CDKTN code for importing a DataAwsConfigurationSet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsConfigurationSet to import
    * @param importFromId The id of the existing DataAwsConfigurationSet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/sesv2_configuration_set#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsConfigurationSet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/sesv2_configuration_set aws_sesv2_configuration_set} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsConfigurationSetConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsConfigurationSetConfig);
    get arn(): string;
    private _configurationSetName?;
    get configurationSetName(): string;
    set configurationSetName(value: string);
    get configurationSetNameInput(): string | undefined;
    private _deliveryOptions;
    get deliveryOptions(): DataAwsConfigurationSet.DeliveryOptionsPropertyList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _reputationOptions;
    get reputationOptions(): DataAwsConfigurationSet.ReputationOptionsPropertyList;
    private _sendingOptions;
    get sendingOptions(): DataAwsConfigurationSet.SendingOptionsPropertyList;
    private _suppressionOptions;
    get suppressionOptions(): DataAwsConfigurationSet.SuppressionOptionsPropertyList;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _trackingOptions;
    get trackingOptions(): DataAwsConfigurationSet.TrackingOptionsPropertyList;
    private _vdmOptions;
    get vdmOptions(): DataAwsConfigurationSet.VdmOptionsPropertyList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsConfigurationSetDeliveryOptionsPropertyToTerraform(struct?: DataAwsConfigurationSet.DeliveryOptionsProperty): any;
export declare function dataAwsConfigurationSetDeliveryOptionsPropertyToHclTerraform(struct?: DataAwsConfigurationSet.DeliveryOptionsProperty): any;
export declare function dataAwsConfigurationSetReputationOptionsPropertyToTerraform(struct?: DataAwsConfigurationSet.ReputationOptionsProperty): any;
export declare function dataAwsConfigurationSetReputationOptionsPropertyToHclTerraform(struct?: DataAwsConfigurationSet.ReputationOptionsProperty): any;
export declare function dataAwsConfigurationSetSendingOptionsPropertyToTerraform(struct?: DataAwsConfigurationSet.SendingOptionsProperty): any;
export declare function dataAwsConfigurationSetSendingOptionsPropertyToHclTerraform(struct?: DataAwsConfigurationSet.SendingOptionsProperty): any;
export declare function dataAwsConfigurationSetSuppressionOptionsPropertyToTerraform(struct?: DataAwsConfigurationSet.SuppressionOptionsProperty): any;
export declare function dataAwsConfigurationSetSuppressionOptionsPropertyToHclTerraform(struct?: DataAwsConfigurationSet.SuppressionOptionsProperty): any;
export declare function dataAwsConfigurationSetTrackingOptionsPropertyToTerraform(struct?: DataAwsConfigurationSet.TrackingOptionsProperty): any;
export declare function dataAwsConfigurationSetTrackingOptionsPropertyToHclTerraform(struct?: DataAwsConfigurationSet.TrackingOptionsProperty): any;
export declare function dataAwsConfigurationSetDashboardOptionsPropertyToTerraform(struct?: DataAwsConfigurationSet.DashboardOptionsProperty): any;
export declare function dataAwsConfigurationSetDashboardOptionsPropertyToHclTerraform(struct?: DataAwsConfigurationSet.DashboardOptionsProperty): any;
export declare function dataAwsConfigurationSetGuardianOptionsPropertyToTerraform(struct?: DataAwsConfigurationSet.GuardianOptionsProperty): any;
export declare function dataAwsConfigurationSetGuardianOptionsPropertyToHclTerraform(struct?: DataAwsConfigurationSet.GuardianOptionsProperty): any;
export declare function dataAwsConfigurationSetVdmOptionsPropertyToTerraform(struct?: DataAwsConfigurationSet.VdmOptionsProperty): any;
export declare function dataAwsConfigurationSetVdmOptionsPropertyToHclTerraform(struct?: DataAwsConfigurationSet.VdmOptionsProperty): any;
export declare namespace DataAwsConfigurationSet {
    interface DeliveryOptionsProperty {
    }
    class DeliveryOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DeliveryOptionsProperty | undefined;
        set internalValue(value: DeliveryOptionsProperty | undefined);
        get maxDeliverySeconds(): number;
        get sendingPoolName(): string;
        get tlsPolicy(): string;
    }
    class DeliveryOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DeliveryOptionsPropertyOutputReference;
    }
    interface ReputationOptionsProperty {
    }
    class ReputationOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ReputationOptionsProperty | undefined;
        set internalValue(value: ReputationOptionsProperty | undefined);
        get lastFreshStart(): string;
        get reputationMetricsEnabled(): cdktn.IResolvable;
    }
    class ReputationOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ReputationOptionsPropertyOutputReference;
    }
    interface SendingOptionsProperty {
    }
    class SendingOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SendingOptionsProperty | undefined;
        set internalValue(value: SendingOptionsProperty | undefined);
        get sendingEnabled(): cdktn.IResolvable;
    }
    class SendingOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SendingOptionsPropertyOutputReference;
    }
    interface SuppressionOptionsProperty {
    }
    class SuppressionOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SuppressionOptionsProperty | undefined;
        set internalValue(value: SuppressionOptionsProperty | undefined);
        get suppressedReasons(): string[];
    }
    class SuppressionOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SuppressionOptionsPropertyOutputReference;
    }
    interface TrackingOptionsProperty {
    }
    class TrackingOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrackingOptionsProperty | undefined;
        set internalValue(value: TrackingOptionsProperty | undefined);
        get customRedirectDomain(): string;
        get httpsPolicy(): string;
    }
    class TrackingOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrackingOptionsPropertyOutputReference;
    }
    interface DashboardOptionsProperty {
    }
    class DashboardOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DashboardOptionsProperty | undefined;
        set internalValue(value: DashboardOptionsProperty | undefined);
        get engagementMetrics(): string;
    }
    class DashboardOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DashboardOptionsPropertyOutputReference;
    }
    interface GuardianOptionsProperty {
    }
    class GuardianOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GuardianOptionsProperty | undefined;
        set internalValue(value: GuardianOptionsProperty | undefined);
        get optimizedSharedDelivery(): string;
    }
    class GuardianOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GuardianOptionsPropertyOutputReference;
    }
    interface VdmOptionsProperty {
    }
    class VdmOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VdmOptionsProperty | undefined;
        set internalValue(value: VdmOptionsProperty | undefined);
        private _dashboardOptions;
        get dashboardOptions(): DashboardOptionsPropertyList;
        private _guardianOptions;
        get guardianOptions(): GuardianOptionsPropertyList;
    }
    class VdmOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VdmOptionsPropertyOutputReference;
    }
}
