import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsTenantResourceAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_tenant_resource_association#region AwsTenantResourceAssociation#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_tenant_resource_association#resource_arn AwsTenantResourceAssociation#resource_arn}
    */
    readonly resourceArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_tenant_resource_association#tenant_name AwsTenantResourceAssociation#tenant_name}
    */
    readonly tenantName: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_tenant_resource_association aws_sesv2_tenant_resource_association}
*/
export declare class AwsTenantResourceAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sesv2_tenant_resource_association";
    /**
    * Generates CDKTN code for importing a AwsTenantResourceAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsTenantResourceAssociation to import
    * @param importFromId The id of the existing AwsTenantResourceAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_tenant_resource_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsTenantResourceAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sesv2_tenant_resource_association aws_sesv2_tenant_resource_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsTenantResourceAssociationConfig
    */
    constructor(scope: Construct, id: string, config: AwsTenantResourceAssociationConfig);
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourceArn?;
    get resourceArn(): string;
    set resourceArn(value: string);
    get resourceArnInput(): string | undefined;
    private _tenantName?;
    get tenantName(): string;
    set tenantName(value: string);
    get tenantNameInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
