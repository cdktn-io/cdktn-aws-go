import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsPrincipalApplicationAssignmentsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssoadmin_principal_application_assignments#instance_arn DataAwsPrincipalApplicationAssignments#instance_arn}
    */
    readonly instanceArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssoadmin_principal_application_assignments#principal_id DataAwsPrincipalApplicationAssignments#principal_id}
    */
    readonly principalId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssoadmin_principal_application_assignments#principal_type DataAwsPrincipalApplicationAssignments#principal_type}
    */
    readonly principalType: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssoadmin_principal_application_assignments#region DataAwsPrincipalApplicationAssignments#region}
    */
    readonly region?: string;
    /**
    * application_assignments block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssoadmin_principal_application_assignments#application_assignments DataAwsPrincipalApplicationAssignments#application_assignments}
    */
    readonly applicationAssignments?: DataAwsPrincipalApplicationAssignments.ApplicationAssignmentsProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssoadmin_principal_application_assignments aws_ssoadmin_principal_application_assignments}
*/
export declare class DataAwsPrincipalApplicationAssignments extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_ssoadmin_principal_application_assignments";
    /**
    * Generates CDKTN code for importing a DataAwsPrincipalApplicationAssignments resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsPrincipalApplicationAssignments to import
    * @param importFromId The id of the existing DataAwsPrincipalApplicationAssignments that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssoadmin_principal_application_assignments#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsPrincipalApplicationAssignments to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssoadmin_principal_application_assignments aws_ssoadmin_principal_application_assignments} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsPrincipalApplicationAssignmentsConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsPrincipalApplicationAssignmentsConfig);
    get id(): string;
    private _instanceArn?;
    get instanceArn(): string;
    set instanceArn(value: string);
    get instanceArnInput(): string | undefined;
    private _principalId?;
    get principalId(): string;
    set principalId(value: string);
    get principalIdInput(): string | undefined;
    private _principalType?;
    get principalType(): string;
    set principalType(value: string);
    get principalTypeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _applicationAssignments;
    get applicationAssignments(): DataAwsPrincipalApplicationAssignments.ApplicationAssignmentsPropertyList;
    putApplicationAssignments(value: DataAwsPrincipalApplicationAssignments.ApplicationAssignmentsProperty[] | cdktn.IResolvable): void;
    resetApplicationAssignments(): void;
    get applicationAssignmentsInput(): cdktn.IResolvable | DataAwsPrincipalApplicationAssignments.ApplicationAssignmentsProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsPrincipalApplicationAssignmentsApplicationAssignmentsPropertyToTerraform(struct?: DataAwsPrincipalApplicationAssignments.ApplicationAssignmentsProperty | cdktn.IResolvable): any;
export declare function dataAwsPrincipalApplicationAssignmentsApplicationAssignmentsPropertyToHclTerraform(struct?: DataAwsPrincipalApplicationAssignments.ApplicationAssignmentsProperty | cdktn.IResolvable): any;
export declare namespace DataAwsPrincipalApplicationAssignments {
    interface ApplicationAssignmentsProperty {
    }
    class ApplicationAssignmentsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ApplicationAssignmentsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ApplicationAssignmentsProperty | cdktn.IResolvable | undefined);
        get applicationArn(): string;
        get principalId(): string;
        get principalType(): string;
    }
    class ApplicationAssignmentsPropertyList extends cdktn.ComplexList {
        internalValue?: ApplicationAssignmentsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ApplicationAssignmentsPropertyOutputReference;
    }
}
