import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsCustomerManagedPolicyAttachmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_customer_managed_policy_attachment#id AwsCustomerManagedPolicyAttachment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_customer_managed_policy_attachment#instance_arn AwsCustomerManagedPolicyAttachment#instance_arn}
    */
    readonly instanceArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_customer_managed_policy_attachment#permission_set_arn AwsCustomerManagedPolicyAttachment#permission_set_arn}
    */
    readonly permissionSetArn: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_customer_managed_policy_attachment#region AwsCustomerManagedPolicyAttachment#region}
    */
    readonly region?: string;
    /**
    * customer_managed_policy_reference block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_customer_managed_policy_attachment#customer_managed_policy_reference AwsCustomerManagedPolicyAttachment#customer_managed_policy_reference}
    */
    readonly customerManagedPolicyReference: AwsCustomerManagedPolicyAttachment.CustomerManagedPolicyReferenceProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_customer_managed_policy_attachment#timeouts AwsCustomerManagedPolicyAttachment#timeouts}
    */
    readonly timeouts?: AwsCustomerManagedPolicyAttachment.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_customer_managed_policy_attachment aws_ssoadmin_customer_managed_policy_attachment}
*/
export declare class AwsCustomerManagedPolicyAttachment extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ssoadmin_customer_managed_policy_attachment";
    /**
    * Generates CDKTN code for importing a AwsCustomerManagedPolicyAttachment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCustomerManagedPolicyAttachment to import
    * @param importFromId The id of the existing AwsCustomerManagedPolicyAttachment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_customer_managed_policy_attachment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCustomerManagedPolicyAttachment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_customer_managed_policy_attachment aws_ssoadmin_customer_managed_policy_attachment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsCustomerManagedPolicyAttachmentConfig
    */
    constructor(scope: Construct, id: string, config: AwsCustomerManagedPolicyAttachmentConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceArn?;
    get instanceArn(): string;
    set instanceArn(value: string);
    get instanceArnInput(): string | undefined;
    private _permissionSetArn?;
    get permissionSetArn(): string;
    set permissionSetArn(value: string);
    get permissionSetArnInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _customerManagedPolicyReference;
    get customerManagedPolicyReference(): AwsCustomerManagedPolicyAttachment.CustomerManagedPolicyReferencePropertyOutputReference;
    putCustomerManagedPolicyReference(value: AwsCustomerManagedPolicyAttachment.CustomerManagedPolicyReferenceProperty): void;
    get customerManagedPolicyReferenceInput(): AwsCustomerManagedPolicyAttachment.CustomerManagedPolicyReferenceProperty | undefined;
    private _timeouts;
    get timeouts(): AwsCustomerManagedPolicyAttachment.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsCustomerManagedPolicyAttachment.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsCustomerManagedPolicyAttachment.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsCustomerManagedPolicyAttachmentCustomerManagedPolicyReferencePropertyToTerraform(struct?: AwsCustomerManagedPolicyAttachment.CustomerManagedPolicyReferencePropertyOutputReference | AwsCustomerManagedPolicyAttachment.CustomerManagedPolicyReferenceProperty): any;
export declare function awsCustomerManagedPolicyAttachmentCustomerManagedPolicyReferencePropertyToHclTerraform(struct?: AwsCustomerManagedPolicyAttachment.CustomerManagedPolicyReferencePropertyOutputReference | AwsCustomerManagedPolicyAttachment.CustomerManagedPolicyReferenceProperty): any;
export declare function awsCustomerManagedPolicyAttachmentTimeoutsPropertyToTerraform(struct?: AwsCustomerManagedPolicyAttachment.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsCustomerManagedPolicyAttachmentTimeoutsPropertyToHclTerraform(struct?: AwsCustomerManagedPolicyAttachment.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsCustomerManagedPolicyAttachment {
    interface CustomerManagedPolicyReferenceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_customer_managed_policy_attachment#name AwsCustomerManagedPolicyAttachment#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_customer_managed_policy_attachment#path AwsCustomerManagedPolicyAttachment#path}
        */
        readonly path?: string;
    }
    class CustomerManagedPolicyReferencePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CustomerManagedPolicyReferenceProperty | undefined;
        set internalValue(value: CustomerManagedPolicyReferenceProperty | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _path?;
        get path(): string;
        set path(value: string);
        resetPath(): void;
        get pathInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_customer_managed_policy_attachment#create AwsCustomerManagedPolicyAttachment#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_customer_managed_policy_attachment#delete AwsCustomerManagedPolicyAttachment#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
