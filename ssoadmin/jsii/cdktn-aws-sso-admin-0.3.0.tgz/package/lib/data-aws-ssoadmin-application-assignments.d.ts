import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsApplicationAssignmentsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssoadmin_application_assignments#application_arn DataAwsApplicationAssignments#application_arn}
    */
    readonly applicationArn: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssoadmin_application_assignments#region DataAwsApplicationAssignments#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssoadmin_application_assignments aws_ssoadmin_application_assignments}
*/
export declare class DataAwsApplicationAssignments extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_ssoadmin_application_assignments";
    /**
    * Generates CDKTN code for importing a DataAwsApplicationAssignments resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsApplicationAssignments to import
    * @param importFromId The id of the existing DataAwsApplicationAssignments that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssoadmin_application_assignments#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsApplicationAssignments to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssoadmin_application_assignments aws_ssoadmin_application_assignments} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsApplicationAssignmentsConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsApplicationAssignmentsConfig);
    private _applicationArn?;
    get applicationArn(): string;
    set applicationArn(value: string);
    get applicationArnInput(): string | undefined;
    private _applicationAssignments;
    get applicationAssignments(): DataAwsApplicationAssignments.ApplicationAssignmentsPropertyList;
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsApplicationAssignmentsApplicationAssignmentsPropertyToTerraform(struct?: DataAwsApplicationAssignments.ApplicationAssignmentsProperty): any;
export declare function dataAwsApplicationAssignmentsApplicationAssignmentsPropertyToHclTerraform(struct?: DataAwsApplicationAssignments.ApplicationAssignmentsProperty): any;
export declare namespace DataAwsApplicationAssignments {
    interface ApplicationAssignmentsProperty {
    }
    class ApplicationAssignmentsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ApplicationAssignmentsProperty | undefined;
        set internalValue(value: ApplicationAssignmentsProperty | undefined);
        get applicationArn(): string;
        get principalId(): string;
        get principalType(): string;
    }
    class ApplicationAssignmentsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ApplicationAssignmentsPropertyOutputReference;
    }
}
