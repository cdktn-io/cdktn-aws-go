import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsApplicationProvidersConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssoadmin_application_providers#region DataAwsApplicationProviders#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssoadmin_application_providers aws_ssoadmin_application_providers}
*/
export declare class DataAwsApplicationProviders extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_ssoadmin_application_providers";
    /**
    * Generates CDKTN code for importing a DataAwsApplicationProviders resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsApplicationProviders to import
    * @param importFromId The id of the existing DataAwsApplicationProviders that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssoadmin_application_providers#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsApplicationProviders to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssoadmin_application_providers aws_ssoadmin_application_providers} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsApplicationProvidersConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsApplicationProvidersConfig);
    private _applicationProviders;
    get applicationProviders(): DataAwsApplicationProviders.ApplicationProvidersPropertyList;
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsApplicationProvidersDisplayDataPropertyToTerraform(struct?: DataAwsApplicationProviders.DisplayDataProperty): any;
export declare function dataAwsApplicationProvidersDisplayDataPropertyToHclTerraform(struct?: DataAwsApplicationProviders.DisplayDataProperty): any;
export declare function dataAwsApplicationProvidersApplicationProvidersPropertyToTerraform(struct?: DataAwsApplicationProviders.ApplicationProvidersProperty): any;
export declare function dataAwsApplicationProvidersApplicationProvidersPropertyToHclTerraform(struct?: DataAwsApplicationProviders.ApplicationProvidersProperty): any;
export declare namespace DataAwsApplicationProviders {
    interface DisplayDataProperty {
    }
    class DisplayDataPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DisplayDataProperty | undefined;
        set internalValue(value: DisplayDataProperty | undefined);
        get description(): string;
        get displayName(): string;
        get iconUrl(): string;
    }
    class DisplayDataPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DisplayDataPropertyOutputReference;
    }
    interface ApplicationProvidersProperty {
    }
    class ApplicationProvidersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ApplicationProvidersProperty | undefined;
        set internalValue(value: ApplicationProvidersProperty | undefined);
        get applicationProviderArn(): string;
        private _displayData;
        get displayData(): DisplayDataPropertyList;
        get federationProtocol(): string;
    }
    class ApplicationProvidersPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ApplicationProvidersPropertyOutputReference;
    }
}
