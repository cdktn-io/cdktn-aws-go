import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsTrustedTokenIssuerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_trusted_token_issuer#client_token AwsTrustedTokenIssuer#client_token}
    */
    readonly clientToken?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_trusted_token_issuer#instance_arn AwsTrustedTokenIssuer#instance_arn}
    */
    readonly instanceArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_trusted_token_issuer#name AwsTrustedTokenIssuer#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_trusted_token_issuer#region AwsTrustedTokenIssuer#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_trusted_token_issuer#tags AwsTrustedTokenIssuer#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_trusted_token_issuer#trusted_token_issuer_type AwsTrustedTokenIssuer#trusted_token_issuer_type}
    */
    readonly trustedTokenIssuerType: string;
    /**
    * trusted_token_issuer_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_trusted_token_issuer#trusted_token_issuer_configuration AwsTrustedTokenIssuer#trusted_token_issuer_configuration}
    */
    readonly trustedTokenIssuerConfiguration?: AwsTrustedTokenIssuer.TrustedTokenIssuerConfigurationProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_trusted_token_issuer aws_ssoadmin_trusted_token_issuer}
*/
export declare class AwsTrustedTokenIssuer extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ssoadmin_trusted_token_issuer";
    /**
    * Generates CDKTN code for importing a AwsTrustedTokenIssuer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsTrustedTokenIssuer to import
    * @param importFromId The id of the existing AwsTrustedTokenIssuer that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_trusted_token_issuer#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsTrustedTokenIssuer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_trusted_token_issuer aws_ssoadmin_trusted_token_issuer} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsTrustedTokenIssuerConfig
    */
    constructor(scope: Construct, id: string, config: AwsTrustedTokenIssuerConfig);
    get arn(): string;
    private _clientToken?;
    get clientToken(): string;
    set clientToken(value: string);
    resetClientToken(): void;
    get clientTokenInput(): string | undefined;
    get id(): string;
    private _instanceArn?;
    get instanceArn(): string;
    set instanceArn(value: string);
    get instanceArnInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _trustedTokenIssuerType?;
    get trustedTokenIssuerType(): string;
    set trustedTokenIssuerType(value: string);
    get trustedTokenIssuerTypeInput(): string | undefined;
    private _trustedTokenIssuerConfiguration;
    get trustedTokenIssuerConfiguration(): AwsTrustedTokenIssuer.TrustedTokenIssuerConfigurationPropertyList;
    putTrustedTokenIssuerConfiguration(value: AwsTrustedTokenIssuer.TrustedTokenIssuerConfigurationProperty[] | cdktn.IResolvable): void;
    resetTrustedTokenIssuerConfiguration(): void;
    get trustedTokenIssuerConfigurationInput(): cdktn.IResolvable | AwsTrustedTokenIssuer.TrustedTokenIssuerConfigurationProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsTrustedTokenIssuerOidcJwtConfigurationPropertyToTerraform(struct?: AwsTrustedTokenIssuer.OidcJwtConfigurationProperty | cdktn.IResolvable): any;
export declare function awsTrustedTokenIssuerOidcJwtConfigurationPropertyToHclTerraform(struct?: AwsTrustedTokenIssuer.OidcJwtConfigurationProperty | cdktn.IResolvable): any;
export declare function awsTrustedTokenIssuerTrustedTokenIssuerConfigurationPropertyToTerraform(struct?: AwsTrustedTokenIssuer.TrustedTokenIssuerConfigurationProperty | cdktn.IResolvable): any;
export declare function awsTrustedTokenIssuerTrustedTokenIssuerConfigurationPropertyToHclTerraform(struct?: AwsTrustedTokenIssuer.TrustedTokenIssuerConfigurationProperty | cdktn.IResolvable): any;
export declare namespace AwsTrustedTokenIssuer {
    interface OidcJwtConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_trusted_token_issuer#claim_attribute_path AwsTrustedTokenIssuer#claim_attribute_path}
        */
        readonly claimAttributePath: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_trusted_token_issuer#identity_store_attribute_path AwsTrustedTokenIssuer#identity_store_attribute_path}
        */
        readonly identityStoreAttributePath: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_trusted_token_issuer#issuer_url AwsTrustedTokenIssuer#issuer_url}
        */
        readonly issuerUrl: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_trusted_token_issuer#jwks_retrieval_option AwsTrustedTokenIssuer#jwks_retrieval_option}
        */
        readonly jwksRetrievalOption: string;
    }
    class OidcJwtConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OidcJwtConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: OidcJwtConfigurationProperty | cdktn.IResolvable | undefined);
        private _claimAttributePath?;
        get claimAttributePath(): string;
        set claimAttributePath(value: string);
        get claimAttributePathInput(): string | undefined;
        private _identityStoreAttributePath?;
        get identityStoreAttributePath(): string;
        set identityStoreAttributePath(value: string);
        get identityStoreAttributePathInput(): string | undefined;
        private _issuerUrl?;
        get issuerUrl(): string;
        set issuerUrl(value: string);
        get issuerUrlInput(): string | undefined;
        private _jwksRetrievalOption?;
        get jwksRetrievalOption(): string;
        set jwksRetrievalOption(value: string);
        get jwksRetrievalOptionInput(): string | undefined;
    }
    class OidcJwtConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: OidcJwtConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OidcJwtConfigurationPropertyOutputReference;
    }
    interface TrustedTokenIssuerConfigurationProperty {
        /**
        * oidc_jwt_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_trusted_token_issuer#oidc_jwt_configuration AwsTrustedTokenIssuer#oidc_jwt_configuration}
        */
        readonly oidcJwtConfiguration?: OidcJwtConfigurationProperty[] | cdktn.IResolvable;
    }
    class TrustedTokenIssuerConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TrustedTokenIssuerConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TrustedTokenIssuerConfigurationProperty | cdktn.IResolvable | undefined);
        private _oidcJwtConfiguration;
        get oidcJwtConfiguration(): OidcJwtConfigurationPropertyList;
        putOidcJwtConfiguration(value: OidcJwtConfigurationProperty[] | cdktn.IResolvable): void;
        resetOidcJwtConfiguration(): void;
        get oidcJwtConfigurationInput(): cdktn.IResolvable | OidcJwtConfigurationProperty[] | undefined;
    }
    class TrustedTokenIssuerConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: TrustedTokenIssuerConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TrustedTokenIssuerConfigurationPropertyOutputReference;
    }
}
