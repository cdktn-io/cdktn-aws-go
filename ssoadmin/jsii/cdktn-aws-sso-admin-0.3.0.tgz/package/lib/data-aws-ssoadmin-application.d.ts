import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsApplicationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssoadmin_application#application_arn DataAwsApplication#application_arn}
    */
    readonly applicationArn: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssoadmin_application#region DataAwsApplication#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssoadmin_application aws_ssoadmin_application}
*/
export declare class DataAwsApplication extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_ssoadmin_application";
    /**
    * Generates CDKTN code for importing a DataAwsApplication resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsApplication to import
    * @param importFromId The id of the existing DataAwsApplication that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssoadmin_application#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsApplication to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssoadmin_application aws_ssoadmin_application} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsApplicationConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsApplicationConfig);
    get applicationAccount(): string;
    private _applicationArn?;
    get applicationArn(): string;
    set applicationArn(value: string);
    get applicationArnInput(): string | undefined;
    get applicationProviderArn(): string;
    get description(): string;
    get id(): string;
    get instanceArn(): string;
    get name(): string;
    private _portalOptions;
    get portalOptions(): DataAwsApplication.PortalOptionsPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsApplicationSignInOptionsPropertyToTerraform(struct?: DataAwsApplication.SignInOptionsProperty): any;
export declare function dataAwsApplicationSignInOptionsPropertyToHclTerraform(struct?: DataAwsApplication.SignInOptionsProperty): any;
export declare function dataAwsApplicationPortalOptionsPropertyToTerraform(struct?: DataAwsApplication.PortalOptionsProperty): any;
export declare function dataAwsApplicationPortalOptionsPropertyToHclTerraform(struct?: DataAwsApplication.PortalOptionsProperty): any;
export declare namespace DataAwsApplication {
    interface SignInOptionsProperty {
    }
    class SignInOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SignInOptionsProperty | undefined;
        set internalValue(value: SignInOptionsProperty | undefined);
        get applicationUrl(): string;
        get origin(): string;
    }
    class SignInOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SignInOptionsPropertyOutputReference;
    }
    interface PortalOptionsProperty {
    }
    class PortalOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PortalOptionsProperty | undefined;
        set internalValue(value: PortalOptionsProperty | undefined);
        private _signInOptions;
        get signInOptions(): SignInOptionsPropertyList;
        get visibility(): string;
    }
    class PortalOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PortalOptionsPropertyOutputReference;
    }
}
