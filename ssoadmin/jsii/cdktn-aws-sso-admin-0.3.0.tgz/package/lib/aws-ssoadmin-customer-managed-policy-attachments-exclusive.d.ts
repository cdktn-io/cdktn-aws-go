import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsCustomerManagedPolicyAttachmentsExclusiveConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_customer_managed_policy_attachments_exclusive#instance_arn AwsCustomerManagedPolicyAttachmentsExclusive#instance_arn}
    */
    readonly instanceArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_customer_managed_policy_attachments_exclusive#permission_set_arn AwsCustomerManagedPolicyAttachmentsExclusive#permission_set_arn}
    */
    readonly permissionSetArn: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_customer_managed_policy_attachments_exclusive#region AwsCustomerManagedPolicyAttachmentsExclusive#region}
    */
    readonly region?: string;
    /**
    * customer_managed_policy_reference block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_customer_managed_policy_attachments_exclusive#customer_managed_policy_reference AwsCustomerManagedPolicyAttachmentsExclusive#customer_managed_policy_reference}
    */
    readonly customerManagedPolicyReference?: AwsCustomerManagedPolicyAttachmentsExclusive.CustomerManagedPolicyReferenceProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_customer_managed_policy_attachments_exclusive#timeouts AwsCustomerManagedPolicyAttachmentsExclusive#timeouts}
    */
    readonly timeouts?: AwsCustomerManagedPolicyAttachmentsExclusive.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_customer_managed_policy_attachments_exclusive aws_ssoadmin_customer_managed_policy_attachments_exclusive}
*/
export declare class AwsCustomerManagedPolicyAttachmentsExclusive extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ssoadmin_customer_managed_policy_attachments_exclusive";
    /**
    * Generates CDKTN code for importing a AwsCustomerManagedPolicyAttachmentsExclusive resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCustomerManagedPolicyAttachmentsExclusive to import
    * @param importFromId The id of the existing AwsCustomerManagedPolicyAttachmentsExclusive that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_customer_managed_policy_attachments_exclusive#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCustomerManagedPolicyAttachmentsExclusive to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_customer_managed_policy_attachments_exclusive aws_ssoadmin_customer_managed_policy_attachments_exclusive} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsCustomerManagedPolicyAttachmentsExclusiveConfig
    */
    constructor(scope: Construct, id: string, config: AwsCustomerManagedPolicyAttachmentsExclusiveConfig);
    private _instanceArn?;
    get instanceArn(): string;
    set instanceArn(value: string);
    get instanceArnInput(): string | undefined;
    private _permissionSetArn?;
    get permissionSetArn(): string;
    set permissionSetArn(value: string);
    get permissionSetArnInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _customerManagedPolicyReference;
    get customerManagedPolicyReference(): AwsCustomerManagedPolicyAttachmentsExclusive.CustomerManagedPolicyReferencePropertyList;
    putCustomerManagedPolicyReference(value: AwsCustomerManagedPolicyAttachmentsExclusive.CustomerManagedPolicyReferenceProperty[] | cdktn.IResolvable): void;
    resetCustomerManagedPolicyReference(): void;
    get customerManagedPolicyReferenceInput(): cdktn.IResolvable | AwsCustomerManagedPolicyAttachmentsExclusive.CustomerManagedPolicyReferenceProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsCustomerManagedPolicyAttachmentsExclusive.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsCustomerManagedPolicyAttachmentsExclusive.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsCustomerManagedPolicyAttachmentsExclusive.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsCustomerManagedPolicyAttachmentsExclusiveCustomerManagedPolicyReferencePropertyToTerraform(struct?: AwsCustomerManagedPolicyAttachmentsExclusive.CustomerManagedPolicyReferenceProperty | cdktn.IResolvable): any;
export declare function awsCustomerManagedPolicyAttachmentsExclusiveCustomerManagedPolicyReferencePropertyToHclTerraform(struct?: AwsCustomerManagedPolicyAttachmentsExclusive.CustomerManagedPolicyReferenceProperty | cdktn.IResolvable): any;
export declare function awsCustomerManagedPolicyAttachmentsExclusiveTimeoutsPropertyToTerraform(struct?: AwsCustomerManagedPolicyAttachmentsExclusive.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsCustomerManagedPolicyAttachmentsExclusiveTimeoutsPropertyToHclTerraform(struct?: AwsCustomerManagedPolicyAttachmentsExclusive.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsCustomerManagedPolicyAttachmentsExclusive {
    interface CustomerManagedPolicyReferenceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_customer_managed_policy_attachments_exclusive#name AwsCustomerManagedPolicyAttachmentsExclusive#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_customer_managed_policy_attachments_exclusive#path AwsCustomerManagedPolicyAttachmentsExclusive#path}
        */
        readonly path?: string;
    }
    class CustomerManagedPolicyReferencePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomerManagedPolicyReferenceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CustomerManagedPolicyReferenceProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _path?;
        get path(): string;
        set path(value: string);
        resetPath(): void;
        get pathInput(): string | undefined;
    }
    class CustomerManagedPolicyReferencePropertyList extends cdktn.ComplexList {
        internalValue?: CustomerManagedPolicyReferenceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomerManagedPolicyReferencePropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_customer_managed_policy_attachments_exclusive#create AwsCustomerManagedPolicyAttachmentsExclusive#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_customer_managed_policy_attachments_exclusive#update AwsCustomerManagedPolicyAttachmentsExclusive#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
