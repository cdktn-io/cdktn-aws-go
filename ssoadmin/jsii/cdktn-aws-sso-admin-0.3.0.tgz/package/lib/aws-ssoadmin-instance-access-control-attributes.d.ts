import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsInstanceAccessControlAttributesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_instance_access_control_attributes#id AwsInstanceAccessControlAttributes#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_instance_access_control_attributes#instance_arn AwsInstanceAccessControlAttributes#instance_arn}
    */
    readonly instanceArn: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_instance_access_control_attributes#region AwsInstanceAccessControlAttributes#region}
    */
    readonly region?: string;
    /**
    * attribute block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_instance_access_control_attributes#attribute AwsInstanceAccessControlAttributes#attribute}
    */
    readonly attribute: AwsInstanceAccessControlAttributes.AttributeProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_instance_access_control_attributes aws_ssoadmin_instance_access_control_attributes}
*/
export declare class AwsInstanceAccessControlAttributes extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ssoadmin_instance_access_control_attributes";
    /**
    * Generates CDKTN code for importing a AwsInstanceAccessControlAttributes resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsInstanceAccessControlAttributes to import
    * @param importFromId The id of the existing AwsInstanceAccessControlAttributes that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_instance_access_control_attributes#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsInstanceAccessControlAttributes to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_instance_access_control_attributes aws_ssoadmin_instance_access_control_attributes} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsInstanceAccessControlAttributesConfig
    */
    constructor(scope: Construct, id: string, config: AwsInstanceAccessControlAttributesConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceArn?;
    get instanceArn(): string;
    set instanceArn(value: string);
    get instanceArnInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    get statusReason(): string;
    private _attribute;
    get attribute(): AwsInstanceAccessControlAttributes.AttributePropertyList;
    putAttribute(value: AwsInstanceAccessControlAttributes.AttributeProperty[] | cdktn.IResolvable): void;
    get attributeInput(): cdktn.IResolvable | AwsInstanceAccessControlAttributes.AttributeProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsInstanceAccessControlAttributesValuePropertyToTerraform(struct?: AwsInstanceAccessControlAttributes.ValueProperty | cdktn.IResolvable): any;
export declare function awsInstanceAccessControlAttributesValuePropertyToHclTerraform(struct?: AwsInstanceAccessControlAttributes.ValueProperty | cdktn.IResolvable): any;
export declare function awsInstanceAccessControlAttributesAttributePropertyToTerraform(struct?: AwsInstanceAccessControlAttributes.AttributeProperty | cdktn.IResolvable): any;
export declare function awsInstanceAccessControlAttributesAttributePropertyToHclTerraform(struct?: AwsInstanceAccessControlAttributes.AttributeProperty | cdktn.IResolvable): any;
export declare namespace AwsInstanceAccessControlAttributes {
    interface ValueProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_instance_access_control_attributes#source AwsInstanceAccessControlAttributes#source}
        */
        readonly source: string[];
    }
    class ValuePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ValueProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ValueProperty | cdktn.IResolvable | undefined);
        private _source?;
        get source(): string[];
        set source(value: string[]);
        get sourceInput(): string[] | undefined;
    }
    class ValuePropertyList extends cdktn.ComplexList {
        internalValue?: ValueProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ValuePropertyOutputReference;
    }
    interface AttributeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_instance_access_control_attributes#key AwsInstanceAccessControlAttributes#key}
        */
        readonly key: string;
        /**
        * value block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ssoadmin_instance_access_control_attributes#value AwsInstanceAccessControlAttributes#value}
        */
        readonly value: ValueProperty[] | cdktn.IResolvable;
    }
    class AttributePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AttributeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AttributeProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _value;
        get value(): ValuePropertyList;
        putValue(value: ValueProperty[] | cdktn.IResolvable): void;
        get valueInput(): cdktn.IResolvable | ValueProperty[] | undefined;
    }
    class AttributePropertyList extends cdktn.ComplexList {
        internalValue?: AttributeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AttributePropertyOutputReference;
    }
}
