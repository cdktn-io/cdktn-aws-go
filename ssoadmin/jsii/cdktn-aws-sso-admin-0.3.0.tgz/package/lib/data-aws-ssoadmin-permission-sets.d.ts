import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsPermissionSetsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssoadmin_permission_sets#instance_arn DataAwsPermissionSets#instance_arn}
    */
    readonly instanceArn: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssoadmin_permission_sets#region DataAwsPermissionSets#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssoadmin_permission_sets aws_ssoadmin_permission_sets}
*/
export declare class DataAwsPermissionSets extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_ssoadmin_permission_sets";
    /**
    * Generates CDKTN code for importing a DataAwsPermissionSets resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsPermissionSets to import
    * @param importFromId The id of the existing DataAwsPermissionSets that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssoadmin_permission_sets#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsPermissionSets to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/ssoadmin_permission_sets aws_ssoadmin_permission_sets} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsPermissionSetsConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsPermissionSetsConfig);
    get arns(): string[];
    get id(): string;
    private _instanceArn?;
    get instanceArn(): string;
    set instanceArn(value: string);
    get instanceArnInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
