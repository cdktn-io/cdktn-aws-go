import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsBudgetsBudgetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/budgets_budget#account_id DataAwsBudgetsBudget#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/budgets_budget#id DataAwsBudgetsBudget#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/budgets_budget#name DataAwsBudgetsBudget#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/budgets_budget#name_prefix DataAwsBudgetsBudget#name_prefix}
    */
    readonly namePrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/budgets_budget#tags DataAwsBudgetsBudget#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/budgets_budget aws_budgets_budget}
*/
export declare class DataAwsBudgetsBudget extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_budgets_budget";
    /**
    * Generates CDKTN code for importing a DataAwsBudgetsBudget resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsBudgetsBudget to import
    * @param importFromId The id of the existing DataAwsBudgetsBudget that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/budgets_budget#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsBudgetsBudget to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/budgets_budget aws_budgets_budget} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsBudgetsBudgetConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsBudgetsBudgetConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get arn(): string;
    private _autoAdjustData;
    get autoAdjustData(): DataAwsBudgetsBudget.AutoAdjustDataPropertyList;
    get billingViewArn(): string;
    get budgetExceeded(): cdktn.IResolvable;
    private _budgetLimit;
    get budgetLimit(): DataAwsBudgetsBudget.BudgetLimitPropertyList;
    get budgetType(): string;
    private _calculatedSpend;
    get calculatedSpend(): DataAwsBudgetsBudget.CalculatedSpendPropertyList;
    private _costFilter;
    get costFilter(): DataAwsBudgetsBudget.CostFilterPropertyList;
    private _costTypes;
    get costTypes(): DataAwsBudgetsBudget.CostTypesPropertyList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _namePrefix?;
    get namePrefix(): string;
    set namePrefix(value: string);
    resetNamePrefix(): void;
    get namePrefixInput(): string | undefined;
    private _notification;
    get notification(): DataAwsBudgetsBudget.NotificationPropertyList;
    private _plannedLimit;
    get plannedLimit(): DataAwsBudgetsBudget.PlannedLimitPropertyList;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get timePeriodEnd(): string;
    get timePeriodStart(): string;
    get timeUnit(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsBudgetsBudgetHistoricalOptionsPropertyToTerraform(struct?: DataAwsBudgetsBudget.HistoricalOptionsProperty): any;
export declare function dataAwsBudgetsBudgetHistoricalOptionsPropertyToHclTerraform(struct?: DataAwsBudgetsBudget.HistoricalOptionsProperty): any;
export declare function dataAwsBudgetsBudgetAutoAdjustDataPropertyToTerraform(struct?: DataAwsBudgetsBudget.AutoAdjustDataProperty): any;
export declare function dataAwsBudgetsBudgetAutoAdjustDataPropertyToHclTerraform(struct?: DataAwsBudgetsBudget.AutoAdjustDataProperty): any;
export declare function dataAwsBudgetsBudgetBudgetLimitPropertyToTerraform(struct?: DataAwsBudgetsBudget.BudgetLimitProperty): any;
export declare function dataAwsBudgetsBudgetBudgetLimitPropertyToHclTerraform(struct?: DataAwsBudgetsBudget.BudgetLimitProperty): any;
export declare function dataAwsBudgetsBudgetActualSpendPropertyToTerraform(struct?: DataAwsBudgetsBudget.ActualSpendProperty): any;
export declare function dataAwsBudgetsBudgetActualSpendPropertyToHclTerraform(struct?: DataAwsBudgetsBudget.ActualSpendProperty): any;
export declare function dataAwsBudgetsBudgetCalculatedSpendPropertyToTerraform(struct?: DataAwsBudgetsBudget.CalculatedSpendProperty): any;
export declare function dataAwsBudgetsBudgetCalculatedSpendPropertyToHclTerraform(struct?: DataAwsBudgetsBudget.CalculatedSpendProperty): any;
export declare function dataAwsBudgetsBudgetCostFilterPropertyToTerraform(struct?: DataAwsBudgetsBudget.CostFilterProperty): any;
export declare function dataAwsBudgetsBudgetCostFilterPropertyToHclTerraform(struct?: DataAwsBudgetsBudget.CostFilterProperty): any;
export declare function dataAwsBudgetsBudgetCostTypesPropertyToTerraform(struct?: DataAwsBudgetsBudget.CostTypesProperty): any;
export declare function dataAwsBudgetsBudgetCostTypesPropertyToHclTerraform(struct?: DataAwsBudgetsBudget.CostTypesProperty): any;
export declare function dataAwsBudgetsBudgetNotificationPropertyToTerraform(struct?: DataAwsBudgetsBudget.NotificationProperty): any;
export declare function dataAwsBudgetsBudgetNotificationPropertyToHclTerraform(struct?: DataAwsBudgetsBudget.NotificationProperty): any;
export declare function dataAwsBudgetsBudgetPlannedLimitPropertyToTerraform(struct?: DataAwsBudgetsBudget.PlannedLimitProperty): any;
export declare function dataAwsBudgetsBudgetPlannedLimitPropertyToHclTerraform(struct?: DataAwsBudgetsBudget.PlannedLimitProperty): any;
export declare namespace DataAwsBudgetsBudget {
    interface HistoricalOptionsProperty {
    }
    class HistoricalOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HistoricalOptionsProperty | undefined;
        set internalValue(value: HistoricalOptionsProperty | undefined);
        get budgetAdjustmentPeriod(): number;
        get lookbackAvailablePeriods(): number;
    }
    class HistoricalOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HistoricalOptionsPropertyOutputReference;
    }
    interface AutoAdjustDataProperty {
    }
    class AutoAdjustDataPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AutoAdjustDataProperty | undefined;
        set internalValue(value: AutoAdjustDataProperty | undefined);
        get autoAdjustType(): string;
        private _historicalOptions;
        get historicalOptions(): HistoricalOptionsPropertyList;
        get lastAutoAdjustTime(): string;
    }
    class AutoAdjustDataPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AutoAdjustDataPropertyOutputReference;
    }
    interface BudgetLimitProperty {
    }
    class BudgetLimitPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): BudgetLimitProperty | undefined;
        set internalValue(value: BudgetLimitProperty | undefined);
        get amount(): string;
        get unit(): string;
    }
    class BudgetLimitPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): BudgetLimitPropertyOutputReference;
    }
    interface ActualSpendProperty {
    }
    class ActualSpendPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ActualSpendProperty | undefined;
        set internalValue(value: ActualSpendProperty | undefined);
        get amount(): string;
        get unit(): string;
    }
    class ActualSpendPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ActualSpendPropertyOutputReference;
    }
    interface CalculatedSpendProperty {
    }
    class CalculatedSpendPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CalculatedSpendProperty | undefined;
        set internalValue(value: CalculatedSpendProperty | undefined);
        private _actualSpend;
        get actualSpend(): ActualSpendPropertyList;
    }
    class CalculatedSpendPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CalculatedSpendPropertyOutputReference;
    }
    interface CostFilterProperty {
    }
    class CostFilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CostFilterProperty | undefined;
        set internalValue(value: CostFilterProperty | undefined);
        get name(): string;
        get values(): string[];
    }
    class CostFilterPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CostFilterPropertyOutputReference;
    }
    interface CostTypesProperty {
    }
    class CostTypesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CostTypesProperty | undefined;
        set internalValue(value: CostTypesProperty | undefined);
        get includeCredit(): cdktn.IResolvable;
        get includeDiscount(): cdktn.IResolvable;
        get includeOtherSubscription(): cdktn.IResolvable;
        get includeRecurring(): cdktn.IResolvable;
        get includeRefund(): cdktn.IResolvable;
        get includeSubscription(): cdktn.IResolvable;
        get includeSupport(): cdktn.IResolvable;
        get includeTax(): cdktn.IResolvable;
        get includeUpfront(): cdktn.IResolvable;
        get useAmortized(): cdktn.IResolvable;
        get useBlended(): cdktn.IResolvable;
    }
    class CostTypesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CostTypesPropertyOutputReference;
    }
    interface NotificationProperty {
    }
    class NotificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NotificationProperty | undefined;
        set internalValue(value: NotificationProperty | undefined);
        get comparisonOperator(): string;
        get notificationType(): string;
        get subscriberEmailAddresses(): string[];
        get subscriberSnsTopicArns(): string[];
        get threshold(): number;
        get thresholdType(): string;
    }
    class NotificationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NotificationPropertyOutputReference;
    }
    interface PlannedLimitProperty {
    }
    class PlannedLimitPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PlannedLimitProperty | undefined;
        set internalValue(value: PlannedLimitProperty | undefined);
        get amount(): string;
        get startTime(): string;
        get unit(): string;
    }
    class PlannedLimitPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PlannedLimitPropertyOutputReference;
    }
}
