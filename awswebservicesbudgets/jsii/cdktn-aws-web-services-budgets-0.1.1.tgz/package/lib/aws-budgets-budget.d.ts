import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsBudgetsBudgetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#account_id AwsBudgetsBudget#account_id}
    */
    readonly accountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#billing_view_arn AwsBudgetsBudget#billing_view_arn}
    */
    readonly billingViewArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#budget_type AwsBudgetsBudget#budget_type}
    */
    readonly budgetType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#id AwsBudgetsBudget#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#limit_amount AwsBudgetsBudget#limit_amount}
    */
    readonly limitAmount?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#limit_unit AwsBudgetsBudget#limit_unit}
    */
    readonly limitUnit?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#metrics AwsBudgetsBudget#metrics}
    */
    readonly metrics?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#name AwsBudgetsBudget#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#name_prefix AwsBudgetsBudget#name_prefix}
    */
    readonly namePrefix?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#tags AwsBudgetsBudget#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#tags_all AwsBudgetsBudget#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#time_period_end AwsBudgetsBudget#time_period_end}
    */
    readonly timePeriodEnd?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#time_period_start AwsBudgetsBudget#time_period_start}
    */
    readonly timePeriodStart?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#time_unit AwsBudgetsBudget#time_unit}
    */
    readonly timeUnit: string;
    /**
    * auto_adjust_data block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#auto_adjust_data AwsBudgetsBudget#auto_adjust_data}
    */
    readonly autoAdjustData?: AwsBudgetsBudget.AutoAdjustDataProperty;
    /**
    * cost_filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#cost_filter AwsBudgetsBudget#cost_filter}
    */
    readonly costFilter?: AwsBudgetsBudget.CostFilterProperty[] | cdktn.IResolvable;
    /**
    * cost_types block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#cost_types AwsBudgetsBudget#cost_types}
    */
    readonly costTypes?: AwsBudgetsBudget.CostTypesProperty;
    /**
    * filter_expression block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#filter_expression AwsBudgetsBudget#filter_expression}
    */
    readonly filterExpression?: AwsBudgetsBudget.FilterExpressionProperty;
    /**
    * notification block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#notification AwsBudgetsBudget#notification}
    */
    readonly notification?: AwsBudgetsBudget.NotificationProperty[] | cdktn.IResolvable;
    /**
    * planned_limit block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#planned_limit AwsBudgetsBudget#planned_limit}
    */
    readonly plannedLimit?: AwsBudgetsBudget.PlannedLimitProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget aws_budgets_budget}
*/
export declare class AwsBudgetsBudget extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_budgets_budget";
    /**
    * Generates CDKTN code for importing a AwsBudgetsBudget resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsBudgetsBudget to import
    * @param importFromId The id of the existing AwsBudgetsBudget that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsBudgetsBudget to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget aws_budgets_budget} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsBudgetsBudgetConfig
    */
    constructor(scope: Construct, id: string, config: AwsBudgetsBudgetConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    resetAccountId(): void;
    get accountIdInput(): string | undefined;
    get arn(): string;
    private _billingViewArn?;
    get billingViewArn(): string;
    set billingViewArn(value: string);
    resetBillingViewArn(): void;
    get billingViewArnInput(): string | undefined;
    private _budgetType?;
    get budgetType(): string;
    set budgetType(value: string);
    get budgetTypeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _limitAmount?;
    get limitAmount(): string;
    set limitAmount(value: string);
    resetLimitAmount(): void;
    get limitAmountInput(): string | undefined;
    private _limitUnit?;
    get limitUnit(): string;
    set limitUnit(value: string);
    resetLimitUnit(): void;
    get limitUnitInput(): string | undefined;
    private _metrics?;
    get metrics(): string[];
    set metrics(value: string[]);
    resetMetrics(): void;
    get metricsInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namePrefix?;
    get namePrefix(): string;
    set namePrefix(value: string);
    resetNamePrefix(): void;
    get namePrefixInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _timePeriodEnd?;
    get timePeriodEnd(): string;
    set timePeriodEnd(value: string);
    resetTimePeriodEnd(): void;
    get timePeriodEndInput(): string | undefined;
    private _timePeriodStart?;
    get timePeriodStart(): string;
    set timePeriodStart(value: string);
    resetTimePeriodStart(): void;
    get timePeriodStartInput(): string | undefined;
    private _timeUnit?;
    get timeUnit(): string;
    set timeUnit(value: string);
    get timeUnitInput(): string | undefined;
    private _autoAdjustData;
    get autoAdjustData(): AwsBudgetsBudget.AutoAdjustDataPropertyOutputReference;
    putAutoAdjustData(value: AwsBudgetsBudget.AutoAdjustDataProperty): void;
    resetAutoAdjustData(): void;
    get autoAdjustDataInput(): AwsBudgetsBudget.AutoAdjustDataProperty | undefined;
    private _costFilter;
    get costFilter(): AwsBudgetsBudget.CostFilterPropertyList;
    putCostFilter(value: AwsBudgetsBudget.CostFilterProperty[] | cdktn.IResolvable): void;
    resetCostFilter(): void;
    get costFilterInput(): cdktn.IResolvable | AwsBudgetsBudget.CostFilterProperty[] | undefined;
    private _costTypes;
    get costTypes(): AwsBudgetsBudget.CostTypesPropertyOutputReference;
    putCostTypes(value: AwsBudgetsBudget.CostTypesProperty): void;
    resetCostTypes(): void;
    get costTypesInput(): AwsBudgetsBudget.CostTypesProperty | undefined;
    private _filterExpression;
    get filterExpression(): AwsBudgetsBudget.FilterExpressionPropertyOutputReference;
    putFilterExpression(value: AwsBudgetsBudget.FilterExpressionProperty): void;
    resetFilterExpression(): void;
    get filterExpressionInput(): AwsBudgetsBudget.FilterExpressionProperty | undefined;
    private _notification;
    get notification(): AwsBudgetsBudget.NotificationPropertyList;
    putNotification(value: AwsBudgetsBudget.NotificationProperty[] | cdktn.IResolvable): void;
    resetNotification(): void;
    get notificationInput(): cdktn.IResolvable | AwsBudgetsBudget.NotificationProperty[] | undefined;
    private _plannedLimit;
    get plannedLimit(): AwsBudgetsBudget.PlannedLimitPropertyList;
    putPlannedLimit(value: AwsBudgetsBudget.PlannedLimitProperty[] | cdktn.IResolvable): void;
    resetPlannedLimit(): void;
    get plannedLimitInput(): cdktn.IResolvable | AwsBudgetsBudget.PlannedLimitProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsBudgetsBudgetHistoricalOptionsPropertyToTerraform(struct?: AwsBudgetsBudget.HistoricalOptionsPropertyOutputReference | AwsBudgetsBudget.HistoricalOptionsProperty): any;
export declare function awsBudgetsBudgetHistoricalOptionsPropertyToHclTerraform(struct?: AwsBudgetsBudget.HistoricalOptionsPropertyOutputReference | AwsBudgetsBudget.HistoricalOptionsProperty): any;
export declare function awsBudgetsBudgetAutoAdjustDataPropertyToTerraform(struct?: AwsBudgetsBudget.AutoAdjustDataPropertyOutputReference | AwsBudgetsBudget.AutoAdjustDataProperty): any;
export declare function awsBudgetsBudgetAutoAdjustDataPropertyToHclTerraform(struct?: AwsBudgetsBudget.AutoAdjustDataPropertyOutputReference | AwsBudgetsBudget.AutoAdjustDataProperty): any;
export declare function awsBudgetsBudgetCostFilterPropertyToTerraform(struct?: AwsBudgetsBudget.CostFilterProperty | cdktn.IResolvable): any;
export declare function awsBudgetsBudgetCostFilterPropertyToHclTerraform(struct?: AwsBudgetsBudget.CostFilterProperty | cdktn.IResolvable): any;
export declare function awsBudgetsBudgetCostTypesPropertyToTerraform(struct?: AwsBudgetsBudget.CostTypesPropertyOutputReference | AwsBudgetsBudget.CostTypesProperty): any;
export declare function awsBudgetsBudgetCostTypesPropertyToHclTerraform(struct?: AwsBudgetsBudget.CostTypesPropertyOutputReference | AwsBudgetsBudget.CostTypesProperty): any;
export declare function awsBudgetsBudgetFilterExpressionAndAndCostCategoriesPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionAndAndCostCategoriesPropertyOutputReference | AwsBudgetsBudget.FilterExpressionAndAndCostCategoriesProperty): any;
export declare function awsBudgetsBudgetFilterExpressionAndAndCostCategoriesPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionAndAndCostCategoriesPropertyOutputReference | AwsBudgetsBudget.FilterExpressionAndAndCostCategoriesProperty): any;
export declare function awsBudgetsBudgetFilterExpressionAndAndDimensionsPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionAndAndDimensionsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionAndAndDimensionsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionAndAndDimensionsPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionAndAndDimensionsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionAndAndDimensionsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionAndAndTagsPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionAndAndTagsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionAndAndTagsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionAndAndTagsPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionAndAndTagsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionAndAndTagsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionAndAndPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionAndAndProperty | cdktn.IResolvable): any;
export declare function awsBudgetsBudgetFilterExpressionAndAndPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionAndAndProperty | cdktn.IResolvable): any;
export declare function awsBudgetsBudgetFilterExpressionAndCostCategoriesPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionAndCostCategoriesPropertyOutputReference | AwsBudgetsBudget.FilterExpressionAndCostCategoriesProperty): any;
export declare function awsBudgetsBudgetFilterExpressionAndCostCategoriesPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionAndCostCategoriesPropertyOutputReference | AwsBudgetsBudget.FilterExpressionAndCostCategoriesProperty): any;
export declare function awsBudgetsBudgetFilterExpressionAndDimensionsPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionAndDimensionsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionAndDimensionsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionAndDimensionsPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionAndDimensionsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionAndDimensionsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionAndNotCostCategoriesPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionAndNotCostCategoriesPropertyOutputReference | AwsBudgetsBudget.FilterExpressionAndNotCostCategoriesProperty): any;
export declare function awsBudgetsBudgetFilterExpressionAndNotCostCategoriesPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionAndNotCostCategoriesPropertyOutputReference | AwsBudgetsBudget.FilterExpressionAndNotCostCategoriesProperty): any;
export declare function awsBudgetsBudgetFilterExpressionAndNotDimensionsPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionAndNotDimensionsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionAndNotDimensionsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionAndNotDimensionsPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionAndNotDimensionsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionAndNotDimensionsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionAndNotTagsPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionAndNotTagsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionAndNotTagsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionAndNotTagsPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionAndNotTagsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionAndNotTagsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionAndNotPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionAndNotPropertyOutputReference | AwsBudgetsBudget.FilterExpressionAndNotProperty): any;
export declare function awsBudgetsBudgetFilterExpressionAndNotPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionAndNotPropertyOutputReference | AwsBudgetsBudget.FilterExpressionAndNotProperty): any;
export declare function awsBudgetsBudgetFilterExpressionAndOrCostCategoriesPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionAndOrCostCategoriesPropertyOutputReference | AwsBudgetsBudget.FilterExpressionAndOrCostCategoriesProperty): any;
export declare function awsBudgetsBudgetFilterExpressionAndOrCostCategoriesPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionAndOrCostCategoriesPropertyOutputReference | AwsBudgetsBudget.FilterExpressionAndOrCostCategoriesProperty): any;
export declare function awsBudgetsBudgetFilterExpressionAndOrDimensionsPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionAndOrDimensionsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionAndOrDimensionsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionAndOrDimensionsPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionAndOrDimensionsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionAndOrDimensionsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionAndOrTagsPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionAndOrTagsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionAndOrTagsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionAndOrTagsPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionAndOrTagsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionAndOrTagsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionAndOrPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionAndOrProperty | cdktn.IResolvable): any;
export declare function awsBudgetsBudgetFilterExpressionAndOrPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionAndOrProperty | cdktn.IResolvable): any;
export declare function awsBudgetsBudgetFilterExpressionAndTagsPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionAndTagsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionAndTagsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionAndTagsPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionAndTagsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionAndTagsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionAndPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionAndProperty | cdktn.IResolvable): any;
export declare function awsBudgetsBudgetFilterExpressionAndPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionAndProperty | cdktn.IResolvable): any;
export declare function awsBudgetsBudgetFilterExpressionCostCategoriesPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionCostCategoriesPropertyOutputReference | AwsBudgetsBudget.FilterExpressionCostCategoriesProperty): any;
export declare function awsBudgetsBudgetFilterExpressionCostCategoriesPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionCostCategoriesPropertyOutputReference | AwsBudgetsBudget.FilterExpressionCostCategoriesProperty): any;
export declare function awsBudgetsBudgetFilterExpressionDimensionsPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionDimensionsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionDimensionsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionDimensionsPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionDimensionsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionDimensionsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionNotAndCostCategoriesPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionNotAndCostCategoriesPropertyOutputReference | AwsBudgetsBudget.FilterExpressionNotAndCostCategoriesProperty): any;
export declare function awsBudgetsBudgetFilterExpressionNotAndCostCategoriesPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionNotAndCostCategoriesPropertyOutputReference | AwsBudgetsBudget.FilterExpressionNotAndCostCategoriesProperty): any;
export declare function awsBudgetsBudgetFilterExpressionNotAndDimensionsPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionNotAndDimensionsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionNotAndDimensionsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionNotAndDimensionsPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionNotAndDimensionsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionNotAndDimensionsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionNotAndTagsPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionNotAndTagsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionNotAndTagsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionNotAndTagsPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionNotAndTagsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionNotAndTagsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionNotAndPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionNotAndProperty | cdktn.IResolvable): any;
export declare function awsBudgetsBudgetFilterExpressionNotAndPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionNotAndProperty | cdktn.IResolvable): any;
export declare function awsBudgetsBudgetFilterExpressionNotCostCategoriesPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionNotCostCategoriesPropertyOutputReference | AwsBudgetsBudget.FilterExpressionNotCostCategoriesProperty): any;
export declare function awsBudgetsBudgetFilterExpressionNotCostCategoriesPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionNotCostCategoriesPropertyOutputReference | AwsBudgetsBudget.FilterExpressionNotCostCategoriesProperty): any;
export declare function awsBudgetsBudgetFilterExpressionNotDimensionsPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionNotDimensionsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionNotDimensionsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionNotDimensionsPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionNotDimensionsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionNotDimensionsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionNotNotCostCategoriesPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionNotNotCostCategoriesPropertyOutputReference | AwsBudgetsBudget.FilterExpressionNotNotCostCategoriesProperty): any;
export declare function awsBudgetsBudgetFilterExpressionNotNotCostCategoriesPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionNotNotCostCategoriesPropertyOutputReference | AwsBudgetsBudget.FilterExpressionNotNotCostCategoriesProperty): any;
export declare function awsBudgetsBudgetFilterExpressionNotNotDimensionsPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionNotNotDimensionsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionNotNotDimensionsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionNotNotDimensionsPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionNotNotDimensionsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionNotNotDimensionsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionNotNotTagsPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionNotNotTagsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionNotNotTagsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionNotNotTagsPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionNotNotTagsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionNotNotTagsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionNotNotPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionNotNotPropertyOutputReference | AwsBudgetsBudget.FilterExpressionNotNotProperty): any;
export declare function awsBudgetsBudgetFilterExpressionNotNotPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionNotNotPropertyOutputReference | AwsBudgetsBudget.FilterExpressionNotNotProperty): any;
export declare function awsBudgetsBudgetFilterExpressionNotOrCostCategoriesPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionNotOrCostCategoriesPropertyOutputReference | AwsBudgetsBudget.FilterExpressionNotOrCostCategoriesProperty): any;
export declare function awsBudgetsBudgetFilterExpressionNotOrCostCategoriesPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionNotOrCostCategoriesPropertyOutputReference | AwsBudgetsBudget.FilterExpressionNotOrCostCategoriesProperty): any;
export declare function awsBudgetsBudgetFilterExpressionNotOrDimensionsPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionNotOrDimensionsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionNotOrDimensionsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionNotOrDimensionsPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionNotOrDimensionsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionNotOrDimensionsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionNotOrTagsPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionNotOrTagsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionNotOrTagsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionNotOrTagsPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionNotOrTagsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionNotOrTagsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionNotOrPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionNotOrProperty | cdktn.IResolvable): any;
export declare function awsBudgetsBudgetFilterExpressionNotOrPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionNotOrProperty | cdktn.IResolvable): any;
export declare function awsBudgetsBudgetFilterExpressionNotTagsPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionNotTagsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionNotTagsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionNotTagsPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionNotTagsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionNotTagsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionNotPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionNotPropertyOutputReference | AwsBudgetsBudget.FilterExpressionNotProperty): any;
export declare function awsBudgetsBudgetFilterExpressionNotPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionNotPropertyOutputReference | AwsBudgetsBudget.FilterExpressionNotProperty): any;
export declare function awsBudgetsBudgetFilterExpressionOrAndCostCategoriesPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionOrAndCostCategoriesPropertyOutputReference | AwsBudgetsBudget.FilterExpressionOrAndCostCategoriesProperty): any;
export declare function awsBudgetsBudgetFilterExpressionOrAndCostCategoriesPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionOrAndCostCategoriesPropertyOutputReference | AwsBudgetsBudget.FilterExpressionOrAndCostCategoriesProperty): any;
export declare function awsBudgetsBudgetFilterExpressionOrAndDimensionsPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionOrAndDimensionsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionOrAndDimensionsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionOrAndDimensionsPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionOrAndDimensionsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionOrAndDimensionsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionOrAndTagsPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionOrAndTagsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionOrAndTagsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionOrAndTagsPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionOrAndTagsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionOrAndTagsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionOrAndPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionOrAndProperty | cdktn.IResolvable): any;
export declare function awsBudgetsBudgetFilterExpressionOrAndPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionOrAndProperty | cdktn.IResolvable): any;
export declare function awsBudgetsBudgetFilterExpressionOrCostCategoriesPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionOrCostCategoriesPropertyOutputReference | AwsBudgetsBudget.FilterExpressionOrCostCategoriesProperty): any;
export declare function awsBudgetsBudgetFilterExpressionOrCostCategoriesPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionOrCostCategoriesPropertyOutputReference | AwsBudgetsBudget.FilterExpressionOrCostCategoriesProperty): any;
export declare function awsBudgetsBudgetFilterExpressionOrDimensionsPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionOrDimensionsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionOrDimensionsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionOrDimensionsPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionOrDimensionsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionOrDimensionsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionOrNotCostCategoriesPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionOrNotCostCategoriesPropertyOutputReference | AwsBudgetsBudget.FilterExpressionOrNotCostCategoriesProperty): any;
export declare function awsBudgetsBudgetFilterExpressionOrNotCostCategoriesPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionOrNotCostCategoriesPropertyOutputReference | AwsBudgetsBudget.FilterExpressionOrNotCostCategoriesProperty): any;
export declare function awsBudgetsBudgetFilterExpressionOrNotDimensionsPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionOrNotDimensionsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionOrNotDimensionsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionOrNotDimensionsPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionOrNotDimensionsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionOrNotDimensionsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionOrNotTagsPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionOrNotTagsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionOrNotTagsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionOrNotTagsPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionOrNotTagsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionOrNotTagsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionOrNotPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionOrNotPropertyOutputReference | AwsBudgetsBudget.FilterExpressionOrNotProperty): any;
export declare function awsBudgetsBudgetFilterExpressionOrNotPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionOrNotPropertyOutputReference | AwsBudgetsBudget.FilterExpressionOrNotProperty): any;
export declare function awsBudgetsBudgetFilterExpressionOrOrCostCategoriesPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionOrOrCostCategoriesPropertyOutputReference | AwsBudgetsBudget.FilterExpressionOrOrCostCategoriesProperty): any;
export declare function awsBudgetsBudgetFilterExpressionOrOrCostCategoriesPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionOrOrCostCategoriesPropertyOutputReference | AwsBudgetsBudget.FilterExpressionOrOrCostCategoriesProperty): any;
export declare function awsBudgetsBudgetFilterExpressionOrOrDimensionsPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionOrOrDimensionsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionOrOrDimensionsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionOrOrDimensionsPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionOrOrDimensionsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionOrOrDimensionsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionOrOrTagsPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionOrOrTagsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionOrOrTagsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionOrOrTagsPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionOrOrTagsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionOrOrTagsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionOrOrPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionOrOrProperty | cdktn.IResolvable): any;
export declare function awsBudgetsBudgetFilterExpressionOrOrPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionOrOrProperty | cdktn.IResolvable): any;
export declare function awsBudgetsBudgetFilterExpressionOrTagsPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionOrTagsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionOrTagsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionOrTagsPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionOrTagsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionOrTagsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionOrPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionOrProperty | cdktn.IResolvable): any;
export declare function awsBudgetsBudgetFilterExpressionOrPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionOrProperty | cdktn.IResolvable): any;
export declare function awsBudgetsBudgetFilterExpressionTagsPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionTagsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionTagsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionTagsPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionTagsPropertyOutputReference | AwsBudgetsBudget.FilterExpressionTagsProperty): any;
export declare function awsBudgetsBudgetFilterExpressionPropertyToTerraform(struct?: AwsBudgetsBudget.FilterExpressionPropertyOutputReference | AwsBudgetsBudget.FilterExpressionProperty): any;
export declare function awsBudgetsBudgetFilterExpressionPropertyToHclTerraform(struct?: AwsBudgetsBudget.FilterExpressionPropertyOutputReference | AwsBudgetsBudget.FilterExpressionProperty): any;
export declare function awsBudgetsBudgetNotificationPropertyToTerraform(struct?: AwsBudgetsBudget.NotificationProperty | cdktn.IResolvable): any;
export declare function awsBudgetsBudgetNotificationPropertyToHclTerraform(struct?: AwsBudgetsBudget.NotificationProperty | cdktn.IResolvable): any;
export declare function awsBudgetsBudgetPlannedLimitPropertyToTerraform(struct?: AwsBudgetsBudget.PlannedLimitProperty | cdktn.IResolvable): any;
export declare function awsBudgetsBudgetPlannedLimitPropertyToHclTerraform(struct?: AwsBudgetsBudget.PlannedLimitProperty | cdktn.IResolvable): any;
export declare namespace AwsBudgetsBudget {
    interface HistoricalOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#budget_adjustment_period AwsBudgetsBudget#budget_adjustment_period}
        */
        readonly budgetAdjustmentPeriod: number;
    }
    class HistoricalOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HistoricalOptionsProperty | undefined;
        set internalValue(value: HistoricalOptionsProperty | undefined);
        private _budgetAdjustmentPeriod?;
        get budgetAdjustmentPeriod(): number;
        set budgetAdjustmentPeriod(value: number);
        get budgetAdjustmentPeriodInput(): number | undefined;
        get lookbackAvailablePeriods(): number;
    }
    interface AutoAdjustDataProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#auto_adjust_type AwsBudgetsBudget#auto_adjust_type}
        */
        readonly autoAdjustType: string;
        /**
        * historical_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#historical_options AwsBudgetsBudget#historical_options}
        */
        readonly historicalOptions?: HistoricalOptionsProperty;
    }
    class AutoAdjustDataPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AutoAdjustDataProperty | undefined;
        set internalValue(value: AutoAdjustDataProperty | undefined);
        private _autoAdjustType?;
        get autoAdjustType(): string;
        set autoAdjustType(value: string);
        get autoAdjustTypeInput(): string | undefined;
        get lastAutoAdjustTime(): string;
        private _historicalOptions;
        get historicalOptions(): HistoricalOptionsPropertyOutputReference;
        putHistoricalOptions(value: HistoricalOptionsProperty): void;
        resetHistoricalOptions(): void;
        get historicalOptionsInput(): HistoricalOptionsProperty | undefined;
    }
    interface CostFilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#name AwsBudgetsBudget#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#values AwsBudgetsBudget#values}
        */
        readonly values: string[];
    }
    class CostFilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CostFilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CostFilterProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class CostFilterPropertyList extends cdktn.ComplexList {
        internalValue?: CostFilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CostFilterPropertyOutputReference;
    }
    interface CostTypesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#include_credit AwsBudgetsBudget#include_credit}
        */
        readonly includeCredit?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#include_discount AwsBudgetsBudget#include_discount}
        */
        readonly includeDiscount?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#include_other_subscription AwsBudgetsBudget#include_other_subscription}
        */
        readonly includeOtherSubscription?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#include_recurring AwsBudgetsBudget#include_recurring}
        */
        readonly includeRecurring?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#include_refund AwsBudgetsBudget#include_refund}
        */
        readonly includeRefund?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#include_subscription AwsBudgetsBudget#include_subscription}
        */
        readonly includeSubscription?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#include_support AwsBudgetsBudget#include_support}
        */
        readonly includeSupport?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#include_tax AwsBudgetsBudget#include_tax}
        */
        readonly includeTax?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#include_upfront AwsBudgetsBudget#include_upfront}
        */
        readonly includeUpfront?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#use_amortized AwsBudgetsBudget#use_amortized}
        */
        readonly useAmortized?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#use_blended AwsBudgetsBudget#use_blended}
        */
        readonly useBlended?: boolean | cdktn.IResolvable;
    }
    class CostTypesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CostTypesProperty | undefined;
        set internalValue(value: CostTypesProperty | undefined);
        private _includeCredit?;
        get includeCredit(): boolean | cdktn.IResolvable;
        set includeCredit(value: boolean | cdktn.IResolvable);
        resetIncludeCredit(): void;
        get includeCreditInput(): boolean | cdktn.IResolvable | undefined;
        private _includeDiscount?;
        get includeDiscount(): boolean | cdktn.IResolvable;
        set includeDiscount(value: boolean | cdktn.IResolvable);
        resetIncludeDiscount(): void;
        get includeDiscountInput(): boolean | cdktn.IResolvable | undefined;
        private _includeOtherSubscription?;
        get includeOtherSubscription(): boolean | cdktn.IResolvable;
        set includeOtherSubscription(value: boolean | cdktn.IResolvable);
        resetIncludeOtherSubscription(): void;
        get includeOtherSubscriptionInput(): boolean | cdktn.IResolvable | undefined;
        private _includeRecurring?;
        get includeRecurring(): boolean | cdktn.IResolvable;
        set includeRecurring(value: boolean | cdktn.IResolvable);
        resetIncludeRecurring(): void;
        get includeRecurringInput(): boolean | cdktn.IResolvable | undefined;
        private _includeRefund?;
        get includeRefund(): boolean | cdktn.IResolvable;
        set includeRefund(value: boolean | cdktn.IResolvable);
        resetIncludeRefund(): void;
        get includeRefundInput(): boolean | cdktn.IResolvable | undefined;
        private _includeSubscription?;
        get includeSubscription(): boolean | cdktn.IResolvable;
        set includeSubscription(value: boolean | cdktn.IResolvable);
        resetIncludeSubscription(): void;
        get includeSubscriptionInput(): boolean | cdktn.IResolvable | undefined;
        private _includeSupport?;
        get includeSupport(): boolean | cdktn.IResolvable;
        set includeSupport(value: boolean | cdktn.IResolvable);
        resetIncludeSupport(): void;
        get includeSupportInput(): boolean | cdktn.IResolvable | undefined;
        private _includeTax?;
        get includeTax(): boolean | cdktn.IResolvable;
        set includeTax(value: boolean | cdktn.IResolvable);
        resetIncludeTax(): void;
        get includeTaxInput(): boolean | cdktn.IResolvable | undefined;
        private _includeUpfront?;
        get includeUpfront(): boolean | cdktn.IResolvable;
        set includeUpfront(value: boolean | cdktn.IResolvable);
        resetIncludeUpfront(): void;
        get includeUpfrontInput(): boolean | cdktn.IResolvable | undefined;
        private _useAmortized?;
        get useAmortized(): boolean | cdktn.IResolvable;
        set useAmortized(value: boolean | cdktn.IResolvable);
        resetUseAmortized(): void;
        get useAmortizedInput(): boolean | cdktn.IResolvable | undefined;
        private _useBlended?;
        get useBlended(): boolean | cdktn.IResolvable;
        set useBlended(value: boolean | cdktn.IResolvable);
        resetUseBlended(): void;
        get useBlendedInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface FilterExpressionAndAndCostCategoriesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#key AwsBudgetsBudget#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#match_options AwsBudgetsBudget#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#values AwsBudgetsBudget#values}
        */
        readonly values?: string[];
    }
    class FilterExpressionAndAndCostCategoriesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterExpressionAndAndCostCategoriesProperty | undefined;
        set internalValue(value: FilterExpressionAndAndCostCategoriesProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterExpressionAndAndDimensionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#key AwsBudgetsBudget#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#match_options AwsBudgetsBudget#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#values AwsBudgetsBudget#values}
        */
        readonly values: string[];
    }
    class FilterExpressionAndAndDimensionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterExpressionAndAndDimensionsProperty | undefined;
        set internalValue(value: FilterExpressionAndAndDimensionsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    interface FilterExpressionAndAndTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#key AwsBudgetsBudget#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#match_options AwsBudgetsBudget#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#values AwsBudgetsBudget#values}
        */
        readonly values?: string[];
    }
    class FilterExpressionAndAndTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterExpressionAndAndTagsProperty | undefined;
        set internalValue(value: FilterExpressionAndAndTagsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterExpressionAndAndProperty {
        /**
        * cost_categories block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#cost_categories AwsBudgetsBudget#cost_categories}
        */
        readonly costCategories?: FilterExpressionAndAndCostCategoriesProperty;
        /**
        * dimensions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#dimensions AwsBudgetsBudget#dimensions}
        */
        readonly dimensions?: FilterExpressionAndAndDimensionsProperty;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#tags AwsBudgetsBudget#tags}
        */
        readonly tags?: FilterExpressionAndAndTagsProperty;
    }
    class FilterExpressionAndAndPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterExpressionAndAndProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilterExpressionAndAndProperty | cdktn.IResolvable | undefined);
        private _costCategories;
        get costCategories(): FilterExpressionAndAndCostCategoriesPropertyOutputReference;
        putCostCategories(value: FilterExpressionAndAndCostCategoriesProperty): void;
        resetCostCategories(): void;
        get costCategoriesInput(): FilterExpressionAndAndCostCategoriesProperty | undefined;
        private _dimensions;
        get dimensions(): FilterExpressionAndAndDimensionsPropertyOutputReference;
        putDimensions(value: FilterExpressionAndAndDimensionsProperty): void;
        resetDimensions(): void;
        get dimensionsInput(): FilterExpressionAndAndDimensionsProperty | undefined;
        private _tags;
        get tags(): FilterExpressionAndAndTagsPropertyOutputReference;
        putTags(value: FilterExpressionAndAndTagsProperty): void;
        resetTags(): void;
        get tagsInput(): FilterExpressionAndAndTagsProperty | undefined;
    }
    class FilterExpressionAndAndPropertyList extends cdktn.ComplexList {
        internalValue?: FilterExpressionAndAndProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterExpressionAndAndPropertyOutputReference;
    }
    interface FilterExpressionAndCostCategoriesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#key AwsBudgetsBudget#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#match_options AwsBudgetsBudget#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#values AwsBudgetsBudget#values}
        */
        readonly values?: string[];
    }
    class FilterExpressionAndCostCategoriesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterExpressionAndCostCategoriesProperty | undefined;
        set internalValue(value: FilterExpressionAndCostCategoriesProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterExpressionAndDimensionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#key AwsBudgetsBudget#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#match_options AwsBudgetsBudget#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#values AwsBudgetsBudget#values}
        */
        readonly values: string[];
    }
    class FilterExpressionAndDimensionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterExpressionAndDimensionsProperty | undefined;
        set internalValue(value: FilterExpressionAndDimensionsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    interface FilterExpressionAndNotCostCategoriesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#key AwsBudgetsBudget#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#match_options AwsBudgetsBudget#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#values AwsBudgetsBudget#values}
        */
        readonly values?: string[];
    }
    class FilterExpressionAndNotCostCategoriesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterExpressionAndNotCostCategoriesProperty | undefined;
        set internalValue(value: FilterExpressionAndNotCostCategoriesProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterExpressionAndNotDimensionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#key AwsBudgetsBudget#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#match_options AwsBudgetsBudget#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#values AwsBudgetsBudget#values}
        */
        readonly values: string[];
    }
    class FilterExpressionAndNotDimensionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterExpressionAndNotDimensionsProperty | undefined;
        set internalValue(value: FilterExpressionAndNotDimensionsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    interface FilterExpressionAndNotTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#key AwsBudgetsBudget#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#match_options AwsBudgetsBudget#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#values AwsBudgetsBudget#values}
        */
        readonly values?: string[];
    }
    class FilterExpressionAndNotTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterExpressionAndNotTagsProperty | undefined;
        set internalValue(value: FilterExpressionAndNotTagsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterExpressionAndNotProperty {
        /**
        * cost_categories block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#cost_categories AwsBudgetsBudget#cost_categories}
        */
        readonly costCategories?: FilterExpressionAndNotCostCategoriesProperty;
        /**
        * dimensions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#dimensions AwsBudgetsBudget#dimensions}
        */
        readonly dimensions?: FilterExpressionAndNotDimensionsProperty;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#tags AwsBudgetsBudget#tags}
        */
        readonly tags?: FilterExpressionAndNotTagsProperty;
    }
    class FilterExpressionAndNotPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterExpressionAndNotProperty | undefined;
        set internalValue(value: FilterExpressionAndNotProperty | undefined);
        private _costCategories;
        get costCategories(): FilterExpressionAndNotCostCategoriesPropertyOutputReference;
        putCostCategories(value: FilterExpressionAndNotCostCategoriesProperty): void;
        resetCostCategories(): void;
        get costCategoriesInput(): FilterExpressionAndNotCostCategoriesProperty | undefined;
        private _dimensions;
        get dimensions(): FilterExpressionAndNotDimensionsPropertyOutputReference;
        putDimensions(value: FilterExpressionAndNotDimensionsProperty): void;
        resetDimensions(): void;
        get dimensionsInput(): FilterExpressionAndNotDimensionsProperty | undefined;
        private _tags;
        get tags(): FilterExpressionAndNotTagsPropertyOutputReference;
        putTags(value: FilterExpressionAndNotTagsProperty): void;
        resetTags(): void;
        get tagsInput(): FilterExpressionAndNotTagsProperty | undefined;
    }
    interface FilterExpressionAndOrCostCategoriesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#key AwsBudgetsBudget#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#match_options AwsBudgetsBudget#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#values AwsBudgetsBudget#values}
        */
        readonly values?: string[];
    }
    class FilterExpressionAndOrCostCategoriesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterExpressionAndOrCostCategoriesProperty | undefined;
        set internalValue(value: FilterExpressionAndOrCostCategoriesProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterExpressionAndOrDimensionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#key AwsBudgetsBudget#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#match_options AwsBudgetsBudget#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#values AwsBudgetsBudget#values}
        */
        readonly values: string[];
    }
    class FilterExpressionAndOrDimensionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterExpressionAndOrDimensionsProperty | undefined;
        set internalValue(value: FilterExpressionAndOrDimensionsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    interface FilterExpressionAndOrTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#key AwsBudgetsBudget#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#match_options AwsBudgetsBudget#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#values AwsBudgetsBudget#values}
        */
        readonly values?: string[];
    }
    class FilterExpressionAndOrTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterExpressionAndOrTagsProperty | undefined;
        set internalValue(value: FilterExpressionAndOrTagsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterExpressionAndOrProperty {
        /**
        * cost_categories block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#cost_categories AwsBudgetsBudget#cost_categories}
        */
        readonly costCategories?: FilterExpressionAndOrCostCategoriesProperty;
        /**
        * dimensions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#dimensions AwsBudgetsBudget#dimensions}
        */
        readonly dimensions?: FilterExpressionAndOrDimensionsProperty;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#tags AwsBudgetsBudget#tags}
        */
        readonly tags?: FilterExpressionAndOrTagsProperty;
    }
    class FilterExpressionAndOrPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterExpressionAndOrProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilterExpressionAndOrProperty | cdktn.IResolvable | undefined);
        private _costCategories;
        get costCategories(): FilterExpressionAndOrCostCategoriesPropertyOutputReference;
        putCostCategories(value: FilterExpressionAndOrCostCategoriesProperty): void;
        resetCostCategories(): void;
        get costCategoriesInput(): FilterExpressionAndOrCostCategoriesProperty | undefined;
        private _dimensions;
        get dimensions(): FilterExpressionAndOrDimensionsPropertyOutputReference;
        putDimensions(value: FilterExpressionAndOrDimensionsProperty): void;
        resetDimensions(): void;
        get dimensionsInput(): FilterExpressionAndOrDimensionsProperty | undefined;
        private _tags;
        get tags(): FilterExpressionAndOrTagsPropertyOutputReference;
        putTags(value: FilterExpressionAndOrTagsProperty): void;
        resetTags(): void;
        get tagsInput(): FilterExpressionAndOrTagsProperty | undefined;
    }
    class FilterExpressionAndOrPropertyList extends cdktn.ComplexList {
        internalValue?: FilterExpressionAndOrProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterExpressionAndOrPropertyOutputReference;
    }
    interface FilterExpressionAndTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#key AwsBudgetsBudget#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#match_options AwsBudgetsBudget#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#values AwsBudgetsBudget#values}
        */
        readonly values?: string[];
    }
    class FilterExpressionAndTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterExpressionAndTagsProperty | undefined;
        set internalValue(value: FilterExpressionAndTagsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterExpressionAndProperty {
        /**
        * and block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#and AwsBudgetsBudget#and}
        */
        readonly and?: FilterExpressionAndAndProperty[] | cdktn.IResolvable;
        /**
        * cost_categories block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#cost_categories AwsBudgetsBudget#cost_categories}
        */
        readonly costCategories?: FilterExpressionAndCostCategoriesProperty;
        /**
        * dimensions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#dimensions AwsBudgetsBudget#dimensions}
        */
        readonly dimensions?: FilterExpressionAndDimensionsProperty;
        /**
        * not block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#not AwsBudgetsBudget#not}
        */
        readonly not?: FilterExpressionAndNotProperty;
        /**
        * or block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#or AwsBudgetsBudget#or}
        */
        readonly or?: FilterExpressionAndOrProperty[] | cdktn.IResolvable;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#tags AwsBudgetsBudget#tags}
        */
        readonly tags?: FilterExpressionAndTagsProperty;
    }
    class FilterExpressionAndPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterExpressionAndProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilterExpressionAndProperty | cdktn.IResolvable | undefined);
        private _and;
        get and(): FilterExpressionAndAndPropertyList;
        putAnd(value: FilterExpressionAndAndProperty[] | cdktn.IResolvable): void;
        resetAnd(): void;
        get andInput(): cdktn.IResolvable | FilterExpressionAndAndProperty[] | undefined;
        private _costCategories;
        get costCategories(): FilterExpressionAndCostCategoriesPropertyOutputReference;
        putCostCategories(value: FilterExpressionAndCostCategoriesProperty): void;
        resetCostCategories(): void;
        get costCategoriesInput(): FilterExpressionAndCostCategoriesProperty | undefined;
        private _dimensions;
        get dimensions(): FilterExpressionAndDimensionsPropertyOutputReference;
        putDimensions(value: FilterExpressionAndDimensionsProperty): void;
        resetDimensions(): void;
        get dimensionsInput(): FilterExpressionAndDimensionsProperty | undefined;
        private _not;
        get not(): FilterExpressionAndNotPropertyOutputReference;
        putNot(value: FilterExpressionAndNotProperty): void;
        resetNot(): void;
        get notInput(): FilterExpressionAndNotProperty | undefined;
        private _or;
        get or(): FilterExpressionAndOrPropertyList;
        putOr(value: FilterExpressionAndOrProperty[] | cdktn.IResolvable): void;
        resetOr(): void;
        get orInput(): cdktn.IResolvable | FilterExpressionAndOrProperty[] | undefined;
        private _tags;
        get tags(): FilterExpressionAndTagsPropertyOutputReference;
        putTags(value: FilterExpressionAndTagsProperty): void;
        resetTags(): void;
        get tagsInput(): FilterExpressionAndTagsProperty | undefined;
    }
    class FilterExpressionAndPropertyList extends cdktn.ComplexList {
        internalValue?: FilterExpressionAndProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterExpressionAndPropertyOutputReference;
    }
    interface FilterExpressionCostCategoriesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#key AwsBudgetsBudget#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#match_options AwsBudgetsBudget#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#values AwsBudgetsBudget#values}
        */
        readonly values?: string[];
    }
    class FilterExpressionCostCategoriesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterExpressionCostCategoriesProperty | undefined;
        set internalValue(value: FilterExpressionCostCategoriesProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterExpressionDimensionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#key AwsBudgetsBudget#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#match_options AwsBudgetsBudget#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#values AwsBudgetsBudget#values}
        */
        readonly values: string[];
    }
    class FilterExpressionDimensionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterExpressionDimensionsProperty | undefined;
        set internalValue(value: FilterExpressionDimensionsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    interface FilterExpressionNotAndCostCategoriesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#key AwsBudgetsBudget#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#match_options AwsBudgetsBudget#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#values AwsBudgetsBudget#values}
        */
        readonly values?: string[];
    }
    class FilterExpressionNotAndCostCategoriesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterExpressionNotAndCostCategoriesProperty | undefined;
        set internalValue(value: FilterExpressionNotAndCostCategoriesProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterExpressionNotAndDimensionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#key AwsBudgetsBudget#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#match_options AwsBudgetsBudget#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#values AwsBudgetsBudget#values}
        */
        readonly values: string[];
    }
    class FilterExpressionNotAndDimensionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterExpressionNotAndDimensionsProperty | undefined;
        set internalValue(value: FilterExpressionNotAndDimensionsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    interface FilterExpressionNotAndTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#key AwsBudgetsBudget#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#match_options AwsBudgetsBudget#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#values AwsBudgetsBudget#values}
        */
        readonly values?: string[];
    }
    class FilterExpressionNotAndTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterExpressionNotAndTagsProperty | undefined;
        set internalValue(value: FilterExpressionNotAndTagsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterExpressionNotAndProperty {
        /**
        * cost_categories block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#cost_categories AwsBudgetsBudget#cost_categories}
        */
        readonly costCategories?: FilterExpressionNotAndCostCategoriesProperty;
        /**
        * dimensions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#dimensions AwsBudgetsBudget#dimensions}
        */
        readonly dimensions?: FilterExpressionNotAndDimensionsProperty;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#tags AwsBudgetsBudget#tags}
        */
        readonly tags?: FilterExpressionNotAndTagsProperty;
    }
    class FilterExpressionNotAndPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterExpressionNotAndProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilterExpressionNotAndProperty | cdktn.IResolvable | undefined);
        private _costCategories;
        get costCategories(): FilterExpressionNotAndCostCategoriesPropertyOutputReference;
        putCostCategories(value: FilterExpressionNotAndCostCategoriesProperty): void;
        resetCostCategories(): void;
        get costCategoriesInput(): FilterExpressionNotAndCostCategoriesProperty | undefined;
        private _dimensions;
        get dimensions(): FilterExpressionNotAndDimensionsPropertyOutputReference;
        putDimensions(value: FilterExpressionNotAndDimensionsProperty): void;
        resetDimensions(): void;
        get dimensionsInput(): FilterExpressionNotAndDimensionsProperty | undefined;
        private _tags;
        get tags(): FilterExpressionNotAndTagsPropertyOutputReference;
        putTags(value: FilterExpressionNotAndTagsProperty): void;
        resetTags(): void;
        get tagsInput(): FilterExpressionNotAndTagsProperty | undefined;
    }
    class FilterExpressionNotAndPropertyList extends cdktn.ComplexList {
        internalValue?: FilterExpressionNotAndProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterExpressionNotAndPropertyOutputReference;
    }
    interface FilterExpressionNotCostCategoriesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#key AwsBudgetsBudget#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#match_options AwsBudgetsBudget#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#values AwsBudgetsBudget#values}
        */
        readonly values?: string[];
    }
    class FilterExpressionNotCostCategoriesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterExpressionNotCostCategoriesProperty | undefined;
        set internalValue(value: FilterExpressionNotCostCategoriesProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterExpressionNotDimensionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#key AwsBudgetsBudget#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#match_options AwsBudgetsBudget#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#values AwsBudgetsBudget#values}
        */
        readonly values: string[];
    }
    class FilterExpressionNotDimensionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterExpressionNotDimensionsProperty | undefined;
        set internalValue(value: FilterExpressionNotDimensionsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    interface FilterExpressionNotNotCostCategoriesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#key AwsBudgetsBudget#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#match_options AwsBudgetsBudget#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#values AwsBudgetsBudget#values}
        */
        readonly values?: string[];
    }
    class FilterExpressionNotNotCostCategoriesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterExpressionNotNotCostCategoriesProperty | undefined;
        set internalValue(value: FilterExpressionNotNotCostCategoriesProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterExpressionNotNotDimensionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#key AwsBudgetsBudget#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#match_options AwsBudgetsBudget#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#values AwsBudgetsBudget#values}
        */
        readonly values: string[];
    }
    class FilterExpressionNotNotDimensionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterExpressionNotNotDimensionsProperty | undefined;
        set internalValue(value: FilterExpressionNotNotDimensionsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    interface FilterExpressionNotNotTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#key AwsBudgetsBudget#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#match_options AwsBudgetsBudget#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#values AwsBudgetsBudget#values}
        */
        readonly values?: string[];
    }
    class FilterExpressionNotNotTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterExpressionNotNotTagsProperty | undefined;
        set internalValue(value: FilterExpressionNotNotTagsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterExpressionNotNotProperty {
        /**
        * cost_categories block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#cost_categories AwsBudgetsBudget#cost_categories}
        */
        readonly costCategories?: FilterExpressionNotNotCostCategoriesProperty;
        /**
        * dimensions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#dimensions AwsBudgetsBudget#dimensions}
        */
        readonly dimensions?: FilterExpressionNotNotDimensionsProperty;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#tags AwsBudgetsBudget#tags}
        */
        readonly tags?: FilterExpressionNotNotTagsProperty;
    }
    class FilterExpressionNotNotPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterExpressionNotNotProperty | undefined;
        set internalValue(value: FilterExpressionNotNotProperty | undefined);
        private _costCategories;
        get costCategories(): FilterExpressionNotNotCostCategoriesPropertyOutputReference;
        putCostCategories(value: FilterExpressionNotNotCostCategoriesProperty): void;
        resetCostCategories(): void;
        get costCategoriesInput(): FilterExpressionNotNotCostCategoriesProperty | undefined;
        private _dimensions;
        get dimensions(): FilterExpressionNotNotDimensionsPropertyOutputReference;
        putDimensions(value: FilterExpressionNotNotDimensionsProperty): void;
        resetDimensions(): void;
        get dimensionsInput(): FilterExpressionNotNotDimensionsProperty | undefined;
        private _tags;
        get tags(): FilterExpressionNotNotTagsPropertyOutputReference;
        putTags(value: FilterExpressionNotNotTagsProperty): void;
        resetTags(): void;
        get tagsInput(): FilterExpressionNotNotTagsProperty | undefined;
    }
    interface FilterExpressionNotOrCostCategoriesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#key AwsBudgetsBudget#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#match_options AwsBudgetsBudget#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#values AwsBudgetsBudget#values}
        */
        readonly values?: string[];
    }
    class FilterExpressionNotOrCostCategoriesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterExpressionNotOrCostCategoriesProperty | undefined;
        set internalValue(value: FilterExpressionNotOrCostCategoriesProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterExpressionNotOrDimensionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#key AwsBudgetsBudget#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#match_options AwsBudgetsBudget#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#values AwsBudgetsBudget#values}
        */
        readonly values: string[];
    }
    class FilterExpressionNotOrDimensionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterExpressionNotOrDimensionsProperty | undefined;
        set internalValue(value: FilterExpressionNotOrDimensionsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    interface FilterExpressionNotOrTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#key AwsBudgetsBudget#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#match_options AwsBudgetsBudget#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#values AwsBudgetsBudget#values}
        */
        readonly values?: string[];
    }
    class FilterExpressionNotOrTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterExpressionNotOrTagsProperty | undefined;
        set internalValue(value: FilterExpressionNotOrTagsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterExpressionNotOrProperty {
        /**
        * cost_categories block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#cost_categories AwsBudgetsBudget#cost_categories}
        */
        readonly costCategories?: FilterExpressionNotOrCostCategoriesProperty;
        /**
        * dimensions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#dimensions AwsBudgetsBudget#dimensions}
        */
        readonly dimensions?: FilterExpressionNotOrDimensionsProperty;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#tags AwsBudgetsBudget#tags}
        */
        readonly tags?: FilterExpressionNotOrTagsProperty;
    }
    class FilterExpressionNotOrPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterExpressionNotOrProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilterExpressionNotOrProperty | cdktn.IResolvable | undefined);
        private _costCategories;
        get costCategories(): FilterExpressionNotOrCostCategoriesPropertyOutputReference;
        putCostCategories(value: FilterExpressionNotOrCostCategoriesProperty): void;
        resetCostCategories(): void;
        get costCategoriesInput(): FilterExpressionNotOrCostCategoriesProperty | undefined;
        private _dimensions;
        get dimensions(): FilterExpressionNotOrDimensionsPropertyOutputReference;
        putDimensions(value: FilterExpressionNotOrDimensionsProperty): void;
        resetDimensions(): void;
        get dimensionsInput(): FilterExpressionNotOrDimensionsProperty | undefined;
        private _tags;
        get tags(): FilterExpressionNotOrTagsPropertyOutputReference;
        putTags(value: FilterExpressionNotOrTagsProperty): void;
        resetTags(): void;
        get tagsInput(): FilterExpressionNotOrTagsProperty | undefined;
    }
    class FilterExpressionNotOrPropertyList extends cdktn.ComplexList {
        internalValue?: FilterExpressionNotOrProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterExpressionNotOrPropertyOutputReference;
    }
    interface FilterExpressionNotTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#key AwsBudgetsBudget#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#match_options AwsBudgetsBudget#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#values AwsBudgetsBudget#values}
        */
        readonly values?: string[];
    }
    class FilterExpressionNotTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterExpressionNotTagsProperty | undefined;
        set internalValue(value: FilterExpressionNotTagsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterExpressionNotProperty {
        /**
        * and block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#and AwsBudgetsBudget#and}
        */
        readonly and?: FilterExpressionNotAndProperty[] | cdktn.IResolvable;
        /**
        * cost_categories block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#cost_categories AwsBudgetsBudget#cost_categories}
        */
        readonly costCategories?: FilterExpressionNotCostCategoriesProperty;
        /**
        * dimensions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#dimensions AwsBudgetsBudget#dimensions}
        */
        readonly dimensions?: FilterExpressionNotDimensionsProperty;
        /**
        * not block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#not AwsBudgetsBudget#not}
        */
        readonly not?: FilterExpressionNotNotProperty;
        /**
        * or block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#or AwsBudgetsBudget#or}
        */
        readonly or?: FilterExpressionNotOrProperty[] | cdktn.IResolvable;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#tags AwsBudgetsBudget#tags}
        */
        readonly tags?: FilterExpressionNotTagsProperty;
    }
    class FilterExpressionNotPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterExpressionNotProperty | undefined;
        set internalValue(value: FilterExpressionNotProperty | undefined);
        private _and;
        get and(): FilterExpressionNotAndPropertyList;
        putAnd(value: FilterExpressionNotAndProperty[] | cdktn.IResolvable): void;
        resetAnd(): void;
        get andInput(): cdktn.IResolvable | FilterExpressionNotAndProperty[] | undefined;
        private _costCategories;
        get costCategories(): FilterExpressionNotCostCategoriesPropertyOutputReference;
        putCostCategories(value: FilterExpressionNotCostCategoriesProperty): void;
        resetCostCategories(): void;
        get costCategoriesInput(): FilterExpressionNotCostCategoriesProperty | undefined;
        private _dimensions;
        get dimensions(): FilterExpressionNotDimensionsPropertyOutputReference;
        putDimensions(value: FilterExpressionNotDimensionsProperty): void;
        resetDimensions(): void;
        get dimensionsInput(): FilterExpressionNotDimensionsProperty | undefined;
        private _not;
        get not(): FilterExpressionNotNotPropertyOutputReference;
        putNot(value: FilterExpressionNotNotProperty): void;
        resetNot(): void;
        get notInput(): FilterExpressionNotNotProperty | undefined;
        private _or;
        get or(): FilterExpressionNotOrPropertyList;
        putOr(value: FilterExpressionNotOrProperty[] | cdktn.IResolvable): void;
        resetOr(): void;
        get orInput(): cdktn.IResolvable | FilterExpressionNotOrProperty[] | undefined;
        private _tags;
        get tags(): FilterExpressionNotTagsPropertyOutputReference;
        putTags(value: FilterExpressionNotTagsProperty): void;
        resetTags(): void;
        get tagsInput(): FilterExpressionNotTagsProperty | undefined;
    }
    interface FilterExpressionOrAndCostCategoriesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#key AwsBudgetsBudget#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#match_options AwsBudgetsBudget#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#values AwsBudgetsBudget#values}
        */
        readonly values?: string[];
    }
    class FilterExpressionOrAndCostCategoriesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterExpressionOrAndCostCategoriesProperty | undefined;
        set internalValue(value: FilterExpressionOrAndCostCategoriesProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterExpressionOrAndDimensionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#key AwsBudgetsBudget#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#match_options AwsBudgetsBudget#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#values AwsBudgetsBudget#values}
        */
        readonly values: string[];
    }
    class FilterExpressionOrAndDimensionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterExpressionOrAndDimensionsProperty | undefined;
        set internalValue(value: FilterExpressionOrAndDimensionsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    interface FilterExpressionOrAndTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#key AwsBudgetsBudget#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#match_options AwsBudgetsBudget#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#values AwsBudgetsBudget#values}
        */
        readonly values?: string[];
    }
    class FilterExpressionOrAndTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterExpressionOrAndTagsProperty | undefined;
        set internalValue(value: FilterExpressionOrAndTagsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterExpressionOrAndProperty {
        /**
        * cost_categories block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#cost_categories AwsBudgetsBudget#cost_categories}
        */
        readonly costCategories?: FilterExpressionOrAndCostCategoriesProperty;
        /**
        * dimensions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#dimensions AwsBudgetsBudget#dimensions}
        */
        readonly dimensions?: FilterExpressionOrAndDimensionsProperty;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#tags AwsBudgetsBudget#tags}
        */
        readonly tags?: FilterExpressionOrAndTagsProperty;
    }
    class FilterExpressionOrAndPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterExpressionOrAndProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilterExpressionOrAndProperty | cdktn.IResolvable | undefined);
        private _costCategories;
        get costCategories(): FilterExpressionOrAndCostCategoriesPropertyOutputReference;
        putCostCategories(value: FilterExpressionOrAndCostCategoriesProperty): void;
        resetCostCategories(): void;
        get costCategoriesInput(): FilterExpressionOrAndCostCategoriesProperty | undefined;
        private _dimensions;
        get dimensions(): FilterExpressionOrAndDimensionsPropertyOutputReference;
        putDimensions(value: FilterExpressionOrAndDimensionsProperty): void;
        resetDimensions(): void;
        get dimensionsInput(): FilterExpressionOrAndDimensionsProperty | undefined;
        private _tags;
        get tags(): FilterExpressionOrAndTagsPropertyOutputReference;
        putTags(value: FilterExpressionOrAndTagsProperty): void;
        resetTags(): void;
        get tagsInput(): FilterExpressionOrAndTagsProperty | undefined;
    }
    class FilterExpressionOrAndPropertyList extends cdktn.ComplexList {
        internalValue?: FilterExpressionOrAndProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterExpressionOrAndPropertyOutputReference;
    }
    interface FilterExpressionOrCostCategoriesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#key AwsBudgetsBudget#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#match_options AwsBudgetsBudget#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#values AwsBudgetsBudget#values}
        */
        readonly values?: string[];
    }
    class FilterExpressionOrCostCategoriesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterExpressionOrCostCategoriesProperty | undefined;
        set internalValue(value: FilterExpressionOrCostCategoriesProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterExpressionOrDimensionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#key AwsBudgetsBudget#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#match_options AwsBudgetsBudget#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#values AwsBudgetsBudget#values}
        */
        readonly values: string[];
    }
    class FilterExpressionOrDimensionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterExpressionOrDimensionsProperty | undefined;
        set internalValue(value: FilterExpressionOrDimensionsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    interface FilterExpressionOrNotCostCategoriesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#key AwsBudgetsBudget#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#match_options AwsBudgetsBudget#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#values AwsBudgetsBudget#values}
        */
        readonly values?: string[];
    }
    class FilterExpressionOrNotCostCategoriesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterExpressionOrNotCostCategoriesProperty | undefined;
        set internalValue(value: FilterExpressionOrNotCostCategoriesProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterExpressionOrNotDimensionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#key AwsBudgetsBudget#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#match_options AwsBudgetsBudget#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#values AwsBudgetsBudget#values}
        */
        readonly values: string[];
    }
    class FilterExpressionOrNotDimensionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterExpressionOrNotDimensionsProperty | undefined;
        set internalValue(value: FilterExpressionOrNotDimensionsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    interface FilterExpressionOrNotTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#key AwsBudgetsBudget#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#match_options AwsBudgetsBudget#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#values AwsBudgetsBudget#values}
        */
        readonly values?: string[];
    }
    class FilterExpressionOrNotTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterExpressionOrNotTagsProperty | undefined;
        set internalValue(value: FilterExpressionOrNotTagsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterExpressionOrNotProperty {
        /**
        * cost_categories block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#cost_categories AwsBudgetsBudget#cost_categories}
        */
        readonly costCategories?: FilterExpressionOrNotCostCategoriesProperty;
        /**
        * dimensions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#dimensions AwsBudgetsBudget#dimensions}
        */
        readonly dimensions?: FilterExpressionOrNotDimensionsProperty;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#tags AwsBudgetsBudget#tags}
        */
        readonly tags?: FilterExpressionOrNotTagsProperty;
    }
    class FilterExpressionOrNotPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterExpressionOrNotProperty | undefined;
        set internalValue(value: FilterExpressionOrNotProperty | undefined);
        private _costCategories;
        get costCategories(): FilterExpressionOrNotCostCategoriesPropertyOutputReference;
        putCostCategories(value: FilterExpressionOrNotCostCategoriesProperty): void;
        resetCostCategories(): void;
        get costCategoriesInput(): FilterExpressionOrNotCostCategoriesProperty | undefined;
        private _dimensions;
        get dimensions(): FilterExpressionOrNotDimensionsPropertyOutputReference;
        putDimensions(value: FilterExpressionOrNotDimensionsProperty): void;
        resetDimensions(): void;
        get dimensionsInput(): FilterExpressionOrNotDimensionsProperty | undefined;
        private _tags;
        get tags(): FilterExpressionOrNotTagsPropertyOutputReference;
        putTags(value: FilterExpressionOrNotTagsProperty): void;
        resetTags(): void;
        get tagsInput(): FilterExpressionOrNotTagsProperty | undefined;
    }
    interface FilterExpressionOrOrCostCategoriesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#key AwsBudgetsBudget#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#match_options AwsBudgetsBudget#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#values AwsBudgetsBudget#values}
        */
        readonly values?: string[];
    }
    class FilterExpressionOrOrCostCategoriesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterExpressionOrOrCostCategoriesProperty | undefined;
        set internalValue(value: FilterExpressionOrOrCostCategoriesProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterExpressionOrOrDimensionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#key AwsBudgetsBudget#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#match_options AwsBudgetsBudget#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#values AwsBudgetsBudget#values}
        */
        readonly values: string[];
    }
    class FilterExpressionOrOrDimensionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterExpressionOrOrDimensionsProperty | undefined;
        set internalValue(value: FilterExpressionOrOrDimensionsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    interface FilterExpressionOrOrTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#key AwsBudgetsBudget#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#match_options AwsBudgetsBudget#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#values AwsBudgetsBudget#values}
        */
        readonly values?: string[];
    }
    class FilterExpressionOrOrTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterExpressionOrOrTagsProperty | undefined;
        set internalValue(value: FilterExpressionOrOrTagsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterExpressionOrOrProperty {
        /**
        * cost_categories block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#cost_categories AwsBudgetsBudget#cost_categories}
        */
        readonly costCategories?: FilterExpressionOrOrCostCategoriesProperty;
        /**
        * dimensions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#dimensions AwsBudgetsBudget#dimensions}
        */
        readonly dimensions?: FilterExpressionOrOrDimensionsProperty;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#tags AwsBudgetsBudget#tags}
        */
        readonly tags?: FilterExpressionOrOrTagsProperty;
    }
    class FilterExpressionOrOrPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterExpressionOrOrProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilterExpressionOrOrProperty | cdktn.IResolvable | undefined);
        private _costCategories;
        get costCategories(): FilterExpressionOrOrCostCategoriesPropertyOutputReference;
        putCostCategories(value: FilterExpressionOrOrCostCategoriesProperty): void;
        resetCostCategories(): void;
        get costCategoriesInput(): FilterExpressionOrOrCostCategoriesProperty | undefined;
        private _dimensions;
        get dimensions(): FilterExpressionOrOrDimensionsPropertyOutputReference;
        putDimensions(value: FilterExpressionOrOrDimensionsProperty): void;
        resetDimensions(): void;
        get dimensionsInput(): FilterExpressionOrOrDimensionsProperty | undefined;
        private _tags;
        get tags(): FilterExpressionOrOrTagsPropertyOutputReference;
        putTags(value: FilterExpressionOrOrTagsProperty): void;
        resetTags(): void;
        get tagsInput(): FilterExpressionOrOrTagsProperty | undefined;
    }
    class FilterExpressionOrOrPropertyList extends cdktn.ComplexList {
        internalValue?: FilterExpressionOrOrProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterExpressionOrOrPropertyOutputReference;
    }
    interface FilterExpressionOrTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#key AwsBudgetsBudget#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#match_options AwsBudgetsBudget#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#values AwsBudgetsBudget#values}
        */
        readonly values?: string[];
    }
    class FilterExpressionOrTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterExpressionOrTagsProperty | undefined;
        set internalValue(value: FilterExpressionOrTagsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterExpressionOrProperty {
        /**
        * and block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#and AwsBudgetsBudget#and}
        */
        readonly and?: FilterExpressionOrAndProperty[] | cdktn.IResolvable;
        /**
        * cost_categories block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#cost_categories AwsBudgetsBudget#cost_categories}
        */
        readonly costCategories?: FilterExpressionOrCostCategoriesProperty;
        /**
        * dimensions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#dimensions AwsBudgetsBudget#dimensions}
        */
        readonly dimensions?: FilterExpressionOrDimensionsProperty;
        /**
        * not block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#not AwsBudgetsBudget#not}
        */
        readonly not?: FilterExpressionOrNotProperty;
        /**
        * or block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#or AwsBudgetsBudget#or}
        */
        readonly or?: FilterExpressionOrOrProperty[] | cdktn.IResolvable;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#tags AwsBudgetsBudget#tags}
        */
        readonly tags?: FilterExpressionOrTagsProperty;
    }
    class FilterExpressionOrPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FilterExpressionOrProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FilterExpressionOrProperty | cdktn.IResolvable | undefined);
        private _and;
        get and(): FilterExpressionOrAndPropertyList;
        putAnd(value: FilterExpressionOrAndProperty[] | cdktn.IResolvable): void;
        resetAnd(): void;
        get andInput(): cdktn.IResolvable | FilterExpressionOrAndProperty[] | undefined;
        private _costCategories;
        get costCategories(): FilterExpressionOrCostCategoriesPropertyOutputReference;
        putCostCategories(value: FilterExpressionOrCostCategoriesProperty): void;
        resetCostCategories(): void;
        get costCategoriesInput(): FilterExpressionOrCostCategoriesProperty | undefined;
        private _dimensions;
        get dimensions(): FilterExpressionOrDimensionsPropertyOutputReference;
        putDimensions(value: FilterExpressionOrDimensionsProperty): void;
        resetDimensions(): void;
        get dimensionsInput(): FilterExpressionOrDimensionsProperty | undefined;
        private _not;
        get not(): FilterExpressionOrNotPropertyOutputReference;
        putNot(value: FilterExpressionOrNotProperty): void;
        resetNot(): void;
        get notInput(): FilterExpressionOrNotProperty | undefined;
        private _or;
        get or(): FilterExpressionOrOrPropertyList;
        putOr(value: FilterExpressionOrOrProperty[] | cdktn.IResolvable): void;
        resetOr(): void;
        get orInput(): cdktn.IResolvable | FilterExpressionOrOrProperty[] | undefined;
        private _tags;
        get tags(): FilterExpressionOrTagsPropertyOutputReference;
        putTags(value: FilterExpressionOrTagsProperty): void;
        resetTags(): void;
        get tagsInput(): FilterExpressionOrTagsProperty | undefined;
    }
    class FilterExpressionOrPropertyList extends cdktn.ComplexList {
        internalValue?: FilterExpressionOrProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FilterExpressionOrPropertyOutputReference;
    }
    interface FilterExpressionTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#key AwsBudgetsBudget#key}
        */
        readonly key?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#match_options AwsBudgetsBudget#match_options}
        */
        readonly matchOptions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#values AwsBudgetsBudget#values}
        */
        readonly values?: string[];
    }
    class FilterExpressionTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterExpressionTagsProperty | undefined;
        set internalValue(value: FilterExpressionTagsProperty | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        resetKey(): void;
        get keyInput(): string | undefined;
        private _matchOptions?;
        get matchOptions(): string[];
        set matchOptions(value: string[]);
        resetMatchOptions(): void;
        get matchOptionsInput(): string[] | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    interface FilterExpressionProperty {
        /**
        * and block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#and AwsBudgetsBudget#and}
        */
        readonly and?: FilterExpressionAndProperty[] | cdktn.IResolvable;
        /**
        * cost_categories block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#cost_categories AwsBudgetsBudget#cost_categories}
        */
        readonly costCategories?: FilterExpressionCostCategoriesProperty;
        /**
        * dimensions block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#dimensions AwsBudgetsBudget#dimensions}
        */
        readonly dimensions?: FilterExpressionDimensionsProperty;
        /**
        * not block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#not AwsBudgetsBudget#not}
        */
        readonly not?: FilterExpressionNotProperty;
        /**
        * or block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#or AwsBudgetsBudget#or}
        */
        readonly or?: FilterExpressionOrProperty[] | cdktn.IResolvable;
        /**
        * tags block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#tags AwsBudgetsBudget#tags}
        */
        readonly tags?: FilterExpressionTagsProperty;
    }
    class FilterExpressionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FilterExpressionProperty | undefined;
        set internalValue(value: FilterExpressionProperty | undefined);
        private _and;
        get and(): FilterExpressionAndPropertyList;
        putAnd(value: FilterExpressionAndProperty[] | cdktn.IResolvable): void;
        resetAnd(): void;
        get andInput(): cdktn.IResolvable | FilterExpressionAndProperty[] | undefined;
        private _costCategories;
        get costCategories(): FilterExpressionCostCategoriesPropertyOutputReference;
        putCostCategories(value: FilterExpressionCostCategoriesProperty): void;
        resetCostCategories(): void;
        get costCategoriesInput(): FilterExpressionCostCategoriesProperty | undefined;
        private _dimensions;
        get dimensions(): FilterExpressionDimensionsPropertyOutputReference;
        putDimensions(value: FilterExpressionDimensionsProperty): void;
        resetDimensions(): void;
        get dimensionsInput(): FilterExpressionDimensionsProperty | undefined;
        private _not;
        get not(): FilterExpressionNotPropertyOutputReference;
        putNot(value: FilterExpressionNotProperty): void;
        resetNot(): void;
        get notInput(): FilterExpressionNotProperty | undefined;
        private _or;
        get or(): FilterExpressionOrPropertyList;
        putOr(value: FilterExpressionOrProperty[] | cdktn.IResolvable): void;
        resetOr(): void;
        get orInput(): cdktn.IResolvable | FilterExpressionOrProperty[] | undefined;
        private _tags;
        get tags(): FilterExpressionTagsPropertyOutputReference;
        putTags(value: FilterExpressionTagsProperty): void;
        resetTags(): void;
        get tagsInput(): FilterExpressionTagsProperty | undefined;
    }
    interface NotificationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#comparison_operator AwsBudgetsBudget#comparison_operator}
        */
        readonly comparisonOperator: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#notification_type AwsBudgetsBudget#notification_type}
        */
        readonly notificationType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#subscriber_email_addresses AwsBudgetsBudget#subscriber_email_addresses}
        */
        readonly subscriberEmailAddresses?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#subscriber_sns_topic_arns AwsBudgetsBudget#subscriber_sns_topic_arns}
        */
        readonly subscriberSnsTopicArns?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#threshold AwsBudgetsBudget#threshold}
        */
        readonly threshold: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#threshold_type AwsBudgetsBudget#threshold_type}
        */
        readonly thresholdType: string;
    }
    class NotificationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): NotificationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: NotificationProperty | cdktn.IResolvable | undefined);
        private _comparisonOperator?;
        get comparisonOperator(): string;
        set comparisonOperator(value: string);
        get comparisonOperatorInput(): string | undefined;
        private _notificationType?;
        get notificationType(): string;
        set notificationType(value: string);
        get notificationTypeInput(): string | undefined;
        private _subscriberEmailAddresses?;
        get subscriberEmailAddresses(): string[];
        set subscriberEmailAddresses(value: string[]);
        resetSubscriberEmailAddresses(): void;
        get subscriberEmailAddressesInput(): string[] | undefined;
        private _subscriberSnsTopicArns?;
        get subscriberSnsTopicArns(): string[];
        set subscriberSnsTopicArns(value: string[]);
        resetSubscriberSnsTopicArns(): void;
        get subscriberSnsTopicArnsInput(): string[] | undefined;
        private _threshold?;
        get threshold(): number;
        set threshold(value: number);
        get thresholdInput(): number | undefined;
        private _thresholdType?;
        get thresholdType(): string;
        set thresholdType(value: string);
        get thresholdTypeInput(): string | undefined;
    }
    class NotificationPropertyList extends cdktn.ComplexList {
        internalValue?: NotificationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): NotificationPropertyOutputReference;
    }
    interface PlannedLimitProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#amount AwsBudgetsBudget#amount}
        */
        readonly amount: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#start_time AwsBudgetsBudget#start_time}
        */
        readonly startTime: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/budgets_budget#unit AwsBudgetsBudget#unit}
        */
        readonly unit: string;
    }
    class PlannedLimitPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PlannedLimitProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PlannedLimitProperty | cdktn.IResolvable | undefined);
        private _amount?;
        get amount(): string;
        set amount(value: string);
        get amountInput(): string | undefined;
        private _startTime?;
        get startTime(): string;
        set startTime(value: string);
        get startTimeInput(): string | undefined;
        private _unit?;
        get unit(): string;
        set unit(value: string);
        get unitInput(): string | undefined;
    }
    class PlannedLimitPropertyList extends cdktn.ComplexList {
        internalValue?: PlannedLimitProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PlannedLimitPropertyOutputReference;
    }
}
