import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsBackupPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_backup_policy#file_system_id AwsBackupPolicy#file_system_id}
    */
    readonly fileSystemId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_backup_policy#id AwsBackupPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_backup_policy#region AwsBackupPolicy#region}
    */
    readonly region?: string;
    /**
    * backup_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_backup_policy#backup_policy AwsBackupPolicy#backup_policy}
    */
    readonly backupPolicy: AwsBackupPolicy.BackupPolicyProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_backup_policy aws_efs_backup_policy}
*/
export declare class AwsBackupPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_efs_backup_policy";
    /**
    * Generates CDKTN code for importing a AwsBackupPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsBackupPolicy to import
    * @param importFromId The id of the existing AwsBackupPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_backup_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsBackupPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_backup_policy aws_efs_backup_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsBackupPolicyConfig
    */
    constructor(scope: Construct, id: string, config: AwsBackupPolicyConfig);
    private _fileSystemId?;
    get fileSystemId(): string;
    set fileSystemId(value: string);
    get fileSystemIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _backupPolicy;
    get backupPolicy(): AwsBackupPolicy.BackupPolicyPropertyOutputReference;
    putBackupPolicy(value: AwsBackupPolicy.BackupPolicyProperty): void;
    get backupPolicyInput(): AwsBackupPolicy.BackupPolicyProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsBackupPolicyBackupPolicyPropertyToTerraform(struct?: AwsBackupPolicy.BackupPolicyPropertyOutputReference | AwsBackupPolicy.BackupPolicyProperty): any;
export declare function awsBackupPolicyBackupPolicyPropertyToHclTerraform(struct?: AwsBackupPolicy.BackupPolicyPropertyOutputReference | AwsBackupPolicy.BackupPolicyProperty): any;
export declare namespace AwsBackupPolicy {
    interface BackupPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_backup_policy#status AwsBackupPolicy#status}
        */
        readonly status: string;
    }
    class BackupPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BackupPolicyProperty | undefined;
        set internalValue(value: BackupPolicyProperty | undefined);
        private _status?;
        get status(): string;
        set status(value: string);
        get statusInput(): string | undefined;
    }
}
