import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAccessPointConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_access_point#file_system_id AwsAccessPoint#file_system_id}
    */
    readonly fileSystemId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_access_point#id AwsAccessPoint#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_access_point#region AwsAccessPoint#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_access_point#tags AwsAccessPoint#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_access_point#tags_all AwsAccessPoint#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * posix_user block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_access_point#posix_user AwsAccessPoint#posix_user}
    */
    readonly posixUser?: AwsAccessPoint.PosixUserProperty;
    /**
    * root_directory block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_access_point#root_directory AwsAccessPoint#root_directory}
    */
    readonly rootDirectory?: AwsAccessPoint.RootDirectoryProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_access_point aws_efs_access_point}
*/
export declare class AwsAccessPoint extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_efs_access_point";
    /**
    * Generates CDKTN code for importing a AwsAccessPoint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAccessPoint to import
    * @param importFromId The id of the existing AwsAccessPoint that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_access_point#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAccessPoint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_access_point aws_efs_access_point} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAccessPointConfig
    */
    constructor(scope: Construct, id: string, config: AwsAccessPointConfig);
    get arn(): string;
    get fileSystemArn(): string;
    private _fileSystemId?;
    get fileSystemId(): string;
    set fileSystemId(value: string);
    get fileSystemIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ownerId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _posixUser;
    get posixUser(): AwsAccessPoint.PosixUserPropertyOutputReference;
    putPosixUser(value: AwsAccessPoint.PosixUserProperty): void;
    resetPosixUser(): void;
    get posixUserInput(): AwsAccessPoint.PosixUserProperty | undefined;
    private _rootDirectory;
    get rootDirectory(): AwsAccessPoint.RootDirectoryPropertyOutputReference;
    putRootDirectory(value: AwsAccessPoint.RootDirectoryProperty): void;
    resetRootDirectory(): void;
    get rootDirectoryInput(): AwsAccessPoint.RootDirectoryProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsAccessPointPosixUserPropertyToTerraform(struct?: AwsAccessPoint.PosixUserPropertyOutputReference | AwsAccessPoint.PosixUserProperty): any;
export declare function awsAccessPointPosixUserPropertyToHclTerraform(struct?: AwsAccessPoint.PosixUserPropertyOutputReference | AwsAccessPoint.PosixUserProperty): any;
export declare function awsAccessPointCreationInfoPropertyToTerraform(struct?: AwsAccessPoint.CreationInfoPropertyOutputReference | AwsAccessPoint.CreationInfoProperty): any;
export declare function awsAccessPointCreationInfoPropertyToHclTerraform(struct?: AwsAccessPoint.CreationInfoPropertyOutputReference | AwsAccessPoint.CreationInfoProperty): any;
export declare function awsAccessPointRootDirectoryPropertyToTerraform(struct?: AwsAccessPoint.RootDirectoryPropertyOutputReference | AwsAccessPoint.RootDirectoryProperty): any;
export declare function awsAccessPointRootDirectoryPropertyToHclTerraform(struct?: AwsAccessPoint.RootDirectoryPropertyOutputReference | AwsAccessPoint.RootDirectoryProperty): any;
export declare namespace AwsAccessPoint {
    interface PosixUserProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_access_point#gid AwsAccessPoint#gid}
        */
        readonly gid: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_access_point#secondary_gids AwsAccessPoint#secondary_gids}
        */
        readonly secondaryGids?: number[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_access_point#uid AwsAccessPoint#uid}
        */
        readonly uid: number;
    }
    class PosixUserPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PosixUserProperty | undefined;
        set internalValue(value: PosixUserProperty | undefined);
        private _gid?;
        get gid(): number;
        set gid(value: number);
        get gidInput(): number | undefined;
        private _secondaryGids?;
        get secondaryGids(): number[];
        set secondaryGids(value: number[]);
        resetSecondaryGids(): void;
        get secondaryGidsInput(): number[] | undefined;
        private _uid?;
        get uid(): number;
        set uid(value: number);
        get uidInput(): number | undefined;
    }
    interface CreationInfoProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_access_point#owner_gid AwsAccessPoint#owner_gid}
        */
        readonly ownerGid: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_access_point#owner_uid AwsAccessPoint#owner_uid}
        */
        readonly ownerUid: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_access_point#permissions AwsAccessPoint#permissions}
        */
        readonly permissions: string;
    }
    class CreationInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CreationInfoProperty | undefined;
        set internalValue(value: CreationInfoProperty | undefined);
        private _ownerGid?;
        get ownerGid(): number;
        set ownerGid(value: number);
        get ownerGidInput(): number | undefined;
        private _ownerUid?;
        get ownerUid(): number;
        set ownerUid(value: number);
        get ownerUidInput(): number | undefined;
        private _permissions?;
        get permissions(): string;
        set permissions(value: string);
        get permissionsInput(): string | undefined;
    }
    interface RootDirectoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_access_point#path AwsAccessPoint#path}
        */
        readonly path?: string;
        /**
        * creation_info block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_access_point#creation_info AwsAccessPoint#creation_info}
        */
        readonly creationInfo?: CreationInfoProperty;
    }
    class RootDirectoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RootDirectoryProperty | undefined;
        set internalValue(value: RootDirectoryProperty | undefined);
        private _path?;
        get path(): string;
        set path(value: string);
        resetPath(): void;
        get pathInput(): string | undefined;
        private _creationInfo;
        get creationInfo(): CreationInfoPropertyOutputReference;
        putCreationInfo(value: CreationInfoProperty): void;
        resetCreationInfo(): void;
        get creationInfoInput(): CreationInfoProperty | undefined;
    }
}
