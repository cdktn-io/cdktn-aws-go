import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsPaymentcryptographyKeyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/paymentcryptography_key#deletion_window_in_days AwsPaymentcryptographyKey#deletion_window_in_days}
    */
    readonly deletionWindowInDays?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/paymentcryptography_key#enabled AwsPaymentcryptographyKey#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/paymentcryptography_key#exportable AwsPaymentcryptographyKey#exportable}
    */
    readonly exportable: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/paymentcryptography_key#key_check_value_algorithm AwsPaymentcryptographyKey#key_check_value_algorithm}
    */
    readonly keyCheckValueAlgorithm?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/paymentcryptography_key#region AwsPaymentcryptographyKey#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/paymentcryptography_key#tags AwsPaymentcryptographyKey#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * key_attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/paymentcryptography_key#key_attributes AwsPaymentcryptographyKey#key_attributes}
    */
    readonly keyAttributes?: AwsPaymentcryptographyKey.KeyAttributesProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/paymentcryptography_key#timeouts AwsPaymentcryptographyKey#timeouts}
    */
    readonly timeouts?: AwsPaymentcryptographyKey.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/paymentcryptography_key aws_paymentcryptography_key}
*/
export declare class AwsPaymentcryptographyKey extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_paymentcryptography_key";
    /**
    * Generates CDKTN code for importing a AwsPaymentcryptographyKey resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsPaymentcryptographyKey to import
    * @param importFromId The id of the existing AwsPaymentcryptographyKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/paymentcryptography_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsPaymentcryptographyKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/paymentcryptography_key aws_paymentcryptography_key} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsPaymentcryptographyKeyConfig
    */
    constructor(scope: Construct, id: string, config: AwsPaymentcryptographyKeyConfig);
    get arn(): string;
    private _deletionWindowInDays?;
    get deletionWindowInDays(): number;
    set deletionWindowInDays(value: number);
    resetDeletionWindowInDays(): void;
    get deletionWindowInDaysInput(): number | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _exportable?;
    get exportable(): boolean | cdktn.IResolvable;
    set exportable(value: boolean | cdktn.IResolvable);
    get exportableInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    get keyCheckValue(): string;
    private _keyCheckValueAlgorithm?;
    get keyCheckValueAlgorithm(): string;
    set keyCheckValueAlgorithm(value: string);
    resetKeyCheckValueAlgorithm(): void;
    get keyCheckValueAlgorithmInput(): string | undefined;
    get keyOrigin(): string;
    get keyState(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _keyAttributes;
    get keyAttributes(): AwsPaymentcryptographyKey.KeyAttributesPropertyList;
    putKeyAttributes(value: AwsPaymentcryptographyKey.KeyAttributesProperty[] | cdktn.IResolvable): void;
    resetKeyAttributes(): void;
    get keyAttributesInput(): cdktn.IResolvable | AwsPaymentcryptographyKey.KeyAttributesProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsPaymentcryptographyKey.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsPaymentcryptographyKey.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsPaymentcryptographyKey.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsPaymentcryptographyKeyKeyModesOfUsePropertyToTerraform(struct?: AwsPaymentcryptographyKey.KeyModesOfUseProperty | cdktn.IResolvable): any;
export declare function awsPaymentcryptographyKeyKeyModesOfUsePropertyToHclTerraform(struct?: AwsPaymentcryptographyKey.KeyModesOfUseProperty | cdktn.IResolvable): any;
export declare function awsPaymentcryptographyKeyKeyAttributesPropertyToTerraform(struct?: AwsPaymentcryptographyKey.KeyAttributesProperty | cdktn.IResolvable): any;
export declare function awsPaymentcryptographyKeyKeyAttributesPropertyToHclTerraform(struct?: AwsPaymentcryptographyKey.KeyAttributesProperty | cdktn.IResolvable): any;
export declare function awsPaymentcryptographyKeyTimeoutsPropertyToTerraform(struct?: AwsPaymentcryptographyKey.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsPaymentcryptographyKeyTimeoutsPropertyToHclTerraform(struct?: AwsPaymentcryptographyKey.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsPaymentcryptographyKey {
    interface KeyModesOfUseProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/paymentcryptography_key#decrypt AwsPaymentcryptographyKey#decrypt}
        */
        readonly decrypt?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/paymentcryptography_key#derive_key AwsPaymentcryptographyKey#derive_key}
        */
        readonly deriveKey?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/paymentcryptography_key#encrypt AwsPaymentcryptographyKey#encrypt}
        */
        readonly encrypt?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/paymentcryptography_key#generate AwsPaymentcryptographyKey#generate}
        */
        readonly generate?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/paymentcryptography_key#no_restrictions AwsPaymentcryptographyKey#no_restrictions}
        */
        readonly noRestrictions?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/paymentcryptography_key#sign AwsPaymentcryptographyKey#sign}
        */
        readonly sign?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/paymentcryptography_key#unwrap AwsPaymentcryptographyKey#unwrap}
        */
        readonly unwrap?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/paymentcryptography_key#verify AwsPaymentcryptographyKey#verify}
        */
        readonly verify?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/paymentcryptography_key#wrap AwsPaymentcryptographyKey#wrap}
        */
        readonly wrap?: boolean | cdktn.IResolvable;
    }
    class KeyModesOfUsePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KeyModesOfUseProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KeyModesOfUseProperty | cdktn.IResolvable | undefined);
        private _decrypt?;
        get decrypt(): boolean | cdktn.IResolvable;
        set decrypt(value: boolean | cdktn.IResolvable);
        resetDecrypt(): void;
        get decryptInput(): boolean | cdktn.IResolvable | undefined;
        private _deriveKey?;
        get deriveKey(): boolean | cdktn.IResolvable;
        set deriveKey(value: boolean | cdktn.IResolvable);
        resetDeriveKey(): void;
        get deriveKeyInput(): boolean | cdktn.IResolvable | undefined;
        private _encrypt?;
        get encrypt(): boolean | cdktn.IResolvable;
        set encrypt(value: boolean | cdktn.IResolvable);
        resetEncrypt(): void;
        get encryptInput(): boolean | cdktn.IResolvable | undefined;
        private _generate?;
        get generate(): boolean | cdktn.IResolvable;
        set generate(value: boolean | cdktn.IResolvable);
        resetGenerate(): void;
        get generateInput(): boolean | cdktn.IResolvable | undefined;
        private _noRestrictions?;
        get noRestrictions(): boolean | cdktn.IResolvable;
        set noRestrictions(value: boolean | cdktn.IResolvable);
        resetNoRestrictions(): void;
        get noRestrictionsInput(): boolean | cdktn.IResolvable | undefined;
        private _sign?;
        get sign(): boolean | cdktn.IResolvable;
        set sign(value: boolean | cdktn.IResolvable);
        resetSign(): void;
        get signInput(): boolean | cdktn.IResolvable | undefined;
        private _unwrap?;
        get unwrap(): boolean | cdktn.IResolvable;
        set unwrap(value: boolean | cdktn.IResolvable);
        resetUnwrap(): void;
        get unwrapInput(): boolean | cdktn.IResolvable | undefined;
        private _verify?;
        get verify(): boolean | cdktn.IResolvable;
        set verify(value: boolean | cdktn.IResolvable);
        resetVerify(): void;
        get verifyInput(): boolean | cdktn.IResolvable | undefined;
        private _wrap?;
        get wrap(): boolean | cdktn.IResolvable;
        set wrap(value: boolean | cdktn.IResolvable);
        resetWrap(): void;
        get wrapInput(): boolean | cdktn.IResolvable | undefined;
    }
    class KeyModesOfUsePropertyList extends cdktn.ComplexList {
        internalValue?: KeyModesOfUseProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KeyModesOfUsePropertyOutputReference;
    }
    interface KeyAttributesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/paymentcryptography_key#key_algorithm AwsPaymentcryptographyKey#key_algorithm}
        */
        readonly keyAlgorithm: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/paymentcryptography_key#key_class AwsPaymentcryptographyKey#key_class}
        */
        readonly keyClass: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/paymentcryptography_key#key_usage AwsPaymentcryptographyKey#key_usage}
        */
        readonly keyUsage: string;
        /**
        * key_modes_of_use block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/paymentcryptography_key#key_modes_of_use AwsPaymentcryptographyKey#key_modes_of_use}
        */
        readonly keyModesOfUse?: KeyModesOfUseProperty[] | cdktn.IResolvable;
    }
    class KeyAttributesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KeyAttributesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KeyAttributesProperty | cdktn.IResolvable | undefined);
        private _keyAlgorithm?;
        get keyAlgorithm(): string;
        set keyAlgorithm(value: string);
        get keyAlgorithmInput(): string | undefined;
        private _keyClass?;
        get keyClass(): string;
        set keyClass(value: string);
        get keyClassInput(): string | undefined;
        private _keyUsage?;
        get keyUsage(): string;
        set keyUsage(value: string);
        get keyUsageInput(): string | undefined;
        private _keyModesOfUse;
        get keyModesOfUse(): KeyModesOfUsePropertyList;
        putKeyModesOfUse(value: KeyModesOfUseProperty[] | cdktn.IResolvable): void;
        resetKeyModesOfUse(): void;
        get keyModesOfUseInput(): cdktn.IResolvable | KeyModesOfUseProperty[] | undefined;
    }
    class KeyAttributesPropertyList extends cdktn.ComplexList {
        internalValue?: KeyAttributesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KeyAttributesPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/paymentcryptography_key#create AwsPaymentcryptographyKey#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/paymentcryptography_key#delete AwsPaymentcryptographyKey#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/paymentcryptography_key#update AwsPaymentcryptographyKey#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
