import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfFastSnapshotRestoreConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ebs_fast_snapshot_restore#availability_zone TfFastSnapshotRestore#availability_zone}
    */
    readonly availabilityZone: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ebs_fast_snapshot_restore#region TfFastSnapshotRestore#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ebs_fast_snapshot_restore#snapshot_id TfFastSnapshotRestore#snapshot_id}
    */
    readonly snapshotId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ebs_fast_snapshot_restore#timeouts TfFastSnapshotRestore#timeouts}
    */
    readonly timeouts?: TfFastSnapshotRestore.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ebs_fast_snapshot_restore aws_ebs_fast_snapshot_restore}
*/
export declare class TfFastSnapshotRestore extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ebs_fast_snapshot_restore";
    /**
    * Generates CDKTN code for importing a TfFastSnapshotRestore resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfFastSnapshotRestore to import
    * @param importFromId The id of the existing TfFastSnapshotRestore that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ebs_fast_snapshot_restore#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfFastSnapshotRestore to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ebs_fast_snapshot_restore aws_ebs_fast_snapshot_restore} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfFastSnapshotRestoreConfig
    */
    constructor(scope: Construct, id: string, config: TfFastSnapshotRestoreConfig);
    private _availabilityZone?;
    get availabilityZone(): string;
    set availabilityZone(value: string);
    get availabilityZoneInput(): string | undefined;
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _snapshotId?;
    get snapshotId(): string;
    set snapshotId(value: string);
    get snapshotIdInput(): string | undefined;
    get state(): string;
    private _timeouts;
    get timeouts(): TfFastSnapshotRestore.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfFastSnapshotRestore.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfFastSnapshotRestore.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfFastSnapshotRestoreTimeoutsPropertyToTerraform(struct?: TfFastSnapshotRestore.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfFastSnapshotRestoreTimeoutsPropertyToHclTerraform(struct?: TfFastSnapshotRestore.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfFastSnapshotRestore {
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ebs_fast_snapshot_restore#create TfFastSnapshotRestore#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ebs_fast_snapshot_restore#delete TfFastSnapshotRestore#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
