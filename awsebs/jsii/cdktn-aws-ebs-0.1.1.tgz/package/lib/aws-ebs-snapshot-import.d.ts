import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsEbsSnapshotImportConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ebs_snapshot_import#description AwsEbsSnapshotImport#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ebs_snapshot_import#encrypted AwsEbsSnapshotImport#encrypted}
    */
    readonly encrypted?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ebs_snapshot_import#id AwsEbsSnapshotImport#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ebs_snapshot_import#kms_key_id AwsEbsSnapshotImport#kms_key_id}
    */
    readonly kmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ebs_snapshot_import#permanent_restore AwsEbsSnapshotImport#permanent_restore}
    */
    readonly permanentRestore?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ebs_snapshot_import#region AwsEbsSnapshotImport#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ebs_snapshot_import#role_name AwsEbsSnapshotImport#role_name}
    */
    readonly roleName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ebs_snapshot_import#storage_tier AwsEbsSnapshotImport#storage_tier}
    */
    readonly storageTier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ebs_snapshot_import#tags AwsEbsSnapshotImport#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ebs_snapshot_import#tags_all AwsEbsSnapshotImport#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ebs_snapshot_import#temporary_restore_days AwsEbsSnapshotImport#temporary_restore_days}
    */
    readonly temporaryRestoreDays?: number;
    /**
    * client_data block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ebs_snapshot_import#client_data AwsEbsSnapshotImport#client_data}
    */
    readonly clientData?: AwsEbsSnapshotImport.ClientDataProperty;
    /**
    * disk_container block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ebs_snapshot_import#disk_container AwsEbsSnapshotImport#disk_container}
    */
    readonly diskContainer: AwsEbsSnapshotImport.DiskContainerProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ebs_snapshot_import#timeouts AwsEbsSnapshotImport#timeouts}
    */
    readonly timeouts?: AwsEbsSnapshotImport.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ebs_snapshot_import aws_ebs_snapshot_import}
*/
export declare class AwsEbsSnapshotImport extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_ebs_snapshot_import";
    /**
    * Generates CDKTN code for importing a AwsEbsSnapshotImport resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsEbsSnapshotImport to import
    * @param importFromId The id of the existing AwsEbsSnapshotImport that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ebs_snapshot_import#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsEbsSnapshotImport to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ebs_snapshot_import aws_ebs_snapshot_import} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsEbsSnapshotImportConfig
    */
    constructor(scope: Construct, id: string, config: AwsEbsSnapshotImportConfig);
    get arn(): string;
    get dataEncryptionKeyId(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _encrypted?;
    get encrypted(): boolean | cdktn.IResolvable;
    set encrypted(value: boolean | cdktn.IResolvable);
    resetEncrypted(): void;
    get encryptedInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    resetKmsKeyId(): void;
    get kmsKeyIdInput(): string | undefined;
    get outpostArn(): string;
    get ownerAlias(): string;
    get ownerId(): string;
    private _permanentRestore?;
    get permanentRestore(): boolean | cdktn.IResolvable;
    set permanentRestore(value: boolean | cdktn.IResolvable);
    resetPermanentRestore(): void;
    get permanentRestoreInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleName?;
    get roleName(): string;
    set roleName(value: string);
    resetRoleName(): void;
    get roleNameInput(): string | undefined;
    private _storageTier?;
    get storageTier(): string;
    set storageTier(value: string);
    resetStorageTier(): void;
    get storageTierInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _temporaryRestoreDays?;
    get temporaryRestoreDays(): number;
    set temporaryRestoreDays(value: number);
    resetTemporaryRestoreDays(): void;
    get temporaryRestoreDaysInput(): number | undefined;
    get volumeId(): string;
    get volumeSize(): number;
    private _clientData;
    get clientData(): AwsEbsSnapshotImport.ClientDataPropertyOutputReference;
    putClientData(value: AwsEbsSnapshotImport.ClientDataProperty): void;
    resetClientData(): void;
    get clientDataInput(): AwsEbsSnapshotImport.ClientDataProperty | undefined;
    private _diskContainer;
    get diskContainer(): AwsEbsSnapshotImport.DiskContainerPropertyOutputReference;
    putDiskContainer(value: AwsEbsSnapshotImport.DiskContainerProperty): void;
    get diskContainerInput(): AwsEbsSnapshotImport.DiskContainerProperty | undefined;
    private _timeouts;
    get timeouts(): AwsEbsSnapshotImport.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsEbsSnapshotImport.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsEbsSnapshotImport.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsEbsSnapshotImportClientDataPropertyToTerraform(struct?: AwsEbsSnapshotImport.ClientDataPropertyOutputReference | AwsEbsSnapshotImport.ClientDataProperty): any;
export declare function awsEbsSnapshotImportClientDataPropertyToHclTerraform(struct?: AwsEbsSnapshotImport.ClientDataPropertyOutputReference | AwsEbsSnapshotImport.ClientDataProperty): any;
export declare function awsEbsSnapshotImportUserBucketPropertyToTerraform(struct?: AwsEbsSnapshotImport.UserBucketPropertyOutputReference | AwsEbsSnapshotImport.UserBucketProperty): any;
export declare function awsEbsSnapshotImportUserBucketPropertyToHclTerraform(struct?: AwsEbsSnapshotImport.UserBucketPropertyOutputReference | AwsEbsSnapshotImport.UserBucketProperty): any;
export declare function awsEbsSnapshotImportDiskContainerPropertyToTerraform(struct?: AwsEbsSnapshotImport.DiskContainerPropertyOutputReference | AwsEbsSnapshotImport.DiskContainerProperty): any;
export declare function awsEbsSnapshotImportDiskContainerPropertyToHclTerraform(struct?: AwsEbsSnapshotImport.DiskContainerPropertyOutputReference | AwsEbsSnapshotImport.DiskContainerProperty): any;
export declare function awsEbsSnapshotImportTimeoutsPropertyToTerraform(struct?: AwsEbsSnapshotImport.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsEbsSnapshotImportTimeoutsPropertyToHclTerraform(struct?: AwsEbsSnapshotImport.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsEbsSnapshotImport {
    interface ClientDataProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ebs_snapshot_import#comment AwsEbsSnapshotImport#comment}
        */
        readonly comment?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ebs_snapshot_import#upload_end AwsEbsSnapshotImport#upload_end}
        */
        readonly uploadEnd?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ebs_snapshot_import#upload_size AwsEbsSnapshotImport#upload_size}
        */
        readonly uploadSize?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ebs_snapshot_import#upload_start AwsEbsSnapshotImport#upload_start}
        */
        readonly uploadStart?: string;
    }
    class ClientDataPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ClientDataProperty | undefined;
        set internalValue(value: ClientDataProperty | undefined);
        private _comment?;
        get comment(): string;
        set comment(value: string);
        resetComment(): void;
        get commentInput(): string | undefined;
        private _uploadEnd?;
        get uploadEnd(): string;
        set uploadEnd(value: string);
        resetUploadEnd(): void;
        get uploadEndInput(): string | undefined;
        private _uploadSize?;
        get uploadSize(): number;
        set uploadSize(value: number);
        resetUploadSize(): void;
        get uploadSizeInput(): number | undefined;
        private _uploadStart?;
        get uploadStart(): string;
        set uploadStart(value: string);
        resetUploadStart(): void;
        get uploadStartInput(): string | undefined;
    }
    interface UserBucketProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ebs_snapshot_import#s3_bucket AwsEbsSnapshotImport#s3_bucket}
        */
        readonly s3Bucket: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ebs_snapshot_import#s3_key AwsEbsSnapshotImport#s3_key}
        */
        readonly s3Key: string;
    }
    class UserBucketPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UserBucketProperty | undefined;
        set internalValue(value: UserBucketProperty | undefined);
        private _s3Bucket?;
        get s3Bucket(): string;
        set s3Bucket(value: string);
        get s3BucketInput(): string | undefined;
        private _s3Key?;
        get s3Key(): string;
        set s3Key(value: string);
        get s3KeyInput(): string | undefined;
    }
    interface DiskContainerProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ebs_snapshot_import#description AwsEbsSnapshotImport#description}
        */
        readonly description?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ebs_snapshot_import#format AwsEbsSnapshotImport#format}
        */
        readonly format: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ebs_snapshot_import#url AwsEbsSnapshotImport#url}
        */
        readonly url?: string;
        /**
        * user_bucket block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ebs_snapshot_import#user_bucket AwsEbsSnapshotImport#user_bucket}
        */
        readonly userBucket?: UserBucketProperty;
    }
    class DiskContainerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DiskContainerProperty | undefined;
        set internalValue(value: DiskContainerProperty | undefined);
        private _description?;
        get description(): string;
        set description(value: string);
        resetDescription(): void;
        get descriptionInput(): string | undefined;
        private _format?;
        get format(): string;
        set format(value: string);
        get formatInput(): string | undefined;
        private _url?;
        get url(): string;
        set url(value: string);
        resetUrl(): void;
        get urlInput(): string | undefined;
        private _userBucket;
        get userBucket(): UserBucketPropertyOutputReference;
        putUserBucket(value: UserBucketProperty): void;
        resetUserBucket(): void;
        get userBucketInput(): UserBucketProperty | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ebs_snapshot_import#create AwsEbsSnapshotImport#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/ebs_snapshot_import#delete AwsEbsSnapshotImport#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
