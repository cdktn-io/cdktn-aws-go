import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfFindingIdsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/guardduty_finding_ids#detector_id DataTfFindingIds#detector_id}
    */
    readonly detectorId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/guardduty_finding_ids#region DataTfFindingIds#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/guardduty_finding_ids aws_guardduty_finding_ids}
*/
export declare class DataTfFindingIds extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_guardduty_finding_ids";
    /**
    * Generates CDKTN code for importing a DataTfFindingIds resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfFindingIds to import
    * @param importFromId The id of the existing DataTfFindingIds that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/guardduty_finding_ids#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfFindingIds to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/guardduty_finding_ids aws_guardduty_finding_ids} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfFindingIdsConfig
    */
    constructor(scope: Construct, id: string, config: DataTfFindingIdsConfig);
    private _detectorId?;
    get detectorId(): string;
    set detectorId(value: string);
    get detectorIdInput(): string | undefined;
    get findingIds(): string[];
    get hasFindings(): cdktn.IResolvable;
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
