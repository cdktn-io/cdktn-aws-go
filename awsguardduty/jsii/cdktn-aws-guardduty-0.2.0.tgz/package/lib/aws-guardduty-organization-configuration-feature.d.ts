import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfOrganizationConfigurationFeatureConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_organization_configuration_feature#auto_enable TfOrganizationConfigurationFeature#auto_enable}
    */
    readonly autoEnable: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_organization_configuration_feature#detector_id TfOrganizationConfigurationFeature#detector_id}
    */
    readonly detectorId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_organization_configuration_feature#id TfOrganizationConfigurationFeature#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_organization_configuration_feature#name TfOrganizationConfigurationFeature#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_organization_configuration_feature#region TfOrganizationConfigurationFeature#region}
    */
    readonly region?: string;
    /**
    * additional_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_organization_configuration_feature#additional_configuration TfOrganizationConfigurationFeature#additional_configuration}
    */
    readonly additionalConfiguration?: TfOrganizationConfigurationFeature.AdditionalConfigurationProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_organization_configuration_feature aws_guardduty_organization_configuration_feature}
*/
export declare class TfOrganizationConfigurationFeature extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_guardduty_organization_configuration_feature";
    /**
    * Generates CDKTN code for importing a TfOrganizationConfigurationFeature resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfOrganizationConfigurationFeature to import
    * @param importFromId The id of the existing TfOrganizationConfigurationFeature that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_organization_configuration_feature#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfOrganizationConfigurationFeature to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_organization_configuration_feature aws_guardduty_organization_configuration_feature} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfOrganizationConfigurationFeatureConfig
    */
    constructor(scope: Construct, id: string, config: TfOrganizationConfigurationFeatureConfig);
    private _autoEnable?;
    get autoEnable(): string;
    set autoEnable(value: string);
    get autoEnableInput(): string | undefined;
    private _detectorId?;
    get detectorId(): string;
    set detectorId(value: string);
    get detectorIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _additionalConfiguration;
    get additionalConfiguration(): TfOrganizationConfigurationFeature.AdditionalConfigurationPropertyList;
    putAdditionalConfiguration(value: TfOrganizationConfigurationFeature.AdditionalConfigurationProperty[] | cdktn.IResolvable): void;
    resetAdditionalConfiguration(): void;
    get additionalConfigurationInput(): cdktn.IResolvable | TfOrganizationConfigurationFeature.AdditionalConfigurationProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfOrganizationConfigurationFeatureAdditionalConfigurationPropertyToTerraform(struct?: TfOrganizationConfigurationFeature.AdditionalConfigurationProperty | cdktn.IResolvable): any;
export declare function tfOrganizationConfigurationFeatureAdditionalConfigurationPropertyToHclTerraform(struct?: TfOrganizationConfigurationFeature.AdditionalConfigurationProperty | cdktn.IResolvable): any;
export declare namespace TfOrganizationConfigurationFeature {
    interface AdditionalConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_organization_configuration_feature#auto_enable TfOrganizationConfigurationFeature#auto_enable}
        */
        readonly autoEnable: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_organization_configuration_feature#name TfOrganizationConfigurationFeature#name}
        */
        readonly name: string;
    }
    class AdditionalConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AdditionalConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AdditionalConfigurationProperty | cdktn.IResolvable | undefined);
        private _autoEnable?;
        get autoEnable(): string;
        set autoEnable(value: string);
        get autoEnableInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    class AdditionalConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: AdditionalConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AdditionalConfigurationPropertyOutputReference;
    }
}
