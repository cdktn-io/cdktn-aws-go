import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsGuarddutyOrganizationConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_organization_configuration#auto_enable_organization_members AwsGuarddutyOrganizationConfiguration#auto_enable_organization_members}
    */
    readonly autoEnableOrganizationMembers: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_organization_configuration#detector_id AwsGuarddutyOrganizationConfiguration#detector_id}
    */
    readonly detectorId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_organization_configuration#id AwsGuarddutyOrganizationConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_organization_configuration#region AwsGuarddutyOrganizationConfiguration#region}
    */
    readonly region?: string;
    /**
    * datasources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_organization_configuration#datasources AwsGuarddutyOrganizationConfiguration#datasources}
    */
    readonly datasources?: AwsGuarddutyOrganizationConfiguration.DatasourcesProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_organization_configuration aws_guardduty_organization_configuration}
*/
export declare class AwsGuarddutyOrganizationConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_guardduty_organization_configuration";
    /**
    * Generates CDKTN code for importing a AwsGuarddutyOrganizationConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsGuarddutyOrganizationConfiguration to import
    * @param importFromId The id of the existing AwsGuarddutyOrganizationConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_organization_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsGuarddutyOrganizationConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_organization_configuration aws_guardduty_organization_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsGuarddutyOrganizationConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsGuarddutyOrganizationConfigurationConfig);
    private _autoEnableOrganizationMembers?;
    get autoEnableOrganizationMembers(): string;
    set autoEnableOrganizationMembers(value: string);
    get autoEnableOrganizationMembersInput(): string | undefined;
    private _detectorId?;
    get detectorId(): string;
    set detectorId(value: string);
    get detectorIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _datasources;
    get datasources(): AwsGuarddutyOrganizationConfiguration.DatasourcesPropertyOutputReference;
    putDatasources(value: AwsGuarddutyOrganizationConfiguration.DatasourcesProperty): void;
    resetDatasources(): void;
    get datasourcesInput(): AwsGuarddutyOrganizationConfiguration.DatasourcesProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsGuarddutyOrganizationConfigurationAuditLogsPropertyToTerraform(struct?: AwsGuarddutyOrganizationConfiguration.AuditLogsPropertyOutputReference | AwsGuarddutyOrganizationConfiguration.AuditLogsProperty): any;
export declare function awsGuarddutyOrganizationConfigurationAuditLogsPropertyToHclTerraform(struct?: AwsGuarddutyOrganizationConfiguration.AuditLogsPropertyOutputReference | AwsGuarddutyOrganizationConfiguration.AuditLogsProperty): any;
export declare function awsGuarddutyOrganizationConfigurationKubernetesPropertyToTerraform(struct?: AwsGuarddutyOrganizationConfiguration.KubernetesPropertyOutputReference | AwsGuarddutyOrganizationConfiguration.KubernetesProperty): any;
export declare function awsGuarddutyOrganizationConfigurationKubernetesPropertyToHclTerraform(struct?: AwsGuarddutyOrganizationConfiguration.KubernetesPropertyOutputReference | AwsGuarddutyOrganizationConfiguration.KubernetesProperty): any;
export declare function awsGuarddutyOrganizationConfigurationEbsVolumesPropertyToTerraform(struct?: AwsGuarddutyOrganizationConfiguration.EbsVolumesPropertyOutputReference | AwsGuarddutyOrganizationConfiguration.EbsVolumesProperty): any;
export declare function awsGuarddutyOrganizationConfigurationEbsVolumesPropertyToHclTerraform(struct?: AwsGuarddutyOrganizationConfiguration.EbsVolumesPropertyOutputReference | AwsGuarddutyOrganizationConfiguration.EbsVolumesProperty): any;
export declare function awsGuarddutyOrganizationConfigurationScanEc2InstanceWithFindingsPropertyToTerraform(struct?: AwsGuarddutyOrganizationConfiguration.ScanEc2InstanceWithFindingsPropertyOutputReference | AwsGuarddutyOrganizationConfiguration.ScanEc2InstanceWithFindingsProperty): any;
export declare function awsGuarddutyOrganizationConfigurationScanEc2InstanceWithFindingsPropertyToHclTerraform(struct?: AwsGuarddutyOrganizationConfiguration.ScanEc2InstanceWithFindingsPropertyOutputReference | AwsGuarddutyOrganizationConfiguration.ScanEc2InstanceWithFindingsProperty): any;
export declare function awsGuarddutyOrganizationConfigurationMalwareProtectionPropertyToTerraform(struct?: AwsGuarddutyOrganizationConfiguration.MalwareProtectionPropertyOutputReference | AwsGuarddutyOrganizationConfiguration.MalwareProtectionProperty): any;
export declare function awsGuarddutyOrganizationConfigurationMalwareProtectionPropertyToHclTerraform(struct?: AwsGuarddutyOrganizationConfiguration.MalwareProtectionPropertyOutputReference | AwsGuarddutyOrganizationConfiguration.MalwareProtectionProperty): any;
export declare function awsGuarddutyOrganizationConfigurationS3LogsPropertyToTerraform(struct?: AwsGuarddutyOrganizationConfiguration.S3LogsPropertyOutputReference | AwsGuarddutyOrganizationConfiguration.S3LogsProperty): any;
export declare function awsGuarddutyOrganizationConfigurationS3LogsPropertyToHclTerraform(struct?: AwsGuarddutyOrganizationConfiguration.S3LogsPropertyOutputReference | AwsGuarddutyOrganizationConfiguration.S3LogsProperty): any;
export declare function awsGuarddutyOrganizationConfigurationDatasourcesPropertyToTerraform(struct?: AwsGuarddutyOrganizationConfiguration.DatasourcesPropertyOutputReference | AwsGuarddutyOrganizationConfiguration.DatasourcesProperty): any;
export declare function awsGuarddutyOrganizationConfigurationDatasourcesPropertyToHclTerraform(struct?: AwsGuarddutyOrganizationConfiguration.DatasourcesPropertyOutputReference | AwsGuarddutyOrganizationConfiguration.DatasourcesProperty): any;
export declare namespace AwsGuarddutyOrganizationConfiguration {
    interface AuditLogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_organization_configuration#enable AwsGuarddutyOrganizationConfiguration#enable}
        */
        readonly enable: boolean | cdktn.IResolvable;
    }
    class AuditLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AuditLogsProperty | undefined;
        set internalValue(value: AuditLogsProperty | undefined);
        private _enable?;
        get enable(): boolean | cdktn.IResolvable;
        set enable(value: boolean | cdktn.IResolvable);
        get enableInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface KubernetesProperty {
        /**
        * audit_logs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_organization_configuration#audit_logs AwsGuarddutyOrganizationConfiguration#audit_logs}
        */
        readonly auditLogs: AuditLogsProperty;
    }
    class KubernetesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KubernetesProperty | undefined;
        set internalValue(value: KubernetesProperty | undefined);
        private _auditLogs;
        get auditLogs(): AuditLogsPropertyOutputReference;
        putAuditLogs(value: AuditLogsProperty): void;
        get auditLogsInput(): AuditLogsProperty | undefined;
    }
    interface EbsVolumesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_organization_configuration#auto_enable AwsGuarddutyOrganizationConfiguration#auto_enable}
        */
        readonly autoEnable: boolean | cdktn.IResolvable;
    }
    class EbsVolumesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EbsVolumesProperty | undefined;
        set internalValue(value: EbsVolumesProperty | undefined);
        private _autoEnable?;
        get autoEnable(): boolean | cdktn.IResolvable;
        set autoEnable(value: boolean | cdktn.IResolvable);
        get autoEnableInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface ScanEc2InstanceWithFindingsProperty {
        /**
        * ebs_volumes block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_organization_configuration#ebs_volumes AwsGuarddutyOrganizationConfiguration#ebs_volumes}
        */
        readonly ebsVolumes: EbsVolumesProperty;
    }
    class ScanEc2InstanceWithFindingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ScanEc2InstanceWithFindingsProperty | undefined;
        set internalValue(value: ScanEc2InstanceWithFindingsProperty | undefined);
        private _ebsVolumes;
        get ebsVolumes(): EbsVolumesPropertyOutputReference;
        putEbsVolumes(value: EbsVolumesProperty): void;
        get ebsVolumesInput(): EbsVolumesProperty | undefined;
    }
    interface MalwareProtectionProperty {
        /**
        * scan_ec2_instance_with_findings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_organization_configuration#scan_ec2_instance_with_findings AwsGuarddutyOrganizationConfiguration#scan_ec2_instance_with_findings}
        */
        readonly scanEc2InstanceWithFindings: ScanEc2InstanceWithFindingsProperty;
    }
    class MalwareProtectionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MalwareProtectionProperty | undefined;
        set internalValue(value: MalwareProtectionProperty | undefined);
        private _scanEc2InstanceWithFindings;
        get scanEc2InstanceWithFindings(): ScanEc2InstanceWithFindingsPropertyOutputReference;
        putScanEc2InstanceWithFindings(value: ScanEc2InstanceWithFindingsProperty): void;
        get scanEc2InstanceWithFindingsInput(): ScanEc2InstanceWithFindingsProperty | undefined;
    }
    interface S3LogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_organization_configuration#auto_enable AwsGuarddutyOrganizationConfiguration#auto_enable}
        */
        readonly autoEnable: boolean | cdktn.IResolvable;
    }
    class S3LogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3LogsProperty | undefined;
        set internalValue(value: S3LogsProperty | undefined);
        private _autoEnable?;
        get autoEnable(): boolean | cdktn.IResolvable;
        set autoEnable(value: boolean | cdktn.IResolvable);
        get autoEnableInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface DatasourcesProperty {
        /**
        * kubernetes block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_organization_configuration#kubernetes AwsGuarddutyOrganizationConfiguration#kubernetes}
        */
        readonly kubernetes?: KubernetesProperty;
        /**
        * malware_protection block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_organization_configuration#malware_protection AwsGuarddutyOrganizationConfiguration#malware_protection}
        */
        readonly malwareProtection?: MalwareProtectionProperty;
        /**
        * s3_logs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_organization_configuration#s3_logs AwsGuarddutyOrganizationConfiguration#s3_logs}
        */
        readonly s3Logs?: S3LogsProperty;
    }
    class DatasourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DatasourcesProperty | undefined;
        set internalValue(value: DatasourcesProperty | undefined);
        private _kubernetes;
        get kubernetes(): KubernetesPropertyOutputReference;
        putKubernetes(value: KubernetesProperty): void;
        resetKubernetes(): void;
        get kubernetesInput(): KubernetesProperty | undefined;
        private _malwareProtection;
        get malwareProtection(): MalwareProtectionPropertyOutputReference;
        putMalwareProtection(value: MalwareProtectionProperty): void;
        resetMalwareProtection(): void;
        get malwareProtectionInput(): MalwareProtectionProperty | undefined;
        private _s3Logs;
        get s3Logs(): S3LogsPropertyOutputReference;
        putS3Logs(value: S3LogsProperty): void;
        resetS3Logs(): void;
        get s3LogsInput(): S3LogsProperty | undefined;
    }
}
