import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsGuarddutyDetectorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_detector#enable AwsGuarddutyDetector#enable}
    */
    readonly enable?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_detector#finding_publishing_frequency AwsGuarddutyDetector#finding_publishing_frequency}
    */
    readonly findingPublishingFrequency?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_detector#id AwsGuarddutyDetector#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_detector#region AwsGuarddutyDetector#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_detector#tags AwsGuarddutyDetector#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_detector#tags_all AwsGuarddutyDetector#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * datasources block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_detector#datasources AwsGuarddutyDetector#datasources}
    */
    readonly datasources?: AwsGuarddutyDetector.DatasourcesProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_detector aws_guardduty_detector}
*/
export declare class AwsGuarddutyDetector extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_guardduty_detector";
    /**
    * Generates CDKTN code for importing a AwsGuarddutyDetector resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsGuarddutyDetector to import
    * @param importFromId The id of the existing AwsGuarddutyDetector that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_detector#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsGuarddutyDetector to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_detector aws_guardduty_detector} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsGuarddutyDetectorConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsGuarddutyDetectorConfig);
    get accountId(): string;
    get arn(): string;
    private _enable?;
    get enable(): boolean | cdktn.IResolvable;
    set enable(value: boolean | cdktn.IResolvable);
    resetEnable(): void;
    get enableInput(): boolean | cdktn.IResolvable | undefined;
    private _findingPublishingFrequency?;
    get findingPublishingFrequency(): string;
    set findingPublishingFrequency(value: string);
    resetFindingPublishingFrequency(): void;
    get findingPublishingFrequencyInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _datasources;
    get datasources(): AwsGuarddutyDetector.DatasourcesPropertyOutputReference;
    putDatasources(value: AwsGuarddutyDetector.DatasourcesProperty): void;
    resetDatasources(): void;
    get datasourcesInput(): AwsGuarddutyDetector.DatasourcesProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsGuarddutyDetectorAuditLogsPropertyToTerraform(struct?: AwsGuarddutyDetector.AuditLogsPropertyOutputReference | AwsGuarddutyDetector.AuditLogsProperty): any;
export declare function awsGuarddutyDetectorAuditLogsPropertyToHclTerraform(struct?: AwsGuarddutyDetector.AuditLogsPropertyOutputReference | AwsGuarddutyDetector.AuditLogsProperty): any;
export declare function awsGuarddutyDetectorKubernetesPropertyToTerraform(struct?: AwsGuarddutyDetector.KubernetesPropertyOutputReference | AwsGuarddutyDetector.KubernetesProperty): any;
export declare function awsGuarddutyDetectorKubernetesPropertyToHclTerraform(struct?: AwsGuarddutyDetector.KubernetesPropertyOutputReference | AwsGuarddutyDetector.KubernetesProperty): any;
export declare function awsGuarddutyDetectorEbsVolumesPropertyToTerraform(struct?: AwsGuarddutyDetector.EbsVolumesPropertyOutputReference | AwsGuarddutyDetector.EbsVolumesProperty): any;
export declare function awsGuarddutyDetectorEbsVolumesPropertyToHclTerraform(struct?: AwsGuarddutyDetector.EbsVolumesPropertyOutputReference | AwsGuarddutyDetector.EbsVolumesProperty): any;
export declare function awsGuarddutyDetectorScanEc2InstanceWithFindingsPropertyToTerraform(struct?: AwsGuarddutyDetector.ScanEc2InstanceWithFindingsPropertyOutputReference | AwsGuarddutyDetector.ScanEc2InstanceWithFindingsProperty): any;
export declare function awsGuarddutyDetectorScanEc2InstanceWithFindingsPropertyToHclTerraform(struct?: AwsGuarddutyDetector.ScanEc2InstanceWithFindingsPropertyOutputReference | AwsGuarddutyDetector.ScanEc2InstanceWithFindingsProperty): any;
export declare function awsGuarddutyDetectorMalwareProtectionPropertyToTerraform(struct?: AwsGuarddutyDetector.MalwareProtectionPropertyOutputReference | AwsGuarddutyDetector.MalwareProtectionProperty): any;
export declare function awsGuarddutyDetectorMalwareProtectionPropertyToHclTerraform(struct?: AwsGuarddutyDetector.MalwareProtectionPropertyOutputReference | AwsGuarddutyDetector.MalwareProtectionProperty): any;
export declare function awsGuarddutyDetectorS3LogsPropertyToTerraform(struct?: AwsGuarddutyDetector.S3LogsPropertyOutputReference | AwsGuarddutyDetector.S3LogsProperty): any;
export declare function awsGuarddutyDetectorS3LogsPropertyToHclTerraform(struct?: AwsGuarddutyDetector.S3LogsPropertyOutputReference | AwsGuarddutyDetector.S3LogsProperty): any;
export declare function awsGuarddutyDetectorDatasourcesPropertyToTerraform(struct?: AwsGuarddutyDetector.DatasourcesPropertyOutputReference | AwsGuarddutyDetector.DatasourcesProperty): any;
export declare function awsGuarddutyDetectorDatasourcesPropertyToHclTerraform(struct?: AwsGuarddutyDetector.DatasourcesPropertyOutputReference | AwsGuarddutyDetector.DatasourcesProperty): any;
export declare namespace AwsGuarddutyDetector {
    interface AuditLogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_detector#enable AwsGuarddutyDetector#enable}
        */
        readonly enable: boolean | cdktn.IResolvable;
    }
    class AuditLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AuditLogsProperty | undefined;
        set internalValue(value: AuditLogsProperty | undefined);
        private _enable?;
        get enable(): boolean | cdktn.IResolvable;
        set enable(value: boolean | cdktn.IResolvable);
        get enableInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface KubernetesProperty {
        /**
        * audit_logs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_detector#audit_logs AwsGuarddutyDetector#audit_logs}
        */
        readonly auditLogs: AuditLogsProperty;
    }
    class KubernetesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KubernetesProperty | undefined;
        set internalValue(value: KubernetesProperty | undefined);
        private _auditLogs;
        get auditLogs(): AuditLogsPropertyOutputReference;
        putAuditLogs(value: AuditLogsProperty): void;
        get auditLogsInput(): AuditLogsProperty | undefined;
    }
    interface EbsVolumesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_detector#enable AwsGuarddutyDetector#enable}
        */
        readonly enable: boolean | cdktn.IResolvable;
    }
    class EbsVolumesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EbsVolumesProperty | undefined;
        set internalValue(value: EbsVolumesProperty | undefined);
        private _enable?;
        get enable(): boolean | cdktn.IResolvable;
        set enable(value: boolean | cdktn.IResolvable);
        get enableInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface ScanEc2InstanceWithFindingsProperty {
        /**
        * ebs_volumes block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_detector#ebs_volumes AwsGuarddutyDetector#ebs_volumes}
        */
        readonly ebsVolumes: EbsVolumesProperty;
    }
    class ScanEc2InstanceWithFindingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ScanEc2InstanceWithFindingsProperty | undefined;
        set internalValue(value: ScanEc2InstanceWithFindingsProperty | undefined);
        private _ebsVolumes;
        get ebsVolumes(): EbsVolumesPropertyOutputReference;
        putEbsVolumes(value: EbsVolumesProperty): void;
        get ebsVolumesInput(): EbsVolumesProperty | undefined;
    }
    interface MalwareProtectionProperty {
        /**
        * scan_ec2_instance_with_findings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_detector#scan_ec2_instance_with_findings AwsGuarddutyDetector#scan_ec2_instance_with_findings}
        */
        readonly scanEc2InstanceWithFindings: ScanEc2InstanceWithFindingsProperty;
    }
    class MalwareProtectionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MalwareProtectionProperty | undefined;
        set internalValue(value: MalwareProtectionProperty | undefined);
        private _scanEc2InstanceWithFindings;
        get scanEc2InstanceWithFindings(): ScanEc2InstanceWithFindingsPropertyOutputReference;
        putScanEc2InstanceWithFindings(value: ScanEc2InstanceWithFindingsProperty): void;
        get scanEc2InstanceWithFindingsInput(): ScanEc2InstanceWithFindingsProperty | undefined;
    }
    interface S3LogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_detector#enable AwsGuarddutyDetector#enable}
        */
        readonly enable: boolean | cdktn.IResolvable;
    }
    class S3LogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3LogsProperty | undefined;
        set internalValue(value: S3LogsProperty | undefined);
        private _enable?;
        get enable(): boolean | cdktn.IResolvable;
        set enable(value: boolean | cdktn.IResolvable);
        get enableInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface DatasourcesProperty {
        /**
        * kubernetes block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_detector#kubernetes AwsGuarddutyDetector#kubernetes}
        */
        readonly kubernetes?: KubernetesProperty;
        /**
        * malware_protection block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_detector#malware_protection AwsGuarddutyDetector#malware_protection}
        */
        readonly malwareProtection?: MalwareProtectionProperty;
        /**
        * s3_logs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_detector#s3_logs AwsGuarddutyDetector#s3_logs}
        */
        readonly s3Logs?: S3LogsProperty;
    }
    class DatasourcesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DatasourcesProperty | undefined;
        set internalValue(value: DatasourcesProperty | undefined);
        private _kubernetes;
        get kubernetes(): KubernetesPropertyOutputReference;
        putKubernetes(value: KubernetesProperty): void;
        resetKubernetes(): void;
        get kubernetesInput(): KubernetesProperty | undefined;
        private _malwareProtection;
        get malwareProtection(): MalwareProtectionPropertyOutputReference;
        putMalwareProtection(value: MalwareProtectionProperty): void;
        resetMalwareProtection(): void;
        get malwareProtectionInput(): MalwareProtectionProperty | undefined;
        private _s3Logs;
        get s3Logs(): S3LogsPropertyOutputReference;
        putS3Logs(value: S3LogsProperty): void;
        resetS3Logs(): void;
        get s3LogsInput(): S3LogsProperty | undefined;
    }
}
