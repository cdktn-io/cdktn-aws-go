import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsApplicationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_application#description AwsApplication#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_application#id AwsApplication#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_application#name AwsApplication#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_application#region AwsApplication#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_application#tags AwsApplication#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_application#tags_all AwsApplication#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * appversion_lifecycle block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_application#appversion_lifecycle AwsApplication#appversion_lifecycle}
    */
    readonly appversionLifecycle?: AwsApplication.AppversionLifecycleProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_application aws_elastic_beanstalk_application}
*/
export declare class AwsApplication extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_elastic_beanstalk_application";
    /**
    * Generates CDKTN code for importing a AwsApplication resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsApplication to import
    * @param importFromId The id of the existing AwsApplication that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_application#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsApplication to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_application aws_elastic_beanstalk_application} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsApplicationConfig
    */
    constructor(scope: Construct, id: string, config: AwsApplicationConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _appversionLifecycle;
    get appversionLifecycle(): AwsApplication.AppversionLifecyclePropertyOutputReference;
    putAppversionLifecycle(value: AwsApplication.AppversionLifecycleProperty): void;
    resetAppversionLifecycle(): void;
    get appversionLifecycleInput(): AwsApplication.AppversionLifecycleProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsApplicationAppversionLifecyclePropertyToTerraform(struct?: AwsApplication.AppversionLifecyclePropertyOutputReference | AwsApplication.AppversionLifecycleProperty): any;
export declare function awsApplicationAppversionLifecyclePropertyToHclTerraform(struct?: AwsApplication.AppversionLifecyclePropertyOutputReference | AwsApplication.AppversionLifecycleProperty): any;
export declare namespace AwsApplication {
    interface AppversionLifecycleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_application#delete_source_from_s3 AwsApplication#delete_source_from_s3}
        */
        readonly deleteSourceFromS3?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_application#max_age_in_days AwsApplication#max_age_in_days}
        */
        readonly maxAgeInDays?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_application#max_count AwsApplication#max_count}
        */
        readonly maxCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/elastic_beanstalk_application#service_role AwsApplication#service_role}
        */
        readonly serviceRole: string;
    }
    class AppversionLifecyclePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AppversionLifecycleProperty | undefined;
        set internalValue(value: AppversionLifecycleProperty | undefined);
        private _deleteSourceFromS3?;
        get deleteSourceFromS3(): boolean | cdktn.IResolvable;
        set deleteSourceFromS3(value: boolean | cdktn.IResolvable);
        resetDeleteSourceFromS3(): void;
        get deleteSourceFromS3Input(): boolean | cdktn.IResolvable | undefined;
        private _maxAgeInDays?;
        get maxAgeInDays(): number;
        set maxAgeInDays(value: number);
        resetMaxAgeInDays(): void;
        get maxAgeInDaysInput(): number | undefined;
        private _maxCount?;
        get maxCount(): number;
        set maxCount(value: number);
        resetMaxCount(): void;
        get maxCountInput(): number | undefined;
        private _serviceRole?;
        get serviceRole(): string;
        set serviceRole(value: string);
        get serviceRoleInput(): string | undefined;
    }
}
