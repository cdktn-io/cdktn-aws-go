import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsApprunnerCustomDomainAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_custom_domain_association#domain_name AwsApprunnerCustomDomainAssociation#domain_name}
    */
    readonly domainName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_custom_domain_association#enable_www_subdomain AwsApprunnerCustomDomainAssociation#enable_www_subdomain}
    */
    readonly enableWwwSubdomain?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_custom_domain_association#id AwsApprunnerCustomDomainAssociation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_custom_domain_association#region AwsApprunnerCustomDomainAssociation#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_custom_domain_association#service_arn AwsApprunnerCustomDomainAssociation#service_arn}
    */
    readonly serviceArn: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_custom_domain_association aws_apprunner_custom_domain_association}
*/
export declare class AwsApprunnerCustomDomainAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_apprunner_custom_domain_association";
    /**
    * Generates CDKTN code for importing a AwsApprunnerCustomDomainAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsApprunnerCustomDomainAssociation to import
    * @param importFromId The id of the existing AwsApprunnerCustomDomainAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_custom_domain_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsApprunnerCustomDomainAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_custom_domain_association aws_apprunner_custom_domain_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsApprunnerCustomDomainAssociationConfig
    */
    constructor(scope: Construct, id: string, config: AwsApprunnerCustomDomainAssociationConfig);
    private _certificateValidationRecords;
    get certificateValidationRecords(): AwsApprunnerCustomDomainAssociation.CertificateValidationRecordsPropertyList;
    get dnsTarget(): string;
    private _domainName?;
    get domainName(): string;
    set domainName(value: string);
    get domainNameInput(): string | undefined;
    private _enableWwwSubdomain?;
    get enableWwwSubdomain(): boolean | cdktn.IResolvable;
    set enableWwwSubdomain(value: boolean | cdktn.IResolvable);
    resetEnableWwwSubdomain(): void;
    get enableWwwSubdomainInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _serviceArn?;
    get serviceArn(): string;
    set serviceArn(value: string);
    get serviceArnInput(): string | undefined;
    get status(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsApprunnerCustomDomainAssociationCertificateValidationRecordsPropertyToTerraform(struct?: AwsApprunnerCustomDomainAssociation.CertificateValidationRecordsProperty): any;
export declare function awsApprunnerCustomDomainAssociationCertificateValidationRecordsPropertyToHclTerraform(struct?: AwsApprunnerCustomDomainAssociation.CertificateValidationRecordsProperty): any;
export declare namespace AwsApprunnerCustomDomainAssociation {
    interface CertificateValidationRecordsProperty {
    }
    class CertificateValidationRecordsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CertificateValidationRecordsProperty | undefined;
        set internalValue(value: CertificateValidationRecordsProperty | undefined);
        get name(): string;
        get status(): string;
        get type(): string;
        get value(): string;
    }
    class CertificateValidationRecordsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CertificateValidationRecordsPropertyOutputReference;
    }
}
