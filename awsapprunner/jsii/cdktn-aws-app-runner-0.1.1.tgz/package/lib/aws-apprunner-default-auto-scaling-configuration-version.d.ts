import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsApprunnerDefaultAutoScalingConfigurationVersionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_default_auto_scaling_configuration_version#auto_scaling_configuration_arn AwsApprunnerDefaultAutoScalingConfigurationVersion#auto_scaling_configuration_arn}
    */
    readonly autoScalingConfigurationArn: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_default_auto_scaling_configuration_version#region AwsApprunnerDefaultAutoScalingConfigurationVersion#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_default_auto_scaling_configuration_version aws_apprunner_default_auto_scaling_configuration_version}
*/
export declare class AwsApprunnerDefaultAutoScalingConfigurationVersion extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_apprunner_default_auto_scaling_configuration_version";
    /**
    * Generates CDKTN code for importing a AwsApprunnerDefaultAutoScalingConfigurationVersion resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsApprunnerDefaultAutoScalingConfigurationVersion to import
    * @param importFromId The id of the existing AwsApprunnerDefaultAutoScalingConfigurationVersion that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_default_auto_scaling_configuration_version#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsApprunnerDefaultAutoScalingConfigurationVersion to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_default_auto_scaling_configuration_version aws_apprunner_default_auto_scaling_configuration_version} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsApprunnerDefaultAutoScalingConfigurationVersionConfig
    */
    constructor(scope: Construct, id: string, config: AwsApprunnerDefaultAutoScalingConfigurationVersionConfig);
    private _autoScalingConfigurationArn?;
    get autoScalingConfigurationArn(): string;
    set autoScalingConfigurationArn(value: string);
    get autoScalingConfigurationArnInput(): string | undefined;
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
