import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsApprunnerServiceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#auto_scaling_configuration_arn AwsApprunnerService#auto_scaling_configuration_arn}
    */
    readonly autoScalingConfigurationArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#id AwsApprunnerService#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#region AwsApprunnerService#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#service_name AwsApprunnerService#service_name}
    */
    readonly serviceName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#tags AwsApprunnerService#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#tags_all AwsApprunnerService#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * encryption_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#encryption_configuration AwsApprunnerService#encryption_configuration}
    */
    readonly encryptionConfiguration?: AwsApprunnerService.EncryptionConfigurationProperty;
    /**
    * health_check_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#health_check_configuration AwsApprunnerService#health_check_configuration}
    */
    readonly healthCheckConfiguration?: AwsApprunnerService.HealthCheckConfigurationProperty;
    /**
    * instance_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#instance_configuration AwsApprunnerService#instance_configuration}
    */
    readonly instanceConfiguration?: AwsApprunnerService.InstanceConfigurationProperty;
    /**
    * network_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#network_configuration AwsApprunnerService#network_configuration}
    */
    readonly networkConfiguration?: AwsApprunnerService.NetworkConfigurationProperty;
    /**
    * observability_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#observability_configuration AwsApprunnerService#observability_configuration}
    */
    readonly observabilityConfiguration?: AwsApprunnerService.ObservabilityConfigurationProperty;
    /**
    * source_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#source_configuration AwsApprunnerService#source_configuration}
    */
    readonly sourceConfiguration: AwsApprunnerService.SourceConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service aws_apprunner_service}
*/
export declare class AwsApprunnerService extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_apprunner_service";
    /**
    * Generates CDKTN code for importing a AwsApprunnerService resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsApprunnerService to import
    * @param importFromId The id of the existing AwsApprunnerService that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsApprunnerService to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service aws_apprunner_service} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsApprunnerServiceConfig
    */
    constructor(scope: Construct, id: string, config: AwsApprunnerServiceConfig);
    get arn(): string;
    private _autoScalingConfigurationArn?;
    get autoScalingConfigurationArn(): string;
    set autoScalingConfigurationArn(value: string);
    resetAutoScalingConfigurationArn(): void;
    get autoScalingConfigurationArnInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get serviceId(): string;
    private _serviceName?;
    get serviceName(): string;
    set serviceName(value: string);
    get serviceNameInput(): string | undefined;
    get serviceUrl(): string;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _encryptionConfiguration;
    get encryptionConfiguration(): AwsApprunnerService.EncryptionConfigurationPropertyOutputReference;
    putEncryptionConfiguration(value: AwsApprunnerService.EncryptionConfigurationProperty): void;
    resetEncryptionConfiguration(): void;
    get encryptionConfigurationInput(): AwsApprunnerService.EncryptionConfigurationProperty | undefined;
    private _healthCheckConfiguration;
    get healthCheckConfiguration(): AwsApprunnerService.HealthCheckConfigurationPropertyOutputReference;
    putHealthCheckConfiguration(value: AwsApprunnerService.HealthCheckConfigurationProperty): void;
    resetHealthCheckConfiguration(): void;
    get healthCheckConfigurationInput(): AwsApprunnerService.HealthCheckConfigurationProperty | undefined;
    private _instanceConfiguration;
    get instanceConfiguration(): AwsApprunnerService.InstanceConfigurationPropertyOutputReference;
    putInstanceConfiguration(value: AwsApprunnerService.InstanceConfigurationProperty): void;
    resetInstanceConfiguration(): void;
    get instanceConfigurationInput(): AwsApprunnerService.InstanceConfigurationProperty | undefined;
    private _networkConfiguration;
    get networkConfiguration(): AwsApprunnerService.NetworkConfigurationPropertyOutputReference;
    putNetworkConfiguration(value: AwsApprunnerService.NetworkConfigurationProperty): void;
    resetNetworkConfiguration(): void;
    get networkConfigurationInput(): AwsApprunnerService.NetworkConfigurationProperty | undefined;
    private _observabilityConfiguration;
    get observabilityConfiguration(): AwsApprunnerService.ObservabilityConfigurationPropertyOutputReference;
    putObservabilityConfiguration(value: AwsApprunnerService.ObservabilityConfigurationProperty): void;
    resetObservabilityConfiguration(): void;
    get observabilityConfigurationInput(): AwsApprunnerService.ObservabilityConfigurationProperty | undefined;
    private _sourceConfiguration;
    get sourceConfiguration(): AwsApprunnerService.SourceConfigurationPropertyOutputReference;
    putSourceConfiguration(value: AwsApprunnerService.SourceConfigurationProperty): void;
    get sourceConfigurationInput(): AwsApprunnerService.SourceConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsApprunnerServiceEncryptionConfigurationPropertyToTerraform(struct?: AwsApprunnerService.EncryptionConfigurationPropertyOutputReference | AwsApprunnerService.EncryptionConfigurationProperty): any;
export declare function awsApprunnerServiceEncryptionConfigurationPropertyToHclTerraform(struct?: AwsApprunnerService.EncryptionConfigurationPropertyOutputReference | AwsApprunnerService.EncryptionConfigurationProperty): any;
export declare function awsApprunnerServiceHealthCheckConfigurationPropertyToTerraform(struct?: AwsApprunnerService.HealthCheckConfigurationPropertyOutputReference | AwsApprunnerService.HealthCheckConfigurationProperty): any;
export declare function awsApprunnerServiceHealthCheckConfigurationPropertyToHclTerraform(struct?: AwsApprunnerService.HealthCheckConfigurationPropertyOutputReference | AwsApprunnerService.HealthCheckConfigurationProperty): any;
export declare function awsApprunnerServiceInstanceConfigurationPropertyToTerraform(struct?: AwsApprunnerService.InstanceConfigurationPropertyOutputReference | AwsApprunnerService.InstanceConfigurationProperty): any;
export declare function awsApprunnerServiceInstanceConfigurationPropertyToHclTerraform(struct?: AwsApprunnerService.InstanceConfigurationPropertyOutputReference | AwsApprunnerService.InstanceConfigurationProperty): any;
export declare function awsApprunnerServiceEgressConfigurationPropertyToTerraform(struct?: AwsApprunnerService.EgressConfigurationPropertyOutputReference | AwsApprunnerService.EgressConfigurationProperty): any;
export declare function awsApprunnerServiceEgressConfigurationPropertyToHclTerraform(struct?: AwsApprunnerService.EgressConfigurationPropertyOutputReference | AwsApprunnerService.EgressConfigurationProperty): any;
export declare function awsApprunnerServiceIngressConfigurationPropertyToTerraform(struct?: AwsApprunnerService.IngressConfigurationPropertyOutputReference | AwsApprunnerService.IngressConfigurationProperty): any;
export declare function awsApprunnerServiceIngressConfigurationPropertyToHclTerraform(struct?: AwsApprunnerService.IngressConfigurationPropertyOutputReference | AwsApprunnerService.IngressConfigurationProperty): any;
export declare function awsApprunnerServiceNetworkConfigurationPropertyToTerraform(struct?: AwsApprunnerService.NetworkConfigurationPropertyOutputReference | AwsApprunnerService.NetworkConfigurationProperty): any;
export declare function awsApprunnerServiceNetworkConfigurationPropertyToHclTerraform(struct?: AwsApprunnerService.NetworkConfigurationPropertyOutputReference | AwsApprunnerService.NetworkConfigurationProperty): any;
export declare function awsApprunnerServiceObservabilityConfigurationPropertyToTerraform(struct?: AwsApprunnerService.ObservabilityConfigurationPropertyOutputReference | AwsApprunnerService.ObservabilityConfigurationProperty): any;
export declare function awsApprunnerServiceObservabilityConfigurationPropertyToHclTerraform(struct?: AwsApprunnerService.ObservabilityConfigurationPropertyOutputReference | AwsApprunnerService.ObservabilityConfigurationProperty): any;
export declare function awsApprunnerServiceAuthenticationConfigurationPropertyToTerraform(struct?: AwsApprunnerService.AuthenticationConfigurationPropertyOutputReference | AwsApprunnerService.AuthenticationConfigurationProperty): any;
export declare function awsApprunnerServiceAuthenticationConfigurationPropertyToHclTerraform(struct?: AwsApprunnerService.AuthenticationConfigurationPropertyOutputReference | AwsApprunnerService.AuthenticationConfigurationProperty): any;
export declare function awsApprunnerServiceCodeConfigurationValuesPropertyToTerraform(struct?: AwsApprunnerService.CodeConfigurationValuesPropertyOutputReference | AwsApprunnerService.CodeConfigurationValuesProperty): any;
export declare function awsApprunnerServiceCodeConfigurationValuesPropertyToHclTerraform(struct?: AwsApprunnerService.CodeConfigurationValuesPropertyOutputReference | AwsApprunnerService.CodeConfigurationValuesProperty): any;
export declare function awsApprunnerServiceCodeConfigurationPropertyToTerraform(struct?: AwsApprunnerService.CodeConfigurationPropertyOutputReference | AwsApprunnerService.CodeConfigurationProperty): any;
export declare function awsApprunnerServiceCodeConfigurationPropertyToHclTerraform(struct?: AwsApprunnerService.CodeConfigurationPropertyOutputReference | AwsApprunnerService.CodeConfigurationProperty): any;
export declare function awsApprunnerServiceSourceCodeVersionPropertyToTerraform(struct?: AwsApprunnerService.SourceCodeVersionPropertyOutputReference | AwsApprunnerService.SourceCodeVersionProperty): any;
export declare function awsApprunnerServiceSourceCodeVersionPropertyToHclTerraform(struct?: AwsApprunnerService.SourceCodeVersionPropertyOutputReference | AwsApprunnerService.SourceCodeVersionProperty): any;
export declare function awsApprunnerServiceCodeRepositoryPropertyToTerraform(struct?: AwsApprunnerService.CodeRepositoryPropertyOutputReference | AwsApprunnerService.CodeRepositoryProperty): any;
export declare function awsApprunnerServiceCodeRepositoryPropertyToHclTerraform(struct?: AwsApprunnerService.CodeRepositoryPropertyOutputReference | AwsApprunnerService.CodeRepositoryProperty): any;
export declare function awsApprunnerServiceImageConfigurationPropertyToTerraform(struct?: AwsApprunnerService.ImageConfigurationPropertyOutputReference | AwsApprunnerService.ImageConfigurationProperty): any;
export declare function awsApprunnerServiceImageConfigurationPropertyToHclTerraform(struct?: AwsApprunnerService.ImageConfigurationPropertyOutputReference | AwsApprunnerService.ImageConfigurationProperty): any;
export declare function awsApprunnerServiceImageRepositoryPropertyToTerraform(struct?: AwsApprunnerService.ImageRepositoryPropertyOutputReference | AwsApprunnerService.ImageRepositoryProperty): any;
export declare function awsApprunnerServiceImageRepositoryPropertyToHclTerraform(struct?: AwsApprunnerService.ImageRepositoryPropertyOutputReference | AwsApprunnerService.ImageRepositoryProperty): any;
export declare function awsApprunnerServiceSourceConfigurationPropertyToTerraform(struct?: AwsApprunnerService.SourceConfigurationPropertyOutputReference | AwsApprunnerService.SourceConfigurationProperty): any;
export declare function awsApprunnerServiceSourceConfigurationPropertyToHclTerraform(struct?: AwsApprunnerService.SourceConfigurationPropertyOutputReference | AwsApprunnerService.SourceConfigurationProperty): any;
export declare namespace AwsApprunnerService {
    interface EncryptionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#kms_key AwsApprunnerService#kms_key}
        */
        readonly kmsKey: string;
    }
    class EncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncryptionConfigurationProperty | undefined;
        set internalValue(value: EncryptionConfigurationProperty | undefined);
        private _kmsKey?;
        get kmsKey(): string;
        set kmsKey(value: string);
        get kmsKeyInput(): string | undefined;
    }
    interface HealthCheckConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#healthy_threshold AwsApprunnerService#healthy_threshold}
        */
        readonly healthyThreshold?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#interval AwsApprunnerService#interval}
        */
        readonly interval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#path AwsApprunnerService#path}
        */
        readonly path?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#protocol AwsApprunnerService#protocol}
        */
        readonly protocol?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#timeout AwsApprunnerService#timeout}
        */
        readonly timeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#unhealthy_threshold AwsApprunnerService#unhealthy_threshold}
        */
        readonly unhealthyThreshold?: number;
    }
    class HealthCheckConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HealthCheckConfigurationProperty | undefined;
        set internalValue(value: HealthCheckConfigurationProperty | undefined);
        private _healthyThreshold?;
        get healthyThreshold(): number;
        set healthyThreshold(value: number);
        resetHealthyThreshold(): void;
        get healthyThresholdInput(): number | undefined;
        private _interval?;
        get interval(): number;
        set interval(value: number);
        resetInterval(): void;
        get intervalInput(): number | undefined;
        private _path?;
        get path(): string;
        set path(value: string);
        resetPath(): void;
        get pathInput(): string | undefined;
        private _protocol?;
        get protocol(): string;
        set protocol(value: string);
        resetProtocol(): void;
        get protocolInput(): string | undefined;
        private _timeout?;
        get timeout(): number;
        set timeout(value: number);
        resetTimeout(): void;
        get timeoutInput(): number | undefined;
        private _unhealthyThreshold?;
        get unhealthyThreshold(): number;
        set unhealthyThreshold(value: number);
        resetUnhealthyThreshold(): void;
        get unhealthyThresholdInput(): number | undefined;
    }
    interface InstanceConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#cpu AwsApprunnerService#cpu}
        */
        readonly cpu?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#instance_role_arn AwsApprunnerService#instance_role_arn}
        */
        readonly instanceRoleArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#memory AwsApprunnerService#memory}
        */
        readonly memory?: string;
    }
    class InstanceConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InstanceConfigurationProperty | undefined;
        set internalValue(value: InstanceConfigurationProperty | undefined);
        private _cpu?;
        get cpu(): string;
        set cpu(value: string);
        resetCpu(): void;
        get cpuInput(): string | undefined;
        private _instanceRoleArn?;
        get instanceRoleArn(): string;
        set instanceRoleArn(value: string);
        resetInstanceRoleArn(): void;
        get instanceRoleArnInput(): string | undefined;
        private _memory?;
        get memory(): string;
        set memory(value: string);
        resetMemory(): void;
        get memoryInput(): string | undefined;
    }
    interface EgressConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#egress_type AwsApprunnerService#egress_type}
        */
        readonly egressType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#vpc_connector_arn AwsApprunnerService#vpc_connector_arn}
        */
        readonly vpcConnectorArn?: string;
    }
    class EgressConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EgressConfigurationProperty | undefined;
        set internalValue(value: EgressConfigurationProperty | undefined);
        private _egressType?;
        get egressType(): string;
        set egressType(value: string);
        resetEgressType(): void;
        get egressTypeInput(): string | undefined;
        private _vpcConnectorArn?;
        get vpcConnectorArn(): string;
        set vpcConnectorArn(value: string);
        resetVpcConnectorArn(): void;
        get vpcConnectorArnInput(): string | undefined;
    }
    interface IngressConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#is_publicly_accessible AwsApprunnerService#is_publicly_accessible}
        */
        readonly isPubliclyAccessible?: boolean | cdktn.IResolvable;
    }
    class IngressConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IngressConfigurationProperty | undefined;
        set internalValue(value: IngressConfigurationProperty | undefined);
        private _isPubliclyAccessible?;
        get isPubliclyAccessible(): boolean | cdktn.IResolvable;
        set isPubliclyAccessible(value: boolean | cdktn.IResolvable);
        resetIsPubliclyAccessible(): void;
        get isPubliclyAccessibleInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface NetworkConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#ip_address_type AwsApprunnerService#ip_address_type}
        */
        readonly ipAddressType?: string;
        /**
        * egress_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#egress_configuration AwsApprunnerService#egress_configuration}
        */
        readonly egressConfiguration?: EgressConfigurationProperty;
        /**
        * ingress_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#ingress_configuration AwsApprunnerService#ingress_configuration}
        */
        readonly ingressConfiguration?: IngressConfigurationProperty;
    }
    class NetworkConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NetworkConfigurationProperty | undefined;
        set internalValue(value: NetworkConfigurationProperty | undefined);
        private _ipAddressType?;
        get ipAddressType(): string;
        set ipAddressType(value: string);
        resetIpAddressType(): void;
        get ipAddressTypeInput(): string | undefined;
        private _egressConfiguration;
        get egressConfiguration(): EgressConfigurationPropertyOutputReference;
        putEgressConfiguration(value: EgressConfigurationProperty): void;
        resetEgressConfiguration(): void;
        get egressConfigurationInput(): EgressConfigurationProperty | undefined;
        private _ingressConfiguration;
        get ingressConfiguration(): IngressConfigurationPropertyOutputReference;
        putIngressConfiguration(value: IngressConfigurationProperty): void;
        resetIngressConfiguration(): void;
        get ingressConfigurationInput(): IngressConfigurationProperty | undefined;
    }
    interface ObservabilityConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#observability_configuration_arn AwsApprunnerService#observability_configuration_arn}
        */
        readonly observabilityConfigurationArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#observability_enabled AwsApprunnerService#observability_enabled}
        */
        readonly observabilityEnabled: boolean | cdktn.IResolvable;
    }
    class ObservabilityConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ObservabilityConfigurationProperty | undefined;
        set internalValue(value: ObservabilityConfigurationProperty | undefined);
        private _observabilityConfigurationArn?;
        get observabilityConfigurationArn(): string;
        set observabilityConfigurationArn(value: string);
        resetObservabilityConfigurationArn(): void;
        get observabilityConfigurationArnInput(): string | undefined;
        private _observabilityEnabled?;
        get observabilityEnabled(): boolean | cdktn.IResolvable;
        set observabilityEnabled(value: boolean | cdktn.IResolvable);
        get observabilityEnabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface AuthenticationConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#access_role_arn AwsApprunnerService#access_role_arn}
        */
        readonly accessRoleArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#connection_arn AwsApprunnerService#connection_arn}
        */
        readonly connectionArn?: string;
    }
    class AuthenticationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AuthenticationConfigurationProperty | undefined;
        set internalValue(value: AuthenticationConfigurationProperty | undefined);
        private _accessRoleArn?;
        get accessRoleArn(): string;
        set accessRoleArn(value: string);
        resetAccessRoleArn(): void;
        get accessRoleArnInput(): string | undefined;
        private _connectionArn?;
        get connectionArn(): string;
        set connectionArn(value: string);
        resetConnectionArn(): void;
        get connectionArnInput(): string | undefined;
    }
    interface CodeConfigurationValuesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#build_command AwsApprunnerService#build_command}
        */
        readonly buildCommand?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#port AwsApprunnerService#port}
        */
        readonly port?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#runtime AwsApprunnerService#runtime}
        */
        readonly runtime: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#runtime_environment_secrets AwsApprunnerService#runtime_environment_secrets}
        */
        readonly runtimeEnvironmentSecrets?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#runtime_environment_variables AwsApprunnerService#runtime_environment_variables}
        */
        readonly runtimeEnvironmentVariables?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#start_command AwsApprunnerService#start_command}
        */
        readonly startCommand?: string;
    }
    class CodeConfigurationValuesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CodeConfigurationValuesProperty | undefined;
        set internalValue(value: CodeConfigurationValuesProperty | undefined);
        private _buildCommand?;
        get buildCommand(): string;
        set buildCommand(value: string);
        resetBuildCommand(): void;
        get buildCommandInput(): string | undefined;
        private _port?;
        get port(): string;
        set port(value: string);
        resetPort(): void;
        get portInput(): string | undefined;
        private _runtime?;
        get runtime(): string;
        set runtime(value: string);
        get runtimeInput(): string | undefined;
        private _runtimeEnvironmentSecrets?;
        get runtimeEnvironmentSecrets(): {
            [key: string]: string;
        };
        set runtimeEnvironmentSecrets(value: {
            [key: string]: string;
        });
        resetRuntimeEnvironmentSecrets(): void;
        get runtimeEnvironmentSecretsInput(): {
            [key: string]: string;
        } | undefined;
        private _runtimeEnvironmentVariables?;
        get runtimeEnvironmentVariables(): {
            [key: string]: string;
        };
        set runtimeEnvironmentVariables(value: {
            [key: string]: string;
        });
        resetRuntimeEnvironmentVariables(): void;
        get runtimeEnvironmentVariablesInput(): {
            [key: string]: string;
        } | undefined;
        private _startCommand?;
        get startCommand(): string;
        set startCommand(value: string);
        resetStartCommand(): void;
        get startCommandInput(): string | undefined;
    }
    interface CodeConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#configuration_source AwsApprunnerService#configuration_source}
        */
        readonly configurationSource: string;
        /**
        * code_configuration_values block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#code_configuration_values AwsApprunnerService#code_configuration_values}
        */
        readonly codeConfigurationValues?: CodeConfigurationValuesProperty;
    }
    class CodeConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CodeConfigurationProperty | undefined;
        set internalValue(value: CodeConfigurationProperty | undefined);
        private _configurationSource?;
        get configurationSource(): string;
        set configurationSource(value: string);
        get configurationSourceInput(): string | undefined;
        private _codeConfigurationValues;
        get codeConfigurationValues(): CodeConfigurationValuesPropertyOutputReference;
        putCodeConfigurationValues(value: CodeConfigurationValuesProperty): void;
        resetCodeConfigurationValues(): void;
        get codeConfigurationValuesInput(): CodeConfigurationValuesProperty | undefined;
    }
    interface SourceCodeVersionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#type AwsApprunnerService#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#value AwsApprunnerService#value}
        */
        readonly value: string;
    }
    class SourceCodeVersionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceCodeVersionProperty | undefined;
        set internalValue(value: SourceCodeVersionProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    interface CodeRepositoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#repository_url AwsApprunnerService#repository_url}
        */
        readonly repositoryUrl: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#source_directory AwsApprunnerService#source_directory}
        */
        readonly sourceDirectory?: string;
        /**
        * code_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#code_configuration AwsApprunnerService#code_configuration}
        */
        readonly codeConfiguration?: CodeConfigurationProperty;
        /**
        * source_code_version block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#source_code_version AwsApprunnerService#source_code_version}
        */
        readonly sourceCodeVersion: SourceCodeVersionProperty;
    }
    class CodeRepositoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CodeRepositoryProperty | undefined;
        set internalValue(value: CodeRepositoryProperty | undefined);
        private _repositoryUrl?;
        get repositoryUrl(): string;
        set repositoryUrl(value: string);
        get repositoryUrlInput(): string | undefined;
        private _sourceDirectory?;
        get sourceDirectory(): string;
        set sourceDirectory(value: string);
        resetSourceDirectory(): void;
        get sourceDirectoryInput(): string | undefined;
        private _codeConfiguration;
        get codeConfiguration(): CodeConfigurationPropertyOutputReference;
        putCodeConfiguration(value: CodeConfigurationProperty): void;
        resetCodeConfiguration(): void;
        get codeConfigurationInput(): CodeConfigurationProperty | undefined;
        private _sourceCodeVersion;
        get sourceCodeVersion(): SourceCodeVersionPropertyOutputReference;
        putSourceCodeVersion(value: SourceCodeVersionProperty): void;
        get sourceCodeVersionInput(): SourceCodeVersionProperty | undefined;
    }
    interface ImageConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#port AwsApprunnerService#port}
        */
        readonly port?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#runtime_environment_secrets AwsApprunnerService#runtime_environment_secrets}
        */
        readonly runtimeEnvironmentSecrets?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#runtime_environment_variables AwsApprunnerService#runtime_environment_variables}
        */
        readonly runtimeEnvironmentVariables?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#start_command AwsApprunnerService#start_command}
        */
        readonly startCommand?: string;
    }
    class ImageConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ImageConfigurationProperty | undefined;
        set internalValue(value: ImageConfigurationProperty | undefined);
        private _port?;
        get port(): string;
        set port(value: string);
        resetPort(): void;
        get portInput(): string | undefined;
        private _runtimeEnvironmentSecrets?;
        get runtimeEnvironmentSecrets(): {
            [key: string]: string;
        };
        set runtimeEnvironmentSecrets(value: {
            [key: string]: string;
        });
        resetRuntimeEnvironmentSecrets(): void;
        get runtimeEnvironmentSecretsInput(): {
            [key: string]: string;
        } | undefined;
        private _runtimeEnvironmentVariables?;
        get runtimeEnvironmentVariables(): {
            [key: string]: string;
        };
        set runtimeEnvironmentVariables(value: {
            [key: string]: string;
        });
        resetRuntimeEnvironmentVariables(): void;
        get runtimeEnvironmentVariablesInput(): {
            [key: string]: string;
        } | undefined;
        private _startCommand?;
        get startCommand(): string;
        set startCommand(value: string);
        resetStartCommand(): void;
        get startCommandInput(): string | undefined;
    }
    interface ImageRepositoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#image_identifier AwsApprunnerService#image_identifier}
        */
        readonly imageIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#image_repository_type AwsApprunnerService#image_repository_type}
        */
        readonly imageRepositoryType: string;
        /**
        * image_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#image_configuration AwsApprunnerService#image_configuration}
        */
        readonly imageConfiguration?: ImageConfigurationProperty;
    }
    class ImageRepositoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ImageRepositoryProperty | undefined;
        set internalValue(value: ImageRepositoryProperty | undefined);
        private _imageIdentifier?;
        get imageIdentifier(): string;
        set imageIdentifier(value: string);
        get imageIdentifierInput(): string | undefined;
        private _imageRepositoryType?;
        get imageRepositoryType(): string;
        set imageRepositoryType(value: string);
        get imageRepositoryTypeInput(): string | undefined;
        private _imageConfiguration;
        get imageConfiguration(): ImageConfigurationPropertyOutputReference;
        putImageConfiguration(value: ImageConfigurationProperty): void;
        resetImageConfiguration(): void;
        get imageConfigurationInput(): ImageConfigurationProperty | undefined;
    }
    interface SourceConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#auto_deployments_enabled AwsApprunnerService#auto_deployments_enabled}
        */
        readonly autoDeploymentsEnabled?: boolean | cdktn.IResolvable;
        /**
        * authentication_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#authentication_configuration AwsApprunnerService#authentication_configuration}
        */
        readonly authenticationConfiguration?: AuthenticationConfigurationProperty;
        /**
        * code_repository block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#code_repository AwsApprunnerService#code_repository}
        */
        readonly codeRepository?: CodeRepositoryProperty;
        /**
        * image_repository block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#image_repository AwsApprunnerService#image_repository}
        */
        readonly imageRepository?: ImageRepositoryProperty;
    }
    class SourceConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceConfigurationProperty | undefined;
        set internalValue(value: SourceConfigurationProperty | undefined);
        private _autoDeploymentsEnabled?;
        get autoDeploymentsEnabled(): boolean | cdktn.IResolvable;
        set autoDeploymentsEnabled(value: boolean | cdktn.IResolvable);
        resetAutoDeploymentsEnabled(): void;
        get autoDeploymentsEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _authenticationConfiguration;
        get authenticationConfiguration(): AuthenticationConfigurationPropertyOutputReference;
        putAuthenticationConfiguration(value: AuthenticationConfigurationProperty): void;
        resetAuthenticationConfiguration(): void;
        get authenticationConfigurationInput(): AuthenticationConfigurationProperty | undefined;
        private _codeRepository;
        get codeRepository(): CodeRepositoryPropertyOutputReference;
        putCodeRepository(value: CodeRepositoryProperty): void;
        resetCodeRepository(): void;
        get codeRepositoryInput(): CodeRepositoryProperty | undefined;
        private _imageRepository;
        get imageRepository(): ImageRepositoryPropertyOutputReference;
        putImageRepository(value: ImageRepositoryProperty): void;
        resetImageRepository(): void;
        get imageRepositoryInput(): ImageRepositoryProperty | undefined;
    }
}
