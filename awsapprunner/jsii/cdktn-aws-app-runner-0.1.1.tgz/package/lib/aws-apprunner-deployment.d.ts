import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsApprunnerDeploymentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_deployment#region AwsApprunnerDeployment#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_deployment#service_arn AwsApprunnerDeployment#service_arn}
    */
    readonly serviceArn: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_deployment#timeouts AwsApprunnerDeployment#timeouts}
    */
    readonly timeouts?: AwsApprunnerDeployment.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_deployment aws_apprunner_deployment}
*/
export declare class AwsApprunnerDeployment extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_apprunner_deployment";
    /**
    * Generates CDKTN code for importing a AwsApprunnerDeployment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsApprunnerDeployment to import
    * @param importFromId The id of the existing AwsApprunnerDeployment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_deployment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsApprunnerDeployment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_deployment aws_apprunner_deployment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsApprunnerDeploymentConfig
    */
    constructor(scope: Construct, id: string, config: AwsApprunnerDeploymentConfig);
    get id(): string;
    get operationId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _serviceArn?;
    get serviceArn(): string;
    set serviceArn(value: string);
    get serviceArnInput(): string | undefined;
    get status(): string;
    private _timeouts;
    get timeouts(): AwsApprunnerDeployment.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsApprunnerDeployment.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsApprunnerDeployment.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsApprunnerDeploymentTimeoutsPropertyToTerraform(struct?: AwsApprunnerDeployment.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsApprunnerDeploymentTimeoutsPropertyToHclTerraform(struct?: AwsApprunnerDeployment.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsApprunnerDeployment {
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_deployment#create AwsApprunnerDeployment#create}
        */
        readonly create?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
    }
}
