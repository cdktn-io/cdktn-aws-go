import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsApprunnerObservabilityConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_observability_configuration#id AwsApprunnerObservabilityConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_observability_configuration#observability_configuration_name AwsApprunnerObservabilityConfiguration#observability_configuration_name}
    */
    readonly observabilityConfigurationName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_observability_configuration#region AwsApprunnerObservabilityConfiguration#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_observability_configuration#tags AwsApprunnerObservabilityConfiguration#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_observability_configuration#tags_all AwsApprunnerObservabilityConfiguration#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * trace_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_observability_configuration#trace_configuration AwsApprunnerObservabilityConfiguration#trace_configuration}
    */
    readonly traceConfiguration?: AwsApprunnerObservabilityConfiguration.TraceConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_observability_configuration aws_apprunner_observability_configuration}
*/
export declare class AwsApprunnerObservabilityConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_apprunner_observability_configuration";
    /**
    * Generates CDKTN code for importing a AwsApprunnerObservabilityConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsApprunnerObservabilityConfiguration to import
    * @param importFromId The id of the existing AwsApprunnerObservabilityConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_observability_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsApprunnerObservabilityConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_observability_configuration aws_apprunner_observability_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsApprunnerObservabilityConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AwsApprunnerObservabilityConfigurationConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get latest(): cdktn.IResolvable;
    private _observabilityConfigurationName?;
    get observabilityConfigurationName(): string;
    set observabilityConfigurationName(value: string);
    get observabilityConfigurationNameInput(): string | undefined;
    get observabilityConfigurationRevision(): number;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _traceConfiguration;
    get traceConfiguration(): AwsApprunnerObservabilityConfiguration.TraceConfigurationPropertyOutputReference;
    putTraceConfiguration(value: AwsApprunnerObservabilityConfiguration.TraceConfigurationProperty): void;
    resetTraceConfiguration(): void;
    get traceConfigurationInput(): AwsApprunnerObservabilityConfiguration.TraceConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsApprunnerObservabilityConfigurationTraceConfigurationPropertyToTerraform(struct?: AwsApprunnerObservabilityConfiguration.TraceConfigurationPropertyOutputReference | AwsApprunnerObservabilityConfiguration.TraceConfigurationProperty): any;
export declare function awsApprunnerObservabilityConfigurationTraceConfigurationPropertyToHclTerraform(struct?: AwsApprunnerObservabilityConfiguration.TraceConfigurationPropertyOutputReference | AwsApprunnerObservabilityConfiguration.TraceConfigurationProperty): any;
export declare namespace AwsApprunnerObservabilityConfiguration {
    interface TraceConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_observability_configuration#vendor AwsApprunnerObservabilityConfiguration#vendor}
        */
        readonly vendor?: string;
    }
    class TraceConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TraceConfigurationProperty | undefined;
        set internalValue(value: TraceConfigurationProperty | undefined);
        private _vendor?;
        get vendor(): string;
        set vendor(value: string);
        resetVendor(): void;
        get vendorInput(): string | undefined;
    }
}
