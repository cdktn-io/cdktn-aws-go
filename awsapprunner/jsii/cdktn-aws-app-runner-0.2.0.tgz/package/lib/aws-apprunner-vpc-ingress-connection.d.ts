import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfVpcIngressConnectionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_vpc_ingress_connection#id TfVpcIngressConnection#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_vpc_ingress_connection#name TfVpcIngressConnection#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_vpc_ingress_connection#region TfVpcIngressConnection#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_vpc_ingress_connection#service_arn TfVpcIngressConnection#service_arn}
    */
    readonly serviceArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_vpc_ingress_connection#tags TfVpcIngressConnection#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_vpc_ingress_connection#tags_all TfVpcIngressConnection#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * ingress_vpc_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_vpc_ingress_connection#ingress_vpc_configuration TfVpcIngressConnection#ingress_vpc_configuration}
    */
    readonly ingressVpcConfiguration: TfVpcIngressConnection.IngressVpcConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_vpc_ingress_connection aws_apprunner_vpc_ingress_connection}
*/
export declare class TfVpcIngressConnection extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_apprunner_vpc_ingress_connection";
    /**
    * Generates CDKTN code for importing a TfVpcIngressConnection resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfVpcIngressConnection to import
    * @param importFromId The id of the existing TfVpcIngressConnection that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_vpc_ingress_connection#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfVpcIngressConnection to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_vpc_ingress_connection aws_apprunner_vpc_ingress_connection} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfVpcIngressConnectionConfig
    */
    constructor(scope: Construct, id: string, config: TfVpcIngressConnectionConfig);
    get arn(): string;
    get domainName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _serviceArn?;
    get serviceArn(): string;
    set serviceArn(value: string);
    get serviceArnInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _ingressVpcConfiguration;
    get ingressVpcConfiguration(): TfVpcIngressConnection.IngressVpcConfigurationPropertyOutputReference;
    putIngressVpcConfiguration(value: TfVpcIngressConnection.IngressVpcConfigurationProperty): void;
    get ingressVpcConfigurationInput(): TfVpcIngressConnection.IngressVpcConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfVpcIngressConnectionIngressVpcConfigurationPropertyToTerraform(struct?: TfVpcIngressConnection.IngressVpcConfigurationPropertyOutputReference | TfVpcIngressConnection.IngressVpcConfigurationProperty): any;
export declare function tfVpcIngressConnectionIngressVpcConfigurationPropertyToHclTerraform(struct?: TfVpcIngressConnection.IngressVpcConfigurationPropertyOutputReference | TfVpcIngressConnection.IngressVpcConfigurationProperty): any;
export declare namespace TfVpcIngressConnection {
    interface IngressVpcConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_vpc_ingress_connection#vpc_endpoint_id TfVpcIngressConnection#vpc_endpoint_id}
        */
        readonly vpcEndpointId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_vpc_ingress_connection#vpc_id TfVpcIngressConnection#vpc_id}
        */
        readonly vpcId?: string;
    }
    class IngressVpcConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IngressVpcConfigurationProperty | undefined;
        set internalValue(value: IngressVpcConfigurationProperty | undefined);
        private _vpcEndpointId?;
        get vpcEndpointId(): string;
        set vpcEndpointId(value: string);
        resetVpcEndpointId(): void;
        get vpcEndpointIdInput(): string | undefined;
        private _vpcId?;
        get vpcId(): string;
        set vpcId(value: string);
        resetVpcId(): void;
        get vpcIdInput(): string | undefined;
    }
}
