import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfServiceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#auto_scaling_configuration_arn TfService#auto_scaling_configuration_arn}
    */
    readonly autoScalingConfigurationArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#id TfService#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#region TfService#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#service_name TfService#service_name}
    */
    readonly serviceName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#tags TfService#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#tags_all TfService#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * encryption_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#encryption_configuration TfService#encryption_configuration}
    */
    readonly encryptionConfiguration?: TfService.EncryptionConfigurationProperty;
    /**
    * health_check_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#health_check_configuration TfService#health_check_configuration}
    */
    readonly healthCheckConfiguration?: TfService.HealthCheckConfigurationProperty;
    /**
    * instance_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#instance_configuration TfService#instance_configuration}
    */
    readonly instanceConfiguration?: TfService.InstanceConfigurationProperty;
    /**
    * network_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#network_configuration TfService#network_configuration}
    */
    readonly networkConfiguration?: TfService.NetworkConfigurationProperty;
    /**
    * observability_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#observability_configuration TfService#observability_configuration}
    */
    readonly observabilityConfiguration?: TfService.ObservabilityConfigurationProperty;
    /**
    * source_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#source_configuration TfService#source_configuration}
    */
    readonly sourceConfiguration: TfService.SourceConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service aws_apprunner_service}
*/
export declare class TfService extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_apprunner_service";
    /**
    * Generates CDKTN code for importing a TfService resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfService to import
    * @param importFromId The id of the existing TfService that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfService to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service aws_apprunner_service} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfServiceConfig
    */
    constructor(scope: Construct, id: string, config: TfServiceConfig);
    get arn(): string;
    private _autoScalingConfigurationArn?;
    get autoScalingConfigurationArn(): string;
    set autoScalingConfigurationArn(value: string);
    resetAutoScalingConfigurationArn(): void;
    get autoScalingConfigurationArnInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get serviceId(): string;
    private _serviceName?;
    get serviceName(): string;
    set serviceName(value: string);
    get serviceNameInput(): string | undefined;
    get serviceUrl(): string;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _encryptionConfiguration;
    get encryptionConfiguration(): TfService.EncryptionConfigurationPropertyOutputReference;
    putEncryptionConfiguration(value: TfService.EncryptionConfigurationProperty): void;
    resetEncryptionConfiguration(): void;
    get encryptionConfigurationInput(): TfService.EncryptionConfigurationProperty | undefined;
    private _healthCheckConfiguration;
    get healthCheckConfiguration(): TfService.HealthCheckConfigurationPropertyOutputReference;
    putHealthCheckConfiguration(value: TfService.HealthCheckConfigurationProperty): void;
    resetHealthCheckConfiguration(): void;
    get healthCheckConfigurationInput(): TfService.HealthCheckConfigurationProperty | undefined;
    private _instanceConfiguration;
    get instanceConfiguration(): TfService.InstanceConfigurationPropertyOutputReference;
    putInstanceConfiguration(value: TfService.InstanceConfigurationProperty): void;
    resetInstanceConfiguration(): void;
    get instanceConfigurationInput(): TfService.InstanceConfigurationProperty | undefined;
    private _networkConfiguration;
    get networkConfiguration(): TfService.NetworkConfigurationPropertyOutputReference;
    putNetworkConfiguration(value: TfService.NetworkConfigurationProperty): void;
    resetNetworkConfiguration(): void;
    get networkConfigurationInput(): TfService.NetworkConfigurationProperty | undefined;
    private _observabilityConfiguration;
    get observabilityConfiguration(): TfService.ObservabilityConfigurationPropertyOutputReference;
    putObservabilityConfiguration(value: TfService.ObservabilityConfigurationProperty): void;
    resetObservabilityConfiguration(): void;
    get observabilityConfigurationInput(): TfService.ObservabilityConfigurationProperty | undefined;
    private _sourceConfiguration;
    get sourceConfiguration(): TfService.SourceConfigurationPropertyOutputReference;
    putSourceConfiguration(value: TfService.SourceConfigurationProperty): void;
    get sourceConfigurationInput(): TfService.SourceConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfServiceEncryptionConfigurationPropertyToTerraform(struct?: TfService.EncryptionConfigurationPropertyOutputReference | TfService.EncryptionConfigurationProperty): any;
export declare function tfServiceEncryptionConfigurationPropertyToHclTerraform(struct?: TfService.EncryptionConfigurationPropertyOutputReference | TfService.EncryptionConfigurationProperty): any;
export declare function tfServiceHealthCheckConfigurationPropertyToTerraform(struct?: TfService.HealthCheckConfigurationPropertyOutputReference | TfService.HealthCheckConfigurationProperty): any;
export declare function tfServiceHealthCheckConfigurationPropertyToHclTerraform(struct?: TfService.HealthCheckConfigurationPropertyOutputReference | TfService.HealthCheckConfigurationProperty): any;
export declare function tfServiceInstanceConfigurationPropertyToTerraform(struct?: TfService.InstanceConfigurationPropertyOutputReference | TfService.InstanceConfigurationProperty): any;
export declare function tfServiceInstanceConfigurationPropertyToHclTerraform(struct?: TfService.InstanceConfigurationPropertyOutputReference | TfService.InstanceConfigurationProperty): any;
export declare function tfServiceEgressConfigurationPropertyToTerraform(struct?: TfService.EgressConfigurationPropertyOutputReference | TfService.EgressConfigurationProperty): any;
export declare function tfServiceEgressConfigurationPropertyToHclTerraform(struct?: TfService.EgressConfigurationPropertyOutputReference | TfService.EgressConfigurationProperty): any;
export declare function tfServiceIngressConfigurationPropertyToTerraform(struct?: TfService.IngressConfigurationPropertyOutputReference | TfService.IngressConfigurationProperty): any;
export declare function tfServiceIngressConfigurationPropertyToHclTerraform(struct?: TfService.IngressConfigurationPropertyOutputReference | TfService.IngressConfigurationProperty): any;
export declare function tfServiceNetworkConfigurationPropertyToTerraform(struct?: TfService.NetworkConfigurationPropertyOutputReference | TfService.NetworkConfigurationProperty): any;
export declare function tfServiceNetworkConfigurationPropertyToHclTerraform(struct?: TfService.NetworkConfigurationPropertyOutputReference | TfService.NetworkConfigurationProperty): any;
export declare function tfServiceObservabilityConfigurationPropertyToTerraform(struct?: TfService.ObservabilityConfigurationPropertyOutputReference | TfService.ObservabilityConfigurationProperty): any;
export declare function tfServiceObservabilityConfigurationPropertyToHclTerraform(struct?: TfService.ObservabilityConfigurationPropertyOutputReference | TfService.ObservabilityConfigurationProperty): any;
export declare function tfServiceAuthenticationConfigurationPropertyToTerraform(struct?: TfService.AuthenticationConfigurationPropertyOutputReference | TfService.AuthenticationConfigurationProperty): any;
export declare function tfServiceAuthenticationConfigurationPropertyToHclTerraform(struct?: TfService.AuthenticationConfigurationPropertyOutputReference | TfService.AuthenticationConfigurationProperty): any;
export declare function tfServiceCodeConfigurationValuesPropertyToTerraform(struct?: TfService.CodeConfigurationValuesPropertyOutputReference | TfService.CodeConfigurationValuesProperty): any;
export declare function tfServiceCodeConfigurationValuesPropertyToHclTerraform(struct?: TfService.CodeConfigurationValuesPropertyOutputReference | TfService.CodeConfigurationValuesProperty): any;
export declare function tfServiceCodeConfigurationPropertyToTerraform(struct?: TfService.CodeConfigurationPropertyOutputReference | TfService.CodeConfigurationProperty): any;
export declare function tfServiceCodeConfigurationPropertyToHclTerraform(struct?: TfService.CodeConfigurationPropertyOutputReference | TfService.CodeConfigurationProperty): any;
export declare function tfServiceSourceCodeVersionPropertyToTerraform(struct?: TfService.SourceCodeVersionPropertyOutputReference | TfService.SourceCodeVersionProperty): any;
export declare function tfServiceSourceCodeVersionPropertyToHclTerraform(struct?: TfService.SourceCodeVersionPropertyOutputReference | TfService.SourceCodeVersionProperty): any;
export declare function tfServiceCodeRepositoryPropertyToTerraform(struct?: TfService.CodeRepositoryPropertyOutputReference | TfService.CodeRepositoryProperty): any;
export declare function tfServiceCodeRepositoryPropertyToHclTerraform(struct?: TfService.CodeRepositoryPropertyOutputReference | TfService.CodeRepositoryProperty): any;
export declare function tfServiceImageConfigurationPropertyToTerraform(struct?: TfService.ImageConfigurationPropertyOutputReference | TfService.ImageConfigurationProperty): any;
export declare function tfServiceImageConfigurationPropertyToHclTerraform(struct?: TfService.ImageConfigurationPropertyOutputReference | TfService.ImageConfigurationProperty): any;
export declare function tfServiceImageRepositoryPropertyToTerraform(struct?: TfService.ImageRepositoryPropertyOutputReference | TfService.ImageRepositoryProperty): any;
export declare function tfServiceImageRepositoryPropertyToHclTerraform(struct?: TfService.ImageRepositoryPropertyOutputReference | TfService.ImageRepositoryProperty): any;
export declare function tfServiceSourceConfigurationPropertyToTerraform(struct?: TfService.SourceConfigurationPropertyOutputReference | TfService.SourceConfigurationProperty): any;
export declare function tfServiceSourceConfigurationPropertyToHclTerraform(struct?: TfService.SourceConfigurationPropertyOutputReference | TfService.SourceConfigurationProperty): any;
export declare namespace TfService {
    interface EncryptionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#kms_key TfService#kms_key}
        */
        readonly kmsKey: string;
    }
    class EncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncryptionConfigurationProperty | undefined;
        set internalValue(value: EncryptionConfigurationProperty | undefined);
        private _kmsKey?;
        get kmsKey(): string;
        set kmsKey(value: string);
        get kmsKeyInput(): string | undefined;
    }
    interface HealthCheckConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#healthy_threshold TfService#healthy_threshold}
        */
        readonly healthyThreshold?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#interval TfService#interval}
        */
        readonly interval?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#path TfService#path}
        */
        readonly path?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#protocol TfService#protocol}
        */
        readonly protocol?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#timeout TfService#timeout}
        */
        readonly timeout?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#unhealthy_threshold TfService#unhealthy_threshold}
        */
        readonly unhealthyThreshold?: number;
    }
    class HealthCheckConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HealthCheckConfigurationProperty | undefined;
        set internalValue(value: HealthCheckConfigurationProperty | undefined);
        private _healthyThreshold?;
        get healthyThreshold(): number;
        set healthyThreshold(value: number);
        resetHealthyThreshold(): void;
        get healthyThresholdInput(): number | undefined;
        private _interval?;
        get interval(): number;
        set interval(value: number);
        resetInterval(): void;
        get intervalInput(): number | undefined;
        private _path?;
        get path(): string;
        set path(value: string);
        resetPath(): void;
        get pathInput(): string | undefined;
        private _protocol?;
        get protocol(): string;
        set protocol(value: string);
        resetProtocol(): void;
        get protocolInput(): string | undefined;
        private _timeout?;
        get timeout(): number;
        set timeout(value: number);
        resetTimeout(): void;
        get timeoutInput(): number | undefined;
        private _unhealthyThreshold?;
        get unhealthyThreshold(): number;
        set unhealthyThreshold(value: number);
        resetUnhealthyThreshold(): void;
        get unhealthyThresholdInput(): number | undefined;
    }
    interface InstanceConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#cpu TfService#cpu}
        */
        readonly cpu?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#instance_role_arn TfService#instance_role_arn}
        */
        readonly instanceRoleArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#memory TfService#memory}
        */
        readonly memory?: string;
    }
    class InstanceConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InstanceConfigurationProperty | undefined;
        set internalValue(value: InstanceConfigurationProperty | undefined);
        private _cpu?;
        get cpu(): string;
        set cpu(value: string);
        resetCpu(): void;
        get cpuInput(): string | undefined;
        private _instanceRoleArn?;
        get instanceRoleArn(): string;
        set instanceRoleArn(value: string);
        resetInstanceRoleArn(): void;
        get instanceRoleArnInput(): string | undefined;
        private _memory?;
        get memory(): string;
        set memory(value: string);
        resetMemory(): void;
        get memoryInput(): string | undefined;
    }
    interface EgressConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#egress_type TfService#egress_type}
        */
        readonly egressType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#vpc_connector_arn TfService#vpc_connector_arn}
        */
        readonly vpcConnectorArn?: string;
    }
    class EgressConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EgressConfigurationProperty | undefined;
        set internalValue(value: EgressConfigurationProperty | undefined);
        private _egressType?;
        get egressType(): string;
        set egressType(value: string);
        resetEgressType(): void;
        get egressTypeInput(): string | undefined;
        private _vpcConnectorArn?;
        get vpcConnectorArn(): string;
        set vpcConnectorArn(value: string);
        resetVpcConnectorArn(): void;
        get vpcConnectorArnInput(): string | undefined;
    }
    interface IngressConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#is_publicly_accessible TfService#is_publicly_accessible}
        */
        readonly isPubliclyAccessible?: boolean | cdktn.IResolvable;
    }
    class IngressConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IngressConfigurationProperty | undefined;
        set internalValue(value: IngressConfigurationProperty | undefined);
        private _isPubliclyAccessible?;
        get isPubliclyAccessible(): boolean | cdktn.IResolvable;
        set isPubliclyAccessible(value: boolean | cdktn.IResolvable);
        resetIsPubliclyAccessible(): void;
        get isPubliclyAccessibleInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface NetworkConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#ip_address_type TfService#ip_address_type}
        */
        readonly ipAddressType?: string;
        /**
        * egress_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#egress_configuration TfService#egress_configuration}
        */
        readonly egressConfiguration?: EgressConfigurationProperty;
        /**
        * ingress_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#ingress_configuration TfService#ingress_configuration}
        */
        readonly ingressConfiguration?: IngressConfigurationProperty;
    }
    class NetworkConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NetworkConfigurationProperty | undefined;
        set internalValue(value: NetworkConfigurationProperty | undefined);
        private _ipAddressType?;
        get ipAddressType(): string;
        set ipAddressType(value: string);
        resetIpAddressType(): void;
        get ipAddressTypeInput(): string | undefined;
        private _egressConfiguration;
        get egressConfiguration(): EgressConfigurationPropertyOutputReference;
        putEgressConfiguration(value: EgressConfigurationProperty): void;
        resetEgressConfiguration(): void;
        get egressConfigurationInput(): EgressConfigurationProperty | undefined;
        private _ingressConfiguration;
        get ingressConfiguration(): IngressConfigurationPropertyOutputReference;
        putIngressConfiguration(value: IngressConfigurationProperty): void;
        resetIngressConfiguration(): void;
        get ingressConfigurationInput(): IngressConfigurationProperty | undefined;
    }
    interface ObservabilityConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#observability_configuration_arn TfService#observability_configuration_arn}
        */
        readonly observabilityConfigurationArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#observability_enabled TfService#observability_enabled}
        */
        readonly observabilityEnabled: boolean | cdktn.IResolvable;
    }
    class ObservabilityConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ObservabilityConfigurationProperty | undefined;
        set internalValue(value: ObservabilityConfigurationProperty | undefined);
        private _observabilityConfigurationArn?;
        get observabilityConfigurationArn(): string;
        set observabilityConfigurationArn(value: string);
        resetObservabilityConfigurationArn(): void;
        get observabilityConfigurationArnInput(): string | undefined;
        private _observabilityEnabled?;
        get observabilityEnabled(): boolean | cdktn.IResolvable;
        set observabilityEnabled(value: boolean | cdktn.IResolvable);
        get observabilityEnabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface AuthenticationConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#access_role_arn TfService#access_role_arn}
        */
        readonly accessRoleArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#connection_arn TfService#connection_arn}
        */
        readonly connectionArn?: string;
    }
    class AuthenticationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AuthenticationConfigurationProperty | undefined;
        set internalValue(value: AuthenticationConfigurationProperty | undefined);
        private _accessRoleArn?;
        get accessRoleArn(): string;
        set accessRoleArn(value: string);
        resetAccessRoleArn(): void;
        get accessRoleArnInput(): string | undefined;
        private _connectionArn?;
        get connectionArn(): string;
        set connectionArn(value: string);
        resetConnectionArn(): void;
        get connectionArnInput(): string | undefined;
    }
    interface CodeConfigurationValuesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#build_command TfService#build_command}
        */
        readonly buildCommand?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#port TfService#port}
        */
        readonly port?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#runtime TfService#runtime}
        */
        readonly runtime: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#runtime_environment_secrets TfService#runtime_environment_secrets}
        */
        readonly runtimeEnvironmentSecrets?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#runtime_environment_variables TfService#runtime_environment_variables}
        */
        readonly runtimeEnvironmentVariables?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#start_command TfService#start_command}
        */
        readonly startCommand?: string;
    }
    class CodeConfigurationValuesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CodeConfigurationValuesProperty | undefined;
        set internalValue(value: CodeConfigurationValuesProperty | undefined);
        private _buildCommand?;
        get buildCommand(): string;
        set buildCommand(value: string);
        resetBuildCommand(): void;
        get buildCommandInput(): string | undefined;
        private _port?;
        get port(): string;
        set port(value: string);
        resetPort(): void;
        get portInput(): string | undefined;
        private _runtime?;
        get runtime(): string;
        set runtime(value: string);
        get runtimeInput(): string | undefined;
        private _runtimeEnvironmentSecrets?;
        get runtimeEnvironmentSecrets(): {
            [key: string]: string;
        };
        set runtimeEnvironmentSecrets(value: {
            [key: string]: string;
        });
        resetRuntimeEnvironmentSecrets(): void;
        get runtimeEnvironmentSecretsInput(): {
            [key: string]: string;
        } | undefined;
        private _runtimeEnvironmentVariables?;
        get runtimeEnvironmentVariables(): {
            [key: string]: string;
        };
        set runtimeEnvironmentVariables(value: {
            [key: string]: string;
        });
        resetRuntimeEnvironmentVariables(): void;
        get runtimeEnvironmentVariablesInput(): {
            [key: string]: string;
        } | undefined;
        private _startCommand?;
        get startCommand(): string;
        set startCommand(value: string);
        resetStartCommand(): void;
        get startCommandInput(): string | undefined;
    }
    interface CodeConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#configuration_source TfService#configuration_source}
        */
        readonly configurationSource: string;
        /**
        * code_configuration_values block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#code_configuration_values TfService#code_configuration_values}
        */
        readonly codeConfigurationValues?: CodeConfigurationValuesProperty;
    }
    class CodeConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CodeConfigurationProperty | undefined;
        set internalValue(value: CodeConfigurationProperty | undefined);
        private _configurationSource?;
        get configurationSource(): string;
        set configurationSource(value: string);
        get configurationSourceInput(): string | undefined;
        private _codeConfigurationValues;
        get codeConfigurationValues(): CodeConfigurationValuesPropertyOutputReference;
        putCodeConfigurationValues(value: CodeConfigurationValuesProperty): void;
        resetCodeConfigurationValues(): void;
        get codeConfigurationValuesInput(): CodeConfigurationValuesProperty | undefined;
    }
    interface SourceCodeVersionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#type TfService#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#value TfService#value}
        */
        readonly value: string;
    }
    class SourceCodeVersionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceCodeVersionProperty | undefined;
        set internalValue(value: SourceCodeVersionProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    interface CodeRepositoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#repository_url TfService#repository_url}
        */
        readonly repositoryUrl: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#source_directory TfService#source_directory}
        */
        readonly sourceDirectory?: string;
        /**
        * code_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#code_configuration TfService#code_configuration}
        */
        readonly codeConfiguration?: CodeConfigurationProperty;
        /**
        * source_code_version block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#source_code_version TfService#source_code_version}
        */
        readonly sourceCodeVersion: SourceCodeVersionProperty;
    }
    class CodeRepositoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CodeRepositoryProperty | undefined;
        set internalValue(value: CodeRepositoryProperty | undefined);
        private _repositoryUrl?;
        get repositoryUrl(): string;
        set repositoryUrl(value: string);
        get repositoryUrlInput(): string | undefined;
        private _sourceDirectory?;
        get sourceDirectory(): string;
        set sourceDirectory(value: string);
        resetSourceDirectory(): void;
        get sourceDirectoryInput(): string | undefined;
        private _codeConfiguration;
        get codeConfiguration(): CodeConfigurationPropertyOutputReference;
        putCodeConfiguration(value: CodeConfigurationProperty): void;
        resetCodeConfiguration(): void;
        get codeConfigurationInput(): CodeConfigurationProperty | undefined;
        private _sourceCodeVersion;
        get sourceCodeVersion(): SourceCodeVersionPropertyOutputReference;
        putSourceCodeVersion(value: SourceCodeVersionProperty): void;
        get sourceCodeVersionInput(): SourceCodeVersionProperty | undefined;
    }
    interface ImageConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#port TfService#port}
        */
        readonly port?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#runtime_environment_secrets TfService#runtime_environment_secrets}
        */
        readonly runtimeEnvironmentSecrets?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#runtime_environment_variables TfService#runtime_environment_variables}
        */
        readonly runtimeEnvironmentVariables?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#start_command TfService#start_command}
        */
        readonly startCommand?: string;
    }
    class ImageConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ImageConfigurationProperty | undefined;
        set internalValue(value: ImageConfigurationProperty | undefined);
        private _port?;
        get port(): string;
        set port(value: string);
        resetPort(): void;
        get portInput(): string | undefined;
        private _runtimeEnvironmentSecrets?;
        get runtimeEnvironmentSecrets(): {
            [key: string]: string;
        };
        set runtimeEnvironmentSecrets(value: {
            [key: string]: string;
        });
        resetRuntimeEnvironmentSecrets(): void;
        get runtimeEnvironmentSecretsInput(): {
            [key: string]: string;
        } | undefined;
        private _runtimeEnvironmentVariables?;
        get runtimeEnvironmentVariables(): {
            [key: string]: string;
        };
        set runtimeEnvironmentVariables(value: {
            [key: string]: string;
        });
        resetRuntimeEnvironmentVariables(): void;
        get runtimeEnvironmentVariablesInput(): {
            [key: string]: string;
        } | undefined;
        private _startCommand?;
        get startCommand(): string;
        set startCommand(value: string);
        resetStartCommand(): void;
        get startCommandInput(): string | undefined;
    }
    interface ImageRepositoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#image_identifier TfService#image_identifier}
        */
        readonly imageIdentifier: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#image_repository_type TfService#image_repository_type}
        */
        readonly imageRepositoryType: string;
        /**
        * image_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#image_configuration TfService#image_configuration}
        */
        readonly imageConfiguration?: ImageConfigurationProperty;
    }
    class ImageRepositoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ImageRepositoryProperty | undefined;
        set internalValue(value: ImageRepositoryProperty | undefined);
        private _imageIdentifier?;
        get imageIdentifier(): string;
        set imageIdentifier(value: string);
        get imageIdentifierInput(): string | undefined;
        private _imageRepositoryType?;
        get imageRepositoryType(): string;
        set imageRepositoryType(value: string);
        get imageRepositoryTypeInput(): string | undefined;
        private _imageConfiguration;
        get imageConfiguration(): ImageConfigurationPropertyOutputReference;
        putImageConfiguration(value: ImageConfigurationProperty): void;
        resetImageConfiguration(): void;
        get imageConfigurationInput(): ImageConfigurationProperty | undefined;
    }
    interface SourceConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#auto_deployments_enabled TfService#auto_deployments_enabled}
        */
        readonly autoDeploymentsEnabled?: boolean | cdktn.IResolvable;
        /**
        * authentication_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#authentication_configuration TfService#authentication_configuration}
        */
        readonly authenticationConfiguration?: AuthenticationConfigurationProperty;
        /**
        * code_repository block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#code_repository TfService#code_repository}
        */
        readonly codeRepository?: CodeRepositoryProperty;
        /**
        * image_repository block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/apprunner_service#image_repository TfService#image_repository}
        */
        readonly imageRepository?: ImageRepositoryProperty;
    }
    class SourceConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceConfigurationProperty | undefined;
        set internalValue(value: SourceConfigurationProperty | undefined);
        private _autoDeploymentsEnabled?;
        get autoDeploymentsEnabled(): boolean | cdktn.IResolvable;
        set autoDeploymentsEnabled(value: boolean | cdktn.IResolvable);
        resetAutoDeploymentsEnabled(): void;
        get autoDeploymentsEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _authenticationConfiguration;
        get authenticationConfiguration(): AuthenticationConfigurationPropertyOutputReference;
        putAuthenticationConfiguration(value: AuthenticationConfigurationProperty): void;
        resetAuthenticationConfiguration(): void;
        get authenticationConfigurationInput(): AuthenticationConfigurationProperty | undefined;
        private _codeRepository;
        get codeRepository(): CodeRepositoryPropertyOutputReference;
        putCodeRepository(value: CodeRepositoryProperty): void;
        resetCodeRepository(): void;
        get codeRepositoryInput(): CodeRepositoryProperty | undefined;
        private _imageRepository;
        get imageRepository(): ImageRepositoryPropertyOutputReference;
        putImageRepository(value: ImageRepositoryProperty): void;
        resetImageRepository(): void;
        get imageRepositoryInput(): ImageRepositoryProperty | undefined;
    }
}
