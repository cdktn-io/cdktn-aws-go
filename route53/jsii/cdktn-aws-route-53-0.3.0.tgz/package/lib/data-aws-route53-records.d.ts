import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsRecordsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_records#name_regex DataAwsRecords#name_regex}
    */
    readonly nameRegex?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_records#zone_id DataAwsRecords#zone_id}
    */
    readonly zoneId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_records aws_route53_records}
*/
export declare class DataAwsRecords extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_route53_records";
    /**
    * Generates CDKTN code for importing a DataAwsRecords resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsRecords to import
    * @param importFromId The id of the existing DataAwsRecords that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_records#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsRecords to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/route53_records aws_route53_records} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsRecordsConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsRecordsConfig);
    private _nameRegex?;
    get nameRegex(): string;
    set nameRegex(value: string);
    resetNameRegex(): void;
    get nameRegexInput(): string | undefined;
    private _resourceRecordSets;
    get resourceRecordSets(): DataAwsRecords.ResourceRecordSetsPropertyList;
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsRecordsAliasTargetPropertyToTerraform(struct?: DataAwsRecords.AliasTargetProperty): any;
export declare function dataAwsRecordsAliasTargetPropertyToHclTerraform(struct?: DataAwsRecords.AliasTargetProperty): any;
export declare function dataAwsRecordsCidrRoutingConfigPropertyToTerraform(struct?: DataAwsRecords.CidrRoutingConfigProperty): any;
export declare function dataAwsRecordsCidrRoutingConfigPropertyToHclTerraform(struct?: DataAwsRecords.CidrRoutingConfigProperty): any;
export declare function dataAwsRecordsGeolocationPropertyToTerraform(struct?: DataAwsRecords.GeolocationProperty): any;
export declare function dataAwsRecordsGeolocationPropertyToHclTerraform(struct?: DataAwsRecords.GeolocationProperty): any;
export declare function dataAwsRecordsCoordinatesPropertyToTerraform(struct?: DataAwsRecords.CoordinatesProperty): any;
export declare function dataAwsRecordsCoordinatesPropertyToHclTerraform(struct?: DataAwsRecords.CoordinatesProperty): any;
export declare function dataAwsRecordsGeoproximityLocationPropertyToTerraform(struct?: DataAwsRecords.GeoproximityLocationProperty): any;
export declare function dataAwsRecordsGeoproximityLocationPropertyToHclTerraform(struct?: DataAwsRecords.GeoproximityLocationProperty): any;
export declare function dataAwsRecordsResourceRecordsPropertyToTerraform(struct?: DataAwsRecords.ResourceRecordsProperty): any;
export declare function dataAwsRecordsResourceRecordsPropertyToHclTerraform(struct?: DataAwsRecords.ResourceRecordsProperty): any;
export declare function dataAwsRecordsResourceRecordSetsPropertyToTerraform(struct?: DataAwsRecords.ResourceRecordSetsProperty): any;
export declare function dataAwsRecordsResourceRecordSetsPropertyToHclTerraform(struct?: DataAwsRecords.ResourceRecordSetsProperty): any;
export declare namespace DataAwsRecords {
    interface AliasTargetProperty {
    }
    class AliasTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AliasTargetProperty | undefined;
        set internalValue(value: AliasTargetProperty | undefined);
        get dnsName(): string;
        get evaluateTargetHealth(): cdktn.IResolvable;
        get hostedZoneId(): string;
    }
    interface CidrRoutingConfigProperty {
    }
    class CidrRoutingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CidrRoutingConfigProperty | undefined;
        set internalValue(value: CidrRoutingConfigProperty | undefined);
        get collectionId(): string;
        get locationName(): string;
    }
    interface GeolocationProperty {
    }
    class GeolocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): GeolocationProperty | undefined;
        set internalValue(value: GeolocationProperty | undefined);
        get continentCode(): string;
        get countryCode(): string;
        get subdivisionCode(): string;
    }
    interface CoordinatesProperty {
    }
    class CoordinatesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CoordinatesProperty | undefined;
        set internalValue(value: CoordinatesProperty | undefined);
        get latitude(): string;
        get longitude(): string;
    }
    interface GeoproximityLocationProperty {
    }
    class GeoproximityLocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): GeoproximityLocationProperty | undefined;
        set internalValue(value: GeoproximityLocationProperty | undefined);
        get awsRegion(): string;
        get bias(): number;
        private _coordinates;
        get coordinates(): CoordinatesPropertyOutputReference;
        get localZoneGroup(): string;
    }
    interface ResourceRecordsProperty {
    }
    class ResourceRecordsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceRecordsProperty | undefined;
        set internalValue(value: ResourceRecordsProperty | undefined);
        get value(): string;
    }
    class ResourceRecordsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceRecordsPropertyOutputReference;
    }
    interface ResourceRecordSetsProperty {
    }
    class ResourceRecordSetsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceRecordSetsProperty | undefined;
        set internalValue(value: ResourceRecordSetsProperty | undefined);
        private _aliasTarget;
        get aliasTarget(): AliasTargetPropertyOutputReference;
        private _cidrRoutingConfig;
        get cidrRoutingConfig(): CidrRoutingConfigPropertyOutputReference;
        get failover(): string;
        private _geolocation;
        get geolocation(): GeolocationPropertyOutputReference;
        private _geoproximityLocation;
        get geoproximityLocation(): GeoproximityLocationPropertyOutputReference;
        get healthCheckId(): string;
        get multiValueAnswer(): cdktn.IResolvable;
        get name(): string;
        get region(): string;
        private _resourceRecords;
        get resourceRecords(): ResourceRecordsPropertyList;
        get setIdentifier(): string;
        get trafficPolicyInstanceId(): string;
        get ttl(): number;
        get type(): string;
        get weight(): number;
    }
    class ResourceRecordSetsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceRecordSetsPropertyOutputReference;
    }
}
