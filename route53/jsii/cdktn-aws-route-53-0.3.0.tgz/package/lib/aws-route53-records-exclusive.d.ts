import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsRecordsExclusiveConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#zone_id AwsRecordsExclusive#zone_id}
    */
    readonly zoneId: string;
    /**
    * resource_record_set block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#resource_record_set AwsRecordsExclusive#resource_record_set}
    */
    readonly resourceRecordSet?: AwsRecordsExclusive.ResourceRecordSetProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#timeouts AwsRecordsExclusive#timeouts}
    */
    readonly timeouts?: AwsRecordsExclusive.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive aws_route53_records_exclusive}
*/
export declare class AwsRecordsExclusive extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_route53_records_exclusive";
    /**
    * Generates CDKTN code for importing a AwsRecordsExclusive resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsRecordsExclusive to import
    * @param importFromId The id of the existing AwsRecordsExclusive that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsRecordsExclusive to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive aws_route53_records_exclusive} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsRecordsExclusiveConfig
    */
    constructor(scope: Construct, id: string, config: AwsRecordsExclusiveConfig);
    private _zoneId?;
    get zoneId(): string;
    set zoneId(value: string);
    get zoneIdInput(): string | undefined;
    private _resourceRecordSet;
    get resourceRecordSet(): AwsRecordsExclusive.ResourceRecordSetPropertyList;
    putResourceRecordSet(value: AwsRecordsExclusive.ResourceRecordSetProperty[] | cdktn.IResolvable): void;
    resetResourceRecordSet(): void;
    get resourceRecordSetInput(): cdktn.IResolvable | AwsRecordsExclusive.ResourceRecordSetProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsRecordsExclusive.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsRecordsExclusive.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsRecordsExclusive.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsRecordsExclusiveAliasTargetPropertyToTerraform(struct?: AwsRecordsExclusive.AliasTargetProperty | cdktn.IResolvable): any;
export declare function awsRecordsExclusiveAliasTargetPropertyToHclTerraform(struct?: AwsRecordsExclusive.AliasTargetProperty | cdktn.IResolvable): any;
export declare function awsRecordsExclusiveCidrRoutingConfigPropertyToTerraform(struct?: AwsRecordsExclusive.CidrRoutingConfigProperty | cdktn.IResolvable): any;
export declare function awsRecordsExclusiveCidrRoutingConfigPropertyToHclTerraform(struct?: AwsRecordsExclusive.CidrRoutingConfigProperty | cdktn.IResolvable): any;
export declare function awsRecordsExclusiveGeolocationPropertyToTerraform(struct?: AwsRecordsExclusive.GeolocationProperty | cdktn.IResolvable): any;
export declare function awsRecordsExclusiveGeolocationPropertyToHclTerraform(struct?: AwsRecordsExclusive.GeolocationProperty | cdktn.IResolvable): any;
export declare function awsRecordsExclusiveCoordinatesPropertyToTerraform(struct?: AwsRecordsExclusive.CoordinatesProperty | cdktn.IResolvable): any;
export declare function awsRecordsExclusiveCoordinatesPropertyToHclTerraform(struct?: AwsRecordsExclusive.CoordinatesProperty | cdktn.IResolvable): any;
export declare function awsRecordsExclusiveGeoproximityLocationPropertyToTerraform(struct?: AwsRecordsExclusive.GeoproximityLocationProperty | cdktn.IResolvable): any;
export declare function awsRecordsExclusiveGeoproximityLocationPropertyToHclTerraform(struct?: AwsRecordsExclusive.GeoproximityLocationProperty | cdktn.IResolvable): any;
export declare function awsRecordsExclusiveResourceRecordsPropertyToTerraform(struct?: AwsRecordsExclusive.ResourceRecordsProperty | cdktn.IResolvable): any;
export declare function awsRecordsExclusiveResourceRecordsPropertyToHclTerraform(struct?: AwsRecordsExclusive.ResourceRecordsProperty | cdktn.IResolvable): any;
export declare function awsRecordsExclusiveResourceRecordSetPropertyToTerraform(struct?: AwsRecordsExclusive.ResourceRecordSetProperty | cdktn.IResolvable): any;
export declare function awsRecordsExclusiveResourceRecordSetPropertyToHclTerraform(struct?: AwsRecordsExclusive.ResourceRecordSetProperty | cdktn.IResolvable): any;
export declare function awsRecordsExclusiveTimeoutsPropertyToTerraform(struct?: AwsRecordsExclusive.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsRecordsExclusiveTimeoutsPropertyToHclTerraform(struct?: AwsRecordsExclusive.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsRecordsExclusive {
    interface AliasTargetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#dns_name AwsRecordsExclusive#dns_name}
        */
        readonly dnsName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#evaluate_target_health AwsRecordsExclusive#evaluate_target_health}
        */
        readonly evaluateTargetHealth: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#hosted_zone_id AwsRecordsExclusive#hosted_zone_id}
        */
        readonly hostedZoneId: string;
    }
    class AliasTargetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AliasTargetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AliasTargetProperty | cdktn.IResolvable | undefined);
        private _dnsName?;
        get dnsName(): string;
        set dnsName(value: string);
        get dnsNameInput(): string | undefined;
        private _evaluateTargetHealth?;
        get evaluateTargetHealth(): boolean | cdktn.IResolvable;
        set evaluateTargetHealth(value: boolean | cdktn.IResolvable);
        get evaluateTargetHealthInput(): boolean | cdktn.IResolvable | undefined;
        private _hostedZoneId?;
        get hostedZoneId(): string;
        set hostedZoneId(value: string);
        get hostedZoneIdInput(): string | undefined;
    }
    class AliasTargetPropertyList extends cdktn.ComplexList {
        internalValue?: AliasTargetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AliasTargetPropertyOutputReference;
    }
    interface CidrRoutingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#collection_id AwsRecordsExclusive#collection_id}
        */
        readonly collectionId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#location_name AwsRecordsExclusive#location_name}
        */
        readonly locationName: string;
    }
    class CidrRoutingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CidrRoutingConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CidrRoutingConfigProperty | cdktn.IResolvable | undefined);
        private _collectionId?;
        get collectionId(): string;
        set collectionId(value: string);
        get collectionIdInput(): string | undefined;
        private _locationName?;
        get locationName(): string;
        set locationName(value: string);
        get locationNameInput(): string | undefined;
    }
    class CidrRoutingConfigPropertyList extends cdktn.ComplexList {
        internalValue?: CidrRoutingConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CidrRoutingConfigPropertyOutputReference;
    }
    interface GeolocationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#continent_code AwsRecordsExclusive#continent_code}
        */
        readonly continentCode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#country_code AwsRecordsExclusive#country_code}
        */
        readonly countryCode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#subdivision_code AwsRecordsExclusive#subdivision_code}
        */
        readonly subdivisionCode?: string;
    }
    class GeolocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GeolocationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: GeolocationProperty | cdktn.IResolvable | undefined);
        private _continentCode?;
        get continentCode(): string;
        set continentCode(value: string);
        resetContinentCode(): void;
        get continentCodeInput(): string | undefined;
        private _countryCode?;
        get countryCode(): string;
        set countryCode(value: string);
        resetCountryCode(): void;
        get countryCodeInput(): string | undefined;
        private _subdivisionCode?;
        get subdivisionCode(): string;
        set subdivisionCode(value: string);
        resetSubdivisionCode(): void;
        get subdivisionCodeInput(): string | undefined;
    }
    class GeolocationPropertyList extends cdktn.ComplexList {
        internalValue?: GeolocationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GeolocationPropertyOutputReference;
    }
    interface CoordinatesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#latitude AwsRecordsExclusive#latitude}
        */
        readonly latitude: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#longitude AwsRecordsExclusive#longitude}
        */
        readonly longitude: string;
    }
    class CoordinatesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CoordinatesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CoordinatesProperty | cdktn.IResolvable | undefined);
        private _latitude?;
        get latitude(): string;
        set latitude(value: string);
        get latitudeInput(): string | undefined;
        private _longitude?;
        get longitude(): string;
        set longitude(value: string);
        get longitudeInput(): string | undefined;
    }
    class CoordinatesPropertyList extends cdktn.ComplexList {
        internalValue?: CoordinatesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CoordinatesPropertyOutputReference;
    }
    interface GeoproximityLocationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#aws_region AwsRecordsExclusive#aws_region}
        */
        readonly awsRegion?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#bias AwsRecordsExclusive#bias}
        */
        readonly bias?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#local_zone_group AwsRecordsExclusive#local_zone_group}
        */
        readonly localZoneGroup?: string;
        /**
        * coordinates block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#coordinates AwsRecordsExclusive#coordinates}
        */
        readonly coordinates?: CoordinatesProperty[] | cdktn.IResolvable;
    }
    class GeoproximityLocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): GeoproximityLocationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: GeoproximityLocationProperty | cdktn.IResolvable | undefined);
        private _awsRegion?;
        get awsRegion(): string;
        set awsRegion(value: string);
        resetAwsRegion(): void;
        get awsRegionInput(): string | undefined;
        private _bias?;
        get bias(): number;
        set bias(value: number);
        resetBias(): void;
        get biasInput(): number | undefined;
        private _localZoneGroup?;
        get localZoneGroup(): string;
        set localZoneGroup(value: string);
        resetLocalZoneGroup(): void;
        get localZoneGroupInput(): string | undefined;
        private _coordinates;
        get coordinates(): CoordinatesPropertyList;
        putCoordinates(value: CoordinatesProperty[] | cdktn.IResolvable): void;
        resetCoordinates(): void;
        get coordinatesInput(): cdktn.IResolvable | CoordinatesProperty[] | undefined;
    }
    class GeoproximityLocationPropertyList extends cdktn.ComplexList {
        internalValue?: GeoproximityLocationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): GeoproximityLocationPropertyOutputReference;
    }
    interface ResourceRecordsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#value AwsRecordsExclusive#value}
        */
        readonly value: string;
    }
    class ResourceRecordsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceRecordsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceRecordsProperty | cdktn.IResolvable | undefined);
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class ResourceRecordsPropertyList extends cdktn.ComplexList {
        internalValue?: ResourceRecordsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceRecordsPropertyOutputReference;
    }
    interface ResourceRecordSetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#failover AwsRecordsExclusive#failover}
        */
        readonly failover?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#health_check_id AwsRecordsExclusive#health_check_id}
        */
        readonly healthCheckId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#multi_value_answer AwsRecordsExclusive#multi_value_answer}
        */
        readonly multiValueAnswer?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#name AwsRecordsExclusive#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#region AwsRecordsExclusive#region}
        */
        readonly region?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#set_identifier AwsRecordsExclusive#set_identifier}
        */
        readonly setIdentifier?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#traffic_policy_instance_id AwsRecordsExclusive#traffic_policy_instance_id}
        */
        readonly trafficPolicyInstanceId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#ttl AwsRecordsExclusive#ttl}
        */
        readonly ttl?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#type AwsRecordsExclusive#type}
        */
        readonly type?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#weight AwsRecordsExclusive#weight}
        */
        readonly weight?: number;
        /**
        * alias_target block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#alias_target AwsRecordsExclusive#alias_target}
        */
        readonly aliasTarget?: AliasTargetProperty[] | cdktn.IResolvable;
        /**
        * cidr_routing_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#cidr_routing_config AwsRecordsExclusive#cidr_routing_config}
        */
        readonly cidrRoutingConfig?: CidrRoutingConfigProperty[] | cdktn.IResolvable;
        /**
        * geolocation block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#geolocation AwsRecordsExclusive#geolocation}
        */
        readonly geolocation?: GeolocationProperty[] | cdktn.IResolvable;
        /**
        * geoproximity_location block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#geoproximity_location AwsRecordsExclusive#geoproximity_location}
        */
        readonly geoproximityLocation?: GeoproximityLocationProperty[] | cdktn.IResolvable;
        /**
        * resource_records block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#resource_records AwsRecordsExclusive#resource_records}
        */
        readonly resourceRecords?: ResourceRecordsProperty[] | cdktn.IResolvable;
    }
    class ResourceRecordSetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceRecordSetProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceRecordSetProperty | cdktn.IResolvable | undefined);
        private _failover?;
        get failover(): string;
        set failover(value: string);
        resetFailover(): void;
        get failoverInput(): string | undefined;
        private _healthCheckId?;
        get healthCheckId(): string;
        set healthCheckId(value: string);
        resetHealthCheckId(): void;
        get healthCheckIdInput(): string | undefined;
        private _multiValueAnswer?;
        get multiValueAnswer(): boolean | cdktn.IResolvable;
        set multiValueAnswer(value: boolean | cdktn.IResolvable);
        resetMultiValueAnswer(): void;
        get multiValueAnswerInput(): boolean | cdktn.IResolvable | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        resetRegion(): void;
        get regionInput(): string | undefined;
        private _setIdentifier?;
        get setIdentifier(): string;
        set setIdentifier(value: string);
        resetSetIdentifier(): void;
        get setIdentifierInput(): string | undefined;
        private _trafficPolicyInstanceId?;
        get trafficPolicyInstanceId(): string;
        set trafficPolicyInstanceId(value: string);
        resetTrafficPolicyInstanceId(): void;
        get trafficPolicyInstanceIdInput(): string | undefined;
        private _ttl?;
        get ttl(): number;
        set ttl(value: number);
        resetTtl(): void;
        get ttlInput(): number | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
        private _weight?;
        get weight(): number;
        set weight(value: number);
        resetWeight(): void;
        get weightInput(): number | undefined;
        private _aliasTarget;
        get aliasTarget(): AliasTargetPropertyList;
        putAliasTarget(value: AliasTargetProperty[] | cdktn.IResolvable): void;
        resetAliasTarget(): void;
        get aliasTargetInput(): cdktn.IResolvable | AliasTargetProperty[] | undefined;
        private _cidrRoutingConfig;
        get cidrRoutingConfig(): CidrRoutingConfigPropertyList;
        putCidrRoutingConfig(value: CidrRoutingConfigProperty[] | cdktn.IResolvable): void;
        resetCidrRoutingConfig(): void;
        get cidrRoutingConfigInput(): cdktn.IResolvable | CidrRoutingConfigProperty[] | undefined;
        private _geolocation;
        get geolocation(): GeolocationPropertyList;
        putGeolocation(value: GeolocationProperty[] | cdktn.IResolvable): void;
        resetGeolocation(): void;
        get geolocationInput(): cdktn.IResolvable | GeolocationProperty[] | undefined;
        private _geoproximityLocation;
        get geoproximityLocation(): GeoproximityLocationPropertyList;
        putGeoproximityLocation(value: GeoproximityLocationProperty[] | cdktn.IResolvable): void;
        resetGeoproximityLocation(): void;
        get geoproximityLocationInput(): cdktn.IResolvable | GeoproximityLocationProperty[] | undefined;
        private _resourceRecords;
        get resourceRecords(): ResourceRecordsPropertyList;
        putResourceRecords(value: ResourceRecordsProperty[] | cdktn.IResolvable): void;
        resetResourceRecords(): void;
        get resourceRecordsInput(): cdktn.IResolvable | ResourceRecordsProperty[] | undefined;
    }
    class ResourceRecordSetPropertyList extends cdktn.ComplexList {
        internalValue?: ResourceRecordSetProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceRecordSetPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#create AwsRecordsExclusive#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_records_exclusive#update AwsRecordsExclusive#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
