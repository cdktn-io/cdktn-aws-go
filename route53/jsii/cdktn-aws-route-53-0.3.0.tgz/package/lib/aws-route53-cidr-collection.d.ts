import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsCidrCollectionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_cidr_collection#name AwsCidrCollection#name}
    */
    readonly name: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_cidr_collection aws_route53_cidr_collection}
*/
export declare class AwsCidrCollection extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_route53_cidr_collection";
    /**
    * Generates CDKTN code for importing a AwsCidrCollection resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsCidrCollection to import
    * @param importFromId The id of the existing AwsCidrCollection that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_cidr_collection#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsCidrCollection to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_cidr_collection aws_route53_cidr_collection} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsCidrCollectionConfig
    */
    constructor(scope: Construct, id: string, config: AwsCidrCollectionConfig);
    get arn(): string;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get version(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
