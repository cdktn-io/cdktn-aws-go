import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsHostedZoneDnssecConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_hosted_zone_dnssec#hosted_zone_id AwsHostedZoneDnssec#hosted_zone_id}
    */
    readonly hostedZoneId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_hosted_zone_dnssec#id AwsHostedZoneDnssec#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_hosted_zone_dnssec#signing_status AwsHostedZoneDnssec#signing_status}
    */
    readonly signingStatus?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_hosted_zone_dnssec#timeouts AwsHostedZoneDnssec#timeouts}
    */
    readonly timeouts?: AwsHostedZoneDnssec.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_hosted_zone_dnssec aws_route53_hosted_zone_dnssec}
*/
export declare class AwsHostedZoneDnssec extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_route53_hosted_zone_dnssec";
    /**
    * Generates CDKTN code for importing a AwsHostedZoneDnssec resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsHostedZoneDnssec to import
    * @param importFromId The id of the existing AwsHostedZoneDnssec that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_hosted_zone_dnssec#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsHostedZoneDnssec to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_hosted_zone_dnssec aws_route53_hosted_zone_dnssec} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsHostedZoneDnssecConfig
    */
    constructor(scope: Construct, id: string, config: AwsHostedZoneDnssecConfig);
    private _hostedZoneId?;
    get hostedZoneId(): string;
    set hostedZoneId(value: string);
    get hostedZoneIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _signingStatus?;
    get signingStatus(): string;
    set signingStatus(value: string);
    resetSigningStatus(): void;
    get signingStatusInput(): string | undefined;
    private _timeouts;
    get timeouts(): AwsHostedZoneDnssec.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsHostedZoneDnssec.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsHostedZoneDnssec.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsHostedZoneDnssecTimeoutsPropertyToTerraform(struct?: AwsHostedZoneDnssec.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsHostedZoneDnssecTimeoutsPropertyToHclTerraform(struct?: AwsHostedZoneDnssec.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsHostedZoneDnssec {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_hosted_zone_dnssec#create AwsHostedZoneDnssec#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_hosted_zone_dnssec#delete AwsHostedZoneDnssec#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/route53_hosted_zone_dnssec#update AwsHostedZoneDnssec#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
