import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsResourcegroupstaggingapiResourcesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/resourcegroupstaggingapi_resources#exclude_compliant_resources DataAwsResourcegroupstaggingapiResources#exclude_compliant_resources}
    */
    readonly excludeCompliantResources?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/resourcegroupstaggingapi_resources#id DataAwsResourcegroupstaggingapiResources#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/resourcegroupstaggingapi_resources#include_compliance_details DataAwsResourcegroupstaggingapiResources#include_compliance_details}
    */
    readonly includeComplianceDetails?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/resourcegroupstaggingapi_resources#region DataAwsResourcegroupstaggingapiResources#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/resourcegroupstaggingapi_resources#resource_arn_list DataAwsResourcegroupstaggingapiResources#resource_arn_list}
    */
    readonly resourceArnList?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/resourcegroupstaggingapi_resources#resource_type_filters DataAwsResourcegroupstaggingapiResources#resource_type_filters}
    */
    readonly resourceTypeFilters?: string[];
    /**
    * tag_filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/resourcegroupstaggingapi_resources#tag_filter DataAwsResourcegroupstaggingapiResources#tag_filter}
    */
    readonly tagFilter?: DataAwsResourcegroupstaggingapiResources.TagFilterProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/resourcegroupstaggingapi_resources aws_resourcegroupstaggingapi_resources}
*/
export declare class DataAwsResourcegroupstaggingapiResources extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_resourcegroupstaggingapi_resources";
    /**
    * Generates CDKTN code for importing a DataAwsResourcegroupstaggingapiResources resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsResourcegroupstaggingapiResources to import
    * @param importFromId The id of the existing DataAwsResourcegroupstaggingapiResources that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/resourcegroupstaggingapi_resources#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsResourcegroupstaggingapiResources to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/resourcegroupstaggingapi_resources aws_resourcegroupstaggingapi_resources} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsResourcegroupstaggingapiResourcesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsResourcegroupstaggingapiResourcesConfig);
    private _excludeCompliantResources?;
    get excludeCompliantResources(): boolean | cdktn.IResolvable;
    set excludeCompliantResources(value: boolean | cdktn.IResolvable);
    resetExcludeCompliantResources(): void;
    get excludeCompliantResourcesInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _includeComplianceDetails?;
    get includeComplianceDetails(): boolean | cdktn.IResolvable;
    set includeComplianceDetails(value: boolean | cdktn.IResolvable);
    resetIncludeComplianceDetails(): void;
    get includeComplianceDetailsInput(): boolean | cdktn.IResolvable | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourceArnList?;
    get resourceArnList(): string[];
    set resourceArnList(value: string[]);
    resetResourceArnList(): void;
    get resourceArnListInput(): string[] | undefined;
    private _resourceTagMappingList;
    get resourceTagMappingList(): DataAwsResourcegroupstaggingapiResources.ResourceTagMappingListPropertyList;
    private _resourceTypeFilters?;
    get resourceTypeFilters(): string[];
    set resourceTypeFilters(value: string[]);
    resetResourceTypeFilters(): void;
    get resourceTypeFiltersInput(): string[] | undefined;
    private _tagFilter;
    get tagFilter(): DataAwsResourcegroupstaggingapiResources.TagFilterPropertyList;
    putTagFilter(value: DataAwsResourcegroupstaggingapiResources.TagFilterProperty[] | cdktn.IResolvable): void;
    resetTagFilter(): void;
    get tagFilterInput(): cdktn.IResolvable | DataAwsResourcegroupstaggingapiResources.TagFilterProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsResourcegroupstaggingapiResourcesComplianceDetailsPropertyToTerraform(struct?: DataAwsResourcegroupstaggingapiResources.ComplianceDetailsProperty): any;
export declare function dataAwsResourcegroupstaggingapiResourcesComplianceDetailsPropertyToHclTerraform(struct?: DataAwsResourcegroupstaggingapiResources.ComplianceDetailsProperty): any;
export declare function dataAwsResourcegroupstaggingapiResourcesResourceTagMappingListPropertyToTerraform(struct?: DataAwsResourcegroupstaggingapiResources.ResourceTagMappingListProperty): any;
export declare function dataAwsResourcegroupstaggingapiResourcesResourceTagMappingListPropertyToHclTerraform(struct?: DataAwsResourcegroupstaggingapiResources.ResourceTagMappingListProperty): any;
export declare function dataAwsResourcegroupstaggingapiResourcesTagFilterPropertyToTerraform(struct?: DataAwsResourcegroupstaggingapiResources.TagFilterProperty | cdktn.IResolvable): any;
export declare function dataAwsResourcegroupstaggingapiResourcesTagFilterPropertyToHclTerraform(struct?: DataAwsResourcegroupstaggingapiResources.TagFilterProperty | cdktn.IResolvable): any;
export declare namespace DataAwsResourcegroupstaggingapiResources {
    interface ComplianceDetailsProperty {
    }
    class ComplianceDetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ComplianceDetailsProperty | undefined;
        set internalValue(value: ComplianceDetailsProperty | undefined);
        get complianceStatus(): cdktn.IResolvable;
        get keysWithNoncompliantValues(): string[];
        get nonCompliantKeys(): string[];
    }
    class ComplianceDetailsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ComplianceDetailsPropertyOutputReference;
    }
    interface ResourceTagMappingListProperty {
    }
    class ResourceTagMappingListPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceTagMappingListProperty | undefined;
        set internalValue(value: ResourceTagMappingListProperty | undefined);
        private _complianceDetails;
        get complianceDetails(): ComplianceDetailsPropertyList;
        get resourceArn(): string;
        private _tags;
        get tags(): cdktn.StringMap;
    }
    class ResourceTagMappingListPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceTagMappingListPropertyOutputReference;
    }
    interface TagFilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/resourcegroupstaggingapi_resources#key DataAwsResourcegroupstaggingapiResources#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/resourcegroupstaggingapi_resources#values DataAwsResourcegroupstaggingapiResources#values}
        */
        readonly values?: string[];
    }
    class TagFilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TagFilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TagFilterProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        resetValues(): void;
        get valuesInput(): string[] | undefined;
    }
    class TagFilterPropertyList extends cdktn.ComplexList {
        internalValue?: TagFilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TagFilterPropertyOutputReference;
    }
}
