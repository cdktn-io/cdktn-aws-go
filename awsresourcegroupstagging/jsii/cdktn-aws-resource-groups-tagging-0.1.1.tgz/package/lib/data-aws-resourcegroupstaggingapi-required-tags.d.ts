import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsResourcegroupstaggingapiRequiredTagsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/resourcegroupstaggingapi_required_tags#region DataAwsResourcegroupstaggingapiRequiredTags#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/resourcegroupstaggingapi_required_tags aws_resourcegroupstaggingapi_required_tags}
*/
export declare class DataAwsResourcegroupstaggingapiRequiredTags extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_resourcegroupstaggingapi_required_tags";
    /**
    * Generates CDKTN code for importing a DataAwsResourcegroupstaggingapiRequiredTags resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsResourcegroupstaggingapiRequiredTags to import
    * @param importFromId The id of the existing DataAwsResourcegroupstaggingapiRequiredTags that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/resourcegroupstaggingapi_required_tags#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsResourcegroupstaggingapiRequiredTags to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/resourcegroupstaggingapi_required_tags aws_resourcegroupstaggingapi_required_tags} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsResourcegroupstaggingapiRequiredTagsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsResourcegroupstaggingapiRequiredTagsConfig);
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _requiredTags;
    get requiredTags(): DataAwsResourcegroupstaggingapiRequiredTags.RequiredTagsPropertyList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsResourcegroupstaggingapiRequiredTagsRequiredTagsPropertyToTerraform(struct?: DataAwsResourcegroupstaggingapiRequiredTags.RequiredTagsProperty): any;
export declare function dataAwsResourcegroupstaggingapiRequiredTagsRequiredTagsPropertyToHclTerraform(struct?: DataAwsResourcegroupstaggingapiRequiredTags.RequiredTagsProperty): any;
export declare namespace DataAwsResourcegroupstaggingapiRequiredTags {
    interface RequiredTagsProperty {
    }
    class RequiredTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RequiredTagsProperty | undefined;
        set internalValue(value: RequiredTagsProperty | undefined);
        get cloudFormationResourceTypes(): string[];
        get reportingTagKeys(): string[];
        get resourceType(): string;
    }
    class RequiredTagsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RequiredTagsPropertyOutputReference;
    }
}
