import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface EphemeralAwsOpenidTokenForDeveloperIdentityConfig extends cdktn.TerraformEphemeralMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/ephemeral-resources/cognito_identity_openid_token_for_developer_identity#identity_id EphemeralAwsOpenidTokenForDeveloperIdentity#identity_id}
    */
    readonly identityId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/ephemeral-resources/cognito_identity_openid_token_for_developer_identity#identity_pool_id EphemeralAwsOpenidTokenForDeveloperIdentity#identity_pool_id}
    */
    readonly identityPoolId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/ephemeral-resources/cognito_identity_openid_token_for_developer_identity#logins EphemeralAwsOpenidTokenForDeveloperIdentity#logins}
    */
    readonly logins: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/ephemeral-resources/cognito_identity_openid_token_for_developer_identity#principal_tags EphemeralAwsOpenidTokenForDeveloperIdentity#principal_tags}
    */
    readonly principalTags?: {
        [key: string]: string;
    };
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/ephemeral-resources/cognito_identity_openid_token_for_developer_identity#region EphemeralAwsOpenidTokenForDeveloperIdentity#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/ephemeral-resources/cognito_identity_openid_token_for_developer_identity#token_duration EphemeralAwsOpenidTokenForDeveloperIdentity#token_duration}
    */
    readonly tokenDuration?: number;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/ephemeral-resources/cognito_identity_openid_token_for_developer_identity aws_cognito_identity_openid_token_for_developer_identity}
*/
export declare class EphemeralAwsOpenidTokenForDeveloperIdentity extends cdktn.TerraformEphemeralResource {
    static readonly tfResourceType = "aws_cognito_identity_openid_token_for_developer_identity";
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/ephemeral-resources/cognito_identity_openid_token_for_developer_identity aws_cognito_identity_openid_token_for_developer_identity} Ephemeral Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options EphemeralAwsOpenidTokenForDeveloperIdentityConfig
    */
    constructor(scope: Construct, id: string, config: EphemeralAwsOpenidTokenForDeveloperIdentityConfig);
    private _identityId?;
    get identityId(): string;
    set identityId(value: string);
    resetIdentityId(): void;
    get identityIdInput(): string | undefined;
    private _identityPoolId?;
    get identityPoolId(): string;
    set identityPoolId(value: string);
    get identityPoolIdInput(): string | undefined;
    private _logins?;
    get logins(): {
        [key: string]: string;
    };
    set logins(value: {
        [key: string]: string;
    });
    get loginsInput(): {
        [key: string]: string;
    } | undefined;
    private _principalTags?;
    get principalTags(): {
        [key: string]: string;
    };
    set principalTags(value: {
        [key: string]: string;
    });
    resetPrincipalTags(): void;
    get principalTagsInput(): {
        [key: string]: string;
    } | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get token(): string;
    private _tokenDuration?;
    get tokenDuration(): number;
    set tokenDuration(value: number);
    resetTokenDuration(): void;
    get tokenDurationInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
