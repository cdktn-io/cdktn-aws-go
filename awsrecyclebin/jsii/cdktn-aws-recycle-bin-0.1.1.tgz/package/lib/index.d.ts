export * from './aws-rbin-rule';
