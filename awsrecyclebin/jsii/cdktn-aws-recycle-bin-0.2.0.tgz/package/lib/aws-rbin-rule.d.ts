import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rbin_rule#description TfRule#description}
    */
    readonly description?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rbin_rule#region TfRule#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rbin_rule#resource_type TfRule#resource_type}
    */
    readonly resourceType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rbin_rule#tags TfRule#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rbin_rule#tags_all TfRule#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * exclude_resource_tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rbin_rule#exclude_resource_tags TfRule#exclude_resource_tags}
    */
    readonly excludeResourceTags?: TfRule.ExcludeResourceTagsProperty[] | cdktn.IResolvable;
    /**
    * lock_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rbin_rule#lock_configuration TfRule#lock_configuration}
    */
    readonly lockConfiguration?: TfRule.LockConfigurationProperty;
    /**
    * resource_tags block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rbin_rule#resource_tags TfRule#resource_tags}
    */
    readonly resourceTags?: TfRule.ResourceTagsProperty[] | cdktn.IResolvable;
    /**
    * retention_period block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rbin_rule#retention_period TfRule#retention_period}
    */
    readonly retentionPeriod: TfRule.RetentionPeriodProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rbin_rule#timeouts TfRule#timeouts}
    */
    readonly timeouts?: TfRule.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rbin_rule aws_rbin_rule}
*/
export declare class TfRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_rbin_rule";
    /**
    * Generates CDKTN code for importing a TfRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfRule to import
    * @param importFromId The id of the existing TfRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rbin_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rbin_rule aws_rbin_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfRuleConfig
    */
    constructor(scope: Construct, id: string, config: TfRuleConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    get lockEndTime(): string;
    get lockState(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourceType?;
    get resourceType(): string;
    set resourceType(value: string);
    get resourceTypeInput(): string | undefined;
    get status(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _excludeResourceTags;
    get excludeResourceTags(): TfRule.ExcludeResourceTagsPropertyList;
    putExcludeResourceTags(value: TfRule.ExcludeResourceTagsProperty[] | cdktn.IResolvable): void;
    resetExcludeResourceTags(): void;
    get excludeResourceTagsInput(): cdktn.IResolvable | TfRule.ExcludeResourceTagsProperty[] | undefined;
    private _lockConfiguration;
    get lockConfiguration(): TfRule.LockConfigurationPropertyOutputReference;
    putLockConfiguration(value: TfRule.LockConfigurationProperty): void;
    resetLockConfiguration(): void;
    get lockConfigurationInput(): TfRule.LockConfigurationProperty | undefined;
    private _resourceTags;
    get resourceTags(): TfRule.ResourceTagsPropertyList;
    putResourceTags(value: TfRule.ResourceTagsProperty[] | cdktn.IResolvable): void;
    resetResourceTags(): void;
    get resourceTagsInput(): cdktn.IResolvable | TfRule.ResourceTagsProperty[] | undefined;
    private _retentionPeriod;
    get retentionPeriod(): TfRule.RetentionPeriodPropertyOutputReference;
    putRetentionPeriod(value: TfRule.RetentionPeriodProperty): void;
    get retentionPeriodInput(): TfRule.RetentionPeriodProperty | undefined;
    private _timeouts;
    get timeouts(): TfRule.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfRule.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfRule.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfRuleExcludeResourceTagsPropertyToTerraform(struct?: TfRule.ExcludeResourceTagsProperty | cdktn.IResolvable): any;
export declare function tfRuleExcludeResourceTagsPropertyToHclTerraform(struct?: TfRule.ExcludeResourceTagsProperty | cdktn.IResolvable): any;
export declare function tfRuleUnlockDelayPropertyToTerraform(struct?: TfRule.UnlockDelayPropertyOutputReference | TfRule.UnlockDelayProperty): any;
export declare function tfRuleUnlockDelayPropertyToHclTerraform(struct?: TfRule.UnlockDelayPropertyOutputReference | TfRule.UnlockDelayProperty): any;
export declare function tfRuleLockConfigurationPropertyToTerraform(struct?: TfRule.LockConfigurationPropertyOutputReference | TfRule.LockConfigurationProperty): any;
export declare function tfRuleLockConfigurationPropertyToHclTerraform(struct?: TfRule.LockConfigurationPropertyOutputReference | TfRule.LockConfigurationProperty): any;
export declare function tfRuleResourceTagsPropertyToTerraform(struct?: TfRule.ResourceTagsProperty | cdktn.IResolvable): any;
export declare function tfRuleResourceTagsPropertyToHclTerraform(struct?: TfRule.ResourceTagsProperty | cdktn.IResolvable): any;
export declare function tfRuleRetentionPeriodPropertyToTerraform(struct?: TfRule.RetentionPeriodPropertyOutputReference | TfRule.RetentionPeriodProperty): any;
export declare function tfRuleRetentionPeriodPropertyToHclTerraform(struct?: TfRule.RetentionPeriodPropertyOutputReference | TfRule.RetentionPeriodProperty): any;
export declare function tfRuleTimeoutsPropertyToTerraform(struct?: TfRule.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfRuleTimeoutsPropertyToHclTerraform(struct?: TfRule.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfRule {
    interface ExcludeResourceTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rbin_rule#resource_tag_key TfRule#resource_tag_key}
        */
        readonly resourceTagKey: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rbin_rule#resource_tag_value TfRule#resource_tag_value}
        */
        readonly resourceTagValue?: string;
    }
    class ExcludeResourceTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExcludeResourceTagsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ExcludeResourceTagsProperty | cdktn.IResolvable | undefined);
        private _resourceTagKey?;
        get resourceTagKey(): string;
        set resourceTagKey(value: string);
        get resourceTagKeyInput(): string | undefined;
        private _resourceTagValue?;
        get resourceTagValue(): string;
        set resourceTagValue(value: string);
        resetResourceTagValue(): void;
        get resourceTagValueInput(): string | undefined;
    }
    class ExcludeResourceTagsPropertyList extends cdktn.ComplexList {
        internalValue?: ExcludeResourceTagsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExcludeResourceTagsPropertyOutputReference;
    }
    interface UnlockDelayProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rbin_rule#unlock_delay_unit TfRule#unlock_delay_unit}
        */
        readonly unlockDelayUnit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rbin_rule#unlock_delay_value TfRule#unlock_delay_value}
        */
        readonly unlockDelayValue: number;
    }
    class UnlockDelayPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UnlockDelayProperty | undefined;
        set internalValue(value: UnlockDelayProperty | undefined);
        private _unlockDelayUnit?;
        get unlockDelayUnit(): string;
        set unlockDelayUnit(value: string);
        get unlockDelayUnitInput(): string | undefined;
        private _unlockDelayValue?;
        get unlockDelayValue(): number;
        set unlockDelayValue(value: number);
        get unlockDelayValueInput(): number | undefined;
    }
    interface LockConfigurationProperty {
        /**
        * unlock_delay block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rbin_rule#unlock_delay TfRule#unlock_delay}
        */
        readonly unlockDelay: UnlockDelayProperty;
    }
    class LockConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LockConfigurationProperty | undefined;
        set internalValue(value: LockConfigurationProperty | undefined);
        private _unlockDelay;
        get unlockDelay(): UnlockDelayPropertyOutputReference;
        putUnlockDelay(value: UnlockDelayProperty): void;
        get unlockDelayInput(): UnlockDelayProperty | undefined;
    }
    interface ResourceTagsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rbin_rule#resource_tag_key TfRule#resource_tag_key}
        */
        readonly resourceTagKey: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rbin_rule#resource_tag_value TfRule#resource_tag_value}
        */
        readonly resourceTagValue?: string;
    }
    class ResourceTagsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ResourceTagsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ResourceTagsProperty | cdktn.IResolvable | undefined);
        private _resourceTagKey?;
        get resourceTagKey(): string;
        set resourceTagKey(value: string);
        get resourceTagKeyInput(): string | undefined;
        private _resourceTagValue?;
        get resourceTagValue(): string;
        set resourceTagValue(value: string);
        resetResourceTagValue(): void;
        get resourceTagValueInput(): string | undefined;
    }
    class ResourceTagsPropertyList extends cdktn.ComplexList {
        internalValue?: ResourceTagsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ResourceTagsPropertyOutputReference;
    }
    interface RetentionPeriodProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rbin_rule#retention_period_unit TfRule#retention_period_unit}
        */
        readonly retentionPeriodUnit: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rbin_rule#retention_period_value TfRule#retention_period_value}
        */
        readonly retentionPeriodValue: number;
    }
    class RetentionPeriodPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RetentionPeriodProperty | undefined;
        set internalValue(value: RetentionPeriodProperty | undefined);
        private _retentionPeriodUnit?;
        get retentionPeriodUnit(): string;
        set retentionPeriodUnit(value: string);
        get retentionPeriodUnitInput(): string | undefined;
        private _retentionPeriodValue?;
        get retentionPeriodValue(): number;
        set retentionPeriodValue(value: number);
        get retentionPeriodValueInput(): number | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rbin_rule#create TfRule#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rbin_rule#delete TfRule#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/rbin_rule#update TfRule#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
