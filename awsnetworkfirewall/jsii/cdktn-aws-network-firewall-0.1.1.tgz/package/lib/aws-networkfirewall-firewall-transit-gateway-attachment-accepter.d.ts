import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsNetworkfirewallFirewallTransitGatewayAttachmentAccepterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_transit_gateway_attachment_accepter#region AwsNetworkfirewallFirewallTransitGatewayAttachmentAccepter#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_transit_gateway_attachment_accepter#transit_gateway_attachment_id AwsNetworkfirewallFirewallTransitGatewayAttachmentAccepter#transit_gateway_attachment_id}
    */
    readonly transitGatewayAttachmentId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_transit_gateway_attachment_accepter#timeouts AwsNetworkfirewallFirewallTransitGatewayAttachmentAccepter#timeouts}
    */
    readonly timeouts?: AwsNetworkfirewallFirewallTransitGatewayAttachmentAccepter.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_transit_gateway_attachment_accepter aws_networkfirewall_firewall_transit_gateway_attachment_accepter}
*/
export declare class AwsNetworkfirewallFirewallTransitGatewayAttachmentAccepter extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_networkfirewall_firewall_transit_gateway_attachment_accepter";
    /**
    * Generates CDKTN code for importing a AwsNetworkfirewallFirewallTransitGatewayAttachmentAccepter resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsNetworkfirewallFirewallTransitGatewayAttachmentAccepter to import
    * @param importFromId The id of the existing AwsNetworkfirewallFirewallTransitGatewayAttachmentAccepter that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_transit_gateway_attachment_accepter#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsNetworkfirewallFirewallTransitGatewayAttachmentAccepter to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_transit_gateway_attachment_accepter aws_networkfirewall_firewall_transit_gateway_attachment_accepter} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsNetworkfirewallFirewallTransitGatewayAttachmentAccepterConfig
    */
    constructor(scope: Construct, id: string, config: AwsNetworkfirewallFirewallTransitGatewayAttachmentAccepterConfig);
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _transitGatewayAttachmentId?;
    get transitGatewayAttachmentId(): string;
    set transitGatewayAttachmentId(value: string);
    get transitGatewayAttachmentIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): AwsNetworkfirewallFirewallTransitGatewayAttachmentAccepter.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsNetworkfirewallFirewallTransitGatewayAttachmentAccepter.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsNetworkfirewallFirewallTransitGatewayAttachmentAccepter.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsNetworkfirewallFirewallTransitGatewayAttachmentAccepterTimeoutsPropertyToTerraform(struct?: AwsNetworkfirewallFirewallTransitGatewayAttachmentAccepter.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsNetworkfirewallFirewallTransitGatewayAttachmentAccepterTimeoutsPropertyToHclTerraform(struct?: AwsNetworkfirewallFirewallTransitGatewayAttachmentAccepter.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsNetworkfirewallFirewallTransitGatewayAttachmentAccepter {
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_transit_gateway_attachment_accepter#create AwsNetworkfirewallFirewallTransitGatewayAttachmentAccepter#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_transit_gateway_attachment_accepter#delete AwsNetworkfirewallFirewallTransitGatewayAttachmentAccepter#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
