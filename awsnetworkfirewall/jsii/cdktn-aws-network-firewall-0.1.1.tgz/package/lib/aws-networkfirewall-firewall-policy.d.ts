import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsNetworkfirewallFirewallPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#description AwsNetworkfirewallFirewallPolicy#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#id AwsNetworkfirewallFirewallPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#name AwsNetworkfirewallFirewallPolicy#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#region AwsNetworkfirewallFirewallPolicy#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#tags AwsNetworkfirewallFirewallPolicy#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#tags_all AwsNetworkfirewallFirewallPolicy#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * encryption_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#encryption_configuration AwsNetworkfirewallFirewallPolicy#encryption_configuration}
    */
    readonly encryptionConfiguration?: AwsNetworkfirewallFirewallPolicy.EncryptionConfigurationProperty;
    /**
    * firewall_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#firewall_policy AwsNetworkfirewallFirewallPolicy#firewall_policy}
    */
    readonly firewallPolicy: AwsNetworkfirewallFirewallPolicy.FirewallPolicyProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy aws_networkfirewall_firewall_policy}
*/
export declare class AwsNetworkfirewallFirewallPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_networkfirewall_firewall_policy";
    /**
    * Generates CDKTN code for importing a AwsNetworkfirewallFirewallPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsNetworkfirewallFirewallPolicy to import
    * @param importFromId The id of the existing AwsNetworkfirewallFirewallPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsNetworkfirewallFirewallPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy aws_networkfirewall_firewall_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsNetworkfirewallFirewallPolicyConfig
    */
    constructor(scope: Construct, id: string, config: AwsNetworkfirewallFirewallPolicyConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get updateToken(): string;
    private _encryptionConfiguration;
    get encryptionConfiguration(): AwsNetworkfirewallFirewallPolicy.EncryptionConfigurationPropertyOutputReference;
    putEncryptionConfiguration(value: AwsNetworkfirewallFirewallPolicy.EncryptionConfigurationProperty): void;
    resetEncryptionConfiguration(): void;
    get encryptionConfigurationInput(): AwsNetworkfirewallFirewallPolicy.EncryptionConfigurationProperty | undefined;
    private _firewallPolicy;
    get firewallPolicy(): AwsNetworkfirewallFirewallPolicy.FirewallPolicyPropertyOutputReference;
    putFirewallPolicy(value: AwsNetworkfirewallFirewallPolicy.FirewallPolicyProperty): void;
    get firewallPolicyInput(): AwsNetworkfirewallFirewallPolicy.FirewallPolicyProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsNetworkfirewallFirewallPolicyEncryptionConfigurationPropertyToTerraform(struct?: AwsNetworkfirewallFirewallPolicy.EncryptionConfigurationPropertyOutputReference | AwsNetworkfirewallFirewallPolicy.EncryptionConfigurationProperty): any;
export declare function awsNetworkfirewallFirewallPolicyEncryptionConfigurationPropertyToHclTerraform(struct?: AwsNetworkfirewallFirewallPolicy.EncryptionConfigurationPropertyOutputReference | AwsNetworkfirewallFirewallPolicy.EncryptionConfigurationProperty): any;
export declare function awsNetworkfirewallFirewallPolicyIpSetPropertyToTerraform(struct?: AwsNetworkfirewallFirewallPolicy.IpSetPropertyOutputReference | AwsNetworkfirewallFirewallPolicy.IpSetProperty): any;
export declare function awsNetworkfirewallFirewallPolicyIpSetPropertyToHclTerraform(struct?: AwsNetworkfirewallFirewallPolicy.IpSetPropertyOutputReference | AwsNetworkfirewallFirewallPolicy.IpSetProperty): any;
export declare function awsNetworkfirewallFirewallPolicyRuleVariablesPropertyToTerraform(struct?: AwsNetworkfirewallFirewallPolicy.RuleVariablesProperty | cdktn.IResolvable): any;
export declare function awsNetworkfirewallFirewallPolicyRuleVariablesPropertyToHclTerraform(struct?: AwsNetworkfirewallFirewallPolicy.RuleVariablesProperty | cdktn.IResolvable): any;
export declare function awsNetworkfirewallFirewallPolicyPolicyVariablesPropertyToTerraform(struct?: AwsNetworkfirewallFirewallPolicy.PolicyVariablesPropertyOutputReference | AwsNetworkfirewallFirewallPolicy.PolicyVariablesProperty): any;
export declare function awsNetworkfirewallFirewallPolicyPolicyVariablesPropertyToHclTerraform(struct?: AwsNetworkfirewallFirewallPolicy.PolicyVariablesPropertyOutputReference | AwsNetworkfirewallFirewallPolicy.PolicyVariablesProperty): any;
export declare function awsNetworkfirewallFirewallPolicyFlowTimeoutsPropertyToTerraform(struct?: AwsNetworkfirewallFirewallPolicy.FlowTimeoutsPropertyOutputReference | AwsNetworkfirewallFirewallPolicy.FlowTimeoutsProperty): any;
export declare function awsNetworkfirewallFirewallPolicyFlowTimeoutsPropertyToHclTerraform(struct?: AwsNetworkfirewallFirewallPolicy.FlowTimeoutsPropertyOutputReference | AwsNetworkfirewallFirewallPolicy.FlowTimeoutsProperty): any;
export declare function awsNetworkfirewallFirewallPolicyStatefulEngineOptionsPropertyToTerraform(struct?: AwsNetworkfirewallFirewallPolicy.StatefulEngineOptionsPropertyOutputReference | AwsNetworkfirewallFirewallPolicy.StatefulEngineOptionsProperty): any;
export declare function awsNetworkfirewallFirewallPolicyStatefulEngineOptionsPropertyToHclTerraform(struct?: AwsNetworkfirewallFirewallPolicy.StatefulEngineOptionsPropertyOutputReference | AwsNetworkfirewallFirewallPolicy.StatefulEngineOptionsProperty): any;
export declare function awsNetworkfirewallFirewallPolicyOverridePropertyToTerraform(struct?: AwsNetworkfirewallFirewallPolicy.OverridePropertyOutputReference | AwsNetworkfirewallFirewallPolicy.OverrideProperty): any;
export declare function awsNetworkfirewallFirewallPolicyOverridePropertyToHclTerraform(struct?: AwsNetworkfirewallFirewallPolicy.OverridePropertyOutputReference | AwsNetworkfirewallFirewallPolicy.OverrideProperty): any;
export declare function awsNetworkfirewallFirewallPolicyStatefulRuleGroupReferencePropertyToTerraform(struct?: AwsNetworkfirewallFirewallPolicy.StatefulRuleGroupReferenceProperty | cdktn.IResolvable): any;
export declare function awsNetworkfirewallFirewallPolicyStatefulRuleGroupReferencePropertyToHclTerraform(struct?: AwsNetworkfirewallFirewallPolicy.StatefulRuleGroupReferenceProperty | cdktn.IResolvable): any;
export declare function awsNetworkfirewallFirewallPolicyDimensionPropertyToTerraform(struct?: AwsNetworkfirewallFirewallPolicy.DimensionProperty | cdktn.IResolvable): any;
export declare function awsNetworkfirewallFirewallPolicyDimensionPropertyToHclTerraform(struct?: AwsNetworkfirewallFirewallPolicy.DimensionProperty | cdktn.IResolvable): any;
export declare function awsNetworkfirewallFirewallPolicyPublishMetricActionPropertyToTerraform(struct?: AwsNetworkfirewallFirewallPolicy.PublishMetricActionPropertyOutputReference | AwsNetworkfirewallFirewallPolicy.PublishMetricActionProperty): any;
export declare function awsNetworkfirewallFirewallPolicyPublishMetricActionPropertyToHclTerraform(struct?: AwsNetworkfirewallFirewallPolicy.PublishMetricActionPropertyOutputReference | AwsNetworkfirewallFirewallPolicy.PublishMetricActionProperty): any;
export declare function awsNetworkfirewallFirewallPolicyActionDefinitionPropertyToTerraform(struct?: AwsNetworkfirewallFirewallPolicy.ActionDefinitionPropertyOutputReference | AwsNetworkfirewallFirewallPolicy.ActionDefinitionProperty): any;
export declare function awsNetworkfirewallFirewallPolicyActionDefinitionPropertyToHclTerraform(struct?: AwsNetworkfirewallFirewallPolicy.ActionDefinitionPropertyOutputReference | AwsNetworkfirewallFirewallPolicy.ActionDefinitionProperty): any;
export declare function awsNetworkfirewallFirewallPolicyStatelessCustomActionPropertyToTerraform(struct?: AwsNetworkfirewallFirewallPolicy.StatelessCustomActionProperty | cdktn.IResolvable): any;
export declare function awsNetworkfirewallFirewallPolicyStatelessCustomActionPropertyToHclTerraform(struct?: AwsNetworkfirewallFirewallPolicy.StatelessCustomActionProperty | cdktn.IResolvable): any;
export declare function awsNetworkfirewallFirewallPolicyStatelessRuleGroupReferencePropertyToTerraform(struct?: AwsNetworkfirewallFirewallPolicy.StatelessRuleGroupReferenceProperty | cdktn.IResolvable): any;
export declare function awsNetworkfirewallFirewallPolicyStatelessRuleGroupReferencePropertyToHclTerraform(struct?: AwsNetworkfirewallFirewallPolicy.StatelessRuleGroupReferenceProperty | cdktn.IResolvable): any;
export declare function awsNetworkfirewallFirewallPolicyFirewallPolicyPropertyToTerraform(struct?: AwsNetworkfirewallFirewallPolicy.FirewallPolicyPropertyOutputReference | AwsNetworkfirewallFirewallPolicy.FirewallPolicyProperty): any;
export declare function awsNetworkfirewallFirewallPolicyFirewallPolicyPropertyToHclTerraform(struct?: AwsNetworkfirewallFirewallPolicy.FirewallPolicyPropertyOutputReference | AwsNetworkfirewallFirewallPolicy.FirewallPolicyProperty): any;
export declare namespace AwsNetworkfirewallFirewallPolicy {
    interface EncryptionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#key_id AwsNetworkfirewallFirewallPolicy#key_id}
        */
        readonly keyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#type AwsNetworkfirewallFirewallPolicy#type}
        */
        readonly type: string;
    }
    class EncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncryptionConfigurationProperty | undefined;
        set internalValue(value: EncryptionConfigurationProperty | undefined);
        private _keyId?;
        get keyId(): string;
        set keyId(value: string);
        resetKeyId(): void;
        get keyIdInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    interface IpSetProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#definition AwsNetworkfirewallFirewallPolicy#definition}
        */
        readonly definition: string[];
    }
    class IpSetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IpSetProperty | undefined;
        set internalValue(value: IpSetProperty | undefined);
        private _definition?;
        get definition(): string[];
        set definition(value: string[]);
        get definitionInput(): string[] | undefined;
    }
    interface RuleVariablesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#key AwsNetworkfirewallFirewallPolicy#key}
        */
        readonly key: string;
        /**
        * ip_set block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#ip_set AwsNetworkfirewallFirewallPolicy#ip_set}
        */
        readonly ipSet: IpSetProperty;
    }
    class RuleVariablesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleVariablesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuleVariablesProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _ipSet;
        get ipSet(): IpSetPropertyOutputReference;
        putIpSet(value: IpSetProperty): void;
        get ipSetInput(): IpSetProperty | undefined;
    }
    class RuleVariablesPropertyList extends cdktn.ComplexList {
        internalValue?: RuleVariablesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleVariablesPropertyOutputReference;
    }
    interface PolicyVariablesProperty {
        /**
        * rule_variables block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#rule_variables AwsNetworkfirewallFirewallPolicy#rule_variables}
        */
        readonly ruleVariables?: RuleVariablesProperty[] | cdktn.IResolvable;
    }
    class PolicyVariablesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PolicyVariablesProperty | undefined;
        set internalValue(value: PolicyVariablesProperty | undefined);
        private _ruleVariables;
        get ruleVariables(): RuleVariablesPropertyList;
        putRuleVariables(value: RuleVariablesProperty[] | cdktn.IResolvable): void;
        resetRuleVariables(): void;
        get ruleVariablesInput(): cdktn.IResolvable | RuleVariablesProperty[] | undefined;
    }
    interface FlowTimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#tcp_idle_timeout_seconds AwsNetworkfirewallFirewallPolicy#tcp_idle_timeout_seconds}
        */
        readonly tcpIdleTimeoutSeconds?: number;
    }
    class FlowTimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FlowTimeoutsProperty | undefined;
        set internalValue(value: FlowTimeoutsProperty | undefined);
        private _tcpIdleTimeoutSeconds?;
        get tcpIdleTimeoutSeconds(): number;
        set tcpIdleTimeoutSeconds(value: number);
        resetTcpIdleTimeoutSeconds(): void;
        get tcpIdleTimeoutSecondsInput(): number | undefined;
    }
    interface StatefulEngineOptionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#rule_order AwsNetworkfirewallFirewallPolicy#rule_order}
        */
        readonly ruleOrder?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#stream_exception_policy AwsNetworkfirewallFirewallPolicy#stream_exception_policy}
        */
        readonly streamExceptionPolicy?: string;
        /**
        * flow_timeouts block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#flow_timeouts AwsNetworkfirewallFirewallPolicy#flow_timeouts}
        */
        readonly flowTimeouts?: FlowTimeoutsProperty;
    }
    class StatefulEngineOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StatefulEngineOptionsProperty | undefined;
        set internalValue(value: StatefulEngineOptionsProperty | undefined);
        private _ruleOrder?;
        get ruleOrder(): string;
        set ruleOrder(value: string);
        resetRuleOrder(): void;
        get ruleOrderInput(): string | undefined;
        private _streamExceptionPolicy?;
        get streamExceptionPolicy(): string;
        set streamExceptionPolicy(value: string);
        resetStreamExceptionPolicy(): void;
        get streamExceptionPolicyInput(): string | undefined;
        private _flowTimeouts;
        get flowTimeouts(): FlowTimeoutsPropertyOutputReference;
        putFlowTimeouts(value: FlowTimeoutsProperty): void;
        resetFlowTimeouts(): void;
        get flowTimeoutsInput(): FlowTimeoutsProperty | undefined;
    }
    interface OverrideProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#action AwsNetworkfirewallFirewallPolicy#action}
        */
        readonly action?: string;
    }
    class OverridePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OverrideProperty | undefined;
        set internalValue(value: OverrideProperty | undefined);
        private _action?;
        get action(): string;
        set action(value: string);
        resetAction(): void;
        get actionInput(): string | undefined;
    }
    interface StatefulRuleGroupReferenceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#deep_threat_inspection AwsNetworkfirewallFirewallPolicy#deep_threat_inspection}
        */
        readonly deepThreatInspection?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#priority AwsNetworkfirewallFirewallPolicy#priority}
        */
        readonly priority?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#resource_arn AwsNetworkfirewallFirewallPolicy#resource_arn}
        */
        readonly resourceArn: string;
        /**
        * override block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#override AwsNetworkfirewallFirewallPolicy#override}
        */
        readonly override?: OverrideProperty;
    }
    class StatefulRuleGroupReferencePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StatefulRuleGroupReferenceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StatefulRuleGroupReferenceProperty | cdktn.IResolvable | undefined);
        private _deepThreatInspection?;
        get deepThreatInspection(): string;
        set deepThreatInspection(value: string);
        resetDeepThreatInspection(): void;
        get deepThreatInspectionInput(): string | undefined;
        private _priority?;
        get priority(): number;
        set priority(value: number);
        resetPriority(): void;
        get priorityInput(): number | undefined;
        private _resourceArn?;
        get resourceArn(): string;
        set resourceArn(value: string);
        get resourceArnInput(): string | undefined;
        private _override;
        get override(): OverridePropertyOutputReference;
        putOverride(value: OverrideProperty): void;
        resetOverride(): void;
        get overrideInput(): OverrideProperty | undefined;
    }
    class StatefulRuleGroupReferencePropertyList extends cdktn.ComplexList {
        internalValue?: StatefulRuleGroupReferenceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StatefulRuleGroupReferencePropertyOutputReference;
    }
    interface DimensionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#value AwsNetworkfirewallFirewallPolicy#value}
        */
        readonly value: string;
    }
    class DimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DimensionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DimensionProperty | cdktn.IResolvable | undefined);
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class DimensionPropertyList extends cdktn.ComplexList {
        internalValue?: DimensionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DimensionPropertyOutputReference;
    }
    interface PublishMetricActionProperty {
        /**
        * dimension block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#dimension AwsNetworkfirewallFirewallPolicy#dimension}
        */
        readonly dimension: DimensionProperty[] | cdktn.IResolvable;
    }
    class PublishMetricActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PublishMetricActionProperty | undefined;
        set internalValue(value: PublishMetricActionProperty | undefined);
        private _dimension;
        get dimension(): DimensionPropertyList;
        putDimension(value: DimensionProperty[] | cdktn.IResolvable): void;
        get dimensionInput(): cdktn.IResolvable | DimensionProperty[] | undefined;
    }
    interface ActionDefinitionProperty {
        /**
        * publish_metric_action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#publish_metric_action AwsNetworkfirewallFirewallPolicy#publish_metric_action}
        */
        readonly publishMetricAction: PublishMetricActionProperty;
    }
    class ActionDefinitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ActionDefinitionProperty | undefined;
        set internalValue(value: ActionDefinitionProperty | undefined);
        private _publishMetricAction;
        get publishMetricAction(): PublishMetricActionPropertyOutputReference;
        putPublishMetricAction(value: PublishMetricActionProperty): void;
        get publishMetricActionInput(): PublishMetricActionProperty | undefined;
    }
    interface StatelessCustomActionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#action_name AwsNetworkfirewallFirewallPolicy#action_name}
        */
        readonly actionName: string;
        /**
        * action_definition block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#action_definition AwsNetworkfirewallFirewallPolicy#action_definition}
        */
        readonly actionDefinition: ActionDefinitionProperty;
    }
    class StatelessCustomActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StatelessCustomActionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StatelessCustomActionProperty | cdktn.IResolvable | undefined);
        private _actionName?;
        get actionName(): string;
        set actionName(value: string);
        get actionNameInput(): string | undefined;
        private _actionDefinition;
        get actionDefinition(): ActionDefinitionPropertyOutputReference;
        putActionDefinition(value: ActionDefinitionProperty): void;
        get actionDefinitionInput(): ActionDefinitionProperty | undefined;
    }
    class StatelessCustomActionPropertyList extends cdktn.ComplexList {
        internalValue?: StatelessCustomActionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StatelessCustomActionPropertyOutputReference;
    }
    interface StatelessRuleGroupReferenceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#priority AwsNetworkfirewallFirewallPolicy#priority}
        */
        readonly priority: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#resource_arn AwsNetworkfirewallFirewallPolicy#resource_arn}
        */
        readonly resourceArn: string;
    }
    class StatelessRuleGroupReferencePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StatelessRuleGroupReferenceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: StatelessRuleGroupReferenceProperty | cdktn.IResolvable | undefined);
        private _priority?;
        get priority(): number;
        set priority(value: number);
        get priorityInput(): number | undefined;
        private _resourceArn?;
        get resourceArn(): string;
        set resourceArn(value: string);
        get resourceArnInput(): string | undefined;
    }
    class StatelessRuleGroupReferencePropertyList extends cdktn.ComplexList {
        internalValue?: StatelessRuleGroupReferenceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StatelessRuleGroupReferencePropertyOutputReference;
    }
    interface FirewallPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#enable_tls_session_holding AwsNetworkfirewallFirewallPolicy#enable_tls_session_holding}
        */
        readonly enableTlsSessionHolding?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#stateful_default_actions AwsNetworkfirewallFirewallPolicy#stateful_default_actions}
        */
        readonly statefulDefaultActions?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#stateless_default_actions AwsNetworkfirewallFirewallPolicy#stateless_default_actions}
        */
        readonly statelessDefaultActions: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#stateless_fragment_default_actions AwsNetworkfirewallFirewallPolicy#stateless_fragment_default_actions}
        */
        readonly statelessFragmentDefaultActions: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#tls_inspection_configuration_arn AwsNetworkfirewallFirewallPolicy#tls_inspection_configuration_arn}
        */
        readonly tlsInspectionConfigurationArn?: string;
        /**
        * policy_variables block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#policy_variables AwsNetworkfirewallFirewallPolicy#policy_variables}
        */
        readonly policyVariables?: PolicyVariablesProperty;
        /**
        * stateful_engine_options block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#stateful_engine_options AwsNetworkfirewallFirewallPolicy#stateful_engine_options}
        */
        readonly statefulEngineOptions?: StatefulEngineOptionsProperty;
        /**
        * stateful_rule_group_reference block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#stateful_rule_group_reference AwsNetworkfirewallFirewallPolicy#stateful_rule_group_reference}
        */
        readonly statefulRuleGroupReference?: StatefulRuleGroupReferenceProperty[] | cdktn.IResolvable;
        /**
        * stateless_custom_action block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#stateless_custom_action AwsNetworkfirewallFirewallPolicy#stateless_custom_action}
        */
        readonly statelessCustomAction?: StatelessCustomActionProperty[] | cdktn.IResolvable;
        /**
        * stateless_rule_group_reference block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall_policy#stateless_rule_group_reference AwsNetworkfirewallFirewallPolicy#stateless_rule_group_reference}
        */
        readonly statelessRuleGroupReference?: StatelessRuleGroupReferenceProperty[] | cdktn.IResolvable;
    }
    class FirewallPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FirewallPolicyProperty | undefined;
        set internalValue(value: FirewallPolicyProperty | undefined);
        private _enableTlsSessionHolding?;
        get enableTlsSessionHolding(): boolean | cdktn.IResolvable;
        set enableTlsSessionHolding(value: boolean | cdktn.IResolvable);
        resetEnableTlsSessionHolding(): void;
        get enableTlsSessionHoldingInput(): boolean | cdktn.IResolvable | undefined;
        private _statefulDefaultActions?;
        get statefulDefaultActions(): string[];
        set statefulDefaultActions(value: string[]);
        resetStatefulDefaultActions(): void;
        get statefulDefaultActionsInput(): string[] | undefined;
        private _statelessDefaultActions?;
        get statelessDefaultActions(): string[];
        set statelessDefaultActions(value: string[]);
        get statelessDefaultActionsInput(): string[] | undefined;
        private _statelessFragmentDefaultActions?;
        get statelessFragmentDefaultActions(): string[];
        set statelessFragmentDefaultActions(value: string[]);
        get statelessFragmentDefaultActionsInput(): string[] | undefined;
        private _tlsInspectionConfigurationArn?;
        get tlsInspectionConfigurationArn(): string;
        set tlsInspectionConfigurationArn(value: string);
        resetTlsInspectionConfigurationArn(): void;
        get tlsInspectionConfigurationArnInput(): string | undefined;
        private _policyVariables;
        get policyVariables(): PolicyVariablesPropertyOutputReference;
        putPolicyVariables(value: PolicyVariablesProperty): void;
        resetPolicyVariables(): void;
        get policyVariablesInput(): PolicyVariablesProperty | undefined;
        private _statefulEngineOptions;
        get statefulEngineOptions(): StatefulEngineOptionsPropertyOutputReference;
        putStatefulEngineOptions(value: StatefulEngineOptionsProperty): void;
        resetStatefulEngineOptions(): void;
        get statefulEngineOptionsInput(): StatefulEngineOptionsProperty | undefined;
        private _statefulRuleGroupReference;
        get statefulRuleGroupReference(): StatefulRuleGroupReferencePropertyList;
        putStatefulRuleGroupReference(value: StatefulRuleGroupReferenceProperty[] | cdktn.IResolvable): void;
        resetStatefulRuleGroupReference(): void;
        get statefulRuleGroupReferenceInput(): cdktn.IResolvable | StatefulRuleGroupReferenceProperty[] | undefined;
        private _statelessCustomAction;
        get statelessCustomAction(): StatelessCustomActionPropertyList;
        putStatelessCustomAction(value: StatelessCustomActionProperty[] | cdktn.IResolvable): void;
        resetStatelessCustomAction(): void;
        get statelessCustomActionInput(): cdktn.IResolvable | StatelessCustomActionProperty[] | undefined;
        private _statelessRuleGroupReference;
        get statelessRuleGroupReference(): StatelessRuleGroupReferencePropertyList;
        putStatelessRuleGroupReference(value: StatelessRuleGroupReferenceProperty[] | cdktn.IResolvable): void;
        resetStatelessRuleGroupReference(): void;
        get statelessRuleGroupReferenceInput(): cdktn.IResolvable | StatelessRuleGroupReferenceProperty[] | undefined;
    }
}
