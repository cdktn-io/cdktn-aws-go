import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsNetworkfirewallFirewallConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall#availability_zone_change_protection AwsNetworkfirewallFirewall#availability_zone_change_protection}
    */
    readonly availabilityZoneChangeProtection?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall#delete_protection AwsNetworkfirewallFirewall#delete_protection}
    */
    readonly deleteProtection?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall#description AwsNetworkfirewallFirewall#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall#enabled_analysis_types AwsNetworkfirewallFirewall#enabled_analysis_types}
    */
    readonly enabledAnalysisTypes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall#firewall_policy_arn AwsNetworkfirewallFirewall#firewall_policy_arn}
    */
    readonly firewallPolicyArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall#firewall_policy_change_protection AwsNetworkfirewallFirewall#firewall_policy_change_protection}
    */
    readonly firewallPolicyChangeProtection?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall#id AwsNetworkfirewallFirewall#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall#name AwsNetworkfirewallFirewall#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall#region AwsNetworkfirewallFirewall#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall#subnet_change_protection AwsNetworkfirewallFirewall#subnet_change_protection}
    */
    readonly subnetChangeProtection?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall#tags AwsNetworkfirewallFirewall#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall#tags_all AwsNetworkfirewallFirewall#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall#transit_gateway_id AwsNetworkfirewallFirewall#transit_gateway_id}
    */
    readonly transitGatewayId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall#vpc_id AwsNetworkfirewallFirewall#vpc_id}
    */
    readonly vpcId?: string;
    /**
    * availability_zone_mapping block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall#availability_zone_mapping AwsNetworkfirewallFirewall#availability_zone_mapping}
    */
    readonly availabilityZoneMapping?: AwsNetworkfirewallFirewall.AvailabilityZoneMappingProperty[] | cdktn.IResolvable;
    /**
    * encryption_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall#encryption_configuration AwsNetworkfirewallFirewall#encryption_configuration}
    */
    readonly encryptionConfiguration?: AwsNetworkfirewallFirewall.EncryptionConfigurationProperty;
    /**
    * subnet_mapping block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall#subnet_mapping AwsNetworkfirewallFirewall#subnet_mapping}
    */
    readonly subnetMapping?: AwsNetworkfirewallFirewall.SubnetMappingProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall#timeouts AwsNetworkfirewallFirewall#timeouts}
    */
    readonly timeouts?: AwsNetworkfirewallFirewall.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall aws_networkfirewall_firewall}
*/
export declare class AwsNetworkfirewallFirewall extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_networkfirewall_firewall";
    /**
    * Generates CDKTN code for importing a AwsNetworkfirewallFirewall resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsNetworkfirewallFirewall to import
    * @param importFromId The id of the existing AwsNetworkfirewallFirewall that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsNetworkfirewallFirewall to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall aws_networkfirewall_firewall} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsNetworkfirewallFirewallConfig
    */
    constructor(scope: Construct, id: string, config: AwsNetworkfirewallFirewallConfig);
    get arn(): string;
    private _availabilityZoneChangeProtection?;
    get availabilityZoneChangeProtection(): boolean | cdktn.IResolvable;
    set availabilityZoneChangeProtection(value: boolean | cdktn.IResolvable);
    resetAvailabilityZoneChangeProtection(): void;
    get availabilityZoneChangeProtectionInput(): boolean | cdktn.IResolvable | undefined;
    private _deleteProtection?;
    get deleteProtection(): boolean | cdktn.IResolvable;
    set deleteProtection(value: boolean | cdktn.IResolvable);
    resetDeleteProtection(): void;
    get deleteProtectionInput(): boolean | cdktn.IResolvable | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _enabledAnalysisTypes?;
    get enabledAnalysisTypes(): string[];
    set enabledAnalysisTypes(value: string[]);
    resetEnabledAnalysisTypes(): void;
    get enabledAnalysisTypesInput(): string[] | undefined;
    private _firewallPolicyArn?;
    get firewallPolicyArn(): string;
    set firewallPolicyArn(value: string);
    get firewallPolicyArnInput(): string | undefined;
    private _firewallPolicyChangeProtection?;
    get firewallPolicyChangeProtection(): boolean | cdktn.IResolvable;
    set firewallPolicyChangeProtection(value: boolean | cdktn.IResolvable);
    resetFirewallPolicyChangeProtection(): void;
    get firewallPolicyChangeProtectionInput(): boolean | cdktn.IResolvable | undefined;
    private _firewallStatus;
    get firewallStatus(): AwsNetworkfirewallFirewall.FirewallStatusPropertyList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _subnetChangeProtection?;
    get subnetChangeProtection(): boolean | cdktn.IResolvable;
    set subnetChangeProtection(value: boolean | cdktn.IResolvable);
    resetSubnetChangeProtection(): void;
    get subnetChangeProtectionInput(): boolean | cdktn.IResolvable | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _transitGatewayId?;
    get transitGatewayId(): string;
    set transitGatewayId(value: string);
    resetTransitGatewayId(): void;
    get transitGatewayIdInput(): string | undefined;
    get transitGatewayOwnerAccountId(): string;
    get updateToken(): string;
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    resetVpcId(): void;
    get vpcIdInput(): string | undefined;
    private _availabilityZoneMapping;
    get availabilityZoneMapping(): AwsNetworkfirewallFirewall.AvailabilityZoneMappingPropertyList;
    putAvailabilityZoneMapping(value: AwsNetworkfirewallFirewall.AvailabilityZoneMappingProperty[] | cdktn.IResolvable): void;
    resetAvailabilityZoneMapping(): void;
    get availabilityZoneMappingInput(): cdktn.IResolvable | AwsNetworkfirewallFirewall.AvailabilityZoneMappingProperty[] | undefined;
    private _encryptionConfiguration;
    get encryptionConfiguration(): AwsNetworkfirewallFirewall.EncryptionConfigurationPropertyOutputReference;
    putEncryptionConfiguration(value: AwsNetworkfirewallFirewall.EncryptionConfigurationProperty): void;
    resetEncryptionConfiguration(): void;
    get encryptionConfigurationInput(): AwsNetworkfirewallFirewall.EncryptionConfigurationProperty | undefined;
    private _subnetMapping;
    get subnetMapping(): AwsNetworkfirewallFirewall.SubnetMappingPropertyList;
    putSubnetMapping(value: AwsNetworkfirewallFirewall.SubnetMappingProperty[] | cdktn.IResolvable): void;
    resetSubnetMapping(): void;
    get subnetMappingInput(): cdktn.IResolvable | AwsNetworkfirewallFirewall.SubnetMappingProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsNetworkfirewallFirewall.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsNetworkfirewallFirewall.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsNetworkfirewallFirewall.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsNetworkfirewallFirewallAttachmentPropertyToTerraform(struct?: AwsNetworkfirewallFirewall.AttachmentProperty): any;
export declare function awsNetworkfirewallFirewallAttachmentPropertyToHclTerraform(struct?: AwsNetworkfirewallFirewall.AttachmentProperty): any;
export declare function awsNetworkfirewallFirewallSyncStatesPropertyToTerraform(struct?: AwsNetworkfirewallFirewall.SyncStatesProperty): any;
export declare function awsNetworkfirewallFirewallSyncStatesPropertyToHclTerraform(struct?: AwsNetworkfirewallFirewall.SyncStatesProperty): any;
export declare function awsNetworkfirewallFirewallTransitGatewayAttachmentSyncStatesPropertyToTerraform(struct?: AwsNetworkfirewallFirewall.TransitGatewayAttachmentSyncStatesProperty): any;
export declare function awsNetworkfirewallFirewallTransitGatewayAttachmentSyncStatesPropertyToHclTerraform(struct?: AwsNetworkfirewallFirewall.TransitGatewayAttachmentSyncStatesProperty): any;
export declare function awsNetworkfirewallFirewallFirewallStatusPropertyToTerraform(struct?: AwsNetworkfirewallFirewall.FirewallStatusProperty): any;
export declare function awsNetworkfirewallFirewallFirewallStatusPropertyToHclTerraform(struct?: AwsNetworkfirewallFirewall.FirewallStatusProperty): any;
export declare function awsNetworkfirewallFirewallAvailabilityZoneMappingPropertyToTerraform(struct?: AwsNetworkfirewallFirewall.AvailabilityZoneMappingProperty | cdktn.IResolvable): any;
export declare function awsNetworkfirewallFirewallAvailabilityZoneMappingPropertyToHclTerraform(struct?: AwsNetworkfirewallFirewall.AvailabilityZoneMappingProperty | cdktn.IResolvable): any;
export declare function awsNetworkfirewallFirewallEncryptionConfigurationPropertyToTerraform(struct?: AwsNetworkfirewallFirewall.EncryptionConfigurationPropertyOutputReference | AwsNetworkfirewallFirewall.EncryptionConfigurationProperty): any;
export declare function awsNetworkfirewallFirewallEncryptionConfigurationPropertyToHclTerraform(struct?: AwsNetworkfirewallFirewall.EncryptionConfigurationPropertyOutputReference | AwsNetworkfirewallFirewall.EncryptionConfigurationProperty): any;
export declare function awsNetworkfirewallFirewallSubnetMappingPropertyToTerraform(struct?: AwsNetworkfirewallFirewall.SubnetMappingProperty | cdktn.IResolvable): any;
export declare function awsNetworkfirewallFirewallSubnetMappingPropertyToHclTerraform(struct?: AwsNetworkfirewallFirewall.SubnetMappingProperty | cdktn.IResolvable): any;
export declare function awsNetworkfirewallFirewallTimeoutsPropertyToTerraform(struct?: AwsNetworkfirewallFirewall.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsNetworkfirewallFirewallTimeoutsPropertyToHclTerraform(struct?: AwsNetworkfirewallFirewall.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsNetworkfirewallFirewall {
    interface AttachmentProperty {
    }
    class AttachmentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AttachmentProperty | undefined;
        set internalValue(value: AttachmentProperty | undefined);
        get endpointId(): string;
        get subnetId(): string;
    }
    class AttachmentPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AttachmentPropertyOutputReference;
    }
    interface SyncStatesProperty {
    }
    class SyncStatesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SyncStatesProperty | undefined;
        set internalValue(value: SyncStatesProperty | undefined);
        private _attachment;
        get attachment(): AttachmentPropertyList;
        get availabilityZone(): string;
    }
    class SyncStatesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SyncStatesPropertyOutputReference;
    }
    interface TransitGatewayAttachmentSyncStatesProperty {
    }
    class TransitGatewayAttachmentSyncStatesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TransitGatewayAttachmentSyncStatesProperty | undefined;
        set internalValue(value: TransitGatewayAttachmentSyncStatesProperty | undefined);
        get attachmentId(): string;
    }
    class TransitGatewayAttachmentSyncStatesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TransitGatewayAttachmentSyncStatesPropertyOutputReference;
    }
    interface FirewallStatusProperty {
    }
    class FirewallStatusPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FirewallStatusProperty | undefined;
        set internalValue(value: FirewallStatusProperty | undefined);
        private _syncStates;
        get syncStates(): SyncStatesPropertyList;
        private _transitGatewayAttachmentSyncStates;
        get transitGatewayAttachmentSyncStates(): TransitGatewayAttachmentSyncStatesPropertyList;
    }
    class FirewallStatusPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FirewallStatusPropertyOutputReference;
    }
    interface AvailabilityZoneMappingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall#availability_zone_id AwsNetworkfirewallFirewall#availability_zone_id}
        */
        readonly availabilityZoneId: string;
    }
    class AvailabilityZoneMappingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AvailabilityZoneMappingProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AvailabilityZoneMappingProperty | cdktn.IResolvable | undefined);
        private _availabilityZoneId?;
        get availabilityZoneId(): string;
        set availabilityZoneId(value: string);
        get availabilityZoneIdInput(): string | undefined;
    }
    class AvailabilityZoneMappingPropertyList extends cdktn.ComplexList {
        internalValue?: AvailabilityZoneMappingProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AvailabilityZoneMappingPropertyOutputReference;
    }
    interface EncryptionConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall#key_id AwsNetworkfirewallFirewall#key_id}
        */
        readonly keyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall#type AwsNetworkfirewallFirewall#type}
        */
        readonly type: string;
    }
    class EncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EncryptionConfigurationProperty | undefined;
        set internalValue(value: EncryptionConfigurationProperty | undefined);
        private _keyId?;
        get keyId(): string;
        set keyId(value: string);
        resetKeyId(): void;
        get keyIdInput(): string | undefined;
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
    }
    interface SubnetMappingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall#ip_address_type AwsNetworkfirewallFirewall#ip_address_type}
        */
        readonly ipAddressType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall#subnet_id AwsNetworkfirewallFirewall#subnet_id}
        */
        readonly subnetId: string;
    }
    class SubnetMappingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SubnetMappingProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SubnetMappingProperty | cdktn.IResolvable | undefined);
        private _ipAddressType?;
        get ipAddressType(): string;
        set ipAddressType(value: string);
        resetIpAddressType(): void;
        get ipAddressTypeInput(): string | undefined;
        private _subnetId?;
        get subnetId(): string;
        set subnetId(value: string);
        get subnetIdInput(): string | undefined;
    }
    class SubnetMappingPropertyList extends cdktn.ComplexList {
        internalValue?: SubnetMappingProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SubnetMappingPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall#create AwsNetworkfirewallFirewall#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall#delete AwsNetworkfirewallFirewall#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_firewall#update AwsNetworkfirewallFirewall#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
