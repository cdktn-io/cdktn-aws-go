import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsNetworkfirewallFirewallPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkfirewall_firewall_policy#arn DataAwsNetworkfirewallFirewallPolicy#arn}
    */
    readonly arn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkfirewall_firewall_policy#id DataAwsNetworkfirewallFirewallPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkfirewall_firewall_policy#name DataAwsNetworkfirewallFirewallPolicy#name}
    */
    readonly name?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkfirewall_firewall_policy#region DataAwsNetworkfirewallFirewallPolicy#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkfirewall_firewall_policy#tags DataAwsNetworkfirewallFirewallPolicy#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkfirewall_firewall_policy aws_networkfirewall_firewall_policy}
*/
export declare class DataAwsNetworkfirewallFirewallPolicy extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_networkfirewall_firewall_policy";
    /**
    * Generates CDKTN code for importing a DataAwsNetworkfirewallFirewallPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsNetworkfirewallFirewallPolicy to import
    * @param importFromId The id of the existing DataAwsNetworkfirewallFirewallPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkfirewall_firewall_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsNetworkfirewallFirewallPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkfirewall_firewall_policy aws_networkfirewall_firewall_policy} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsNetworkfirewallFirewallPolicyConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsNetworkfirewallFirewallPolicyConfig);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    resetArn(): void;
    get arnInput(): string | undefined;
    get description(): string;
    private _firewallPolicy;
    get firewallPolicy(): DataAwsNetworkfirewallFirewallPolicy.FirewallPolicyPropertyList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get updateToken(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsNetworkfirewallFirewallPolicyIpSetPropertyToTerraform(struct?: DataAwsNetworkfirewallFirewallPolicy.IpSetProperty): any;
export declare function dataAwsNetworkfirewallFirewallPolicyIpSetPropertyToHclTerraform(struct?: DataAwsNetworkfirewallFirewallPolicy.IpSetProperty): any;
export declare function dataAwsNetworkfirewallFirewallPolicyRuleVariablesPropertyToTerraform(struct?: DataAwsNetworkfirewallFirewallPolicy.RuleVariablesProperty): any;
export declare function dataAwsNetworkfirewallFirewallPolicyRuleVariablesPropertyToHclTerraform(struct?: DataAwsNetworkfirewallFirewallPolicy.RuleVariablesProperty): any;
export declare function dataAwsNetworkfirewallFirewallPolicyPolicyVariablesPropertyToTerraform(struct?: DataAwsNetworkfirewallFirewallPolicy.PolicyVariablesProperty): any;
export declare function dataAwsNetworkfirewallFirewallPolicyPolicyVariablesPropertyToHclTerraform(struct?: DataAwsNetworkfirewallFirewallPolicy.PolicyVariablesProperty): any;
export declare function dataAwsNetworkfirewallFirewallPolicyFlowTimeoutsPropertyToTerraform(struct?: DataAwsNetworkfirewallFirewallPolicy.FlowTimeoutsProperty): any;
export declare function dataAwsNetworkfirewallFirewallPolicyFlowTimeoutsPropertyToHclTerraform(struct?: DataAwsNetworkfirewallFirewallPolicy.FlowTimeoutsProperty): any;
export declare function dataAwsNetworkfirewallFirewallPolicyStatefulEngineOptionsPropertyToTerraform(struct?: DataAwsNetworkfirewallFirewallPolicy.StatefulEngineOptionsProperty): any;
export declare function dataAwsNetworkfirewallFirewallPolicyStatefulEngineOptionsPropertyToHclTerraform(struct?: DataAwsNetworkfirewallFirewallPolicy.StatefulEngineOptionsProperty): any;
export declare function dataAwsNetworkfirewallFirewallPolicyOverridePropertyToTerraform(struct?: DataAwsNetworkfirewallFirewallPolicy.OverrideProperty): any;
export declare function dataAwsNetworkfirewallFirewallPolicyOverridePropertyToHclTerraform(struct?: DataAwsNetworkfirewallFirewallPolicy.OverrideProperty): any;
export declare function dataAwsNetworkfirewallFirewallPolicyStatefulRuleGroupReferencePropertyToTerraform(struct?: DataAwsNetworkfirewallFirewallPolicy.StatefulRuleGroupReferenceProperty): any;
export declare function dataAwsNetworkfirewallFirewallPolicyStatefulRuleGroupReferencePropertyToHclTerraform(struct?: DataAwsNetworkfirewallFirewallPolicy.StatefulRuleGroupReferenceProperty): any;
export declare function dataAwsNetworkfirewallFirewallPolicyDimensionPropertyToTerraform(struct?: DataAwsNetworkfirewallFirewallPolicy.DimensionProperty): any;
export declare function dataAwsNetworkfirewallFirewallPolicyDimensionPropertyToHclTerraform(struct?: DataAwsNetworkfirewallFirewallPolicy.DimensionProperty): any;
export declare function dataAwsNetworkfirewallFirewallPolicyPublishMetricActionPropertyToTerraform(struct?: DataAwsNetworkfirewallFirewallPolicy.PublishMetricActionProperty): any;
export declare function dataAwsNetworkfirewallFirewallPolicyPublishMetricActionPropertyToHclTerraform(struct?: DataAwsNetworkfirewallFirewallPolicy.PublishMetricActionProperty): any;
export declare function dataAwsNetworkfirewallFirewallPolicyActionDefinitionPropertyToTerraform(struct?: DataAwsNetworkfirewallFirewallPolicy.ActionDefinitionProperty): any;
export declare function dataAwsNetworkfirewallFirewallPolicyActionDefinitionPropertyToHclTerraform(struct?: DataAwsNetworkfirewallFirewallPolicy.ActionDefinitionProperty): any;
export declare function dataAwsNetworkfirewallFirewallPolicyStatelessCustomActionPropertyToTerraform(struct?: DataAwsNetworkfirewallFirewallPolicy.StatelessCustomActionProperty): any;
export declare function dataAwsNetworkfirewallFirewallPolicyStatelessCustomActionPropertyToHclTerraform(struct?: DataAwsNetworkfirewallFirewallPolicy.StatelessCustomActionProperty): any;
export declare function dataAwsNetworkfirewallFirewallPolicyStatelessRuleGroupReferencePropertyToTerraform(struct?: DataAwsNetworkfirewallFirewallPolicy.StatelessRuleGroupReferenceProperty): any;
export declare function dataAwsNetworkfirewallFirewallPolicyStatelessRuleGroupReferencePropertyToHclTerraform(struct?: DataAwsNetworkfirewallFirewallPolicy.StatelessRuleGroupReferenceProperty): any;
export declare function dataAwsNetworkfirewallFirewallPolicyFirewallPolicyPropertyToTerraform(struct?: DataAwsNetworkfirewallFirewallPolicy.FirewallPolicyProperty): any;
export declare function dataAwsNetworkfirewallFirewallPolicyFirewallPolicyPropertyToHclTerraform(struct?: DataAwsNetworkfirewallFirewallPolicy.FirewallPolicyProperty): any;
export declare namespace DataAwsNetworkfirewallFirewallPolicy {
    interface IpSetProperty {
    }
    class IpSetPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IpSetProperty | undefined;
        set internalValue(value: IpSetProperty | undefined);
        get definition(): string[];
    }
    class IpSetPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IpSetPropertyOutputReference;
    }
    interface RuleVariablesProperty {
    }
    class RuleVariablesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuleVariablesProperty | undefined;
        set internalValue(value: RuleVariablesProperty | undefined);
        private _ipSet;
        get ipSet(): IpSetPropertyList;
        get key(): string;
    }
    class RuleVariablesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuleVariablesPropertyOutputReference;
    }
    interface PolicyVariablesProperty {
    }
    class PolicyVariablesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PolicyVariablesProperty | undefined;
        set internalValue(value: PolicyVariablesProperty | undefined);
        private _ruleVariables;
        get ruleVariables(): RuleVariablesPropertyList;
    }
    class PolicyVariablesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PolicyVariablesPropertyOutputReference;
    }
    interface FlowTimeoutsProperty {
    }
    class FlowTimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FlowTimeoutsProperty | undefined;
        set internalValue(value: FlowTimeoutsProperty | undefined);
        get tcpIdleTimeoutSeconds(): number;
    }
    class FlowTimeoutsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FlowTimeoutsPropertyOutputReference;
    }
    interface StatefulEngineOptionsProperty {
    }
    class StatefulEngineOptionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StatefulEngineOptionsProperty | undefined;
        set internalValue(value: StatefulEngineOptionsProperty | undefined);
        private _flowTimeouts;
        get flowTimeouts(): FlowTimeoutsPropertyList;
        get ruleOrder(): string;
        get streamExceptionPolicy(): string;
    }
    class StatefulEngineOptionsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StatefulEngineOptionsPropertyOutputReference;
    }
    interface OverrideProperty {
    }
    class OverridePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): OverrideProperty | undefined;
        set internalValue(value: OverrideProperty | undefined);
        get action(): string;
    }
    class OverridePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): OverridePropertyOutputReference;
    }
    interface StatefulRuleGroupReferenceProperty {
    }
    class StatefulRuleGroupReferencePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StatefulRuleGroupReferenceProperty | undefined;
        set internalValue(value: StatefulRuleGroupReferenceProperty | undefined);
        get deepThreatInspection(): string;
        private _override;
        get override(): OverridePropertyList;
        get priority(): number;
        get resourceArn(): string;
    }
    class StatefulRuleGroupReferencePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StatefulRuleGroupReferencePropertyOutputReference;
    }
    interface DimensionProperty {
    }
    class DimensionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DimensionProperty | undefined;
        set internalValue(value: DimensionProperty | undefined);
        get value(): string;
    }
    class DimensionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DimensionPropertyOutputReference;
    }
    interface PublishMetricActionProperty {
    }
    class PublishMetricActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PublishMetricActionProperty | undefined;
        set internalValue(value: PublishMetricActionProperty | undefined);
        private _dimension;
        get dimension(): DimensionPropertyList;
    }
    class PublishMetricActionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PublishMetricActionPropertyOutputReference;
    }
    interface ActionDefinitionProperty {
    }
    class ActionDefinitionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ActionDefinitionProperty | undefined;
        set internalValue(value: ActionDefinitionProperty | undefined);
        private _publishMetricAction;
        get publishMetricAction(): PublishMetricActionPropertyList;
    }
    class ActionDefinitionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ActionDefinitionPropertyOutputReference;
    }
    interface StatelessCustomActionProperty {
    }
    class StatelessCustomActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StatelessCustomActionProperty | undefined;
        set internalValue(value: StatelessCustomActionProperty | undefined);
        private _actionDefinition;
        get actionDefinition(): ActionDefinitionPropertyList;
        get actionName(): string;
    }
    class StatelessCustomActionPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StatelessCustomActionPropertyOutputReference;
    }
    interface StatelessRuleGroupReferenceProperty {
    }
    class StatelessRuleGroupReferencePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StatelessRuleGroupReferenceProperty | undefined;
        set internalValue(value: StatelessRuleGroupReferenceProperty | undefined);
        get priority(): number;
        get resourceArn(): string;
    }
    class StatelessRuleGroupReferencePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StatelessRuleGroupReferencePropertyOutputReference;
    }
    interface FirewallPolicyProperty {
    }
    class FirewallPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FirewallPolicyProperty | undefined;
        set internalValue(value: FirewallPolicyProperty | undefined);
        get enableTlsSessionHolding(): cdktn.IResolvable;
        private _policyVariables;
        get policyVariables(): PolicyVariablesPropertyList;
        get statefulDefaultActions(): string[];
        private _statefulEngineOptions;
        get statefulEngineOptions(): StatefulEngineOptionsPropertyList;
        private _statefulRuleGroupReference;
        get statefulRuleGroupReference(): StatefulRuleGroupReferencePropertyList;
        private _statelessCustomAction;
        get statelessCustomAction(): StatelessCustomActionPropertyList;
        get statelessDefaultActions(): string[];
        get statelessFragmentDefaultActions(): string[];
        private _statelessRuleGroupReference;
        get statelessRuleGroupReference(): StatelessRuleGroupReferencePropertyList;
        get tlsInspectionConfigurationArn(): string;
    }
    class FirewallPolicyPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FirewallPolicyPropertyOutputReference;
    }
}
