import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsNetworkfirewallContainerAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_container_association#container_association_name AwsNetworkfirewallContainerAssociation#container_association_name}
    */
    readonly containerAssociationName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_container_association#description AwsNetworkfirewallContainerAssociation#description}
    */
    readonly description?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_container_association#region AwsNetworkfirewallContainerAssociation#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_container_association#tags AwsNetworkfirewallContainerAssociation#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_container_association#type AwsNetworkfirewallContainerAssociation#type}
    */
    readonly type: string;
    /**
    * container_monitoring_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_container_association#container_monitoring_configuration AwsNetworkfirewallContainerAssociation#container_monitoring_configuration}
    */
    readonly containerMonitoringConfiguration?: AwsNetworkfirewallContainerAssociation.ContainerMonitoringConfigurationProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_container_association#timeouts AwsNetworkfirewallContainerAssociation#timeouts}
    */
    readonly timeouts?: AwsNetworkfirewallContainerAssociation.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_container_association aws_networkfirewall_container_association}
*/
export declare class AwsNetworkfirewallContainerAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_networkfirewall_container_association";
    /**
    * Generates CDKTN code for importing a AwsNetworkfirewallContainerAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsNetworkfirewallContainerAssociation to import
    * @param importFromId The id of the existing AwsNetworkfirewallContainerAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_container_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsNetworkfirewallContainerAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_container_association aws_networkfirewall_container_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsNetworkfirewallContainerAssociationConfig
    */
    constructor(scope: Construct, id: string, config: AwsNetworkfirewallContainerAssociationConfig);
    get containerAssociationArn(): string;
    private _containerAssociationName?;
    get containerAssociationName(): string;
    set containerAssociationName(value: string);
    get containerAssociationNameInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get resolvedCidrCount(): number;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    get updateToken(): string;
    private _containerMonitoringConfiguration;
    get containerMonitoringConfiguration(): AwsNetworkfirewallContainerAssociation.ContainerMonitoringConfigurationPropertyList;
    putContainerMonitoringConfiguration(value: AwsNetworkfirewallContainerAssociation.ContainerMonitoringConfigurationProperty[] | cdktn.IResolvable): void;
    resetContainerMonitoringConfiguration(): void;
    get containerMonitoringConfigurationInput(): cdktn.IResolvable | AwsNetworkfirewallContainerAssociation.ContainerMonitoringConfigurationProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsNetworkfirewallContainerAssociation.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsNetworkfirewallContainerAssociation.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsNetworkfirewallContainerAssociation.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsNetworkfirewallContainerAssociationAttributeFilterPropertyToTerraform(struct?: AwsNetworkfirewallContainerAssociation.AttributeFilterProperty | cdktn.IResolvable): any;
export declare function awsNetworkfirewallContainerAssociationAttributeFilterPropertyToHclTerraform(struct?: AwsNetworkfirewallContainerAssociation.AttributeFilterProperty | cdktn.IResolvable): any;
export declare function awsNetworkfirewallContainerAssociationContainerMonitoringConfigurationPropertyToTerraform(struct?: AwsNetworkfirewallContainerAssociation.ContainerMonitoringConfigurationProperty | cdktn.IResolvable): any;
export declare function awsNetworkfirewallContainerAssociationContainerMonitoringConfigurationPropertyToHclTerraform(struct?: AwsNetworkfirewallContainerAssociation.ContainerMonitoringConfigurationProperty | cdktn.IResolvable): any;
export declare function awsNetworkfirewallContainerAssociationTimeoutsPropertyToTerraform(struct?: AwsNetworkfirewallContainerAssociation.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsNetworkfirewallContainerAssociationTimeoutsPropertyToHclTerraform(struct?: AwsNetworkfirewallContainerAssociation.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsNetworkfirewallContainerAssociation {
    interface AttributeFilterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_container_association#key AwsNetworkfirewallContainerAssociation#key}
        */
        readonly key: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_container_association#value AwsNetworkfirewallContainerAssociation#value}
        */
        readonly value: string;
    }
    class AttributeFilterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AttributeFilterProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AttributeFilterProperty | cdktn.IResolvable | undefined);
        private _key?;
        get key(): string;
        set key(value: string);
        get keyInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        get valueInput(): string | undefined;
    }
    class AttributeFilterPropertyList extends cdktn.ComplexList {
        internalValue?: AttributeFilterProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AttributeFilterPropertyOutputReference;
    }
    interface ContainerMonitoringConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_container_association#cluster_arn AwsNetworkfirewallContainerAssociation#cluster_arn}
        */
        readonly clusterArn: string;
        /**
        * attribute_filter block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_container_association#attribute_filter AwsNetworkfirewallContainerAssociation#attribute_filter}
        */
        readonly attributeFilter?: AttributeFilterProperty[] | cdktn.IResolvable;
    }
    class ContainerMonitoringConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ContainerMonitoringConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ContainerMonitoringConfigurationProperty | cdktn.IResolvable | undefined);
        private _clusterArn?;
        get clusterArn(): string;
        set clusterArn(value: string);
        get clusterArnInput(): string | undefined;
        private _attributeFilter;
        get attributeFilter(): AttributeFilterPropertyList;
        putAttributeFilter(value: AttributeFilterProperty[] | cdktn.IResolvable): void;
        resetAttributeFilter(): void;
        get attributeFilterInput(): cdktn.IResolvable | AttributeFilterProperty[] | undefined;
    }
    class ContainerMonitoringConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ContainerMonitoringConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ContainerMonitoringConfigurationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_container_association#create AwsNetworkfirewallContainerAssociation#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_container_association#delete AwsNetworkfirewallContainerAssociation#delete}
        */
        readonly delete?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_container_association#update AwsNetworkfirewallContainerAssociation#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
