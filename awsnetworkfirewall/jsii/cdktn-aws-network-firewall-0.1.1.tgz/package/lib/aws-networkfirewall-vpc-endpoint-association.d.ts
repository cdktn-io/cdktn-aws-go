import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsNetworkfirewallVpcEndpointAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_vpc_endpoint_association#description AwsNetworkfirewallVpcEndpointAssociation#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_vpc_endpoint_association#firewall_arn AwsNetworkfirewallVpcEndpointAssociation#firewall_arn}
    */
    readonly firewallArn: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_vpc_endpoint_association#region AwsNetworkfirewallVpcEndpointAssociation#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_vpc_endpoint_association#tags AwsNetworkfirewallVpcEndpointAssociation#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_vpc_endpoint_association#vpc_id AwsNetworkfirewallVpcEndpointAssociation#vpc_id}
    */
    readonly vpcId: string;
    /**
    * subnet_mapping block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_vpc_endpoint_association#subnet_mapping AwsNetworkfirewallVpcEndpointAssociation#subnet_mapping}
    */
    readonly subnetMapping?: AwsNetworkfirewallVpcEndpointAssociation.SubnetMappingProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_vpc_endpoint_association#timeouts AwsNetworkfirewallVpcEndpointAssociation#timeouts}
    */
    readonly timeouts?: AwsNetworkfirewallVpcEndpointAssociation.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_vpc_endpoint_association aws_networkfirewall_vpc_endpoint_association}
*/
export declare class AwsNetworkfirewallVpcEndpointAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_networkfirewall_vpc_endpoint_association";
    /**
    * Generates CDKTN code for importing a AwsNetworkfirewallVpcEndpointAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsNetworkfirewallVpcEndpointAssociation to import
    * @param importFromId The id of the existing AwsNetworkfirewallVpcEndpointAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_vpc_endpoint_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsNetworkfirewallVpcEndpointAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_vpc_endpoint_association aws_networkfirewall_vpc_endpoint_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsNetworkfirewallVpcEndpointAssociationConfig
    */
    constructor(scope: Construct, id: string, config: AwsNetworkfirewallVpcEndpointAssociationConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _firewallArn?;
    get firewallArn(): string;
    set firewallArn(value: string);
    get firewallArnInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    get vpcEndpointAssociationArn(): string;
    get vpcEndpointAssociationId(): string;
    private _vpcEndpointAssociationStatus;
    get vpcEndpointAssociationStatus(): AwsNetworkfirewallVpcEndpointAssociation.VpcEndpointAssociationStatusPropertyList;
    private _vpcId?;
    get vpcId(): string;
    set vpcId(value: string);
    get vpcIdInput(): string | undefined;
    private _subnetMapping;
    get subnetMapping(): AwsNetworkfirewallVpcEndpointAssociation.SubnetMappingPropertyList;
    putSubnetMapping(value: AwsNetworkfirewallVpcEndpointAssociation.SubnetMappingProperty[] | cdktn.IResolvable): void;
    resetSubnetMapping(): void;
    get subnetMappingInput(): cdktn.IResolvable | AwsNetworkfirewallVpcEndpointAssociation.SubnetMappingProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsNetworkfirewallVpcEndpointAssociation.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsNetworkfirewallVpcEndpointAssociation.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsNetworkfirewallVpcEndpointAssociation.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsNetworkfirewallVpcEndpointAssociationAttachmentPropertyToTerraform(struct?: AwsNetworkfirewallVpcEndpointAssociation.AttachmentProperty): any;
export declare function awsNetworkfirewallVpcEndpointAssociationAttachmentPropertyToHclTerraform(struct?: AwsNetworkfirewallVpcEndpointAssociation.AttachmentProperty): any;
export declare function awsNetworkfirewallVpcEndpointAssociationAssociationSyncStatePropertyToTerraform(struct?: AwsNetworkfirewallVpcEndpointAssociation.AssociationSyncStateProperty): any;
export declare function awsNetworkfirewallVpcEndpointAssociationAssociationSyncStatePropertyToHclTerraform(struct?: AwsNetworkfirewallVpcEndpointAssociation.AssociationSyncStateProperty): any;
export declare function awsNetworkfirewallVpcEndpointAssociationVpcEndpointAssociationStatusPropertyToTerraform(struct?: AwsNetworkfirewallVpcEndpointAssociation.VpcEndpointAssociationStatusProperty): any;
export declare function awsNetworkfirewallVpcEndpointAssociationVpcEndpointAssociationStatusPropertyToHclTerraform(struct?: AwsNetworkfirewallVpcEndpointAssociation.VpcEndpointAssociationStatusProperty): any;
export declare function awsNetworkfirewallVpcEndpointAssociationSubnetMappingPropertyToTerraform(struct?: AwsNetworkfirewallVpcEndpointAssociation.SubnetMappingProperty | cdktn.IResolvable): any;
export declare function awsNetworkfirewallVpcEndpointAssociationSubnetMappingPropertyToHclTerraform(struct?: AwsNetworkfirewallVpcEndpointAssociation.SubnetMappingProperty | cdktn.IResolvable): any;
export declare function awsNetworkfirewallVpcEndpointAssociationTimeoutsPropertyToTerraform(struct?: AwsNetworkfirewallVpcEndpointAssociation.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsNetworkfirewallVpcEndpointAssociationTimeoutsPropertyToHclTerraform(struct?: AwsNetworkfirewallVpcEndpointAssociation.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsNetworkfirewallVpcEndpointAssociation {
    interface AttachmentProperty {
    }
    class AttachmentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AttachmentProperty | undefined;
        set internalValue(value: AttachmentProperty | undefined);
        get endpointId(): string;
        get status(): string;
        get statusMessage(): string;
        get subnetId(): string;
    }
    class AttachmentPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AttachmentPropertyOutputReference;
    }
    interface AssociationSyncStateProperty {
    }
    class AssociationSyncStatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AssociationSyncStateProperty | undefined;
        set internalValue(value: AssociationSyncStateProperty | undefined);
        private _attachment;
        get attachment(): AttachmentPropertyList;
        get availabilityZone(): string;
    }
    class AssociationSyncStatePropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AssociationSyncStatePropertyOutputReference;
    }
    interface VpcEndpointAssociationStatusProperty {
    }
    class VpcEndpointAssociationStatusPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): VpcEndpointAssociationStatusProperty | undefined;
        set internalValue(value: VpcEndpointAssociationStatusProperty | undefined);
        private _associationSyncState;
        get associationSyncState(): AssociationSyncStatePropertyList;
    }
    class VpcEndpointAssociationStatusPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): VpcEndpointAssociationStatusPropertyOutputReference;
    }
    interface SubnetMappingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_vpc_endpoint_association#ip_address_type AwsNetworkfirewallVpcEndpointAssociation#ip_address_type}
        */
        readonly ipAddressType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_vpc_endpoint_association#subnet_id AwsNetworkfirewallVpcEndpointAssociation#subnet_id}
        */
        readonly subnetId: string;
    }
    class SubnetMappingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SubnetMappingProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SubnetMappingProperty | cdktn.IResolvable | undefined);
        private _ipAddressType?;
        get ipAddressType(): string;
        set ipAddressType(value: string);
        resetIpAddressType(): void;
        get ipAddressTypeInput(): string | undefined;
        private _subnetId?;
        get subnetId(): string;
        set subnetId(value: string);
        get subnetIdInput(): string | undefined;
    }
    class SubnetMappingPropertyList extends cdktn.ComplexList {
        internalValue?: SubnetMappingProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SubnetMappingPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_vpc_endpoint_association#create AwsNetworkfirewallVpcEndpointAssociation#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/networkfirewall_vpc_endpoint_association#delete AwsNetworkfirewallVpcEndpointAssociation#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
