import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfFirewallConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkfirewall_firewall#arn DataTfFirewall#arn}
    */
    readonly arn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkfirewall_firewall#id DataTfFirewall#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkfirewall_firewall#name DataTfFirewall#name}
    */
    readonly name?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkfirewall_firewall#region DataTfFirewall#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkfirewall_firewall#tags DataTfFirewall#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkfirewall_firewall aws_networkfirewall_firewall}
*/
export declare class DataTfFirewall extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_networkfirewall_firewall";
    /**
    * Generates CDKTN code for importing a DataTfFirewall resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfFirewall to import
    * @param importFromId The id of the existing DataTfFirewall that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkfirewall_firewall#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfFirewall to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/networkfirewall_firewall aws_networkfirewall_firewall} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfFirewallConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataTfFirewallConfig);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    resetArn(): void;
    get arnInput(): string | undefined;
    get availabilityZoneChangeProtection(): cdktn.IResolvable;
    private _availabilityZoneMapping;
    get availabilityZoneMapping(): DataTfFirewall.AvailabilityZoneMappingPropertyList;
    get deleteProtection(): cdktn.IResolvable;
    get description(): string;
    get enabledAnalysisTypes(): string[];
    private _encryptionConfiguration;
    get encryptionConfiguration(): DataTfFirewall.EncryptionConfigurationPropertyList;
    get firewallPolicyArn(): string;
    get firewallPolicyChangeProtection(): cdktn.IResolvable;
    private _firewallStatus;
    get firewallStatus(): DataTfFirewall.FirewallStatusPropertyList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get subnetChangeProtection(): cdktn.IResolvable;
    private _subnetMapping;
    get subnetMapping(): DataTfFirewall.SubnetMappingPropertyList;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get transitGatewayId(): string;
    get transitGatewayOwnerAccountId(): string;
    get updateToken(): string;
    get vpcId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfFirewallAvailabilityZoneMappingPropertyToTerraform(struct?: DataTfFirewall.AvailabilityZoneMappingProperty): any;
export declare function dataTfFirewallAvailabilityZoneMappingPropertyToHclTerraform(struct?: DataTfFirewall.AvailabilityZoneMappingProperty): any;
export declare function dataTfFirewallEncryptionConfigurationPropertyToTerraform(struct?: DataTfFirewall.EncryptionConfigurationProperty): any;
export declare function dataTfFirewallEncryptionConfigurationPropertyToHclTerraform(struct?: DataTfFirewall.EncryptionConfigurationProperty): any;
export declare function dataTfFirewallIpSetReferencesPropertyToTerraform(struct?: DataTfFirewall.IpSetReferencesProperty): any;
export declare function dataTfFirewallIpSetReferencesPropertyToHclTerraform(struct?: DataTfFirewall.IpSetReferencesProperty): any;
export declare function dataTfFirewallCidrsPropertyToTerraform(struct?: DataTfFirewall.CidrsProperty): any;
export declare function dataTfFirewallCidrsPropertyToHclTerraform(struct?: DataTfFirewall.CidrsProperty): any;
export declare function dataTfFirewallCapacityUsageSummaryPropertyToTerraform(struct?: DataTfFirewall.CapacityUsageSummaryProperty): any;
export declare function dataTfFirewallCapacityUsageSummaryPropertyToHclTerraform(struct?: DataTfFirewall.CapacityUsageSummaryProperty): any;
export declare function dataTfFirewallAttachmentPropertyToTerraform(struct?: DataTfFirewall.AttachmentProperty): any;
export declare function dataTfFirewallAttachmentPropertyToHclTerraform(struct?: DataTfFirewall.AttachmentProperty): any;
export declare function dataTfFirewallSyncStatesPropertyToTerraform(struct?: DataTfFirewall.SyncStatesProperty): any;
export declare function dataTfFirewallSyncStatesPropertyToHclTerraform(struct?: DataTfFirewall.SyncStatesProperty): any;
export declare function dataTfFirewallTransitGatewayAttachmentSyncStatesPropertyToTerraform(struct?: DataTfFirewall.TransitGatewayAttachmentSyncStatesProperty): any;
export declare function dataTfFirewallTransitGatewayAttachmentSyncStatesPropertyToHclTerraform(struct?: DataTfFirewall.TransitGatewayAttachmentSyncStatesProperty): any;
export declare function dataTfFirewallFirewallStatusPropertyToTerraform(struct?: DataTfFirewall.FirewallStatusProperty): any;
export declare function dataTfFirewallFirewallStatusPropertyToHclTerraform(struct?: DataTfFirewall.FirewallStatusProperty): any;
export declare function dataTfFirewallSubnetMappingPropertyToTerraform(struct?: DataTfFirewall.SubnetMappingProperty): any;
export declare function dataTfFirewallSubnetMappingPropertyToHclTerraform(struct?: DataTfFirewall.SubnetMappingProperty): any;
export declare namespace DataTfFirewall {
    interface AvailabilityZoneMappingProperty {
    }
    class AvailabilityZoneMappingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AvailabilityZoneMappingProperty | undefined;
        set internalValue(value: AvailabilityZoneMappingProperty | undefined);
        get availabilityZoneId(): string;
    }
    class AvailabilityZoneMappingPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AvailabilityZoneMappingPropertyOutputReference;
    }
    interface EncryptionConfigurationProperty {
    }
    class EncryptionConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EncryptionConfigurationProperty | undefined;
        set internalValue(value: EncryptionConfigurationProperty | undefined);
        get keyId(): string;
        get type(): string;
    }
    class EncryptionConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EncryptionConfigurationPropertyOutputReference;
    }
    interface IpSetReferencesProperty {
    }
    class IpSetReferencesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IpSetReferencesProperty | undefined;
        set internalValue(value: IpSetReferencesProperty | undefined);
        get resolvedCidrCount(): number;
    }
    class IpSetReferencesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IpSetReferencesPropertyOutputReference;
    }
    interface CidrsProperty {
    }
    class CidrsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CidrsProperty | undefined;
        set internalValue(value: CidrsProperty | undefined);
        get availableCidrCount(): number;
        private _ipSetReferences;
        get ipSetReferences(): IpSetReferencesPropertyList;
        get utilizedCidrCount(): number;
    }
    class CidrsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CidrsPropertyOutputReference;
    }
    interface CapacityUsageSummaryProperty {
    }
    class CapacityUsageSummaryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CapacityUsageSummaryProperty | undefined;
        set internalValue(value: CapacityUsageSummaryProperty | undefined);
        private _cidrs;
        get cidrs(): CidrsPropertyList;
    }
    class CapacityUsageSummaryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CapacityUsageSummaryPropertyOutputReference;
    }
    interface AttachmentProperty {
    }
    class AttachmentPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AttachmentProperty | undefined;
        set internalValue(value: AttachmentProperty | undefined);
        get endpointId(): string;
        get status(): string;
        get statusMessage(): string;
        get subnetId(): string;
    }
    class AttachmentPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AttachmentPropertyOutputReference;
    }
    interface SyncStatesProperty {
    }
    class SyncStatesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SyncStatesProperty | undefined;
        set internalValue(value: SyncStatesProperty | undefined);
        private _attachment;
        get attachment(): AttachmentPropertyList;
        get availabilityZone(): string;
    }
    class SyncStatesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SyncStatesPropertyOutputReference;
    }
    interface TransitGatewayAttachmentSyncStatesProperty {
    }
    class TransitGatewayAttachmentSyncStatesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TransitGatewayAttachmentSyncStatesProperty | undefined;
        set internalValue(value: TransitGatewayAttachmentSyncStatesProperty | undefined);
        get attachmentId(): string;
        get statusMessage(): string;
        get transitGatewayAttachmentStatus(): string;
    }
    class TransitGatewayAttachmentSyncStatesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TransitGatewayAttachmentSyncStatesPropertyOutputReference;
    }
    interface FirewallStatusProperty {
    }
    class FirewallStatusPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FirewallStatusProperty | undefined;
        set internalValue(value: FirewallStatusProperty | undefined);
        private _capacityUsageSummary;
        get capacityUsageSummary(): CapacityUsageSummaryPropertyList;
        get configurationSyncStateSummary(): string;
        get status(): string;
        private _syncStates;
        get syncStates(): SyncStatesPropertyList;
        private _transitGatewayAttachmentSyncStates;
        get transitGatewayAttachmentSyncStates(): TransitGatewayAttachmentSyncStatesPropertyList;
    }
    class FirewallStatusPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FirewallStatusPropertyOutputReference;
    }
    interface SubnetMappingProperty {
    }
    class SubnetMappingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SubnetMappingProperty | undefined;
        set internalValue(value: SubnetMappingProperty | undefined);
        get subnetId(): string;
    }
    class SubnetMappingPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SubnetMappingPropertyOutputReference;
    }
}
