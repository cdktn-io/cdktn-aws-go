import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsMskconnectConnectorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#connector_configuration AwsMskconnectConnector#connector_configuration}
    */
    readonly connectorConfiguration: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#description AwsMskconnectConnector#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#id AwsMskconnectConnector#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#kafkaconnect_version AwsMskconnectConnector#kafkaconnect_version}
    */
    readonly kafkaconnectVersion: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#name AwsMskconnectConnector#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#region AwsMskconnectConnector#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#service_execution_role_arn AwsMskconnectConnector#service_execution_role_arn}
    */
    readonly serviceExecutionRoleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#tags AwsMskconnectConnector#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#tags_all AwsMskconnectConnector#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * capacity block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#capacity AwsMskconnectConnector#capacity}
    */
    readonly capacity: AwsMskconnectConnector.CapacityProperty;
    /**
    * kafka_cluster block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#kafka_cluster AwsMskconnectConnector#kafka_cluster}
    */
    readonly kafkaCluster: AwsMskconnectConnector.KafkaClusterProperty;
    /**
    * kafka_cluster_client_authentication block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#kafka_cluster_client_authentication AwsMskconnectConnector#kafka_cluster_client_authentication}
    */
    readonly kafkaClusterClientAuthentication: AwsMskconnectConnector.KafkaClusterClientAuthenticationProperty;
    /**
    * kafka_cluster_encryption_in_transit block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#kafka_cluster_encryption_in_transit AwsMskconnectConnector#kafka_cluster_encryption_in_transit}
    */
    readonly kafkaClusterEncryptionInTransit: AwsMskconnectConnector.KafkaClusterEncryptionInTransitProperty;
    /**
    * log_delivery block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#log_delivery AwsMskconnectConnector#log_delivery}
    */
    readonly logDelivery?: AwsMskconnectConnector.LogDeliveryProperty;
    /**
    * plugin block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#plugin AwsMskconnectConnector#plugin}
    */
    readonly plugin: AwsMskconnectConnector.PluginProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#timeouts AwsMskconnectConnector#timeouts}
    */
    readonly timeouts?: AwsMskconnectConnector.TimeoutsProperty;
    /**
    * worker_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#worker_configuration AwsMskconnectConnector#worker_configuration}
    */
    readonly workerConfiguration?: AwsMskconnectConnector.WorkerConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector aws_mskconnect_connector}
*/
export declare class AwsMskconnectConnector extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_mskconnect_connector";
    /**
    * Generates CDKTN code for importing a AwsMskconnectConnector resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsMskconnectConnector to import
    * @param importFromId The id of the existing AwsMskconnectConnector that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsMskconnectConnector to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector aws_mskconnect_connector} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsMskconnectConnectorConfig
    */
    constructor(scope: Construct, id: string, config: AwsMskconnectConnectorConfig);
    get arn(): string;
    private _connectorConfiguration?;
    get connectorConfiguration(): {
        [key: string]: string;
    };
    set connectorConfiguration(value: {
        [key: string]: string;
    });
    get connectorConfigurationInput(): {
        [key: string]: string;
    } | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _kafkaconnectVersion?;
    get kafkaconnectVersion(): string;
    set kafkaconnectVersion(value: string);
    get kafkaconnectVersionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _serviceExecutionRoleArn?;
    get serviceExecutionRoleArn(): string;
    set serviceExecutionRoleArn(value: string);
    get serviceExecutionRoleArnInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    get version(): string;
    private _capacity;
    get capacity(): AwsMskconnectConnector.CapacityPropertyOutputReference;
    putCapacity(value: AwsMskconnectConnector.CapacityProperty): void;
    get capacityInput(): AwsMskconnectConnector.CapacityProperty | undefined;
    private _kafkaCluster;
    get kafkaCluster(): AwsMskconnectConnector.KafkaClusterPropertyOutputReference;
    putKafkaCluster(value: AwsMskconnectConnector.KafkaClusterProperty): void;
    get kafkaClusterInput(): AwsMskconnectConnector.KafkaClusterProperty | undefined;
    private _kafkaClusterClientAuthentication;
    get kafkaClusterClientAuthentication(): AwsMskconnectConnector.KafkaClusterClientAuthenticationPropertyOutputReference;
    putKafkaClusterClientAuthentication(value: AwsMskconnectConnector.KafkaClusterClientAuthenticationProperty): void;
    get kafkaClusterClientAuthenticationInput(): AwsMskconnectConnector.KafkaClusterClientAuthenticationProperty | undefined;
    private _kafkaClusterEncryptionInTransit;
    get kafkaClusterEncryptionInTransit(): AwsMskconnectConnector.KafkaClusterEncryptionInTransitPropertyOutputReference;
    putKafkaClusterEncryptionInTransit(value: AwsMskconnectConnector.KafkaClusterEncryptionInTransitProperty): void;
    get kafkaClusterEncryptionInTransitInput(): AwsMskconnectConnector.KafkaClusterEncryptionInTransitProperty | undefined;
    private _logDelivery;
    get logDelivery(): AwsMskconnectConnector.LogDeliveryPropertyOutputReference;
    putLogDelivery(value: AwsMskconnectConnector.LogDeliveryProperty): void;
    resetLogDelivery(): void;
    get logDeliveryInput(): AwsMskconnectConnector.LogDeliveryProperty | undefined;
    private _plugin;
    get plugin(): AwsMskconnectConnector.PluginPropertyList;
    putPlugin(value: AwsMskconnectConnector.PluginProperty[] | cdktn.IResolvable): void;
    get pluginInput(): cdktn.IResolvable | AwsMskconnectConnector.PluginProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsMskconnectConnector.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsMskconnectConnector.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsMskconnectConnector.TimeoutsProperty | undefined;
    private _workerConfiguration;
    get workerConfiguration(): AwsMskconnectConnector.WorkerConfigurationPropertyOutputReference;
    putWorkerConfiguration(value: AwsMskconnectConnector.WorkerConfigurationProperty): void;
    resetWorkerConfiguration(): void;
    get workerConfigurationInput(): AwsMskconnectConnector.WorkerConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsMskconnectConnectorScaleInPolicyPropertyToTerraform(struct?: AwsMskconnectConnector.ScaleInPolicyPropertyOutputReference | AwsMskconnectConnector.ScaleInPolicyProperty): any;
export declare function awsMskconnectConnectorScaleInPolicyPropertyToHclTerraform(struct?: AwsMskconnectConnector.ScaleInPolicyPropertyOutputReference | AwsMskconnectConnector.ScaleInPolicyProperty): any;
export declare function awsMskconnectConnectorScaleOutPolicyPropertyToTerraform(struct?: AwsMskconnectConnector.ScaleOutPolicyPropertyOutputReference | AwsMskconnectConnector.ScaleOutPolicyProperty): any;
export declare function awsMskconnectConnectorScaleOutPolicyPropertyToHclTerraform(struct?: AwsMskconnectConnector.ScaleOutPolicyPropertyOutputReference | AwsMskconnectConnector.ScaleOutPolicyProperty): any;
export declare function awsMskconnectConnectorAutoscalingPropertyToTerraform(struct?: AwsMskconnectConnector.AutoscalingPropertyOutputReference | AwsMskconnectConnector.AutoscalingProperty): any;
export declare function awsMskconnectConnectorAutoscalingPropertyToHclTerraform(struct?: AwsMskconnectConnector.AutoscalingPropertyOutputReference | AwsMskconnectConnector.AutoscalingProperty): any;
export declare function awsMskconnectConnectorProvisionedCapacityPropertyToTerraform(struct?: AwsMskconnectConnector.ProvisionedCapacityPropertyOutputReference | AwsMskconnectConnector.ProvisionedCapacityProperty): any;
export declare function awsMskconnectConnectorProvisionedCapacityPropertyToHclTerraform(struct?: AwsMskconnectConnector.ProvisionedCapacityPropertyOutputReference | AwsMskconnectConnector.ProvisionedCapacityProperty): any;
export declare function awsMskconnectConnectorCapacityPropertyToTerraform(struct?: AwsMskconnectConnector.CapacityPropertyOutputReference | AwsMskconnectConnector.CapacityProperty): any;
export declare function awsMskconnectConnectorCapacityPropertyToHclTerraform(struct?: AwsMskconnectConnector.CapacityPropertyOutputReference | AwsMskconnectConnector.CapacityProperty): any;
export declare function awsMskconnectConnectorVpcPropertyToTerraform(struct?: AwsMskconnectConnector.VpcPropertyOutputReference | AwsMskconnectConnector.VpcProperty): any;
export declare function awsMskconnectConnectorVpcPropertyToHclTerraform(struct?: AwsMskconnectConnector.VpcPropertyOutputReference | AwsMskconnectConnector.VpcProperty): any;
export declare function awsMskconnectConnectorApacheKafkaClusterPropertyToTerraform(struct?: AwsMskconnectConnector.ApacheKafkaClusterPropertyOutputReference | AwsMskconnectConnector.ApacheKafkaClusterProperty): any;
export declare function awsMskconnectConnectorApacheKafkaClusterPropertyToHclTerraform(struct?: AwsMskconnectConnector.ApacheKafkaClusterPropertyOutputReference | AwsMskconnectConnector.ApacheKafkaClusterProperty): any;
export declare function awsMskconnectConnectorKafkaClusterPropertyToTerraform(struct?: AwsMskconnectConnector.KafkaClusterPropertyOutputReference | AwsMskconnectConnector.KafkaClusterProperty): any;
export declare function awsMskconnectConnectorKafkaClusterPropertyToHclTerraform(struct?: AwsMskconnectConnector.KafkaClusterPropertyOutputReference | AwsMskconnectConnector.KafkaClusterProperty): any;
export declare function awsMskconnectConnectorKafkaClusterClientAuthenticationPropertyToTerraform(struct?: AwsMskconnectConnector.KafkaClusterClientAuthenticationPropertyOutputReference | AwsMskconnectConnector.KafkaClusterClientAuthenticationProperty): any;
export declare function awsMskconnectConnectorKafkaClusterClientAuthenticationPropertyToHclTerraform(struct?: AwsMskconnectConnector.KafkaClusterClientAuthenticationPropertyOutputReference | AwsMskconnectConnector.KafkaClusterClientAuthenticationProperty): any;
export declare function awsMskconnectConnectorKafkaClusterEncryptionInTransitPropertyToTerraform(struct?: AwsMskconnectConnector.KafkaClusterEncryptionInTransitPropertyOutputReference | AwsMskconnectConnector.KafkaClusterEncryptionInTransitProperty): any;
export declare function awsMskconnectConnectorKafkaClusterEncryptionInTransitPropertyToHclTerraform(struct?: AwsMskconnectConnector.KafkaClusterEncryptionInTransitPropertyOutputReference | AwsMskconnectConnector.KafkaClusterEncryptionInTransitProperty): any;
export declare function awsMskconnectConnectorCloudwatchLogsPropertyToTerraform(struct?: AwsMskconnectConnector.CloudwatchLogsPropertyOutputReference | AwsMskconnectConnector.CloudwatchLogsProperty): any;
export declare function awsMskconnectConnectorCloudwatchLogsPropertyToHclTerraform(struct?: AwsMskconnectConnector.CloudwatchLogsPropertyOutputReference | AwsMskconnectConnector.CloudwatchLogsProperty): any;
export declare function awsMskconnectConnectorFirehosePropertyToTerraform(struct?: AwsMskconnectConnector.FirehosePropertyOutputReference | AwsMskconnectConnector.FirehoseProperty): any;
export declare function awsMskconnectConnectorFirehosePropertyToHclTerraform(struct?: AwsMskconnectConnector.FirehosePropertyOutputReference | AwsMskconnectConnector.FirehoseProperty): any;
export declare function awsMskconnectConnectorS3PropertyToTerraform(struct?: AwsMskconnectConnector.S3PropertyOutputReference | AwsMskconnectConnector.S3Property): any;
export declare function awsMskconnectConnectorS3PropertyToHclTerraform(struct?: AwsMskconnectConnector.S3PropertyOutputReference | AwsMskconnectConnector.S3Property): any;
export declare function awsMskconnectConnectorWorkerLogDeliveryPropertyToTerraform(struct?: AwsMskconnectConnector.WorkerLogDeliveryPropertyOutputReference | AwsMskconnectConnector.WorkerLogDeliveryProperty): any;
export declare function awsMskconnectConnectorWorkerLogDeliveryPropertyToHclTerraform(struct?: AwsMskconnectConnector.WorkerLogDeliveryPropertyOutputReference | AwsMskconnectConnector.WorkerLogDeliveryProperty): any;
export declare function awsMskconnectConnectorLogDeliveryPropertyToTerraform(struct?: AwsMskconnectConnector.LogDeliveryPropertyOutputReference | AwsMskconnectConnector.LogDeliveryProperty): any;
export declare function awsMskconnectConnectorLogDeliveryPropertyToHclTerraform(struct?: AwsMskconnectConnector.LogDeliveryPropertyOutputReference | AwsMskconnectConnector.LogDeliveryProperty): any;
export declare function awsMskconnectConnectorCustomPluginPropertyToTerraform(struct?: AwsMskconnectConnector.CustomPluginPropertyOutputReference | AwsMskconnectConnector.CustomPluginProperty): any;
export declare function awsMskconnectConnectorCustomPluginPropertyToHclTerraform(struct?: AwsMskconnectConnector.CustomPluginPropertyOutputReference | AwsMskconnectConnector.CustomPluginProperty): any;
export declare function awsMskconnectConnectorPluginPropertyToTerraform(struct?: AwsMskconnectConnector.PluginProperty | cdktn.IResolvable): any;
export declare function awsMskconnectConnectorPluginPropertyToHclTerraform(struct?: AwsMskconnectConnector.PluginProperty | cdktn.IResolvable): any;
export declare function awsMskconnectConnectorTimeoutsPropertyToTerraform(struct?: AwsMskconnectConnector.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsMskconnectConnectorTimeoutsPropertyToHclTerraform(struct?: AwsMskconnectConnector.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsMskconnectConnectorWorkerConfigurationPropertyToTerraform(struct?: AwsMskconnectConnector.WorkerConfigurationPropertyOutputReference | AwsMskconnectConnector.WorkerConfigurationProperty): any;
export declare function awsMskconnectConnectorWorkerConfigurationPropertyToHclTerraform(struct?: AwsMskconnectConnector.WorkerConfigurationPropertyOutputReference | AwsMskconnectConnector.WorkerConfigurationProperty): any;
export declare namespace AwsMskconnectConnector {
    interface ScaleInPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#cpu_utilization_percentage AwsMskconnectConnector#cpu_utilization_percentage}
        */
        readonly cpuUtilizationPercentage?: number;
    }
    class ScaleInPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ScaleInPolicyProperty | undefined;
        set internalValue(value: ScaleInPolicyProperty | undefined);
        private _cpuUtilizationPercentage?;
        get cpuUtilizationPercentage(): number;
        set cpuUtilizationPercentage(value: number);
        resetCpuUtilizationPercentage(): void;
        get cpuUtilizationPercentageInput(): number | undefined;
    }
    interface ScaleOutPolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#cpu_utilization_percentage AwsMskconnectConnector#cpu_utilization_percentage}
        */
        readonly cpuUtilizationPercentage?: number;
    }
    class ScaleOutPolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ScaleOutPolicyProperty | undefined;
        set internalValue(value: ScaleOutPolicyProperty | undefined);
        private _cpuUtilizationPercentage?;
        get cpuUtilizationPercentage(): number;
        set cpuUtilizationPercentage(value: number);
        resetCpuUtilizationPercentage(): void;
        get cpuUtilizationPercentageInput(): number | undefined;
    }
    interface AutoscalingProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#max_worker_count AwsMskconnectConnector#max_worker_count}
        */
        readonly maxWorkerCount: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#mcu_count AwsMskconnectConnector#mcu_count}
        */
        readonly mcuCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#min_worker_count AwsMskconnectConnector#min_worker_count}
        */
        readonly minWorkerCount: number;
        /**
        * scale_in_policy block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#scale_in_policy AwsMskconnectConnector#scale_in_policy}
        */
        readonly scaleInPolicy?: ScaleInPolicyProperty;
        /**
        * scale_out_policy block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#scale_out_policy AwsMskconnectConnector#scale_out_policy}
        */
        readonly scaleOutPolicy?: ScaleOutPolicyProperty;
    }
    class AutoscalingPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AutoscalingProperty | undefined;
        set internalValue(value: AutoscalingProperty | undefined);
        private _maxWorkerCount?;
        get maxWorkerCount(): number;
        set maxWorkerCount(value: number);
        get maxWorkerCountInput(): number | undefined;
        private _mcuCount?;
        get mcuCount(): number;
        set mcuCount(value: number);
        resetMcuCount(): void;
        get mcuCountInput(): number | undefined;
        private _minWorkerCount?;
        get minWorkerCount(): number;
        set minWorkerCount(value: number);
        get minWorkerCountInput(): number | undefined;
        private _scaleInPolicy;
        get scaleInPolicy(): ScaleInPolicyPropertyOutputReference;
        putScaleInPolicy(value: ScaleInPolicyProperty): void;
        resetScaleInPolicy(): void;
        get scaleInPolicyInput(): ScaleInPolicyProperty | undefined;
        private _scaleOutPolicy;
        get scaleOutPolicy(): ScaleOutPolicyPropertyOutputReference;
        putScaleOutPolicy(value: ScaleOutPolicyProperty): void;
        resetScaleOutPolicy(): void;
        get scaleOutPolicyInput(): ScaleOutPolicyProperty | undefined;
    }
    interface ProvisionedCapacityProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#mcu_count AwsMskconnectConnector#mcu_count}
        */
        readonly mcuCount?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#worker_count AwsMskconnectConnector#worker_count}
        */
        readonly workerCount: number;
    }
    class ProvisionedCapacityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ProvisionedCapacityProperty | undefined;
        set internalValue(value: ProvisionedCapacityProperty | undefined);
        private _mcuCount?;
        get mcuCount(): number;
        set mcuCount(value: number);
        resetMcuCount(): void;
        get mcuCountInput(): number | undefined;
        private _workerCount?;
        get workerCount(): number;
        set workerCount(value: number);
        get workerCountInput(): number | undefined;
    }
    interface CapacityProperty {
        /**
        * autoscaling block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#autoscaling AwsMskconnectConnector#autoscaling}
        */
        readonly autoscaling?: AutoscalingProperty;
        /**
        * provisioned_capacity block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#provisioned_capacity AwsMskconnectConnector#provisioned_capacity}
        */
        readonly provisionedCapacity?: ProvisionedCapacityProperty;
    }
    class CapacityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CapacityProperty | undefined;
        set internalValue(value: CapacityProperty | undefined);
        private _autoscaling;
        get autoscaling(): AutoscalingPropertyOutputReference;
        putAutoscaling(value: AutoscalingProperty): void;
        resetAutoscaling(): void;
        get autoscalingInput(): AutoscalingProperty | undefined;
        private _provisionedCapacity;
        get provisionedCapacity(): ProvisionedCapacityPropertyOutputReference;
        putProvisionedCapacity(value: ProvisionedCapacityProperty): void;
        resetProvisionedCapacity(): void;
        get provisionedCapacityInput(): ProvisionedCapacityProperty | undefined;
    }
    interface VpcProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#security_groups AwsMskconnectConnector#security_groups}
        */
        readonly securityGroups: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#subnets AwsMskconnectConnector#subnets}
        */
        readonly subnets: string[];
    }
    class VpcPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcProperty | undefined;
        set internalValue(value: VpcProperty | undefined);
        private _securityGroups?;
        get securityGroups(): string[];
        set securityGroups(value: string[]);
        get securityGroupsInput(): string[] | undefined;
        private _subnets?;
        get subnets(): string[];
        set subnets(value: string[]);
        get subnetsInput(): string[] | undefined;
    }
    interface ApacheKafkaClusterProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#bootstrap_servers AwsMskconnectConnector#bootstrap_servers}
        */
        readonly bootstrapServers: string;
        /**
        * vpc block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#vpc AwsMskconnectConnector#vpc}
        */
        readonly vpc: VpcProperty;
    }
    class ApacheKafkaClusterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ApacheKafkaClusterProperty | undefined;
        set internalValue(value: ApacheKafkaClusterProperty | undefined);
        private _bootstrapServers?;
        get bootstrapServers(): string;
        set bootstrapServers(value: string);
        get bootstrapServersInput(): string | undefined;
        private _vpc;
        get vpc(): VpcPropertyOutputReference;
        putVpc(value: VpcProperty): void;
        get vpcInput(): VpcProperty | undefined;
    }
    interface KafkaClusterProperty {
        /**
        * apache_kafka_cluster block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#apache_kafka_cluster AwsMskconnectConnector#apache_kafka_cluster}
        */
        readonly apacheKafkaCluster: ApacheKafkaClusterProperty;
    }
    class KafkaClusterPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KafkaClusterProperty | undefined;
        set internalValue(value: KafkaClusterProperty | undefined);
        private _apacheKafkaCluster;
        get apacheKafkaCluster(): ApacheKafkaClusterPropertyOutputReference;
        putApacheKafkaCluster(value: ApacheKafkaClusterProperty): void;
        get apacheKafkaClusterInput(): ApacheKafkaClusterProperty | undefined;
    }
    interface KafkaClusterClientAuthenticationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#authentication_type AwsMskconnectConnector#authentication_type}
        */
        readonly authenticationType?: string;
    }
    class KafkaClusterClientAuthenticationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KafkaClusterClientAuthenticationProperty | undefined;
        set internalValue(value: KafkaClusterClientAuthenticationProperty | undefined);
        private _authenticationType?;
        get authenticationType(): string;
        set authenticationType(value: string);
        resetAuthenticationType(): void;
        get authenticationTypeInput(): string | undefined;
    }
    interface KafkaClusterEncryptionInTransitProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#encryption_type AwsMskconnectConnector#encryption_type}
        */
        readonly encryptionType?: string;
    }
    class KafkaClusterEncryptionInTransitPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KafkaClusterEncryptionInTransitProperty | undefined;
        set internalValue(value: KafkaClusterEncryptionInTransitProperty | undefined);
        private _encryptionType?;
        get encryptionType(): string;
        set encryptionType(value: string);
        resetEncryptionType(): void;
        get encryptionTypeInput(): string | undefined;
    }
    interface CloudwatchLogsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#enabled AwsMskconnectConnector#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#log_group AwsMskconnectConnector#log_group}
        */
        readonly logGroup?: string;
    }
    class CloudwatchLogsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CloudwatchLogsProperty | undefined;
        set internalValue(value: CloudwatchLogsProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _logGroup?;
        get logGroup(): string;
        set logGroup(value: string);
        resetLogGroup(): void;
        get logGroupInput(): string | undefined;
    }
    interface FirehoseProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#delivery_stream AwsMskconnectConnector#delivery_stream}
        */
        readonly deliveryStream?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#enabled AwsMskconnectConnector#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
    }
    class FirehosePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FirehoseProperty | undefined;
        set internalValue(value: FirehoseProperty | undefined);
        private _deliveryStream?;
        get deliveryStream(): string;
        set deliveryStream(value: string);
        resetDeliveryStream(): void;
        get deliveryStreamInput(): string | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface S3Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#bucket AwsMskconnectConnector#bucket}
        */
        readonly bucket?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#enabled AwsMskconnectConnector#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#prefix AwsMskconnectConnector#prefix}
        */
        readonly prefix?: string;
    }
    class S3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3Property | undefined;
        set internalValue(value: S3Property | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        resetBucket(): void;
        get bucketInput(): string | undefined;
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _prefix?;
        get prefix(): string;
        set prefix(value: string);
        resetPrefix(): void;
        get prefixInput(): string | undefined;
    }
    interface WorkerLogDeliveryProperty {
        /**
        * cloudwatch_logs block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#cloudwatch_logs AwsMskconnectConnector#cloudwatch_logs}
        */
        readonly cloudwatchLogs?: CloudwatchLogsProperty;
        /**
        * firehose block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#firehose AwsMskconnectConnector#firehose}
        */
        readonly firehose?: FirehoseProperty;
        /**
        * s3 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#s3 AwsMskconnectConnector#s3}
        */
        readonly s3?: S3Property;
    }
    class WorkerLogDeliveryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): WorkerLogDeliveryProperty | undefined;
        set internalValue(value: WorkerLogDeliveryProperty | undefined);
        private _cloudwatchLogs;
        get cloudwatchLogs(): CloudwatchLogsPropertyOutputReference;
        putCloudwatchLogs(value: CloudwatchLogsProperty): void;
        resetCloudwatchLogs(): void;
        get cloudwatchLogsInput(): CloudwatchLogsProperty | undefined;
        private _firehose;
        get firehose(): FirehosePropertyOutputReference;
        putFirehose(value: FirehoseProperty): void;
        resetFirehose(): void;
        get firehoseInput(): FirehoseProperty | undefined;
        private _s3;
        get s3(): S3PropertyOutputReference;
        putS3(value: S3Property): void;
        resetS3(): void;
        get s3Input(): S3Property | undefined;
    }
    interface LogDeliveryProperty {
        /**
        * worker_log_delivery block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#worker_log_delivery AwsMskconnectConnector#worker_log_delivery}
        */
        readonly workerLogDelivery: WorkerLogDeliveryProperty;
    }
    class LogDeliveryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LogDeliveryProperty | undefined;
        set internalValue(value: LogDeliveryProperty | undefined);
        private _workerLogDelivery;
        get workerLogDelivery(): WorkerLogDeliveryPropertyOutputReference;
        putWorkerLogDelivery(value: WorkerLogDeliveryProperty): void;
        get workerLogDeliveryInput(): WorkerLogDeliveryProperty | undefined;
    }
    interface CustomPluginProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#arn AwsMskconnectConnector#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#revision AwsMskconnectConnector#revision}
        */
        readonly revision: number;
    }
    class CustomPluginPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CustomPluginProperty | undefined;
        set internalValue(value: CustomPluginProperty | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _revision?;
        get revision(): number;
        set revision(value: number);
        get revisionInput(): number | undefined;
    }
    interface PluginProperty {
        /**
        * custom_plugin block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#custom_plugin AwsMskconnectConnector#custom_plugin}
        */
        readonly customPlugin: CustomPluginProperty;
    }
    class PluginPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PluginProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PluginProperty | cdktn.IResolvable | undefined);
        private _customPlugin;
        get customPlugin(): CustomPluginPropertyOutputReference;
        putCustomPlugin(value: CustomPluginProperty): void;
        get customPluginInput(): CustomPluginProperty | undefined;
    }
    class PluginPropertyList extends cdktn.ComplexList {
        internalValue?: PluginProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PluginPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#create AwsMskconnectConnector#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#delete AwsMskconnectConnector#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#update AwsMskconnectConnector#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
    interface WorkerConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#arn AwsMskconnectConnector#arn}
        */
        readonly arn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/mskconnect_connector#revision AwsMskconnectConnector#revision}
        */
        readonly revision: number;
    }
    class WorkerConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): WorkerConfigurationProperty | undefined;
        set internalValue(value: WorkerConfigurationProperty | undefined);
        private _arn?;
        get arn(): string;
        set arn(value: string);
        get arnInput(): string | undefined;
        private _revision?;
        get revision(): number;
        set revision(value: number);
        get revisionInput(): number | undefined;
    }
}
