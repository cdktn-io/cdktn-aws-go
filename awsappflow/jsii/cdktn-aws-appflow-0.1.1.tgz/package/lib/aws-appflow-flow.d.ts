import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAppflowFlowConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#description AwsAppflowFlow#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#id AwsAppflowFlow#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#kms_arn AwsAppflowFlow#kms_arn}
    */
    readonly kmsArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#name AwsAppflowFlow#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#region AwsAppflowFlow#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#tags AwsAppflowFlow#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#tags_all AwsAppflowFlow#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * destination_flow_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#destination_flow_config AwsAppflowFlow#destination_flow_config}
    */
    readonly destinationFlowConfig: AwsAppflowFlow.DestinationFlowConfigProperty[] | cdktn.IResolvable;
    /**
    * metadata_catalog_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#metadata_catalog_config AwsAppflowFlow#metadata_catalog_config}
    */
    readonly metadataCatalogConfig?: AwsAppflowFlow.MetadataCatalogConfigProperty;
    /**
    * source_flow_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#source_flow_config AwsAppflowFlow#source_flow_config}
    */
    readonly sourceFlowConfig: AwsAppflowFlow.SourceFlowConfigProperty;
    /**
    * task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#task AwsAppflowFlow#task}
    */
    readonly task: AwsAppflowFlow.TaskProperty[] | cdktn.IResolvable;
    /**
    * trigger_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#trigger_config AwsAppflowFlow#trigger_config}
    */
    readonly triggerConfig: AwsAppflowFlow.TriggerConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow aws_appflow_flow}
*/
export declare class AwsAppflowFlow extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_appflow_flow";
    /**
    * Generates CDKTN code for importing a AwsAppflowFlow resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAppflowFlow to import
    * @param importFromId The id of the existing AwsAppflowFlow that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAppflowFlow to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow aws_appflow_flow} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAppflowFlowConfig
    */
    constructor(scope: Construct, id: string, config: AwsAppflowFlowConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get flowStatus(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _kmsArn?;
    get kmsArn(): string;
    set kmsArn(value: string);
    resetKmsArn(): void;
    get kmsArnInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _destinationFlowConfig;
    get destinationFlowConfig(): AwsAppflowFlow.DestinationFlowConfigPropertyList;
    putDestinationFlowConfig(value: AwsAppflowFlow.DestinationFlowConfigProperty[] | cdktn.IResolvable): void;
    get destinationFlowConfigInput(): cdktn.IResolvable | AwsAppflowFlow.DestinationFlowConfigProperty[] | undefined;
    private _metadataCatalogConfig;
    get metadataCatalogConfig(): AwsAppflowFlow.MetadataCatalogConfigPropertyOutputReference;
    putMetadataCatalogConfig(value: AwsAppflowFlow.MetadataCatalogConfigProperty): void;
    resetMetadataCatalogConfig(): void;
    get metadataCatalogConfigInput(): AwsAppflowFlow.MetadataCatalogConfigProperty | undefined;
    private _sourceFlowConfig;
    get sourceFlowConfig(): AwsAppflowFlow.SourceFlowConfigPropertyOutputReference;
    putSourceFlowConfig(value: AwsAppflowFlow.SourceFlowConfigProperty): void;
    get sourceFlowConfigInput(): AwsAppflowFlow.SourceFlowConfigProperty | undefined;
    private _task;
    get task(): AwsAppflowFlow.TaskPropertyList;
    putTask(value: AwsAppflowFlow.TaskProperty[] | cdktn.IResolvable): void;
    get taskInput(): cdktn.IResolvable | AwsAppflowFlow.TaskProperty[] | undefined;
    private _triggerConfig;
    get triggerConfig(): AwsAppflowFlow.TriggerConfigPropertyOutputReference;
    putTriggerConfig(value: AwsAppflowFlow.TriggerConfigProperty): void;
    get triggerConfigInput(): AwsAppflowFlow.TriggerConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsAppflowFlowDestinationFlowConfigDestinationConnectorPropertiesCustomConnectorErrorHandlingConfigPropertyToTerraform(struct?: AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorErrorHandlingConfigPropertyOutputReference | AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorErrorHandlingConfigProperty): any;
export declare function awsAppflowFlowDestinationFlowConfigDestinationConnectorPropertiesCustomConnectorErrorHandlingConfigPropertyToHclTerraform(struct?: AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorErrorHandlingConfigPropertyOutputReference | AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorErrorHandlingConfigProperty): any;
export declare function awsAppflowFlowDestinationFlowConfigDestinationConnectorPropertiesCustomConnectorPropertyToTerraform(struct?: AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorPropertyOutputReference | AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorProperty): any;
export declare function awsAppflowFlowDestinationFlowConfigDestinationConnectorPropertiesCustomConnectorPropertyToHclTerraform(struct?: AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorPropertyOutputReference | AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorProperty): any;
export declare function awsAppflowFlowCustomerProfilesPropertyToTerraform(struct?: AwsAppflowFlow.CustomerProfilesPropertyOutputReference | AwsAppflowFlow.CustomerProfilesProperty): any;
export declare function awsAppflowFlowCustomerProfilesPropertyToHclTerraform(struct?: AwsAppflowFlow.CustomerProfilesPropertyOutputReference | AwsAppflowFlow.CustomerProfilesProperty): any;
export declare function awsAppflowFlowDestinationFlowConfigDestinationConnectorPropertiesEventBridgeErrorHandlingConfigPropertyToTerraform(struct?: AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesEventBridgeErrorHandlingConfigPropertyOutputReference | AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesEventBridgeErrorHandlingConfigProperty): any;
export declare function awsAppflowFlowDestinationFlowConfigDestinationConnectorPropertiesEventBridgeErrorHandlingConfigPropertyToHclTerraform(struct?: AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesEventBridgeErrorHandlingConfigPropertyOutputReference | AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesEventBridgeErrorHandlingConfigProperty): any;
export declare function awsAppflowFlowEventBridgePropertyToTerraform(struct?: AwsAppflowFlow.EventBridgePropertyOutputReference | AwsAppflowFlow.EventBridgeProperty): any;
export declare function awsAppflowFlowEventBridgePropertyToHclTerraform(struct?: AwsAppflowFlow.EventBridgePropertyOutputReference | AwsAppflowFlow.EventBridgeProperty): any;
export declare function awsAppflowFlowDestinationFlowConfigDestinationConnectorPropertiesHoneycodeErrorHandlingConfigPropertyToTerraform(struct?: AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesHoneycodeErrorHandlingConfigPropertyOutputReference | AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesHoneycodeErrorHandlingConfigProperty): any;
export declare function awsAppflowFlowDestinationFlowConfigDestinationConnectorPropertiesHoneycodeErrorHandlingConfigPropertyToHclTerraform(struct?: AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesHoneycodeErrorHandlingConfigPropertyOutputReference | AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesHoneycodeErrorHandlingConfigProperty): any;
export declare function awsAppflowFlowHoneycodePropertyToTerraform(struct?: AwsAppflowFlow.HoneycodePropertyOutputReference | AwsAppflowFlow.HoneycodeProperty): any;
export declare function awsAppflowFlowHoneycodePropertyToHclTerraform(struct?: AwsAppflowFlow.HoneycodePropertyOutputReference | AwsAppflowFlow.HoneycodeProperty): any;
export declare function awsAppflowFlowLookoutMetricsPropertyToTerraform(struct?: AwsAppflowFlow.LookoutMetricsPropertyOutputReference | AwsAppflowFlow.LookoutMetricsProperty): any;
export declare function awsAppflowFlowLookoutMetricsPropertyToHclTerraform(struct?: AwsAppflowFlow.LookoutMetricsPropertyOutputReference | AwsAppflowFlow.LookoutMetricsProperty): any;
export declare function awsAppflowFlowDestinationFlowConfigDestinationConnectorPropertiesMarketoErrorHandlingConfigPropertyToTerraform(struct?: AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesMarketoErrorHandlingConfigPropertyOutputReference | AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesMarketoErrorHandlingConfigProperty): any;
export declare function awsAppflowFlowDestinationFlowConfigDestinationConnectorPropertiesMarketoErrorHandlingConfigPropertyToHclTerraform(struct?: AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesMarketoErrorHandlingConfigPropertyOutputReference | AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesMarketoErrorHandlingConfigProperty): any;
export declare function awsAppflowFlowDestinationFlowConfigDestinationConnectorPropertiesMarketoPropertyToTerraform(struct?: AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesMarketoPropertyOutputReference | AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesMarketoProperty): any;
export declare function awsAppflowFlowDestinationFlowConfigDestinationConnectorPropertiesMarketoPropertyToHclTerraform(struct?: AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesMarketoPropertyOutputReference | AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesMarketoProperty): any;
export declare function awsAppflowFlowDestinationFlowConfigDestinationConnectorPropertiesRedshiftErrorHandlingConfigPropertyToTerraform(struct?: AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesRedshiftErrorHandlingConfigPropertyOutputReference | AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesRedshiftErrorHandlingConfigProperty): any;
export declare function awsAppflowFlowDestinationFlowConfigDestinationConnectorPropertiesRedshiftErrorHandlingConfigPropertyToHclTerraform(struct?: AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesRedshiftErrorHandlingConfigPropertyOutputReference | AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesRedshiftErrorHandlingConfigProperty): any;
export declare function awsAppflowFlowRedshiftPropertyToTerraform(struct?: AwsAppflowFlow.RedshiftPropertyOutputReference | AwsAppflowFlow.RedshiftProperty): any;
export declare function awsAppflowFlowRedshiftPropertyToHclTerraform(struct?: AwsAppflowFlow.RedshiftPropertyOutputReference | AwsAppflowFlow.RedshiftProperty): any;
export declare function awsAppflowFlowDestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigAggregationConfigPropertyToTerraform(struct?: AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigAggregationConfigPropertyOutputReference | AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigAggregationConfigProperty): any;
export declare function awsAppflowFlowDestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigAggregationConfigPropertyToHclTerraform(struct?: AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigAggregationConfigPropertyOutputReference | AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigAggregationConfigProperty): any;
export declare function awsAppflowFlowDestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigPrefixConfigPropertyToTerraform(struct?: AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigPrefixConfigPropertyOutputReference | AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigPrefixConfigProperty): any;
export declare function awsAppflowFlowDestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigPrefixConfigPropertyToHclTerraform(struct?: AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigPrefixConfigPropertyOutputReference | AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigPrefixConfigProperty): any;
export declare function awsAppflowFlowDestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigPropertyToTerraform(struct?: AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigPropertyOutputReference | AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigProperty): any;
export declare function awsAppflowFlowDestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigPropertyToHclTerraform(struct?: AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigPropertyOutputReference | AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigProperty): any;
export declare function awsAppflowFlowDestinationFlowConfigDestinationConnectorPropertiesS3PropertyToTerraform(struct?: AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesS3PropertyOutputReference | AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesS3Property): any;
export declare function awsAppflowFlowDestinationFlowConfigDestinationConnectorPropertiesS3PropertyToHclTerraform(struct?: AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesS3PropertyOutputReference | AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesS3Property): any;
export declare function awsAppflowFlowDestinationFlowConfigDestinationConnectorPropertiesSalesforceErrorHandlingConfigPropertyToTerraform(struct?: AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesSalesforceErrorHandlingConfigPropertyOutputReference | AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesSalesforceErrorHandlingConfigProperty): any;
export declare function awsAppflowFlowDestinationFlowConfigDestinationConnectorPropertiesSalesforceErrorHandlingConfigPropertyToHclTerraform(struct?: AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesSalesforceErrorHandlingConfigPropertyOutputReference | AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesSalesforceErrorHandlingConfigProperty): any;
export declare function awsAppflowFlowDestinationFlowConfigDestinationConnectorPropertiesSalesforcePropertyToTerraform(struct?: AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesSalesforcePropertyOutputReference | AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesSalesforceProperty): any;
export declare function awsAppflowFlowDestinationFlowConfigDestinationConnectorPropertiesSalesforcePropertyToHclTerraform(struct?: AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesSalesforcePropertyOutputReference | AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesSalesforceProperty): any;
export declare function awsAppflowFlowDestinationFlowConfigDestinationConnectorPropertiesSapoDataErrorHandlingConfigPropertyToTerraform(struct?: AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesSapoDataErrorHandlingConfigPropertyOutputReference | AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesSapoDataErrorHandlingConfigProperty): any;
export declare function awsAppflowFlowDestinationFlowConfigDestinationConnectorPropertiesSapoDataErrorHandlingConfigPropertyToHclTerraform(struct?: AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesSapoDataErrorHandlingConfigPropertyOutputReference | AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesSapoDataErrorHandlingConfigProperty): any;
export declare function awsAppflowFlowSuccessResponseHandlingConfigPropertyToTerraform(struct?: AwsAppflowFlow.SuccessResponseHandlingConfigPropertyOutputReference | AwsAppflowFlow.SuccessResponseHandlingConfigProperty): any;
export declare function awsAppflowFlowSuccessResponseHandlingConfigPropertyToHclTerraform(struct?: AwsAppflowFlow.SuccessResponseHandlingConfigPropertyOutputReference | AwsAppflowFlow.SuccessResponseHandlingConfigProperty): any;
export declare function awsAppflowFlowDestinationFlowConfigDestinationConnectorPropertiesSapoDataPropertyToTerraform(struct?: AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesSapoDataPropertyOutputReference | AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesSapoDataProperty): any;
export declare function awsAppflowFlowDestinationFlowConfigDestinationConnectorPropertiesSapoDataPropertyToHclTerraform(struct?: AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesSapoDataPropertyOutputReference | AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesSapoDataProperty): any;
export declare function awsAppflowFlowDestinationFlowConfigDestinationConnectorPropertiesSnowflakeErrorHandlingConfigPropertyToTerraform(struct?: AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesSnowflakeErrorHandlingConfigPropertyOutputReference | AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesSnowflakeErrorHandlingConfigProperty): any;
export declare function awsAppflowFlowDestinationFlowConfigDestinationConnectorPropertiesSnowflakeErrorHandlingConfigPropertyToHclTerraform(struct?: AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesSnowflakeErrorHandlingConfigPropertyOutputReference | AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesSnowflakeErrorHandlingConfigProperty): any;
export declare function awsAppflowFlowSnowflakePropertyToTerraform(struct?: AwsAppflowFlow.SnowflakePropertyOutputReference | AwsAppflowFlow.SnowflakeProperty): any;
export declare function awsAppflowFlowSnowflakePropertyToHclTerraform(struct?: AwsAppflowFlow.SnowflakePropertyOutputReference | AwsAppflowFlow.SnowflakeProperty): any;
export declare function awsAppflowFlowDestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigAggregationConfigPropertyToTerraform(struct?: AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigAggregationConfigPropertyOutputReference | AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigAggregationConfigProperty): any;
export declare function awsAppflowFlowDestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigAggregationConfigPropertyToHclTerraform(struct?: AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigAggregationConfigPropertyOutputReference | AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigAggregationConfigProperty): any;
export declare function awsAppflowFlowDestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPrefixConfigPropertyToTerraform(struct?: AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPrefixConfigPropertyOutputReference | AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPrefixConfigProperty): any;
export declare function awsAppflowFlowDestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPrefixConfigPropertyToHclTerraform(struct?: AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPrefixConfigPropertyOutputReference | AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPrefixConfigProperty): any;
export declare function awsAppflowFlowDestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPropertyToTerraform(struct?: AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPropertyOutputReference | AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigProperty): any;
export declare function awsAppflowFlowDestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPropertyToHclTerraform(struct?: AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPropertyOutputReference | AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigProperty): any;
export declare function awsAppflowFlowUpsolverPropertyToTerraform(struct?: AwsAppflowFlow.UpsolverPropertyOutputReference | AwsAppflowFlow.UpsolverProperty): any;
export declare function awsAppflowFlowUpsolverPropertyToHclTerraform(struct?: AwsAppflowFlow.UpsolverPropertyOutputReference | AwsAppflowFlow.UpsolverProperty): any;
export declare function awsAppflowFlowDestinationFlowConfigDestinationConnectorPropertiesZendeskErrorHandlingConfigPropertyToTerraform(struct?: AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesZendeskErrorHandlingConfigPropertyOutputReference | AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesZendeskErrorHandlingConfigProperty): any;
export declare function awsAppflowFlowDestinationFlowConfigDestinationConnectorPropertiesZendeskErrorHandlingConfigPropertyToHclTerraform(struct?: AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesZendeskErrorHandlingConfigPropertyOutputReference | AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesZendeskErrorHandlingConfigProperty): any;
export declare function awsAppflowFlowDestinationFlowConfigDestinationConnectorPropertiesZendeskPropertyToTerraform(struct?: AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesZendeskPropertyOutputReference | AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesZendeskProperty): any;
export declare function awsAppflowFlowDestinationFlowConfigDestinationConnectorPropertiesZendeskPropertyToHclTerraform(struct?: AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesZendeskPropertyOutputReference | AwsAppflowFlow.DestinationFlowConfigDestinationConnectorPropertiesZendeskProperty): any;
export declare function awsAppflowFlowDestinationConnectorPropertiesPropertyToTerraform(struct?: AwsAppflowFlow.DestinationConnectorPropertiesPropertyOutputReference | AwsAppflowFlow.DestinationConnectorPropertiesProperty): any;
export declare function awsAppflowFlowDestinationConnectorPropertiesPropertyToHclTerraform(struct?: AwsAppflowFlow.DestinationConnectorPropertiesPropertyOutputReference | AwsAppflowFlow.DestinationConnectorPropertiesProperty): any;
export declare function awsAppflowFlowDestinationFlowConfigPropertyToTerraform(struct?: AwsAppflowFlow.DestinationFlowConfigProperty | cdktn.IResolvable): any;
export declare function awsAppflowFlowDestinationFlowConfigPropertyToHclTerraform(struct?: AwsAppflowFlow.DestinationFlowConfigProperty | cdktn.IResolvable): any;
export declare function awsAppflowFlowGlueDataCatalogPropertyToTerraform(struct?: AwsAppflowFlow.GlueDataCatalogPropertyOutputReference | AwsAppflowFlow.GlueDataCatalogProperty): any;
export declare function awsAppflowFlowGlueDataCatalogPropertyToHclTerraform(struct?: AwsAppflowFlow.GlueDataCatalogPropertyOutputReference | AwsAppflowFlow.GlueDataCatalogProperty): any;
export declare function awsAppflowFlowMetadataCatalogConfigPropertyToTerraform(struct?: AwsAppflowFlow.MetadataCatalogConfigPropertyOutputReference | AwsAppflowFlow.MetadataCatalogConfigProperty): any;
export declare function awsAppflowFlowMetadataCatalogConfigPropertyToHclTerraform(struct?: AwsAppflowFlow.MetadataCatalogConfigPropertyOutputReference | AwsAppflowFlow.MetadataCatalogConfigProperty): any;
export declare function awsAppflowFlowIncrementalPullConfigPropertyToTerraform(struct?: AwsAppflowFlow.IncrementalPullConfigPropertyOutputReference | AwsAppflowFlow.IncrementalPullConfigProperty): any;
export declare function awsAppflowFlowIncrementalPullConfigPropertyToHclTerraform(struct?: AwsAppflowFlow.IncrementalPullConfigPropertyOutputReference | AwsAppflowFlow.IncrementalPullConfigProperty): any;
export declare function awsAppflowFlowAmplitudePropertyToTerraform(struct?: AwsAppflowFlow.AmplitudePropertyOutputReference | AwsAppflowFlow.AmplitudeProperty): any;
export declare function awsAppflowFlowAmplitudePropertyToHclTerraform(struct?: AwsAppflowFlow.AmplitudePropertyOutputReference | AwsAppflowFlow.AmplitudeProperty): any;
export declare function awsAppflowFlowSourceFlowConfigSourceConnectorPropertiesCustomConnectorPropertyToTerraform(struct?: AwsAppflowFlow.SourceFlowConfigSourceConnectorPropertiesCustomConnectorPropertyOutputReference | AwsAppflowFlow.SourceFlowConfigSourceConnectorPropertiesCustomConnectorProperty): any;
export declare function awsAppflowFlowSourceFlowConfigSourceConnectorPropertiesCustomConnectorPropertyToHclTerraform(struct?: AwsAppflowFlow.SourceFlowConfigSourceConnectorPropertiesCustomConnectorPropertyOutputReference | AwsAppflowFlow.SourceFlowConfigSourceConnectorPropertiesCustomConnectorProperty): any;
export declare function awsAppflowFlowDatadogPropertyToTerraform(struct?: AwsAppflowFlow.DatadogPropertyOutputReference | AwsAppflowFlow.DatadogProperty): any;
export declare function awsAppflowFlowDatadogPropertyToHclTerraform(struct?: AwsAppflowFlow.DatadogPropertyOutputReference | AwsAppflowFlow.DatadogProperty): any;
export declare function awsAppflowFlowDynatracePropertyToTerraform(struct?: AwsAppflowFlow.DynatracePropertyOutputReference | AwsAppflowFlow.DynatraceProperty): any;
export declare function awsAppflowFlowDynatracePropertyToHclTerraform(struct?: AwsAppflowFlow.DynatracePropertyOutputReference | AwsAppflowFlow.DynatraceProperty): any;
export declare function awsAppflowFlowGoogleAnalyticsPropertyToTerraform(struct?: AwsAppflowFlow.GoogleAnalyticsPropertyOutputReference | AwsAppflowFlow.GoogleAnalyticsProperty): any;
export declare function awsAppflowFlowGoogleAnalyticsPropertyToHclTerraform(struct?: AwsAppflowFlow.GoogleAnalyticsPropertyOutputReference | AwsAppflowFlow.GoogleAnalyticsProperty): any;
export declare function awsAppflowFlowInforNexusPropertyToTerraform(struct?: AwsAppflowFlow.InforNexusPropertyOutputReference | AwsAppflowFlow.InforNexusProperty): any;
export declare function awsAppflowFlowInforNexusPropertyToHclTerraform(struct?: AwsAppflowFlow.InforNexusPropertyOutputReference | AwsAppflowFlow.InforNexusProperty): any;
export declare function awsAppflowFlowSourceFlowConfigSourceConnectorPropertiesMarketoPropertyToTerraform(struct?: AwsAppflowFlow.SourceFlowConfigSourceConnectorPropertiesMarketoPropertyOutputReference | AwsAppflowFlow.SourceFlowConfigSourceConnectorPropertiesMarketoProperty): any;
export declare function awsAppflowFlowSourceFlowConfigSourceConnectorPropertiesMarketoPropertyToHclTerraform(struct?: AwsAppflowFlow.SourceFlowConfigSourceConnectorPropertiesMarketoPropertyOutputReference | AwsAppflowFlow.SourceFlowConfigSourceConnectorPropertiesMarketoProperty): any;
export declare function awsAppflowFlowS3InputFormatConfigPropertyToTerraform(struct?: AwsAppflowFlow.S3InputFormatConfigPropertyOutputReference | AwsAppflowFlow.S3InputFormatConfigProperty): any;
export declare function awsAppflowFlowS3InputFormatConfigPropertyToHclTerraform(struct?: AwsAppflowFlow.S3InputFormatConfigPropertyOutputReference | AwsAppflowFlow.S3InputFormatConfigProperty): any;
export declare function awsAppflowFlowSourceFlowConfigSourceConnectorPropertiesS3PropertyToTerraform(struct?: AwsAppflowFlow.SourceFlowConfigSourceConnectorPropertiesS3PropertyOutputReference | AwsAppflowFlow.SourceFlowConfigSourceConnectorPropertiesS3Property): any;
export declare function awsAppflowFlowSourceFlowConfigSourceConnectorPropertiesS3PropertyToHclTerraform(struct?: AwsAppflowFlow.SourceFlowConfigSourceConnectorPropertiesS3PropertyOutputReference | AwsAppflowFlow.SourceFlowConfigSourceConnectorPropertiesS3Property): any;
export declare function awsAppflowFlowSourceFlowConfigSourceConnectorPropertiesSalesforcePropertyToTerraform(struct?: AwsAppflowFlow.SourceFlowConfigSourceConnectorPropertiesSalesforcePropertyOutputReference | AwsAppflowFlow.SourceFlowConfigSourceConnectorPropertiesSalesforceProperty): any;
export declare function awsAppflowFlowSourceFlowConfigSourceConnectorPropertiesSalesforcePropertyToHclTerraform(struct?: AwsAppflowFlow.SourceFlowConfigSourceConnectorPropertiesSalesforcePropertyOutputReference | AwsAppflowFlow.SourceFlowConfigSourceConnectorPropertiesSalesforceProperty): any;
export declare function awsAppflowFlowPaginationConfigPropertyToTerraform(struct?: AwsAppflowFlow.PaginationConfigPropertyOutputReference | AwsAppflowFlow.PaginationConfigProperty): any;
export declare function awsAppflowFlowPaginationConfigPropertyToHclTerraform(struct?: AwsAppflowFlow.PaginationConfigPropertyOutputReference | AwsAppflowFlow.PaginationConfigProperty): any;
export declare function awsAppflowFlowParallelismConfigPropertyToTerraform(struct?: AwsAppflowFlow.ParallelismConfigPropertyOutputReference | AwsAppflowFlow.ParallelismConfigProperty): any;
export declare function awsAppflowFlowParallelismConfigPropertyToHclTerraform(struct?: AwsAppflowFlow.ParallelismConfigPropertyOutputReference | AwsAppflowFlow.ParallelismConfigProperty): any;
export declare function awsAppflowFlowSourceFlowConfigSourceConnectorPropertiesSapoDataPropertyToTerraform(struct?: AwsAppflowFlow.SourceFlowConfigSourceConnectorPropertiesSapoDataPropertyOutputReference | AwsAppflowFlow.SourceFlowConfigSourceConnectorPropertiesSapoDataProperty): any;
export declare function awsAppflowFlowSourceFlowConfigSourceConnectorPropertiesSapoDataPropertyToHclTerraform(struct?: AwsAppflowFlow.SourceFlowConfigSourceConnectorPropertiesSapoDataPropertyOutputReference | AwsAppflowFlow.SourceFlowConfigSourceConnectorPropertiesSapoDataProperty): any;
export declare function awsAppflowFlowServiceNowPropertyToTerraform(struct?: AwsAppflowFlow.ServiceNowPropertyOutputReference | AwsAppflowFlow.ServiceNowProperty): any;
export declare function awsAppflowFlowServiceNowPropertyToHclTerraform(struct?: AwsAppflowFlow.ServiceNowPropertyOutputReference | AwsAppflowFlow.ServiceNowProperty): any;
export declare function awsAppflowFlowSingularPropertyToTerraform(struct?: AwsAppflowFlow.SingularPropertyOutputReference | AwsAppflowFlow.SingularProperty): any;
export declare function awsAppflowFlowSingularPropertyToHclTerraform(struct?: AwsAppflowFlow.SingularPropertyOutputReference | AwsAppflowFlow.SingularProperty): any;
export declare function awsAppflowFlowSlackPropertyToTerraform(struct?: AwsAppflowFlow.SlackPropertyOutputReference | AwsAppflowFlow.SlackProperty): any;
export declare function awsAppflowFlowSlackPropertyToHclTerraform(struct?: AwsAppflowFlow.SlackPropertyOutputReference | AwsAppflowFlow.SlackProperty): any;
export declare function awsAppflowFlowTrendmicroPropertyToTerraform(struct?: AwsAppflowFlow.TrendmicroPropertyOutputReference | AwsAppflowFlow.TrendmicroProperty): any;
export declare function awsAppflowFlowTrendmicroPropertyToHclTerraform(struct?: AwsAppflowFlow.TrendmicroPropertyOutputReference | AwsAppflowFlow.TrendmicroProperty): any;
export declare function awsAppflowFlowVeevaPropertyToTerraform(struct?: AwsAppflowFlow.VeevaPropertyOutputReference | AwsAppflowFlow.VeevaProperty): any;
export declare function awsAppflowFlowVeevaPropertyToHclTerraform(struct?: AwsAppflowFlow.VeevaPropertyOutputReference | AwsAppflowFlow.VeevaProperty): any;
export declare function awsAppflowFlowSourceFlowConfigSourceConnectorPropertiesZendeskPropertyToTerraform(struct?: AwsAppflowFlow.SourceFlowConfigSourceConnectorPropertiesZendeskPropertyOutputReference | AwsAppflowFlow.SourceFlowConfigSourceConnectorPropertiesZendeskProperty): any;
export declare function awsAppflowFlowSourceFlowConfigSourceConnectorPropertiesZendeskPropertyToHclTerraform(struct?: AwsAppflowFlow.SourceFlowConfigSourceConnectorPropertiesZendeskPropertyOutputReference | AwsAppflowFlow.SourceFlowConfigSourceConnectorPropertiesZendeskProperty): any;
export declare function awsAppflowFlowSourceConnectorPropertiesPropertyToTerraform(struct?: AwsAppflowFlow.SourceConnectorPropertiesPropertyOutputReference | AwsAppflowFlow.SourceConnectorPropertiesProperty): any;
export declare function awsAppflowFlowSourceConnectorPropertiesPropertyToHclTerraform(struct?: AwsAppflowFlow.SourceConnectorPropertiesPropertyOutputReference | AwsAppflowFlow.SourceConnectorPropertiesProperty): any;
export declare function awsAppflowFlowSourceFlowConfigPropertyToTerraform(struct?: AwsAppflowFlow.SourceFlowConfigPropertyOutputReference | AwsAppflowFlow.SourceFlowConfigProperty): any;
export declare function awsAppflowFlowSourceFlowConfigPropertyToHclTerraform(struct?: AwsAppflowFlow.SourceFlowConfigPropertyOutputReference | AwsAppflowFlow.SourceFlowConfigProperty): any;
export declare function awsAppflowFlowConnectorOperatorPropertyToTerraform(struct?: AwsAppflowFlow.ConnectorOperatorProperty | cdktn.IResolvable): any;
export declare function awsAppflowFlowConnectorOperatorPropertyToHclTerraform(struct?: AwsAppflowFlow.ConnectorOperatorProperty | cdktn.IResolvable): any;
export declare function awsAppflowFlowTaskPropertyToTerraform(struct?: AwsAppflowFlow.TaskProperty | cdktn.IResolvable): any;
export declare function awsAppflowFlowTaskPropertyToHclTerraform(struct?: AwsAppflowFlow.TaskProperty | cdktn.IResolvable): any;
export declare function awsAppflowFlowScheduledPropertyToTerraform(struct?: AwsAppflowFlow.ScheduledPropertyOutputReference | AwsAppflowFlow.ScheduledProperty): any;
export declare function awsAppflowFlowScheduledPropertyToHclTerraform(struct?: AwsAppflowFlow.ScheduledPropertyOutputReference | AwsAppflowFlow.ScheduledProperty): any;
export declare function awsAppflowFlowTriggerPropertiesPropertyToTerraform(struct?: AwsAppflowFlow.TriggerPropertiesPropertyOutputReference | AwsAppflowFlow.TriggerPropertiesProperty): any;
export declare function awsAppflowFlowTriggerPropertiesPropertyToHclTerraform(struct?: AwsAppflowFlow.TriggerPropertiesPropertyOutputReference | AwsAppflowFlow.TriggerPropertiesProperty): any;
export declare function awsAppflowFlowTriggerConfigPropertyToTerraform(struct?: AwsAppflowFlow.TriggerConfigPropertyOutputReference | AwsAppflowFlow.TriggerConfigProperty): any;
export declare function awsAppflowFlowTriggerConfigPropertyToHclTerraform(struct?: AwsAppflowFlow.TriggerConfigPropertyOutputReference | AwsAppflowFlow.TriggerConfigProperty): any;
export declare namespace AwsAppflowFlow {
    interface DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorErrorHandlingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_name AwsAppflowFlow#bucket_name}
        */
        readonly bucketName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_prefix AwsAppflowFlow#bucket_prefix}
        */
        readonly bucketPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#fail_on_first_destination_error AwsAppflowFlow#fail_on_first_destination_error}
        */
        readonly failOnFirstDestinationError?: boolean | cdktn.IResolvable;
    }
    class DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorErrorHandlingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorErrorHandlingConfigProperty | undefined;
        set internalValue(value: DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorErrorHandlingConfigProperty | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        resetBucketName(): void;
        get bucketNameInput(): string | undefined;
        private _bucketPrefix?;
        get bucketPrefix(): string;
        set bucketPrefix(value: string);
        resetBucketPrefix(): void;
        get bucketPrefixInput(): string | undefined;
        private _failOnFirstDestinationError?;
        get failOnFirstDestinationError(): boolean | cdktn.IResolvable;
        set failOnFirstDestinationError(value: boolean | cdktn.IResolvable);
        resetFailOnFirstDestinationError(): void;
        get failOnFirstDestinationErrorInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#custom_properties AwsAppflowFlow#custom_properties}
        */
        readonly customProperties?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#entity_name AwsAppflowFlow#entity_name}
        */
        readonly entityName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#id_field_names AwsAppflowFlow#id_field_names}
        */
        readonly idFieldNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#write_operation_type AwsAppflowFlow#write_operation_type}
        */
        readonly writeOperationType?: string;
        /**
        * error_handling_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#error_handling_config AwsAppflowFlow#error_handling_config}
        */
        readonly errorHandlingConfig?: DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorErrorHandlingConfigProperty;
    }
    class DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorProperty | undefined;
        set internalValue(value: DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorProperty | undefined);
        private _customProperties?;
        get customProperties(): {
            [key: string]: string;
        };
        set customProperties(value: {
            [key: string]: string;
        });
        resetCustomProperties(): void;
        get customPropertiesInput(): {
            [key: string]: string;
        } | undefined;
        private _entityName?;
        get entityName(): string;
        set entityName(value: string);
        get entityNameInput(): string | undefined;
        private _idFieldNames?;
        get idFieldNames(): string[];
        set idFieldNames(value: string[]);
        resetIdFieldNames(): void;
        get idFieldNamesInput(): string[] | undefined;
        private _writeOperationType?;
        get writeOperationType(): string;
        set writeOperationType(value: string);
        resetWriteOperationType(): void;
        get writeOperationTypeInput(): string | undefined;
        private _errorHandlingConfig;
        get errorHandlingConfig(): DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorErrorHandlingConfigPropertyOutputReference;
        putErrorHandlingConfig(value: DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorErrorHandlingConfigProperty): void;
        resetErrorHandlingConfig(): void;
        get errorHandlingConfigInput(): DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorErrorHandlingConfigProperty | undefined;
    }
    interface CustomerProfilesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#domain_name AwsAppflowFlow#domain_name}
        */
        readonly domainName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object_type_name AwsAppflowFlow#object_type_name}
        */
        readonly objectTypeName?: string;
    }
    class CustomerProfilesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CustomerProfilesProperty | undefined;
        set internalValue(value: CustomerProfilesProperty | undefined);
        private _domainName?;
        get domainName(): string;
        set domainName(value: string);
        get domainNameInput(): string | undefined;
        private _objectTypeName?;
        get objectTypeName(): string;
        set objectTypeName(value: string);
        resetObjectTypeName(): void;
        get objectTypeNameInput(): string | undefined;
    }
    interface DestinationFlowConfigDestinationConnectorPropertiesEventBridgeErrorHandlingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_name AwsAppflowFlow#bucket_name}
        */
        readonly bucketName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_prefix AwsAppflowFlow#bucket_prefix}
        */
        readonly bucketPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#fail_on_first_destination_error AwsAppflowFlow#fail_on_first_destination_error}
        */
        readonly failOnFirstDestinationError?: boolean | cdktn.IResolvable;
    }
    class DestinationFlowConfigDestinationConnectorPropertiesEventBridgeErrorHandlingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationFlowConfigDestinationConnectorPropertiesEventBridgeErrorHandlingConfigProperty | undefined;
        set internalValue(value: DestinationFlowConfigDestinationConnectorPropertiesEventBridgeErrorHandlingConfigProperty | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        resetBucketName(): void;
        get bucketNameInput(): string | undefined;
        private _bucketPrefix?;
        get bucketPrefix(): string;
        set bucketPrefix(value: string);
        resetBucketPrefix(): void;
        get bucketPrefixInput(): string | undefined;
        private _failOnFirstDestinationError?;
        get failOnFirstDestinationError(): boolean | cdktn.IResolvable;
        set failOnFirstDestinationError(value: boolean | cdktn.IResolvable);
        resetFailOnFirstDestinationError(): void;
        get failOnFirstDestinationErrorInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface EventBridgeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object AwsAppflowFlow#object}
        */
        readonly object: string;
        /**
        * error_handling_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#error_handling_config AwsAppflowFlow#error_handling_config}
        */
        readonly errorHandlingConfig?: DestinationFlowConfigDestinationConnectorPropertiesEventBridgeErrorHandlingConfigProperty;
    }
    class EventBridgePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EventBridgeProperty | undefined;
        set internalValue(value: EventBridgeProperty | undefined);
        private _object?;
        get object(): string;
        set object(value: string);
        get objectInput(): string | undefined;
        private _errorHandlingConfig;
        get errorHandlingConfig(): DestinationFlowConfigDestinationConnectorPropertiesEventBridgeErrorHandlingConfigPropertyOutputReference;
        putErrorHandlingConfig(value: DestinationFlowConfigDestinationConnectorPropertiesEventBridgeErrorHandlingConfigProperty): void;
        resetErrorHandlingConfig(): void;
        get errorHandlingConfigInput(): DestinationFlowConfigDestinationConnectorPropertiesEventBridgeErrorHandlingConfigProperty | undefined;
    }
    interface DestinationFlowConfigDestinationConnectorPropertiesHoneycodeErrorHandlingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_name AwsAppflowFlow#bucket_name}
        */
        readonly bucketName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_prefix AwsAppflowFlow#bucket_prefix}
        */
        readonly bucketPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#fail_on_first_destination_error AwsAppflowFlow#fail_on_first_destination_error}
        */
        readonly failOnFirstDestinationError?: boolean | cdktn.IResolvable;
    }
    class DestinationFlowConfigDestinationConnectorPropertiesHoneycodeErrorHandlingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationFlowConfigDestinationConnectorPropertiesHoneycodeErrorHandlingConfigProperty | undefined;
        set internalValue(value: DestinationFlowConfigDestinationConnectorPropertiesHoneycodeErrorHandlingConfigProperty | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        resetBucketName(): void;
        get bucketNameInput(): string | undefined;
        private _bucketPrefix?;
        get bucketPrefix(): string;
        set bucketPrefix(value: string);
        resetBucketPrefix(): void;
        get bucketPrefixInput(): string | undefined;
        private _failOnFirstDestinationError?;
        get failOnFirstDestinationError(): boolean | cdktn.IResolvable;
        set failOnFirstDestinationError(value: boolean | cdktn.IResolvable);
        resetFailOnFirstDestinationError(): void;
        get failOnFirstDestinationErrorInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface HoneycodeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object AwsAppflowFlow#object}
        */
        readonly object: string;
        /**
        * error_handling_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#error_handling_config AwsAppflowFlow#error_handling_config}
        */
        readonly errorHandlingConfig?: DestinationFlowConfigDestinationConnectorPropertiesHoneycodeErrorHandlingConfigProperty;
    }
    class HoneycodePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HoneycodeProperty | undefined;
        set internalValue(value: HoneycodeProperty | undefined);
        private _object?;
        get object(): string;
        set object(value: string);
        get objectInput(): string | undefined;
        private _errorHandlingConfig;
        get errorHandlingConfig(): DestinationFlowConfigDestinationConnectorPropertiesHoneycodeErrorHandlingConfigPropertyOutputReference;
        putErrorHandlingConfig(value: DestinationFlowConfigDestinationConnectorPropertiesHoneycodeErrorHandlingConfigProperty): void;
        resetErrorHandlingConfig(): void;
        get errorHandlingConfigInput(): DestinationFlowConfigDestinationConnectorPropertiesHoneycodeErrorHandlingConfigProperty | undefined;
    }
    interface LookoutMetricsProperty {
    }
    class LookoutMetricsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LookoutMetricsProperty | undefined;
        set internalValue(value: LookoutMetricsProperty | undefined);
    }
    interface DestinationFlowConfigDestinationConnectorPropertiesMarketoErrorHandlingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_name AwsAppflowFlow#bucket_name}
        */
        readonly bucketName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_prefix AwsAppflowFlow#bucket_prefix}
        */
        readonly bucketPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#fail_on_first_destination_error AwsAppflowFlow#fail_on_first_destination_error}
        */
        readonly failOnFirstDestinationError?: boolean | cdktn.IResolvable;
    }
    class DestinationFlowConfigDestinationConnectorPropertiesMarketoErrorHandlingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationFlowConfigDestinationConnectorPropertiesMarketoErrorHandlingConfigProperty | undefined;
        set internalValue(value: DestinationFlowConfigDestinationConnectorPropertiesMarketoErrorHandlingConfigProperty | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        resetBucketName(): void;
        get bucketNameInput(): string | undefined;
        private _bucketPrefix?;
        get bucketPrefix(): string;
        set bucketPrefix(value: string);
        resetBucketPrefix(): void;
        get bucketPrefixInput(): string | undefined;
        private _failOnFirstDestinationError?;
        get failOnFirstDestinationError(): boolean | cdktn.IResolvable;
        set failOnFirstDestinationError(value: boolean | cdktn.IResolvable);
        resetFailOnFirstDestinationError(): void;
        get failOnFirstDestinationErrorInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface DestinationFlowConfigDestinationConnectorPropertiesMarketoProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object AwsAppflowFlow#object}
        */
        readonly object: string;
        /**
        * error_handling_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#error_handling_config AwsAppflowFlow#error_handling_config}
        */
        readonly errorHandlingConfig?: DestinationFlowConfigDestinationConnectorPropertiesMarketoErrorHandlingConfigProperty;
    }
    class DestinationFlowConfigDestinationConnectorPropertiesMarketoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationFlowConfigDestinationConnectorPropertiesMarketoProperty | undefined;
        set internalValue(value: DestinationFlowConfigDestinationConnectorPropertiesMarketoProperty | undefined);
        private _object?;
        get object(): string;
        set object(value: string);
        get objectInput(): string | undefined;
        private _errorHandlingConfig;
        get errorHandlingConfig(): DestinationFlowConfigDestinationConnectorPropertiesMarketoErrorHandlingConfigPropertyOutputReference;
        putErrorHandlingConfig(value: DestinationFlowConfigDestinationConnectorPropertiesMarketoErrorHandlingConfigProperty): void;
        resetErrorHandlingConfig(): void;
        get errorHandlingConfigInput(): DestinationFlowConfigDestinationConnectorPropertiesMarketoErrorHandlingConfigProperty | undefined;
    }
    interface DestinationFlowConfigDestinationConnectorPropertiesRedshiftErrorHandlingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_name AwsAppflowFlow#bucket_name}
        */
        readonly bucketName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_prefix AwsAppflowFlow#bucket_prefix}
        */
        readonly bucketPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#fail_on_first_destination_error AwsAppflowFlow#fail_on_first_destination_error}
        */
        readonly failOnFirstDestinationError?: boolean | cdktn.IResolvable;
    }
    class DestinationFlowConfigDestinationConnectorPropertiesRedshiftErrorHandlingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationFlowConfigDestinationConnectorPropertiesRedshiftErrorHandlingConfigProperty | undefined;
        set internalValue(value: DestinationFlowConfigDestinationConnectorPropertiesRedshiftErrorHandlingConfigProperty | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        resetBucketName(): void;
        get bucketNameInput(): string | undefined;
        private _bucketPrefix?;
        get bucketPrefix(): string;
        set bucketPrefix(value: string);
        resetBucketPrefix(): void;
        get bucketPrefixInput(): string | undefined;
        private _failOnFirstDestinationError?;
        get failOnFirstDestinationError(): boolean | cdktn.IResolvable;
        set failOnFirstDestinationError(value: boolean | cdktn.IResolvable);
        resetFailOnFirstDestinationError(): void;
        get failOnFirstDestinationErrorInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface RedshiftProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_prefix AwsAppflowFlow#bucket_prefix}
        */
        readonly bucketPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#intermediate_bucket_name AwsAppflowFlow#intermediate_bucket_name}
        */
        readonly intermediateBucketName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object AwsAppflowFlow#object}
        */
        readonly object: string;
        /**
        * error_handling_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#error_handling_config AwsAppflowFlow#error_handling_config}
        */
        readonly errorHandlingConfig?: DestinationFlowConfigDestinationConnectorPropertiesRedshiftErrorHandlingConfigProperty;
    }
    class RedshiftPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RedshiftProperty | undefined;
        set internalValue(value: RedshiftProperty | undefined);
        private _bucketPrefix?;
        get bucketPrefix(): string;
        set bucketPrefix(value: string);
        resetBucketPrefix(): void;
        get bucketPrefixInput(): string | undefined;
        private _intermediateBucketName?;
        get intermediateBucketName(): string;
        set intermediateBucketName(value: string);
        get intermediateBucketNameInput(): string | undefined;
        private _object?;
        get object(): string;
        set object(value: string);
        get objectInput(): string | undefined;
        private _errorHandlingConfig;
        get errorHandlingConfig(): DestinationFlowConfigDestinationConnectorPropertiesRedshiftErrorHandlingConfigPropertyOutputReference;
        putErrorHandlingConfig(value: DestinationFlowConfigDestinationConnectorPropertiesRedshiftErrorHandlingConfigProperty): void;
        resetErrorHandlingConfig(): void;
        get errorHandlingConfigInput(): DestinationFlowConfigDestinationConnectorPropertiesRedshiftErrorHandlingConfigProperty | undefined;
    }
    interface DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigAggregationConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#aggregation_type AwsAppflowFlow#aggregation_type}
        */
        readonly aggregationType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#target_file_size AwsAppflowFlow#target_file_size}
        */
        readonly targetFileSize?: number;
    }
    class DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigAggregationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigAggregationConfigProperty | undefined;
        set internalValue(value: DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigAggregationConfigProperty | undefined);
        private _aggregationType?;
        get aggregationType(): string;
        set aggregationType(value: string);
        resetAggregationType(): void;
        get aggregationTypeInput(): string | undefined;
        private _targetFileSize?;
        get targetFileSize(): number;
        set targetFileSize(value: number);
        resetTargetFileSize(): void;
        get targetFileSizeInput(): number | undefined;
    }
    interface DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigPrefixConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#prefix_format AwsAppflowFlow#prefix_format}
        */
        readonly prefixFormat?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#prefix_hierarchy AwsAppflowFlow#prefix_hierarchy}
        */
        readonly prefixHierarchy?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#prefix_type AwsAppflowFlow#prefix_type}
        */
        readonly prefixType?: string;
    }
    class DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigPrefixConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigPrefixConfigProperty | undefined;
        set internalValue(value: DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigPrefixConfigProperty | undefined);
        private _prefixFormat?;
        get prefixFormat(): string;
        set prefixFormat(value: string);
        resetPrefixFormat(): void;
        get prefixFormatInput(): string | undefined;
        private _prefixHierarchy?;
        get prefixHierarchy(): string[];
        set prefixHierarchy(value: string[]);
        resetPrefixHierarchy(): void;
        get prefixHierarchyInput(): string[] | undefined;
        private _prefixType?;
        get prefixType(): string;
        set prefixType(value: string);
        resetPrefixType(): void;
        get prefixTypeInput(): string | undefined;
    }
    interface DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#file_type AwsAppflowFlow#file_type}
        */
        readonly fileType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#preserve_source_data_typing AwsAppflowFlow#preserve_source_data_typing}
        */
        readonly preserveSourceDataTyping?: boolean | cdktn.IResolvable;
        /**
        * aggregation_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#aggregation_config AwsAppflowFlow#aggregation_config}
        */
        readonly aggregationConfig?: DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigAggregationConfigProperty;
        /**
        * prefix_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#prefix_config AwsAppflowFlow#prefix_config}
        */
        readonly prefixConfig?: DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigPrefixConfigProperty;
    }
    class DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigProperty | undefined;
        set internalValue(value: DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigProperty | undefined);
        private _fileType?;
        get fileType(): string;
        set fileType(value: string);
        resetFileType(): void;
        get fileTypeInput(): string | undefined;
        private _preserveSourceDataTyping?;
        get preserveSourceDataTyping(): boolean | cdktn.IResolvable;
        set preserveSourceDataTyping(value: boolean | cdktn.IResolvable);
        resetPreserveSourceDataTyping(): void;
        get preserveSourceDataTypingInput(): boolean | cdktn.IResolvable | undefined;
        private _aggregationConfig;
        get aggregationConfig(): DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigAggregationConfigPropertyOutputReference;
        putAggregationConfig(value: DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigAggregationConfigProperty): void;
        resetAggregationConfig(): void;
        get aggregationConfigInput(): DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigAggregationConfigProperty | undefined;
        private _prefixConfig;
        get prefixConfig(): DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigPrefixConfigPropertyOutputReference;
        putPrefixConfig(value: DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigPrefixConfigProperty): void;
        resetPrefixConfig(): void;
        get prefixConfigInput(): DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigPrefixConfigProperty | undefined;
    }
    interface DestinationFlowConfigDestinationConnectorPropertiesS3Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_name AwsAppflowFlow#bucket_name}
        */
        readonly bucketName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_prefix AwsAppflowFlow#bucket_prefix}
        */
        readonly bucketPrefix?: string;
        /**
        * s3_output_format_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#s3_output_format_config AwsAppflowFlow#s3_output_format_config}
        */
        readonly s3OutputFormatConfig?: DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigProperty;
    }
    class DestinationFlowConfigDestinationConnectorPropertiesS3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationFlowConfigDestinationConnectorPropertiesS3Property | undefined;
        set internalValue(value: DestinationFlowConfigDestinationConnectorPropertiesS3Property | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        get bucketNameInput(): string | undefined;
        private _bucketPrefix?;
        get bucketPrefix(): string;
        set bucketPrefix(value: string);
        resetBucketPrefix(): void;
        get bucketPrefixInput(): string | undefined;
        private _s3OutputFormatConfig;
        get s3OutputFormatConfig(): DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigPropertyOutputReference;
        putS3OutputFormatConfig(value: DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigProperty): void;
        resetS3OutputFormatConfig(): void;
        get s3OutputFormatConfigInput(): DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigProperty | undefined;
    }
    interface DestinationFlowConfigDestinationConnectorPropertiesSalesforceErrorHandlingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_name AwsAppflowFlow#bucket_name}
        */
        readonly bucketName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_prefix AwsAppflowFlow#bucket_prefix}
        */
        readonly bucketPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#fail_on_first_destination_error AwsAppflowFlow#fail_on_first_destination_error}
        */
        readonly failOnFirstDestinationError?: boolean | cdktn.IResolvable;
    }
    class DestinationFlowConfigDestinationConnectorPropertiesSalesforceErrorHandlingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationFlowConfigDestinationConnectorPropertiesSalesforceErrorHandlingConfigProperty | undefined;
        set internalValue(value: DestinationFlowConfigDestinationConnectorPropertiesSalesforceErrorHandlingConfigProperty | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        resetBucketName(): void;
        get bucketNameInput(): string | undefined;
        private _bucketPrefix?;
        get bucketPrefix(): string;
        set bucketPrefix(value: string);
        resetBucketPrefix(): void;
        get bucketPrefixInput(): string | undefined;
        private _failOnFirstDestinationError?;
        get failOnFirstDestinationError(): boolean | cdktn.IResolvable;
        set failOnFirstDestinationError(value: boolean | cdktn.IResolvable);
        resetFailOnFirstDestinationError(): void;
        get failOnFirstDestinationErrorInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface DestinationFlowConfigDestinationConnectorPropertiesSalesforceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#data_transfer_api AwsAppflowFlow#data_transfer_api}
        */
        readonly dataTransferApi?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#id_field_names AwsAppflowFlow#id_field_names}
        */
        readonly idFieldNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object AwsAppflowFlow#object}
        */
        readonly object: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#write_operation_type AwsAppflowFlow#write_operation_type}
        */
        readonly writeOperationType?: string;
        /**
        * error_handling_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#error_handling_config AwsAppflowFlow#error_handling_config}
        */
        readonly errorHandlingConfig?: DestinationFlowConfigDestinationConnectorPropertiesSalesforceErrorHandlingConfigProperty;
    }
    class DestinationFlowConfigDestinationConnectorPropertiesSalesforcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationFlowConfigDestinationConnectorPropertiesSalesforceProperty | undefined;
        set internalValue(value: DestinationFlowConfigDestinationConnectorPropertiesSalesforceProperty | undefined);
        private _dataTransferApi?;
        get dataTransferApi(): string;
        set dataTransferApi(value: string);
        resetDataTransferApi(): void;
        get dataTransferApiInput(): string | undefined;
        private _idFieldNames?;
        get idFieldNames(): string[];
        set idFieldNames(value: string[]);
        resetIdFieldNames(): void;
        get idFieldNamesInput(): string[] | undefined;
        private _object?;
        get object(): string;
        set object(value: string);
        get objectInput(): string | undefined;
        private _writeOperationType?;
        get writeOperationType(): string;
        set writeOperationType(value: string);
        resetWriteOperationType(): void;
        get writeOperationTypeInput(): string | undefined;
        private _errorHandlingConfig;
        get errorHandlingConfig(): DestinationFlowConfigDestinationConnectorPropertiesSalesforceErrorHandlingConfigPropertyOutputReference;
        putErrorHandlingConfig(value: DestinationFlowConfigDestinationConnectorPropertiesSalesforceErrorHandlingConfigProperty): void;
        resetErrorHandlingConfig(): void;
        get errorHandlingConfigInput(): DestinationFlowConfigDestinationConnectorPropertiesSalesforceErrorHandlingConfigProperty | undefined;
    }
    interface DestinationFlowConfigDestinationConnectorPropertiesSapoDataErrorHandlingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_name AwsAppflowFlow#bucket_name}
        */
        readonly bucketName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_prefix AwsAppflowFlow#bucket_prefix}
        */
        readonly bucketPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#fail_on_first_destination_error AwsAppflowFlow#fail_on_first_destination_error}
        */
        readonly failOnFirstDestinationError?: boolean | cdktn.IResolvable;
    }
    class DestinationFlowConfigDestinationConnectorPropertiesSapoDataErrorHandlingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationFlowConfigDestinationConnectorPropertiesSapoDataErrorHandlingConfigProperty | undefined;
        set internalValue(value: DestinationFlowConfigDestinationConnectorPropertiesSapoDataErrorHandlingConfigProperty | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        resetBucketName(): void;
        get bucketNameInput(): string | undefined;
        private _bucketPrefix?;
        get bucketPrefix(): string;
        set bucketPrefix(value: string);
        resetBucketPrefix(): void;
        get bucketPrefixInput(): string | undefined;
        private _failOnFirstDestinationError?;
        get failOnFirstDestinationError(): boolean | cdktn.IResolvable;
        set failOnFirstDestinationError(value: boolean | cdktn.IResolvable);
        resetFailOnFirstDestinationError(): void;
        get failOnFirstDestinationErrorInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface SuccessResponseHandlingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_name AwsAppflowFlow#bucket_name}
        */
        readonly bucketName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_prefix AwsAppflowFlow#bucket_prefix}
        */
        readonly bucketPrefix?: string;
    }
    class SuccessResponseHandlingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SuccessResponseHandlingConfigProperty | undefined;
        set internalValue(value: SuccessResponseHandlingConfigProperty | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        resetBucketName(): void;
        get bucketNameInput(): string | undefined;
        private _bucketPrefix?;
        get bucketPrefix(): string;
        set bucketPrefix(value: string);
        resetBucketPrefix(): void;
        get bucketPrefixInput(): string | undefined;
    }
    interface DestinationFlowConfigDestinationConnectorPropertiesSapoDataProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#id_field_names AwsAppflowFlow#id_field_names}
        */
        readonly idFieldNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object_path AwsAppflowFlow#object_path}
        */
        readonly objectPath: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#write_operation_type AwsAppflowFlow#write_operation_type}
        */
        readonly writeOperationType?: string;
        /**
        * error_handling_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#error_handling_config AwsAppflowFlow#error_handling_config}
        */
        readonly errorHandlingConfig?: DestinationFlowConfigDestinationConnectorPropertiesSapoDataErrorHandlingConfigProperty;
        /**
        * success_response_handling_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#success_response_handling_config AwsAppflowFlow#success_response_handling_config}
        */
        readonly successResponseHandlingConfig?: SuccessResponseHandlingConfigProperty;
    }
    class DestinationFlowConfigDestinationConnectorPropertiesSapoDataPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationFlowConfigDestinationConnectorPropertiesSapoDataProperty | undefined;
        set internalValue(value: DestinationFlowConfigDestinationConnectorPropertiesSapoDataProperty | undefined);
        private _idFieldNames?;
        get idFieldNames(): string[];
        set idFieldNames(value: string[]);
        resetIdFieldNames(): void;
        get idFieldNamesInput(): string[] | undefined;
        private _objectPath?;
        get objectPath(): string;
        set objectPath(value: string);
        get objectPathInput(): string | undefined;
        private _writeOperationType?;
        get writeOperationType(): string;
        set writeOperationType(value: string);
        resetWriteOperationType(): void;
        get writeOperationTypeInput(): string | undefined;
        private _errorHandlingConfig;
        get errorHandlingConfig(): DestinationFlowConfigDestinationConnectorPropertiesSapoDataErrorHandlingConfigPropertyOutputReference;
        putErrorHandlingConfig(value: DestinationFlowConfigDestinationConnectorPropertiesSapoDataErrorHandlingConfigProperty): void;
        resetErrorHandlingConfig(): void;
        get errorHandlingConfigInput(): DestinationFlowConfigDestinationConnectorPropertiesSapoDataErrorHandlingConfigProperty | undefined;
        private _successResponseHandlingConfig;
        get successResponseHandlingConfig(): SuccessResponseHandlingConfigPropertyOutputReference;
        putSuccessResponseHandlingConfig(value: SuccessResponseHandlingConfigProperty): void;
        resetSuccessResponseHandlingConfig(): void;
        get successResponseHandlingConfigInput(): SuccessResponseHandlingConfigProperty | undefined;
    }
    interface DestinationFlowConfigDestinationConnectorPropertiesSnowflakeErrorHandlingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_name AwsAppflowFlow#bucket_name}
        */
        readonly bucketName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_prefix AwsAppflowFlow#bucket_prefix}
        */
        readonly bucketPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#fail_on_first_destination_error AwsAppflowFlow#fail_on_first_destination_error}
        */
        readonly failOnFirstDestinationError?: boolean | cdktn.IResolvable;
    }
    class DestinationFlowConfigDestinationConnectorPropertiesSnowflakeErrorHandlingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationFlowConfigDestinationConnectorPropertiesSnowflakeErrorHandlingConfigProperty | undefined;
        set internalValue(value: DestinationFlowConfigDestinationConnectorPropertiesSnowflakeErrorHandlingConfigProperty | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        resetBucketName(): void;
        get bucketNameInput(): string | undefined;
        private _bucketPrefix?;
        get bucketPrefix(): string;
        set bucketPrefix(value: string);
        resetBucketPrefix(): void;
        get bucketPrefixInput(): string | undefined;
        private _failOnFirstDestinationError?;
        get failOnFirstDestinationError(): boolean | cdktn.IResolvable;
        set failOnFirstDestinationError(value: boolean | cdktn.IResolvable);
        resetFailOnFirstDestinationError(): void;
        get failOnFirstDestinationErrorInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface SnowflakeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_prefix AwsAppflowFlow#bucket_prefix}
        */
        readonly bucketPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#intermediate_bucket_name AwsAppflowFlow#intermediate_bucket_name}
        */
        readonly intermediateBucketName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object AwsAppflowFlow#object}
        */
        readonly object: string;
        /**
        * error_handling_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#error_handling_config AwsAppflowFlow#error_handling_config}
        */
        readonly errorHandlingConfig?: DestinationFlowConfigDestinationConnectorPropertiesSnowflakeErrorHandlingConfigProperty;
    }
    class SnowflakePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SnowflakeProperty | undefined;
        set internalValue(value: SnowflakeProperty | undefined);
        private _bucketPrefix?;
        get bucketPrefix(): string;
        set bucketPrefix(value: string);
        resetBucketPrefix(): void;
        get bucketPrefixInput(): string | undefined;
        private _intermediateBucketName?;
        get intermediateBucketName(): string;
        set intermediateBucketName(value: string);
        get intermediateBucketNameInput(): string | undefined;
        private _object?;
        get object(): string;
        set object(value: string);
        get objectInput(): string | undefined;
        private _errorHandlingConfig;
        get errorHandlingConfig(): DestinationFlowConfigDestinationConnectorPropertiesSnowflakeErrorHandlingConfigPropertyOutputReference;
        putErrorHandlingConfig(value: DestinationFlowConfigDestinationConnectorPropertiesSnowflakeErrorHandlingConfigProperty): void;
        resetErrorHandlingConfig(): void;
        get errorHandlingConfigInput(): DestinationFlowConfigDestinationConnectorPropertiesSnowflakeErrorHandlingConfigProperty | undefined;
    }
    interface DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigAggregationConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#aggregation_type AwsAppflowFlow#aggregation_type}
        */
        readonly aggregationType?: string;
    }
    class DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigAggregationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigAggregationConfigProperty | undefined;
        set internalValue(value: DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigAggregationConfigProperty | undefined);
        private _aggregationType?;
        get aggregationType(): string;
        set aggregationType(value: string);
        resetAggregationType(): void;
        get aggregationTypeInput(): string | undefined;
    }
    interface DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPrefixConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#prefix_format AwsAppflowFlow#prefix_format}
        */
        readonly prefixFormat?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#prefix_hierarchy AwsAppflowFlow#prefix_hierarchy}
        */
        readonly prefixHierarchy?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#prefix_type AwsAppflowFlow#prefix_type}
        */
        readonly prefixType: string;
    }
    class DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPrefixConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPrefixConfigProperty | undefined;
        set internalValue(value: DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPrefixConfigProperty | undefined);
        private _prefixFormat?;
        get prefixFormat(): string;
        set prefixFormat(value: string);
        resetPrefixFormat(): void;
        get prefixFormatInput(): string | undefined;
        private _prefixHierarchy?;
        get prefixHierarchy(): string[];
        set prefixHierarchy(value: string[]);
        resetPrefixHierarchy(): void;
        get prefixHierarchyInput(): string[] | undefined;
        private _prefixType?;
        get prefixType(): string;
        set prefixType(value: string);
        get prefixTypeInput(): string | undefined;
    }
    interface DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#file_type AwsAppflowFlow#file_type}
        */
        readonly fileType?: string;
        /**
        * aggregation_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#aggregation_config AwsAppflowFlow#aggregation_config}
        */
        readonly aggregationConfig?: DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigAggregationConfigProperty;
        /**
        * prefix_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#prefix_config AwsAppflowFlow#prefix_config}
        */
        readonly prefixConfig: DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPrefixConfigProperty;
    }
    class DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigProperty | undefined;
        set internalValue(value: DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigProperty | undefined);
        private _fileType?;
        get fileType(): string;
        set fileType(value: string);
        resetFileType(): void;
        get fileTypeInput(): string | undefined;
        private _aggregationConfig;
        get aggregationConfig(): DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigAggregationConfigPropertyOutputReference;
        putAggregationConfig(value: DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigAggregationConfigProperty): void;
        resetAggregationConfig(): void;
        get aggregationConfigInput(): DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigAggregationConfigProperty | undefined;
        private _prefixConfig;
        get prefixConfig(): DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPrefixConfigPropertyOutputReference;
        putPrefixConfig(value: DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPrefixConfigProperty): void;
        get prefixConfigInput(): DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPrefixConfigProperty | undefined;
    }
    interface UpsolverProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_name AwsAppflowFlow#bucket_name}
        */
        readonly bucketName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_prefix AwsAppflowFlow#bucket_prefix}
        */
        readonly bucketPrefix?: string;
        /**
        * s3_output_format_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#s3_output_format_config AwsAppflowFlow#s3_output_format_config}
        */
        readonly s3OutputFormatConfig: DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigProperty;
    }
    class UpsolverPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UpsolverProperty | undefined;
        set internalValue(value: UpsolverProperty | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        get bucketNameInput(): string | undefined;
        private _bucketPrefix?;
        get bucketPrefix(): string;
        set bucketPrefix(value: string);
        resetBucketPrefix(): void;
        get bucketPrefixInput(): string | undefined;
        private _s3OutputFormatConfig;
        get s3OutputFormatConfig(): DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPropertyOutputReference;
        putS3OutputFormatConfig(value: DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigProperty): void;
        get s3OutputFormatConfigInput(): DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigProperty | undefined;
    }
    interface DestinationFlowConfigDestinationConnectorPropertiesZendeskErrorHandlingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_name AwsAppflowFlow#bucket_name}
        */
        readonly bucketName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_prefix AwsAppflowFlow#bucket_prefix}
        */
        readonly bucketPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#fail_on_first_destination_error AwsAppflowFlow#fail_on_first_destination_error}
        */
        readonly failOnFirstDestinationError?: boolean | cdktn.IResolvable;
    }
    class DestinationFlowConfigDestinationConnectorPropertiesZendeskErrorHandlingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationFlowConfigDestinationConnectorPropertiesZendeskErrorHandlingConfigProperty | undefined;
        set internalValue(value: DestinationFlowConfigDestinationConnectorPropertiesZendeskErrorHandlingConfigProperty | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        resetBucketName(): void;
        get bucketNameInput(): string | undefined;
        private _bucketPrefix?;
        get bucketPrefix(): string;
        set bucketPrefix(value: string);
        resetBucketPrefix(): void;
        get bucketPrefixInput(): string | undefined;
        private _failOnFirstDestinationError?;
        get failOnFirstDestinationError(): boolean | cdktn.IResolvable;
        set failOnFirstDestinationError(value: boolean | cdktn.IResolvable);
        resetFailOnFirstDestinationError(): void;
        get failOnFirstDestinationErrorInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface DestinationFlowConfigDestinationConnectorPropertiesZendeskProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#id_field_names AwsAppflowFlow#id_field_names}
        */
        readonly idFieldNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object AwsAppflowFlow#object}
        */
        readonly object: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#write_operation_type AwsAppflowFlow#write_operation_type}
        */
        readonly writeOperationType?: string;
        /**
        * error_handling_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#error_handling_config AwsAppflowFlow#error_handling_config}
        */
        readonly errorHandlingConfig?: DestinationFlowConfigDestinationConnectorPropertiesZendeskErrorHandlingConfigProperty;
    }
    class DestinationFlowConfigDestinationConnectorPropertiesZendeskPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationFlowConfigDestinationConnectorPropertiesZendeskProperty | undefined;
        set internalValue(value: DestinationFlowConfigDestinationConnectorPropertiesZendeskProperty | undefined);
        private _idFieldNames?;
        get idFieldNames(): string[];
        set idFieldNames(value: string[]);
        resetIdFieldNames(): void;
        get idFieldNamesInput(): string[] | undefined;
        private _object?;
        get object(): string;
        set object(value: string);
        get objectInput(): string | undefined;
        private _writeOperationType?;
        get writeOperationType(): string;
        set writeOperationType(value: string);
        resetWriteOperationType(): void;
        get writeOperationTypeInput(): string | undefined;
        private _errorHandlingConfig;
        get errorHandlingConfig(): DestinationFlowConfigDestinationConnectorPropertiesZendeskErrorHandlingConfigPropertyOutputReference;
        putErrorHandlingConfig(value: DestinationFlowConfigDestinationConnectorPropertiesZendeskErrorHandlingConfigProperty): void;
        resetErrorHandlingConfig(): void;
        get errorHandlingConfigInput(): DestinationFlowConfigDestinationConnectorPropertiesZendeskErrorHandlingConfigProperty | undefined;
    }
    interface DestinationConnectorPropertiesProperty {
        /**
        * custom_connector block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#custom_connector AwsAppflowFlow#custom_connector}
        */
        readonly customConnector?: DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorProperty;
        /**
        * customer_profiles block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#customer_profiles AwsAppflowFlow#customer_profiles}
        */
        readonly customerProfiles?: CustomerProfilesProperty;
        /**
        * event_bridge block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#event_bridge AwsAppflowFlow#event_bridge}
        */
        readonly eventBridge?: EventBridgeProperty;
        /**
        * honeycode block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#honeycode AwsAppflowFlow#honeycode}
        */
        readonly honeycode?: HoneycodeProperty;
        /**
        * lookout_metrics block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#lookout_metrics AwsAppflowFlow#lookout_metrics}
        */
        readonly lookoutMetrics?: LookoutMetricsProperty;
        /**
        * marketo block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#marketo AwsAppflowFlow#marketo}
        */
        readonly marketo?: DestinationFlowConfigDestinationConnectorPropertiesMarketoProperty;
        /**
        * redshift block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#redshift AwsAppflowFlow#redshift}
        */
        readonly redshift?: RedshiftProperty;
        /**
        * s3 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#s3 AwsAppflowFlow#s3}
        */
        readonly s3?: DestinationFlowConfigDestinationConnectorPropertiesS3Property;
        /**
        * salesforce block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#salesforce AwsAppflowFlow#salesforce}
        */
        readonly salesforce?: DestinationFlowConfigDestinationConnectorPropertiesSalesforceProperty;
        /**
        * sapo_data block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#sapo_data AwsAppflowFlow#sapo_data}
        */
        readonly sapoData?: DestinationFlowConfigDestinationConnectorPropertiesSapoDataProperty;
        /**
        * snowflake block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#snowflake AwsAppflowFlow#snowflake}
        */
        readonly snowflake?: SnowflakeProperty;
        /**
        * upsolver block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#upsolver AwsAppflowFlow#upsolver}
        */
        readonly upsolver?: UpsolverProperty;
        /**
        * zendesk block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#zendesk AwsAppflowFlow#zendesk}
        */
        readonly zendesk?: DestinationFlowConfigDestinationConnectorPropertiesZendeskProperty;
    }
    class DestinationConnectorPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationConnectorPropertiesProperty | undefined;
        set internalValue(value: DestinationConnectorPropertiesProperty | undefined);
        private _customConnector;
        get customConnector(): DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorPropertyOutputReference;
        putCustomConnector(value: DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorProperty): void;
        resetCustomConnector(): void;
        get customConnectorInput(): DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorProperty | undefined;
        private _customerProfiles;
        get customerProfiles(): CustomerProfilesPropertyOutputReference;
        putCustomerProfiles(value: CustomerProfilesProperty): void;
        resetCustomerProfiles(): void;
        get customerProfilesInput(): CustomerProfilesProperty | undefined;
        private _eventBridge;
        get eventBridge(): EventBridgePropertyOutputReference;
        putEventBridge(value: EventBridgeProperty): void;
        resetEventBridge(): void;
        get eventBridgeInput(): EventBridgeProperty | undefined;
        private _honeycode;
        get honeycode(): HoneycodePropertyOutputReference;
        putHoneycode(value: HoneycodeProperty): void;
        resetHoneycode(): void;
        get honeycodeInput(): HoneycodeProperty | undefined;
        private _lookoutMetrics;
        get lookoutMetrics(): LookoutMetricsPropertyOutputReference;
        putLookoutMetrics(value: LookoutMetricsProperty): void;
        resetLookoutMetrics(): void;
        get lookoutMetricsInput(): LookoutMetricsProperty | undefined;
        private _marketo;
        get marketo(): DestinationFlowConfigDestinationConnectorPropertiesMarketoPropertyOutputReference;
        putMarketo(value: DestinationFlowConfigDestinationConnectorPropertiesMarketoProperty): void;
        resetMarketo(): void;
        get marketoInput(): DestinationFlowConfigDestinationConnectorPropertiesMarketoProperty | undefined;
        private _redshift;
        get redshift(): RedshiftPropertyOutputReference;
        putRedshift(value: RedshiftProperty): void;
        resetRedshift(): void;
        get redshiftInput(): RedshiftProperty | undefined;
        private _s3;
        get s3(): DestinationFlowConfigDestinationConnectorPropertiesS3PropertyOutputReference;
        putS3(value: DestinationFlowConfigDestinationConnectorPropertiesS3Property): void;
        resetS3(): void;
        get s3Input(): DestinationFlowConfigDestinationConnectorPropertiesS3Property | undefined;
        private _salesforce;
        get salesforce(): DestinationFlowConfigDestinationConnectorPropertiesSalesforcePropertyOutputReference;
        putSalesforce(value: DestinationFlowConfigDestinationConnectorPropertiesSalesforceProperty): void;
        resetSalesforce(): void;
        get salesforceInput(): DestinationFlowConfigDestinationConnectorPropertiesSalesforceProperty | undefined;
        private _sapoData;
        get sapoData(): DestinationFlowConfigDestinationConnectorPropertiesSapoDataPropertyOutputReference;
        putSapoData(value: DestinationFlowConfigDestinationConnectorPropertiesSapoDataProperty): void;
        resetSapoData(): void;
        get sapoDataInput(): DestinationFlowConfigDestinationConnectorPropertiesSapoDataProperty | undefined;
        private _snowflake;
        get snowflake(): SnowflakePropertyOutputReference;
        putSnowflake(value: SnowflakeProperty): void;
        resetSnowflake(): void;
        get snowflakeInput(): SnowflakeProperty | undefined;
        private _upsolver;
        get upsolver(): UpsolverPropertyOutputReference;
        putUpsolver(value: UpsolverProperty): void;
        resetUpsolver(): void;
        get upsolverInput(): UpsolverProperty | undefined;
        private _zendesk;
        get zendesk(): DestinationFlowConfigDestinationConnectorPropertiesZendeskPropertyOutputReference;
        putZendesk(value: DestinationFlowConfigDestinationConnectorPropertiesZendeskProperty): void;
        resetZendesk(): void;
        get zendeskInput(): DestinationFlowConfigDestinationConnectorPropertiesZendeskProperty | undefined;
    }
    interface DestinationFlowConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#api_version AwsAppflowFlow#api_version}
        */
        readonly apiVersion?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#connector_profile_name AwsAppflowFlow#connector_profile_name}
        */
        readonly connectorProfileName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#connector_type AwsAppflowFlow#connector_type}
        */
        readonly connectorType: string;
        /**
        * destination_connector_properties block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#destination_connector_properties AwsAppflowFlow#destination_connector_properties}
        */
        readonly destinationConnectorProperties: DestinationConnectorPropertiesProperty;
    }
    class DestinationFlowConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DestinationFlowConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DestinationFlowConfigProperty | cdktn.IResolvable | undefined);
        private _apiVersion?;
        get apiVersion(): string;
        set apiVersion(value: string);
        resetApiVersion(): void;
        get apiVersionInput(): string | undefined;
        private _connectorProfileName?;
        get connectorProfileName(): string;
        set connectorProfileName(value: string);
        resetConnectorProfileName(): void;
        get connectorProfileNameInput(): string | undefined;
        private _connectorType?;
        get connectorType(): string;
        set connectorType(value: string);
        get connectorTypeInput(): string | undefined;
        private _destinationConnectorProperties;
        get destinationConnectorProperties(): DestinationConnectorPropertiesPropertyOutputReference;
        putDestinationConnectorProperties(value: DestinationConnectorPropertiesProperty): void;
        get destinationConnectorPropertiesInput(): DestinationConnectorPropertiesProperty | undefined;
    }
    class DestinationFlowConfigPropertyList extends cdktn.ComplexList {
        internalValue?: DestinationFlowConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DestinationFlowConfigPropertyOutputReference;
    }
    interface GlueDataCatalogProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#database_name AwsAppflowFlow#database_name}
        */
        readonly databaseName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#role_arn AwsAppflowFlow#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#table_prefix AwsAppflowFlow#table_prefix}
        */
        readonly tablePrefix: string;
    }
    class GlueDataCatalogPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): GlueDataCatalogProperty | undefined;
        set internalValue(value: GlueDataCatalogProperty | undefined);
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        get databaseNameInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _tablePrefix?;
        get tablePrefix(): string;
        set tablePrefix(value: string);
        get tablePrefixInput(): string | undefined;
    }
    interface MetadataCatalogConfigProperty {
        /**
        * glue_data_catalog block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#glue_data_catalog AwsAppflowFlow#glue_data_catalog}
        */
        readonly glueDataCatalog?: GlueDataCatalogProperty;
    }
    class MetadataCatalogConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MetadataCatalogConfigProperty | undefined;
        set internalValue(value: MetadataCatalogConfigProperty | undefined);
        private _glueDataCatalog;
        get glueDataCatalog(): GlueDataCatalogPropertyOutputReference;
        putGlueDataCatalog(value: GlueDataCatalogProperty): void;
        resetGlueDataCatalog(): void;
        get glueDataCatalogInput(): GlueDataCatalogProperty | undefined;
    }
    interface IncrementalPullConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#datetime_type_field_name AwsAppflowFlow#datetime_type_field_name}
        */
        readonly datetimeTypeFieldName?: string;
    }
    class IncrementalPullConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IncrementalPullConfigProperty | undefined;
        set internalValue(value: IncrementalPullConfigProperty | undefined);
        private _datetimeTypeFieldName?;
        get datetimeTypeFieldName(): string;
        set datetimeTypeFieldName(value: string);
        resetDatetimeTypeFieldName(): void;
        get datetimeTypeFieldNameInput(): string | undefined;
    }
    interface AmplitudeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object AwsAppflowFlow#object}
        */
        readonly object: string;
    }
    class AmplitudePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AmplitudeProperty | undefined;
        set internalValue(value: AmplitudeProperty | undefined);
        private _object?;
        get object(): string;
        set object(value: string);
        get objectInput(): string | undefined;
    }
    interface SourceFlowConfigSourceConnectorPropertiesCustomConnectorProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#custom_properties AwsAppflowFlow#custom_properties}
        */
        readonly customProperties?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#entity_name AwsAppflowFlow#entity_name}
        */
        readonly entityName: string;
    }
    class SourceFlowConfigSourceConnectorPropertiesCustomConnectorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceFlowConfigSourceConnectorPropertiesCustomConnectorProperty | undefined;
        set internalValue(value: SourceFlowConfigSourceConnectorPropertiesCustomConnectorProperty | undefined);
        private _customProperties?;
        get customProperties(): {
            [key: string]: string;
        };
        set customProperties(value: {
            [key: string]: string;
        });
        resetCustomProperties(): void;
        get customPropertiesInput(): {
            [key: string]: string;
        } | undefined;
        private _entityName?;
        get entityName(): string;
        set entityName(value: string);
        get entityNameInput(): string | undefined;
    }
    interface DatadogProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object AwsAppflowFlow#object}
        */
        readonly object: string;
    }
    class DatadogPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DatadogProperty | undefined;
        set internalValue(value: DatadogProperty | undefined);
        private _object?;
        get object(): string;
        set object(value: string);
        get objectInput(): string | undefined;
    }
    interface DynatraceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object AwsAppflowFlow#object}
        */
        readonly object: string;
    }
    class DynatracePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DynatraceProperty | undefined;
        set internalValue(value: DynatraceProperty | undefined);
        private _object?;
        get object(): string;
        set object(value: string);
        get objectInput(): string | undefined;
    }
    interface GoogleAnalyticsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object AwsAppflowFlow#object}
        */
        readonly object: string;
    }
    class GoogleAnalyticsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): GoogleAnalyticsProperty | undefined;
        set internalValue(value: GoogleAnalyticsProperty | undefined);
        private _object?;
        get object(): string;
        set object(value: string);
        get objectInput(): string | undefined;
    }
    interface InforNexusProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object AwsAppflowFlow#object}
        */
        readonly object: string;
    }
    class InforNexusPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InforNexusProperty | undefined;
        set internalValue(value: InforNexusProperty | undefined);
        private _object?;
        get object(): string;
        set object(value: string);
        get objectInput(): string | undefined;
    }
    interface SourceFlowConfigSourceConnectorPropertiesMarketoProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object AwsAppflowFlow#object}
        */
        readonly object: string;
    }
    class SourceFlowConfigSourceConnectorPropertiesMarketoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceFlowConfigSourceConnectorPropertiesMarketoProperty | undefined;
        set internalValue(value: SourceFlowConfigSourceConnectorPropertiesMarketoProperty | undefined);
        private _object?;
        get object(): string;
        set object(value: string);
        get objectInput(): string | undefined;
    }
    interface S3InputFormatConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#s3_input_file_type AwsAppflowFlow#s3_input_file_type}
        */
        readonly s3InputFileType?: string;
    }
    class S3InputFormatConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3InputFormatConfigProperty | undefined;
        set internalValue(value: S3InputFormatConfigProperty | undefined);
        private _s3InputFileType?;
        get s3InputFileType(): string;
        set s3InputFileType(value: string);
        resetS3InputFileType(): void;
        get s3InputFileTypeInput(): string | undefined;
    }
    interface SourceFlowConfigSourceConnectorPropertiesS3Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_name AwsAppflowFlow#bucket_name}
        */
        readonly bucketName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_prefix AwsAppflowFlow#bucket_prefix}
        */
        readonly bucketPrefix: string;
        /**
        * s3_input_format_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#s3_input_format_config AwsAppflowFlow#s3_input_format_config}
        */
        readonly s3InputFormatConfig?: S3InputFormatConfigProperty;
    }
    class SourceFlowConfigSourceConnectorPropertiesS3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceFlowConfigSourceConnectorPropertiesS3Property | undefined;
        set internalValue(value: SourceFlowConfigSourceConnectorPropertiesS3Property | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        get bucketNameInput(): string | undefined;
        private _bucketPrefix?;
        get bucketPrefix(): string;
        set bucketPrefix(value: string);
        get bucketPrefixInput(): string | undefined;
        private _s3InputFormatConfig;
        get s3InputFormatConfig(): S3InputFormatConfigPropertyOutputReference;
        putS3InputFormatConfig(value: S3InputFormatConfigProperty): void;
        resetS3InputFormatConfig(): void;
        get s3InputFormatConfigInput(): S3InputFormatConfigProperty | undefined;
    }
    interface SourceFlowConfigSourceConnectorPropertiesSalesforceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#data_transfer_api AwsAppflowFlow#data_transfer_api}
        */
        readonly dataTransferApi?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#enable_dynamic_field_update AwsAppflowFlow#enable_dynamic_field_update}
        */
        readonly enableDynamicFieldUpdate?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#include_deleted_records AwsAppflowFlow#include_deleted_records}
        */
        readonly includeDeletedRecords?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object AwsAppflowFlow#object}
        */
        readonly object: string;
    }
    class SourceFlowConfigSourceConnectorPropertiesSalesforcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceFlowConfigSourceConnectorPropertiesSalesforceProperty | undefined;
        set internalValue(value: SourceFlowConfigSourceConnectorPropertiesSalesforceProperty | undefined);
        private _dataTransferApi?;
        get dataTransferApi(): string;
        set dataTransferApi(value: string);
        resetDataTransferApi(): void;
        get dataTransferApiInput(): string | undefined;
        private _enableDynamicFieldUpdate?;
        get enableDynamicFieldUpdate(): boolean | cdktn.IResolvable;
        set enableDynamicFieldUpdate(value: boolean | cdktn.IResolvable);
        resetEnableDynamicFieldUpdate(): void;
        get enableDynamicFieldUpdateInput(): boolean | cdktn.IResolvable | undefined;
        private _includeDeletedRecords?;
        get includeDeletedRecords(): boolean | cdktn.IResolvable;
        set includeDeletedRecords(value: boolean | cdktn.IResolvable);
        resetIncludeDeletedRecords(): void;
        get includeDeletedRecordsInput(): boolean | cdktn.IResolvable | undefined;
        private _object?;
        get object(): string;
        set object(value: string);
        get objectInput(): string | undefined;
    }
    interface PaginationConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#max_page_size AwsAppflowFlow#max_page_size}
        */
        readonly maxPageSize: number;
    }
    class PaginationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PaginationConfigProperty | undefined;
        set internalValue(value: PaginationConfigProperty | undefined);
        private _maxPageSize?;
        get maxPageSize(): number;
        set maxPageSize(value: number);
        get maxPageSizeInput(): number | undefined;
    }
    interface ParallelismConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#max_page_size AwsAppflowFlow#max_page_size}
        */
        readonly maxPageSize: number;
    }
    class ParallelismConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ParallelismConfigProperty | undefined;
        set internalValue(value: ParallelismConfigProperty | undefined);
        private _maxPageSize?;
        get maxPageSize(): number;
        set maxPageSize(value: number);
        get maxPageSizeInput(): number | undefined;
    }
    interface SourceFlowConfigSourceConnectorPropertiesSapoDataProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object_path AwsAppflowFlow#object_path}
        */
        readonly objectPath: string;
        /**
        * pagination_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#pagination_config AwsAppflowFlow#pagination_config}
        */
        readonly paginationConfig?: PaginationConfigProperty;
        /**
        * parallelism_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#parallelism_config AwsAppflowFlow#parallelism_config}
        */
        readonly parallelismConfig?: ParallelismConfigProperty;
    }
    class SourceFlowConfigSourceConnectorPropertiesSapoDataPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceFlowConfigSourceConnectorPropertiesSapoDataProperty | undefined;
        set internalValue(value: SourceFlowConfigSourceConnectorPropertiesSapoDataProperty | undefined);
        private _objectPath?;
        get objectPath(): string;
        set objectPath(value: string);
        get objectPathInput(): string | undefined;
        private _paginationConfig;
        get paginationConfig(): PaginationConfigPropertyOutputReference;
        putPaginationConfig(value: PaginationConfigProperty): void;
        resetPaginationConfig(): void;
        get paginationConfigInput(): PaginationConfigProperty | undefined;
        private _parallelismConfig;
        get parallelismConfig(): ParallelismConfigPropertyOutputReference;
        putParallelismConfig(value: ParallelismConfigProperty): void;
        resetParallelismConfig(): void;
        get parallelismConfigInput(): ParallelismConfigProperty | undefined;
    }
    interface ServiceNowProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object AwsAppflowFlow#object}
        */
        readonly object: string;
    }
    class ServiceNowPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ServiceNowProperty | undefined;
        set internalValue(value: ServiceNowProperty | undefined);
        private _object?;
        get object(): string;
        set object(value: string);
        get objectInput(): string | undefined;
    }
    interface SingularProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object AwsAppflowFlow#object}
        */
        readonly object: string;
    }
    class SingularPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SingularProperty | undefined;
        set internalValue(value: SingularProperty | undefined);
        private _object?;
        get object(): string;
        set object(value: string);
        get objectInput(): string | undefined;
    }
    interface SlackProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object AwsAppflowFlow#object}
        */
        readonly object: string;
    }
    class SlackPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SlackProperty | undefined;
        set internalValue(value: SlackProperty | undefined);
        private _object?;
        get object(): string;
        set object(value: string);
        get objectInput(): string | undefined;
    }
    interface TrendmicroProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object AwsAppflowFlow#object}
        */
        readonly object: string;
    }
    class TrendmicroPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TrendmicroProperty | undefined;
        set internalValue(value: TrendmicroProperty | undefined);
        private _object?;
        get object(): string;
        set object(value: string);
        get objectInput(): string | undefined;
    }
    interface VeevaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#document_type AwsAppflowFlow#document_type}
        */
        readonly documentType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#include_all_versions AwsAppflowFlow#include_all_versions}
        */
        readonly includeAllVersions?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#include_renditions AwsAppflowFlow#include_renditions}
        */
        readonly includeRenditions?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#include_source_files AwsAppflowFlow#include_source_files}
        */
        readonly includeSourceFiles?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object AwsAppflowFlow#object}
        */
        readonly object: string;
    }
    class VeevaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VeevaProperty | undefined;
        set internalValue(value: VeevaProperty | undefined);
        private _documentType?;
        get documentType(): string;
        set documentType(value: string);
        resetDocumentType(): void;
        get documentTypeInput(): string | undefined;
        private _includeAllVersions?;
        get includeAllVersions(): boolean | cdktn.IResolvable;
        set includeAllVersions(value: boolean | cdktn.IResolvable);
        resetIncludeAllVersions(): void;
        get includeAllVersionsInput(): boolean | cdktn.IResolvable | undefined;
        private _includeRenditions?;
        get includeRenditions(): boolean | cdktn.IResolvable;
        set includeRenditions(value: boolean | cdktn.IResolvable);
        resetIncludeRenditions(): void;
        get includeRenditionsInput(): boolean | cdktn.IResolvable | undefined;
        private _includeSourceFiles?;
        get includeSourceFiles(): boolean | cdktn.IResolvable;
        set includeSourceFiles(value: boolean | cdktn.IResolvable);
        resetIncludeSourceFiles(): void;
        get includeSourceFilesInput(): boolean | cdktn.IResolvable | undefined;
        private _object?;
        get object(): string;
        set object(value: string);
        get objectInput(): string | undefined;
    }
    interface SourceFlowConfigSourceConnectorPropertiesZendeskProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object AwsAppflowFlow#object}
        */
        readonly object: string;
    }
    class SourceFlowConfigSourceConnectorPropertiesZendeskPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceFlowConfigSourceConnectorPropertiesZendeskProperty | undefined;
        set internalValue(value: SourceFlowConfigSourceConnectorPropertiesZendeskProperty | undefined);
        private _object?;
        get object(): string;
        set object(value: string);
        get objectInput(): string | undefined;
    }
    interface SourceConnectorPropertiesProperty {
        /**
        * amplitude block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#amplitude AwsAppflowFlow#amplitude}
        */
        readonly amplitude?: AmplitudeProperty;
        /**
        * custom_connector block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#custom_connector AwsAppflowFlow#custom_connector}
        */
        readonly customConnector?: SourceFlowConfigSourceConnectorPropertiesCustomConnectorProperty;
        /**
        * datadog block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#datadog AwsAppflowFlow#datadog}
        */
        readonly datadog?: DatadogProperty;
        /**
        * dynatrace block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#dynatrace AwsAppflowFlow#dynatrace}
        */
        readonly dynatrace?: DynatraceProperty;
        /**
        * google_analytics block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#google_analytics AwsAppflowFlow#google_analytics}
        */
        readonly googleAnalytics?: GoogleAnalyticsProperty;
        /**
        * infor_nexus block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#infor_nexus AwsAppflowFlow#infor_nexus}
        */
        readonly inforNexus?: InforNexusProperty;
        /**
        * marketo block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#marketo AwsAppflowFlow#marketo}
        */
        readonly marketo?: SourceFlowConfigSourceConnectorPropertiesMarketoProperty;
        /**
        * s3 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#s3 AwsAppflowFlow#s3}
        */
        readonly s3?: SourceFlowConfigSourceConnectorPropertiesS3Property;
        /**
        * salesforce block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#salesforce AwsAppflowFlow#salesforce}
        */
        readonly salesforce?: SourceFlowConfigSourceConnectorPropertiesSalesforceProperty;
        /**
        * sapo_data block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#sapo_data AwsAppflowFlow#sapo_data}
        */
        readonly sapoData?: SourceFlowConfigSourceConnectorPropertiesSapoDataProperty;
        /**
        * service_now block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#service_now AwsAppflowFlow#service_now}
        */
        readonly serviceNow?: ServiceNowProperty;
        /**
        * singular block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#singular AwsAppflowFlow#singular}
        */
        readonly singular?: SingularProperty;
        /**
        * slack block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#slack AwsAppflowFlow#slack}
        */
        readonly slack?: SlackProperty;
        /**
        * trendmicro block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#trendmicro AwsAppflowFlow#trendmicro}
        */
        readonly trendmicro?: TrendmicroProperty;
        /**
        * veeva block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#veeva AwsAppflowFlow#veeva}
        */
        readonly veeva?: VeevaProperty;
        /**
        * zendesk block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#zendesk AwsAppflowFlow#zendesk}
        */
        readonly zendesk?: SourceFlowConfigSourceConnectorPropertiesZendeskProperty;
    }
    class SourceConnectorPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceConnectorPropertiesProperty | undefined;
        set internalValue(value: SourceConnectorPropertiesProperty | undefined);
        private _amplitude;
        get amplitude(): AmplitudePropertyOutputReference;
        putAmplitude(value: AmplitudeProperty): void;
        resetAmplitude(): void;
        get amplitudeInput(): AmplitudeProperty | undefined;
        private _customConnector;
        get customConnector(): SourceFlowConfigSourceConnectorPropertiesCustomConnectorPropertyOutputReference;
        putCustomConnector(value: SourceFlowConfigSourceConnectorPropertiesCustomConnectorProperty): void;
        resetCustomConnector(): void;
        get customConnectorInput(): SourceFlowConfigSourceConnectorPropertiesCustomConnectorProperty | undefined;
        private _datadog;
        get datadog(): DatadogPropertyOutputReference;
        putDatadog(value: DatadogProperty): void;
        resetDatadog(): void;
        get datadogInput(): DatadogProperty | undefined;
        private _dynatrace;
        get dynatrace(): DynatracePropertyOutputReference;
        putDynatrace(value: DynatraceProperty): void;
        resetDynatrace(): void;
        get dynatraceInput(): DynatraceProperty | undefined;
        private _googleAnalytics;
        get googleAnalytics(): GoogleAnalyticsPropertyOutputReference;
        putGoogleAnalytics(value: GoogleAnalyticsProperty): void;
        resetGoogleAnalytics(): void;
        get googleAnalyticsInput(): GoogleAnalyticsProperty | undefined;
        private _inforNexus;
        get inforNexus(): InforNexusPropertyOutputReference;
        putInforNexus(value: InforNexusProperty): void;
        resetInforNexus(): void;
        get inforNexusInput(): InforNexusProperty | undefined;
        private _marketo;
        get marketo(): SourceFlowConfigSourceConnectorPropertiesMarketoPropertyOutputReference;
        putMarketo(value: SourceFlowConfigSourceConnectorPropertiesMarketoProperty): void;
        resetMarketo(): void;
        get marketoInput(): SourceFlowConfigSourceConnectorPropertiesMarketoProperty | undefined;
        private _s3;
        get s3(): SourceFlowConfigSourceConnectorPropertiesS3PropertyOutputReference;
        putS3(value: SourceFlowConfigSourceConnectorPropertiesS3Property): void;
        resetS3(): void;
        get s3Input(): SourceFlowConfigSourceConnectorPropertiesS3Property | undefined;
        private _salesforce;
        get salesforce(): SourceFlowConfigSourceConnectorPropertiesSalesforcePropertyOutputReference;
        putSalesforce(value: SourceFlowConfigSourceConnectorPropertiesSalesforceProperty): void;
        resetSalesforce(): void;
        get salesforceInput(): SourceFlowConfigSourceConnectorPropertiesSalesforceProperty | undefined;
        private _sapoData;
        get sapoData(): SourceFlowConfigSourceConnectorPropertiesSapoDataPropertyOutputReference;
        putSapoData(value: SourceFlowConfigSourceConnectorPropertiesSapoDataProperty): void;
        resetSapoData(): void;
        get sapoDataInput(): SourceFlowConfigSourceConnectorPropertiesSapoDataProperty | undefined;
        private _serviceNow;
        get serviceNow(): ServiceNowPropertyOutputReference;
        putServiceNow(value: ServiceNowProperty): void;
        resetServiceNow(): void;
        get serviceNowInput(): ServiceNowProperty | undefined;
        private _singular;
        get singular(): SingularPropertyOutputReference;
        putSingular(value: SingularProperty): void;
        resetSingular(): void;
        get singularInput(): SingularProperty | undefined;
        private _slack;
        get slack(): SlackPropertyOutputReference;
        putSlack(value: SlackProperty): void;
        resetSlack(): void;
        get slackInput(): SlackProperty | undefined;
        private _trendmicro;
        get trendmicro(): TrendmicroPropertyOutputReference;
        putTrendmicro(value: TrendmicroProperty): void;
        resetTrendmicro(): void;
        get trendmicroInput(): TrendmicroProperty | undefined;
        private _veeva;
        get veeva(): VeevaPropertyOutputReference;
        putVeeva(value: VeevaProperty): void;
        resetVeeva(): void;
        get veevaInput(): VeevaProperty | undefined;
        private _zendesk;
        get zendesk(): SourceFlowConfigSourceConnectorPropertiesZendeskPropertyOutputReference;
        putZendesk(value: SourceFlowConfigSourceConnectorPropertiesZendeskProperty): void;
        resetZendesk(): void;
        get zendeskInput(): SourceFlowConfigSourceConnectorPropertiesZendeskProperty | undefined;
    }
    interface SourceFlowConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#api_version AwsAppflowFlow#api_version}
        */
        readonly apiVersion?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#connector_profile_name AwsAppflowFlow#connector_profile_name}
        */
        readonly connectorProfileName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#connector_type AwsAppflowFlow#connector_type}
        */
        readonly connectorType: string;
        /**
        * incremental_pull_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#incremental_pull_config AwsAppflowFlow#incremental_pull_config}
        */
        readonly incrementalPullConfig?: IncrementalPullConfigProperty;
        /**
        * source_connector_properties block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#source_connector_properties AwsAppflowFlow#source_connector_properties}
        */
        readonly sourceConnectorProperties: SourceConnectorPropertiesProperty;
    }
    class SourceFlowConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceFlowConfigProperty | undefined;
        set internalValue(value: SourceFlowConfigProperty | undefined);
        private _apiVersion?;
        get apiVersion(): string;
        set apiVersion(value: string);
        resetApiVersion(): void;
        get apiVersionInput(): string | undefined;
        private _connectorProfileName?;
        get connectorProfileName(): string;
        set connectorProfileName(value: string);
        resetConnectorProfileName(): void;
        get connectorProfileNameInput(): string | undefined;
        private _connectorType?;
        get connectorType(): string;
        set connectorType(value: string);
        get connectorTypeInput(): string | undefined;
        private _incrementalPullConfig;
        get incrementalPullConfig(): IncrementalPullConfigPropertyOutputReference;
        putIncrementalPullConfig(value: IncrementalPullConfigProperty): void;
        resetIncrementalPullConfig(): void;
        get incrementalPullConfigInput(): IncrementalPullConfigProperty | undefined;
        private _sourceConnectorProperties;
        get sourceConnectorProperties(): SourceConnectorPropertiesPropertyOutputReference;
        putSourceConnectorProperties(value: SourceConnectorPropertiesProperty): void;
        get sourceConnectorPropertiesInput(): SourceConnectorPropertiesProperty | undefined;
    }
    interface ConnectorOperatorProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#amplitude AwsAppflowFlow#amplitude}
        */
        readonly amplitude?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#custom_connector AwsAppflowFlow#custom_connector}
        */
        readonly customConnector?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#datadog AwsAppflowFlow#datadog}
        */
        readonly datadog?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#dynatrace AwsAppflowFlow#dynatrace}
        */
        readonly dynatrace?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#google_analytics AwsAppflowFlow#google_analytics}
        */
        readonly googleAnalytics?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#infor_nexus AwsAppflowFlow#infor_nexus}
        */
        readonly inforNexus?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#marketo AwsAppflowFlow#marketo}
        */
        readonly marketo?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#s3 AwsAppflowFlow#s3}
        */
        readonly s3?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#salesforce AwsAppflowFlow#salesforce}
        */
        readonly salesforce?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#sapo_data AwsAppflowFlow#sapo_data}
        */
        readonly sapoData?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#service_now AwsAppflowFlow#service_now}
        */
        readonly serviceNow?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#singular AwsAppflowFlow#singular}
        */
        readonly singular?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#slack AwsAppflowFlow#slack}
        */
        readonly slack?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#trendmicro AwsAppflowFlow#trendmicro}
        */
        readonly trendmicro?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#veeva AwsAppflowFlow#veeva}
        */
        readonly veeva?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#zendesk AwsAppflowFlow#zendesk}
        */
        readonly zendesk?: string;
    }
    class ConnectorOperatorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConnectorOperatorProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConnectorOperatorProperty | cdktn.IResolvable | undefined);
        private _amplitude?;
        get amplitude(): string;
        set amplitude(value: string);
        resetAmplitude(): void;
        get amplitudeInput(): string | undefined;
        private _customConnector?;
        get customConnector(): string;
        set customConnector(value: string);
        resetCustomConnector(): void;
        get customConnectorInput(): string | undefined;
        private _datadog?;
        get datadog(): string;
        set datadog(value: string);
        resetDatadog(): void;
        get datadogInput(): string | undefined;
        private _dynatrace?;
        get dynatrace(): string;
        set dynatrace(value: string);
        resetDynatrace(): void;
        get dynatraceInput(): string | undefined;
        private _googleAnalytics?;
        get googleAnalytics(): string;
        set googleAnalytics(value: string);
        resetGoogleAnalytics(): void;
        get googleAnalyticsInput(): string | undefined;
        private _inforNexus?;
        get inforNexus(): string;
        set inforNexus(value: string);
        resetInforNexus(): void;
        get inforNexusInput(): string | undefined;
        private _marketo?;
        get marketo(): string;
        set marketo(value: string);
        resetMarketo(): void;
        get marketoInput(): string | undefined;
        private _s3?;
        get s3(): string;
        set s3(value: string);
        resetS3(): void;
        get s3Input(): string | undefined;
        private _salesforce?;
        get salesforce(): string;
        set salesforce(value: string);
        resetSalesforce(): void;
        get salesforceInput(): string | undefined;
        private _sapoData?;
        get sapoData(): string;
        set sapoData(value: string);
        resetSapoData(): void;
        get sapoDataInput(): string | undefined;
        private _serviceNow?;
        get serviceNow(): string;
        set serviceNow(value: string);
        resetServiceNow(): void;
        get serviceNowInput(): string | undefined;
        private _singular?;
        get singular(): string;
        set singular(value: string);
        resetSingular(): void;
        get singularInput(): string | undefined;
        private _slack?;
        get slack(): string;
        set slack(value: string);
        resetSlack(): void;
        get slackInput(): string | undefined;
        private _trendmicro?;
        get trendmicro(): string;
        set trendmicro(value: string);
        resetTrendmicro(): void;
        get trendmicroInput(): string | undefined;
        private _veeva?;
        get veeva(): string;
        set veeva(value: string);
        resetVeeva(): void;
        get veevaInput(): string | undefined;
        private _zendesk?;
        get zendesk(): string;
        set zendesk(value: string);
        resetZendesk(): void;
        get zendeskInput(): string | undefined;
    }
    class ConnectorOperatorPropertyList extends cdktn.ComplexList {
        internalValue?: ConnectorOperatorProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConnectorOperatorPropertyOutputReference;
    }
    interface TaskProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#destination_field AwsAppflowFlow#destination_field}
        */
        readonly destinationField?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#source_fields AwsAppflowFlow#source_fields}
        */
        readonly sourceFields?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#task_properties AwsAppflowFlow#task_properties}
        */
        readonly taskProperties?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#task_type AwsAppflowFlow#task_type}
        */
        readonly taskType: string;
        /**
        * connector_operator block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#connector_operator AwsAppflowFlow#connector_operator}
        */
        readonly connectorOperator?: ConnectorOperatorProperty[] | cdktn.IResolvable;
    }
    class TaskPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TaskProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TaskProperty | cdktn.IResolvable | undefined);
        private _destinationField?;
        get destinationField(): string;
        set destinationField(value: string);
        resetDestinationField(): void;
        get destinationFieldInput(): string | undefined;
        private _sourceFields?;
        get sourceFields(): string[];
        set sourceFields(value: string[]);
        resetSourceFields(): void;
        get sourceFieldsInput(): string[] | undefined;
        private _taskProperties?;
        get taskProperties(): {
            [key: string]: string;
        };
        set taskProperties(value: {
            [key: string]: string;
        });
        resetTaskProperties(): void;
        get taskPropertiesInput(): {
            [key: string]: string;
        } | undefined;
        private _taskType?;
        get taskType(): string;
        set taskType(value: string);
        get taskTypeInput(): string | undefined;
        private _connectorOperator;
        get connectorOperator(): ConnectorOperatorPropertyList;
        putConnectorOperator(value: ConnectorOperatorProperty[] | cdktn.IResolvable): void;
        resetConnectorOperator(): void;
        get connectorOperatorInput(): cdktn.IResolvable | ConnectorOperatorProperty[] | undefined;
    }
    class TaskPropertyList extends cdktn.ComplexList {
        internalValue?: TaskProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TaskPropertyOutputReference;
    }
    interface ScheduledProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#data_pull_mode AwsAppflowFlow#data_pull_mode}
        */
        readonly dataPullMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#first_execution_from AwsAppflowFlow#first_execution_from}
        */
        readonly firstExecutionFrom?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#schedule_end_time AwsAppflowFlow#schedule_end_time}
        */
        readonly scheduleEndTime?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#schedule_expression AwsAppflowFlow#schedule_expression}
        */
        readonly scheduleExpression: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#schedule_offset AwsAppflowFlow#schedule_offset}
        */
        readonly scheduleOffset?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#schedule_start_time AwsAppflowFlow#schedule_start_time}
        */
        readonly scheduleStartTime?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#timezone AwsAppflowFlow#timezone}
        */
        readonly timezone?: string;
    }
    class ScheduledPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ScheduledProperty | undefined;
        set internalValue(value: ScheduledProperty | undefined);
        private _dataPullMode?;
        get dataPullMode(): string;
        set dataPullMode(value: string);
        resetDataPullMode(): void;
        get dataPullModeInput(): string | undefined;
        private _firstExecutionFrom?;
        get firstExecutionFrom(): string;
        set firstExecutionFrom(value: string);
        resetFirstExecutionFrom(): void;
        get firstExecutionFromInput(): string | undefined;
        private _scheduleEndTime?;
        get scheduleEndTime(): string;
        set scheduleEndTime(value: string);
        resetScheduleEndTime(): void;
        get scheduleEndTimeInput(): string | undefined;
        private _scheduleExpression?;
        get scheduleExpression(): string;
        set scheduleExpression(value: string);
        get scheduleExpressionInput(): string | undefined;
        private _scheduleOffset?;
        get scheduleOffset(): number;
        set scheduleOffset(value: number);
        resetScheduleOffset(): void;
        get scheduleOffsetInput(): number | undefined;
        private _scheduleStartTime?;
        get scheduleStartTime(): string;
        set scheduleStartTime(value: string);
        resetScheduleStartTime(): void;
        get scheduleStartTimeInput(): string | undefined;
        private _timezone?;
        get timezone(): string;
        set timezone(value: string);
        resetTimezone(): void;
        get timezoneInput(): string | undefined;
    }
    interface TriggerPropertiesProperty {
        /**
        * scheduled block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#scheduled AwsAppflowFlow#scheduled}
        */
        readonly scheduled?: ScheduledProperty;
    }
    class TriggerPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TriggerPropertiesProperty | undefined;
        set internalValue(value: TriggerPropertiesProperty | undefined);
        private _scheduled;
        get scheduled(): ScheduledPropertyOutputReference;
        putScheduled(value: ScheduledProperty): void;
        resetScheduled(): void;
        get scheduledInput(): ScheduledProperty | undefined;
    }
    interface TriggerConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#trigger_type AwsAppflowFlow#trigger_type}
        */
        readonly triggerType: string;
        /**
        * trigger_properties block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#trigger_properties AwsAppflowFlow#trigger_properties}
        */
        readonly triggerProperties?: TriggerPropertiesProperty;
    }
    class TriggerConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TriggerConfigProperty | undefined;
        set internalValue(value: TriggerConfigProperty | undefined);
        private _triggerType?;
        get triggerType(): string;
        set triggerType(value: string);
        get triggerTypeInput(): string | undefined;
        private _triggerProperties;
        get triggerProperties(): TriggerPropertiesPropertyOutputReference;
        putTriggerProperties(value: TriggerPropertiesProperty): void;
        resetTriggerProperties(): void;
        get triggerPropertiesInput(): TriggerPropertiesProperty | undefined;
    }
}
