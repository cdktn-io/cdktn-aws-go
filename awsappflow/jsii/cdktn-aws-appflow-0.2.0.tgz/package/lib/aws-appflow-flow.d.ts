import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfFlowConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#description TfFlow#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#id TfFlow#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#kms_arn TfFlow#kms_arn}
    */
    readonly kmsArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#name TfFlow#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#region TfFlow#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#tags TfFlow#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#tags_all TfFlow#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * destination_flow_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#destination_flow_config TfFlow#destination_flow_config}
    */
    readonly destinationFlowConfig: TfFlow.DestinationFlowConfigProperty[] | cdktn.IResolvable;
    /**
    * metadata_catalog_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#metadata_catalog_config TfFlow#metadata_catalog_config}
    */
    readonly metadataCatalogConfig?: TfFlow.MetadataCatalogConfigProperty;
    /**
    * source_flow_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#source_flow_config TfFlow#source_flow_config}
    */
    readonly sourceFlowConfig: TfFlow.SourceFlowConfigProperty;
    /**
    * task block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#task TfFlow#task}
    */
    readonly task: TfFlow.TaskProperty[] | cdktn.IResolvable;
    /**
    * trigger_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#trigger_config TfFlow#trigger_config}
    */
    readonly triggerConfig: TfFlow.TriggerConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow aws_appflow_flow}
*/
export declare class TfFlow extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_appflow_flow";
    /**
    * Generates CDKTN code for importing a TfFlow resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfFlow to import
    * @param importFromId The id of the existing TfFlow that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfFlow to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow aws_appflow_flow} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfFlowConfig
    */
    constructor(scope: Construct, id: string, config: TfFlowConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get flowStatus(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _kmsArn?;
    get kmsArn(): string;
    set kmsArn(value: string);
    resetKmsArn(): void;
    get kmsArnInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _destinationFlowConfig;
    get destinationFlowConfig(): TfFlow.DestinationFlowConfigPropertyList;
    putDestinationFlowConfig(value: TfFlow.DestinationFlowConfigProperty[] | cdktn.IResolvable): void;
    get destinationFlowConfigInput(): cdktn.IResolvable | TfFlow.DestinationFlowConfigProperty[] | undefined;
    private _metadataCatalogConfig;
    get metadataCatalogConfig(): TfFlow.MetadataCatalogConfigPropertyOutputReference;
    putMetadataCatalogConfig(value: TfFlow.MetadataCatalogConfigProperty): void;
    resetMetadataCatalogConfig(): void;
    get metadataCatalogConfigInput(): TfFlow.MetadataCatalogConfigProperty | undefined;
    private _sourceFlowConfig;
    get sourceFlowConfig(): TfFlow.SourceFlowConfigPropertyOutputReference;
    putSourceFlowConfig(value: TfFlow.SourceFlowConfigProperty): void;
    get sourceFlowConfigInput(): TfFlow.SourceFlowConfigProperty | undefined;
    private _task;
    get task(): TfFlow.TaskPropertyList;
    putTask(value: TfFlow.TaskProperty[] | cdktn.IResolvable): void;
    get taskInput(): cdktn.IResolvable | TfFlow.TaskProperty[] | undefined;
    private _triggerConfig;
    get triggerConfig(): TfFlow.TriggerConfigPropertyOutputReference;
    putTriggerConfig(value: TfFlow.TriggerConfigProperty): void;
    get triggerConfigInput(): TfFlow.TriggerConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfFlowDestinationFlowConfigDestinationConnectorPropertiesCustomConnectorErrorHandlingConfigPropertyToTerraform(struct?: TfFlow.DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorErrorHandlingConfigPropertyOutputReference | TfFlow.DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorErrorHandlingConfigProperty): any;
export declare function tfFlowDestinationFlowConfigDestinationConnectorPropertiesCustomConnectorErrorHandlingConfigPropertyToHclTerraform(struct?: TfFlow.DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorErrorHandlingConfigPropertyOutputReference | TfFlow.DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorErrorHandlingConfigProperty): any;
export declare function tfFlowDestinationFlowConfigDestinationConnectorPropertiesCustomConnectorPropertyToTerraform(struct?: TfFlow.DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorPropertyOutputReference | TfFlow.DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorProperty): any;
export declare function tfFlowDestinationFlowConfigDestinationConnectorPropertiesCustomConnectorPropertyToHclTerraform(struct?: TfFlow.DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorPropertyOutputReference | TfFlow.DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorProperty): any;
export declare function tfFlowCustomerProfilesPropertyToTerraform(struct?: TfFlow.CustomerProfilesPropertyOutputReference | TfFlow.CustomerProfilesProperty): any;
export declare function tfFlowCustomerProfilesPropertyToHclTerraform(struct?: TfFlow.CustomerProfilesPropertyOutputReference | TfFlow.CustomerProfilesProperty): any;
export declare function tfFlowDestinationFlowConfigDestinationConnectorPropertiesEventBridgeErrorHandlingConfigPropertyToTerraform(struct?: TfFlow.DestinationFlowConfigDestinationConnectorPropertiesEventBridgeErrorHandlingConfigPropertyOutputReference | TfFlow.DestinationFlowConfigDestinationConnectorPropertiesEventBridgeErrorHandlingConfigProperty): any;
export declare function tfFlowDestinationFlowConfigDestinationConnectorPropertiesEventBridgeErrorHandlingConfigPropertyToHclTerraform(struct?: TfFlow.DestinationFlowConfigDestinationConnectorPropertiesEventBridgeErrorHandlingConfigPropertyOutputReference | TfFlow.DestinationFlowConfigDestinationConnectorPropertiesEventBridgeErrorHandlingConfigProperty): any;
export declare function tfFlowEventBridgePropertyToTerraform(struct?: TfFlow.EventBridgePropertyOutputReference | TfFlow.EventBridgeProperty): any;
export declare function tfFlowEventBridgePropertyToHclTerraform(struct?: TfFlow.EventBridgePropertyOutputReference | TfFlow.EventBridgeProperty): any;
export declare function tfFlowDestinationFlowConfigDestinationConnectorPropertiesHoneycodeErrorHandlingConfigPropertyToTerraform(struct?: TfFlow.DestinationFlowConfigDestinationConnectorPropertiesHoneycodeErrorHandlingConfigPropertyOutputReference | TfFlow.DestinationFlowConfigDestinationConnectorPropertiesHoneycodeErrorHandlingConfigProperty): any;
export declare function tfFlowDestinationFlowConfigDestinationConnectorPropertiesHoneycodeErrorHandlingConfigPropertyToHclTerraform(struct?: TfFlow.DestinationFlowConfigDestinationConnectorPropertiesHoneycodeErrorHandlingConfigPropertyOutputReference | TfFlow.DestinationFlowConfigDestinationConnectorPropertiesHoneycodeErrorHandlingConfigProperty): any;
export declare function tfFlowHoneycodePropertyToTerraform(struct?: TfFlow.HoneycodePropertyOutputReference | TfFlow.HoneycodeProperty): any;
export declare function tfFlowHoneycodePropertyToHclTerraform(struct?: TfFlow.HoneycodePropertyOutputReference | TfFlow.HoneycodeProperty): any;
export declare function tfFlowLookoutMetricsPropertyToTerraform(struct?: TfFlow.LookoutMetricsPropertyOutputReference | TfFlow.LookoutMetricsProperty): any;
export declare function tfFlowLookoutMetricsPropertyToHclTerraform(struct?: TfFlow.LookoutMetricsPropertyOutputReference | TfFlow.LookoutMetricsProperty): any;
export declare function tfFlowDestinationFlowConfigDestinationConnectorPropertiesMarketoErrorHandlingConfigPropertyToTerraform(struct?: TfFlow.DestinationFlowConfigDestinationConnectorPropertiesMarketoErrorHandlingConfigPropertyOutputReference | TfFlow.DestinationFlowConfigDestinationConnectorPropertiesMarketoErrorHandlingConfigProperty): any;
export declare function tfFlowDestinationFlowConfigDestinationConnectorPropertiesMarketoErrorHandlingConfigPropertyToHclTerraform(struct?: TfFlow.DestinationFlowConfigDestinationConnectorPropertiesMarketoErrorHandlingConfigPropertyOutputReference | TfFlow.DestinationFlowConfigDestinationConnectorPropertiesMarketoErrorHandlingConfigProperty): any;
export declare function tfFlowDestinationFlowConfigDestinationConnectorPropertiesMarketoPropertyToTerraform(struct?: TfFlow.DestinationFlowConfigDestinationConnectorPropertiesMarketoPropertyOutputReference | TfFlow.DestinationFlowConfigDestinationConnectorPropertiesMarketoProperty): any;
export declare function tfFlowDestinationFlowConfigDestinationConnectorPropertiesMarketoPropertyToHclTerraform(struct?: TfFlow.DestinationFlowConfigDestinationConnectorPropertiesMarketoPropertyOutputReference | TfFlow.DestinationFlowConfigDestinationConnectorPropertiesMarketoProperty): any;
export declare function tfFlowDestinationFlowConfigDestinationConnectorPropertiesRedshiftErrorHandlingConfigPropertyToTerraform(struct?: TfFlow.DestinationFlowConfigDestinationConnectorPropertiesRedshiftErrorHandlingConfigPropertyOutputReference | TfFlow.DestinationFlowConfigDestinationConnectorPropertiesRedshiftErrorHandlingConfigProperty): any;
export declare function tfFlowDestinationFlowConfigDestinationConnectorPropertiesRedshiftErrorHandlingConfigPropertyToHclTerraform(struct?: TfFlow.DestinationFlowConfigDestinationConnectorPropertiesRedshiftErrorHandlingConfigPropertyOutputReference | TfFlow.DestinationFlowConfigDestinationConnectorPropertiesRedshiftErrorHandlingConfigProperty): any;
export declare function tfFlowRedshiftPropertyToTerraform(struct?: TfFlow.RedshiftPropertyOutputReference | TfFlow.RedshiftProperty): any;
export declare function tfFlowRedshiftPropertyToHclTerraform(struct?: TfFlow.RedshiftPropertyOutputReference | TfFlow.RedshiftProperty): any;
export declare function tfFlowDestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigAggregationConfigPropertyToTerraform(struct?: TfFlow.DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigAggregationConfigPropertyOutputReference | TfFlow.DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigAggregationConfigProperty): any;
export declare function tfFlowDestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigAggregationConfigPropertyToHclTerraform(struct?: TfFlow.DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigAggregationConfigPropertyOutputReference | TfFlow.DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigAggregationConfigProperty): any;
export declare function tfFlowDestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigPrefixConfigPropertyToTerraform(struct?: TfFlow.DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigPrefixConfigPropertyOutputReference | TfFlow.DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigPrefixConfigProperty): any;
export declare function tfFlowDestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigPrefixConfigPropertyToHclTerraform(struct?: TfFlow.DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigPrefixConfigPropertyOutputReference | TfFlow.DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigPrefixConfigProperty): any;
export declare function tfFlowDestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigPropertyToTerraform(struct?: TfFlow.DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigPropertyOutputReference | TfFlow.DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigProperty): any;
export declare function tfFlowDestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigPropertyToHclTerraform(struct?: TfFlow.DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigPropertyOutputReference | TfFlow.DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigProperty): any;
export declare function tfFlowDestinationFlowConfigDestinationConnectorPropertiesS3PropertyToTerraform(struct?: TfFlow.DestinationFlowConfigDestinationConnectorPropertiesS3PropertyOutputReference | TfFlow.DestinationFlowConfigDestinationConnectorPropertiesS3Property): any;
export declare function tfFlowDestinationFlowConfigDestinationConnectorPropertiesS3PropertyToHclTerraform(struct?: TfFlow.DestinationFlowConfigDestinationConnectorPropertiesS3PropertyOutputReference | TfFlow.DestinationFlowConfigDestinationConnectorPropertiesS3Property): any;
export declare function tfFlowDestinationFlowConfigDestinationConnectorPropertiesSalesforceErrorHandlingConfigPropertyToTerraform(struct?: TfFlow.DestinationFlowConfigDestinationConnectorPropertiesSalesforceErrorHandlingConfigPropertyOutputReference | TfFlow.DestinationFlowConfigDestinationConnectorPropertiesSalesforceErrorHandlingConfigProperty): any;
export declare function tfFlowDestinationFlowConfigDestinationConnectorPropertiesSalesforceErrorHandlingConfigPropertyToHclTerraform(struct?: TfFlow.DestinationFlowConfigDestinationConnectorPropertiesSalesforceErrorHandlingConfigPropertyOutputReference | TfFlow.DestinationFlowConfigDestinationConnectorPropertiesSalesforceErrorHandlingConfigProperty): any;
export declare function tfFlowDestinationFlowConfigDestinationConnectorPropertiesSalesforcePropertyToTerraform(struct?: TfFlow.DestinationFlowConfigDestinationConnectorPropertiesSalesforcePropertyOutputReference | TfFlow.DestinationFlowConfigDestinationConnectorPropertiesSalesforceProperty): any;
export declare function tfFlowDestinationFlowConfigDestinationConnectorPropertiesSalesforcePropertyToHclTerraform(struct?: TfFlow.DestinationFlowConfigDestinationConnectorPropertiesSalesforcePropertyOutputReference | TfFlow.DestinationFlowConfigDestinationConnectorPropertiesSalesforceProperty): any;
export declare function tfFlowDestinationFlowConfigDestinationConnectorPropertiesSapoDataErrorHandlingConfigPropertyToTerraform(struct?: TfFlow.DestinationFlowConfigDestinationConnectorPropertiesSapoDataErrorHandlingConfigPropertyOutputReference | TfFlow.DestinationFlowConfigDestinationConnectorPropertiesSapoDataErrorHandlingConfigProperty): any;
export declare function tfFlowDestinationFlowConfigDestinationConnectorPropertiesSapoDataErrorHandlingConfigPropertyToHclTerraform(struct?: TfFlow.DestinationFlowConfigDestinationConnectorPropertiesSapoDataErrorHandlingConfigPropertyOutputReference | TfFlow.DestinationFlowConfigDestinationConnectorPropertiesSapoDataErrorHandlingConfigProperty): any;
export declare function tfFlowSuccessResponseHandlingConfigPropertyToTerraform(struct?: TfFlow.SuccessResponseHandlingConfigPropertyOutputReference | TfFlow.SuccessResponseHandlingConfigProperty): any;
export declare function tfFlowSuccessResponseHandlingConfigPropertyToHclTerraform(struct?: TfFlow.SuccessResponseHandlingConfigPropertyOutputReference | TfFlow.SuccessResponseHandlingConfigProperty): any;
export declare function tfFlowDestinationFlowConfigDestinationConnectorPropertiesSapoDataPropertyToTerraform(struct?: TfFlow.DestinationFlowConfigDestinationConnectorPropertiesSapoDataPropertyOutputReference | TfFlow.DestinationFlowConfigDestinationConnectorPropertiesSapoDataProperty): any;
export declare function tfFlowDestinationFlowConfigDestinationConnectorPropertiesSapoDataPropertyToHclTerraform(struct?: TfFlow.DestinationFlowConfigDestinationConnectorPropertiesSapoDataPropertyOutputReference | TfFlow.DestinationFlowConfigDestinationConnectorPropertiesSapoDataProperty): any;
export declare function tfFlowDestinationFlowConfigDestinationConnectorPropertiesSnowflakeErrorHandlingConfigPropertyToTerraform(struct?: TfFlow.DestinationFlowConfigDestinationConnectorPropertiesSnowflakeErrorHandlingConfigPropertyOutputReference | TfFlow.DestinationFlowConfigDestinationConnectorPropertiesSnowflakeErrorHandlingConfigProperty): any;
export declare function tfFlowDestinationFlowConfigDestinationConnectorPropertiesSnowflakeErrorHandlingConfigPropertyToHclTerraform(struct?: TfFlow.DestinationFlowConfigDestinationConnectorPropertiesSnowflakeErrorHandlingConfigPropertyOutputReference | TfFlow.DestinationFlowConfigDestinationConnectorPropertiesSnowflakeErrorHandlingConfigProperty): any;
export declare function tfFlowSnowflakePropertyToTerraform(struct?: TfFlow.SnowflakePropertyOutputReference | TfFlow.SnowflakeProperty): any;
export declare function tfFlowSnowflakePropertyToHclTerraform(struct?: TfFlow.SnowflakePropertyOutputReference | TfFlow.SnowflakeProperty): any;
export declare function tfFlowDestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigAggregationConfigPropertyToTerraform(struct?: TfFlow.DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigAggregationConfigPropertyOutputReference | TfFlow.DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigAggregationConfigProperty): any;
export declare function tfFlowDestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigAggregationConfigPropertyToHclTerraform(struct?: TfFlow.DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigAggregationConfigPropertyOutputReference | TfFlow.DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigAggregationConfigProperty): any;
export declare function tfFlowDestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPrefixConfigPropertyToTerraform(struct?: TfFlow.DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPrefixConfigPropertyOutputReference | TfFlow.DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPrefixConfigProperty): any;
export declare function tfFlowDestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPrefixConfigPropertyToHclTerraform(struct?: TfFlow.DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPrefixConfigPropertyOutputReference | TfFlow.DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPrefixConfigProperty): any;
export declare function tfFlowDestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPropertyToTerraform(struct?: TfFlow.DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPropertyOutputReference | TfFlow.DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigProperty): any;
export declare function tfFlowDestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPropertyToHclTerraform(struct?: TfFlow.DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPropertyOutputReference | TfFlow.DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigProperty): any;
export declare function tfFlowUpsolverPropertyToTerraform(struct?: TfFlow.UpsolverPropertyOutputReference | TfFlow.UpsolverProperty): any;
export declare function tfFlowUpsolverPropertyToHclTerraform(struct?: TfFlow.UpsolverPropertyOutputReference | TfFlow.UpsolverProperty): any;
export declare function tfFlowDestinationFlowConfigDestinationConnectorPropertiesZendeskErrorHandlingConfigPropertyToTerraform(struct?: TfFlow.DestinationFlowConfigDestinationConnectorPropertiesZendeskErrorHandlingConfigPropertyOutputReference | TfFlow.DestinationFlowConfigDestinationConnectorPropertiesZendeskErrorHandlingConfigProperty): any;
export declare function tfFlowDestinationFlowConfigDestinationConnectorPropertiesZendeskErrorHandlingConfigPropertyToHclTerraform(struct?: TfFlow.DestinationFlowConfigDestinationConnectorPropertiesZendeskErrorHandlingConfigPropertyOutputReference | TfFlow.DestinationFlowConfigDestinationConnectorPropertiesZendeskErrorHandlingConfigProperty): any;
export declare function tfFlowDestinationFlowConfigDestinationConnectorPropertiesZendeskPropertyToTerraform(struct?: TfFlow.DestinationFlowConfigDestinationConnectorPropertiesZendeskPropertyOutputReference | TfFlow.DestinationFlowConfigDestinationConnectorPropertiesZendeskProperty): any;
export declare function tfFlowDestinationFlowConfigDestinationConnectorPropertiesZendeskPropertyToHclTerraform(struct?: TfFlow.DestinationFlowConfigDestinationConnectorPropertiesZendeskPropertyOutputReference | TfFlow.DestinationFlowConfigDestinationConnectorPropertiesZendeskProperty): any;
export declare function tfFlowDestinationConnectorPropertiesPropertyToTerraform(struct?: TfFlow.DestinationConnectorPropertiesPropertyOutputReference | TfFlow.DestinationConnectorPropertiesProperty): any;
export declare function tfFlowDestinationConnectorPropertiesPropertyToHclTerraform(struct?: TfFlow.DestinationConnectorPropertiesPropertyOutputReference | TfFlow.DestinationConnectorPropertiesProperty): any;
export declare function tfFlowDestinationFlowConfigPropertyToTerraform(struct?: TfFlow.DestinationFlowConfigProperty | cdktn.IResolvable): any;
export declare function tfFlowDestinationFlowConfigPropertyToHclTerraform(struct?: TfFlow.DestinationFlowConfigProperty | cdktn.IResolvable): any;
export declare function tfFlowGlueDataCatalogPropertyToTerraform(struct?: TfFlow.GlueDataCatalogPropertyOutputReference | TfFlow.GlueDataCatalogProperty): any;
export declare function tfFlowGlueDataCatalogPropertyToHclTerraform(struct?: TfFlow.GlueDataCatalogPropertyOutputReference | TfFlow.GlueDataCatalogProperty): any;
export declare function tfFlowMetadataCatalogConfigPropertyToTerraform(struct?: TfFlow.MetadataCatalogConfigPropertyOutputReference | TfFlow.MetadataCatalogConfigProperty): any;
export declare function tfFlowMetadataCatalogConfigPropertyToHclTerraform(struct?: TfFlow.MetadataCatalogConfigPropertyOutputReference | TfFlow.MetadataCatalogConfigProperty): any;
export declare function tfFlowIncrementalPullConfigPropertyToTerraform(struct?: TfFlow.IncrementalPullConfigPropertyOutputReference | TfFlow.IncrementalPullConfigProperty): any;
export declare function tfFlowIncrementalPullConfigPropertyToHclTerraform(struct?: TfFlow.IncrementalPullConfigPropertyOutputReference | TfFlow.IncrementalPullConfigProperty): any;
export declare function tfFlowAmplitudePropertyToTerraform(struct?: TfFlow.AmplitudePropertyOutputReference | TfFlow.AmplitudeProperty): any;
export declare function tfFlowAmplitudePropertyToHclTerraform(struct?: TfFlow.AmplitudePropertyOutputReference | TfFlow.AmplitudeProperty): any;
export declare function tfFlowSourceFlowConfigSourceConnectorPropertiesCustomConnectorPropertyToTerraform(struct?: TfFlow.SourceFlowConfigSourceConnectorPropertiesCustomConnectorPropertyOutputReference | TfFlow.SourceFlowConfigSourceConnectorPropertiesCustomConnectorProperty): any;
export declare function tfFlowSourceFlowConfigSourceConnectorPropertiesCustomConnectorPropertyToHclTerraform(struct?: TfFlow.SourceFlowConfigSourceConnectorPropertiesCustomConnectorPropertyOutputReference | TfFlow.SourceFlowConfigSourceConnectorPropertiesCustomConnectorProperty): any;
export declare function tfFlowDatadogPropertyToTerraform(struct?: TfFlow.DatadogPropertyOutputReference | TfFlow.DatadogProperty): any;
export declare function tfFlowDatadogPropertyToHclTerraform(struct?: TfFlow.DatadogPropertyOutputReference | TfFlow.DatadogProperty): any;
export declare function tfFlowDynatracePropertyToTerraform(struct?: TfFlow.DynatracePropertyOutputReference | TfFlow.DynatraceProperty): any;
export declare function tfFlowDynatracePropertyToHclTerraform(struct?: TfFlow.DynatracePropertyOutputReference | TfFlow.DynatraceProperty): any;
export declare function tfFlowGoogleAnalyticsPropertyToTerraform(struct?: TfFlow.GoogleAnalyticsPropertyOutputReference | TfFlow.GoogleAnalyticsProperty): any;
export declare function tfFlowGoogleAnalyticsPropertyToHclTerraform(struct?: TfFlow.GoogleAnalyticsPropertyOutputReference | TfFlow.GoogleAnalyticsProperty): any;
export declare function tfFlowInforNexusPropertyToTerraform(struct?: TfFlow.InforNexusPropertyOutputReference | TfFlow.InforNexusProperty): any;
export declare function tfFlowInforNexusPropertyToHclTerraform(struct?: TfFlow.InforNexusPropertyOutputReference | TfFlow.InforNexusProperty): any;
export declare function tfFlowSourceFlowConfigSourceConnectorPropertiesMarketoPropertyToTerraform(struct?: TfFlow.SourceFlowConfigSourceConnectorPropertiesMarketoPropertyOutputReference | TfFlow.SourceFlowConfigSourceConnectorPropertiesMarketoProperty): any;
export declare function tfFlowSourceFlowConfigSourceConnectorPropertiesMarketoPropertyToHclTerraform(struct?: TfFlow.SourceFlowConfigSourceConnectorPropertiesMarketoPropertyOutputReference | TfFlow.SourceFlowConfigSourceConnectorPropertiesMarketoProperty): any;
export declare function tfFlowS3InputFormatConfigPropertyToTerraform(struct?: TfFlow.S3InputFormatConfigPropertyOutputReference | TfFlow.S3InputFormatConfigProperty): any;
export declare function tfFlowS3InputFormatConfigPropertyToHclTerraform(struct?: TfFlow.S3InputFormatConfigPropertyOutputReference | TfFlow.S3InputFormatConfigProperty): any;
export declare function tfFlowSourceFlowConfigSourceConnectorPropertiesS3PropertyToTerraform(struct?: TfFlow.SourceFlowConfigSourceConnectorPropertiesS3PropertyOutputReference | TfFlow.SourceFlowConfigSourceConnectorPropertiesS3Property): any;
export declare function tfFlowSourceFlowConfigSourceConnectorPropertiesS3PropertyToHclTerraform(struct?: TfFlow.SourceFlowConfigSourceConnectorPropertiesS3PropertyOutputReference | TfFlow.SourceFlowConfigSourceConnectorPropertiesS3Property): any;
export declare function tfFlowSourceFlowConfigSourceConnectorPropertiesSalesforcePropertyToTerraform(struct?: TfFlow.SourceFlowConfigSourceConnectorPropertiesSalesforcePropertyOutputReference | TfFlow.SourceFlowConfigSourceConnectorPropertiesSalesforceProperty): any;
export declare function tfFlowSourceFlowConfigSourceConnectorPropertiesSalesforcePropertyToHclTerraform(struct?: TfFlow.SourceFlowConfigSourceConnectorPropertiesSalesforcePropertyOutputReference | TfFlow.SourceFlowConfigSourceConnectorPropertiesSalesforceProperty): any;
export declare function tfFlowPaginationConfigPropertyToTerraform(struct?: TfFlow.PaginationConfigPropertyOutputReference | TfFlow.PaginationConfigProperty): any;
export declare function tfFlowPaginationConfigPropertyToHclTerraform(struct?: TfFlow.PaginationConfigPropertyOutputReference | TfFlow.PaginationConfigProperty): any;
export declare function tfFlowParallelismConfigPropertyToTerraform(struct?: TfFlow.ParallelismConfigPropertyOutputReference | TfFlow.ParallelismConfigProperty): any;
export declare function tfFlowParallelismConfigPropertyToHclTerraform(struct?: TfFlow.ParallelismConfigPropertyOutputReference | TfFlow.ParallelismConfigProperty): any;
export declare function tfFlowSourceFlowConfigSourceConnectorPropertiesSapoDataPropertyToTerraform(struct?: TfFlow.SourceFlowConfigSourceConnectorPropertiesSapoDataPropertyOutputReference | TfFlow.SourceFlowConfigSourceConnectorPropertiesSapoDataProperty): any;
export declare function tfFlowSourceFlowConfigSourceConnectorPropertiesSapoDataPropertyToHclTerraform(struct?: TfFlow.SourceFlowConfigSourceConnectorPropertiesSapoDataPropertyOutputReference | TfFlow.SourceFlowConfigSourceConnectorPropertiesSapoDataProperty): any;
export declare function tfFlowServiceNowPropertyToTerraform(struct?: TfFlow.ServiceNowPropertyOutputReference | TfFlow.ServiceNowProperty): any;
export declare function tfFlowServiceNowPropertyToHclTerraform(struct?: TfFlow.ServiceNowPropertyOutputReference | TfFlow.ServiceNowProperty): any;
export declare function tfFlowSingularPropertyToTerraform(struct?: TfFlow.SingularPropertyOutputReference | TfFlow.SingularProperty): any;
export declare function tfFlowSingularPropertyToHclTerraform(struct?: TfFlow.SingularPropertyOutputReference | TfFlow.SingularProperty): any;
export declare function tfFlowSlackPropertyToTerraform(struct?: TfFlow.SlackPropertyOutputReference | TfFlow.SlackProperty): any;
export declare function tfFlowSlackPropertyToHclTerraform(struct?: TfFlow.SlackPropertyOutputReference | TfFlow.SlackProperty): any;
export declare function tfFlowTrendmicroPropertyToTerraform(struct?: TfFlow.TrendmicroPropertyOutputReference | TfFlow.TrendmicroProperty): any;
export declare function tfFlowTrendmicroPropertyToHclTerraform(struct?: TfFlow.TrendmicroPropertyOutputReference | TfFlow.TrendmicroProperty): any;
export declare function tfFlowVeevaPropertyToTerraform(struct?: TfFlow.VeevaPropertyOutputReference | TfFlow.VeevaProperty): any;
export declare function tfFlowVeevaPropertyToHclTerraform(struct?: TfFlow.VeevaPropertyOutputReference | TfFlow.VeevaProperty): any;
export declare function tfFlowSourceFlowConfigSourceConnectorPropertiesZendeskPropertyToTerraform(struct?: TfFlow.SourceFlowConfigSourceConnectorPropertiesZendeskPropertyOutputReference | TfFlow.SourceFlowConfigSourceConnectorPropertiesZendeskProperty): any;
export declare function tfFlowSourceFlowConfigSourceConnectorPropertiesZendeskPropertyToHclTerraform(struct?: TfFlow.SourceFlowConfigSourceConnectorPropertiesZendeskPropertyOutputReference | TfFlow.SourceFlowConfigSourceConnectorPropertiesZendeskProperty): any;
export declare function tfFlowSourceConnectorPropertiesPropertyToTerraform(struct?: TfFlow.SourceConnectorPropertiesPropertyOutputReference | TfFlow.SourceConnectorPropertiesProperty): any;
export declare function tfFlowSourceConnectorPropertiesPropertyToHclTerraform(struct?: TfFlow.SourceConnectorPropertiesPropertyOutputReference | TfFlow.SourceConnectorPropertiesProperty): any;
export declare function tfFlowSourceFlowConfigPropertyToTerraform(struct?: TfFlow.SourceFlowConfigPropertyOutputReference | TfFlow.SourceFlowConfigProperty): any;
export declare function tfFlowSourceFlowConfigPropertyToHclTerraform(struct?: TfFlow.SourceFlowConfigPropertyOutputReference | TfFlow.SourceFlowConfigProperty): any;
export declare function tfFlowConnectorOperatorPropertyToTerraform(struct?: TfFlow.ConnectorOperatorProperty | cdktn.IResolvable): any;
export declare function tfFlowConnectorOperatorPropertyToHclTerraform(struct?: TfFlow.ConnectorOperatorProperty | cdktn.IResolvable): any;
export declare function tfFlowTaskPropertyToTerraform(struct?: TfFlow.TaskProperty | cdktn.IResolvable): any;
export declare function tfFlowTaskPropertyToHclTerraform(struct?: TfFlow.TaskProperty | cdktn.IResolvable): any;
export declare function tfFlowScheduledPropertyToTerraform(struct?: TfFlow.ScheduledPropertyOutputReference | TfFlow.ScheduledProperty): any;
export declare function tfFlowScheduledPropertyToHclTerraform(struct?: TfFlow.ScheduledPropertyOutputReference | TfFlow.ScheduledProperty): any;
export declare function tfFlowTriggerPropertiesPropertyToTerraform(struct?: TfFlow.TriggerPropertiesPropertyOutputReference | TfFlow.TriggerPropertiesProperty): any;
export declare function tfFlowTriggerPropertiesPropertyToHclTerraform(struct?: TfFlow.TriggerPropertiesPropertyOutputReference | TfFlow.TriggerPropertiesProperty): any;
export declare function tfFlowTriggerConfigPropertyToTerraform(struct?: TfFlow.TriggerConfigPropertyOutputReference | TfFlow.TriggerConfigProperty): any;
export declare function tfFlowTriggerConfigPropertyToHclTerraform(struct?: TfFlow.TriggerConfigPropertyOutputReference | TfFlow.TriggerConfigProperty): any;
export declare namespace TfFlow {
    interface DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorErrorHandlingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_name TfFlow#bucket_name}
        */
        readonly bucketName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_prefix TfFlow#bucket_prefix}
        */
        readonly bucketPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#fail_on_first_destination_error TfFlow#fail_on_first_destination_error}
        */
        readonly failOnFirstDestinationError?: boolean | cdktn.IResolvable;
    }
    class DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorErrorHandlingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorErrorHandlingConfigProperty | undefined;
        set internalValue(value: DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorErrorHandlingConfigProperty | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        resetBucketName(): void;
        get bucketNameInput(): string | undefined;
        private _bucketPrefix?;
        get bucketPrefix(): string;
        set bucketPrefix(value: string);
        resetBucketPrefix(): void;
        get bucketPrefixInput(): string | undefined;
        private _failOnFirstDestinationError?;
        get failOnFirstDestinationError(): boolean | cdktn.IResolvable;
        set failOnFirstDestinationError(value: boolean | cdktn.IResolvable);
        resetFailOnFirstDestinationError(): void;
        get failOnFirstDestinationErrorInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#custom_properties TfFlow#custom_properties}
        */
        readonly customProperties?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#entity_name TfFlow#entity_name}
        */
        readonly entityName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#id_field_names TfFlow#id_field_names}
        */
        readonly idFieldNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#write_operation_type TfFlow#write_operation_type}
        */
        readonly writeOperationType?: string;
        /**
        * error_handling_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#error_handling_config TfFlow#error_handling_config}
        */
        readonly errorHandlingConfig?: DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorErrorHandlingConfigProperty;
    }
    class DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorProperty | undefined;
        set internalValue(value: DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorProperty | undefined);
        private _customProperties?;
        get customProperties(): {
            [key: string]: string;
        };
        set customProperties(value: {
            [key: string]: string;
        });
        resetCustomProperties(): void;
        get customPropertiesInput(): {
            [key: string]: string;
        } | undefined;
        private _entityName?;
        get entityName(): string;
        set entityName(value: string);
        get entityNameInput(): string | undefined;
        private _idFieldNames?;
        get idFieldNames(): string[];
        set idFieldNames(value: string[]);
        resetIdFieldNames(): void;
        get idFieldNamesInput(): string[] | undefined;
        private _writeOperationType?;
        get writeOperationType(): string;
        set writeOperationType(value: string);
        resetWriteOperationType(): void;
        get writeOperationTypeInput(): string | undefined;
        private _errorHandlingConfig;
        get errorHandlingConfig(): DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorErrorHandlingConfigPropertyOutputReference;
        putErrorHandlingConfig(value: DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorErrorHandlingConfigProperty): void;
        resetErrorHandlingConfig(): void;
        get errorHandlingConfigInput(): DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorErrorHandlingConfigProperty | undefined;
    }
    interface CustomerProfilesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#domain_name TfFlow#domain_name}
        */
        readonly domainName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object_type_name TfFlow#object_type_name}
        */
        readonly objectTypeName?: string;
    }
    class CustomerProfilesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CustomerProfilesProperty | undefined;
        set internalValue(value: CustomerProfilesProperty | undefined);
        private _domainName?;
        get domainName(): string;
        set domainName(value: string);
        get domainNameInput(): string | undefined;
        private _objectTypeName?;
        get objectTypeName(): string;
        set objectTypeName(value: string);
        resetObjectTypeName(): void;
        get objectTypeNameInput(): string | undefined;
    }
    interface DestinationFlowConfigDestinationConnectorPropertiesEventBridgeErrorHandlingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_name TfFlow#bucket_name}
        */
        readonly bucketName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_prefix TfFlow#bucket_prefix}
        */
        readonly bucketPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#fail_on_first_destination_error TfFlow#fail_on_first_destination_error}
        */
        readonly failOnFirstDestinationError?: boolean | cdktn.IResolvable;
    }
    class DestinationFlowConfigDestinationConnectorPropertiesEventBridgeErrorHandlingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationFlowConfigDestinationConnectorPropertiesEventBridgeErrorHandlingConfigProperty | undefined;
        set internalValue(value: DestinationFlowConfigDestinationConnectorPropertiesEventBridgeErrorHandlingConfigProperty | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        resetBucketName(): void;
        get bucketNameInput(): string | undefined;
        private _bucketPrefix?;
        get bucketPrefix(): string;
        set bucketPrefix(value: string);
        resetBucketPrefix(): void;
        get bucketPrefixInput(): string | undefined;
        private _failOnFirstDestinationError?;
        get failOnFirstDestinationError(): boolean | cdktn.IResolvable;
        set failOnFirstDestinationError(value: boolean | cdktn.IResolvable);
        resetFailOnFirstDestinationError(): void;
        get failOnFirstDestinationErrorInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface EventBridgeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object TfFlow#object}
        */
        readonly object: string;
        /**
        * error_handling_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#error_handling_config TfFlow#error_handling_config}
        */
        readonly errorHandlingConfig?: DestinationFlowConfigDestinationConnectorPropertiesEventBridgeErrorHandlingConfigProperty;
    }
    class EventBridgePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EventBridgeProperty | undefined;
        set internalValue(value: EventBridgeProperty | undefined);
        private _object?;
        get object(): string;
        set object(value: string);
        get objectInput(): string | undefined;
        private _errorHandlingConfig;
        get errorHandlingConfig(): DestinationFlowConfigDestinationConnectorPropertiesEventBridgeErrorHandlingConfigPropertyOutputReference;
        putErrorHandlingConfig(value: DestinationFlowConfigDestinationConnectorPropertiesEventBridgeErrorHandlingConfigProperty): void;
        resetErrorHandlingConfig(): void;
        get errorHandlingConfigInput(): DestinationFlowConfigDestinationConnectorPropertiesEventBridgeErrorHandlingConfigProperty | undefined;
    }
    interface DestinationFlowConfigDestinationConnectorPropertiesHoneycodeErrorHandlingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_name TfFlow#bucket_name}
        */
        readonly bucketName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_prefix TfFlow#bucket_prefix}
        */
        readonly bucketPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#fail_on_first_destination_error TfFlow#fail_on_first_destination_error}
        */
        readonly failOnFirstDestinationError?: boolean | cdktn.IResolvable;
    }
    class DestinationFlowConfigDestinationConnectorPropertiesHoneycodeErrorHandlingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationFlowConfigDestinationConnectorPropertiesHoneycodeErrorHandlingConfigProperty | undefined;
        set internalValue(value: DestinationFlowConfigDestinationConnectorPropertiesHoneycodeErrorHandlingConfigProperty | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        resetBucketName(): void;
        get bucketNameInput(): string | undefined;
        private _bucketPrefix?;
        get bucketPrefix(): string;
        set bucketPrefix(value: string);
        resetBucketPrefix(): void;
        get bucketPrefixInput(): string | undefined;
        private _failOnFirstDestinationError?;
        get failOnFirstDestinationError(): boolean | cdktn.IResolvable;
        set failOnFirstDestinationError(value: boolean | cdktn.IResolvable);
        resetFailOnFirstDestinationError(): void;
        get failOnFirstDestinationErrorInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface HoneycodeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object TfFlow#object}
        */
        readonly object: string;
        /**
        * error_handling_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#error_handling_config TfFlow#error_handling_config}
        */
        readonly errorHandlingConfig?: DestinationFlowConfigDestinationConnectorPropertiesHoneycodeErrorHandlingConfigProperty;
    }
    class HoneycodePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): HoneycodeProperty | undefined;
        set internalValue(value: HoneycodeProperty | undefined);
        private _object?;
        get object(): string;
        set object(value: string);
        get objectInput(): string | undefined;
        private _errorHandlingConfig;
        get errorHandlingConfig(): DestinationFlowConfigDestinationConnectorPropertiesHoneycodeErrorHandlingConfigPropertyOutputReference;
        putErrorHandlingConfig(value: DestinationFlowConfigDestinationConnectorPropertiesHoneycodeErrorHandlingConfigProperty): void;
        resetErrorHandlingConfig(): void;
        get errorHandlingConfigInput(): DestinationFlowConfigDestinationConnectorPropertiesHoneycodeErrorHandlingConfigProperty | undefined;
    }
    interface LookoutMetricsProperty {
    }
    class LookoutMetricsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LookoutMetricsProperty | undefined;
        set internalValue(value: LookoutMetricsProperty | undefined);
    }
    interface DestinationFlowConfigDestinationConnectorPropertiesMarketoErrorHandlingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_name TfFlow#bucket_name}
        */
        readonly bucketName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_prefix TfFlow#bucket_prefix}
        */
        readonly bucketPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#fail_on_first_destination_error TfFlow#fail_on_first_destination_error}
        */
        readonly failOnFirstDestinationError?: boolean | cdktn.IResolvable;
    }
    class DestinationFlowConfigDestinationConnectorPropertiesMarketoErrorHandlingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationFlowConfigDestinationConnectorPropertiesMarketoErrorHandlingConfigProperty | undefined;
        set internalValue(value: DestinationFlowConfigDestinationConnectorPropertiesMarketoErrorHandlingConfigProperty | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        resetBucketName(): void;
        get bucketNameInput(): string | undefined;
        private _bucketPrefix?;
        get bucketPrefix(): string;
        set bucketPrefix(value: string);
        resetBucketPrefix(): void;
        get bucketPrefixInput(): string | undefined;
        private _failOnFirstDestinationError?;
        get failOnFirstDestinationError(): boolean | cdktn.IResolvable;
        set failOnFirstDestinationError(value: boolean | cdktn.IResolvable);
        resetFailOnFirstDestinationError(): void;
        get failOnFirstDestinationErrorInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface DestinationFlowConfigDestinationConnectorPropertiesMarketoProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object TfFlow#object}
        */
        readonly object: string;
        /**
        * error_handling_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#error_handling_config TfFlow#error_handling_config}
        */
        readonly errorHandlingConfig?: DestinationFlowConfigDestinationConnectorPropertiesMarketoErrorHandlingConfigProperty;
    }
    class DestinationFlowConfigDestinationConnectorPropertiesMarketoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationFlowConfigDestinationConnectorPropertiesMarketoProperty | undefined;
        set internalValue(value: DestinationFlowConfigDestinationConnectorPropertiesMarketoProperty | undefined);
        private _object?;
        get object(): string;
        set object(value: string);
        get objectInput(): string | undefined;
        private _errorHandlingConfig;
        get errorHandlingConfig(): DestinationFlowConfigDestinationConnectorPropertiesMarketoErrorHandlingConfigPropertyOutputReference;
        putErrorHandlingConfig(value: DestinationFlowConfigDestinationConnectorPropertiesMarketoErrorHandlingConfigProperty): void;
        resetErrorHandlingConfig(): void;
        get errorHandlingConfigInput(): DestinationFlowConfigDestinationConnectorPropertiesMarketoErrorHandlingConfigProperty | undefined;
    }
    interface DestinationFlowConfigDestinationConnectorPropertiesRedshiftErrorHandlingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_name TfFlow#bucket_name}
        */
        readonly bucketName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_prefix TfFlow#bucket_prefix}
        */
        readonly bucketPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#fail_on_first_destination_error TfFlow#fail_on_first_destination_error}
        */
        readonly failOnFirstDestinationError?: boolean | cdktn.IResolvable;
    }
    class DestinationFlowConfigDestinationConnectorPropertiesRedshiftErrorHandlingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationFlowConfigDestinationConnectorPropertiesRedshiftErrorHandlingConfigProperty | undefined;
        set internalValue(value: DestinationFlowConfigDestinationConnectorPropertiesRedshiftErrorHandlingConfigProperty | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        resetBucketName(): void;
        get bucketNameInput(): string | undefined;
        private _bucketPrefix?;
        get bucketPrefix(): string;
        set bucketPrefix(value: string);
        resetBucketPrefix(): void;
        get bucketPrefixInput(): string | undefined;
        private _failOnFirstDestinationError?;
        get failOnFirstDestinationError(): boolean | cdktn.IResolvable;
        set failOnFirstDestinationError(value: boolean | cdktn.IResolvable);
        resetFailOnFirstDestinationError(): void;
        get failOnFirstDestinationErrorInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface RedshiftProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_prefix TfFlow#bucket_prefix}
        */
        readonly bucketPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#intermediate_bucket_name TfFlow#intermediate_bucket_name}
        */
        readonly intermediateBucketName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object TfFlow#object}
        */
        readonly object: string;
        /**
        * error_handling_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#error_handling_config TfFlow#error_handling_config}
        */
        readonly errorHandlingConfig?: DestinationFlowConfigDestinationConnectorPropertiesRedshiftErrorHandlingConfigProperty;
    }
    class RedshiftPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RedshiftProperty | undefined;
        set internalValue(value: RedshiftProperty | undefined);
        private _bucketPrefix?;
        get bucketPrefix(): string;
        set bucketPrefix(value: string);
        resetBucketPrefix(): void;
        get bucketPrefixInput(): string | undefined;
        private _intermediateBucketName?;
        get intermediateBucketName(): string;
        set intermediateBucketName(value: string);
        get intermediateBucketNameInput(): string | undefined;
        private _object?;
        get object(): string;
        set object(value: string);
        get objectInput(): string | undefined;
        private _errorHandlingConfig;
        get errorHandlingConfig(): DestinationFlowConfigDestinationConnectorPropertiesRedshiftErrorHandlingConfigPropertyOutputReference;
        putErrorHandlingConfig(value: DestinationFlowConfigDestinationConnectorPropertiesRedshiftErrorHandlingConfigProperty): void;
        resetErrorHandlingConfig(): void;
        get errorHandlingConfigInput(): DestinationFlowConfigDestinationConnectorPropertiesRedshiftErrorHandlingConfigProperty | undefined;
    }
    interface DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigAggregationConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#aggregation_type TfFlow#aggregation_type}
        */
        readonly aggregationType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#target_file_size TfFlow#target_file_size}
        */
        readonly targetFileSize?: number;
    }
    class DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigAggregationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigAggregationConfigProperty | undefined;
        set internalValue(value: DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigAggregationConfigProperty | undefined);
        private _aggregationType?;
        get aggregationType(): string;
        set aggregationType(value: string);
        resetAggregationType(): void;
        get aggregationTypeInput(): string | undefined;
        private _targetFileSize?;
        get targetFileSize(): number;
        set targetFileSize(value: number);
        resetTargetFileSize(): void;
        get targetFileSizeInput(): number | undefined;
    }
    interface DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigPrefixConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#prefix_format TfFlow#prefix_format}
        */
        readonly prefixFormat?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#prefix_hierarchy TfFlow#prefix_hierarchy}
        */
        readonly prefixHierarchy?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#prefix_type TfFlow#prefix_type}
        */
        readonly prefixType?: string;
    }
    class DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigPrefixConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigPrefixConfigProperty | undefined;
        set internalValue(value: DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigPrefixConfigProperty | undefined);
        private _prefixFormat?;
        get prefixFormat(): string;
        set prefixFormat(value: string);
        resetPrefixFormat(): void;
        get prefixFormatInput(): string | undefined;
        private _prefixHierarchy?;
        get prefixHierarchy(): string[];
        set prefixHierarchy(value: string[]);
        resetPrefixHierarchy(): void;
        get prefixHierarchyInput(): string[] | undefined;
        private _prefixType?;
        get prefixType(): string;
        set prefixType(value: string);
        resetPrefixType(): void;
        get prefixTypeInput(): string | undefined;
    }
    interface DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#file_type TfFlow#file_type}
        */
        readonly fileType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#preserve_source_data_typing TfFlow#preserve_source_data_typing}
        */
        readonly preserveSourceDataTyping?: boolean | cdktn.IResolvable;
        /**
        * aggregation_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#aggregation_config TfFlow#aggregation_config}
        */
        readonly aggregationConfig?: DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigAggregationConfigProperty;
        /**
        * prefix_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#prefix_config TfFlow#prefix_config}
        */
        readonly prefixConfig?: DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigPrefixConfigProperty;
    }
    class DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigProperty | undefined;
        set internalValue(value: DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigProperty | undefined);
        private _fileType?;
        get fileType(): string;
        set fileType(value: string);
        resetFileType(): void;
        get fileTypeInput(): string | undefined;
        private _preserveSourceDataTyping?;
        get preserveSourceDataTyping(): boolean | cdktn.IResolvable;
        set preserveSourceDataTyping(value: boolean | cdktn.IResolvable);
        resetPreserveSourceDataTyping(): void;
        get preserveSourceDataTypingInput(): boolean | cdktn.IResolvable | undefined;
        private _aggregationConfig;
        get aggregationConfig(): DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigAggregationConfigPropertyOutputReference;
        putAggregationConfig(value: DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigAggregationConfigProperty): void;
        resetAggregationConfig(): void;
        get aggregationConfigInput(): DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigAggregationConfigProperty | undefined;
        private _prefixConfig;
        get prefixConfig(): DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigPrefixConfigPropertyOutputReference;
        putPrefixConfig(value: DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigPrefixConfigProperty): void;
        resetPrefixConfig(): void;
        get prefixConfigInput(): DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigPrefixConfigProperty | undefined;
    }
    interface DestinationFlowConfigDestinationConnectorPropertiesS3Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_name TfFlow#bucket_name}
        */
        readonly bucketName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_prefix TfFlow#bucket_prefix}
        */
        readonly bucketPrefix?: string;
        /**
        * s3_output_format_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#s3_output_format_config TfFlow#s3_output_format_config}
        */
        readonly s3OutputFormatConfig?: DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigProperty;
    }
    class DestinationFlowConfigDestinationConnectorPropertiesS3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationFlowConfigDestinationConnectorPropertiesS3Property | undefined;
        set internalValue(value: DestinationFlowConfigDestinationConnectorPropertiesS3Property | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        get bucketNameInput(): string | undefined;
        private _bucketPrefix?;
        get bucketPrefix(): string;
        set bucketPrefix(value: string);
        resetBucketPrefix(): void;
        get bucketPrefixInput(): string | undefined;
        private _s3OutputFormatConfig;
        get s3OutputFormatConfig(): DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigPropertyOutputReference;
        putS3OutputFormatConfig(value: DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigProperty): void;
        resetS3OutputFormatConfig(): void;
        get s3OutputFormatConfigInput(): DestinationFlowConfigDestinationConnectorPropertiesS3S3OutputFormatConfigProperty | undefined;
    }
    interface DestinationFlowConfigDestinationConnectorPropertiesSalesforceErrorHandlingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_name TfFlow#bucket_name}
        */
        readonly bucketName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_prefix TfFlow#bucket_prefix}
        */
        readonly bucketPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#fail_on_first_destination_error TfFlow#fail_on_first_destination_error}
        */
        readonly failOnFirstDestinationError?: boolean | cdktn.IResolvable;
    }
    class DestinationFlowConfigDestinationConnectorPropertiesSalesforceErrorHandlingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationFlowConfigDestinationConnectorPropertiesSalesforceErrorHandlingConfigProperty | undefined;
        set internalValue(value: DestinationFlowConfigDestinationConnectorPropertiesSalesforceErrorHandlingConfigProperty | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        resetBucketName(): void;
        get bucketNameInput(): string | undefined;
        private _bucketPrefix?;
        get bucketPrefix(): string;
        set bucketPrefix(value: string);
        resetBucketPrefix(): void;
        get bucketPrefixInput(): string | undefined;
        private _failOnFirstDestinationError?;
        get failOnFirstDestinationError(): boolean | cdktn.IResolvable;
        set failOnFirstDestinationError(value: boolean | cdktn.IResolvable);
        resetFailOnFirstDestinationError(): void;
        get failOnFirstDestinationErrorInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface DestinationFlowConfigDestinationConnectorPropertiesSalesforceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#data_transfer_api TfFlow#data_transfer_api}
        */
        readonly dataTransferApi?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#id_field_names TfFlow#id_field_names}
        */
        readonly idFieldNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object TfFlow#object}
        */
        readonly object: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#write_operation_type TfFlow#write_operation_type}
        */
        readonly writeOperationType?: string;
        /**
        * error_handling_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#error_handling_config TfFlow#error_handling_config}
        */
        readonly errorHandlingConfig?: DestinationFlowConfigDestinationConnectorPropertiesSalesforceErrorHandlingConfigProperty;
    }
    class DestinationFlowConfigDestinationConnectorPropertiesSalesforcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationFlowConfigDestinationConnectorPropertiesSalesforceProperty | undefined;
        set internalValue(value: DestinationFlowConfigDestinationConnectorPropertiesSalesforceProperty | undefined);
        private _dataTransferApi?;
        get dataTransferApi(): string;
        set dataTransferApi(value: string);
        resetDataTransferApi(): void;
        get dataTransferApiInput(): string | undefined;
        private _idFieldNames?;
        get idFieldNames(): string[];
        set idFieldNames(value: string[]);
        resetIdFieldNames(): void;
        get idFieldNamesInput(): string[] | undefined;
        private _object?;
        get object(): string;
        set object(value: string);
        get objectInput(): string | undefined;
        private _writeOperationType?;
        get writeOperationType(): string;
        set writeOperationType(value: string);
        resetWriteOperationType(): void;
        get writeOperationTypeInput(): string | undefined;
        private _errorHandlingConfig;
        get errorHandlingConfig(): DestinationFlowConfigDestinationConnectorPropertiesSalesforceErrorHandlingConfigPropertyOutputReference;
        putErrorHandlingConfig(value: DestinationFlowConfigDestinationConnectorPropertiesSalesforceErrorHandlingConfigProperty): void;
        resetErrorHandlingConfig(): void;
        get errorHandlingConfigInput(): DestinationFlowConfigDestinationConnectorPropertiesSalesforceErrorHandlingConfigProperty | undefined;
    }
    interface DestinationFlowConfigDestinationConnectorPropertiesSapoDataErrorHandlingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_name TfFlow#bucket_name}
        */
        readonly bucketName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_prefix TfFlow#bucket_prefix}
        */
        readonly bucketPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#fail_on_first_destination_error TfFlow#fail_on_first_destination_error}
        */
        readonly failOnFirstDestinationError?: boolean | cdktn.IResolvable;
    }
    class DestinationFlowConfigDestinationConnectorPropertiesSapoDataErrorHandlingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationFlowConfigDestinationConnectorPropertiesSapoDataErrorHandlingConfigProperty | undefined;
        set internalValue(value: DestinationFlowConfigDestinationConnectorPropertiesSapoDataErrorHandlingConfigProperty | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        resetBucketName(): void;
        get bucketNameInput(): string | undefined;
        private _bucketPrefix?;
        get bucketPrefix(): string;
        set bucketPrefix(value: string);
        resetBucketPrefix(): void;
        get bucketPrefixInput(): string | undefined;
        private _failOnFirstDestinationError?;
        get failOnFirstDestinationError(): boolean | cdktn.IResolvable;
        set failOnFirstDestinationError(value: boolean | cdktn.IResolvable);
        resetFailOnFirstDestinationError(): void;
        get failOnFirstDestinationErrorInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface SuccessResponseHandlingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_name TfFlow#bucket_name}
        */
        readonly bucketName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_prefix TfFlow#bucket_prefix}
        */
        readonly bucketPrefix?: string;
    }
    class SuccessResponseHandlingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SuccessResponseHandlingConfigProperty | undefined;
        set internalValue(value: SuccessResponseHandlingConfigProperty | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        resetBucketName(): void;
        get bucketNameInput(): string | undefined;
        private _bucketPrefix?;
        get bucketPrefix(): string;
        set bucketPrefix(value: string);
        resetBucketPrefix(): void;
        get bucketPrefixInput(): string | undefined;
    }
    interface DestinationFlowConfigDestinationConnectorPropertiesSapoDataProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#id_field_names TfFlow#id_field_names}
        */
        readonly idFieldNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object_path TfFlow#object_path}
        */
        readonly objectPath: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#write_operation_type TfFlow#write_operation_type}
        */
        readonly writeOperationType?: string;
        /**
        * error_handling_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#error_handling_config TfFlow#error_handling_config}
        */
        readonly errorHandlingConfig?: DestinationFlowConfigDestinationConnectorPropertiesSapoDataErrorHandlingConfigProperty;
        /**
        * success_response_handling_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#success_response_handling_config TfFlow#success_response_handling_config}
        */
        readonly successResponseHandlingConfig?: SuccessResponseHandlingConfigProperty;
    }
    class DestinationFlowConfigDestinationConnectorPropertiesSapoDataPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationFlowConfigDestinationConnectorPropertiesSapoDataProperty | undefined;
        set internalValue(value: DestinationFlowConfigDestinationConnectorPropertiesSapoDataProperty | undefined);
        private _idFieldNames?;
        get idFieldNames(): string[];
        set idFieldNames(value: string[]);
        resetIdFieldNames(): void;
        get idFieldNamesInput(): string[] | undefined;
        private _objectPath?;
        get objectPath(): string;
        set objectPath(value: string);
        get objectPathInput(): string | undefined;
        private _writeOperationType?;
        get writeOperationType(): string;
        set writeOperationType(value: string);
        resetWriteOperationType(): void;
        get writeOperationTypeInput(): string | undefined;
        private _errorHandlingConfig;
        get errorHandlingConfig(): DestinationFlowConfigDestinationConnectorPropertiesSapoDataErrorHandlingConfigPropertyOutputReference;
        putErrorHandlingConfig(value: DestinationFlowConfigDestinationConnectorPropertiesSapoDataErrorHandlingConfigProperty): void;
        resetErrorHandlingConfig(): void;
        get errorHandlingConfigInput(): DestinationFlowConfigDestinationConnectorPropertiesSapoDataErrorHandlingConfigProperty | undefined;
        private _successResponseHandlingConfig;
        get successResponseHandlingConfig(): SuccessResponseHandlingConfigPropertyOutputReference;
        putSuccessResponseHandlingConfig(value: SuccessResponseHandlingConfigProperty): void;
        resetSuccessResponseHandlingConfig(): void;
        get successResponseHandlingConfigInput(): SuccessResponseHandlingConfigProperty | undefined;
    }
    interface DestinationFlowConfigDestinationConnectorPropertiesSnowflakeErrorHandlingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_name TfFlow#bucket_name}
        */
        readonly bucketName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_prefix TfFlow#bucket_prefix}
        */
        readonly bucketPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#fail_on_first_destination_error TfFlow#fail_on_first_destination_error}
        */
        readonly failOnFirstDestinationError?: boolean | cdktn.IResolvable;
    }
    class DestinationFlowConfigDestinationConnectorPropertiesSnowflakeErrorHandlingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationFlowConfigDestinationConnectorPropertiesSnowflakeErrorHandlingConfigProperty | undefined;
        set internalValue(value: DestinationFlowConfigDestinationConnectorPropertiesSnowflakeErrorHandlingConfigProperty | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        resetBucketName(): void;
        get bucketNameInput(): string | undefined;
        private _bucketPrefix?;
        get bucketPrefix(): string;
        set bucketPrefix(value: string);
        resetBucketPrefix(): void;
        get bucketPrefixInput(): string | undefined;
        private _failOnFirstDestinationError?;
        get failOnFirstDestinationError(): boolean | cdktn.IResolvable;
        set failOnFirstDestinationError(value: boolean | cdktn.IResolvable);
        resetFailOnFirstDestinationError(): void;
        get failOnFirstDestinationErrorInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface SnowflakeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_prefix TfFlow#bucket_prefix}
        */
        readonly bucketPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#intermediate_bucket_name TfFlow#intermediate_bucket_name}
        */
        readonly intermediateBucketName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object TfFlow#object}
        */
        readonly object: string;
        /**
        * error_handling_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#error_handling_config TfFlow#error_handling_config}
        */
        readonly errorHandlingConfig?: DestinationFlowConfigDestinationConnectorPropertiesSnowflakeErrorHandlingConfigProperty;
    }
    class SnowflakePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SnowflakeProperty | undefined;
        set internalValue(value: SnowflakeProperty | undefined);
        private _bucketPrefix?;
        get bucketPrefix(): string;
        set bucketPrefix(value: string);
        resetBucketPrefix(): void;
        get bucketPrefixInput(): string | undefined;
        private _intermediateBucketName?;
        get intermediateBucketName(): string;
        set intermediateBucketName(value: string);
        get intermediateBucketNameInput(): string | undefined;
        private _object?;
        get object(): string;
        set object(value: string);
        get objectInput(): string | undefined;
        private _errorHandlingConfig;
        get errorHandlingConfig(): DestinationFlowConfigDestinationConnectorPropertiesSnowflakeErrorHandlingConfigPropertyOutputReference;
        putErrorHandlingConfig(value: DestinationFlowConfigDestinationConnectorPropertiesSnowflakeErrorHandlingConfigProperty): void;
        resetErrorHandlingConfig(): void;
        get errorHandlingConfigInput(): DestinationFlowConfigDestinationConnectorPropertiesSnowflakeErrorHandlingConfigProperty | undefined;
    }
    interface DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigAggregationConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#aggregation_type TfFlow#aggregation_type}
        */
        readonly aggregationType?: string;
    }
    class DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigAggregationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigAggregationConfigProperty | undefined;
        set internalValue(value: DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigAggregationConfigProperty | undefined);
        private _aggregationType?;
        get aggregationType(): string;
        set aggregationType(value: string);
        resetAggregationType(): void;
        get aggregationTypeInput(): string | undefined;
    }
    interface DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPrefixConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#prefix_format TfFlow#prefix_format}
        */
        readonly prefixFormat?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#prefix_hierarchy TfFlow#prefix_hierarchy}
        */
        readonly prefixHierarchy?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#prefix_type TfFlow#prefix_type}
        */
        readonly prefixType: string;
    }
    class DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPrefixConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPrefixConfigProperty | undefined;
        set internalValue(value: DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPrefixConfigProperty | undefined);
        private _prefixFormat?;
        get prefixFormat(): string;
        set prefixFormat(value: string);
        resetPrefixFormat(): void;
        get prefixFormatInput(): string | undefined;
        private _prefixHierarchy?;
        get prefixHierarchy(): string[];
        set prefixHierarchy(value: string[]);
        resetPrefixHierarchy(): void;
        get prefixHierarchyInput(): string[] | undefined;
        private _prefixType?;
        get prefixType(): string;
        set prefixType(value: string);
        get prefixTypeInput(): string | undefined;
    }
    interface DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#file_type TfFlow#file_type}
        */
        readonly fileType?: string;
        /**
        * aggregation_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#aggregation_config TfFlow#aggregation_config}
        */
        readonly aggregationConfig?: DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigAggregationConfigProperty;
        /**
        * prefix_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#prefix_config TfFlow#prefix_config}
        */
        readonly prefixConfig: DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPrefixConfigProperty;
    }
    class DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigProperty | undefined;
        set internalValue(value: DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigProperty | undefined);
        private _fileType?;
        get fileType(): string;
        set fileType(value: string);
        resetFileType(): void;
        get fileTypeInput(): string | undefined;
        private _aggregationConfig;
        get aggregationConfig(): DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigAggregationConfigPropertyOutputReference;
        putAggregationConfig(value: DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigAggregationConfigProperty): void;
        resetAggregationConfig(): void;
        get aggregationConfigInput(): DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigAggregationConfigProperty | undefined;
        private _prefixConfig;
        get prefixConfig(): DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPrefixConfigPropertyOutputReference;
        putPrefixConfig(value: DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPrefixConfigProperty): void;
        get prefixConfigInput(): DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPrefixConfigProperty | undefined;
    }
    interface UpsolverProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_name TfFlow#bucket_name}
        */
        readonly bucketName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_prefix TfFlow#bucket_prefix}
        */
        readonly bucketPrefix?: string;
        /**
        * s3_output_format_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#s3_output_format_config TfFlow#s3_output_format_config}
        */
        readonly s3OutputFormatConfig: DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigProperty;
    }
    class UpsolverPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UpsolverProperty | undefined;
        set internalValue(value: UpsolverProperty | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        get bucketNameInput(): string | undefined;
        private _bucketPrefix?;
        get bucketPrefix(): string;
        set bucketPrefix(value: string);
        resetBucketPrefix(): void;
        get bucketPrefixInput(): string | undefined;
        private _s3OutputFormatConfig;
        get s3OutputFormatConfig(): DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigPropertyOutputReference;
        putS3OutputFormatConfig(value: DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigProperty): void;
        get s3OutputFormatConfigInput(): DestinationFlowConfigDestinationConnectorPropertiesUpsolverS3OutputFormatConfigProperty | undefined;
    }
    interface DestinationFlowConfigDestinationConnectorPropertiesZendeskErrorHandlingConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_name TfFlow#bucket_name}
        */
        readonly bucketName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_prefix TfFlow#bucket_prefix}
        */
        readonly bucketPrefix?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#fail_on_first_destination_error TfFlow#fail_on_first_destination_error}
        */
        readonly failOnFirstDestinationError?: boolean | cdktn.IResolvable;
    }
    class DestinationFlowConfigDestinationConnectorPropertiesZendeskErrorHandlingConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationFlowConfigDestinationConnectorPropertiesZendeskErrorHandlingConfigProperty | undefined;
        set internalValue(value: DestinationFlowConfigDestinationConnectorPropertiesZendeskErrorHandlingConfigProperty | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        resetBucketName(): void;
        get bucketNameInput(): string | undefined;
        private _bucketPrefix?;
        get bucketPrefix(): string;
        set bucketPrefix(value: string);
        resetBucketPrefix(): void;
        get bucketPrefixInput(): string | undefined;
        private _failOnFirstDestinationError?;
        get failOnFirstDestinationError(): boolean | cdktn.IResolvable;
        set failOnFirstDestinationError(value: boolean | cdktn.IResolvable);
        resetFailOnFirstDestinationError(): void;
        get failOnFirstDestinationErrorInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface DestinationFlowConfigDestinationConnectorPropertiesZendeskProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#id_field_names TfFlow#id_field_names}
        */
        readonly idFieldNames?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object TfFlow#object}
        */
        readonly object: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#write_operation_type TfFlow#write_operation_type}
        */
        readonly writeOperationType?: string;
        /**
        * error_handling_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#error_handling_config TfFlow#error_handling_config}
        */
        readonly errorHandlingConfig?: DestinationFlowConfigDestinationConnectorPropertiesZendeskErrorHandlingConfigProperty;
    }
    class DestinationFlowConfigDestinationConnectorPropertiesZendeskPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationFlowConfigDestinationConnectorPropertiesZendeskProperty | undefined;
        set internalValue(value: DestinationFlowConfigDestinationConnectorPropertiesZendeskProperty | undefined);
        private _idFieldNames?;
        get idFieldNames(): string[];
        set idFieldNames(value: string[]);
        resetIdFieldNames(): void;
        get idFieldNamesInput(): string[] | undefined;
        private _object?;
        get object(): string;
        set object(value: string);
        get objectInput(): string | undefined;
        private _writeOperationType?;
        get writeOperationType(): string;
        set writeOperationType(value: string);
        resetWriteOperationType(): void;
        get writeOperationTypeInput(): string | undefined;
        private _errorHandlingConfig;
        get errorHandlingConfig(): DestinationFlowConfigDestinationConnectorPropertiesZendeskErrorHandlingConfigPropertyOutputReference;
        putErrorHandlingConfig(value: DestinationFlowConfigDestinationConnectorPropertiesZendeskErrorHandlingConfigProperty): void;
        resetErrorHandlingConfig(): void;
        get errorHandlingConfigInput(): DestinationFlowConfigDestinationConnectorPropertiesZendeskErrorHandlingConfigProperty | undefined;
    }
    interface DestinationConnectorPropertiesProperty {
        /**
        * custom_connector block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#custom_connector TfFlow#custom_connector}
        */
        readonly customConnector?: DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorProperty;
        /**
        * customer_profiles block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#customer_profiles TfFlow#customer_profiles}
        */
        readonly customerProfiles?: CustomerProfilesProperty;
        /**
        * event_bridge block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#event_bridge TfFlow#event_bridge}
        */
        readonly eventBridge?: EventBridgeProperty;
        /**
        * honeycode block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#honeycode TfFlow#honeycode}
        */
        readonly honeycode?: HoneycodeProperty;
        /**
        * lookout_metrics block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#lookout_metrics TfFlow#lookout_metrics}
        */
        readonly lookoutMetrics?: LookoutMetricsProperty;
        /**
        * marketo block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#marketo TfFlow#marketo}
        */
        readonly marketo?: DestinationFlowConfigDestinationConnectorPropertiesMarketoProperty;
        /**
        * redshift block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#redshift TfFlow#redshift}
        */
        readonly redshift?: RedshiftProperty;
        /**
        * s3 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#s3 TfFlow#s3}
        */
        readonly s3?: DestinationFlowConfigDestinationConnectorPropertiesS3Property;
        /**
        * salesforce block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#salesforce TfFlow#salesforce}
        */
        readonly salesforce?: DestinationFlowConfigDestinationConnectorPropertiesSalesforceProperty;
        /**
        * sapo_data block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#sapo_data TfFlow#sapo_data}
        */
        readonly sapoData?: DestinationFlowConfigDestinationConnectorPropertiesSapoDataProperty;
        /**
        * snowflake block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#snowflake TfFlow#snowflake}
        */
        readonly snowflake?: SnowflakeProperty;
        /**
        * upsolver block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#upsolver TfFlow#upsolver}
        */
        readonly upsolver?: UpsolverProperty;
        /**
        * zendesk block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#zendesk TfFlow#zendesk}
        */
        readonly zendesk?: DestinationFlowConfigDestinationConnectorPropertiesZendeskProperty;
    }
    class DestinationConnectorPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationConnectorPropertiesProperty | undefined;
        set internalValue(value: DestinationConnectorPropertiesProperty | undefined);
        private _customConnector;
        get customConnector(): DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorPropertyOutputReference;
        putCustomConnector(value: DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorProperty): void;
        resetCustomConnector(): void;
        get customConnectorInput(): DestinationFlowConfigDestinationConnectorPropertiesCustomConnectorProperty | undefined;
        private _customerProfiles;
        get customerProfiles(): CustomerProfilesPropertyOutputReference;
        putCustomerProfiles(value: CustomerProfilesProperty): void;
        resetCustomerProfiles(): void;
        get customerProfilesInput(): CustomerProfilesProperty | undefined;
        private _eventBridge;
        get eventBridge(): EventBridgePropertyOutputReference;
        putEventBridge(value: EventBridgeProperty): void;
        resetEventBridge(): void;
        get eventBridgeInput(): EventBridgeProperty | undefined;
        private _honeycode;
        get honeycode(): HoneycodePropertyOutputReference;
        putHoneycode(value: HoneycodeProperty): void;
        resetHoneycode(): void;
        get honeycodeInput(): HoneycodeProperty | undefined;
        private _lookoutMetrics;
        get lookoutMetrics(): LookoutMetricsPropertyOutputReference;
        putLookoutMetrics(value: LookoutMetricsProperty): void;
        resetLookoutMetrics(): void;
        get lookoutMetricsInput(): LookoutMetricsProperty | undefined;
        private _marketo;
        get marketo(): DestinationFlowConfigDestinationConnectorPropertiesMarketoPropertyOutputReference;
        putMarketo(value: DestinationFlowConfigDestinationConnectorPropertiesMarketoProperty): void;
        resetMarketo(): void;
        get marketoInput(): DestinationFlowConfigDestinationConnectorPropertiesMarketoProperty | undefined;
        private _redshift;
        get redshift(): RedshiftPropertyOutputReference;
        putRedshift(value: RedshiftProperty): void;
        resetRedshift(): void;
        get redshiftInput(): RedshiftProperty | undefined;
        private _s3;
        get s3(): DestinationFlowConfigDestinationConnectorPropertiesS3PropertyOutputReference;
        putS3(value: DestinationFlowConfigDestinationConnectorPropertiesS3Property): void;
        resetS3(): void;
        get s3Input(): DestinationFlowConfigDestinationConnectorPropertiesS3Property | undefined;
        private _salesforce;
        get salesforce(): DestinationFlowConfigDestinationConnectorPropertiesSalesforcePropertyOutputReference;
        putSalesforce(value: DestinationFlowConfigDestinationConnectorPropertiesSalesforceProperty): void;
        resetSalesforce(): void;
        get salesforceInput(): DestinationFlowConfigDestinationConnectorPropertiesSalesforceProperty | undefined;
        private _sapoData;
        get sapoData(): DestinationFlowConfigDestinationConnectorPropertiesSapoDataPropertyOutputReference;
        putSapoData(value: DestinationFlowConfigDestinationConnectorPropertiesSapoDataProperty): void;
        resetSapoData(): void;
        get sapoDataInput(): DestinationFlowConfigDestinationConnectorPropertiesSapoDataProperty | undefined;
        private _snowflake;
        get snowflake(): SnowflakePropertyOutputReference;
        putSnowflake(value: SnowflakeProperty): void;
        resetSnowflake(): void;
        get snowflakeInput(): SnowflakeProperty | undefined;
        private _upsolver;
        get upsolver(): UpsolverPropertyOutputReference;
        putUpsolver(value: UpsolverProperty): void;
        resetUpsolver(): void;
        get upsolverInput(): UpsolverProperty | undefined;
        private _zendesk;
        get zendesk(): DestinationFlowConfigDestinationConnectorPropertiesZendeskPropertyOutputReference;
        putZendesk(value: DestinationFlowConfigDestinationConnectorPropertiesZendeskProperty): void;
        resetZendesk(): void;
        get zendeskInput(): DestinationFlowConfigDestinationConnectorPropertiesZendeskProperty | undefined;
    }
    interface DestinationFlowConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#api_version TfFlow#api_version}
        */
        readonly apiVersion?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#connector_profile_name TfFlow#connector_profile_name}
        */
        readonly connectorProfileName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#connector_type TfFlow#connector_type}
        */
        readonly connectorType: string;
        /**
        * destination_connector_properties block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#destination_connector_properties TfFlow#destination_connector_properties}
        */
        readonly destinationConnectorProperties: DestinationConnectorPropertiesProperty;
    }
    class DestinationFlowConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DestinationFlowConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DestinationFlowConfigProperty | cdktn.IResolvable | undefined);
        private _apiVersion?;
        get apiVersion(): string;
        set apiVersion(value: string);
        resetApiVersion(): void;
        get apiVersionInput(): string | undefined;
        private _connectorProfileName?;
        get connectorProfileName(): string;
        set connectorProfileName(value: string);
        resetConnectorProfileName(): void;
        get connectorProfileNameInput(): string | undefined;
        private _connectorType?;
        get connectorType(): string;
        set connectorType(value: string);
        get connectorTypeInput(): string | undefined;
        private _destinationConnectorProperties;
        get destinationConnectorProperties(): DestinationConnectorPropertiesPropertyOutputReference;
        putDestinationConnectorProperties(value: DestinationConnectorPropertiesProperty): void;
        get destinationConnectorPropertiesInput(): DestinationConnectorPropertiesProperty | undefined;
    }
    class DestinationFlowConfigPropertyList extends cdktn.ComplexList {
        internalValue?: DestinationFlowConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DestinationFlowConfigPropertyOutputReference;
    }
    interface GlueDataCatalogProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#database_name TfFlow#database_name}
        */
        readonly databaseName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#role_arn TfFlow#role_arn}
        */
        readonly roleArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#table_prefix TfFlow#table_prefix}
        */
        readonly tablePrefix: string;
    }
    class GlueDataCatalogPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): GlueDataCatalogProperty | undefined;
        set internalValue(value: GlueDataCatalogProperty | undefined);
        private _databaseName?;
        get databaseName(): string;
        set databaseName(value: string);
        get databaseNameInput(): string | undefined;
        private _roleArn?;
        get roleArn(): string;
        set roleArn(value: string);
        get roleArnInput(): string | undefined;
        private _tablePrefix?;
        get tablePrefix(): string;
        set tablePrefix(value: string);
        get tablePrefixInput(): string | undefined;
    }
    interface MetadataCatalogConfigProperty {
        /**
        * glue_data_catalog block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#glue_data_catalog TfFlow#glue_data_catalog}
        */
        readonly glueDataCatalog?: GlueDataCatalogProperty;
    }
    class MetadataCatalogConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MetadataCatalogConfigProperty | undefined;
        set internalValue(value: MetadataCatalogConfigProperty | undefined);
        private _glueDataCatalog;
        get glueDataCatalog(): GlueDataCatalogPropertyOutputReference;
        putGlueDataCatalog(value: GlueDataCatalogProperty): void;
        resetGlueDataCatalog(): void;
        get glueDataCatalogInput(): GlueDataCatalogProperty | undefined;
    }
    interface IncrementalPullConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#datetime_type_field_name TfFlow#datetime_type_field_name}
        */
        readonly datetimeTypeFieldName?: string;
    }
    class IncrementalPullConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): IncrementalPullConfigProperty | undefined;
        set internalValue(value: IncrementalPullConfigProperty | undefined);
        private _datetimeTypeFieldName?;
        get datetimeTypeFieldName(): string;
        set datetimeTypeFieldName(value: string);
        resetDatetimeTypeFieldName(): void;
        get datetimeTypeFieldNameInput(): string | undefined;
    }
    interface AmplitudeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object TfFlow#object}
        */
        readonly object: string;
    }
    class AmplitudePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AmplitudeProperty | undefined;
        set internalValue(value: AmplitudeProperty | undefined);
        private _object?;
        get object(): string;
        set object(value: string);
        get objectInput(): string | undefined;
    }
    interface SourceFlowConfigSourceConnectorPropertiesCustomConnectorProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#custom_properties TfFlow#custom_properties}
        */
        readonly customProperties?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#entity_name TfFlow#entity_name}
        */
        readonly entityName: string;
    }
    class SourceFlowConfigSourceConnectorPropertiesCustomConnectorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceFlowConfigSourceConnectorPropertiesCustomConnectorProperty | undefined;
        set internalValue(value: SourceFlowConfigSourceConnectorPropertiesCustomConnectorProperty | undefined);
        private _customProperties?;
        get customProperties(): {
            [key: string]: string;
        };
        set customProperties(value: {
            [key: string]: string;
        });
        resetCustomProperties(): void;
        get customPropertiesInput(): {
            [key: string]: string;
        } | undefined;
        private _entityName?;
        get entityName(): string;
        set entityName(value: string);
        get entityNameInput(): string | undefined;
    }
    interface DatadogProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object TfFlow#object}
        */
        readonly object: string;
    }
    class DatadogPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DatadogProperty | undefined;
        set internalValue(value: DatadogProperty | undefined);
        private _object?;
        get object(): string;
        set object(value: string);
        get objectInput(): string | undefined;
    }
    interface DynatraceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object TfFlow#object}
        */
        readonly object: string;
    }
    class DynatracePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DynatraceProperty | undefined;
        set internalValue(value: DynatraceProperty | undefined);
        private _object?;
        get object(): string;
        set object(value: string);
        get objectInput(): string | undefined;
    }
    interface GoogleAnalyticsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object TfFlow#object}
        */
        readonly object: string;
    }
    class GoogleAnalyticsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): GoogleAnalyticsProperty | undefined;
        set internalValue(value: GoogleAnalyticsProperty | undefined);
        private _object?;
        get object(): string;
        set object(value: string);
        get objectInput(): string | undefined;
    }
    interface InforNexusProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object TfFlow#object}
        */
        readonly object: string;
    }
    class InforNexusPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InforNexusProperty | undefined;
        set internalValue(value: InforNexusProperty | undefined);
        private _object?;
        get object(): string;
        set object(value: string);
        get objectInput(): string | undefined;
    }
    interface SourceFlowConfigSourceConnectorPropertiesMarketoProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object TfFlow#object}
        */
        readonly object: string;
    }
    class SourceFlowConfigSourceConnectorPropertiesMarketoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceFlowConfigSourceConnectorPropertiesMarketoProperty | undefined;
        set internalValue(value: SourceFlowConfigSourceConnectorPropertiesMarketoProperty | undefined);
        private _object?;
        get object(): string;
        set object(value: string);
        get objectInput(): string | undefined;
    }
    interface S3InputFormatConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#s3_input_file_type TfFlow#s3_input_file_type}
        */
        readonly s3InputFileType?: string;
    }
    class S3InputFormatConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3InputFormatConfigProperty | undefined;
        set internalValue(value: S3InputFormatConfigProperty | undefined);
        private _s3InputFileType?;
        get s3InputFileType(): string;
        set s3InputFileType(value: string);
        resetS3InputFileType(): void;
        get s3InputFileTypeInput(): string | undefined;
    }
    interface SourceFlowConfigSourceConnectorPropertiesS3Property {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_name TfFlow#bucket_name}
        */
        readonly bucketName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#bucket_prefix TfFlow#bucket_prefix}
        */
        readonly bucketPrefix: string;
        /**
        * s3_input_format_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#s3_input_format_config TfFlow#s3_input_format_config}
        */
        readonly s3InputFormatConfig?: S3InputFormatConfigProperty;
    }
    class SourceFlowConfigSourceConnectorPropertiesS3PropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceFlowConfigSourceConnectorPropertiesS3Property | undefined;
        set internalValue(value: SourceFlowConfigSourceConnectorPropertiesS3Property | undefined);
        private _bucketName?;
        get bucketName(): string;
        set bucketName(value: string);
        get bucketNameInput(): string | undefined;
        private _bucketPrefix?;
        get bucketPrefix(): string;
        set bucketPrefix(value: string);
        get bucketPrefixInput(): string | undefined;
        private _s3InputFormatConfig;
        get s3InputFormatConfig(): S3InputFormatConfigPropertyOutputReference;
        putS3InputFormatConfig(value: S3InputFormatConfigProperty): void;
        resetS3InputFormatConfig(): void;
        get s3InputFormatConfigInput(): S3InputFormatConfigProperty | undefined;
    }
    interface SourceFlowConfigSourceConnectorPropertiesSalesforceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#data_transfer_api TfFlow#data_transfer_api}
        */
        readonly dataTransferApi?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#enable_dynamic_field_update TfFlow#enable_dynamic_field_update}
        */
        readonly enableDynamicFieldUpdate?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#include_deleted_records TfFlow#include_deleted_records}
        */
        readonly includeDeletedRecords?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object TfFlow#object}
        */
        readonly object: string;
    }
    class SourceFlowConfigSourceConnectorPropertiesSalesforcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceFlowConfigSourceConnectorPropertiesSalesforceProperty | undefined;
        set internalValue(value: SourceFlowConfigSourceConnectorPropertiesSalesforceProperty | undefined);
        private _dataTransferApi?;
        get dataTransferApi(): string;
        set dataTransferApi(value: string);
        resetDataTransferApi(): void;
        get dataTransferApiInput(): string | undefined;
        private _enableDynamicFieldUpdate?;
        get enableDynamicFieldUpdate(): boolean | cdktn.IResolvable;
        set enableDynamicFieldUpdate(value: boolean | cdktn.IResolvable);
        resetEnableDynamicFieldUpdate(): void;
        get enableDynamicFieldUpdateInput(): boolean | cdktn.IResolvable | undefined;
        private _includeDeletedRecords?;
        get includeDeletedRecords(): boolean | cdktn.IResolvable;
        set includeDeletedRecords(value: boolean | cdktn.IResolvable);
        resetIncludeDeletedRecords(): void;
        get includeDeletedRecordsInput(): boolean | cdktn.IResolvable | undefined;
        private _object?;
        get object(): string;
        set object(value: string);
        get objectInput(): string | undefined;
    }
    interface PaginationConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#max_page_size TfFlow#max_page_size}
        */
        readonly maxPageSize: number;
    }
    class PaginationConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PaginationConfigProperty | undefined;
        set internalValue(value: PaginationConfigProperty | undefined);
        private _maxPageSize?;
        get maxPageSize(): number;
        set maxPageSize(value: number);
        get maxPageSizeInput(): number | undefined;
    }
    interface ParallelismConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#max_page_size TfFlow#max_page_size}
        */
        readonly maxPageSize: number;
    }
    class ParallelismConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ParallelismConfigProperty | undefined;
        set internalValue(value: ParallelismConfigProperty | undefined);
        private _maxPageSize?;
        get maxPageSize(): number;
        set maxPageSize(value: number);
        get maxPageSizeInput(): number | undefined;
    }
    interface SourceFlowConfigSourceConnectorPropertiesSapoDataProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object_path TfFlow#object_path}
        */
        readonly objectPath: string;
        /**
        * pagination_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#pagination_config TfFlow#pagination_config}
        */
        readonly paginationConfig?: PaginationConfigProperty;
        /**
        * parallelism_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#parallelism_config TfFlow#parallelism_config}
        */
        readonly parallelismConfig?: ParallelismConfigProperty;
    }
    class SourceFlowConfigSourceConnectorPropertiesSapoDataPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceFlowConfigSourceConnectorPropertiesSapoDataProperty | undefined;
        set internalValue(value: SourceFlowConfigSourceConnectorPropertiesSapoDataProperty | undefined);
        private _objectPath?;
        get objectPath(): string;
        set objectPath(value: string);
        get objectPathInput(): string | undefined;
        private _paginationConfig;
        get paginationConfig(): PaginationConfigPropertyOutputReference;
        putPaginationConfig(value: PaginationConfigProperty): void;
        resetPaginationConfig(): void;
        get paginationConfigInput(): PaginationConfigProperty | undefined;
        private _parallelismConfig;
        get parallelismConfig(): ParallelismConfigPropertyOutputReference;
        putParallelismConfig(value: ParallelismConfigProperty): void;
        resetParallelismConfig(): void;
        get parallelismConfigInput(): ParallelismConfigProperty | undefined;
    }
    interface ServiceNowProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object TfFlow#object}
        */
        readonly object: string;
    }
    class ServiceNowPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ServiceNowProperty | undefined;
        set internalValue(value: ServiceNowProperty | undefined);
        private _object?;
        get object(): string;
        set object(value: string);
        get objectInput(): string | undefined;
    }
    interface SingularProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object TfFlow#object}
        */
        readonly object: string;
    }
    class SingularPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SingularProperty | undefined;
        set internalValue(value: SingularProperty | undefined);
        private _object?;
        get object(): string;
        set object(value: string);
        get objectInput(): string | undefined;
    }
    interface SlackProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object TfFlow#object}
        */
        readonly object: string;
    }
    class SlackPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SlackProperty | undefined;
        set internalValue(value: SlackProperty | undefined);
        private _object?;
        get object(): string;
        set object(value: string);
        get objectInput(): string | undefined;
    }
    interface TrendmicroProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object TfFlow#object}
        */
        readonly object: string;
    }
    class TrendmicroPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TrendmicroProperty | undefined;
        set internalValue(value: TrendmicroProperty | undefined);
        private _object?;
        get object(): string;
        set object(value: string);
        get objectInput(): string | undefined;
    }
    interface VeevaProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#document_type TfFlow#document_type}
        */
        readonly documentType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#include_all_versions TfFlow#include_all_versions}
        */
        readonly includeAllVersions?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#include_renditions TfFlow#include_renditions}
        */
        readonly includeRenditions?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#include_source_files TfFlow#include_source_files}
        */
        readonly includeSourceFiles?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object TfFlow#object}
        */
        readonly object: string;
    }
    class VeevaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VeevaProperty | undefined;
        set internalValue(value: VeevaProperty | undefined);
        private _documentType?;
        get documentType(): string;
        set documentType(value: string);
        resetDocumentType(): void;
        get documentTypeInput(): string | undefined;
        private _includeAllVersions?;
        get includeAllVersions(): boolean | cdktn.IResolvable;
        set includeAllVersions(value: boolean | cdktn.IResolvable);
        resetIncludeAllVersions(): void;
        get includeAllVersionsInput(): boolean | cdktn.IResolvable | undefined;
        private _includeRenditions?;
        get includeRenditions(): boolean | cdktn.IResolvable;
        set includeRenditions(value: boolean | cdktn.IResolvable);
        resetIncludeRenditions(): void;
        get includeRenditionsInput(): boolean | cdktn.IResolvable | undefined;
        private _includeSourceFiles?;
        get includeSourceFiles(): boolean | cdktn.IResolvable;
        set includeSourceFiles(value: boolean | cdktn.IResolvable);
        resetIncludeSourceFiles(): void;
        get includeSourceFilesInput(): boolean | cdktn.IResolvable | undefined;
        private _object?;
        get object(): string;
        set object(value: string);
        get objectInput(): string | undefined;
    }
    interface SourceFlowConfigSourceConnectorPropertiesZendeskProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#object TfFlow#object}
        */
        readonly object: string;
    }
    class SourceFlowConfigSourceConnectorPropertiesZendeskPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceFlowConfigSourceConnectorPropertiesZendeskProperty | undefined;
        set internalValue(value: SourceFlowConfigSourceConnectorPropertiesZendeskProperty | undefined);
        private _object?;
        get object(): string;
        set object(value: string);
        get objectInput(): string | undefined;
    }
    interface SourceConnectorPropertiesProperty {
        /**
        * amplitude block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#amplitude TfFlow#amplitude}
        */
        readonly amplitude?: AmplitudeProperty;
        /**
        * custom_connector block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#custom_connector TfFlow#custom_connector}
        */
        readonly customConnector?: SourceFlowConfigSourceConnectorPropertiesCustomConnectorProperty;
        /**
        * datadog block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#datadog TfFlow#datadog}
        */
        readonly datadog?: DatadogProperty;
        /**
        * dynatrace block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#dynatrace TfFlow#dynatrace}
        */
        readonly dynatrace?: DynatraceProperty;
        /**
        * google_analytics block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#google_analytics TfFlow#google_analytics}
        */
        readonly googleAnalytics?: GoogleAnalyticsProperty;
        /**
        * infor_nexus block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#infor_nexus TfFlow#infor_nexus}
        */
        readonly inforNexus?: InforNexusProperty;
        /**
        * marketo block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#marketo TfFlow#marketo}
        */
        readonly marketo?: SourceFlowConfigSourceConnectorPropertiesMarketoProperty;
        /**
        * s3 block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#s3 TfFlow#s3}
        */
        readonly s3?: SourceFlowConfigSourceConnectorPropertiesS3Property;
        /**
        * salesforce block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#salesforce TfFlow#salesforce}
        */
        readonly salesforce?: SourceFlowConfigSourceConnectorPropertiesSalesforceProperty;
        /**
        * sapo_data block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#sapo_data TfFlow#sapo_data}
        */
        readonly sapoData?: SourceFlowConfigSourceConnectorPropertiesSapoDataProperty;
        /**
        * service_now block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#service_now TfFlow#service_now}
        */
        readonly serviceNow?: ServiceNowProperty;
        /**
        * singular block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#singular TfFlow#singular}
        */
        readonly singular?: SingularProperty;
        /**
        * slack block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#slack TfFlow#slack}
        */
        readonly slack?: SlackProperty;
        /**
        * trendmicro block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#trendmicro TfFlow#trendmicro}
        */
        readonly trendmicro?: TrendmicroProperty;
        /**
        * veeva block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#veeva TfFlow#veeva}
        */
        readonly veeva?: VeevaProperty;
        /**
        * zendesk block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#zendesk TfFlow#zendesk}
        */
        readonly zendesk?: SourceFlowConfigSourceConnectorPropertiesZendeskProperty;
    }
    class SourceConnectorPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceConnectorPropertiesProperty | undefined;
        set internalValue(value: SourceConnectorPropertiesProperty | undefined);
        private _amplitude;
        get amplitude(): AmplitudePropertyOutputReference;
        putAmplitude(value: AmplitudeProperty): void;
        resetAmplitude(): void;
        get amplitudeInput(): AmplitudeProperty | undefined;
        private _customConnector;
        get customConnector(): SourceFlowConfigSourceConnectorPropertiesCustomConnectorPropertyOutputReference;
        putCustomConnector(value: SourceFlowConfigSourceConnectorPropertiesCustomConnectorProperty): void;
        resetCustomConnector(): void;
        get customConnectorInput(): SourceFlowConfigSourceConnectorPropertiesCustomConnectorProperty | undefined;
        private _datadog;
        get datadog(): DatadogPropertyOutputReference;
        putDatadog(value: DatadogProperty): void;
        resetDatadog(): void;
        get datadogInput(): DatadogProperty | undefined;
        private _dynatrace;
        get dynatrace(): DynatracePropertyOutputReference;
        putDynatrace(value: DynatraceProperty): void;
        resetDynatrace(): void;
        get dynatraceInput(): DynatraceProperty | undefined;
        private _googleAnalytics;
        get googleAnalytics(): GoogleAnalyticsPropertyOutputReference;
        putGoogleAnalytics(value: GoogleAnalyticsProperty): void;
        resetGoogleAnalytics(): void;
        get googleAnalyticsInput(): GoogleAnalyticsProperty | undefined;
        private _inforNexus;
        get inforNexus(): InforNexusPropertyOutputReference;
        putInforNexus(value: InforNexusProperty): void;
        resetInforNexus(): void;
        get inforNexusInput(): InforNexusProperty | undefined;
        private _marketo;
        get marketo(): SourceFlowConfigSourceConnectorPropertiesMarketoPropertyOutputReference;
        putMarketo(value: SourceFlowConfigSourceConnectorPropertiesMarketoProperty): void;
        resetMarketo(): void;
        get marketoInput(): SourceFlowConfigSourceConnectorPropertiesMarketoProperty | undefined;
        private _s3;
        get s3(): SourceFlowConfigSourceConnectorPropertiesS3PropertyOutputReference;
        putS3(value: SourceFlowConfigSourceConnectorPropertiesS3Property): void;
        resetS3(): void;
        get s3Input(): SourceFlowConfigSourceConnectorPropertiesS3Property | undefined;
        private _salesforce;
        get salesforce(): SourceFlowConfigSourceConnectorPropertiesSalesforcePropertyOutputReference;
        putSalesforce(value: SourceFlowConfigSourceConnectorPropertiesSalesforceProperty): void;
        resetSalesforce(): void;
        get salesforceInput(): SourceFlowConfigSourceConnectorPropertiesSalesforceProperty | undefined;
        private _sapoData;
        get sapoData(): SourceFlowConfigSourceConnectorPropertiesSapoDataPropertyOutputReference;
        putSapoData(value: SourceFlowConfigSourceConnectorPropertiesSapoDataProperty): void;
        resetSapoData(): void;
        get sapoDataInput(): SourceFlowConfigSourceConnectorPropertiesSapoDataProperty | undefined;
        private _serviceNow;
        get serviceNow(): ServiceNowPropertyOutputReference;
        putServiceNow(value: ServiceNowProperty): void;
        resetServiceNow(): void;
        get serviceNowInput(): ServiceNowProperty | undefined;
        private _singular;
        get singular(): SingularPropertyOutputReference;
        putSingular(value: SingularProperty): void;
        resetSingular(): void;
        get singularInput(): SingularProperty | undefined;
        private _slack;
        get slack(): SlackPropertyOutputReference;
        putSlack(value: SlackProperty): void;
        resetSlack(): void;
        get slackInput(): SlackProperty | undefined;
        private _trendmicro;
        get trendmicro(): TrendmicroPropertyOutputReference;
        putTrendmicro(value: TrendmicroProperty): void;
        resetTrendmicro(): void;
        get trendmicroInput(): TrendmicroProperty | undefined;
        private _veeva;
        get veeva(): VeevaPropertyOutputReference;
        putVeeva(value: VeevaProperty): void;
        resetVeeva(): void;
        get veevaInput(): VeevaProperty | undefined;
        private _zendesk;
        get zendesk(): SourceFlowConfigSourceConnectorPropertiesZendeskPropertyOutputReference;
        putZendesk(value: SourceFlowConfigSourceConnectorPropertiesZendeskProperty): void;
        resetZendesk(): void;
        get zendeskInput(): SourceFlowConfigSourceConnectorPropertiesZendeskProperty | undefined;
    }
    interface SourceFlowConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#api_version TfFlow#api_version}
        */
        readonly apiVersion?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#connector_profile_name TfFlow#connector_profile_name}
        */
        readonly connectorProfileName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#connector_type TfFlow#connector_type}
        */
        readonly connectorType: string;
        /**
        * incremental_pull_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#incremental_pull_config TfFlow#incremental_pull_config}
        */
        readonly incrementalPullConfig?: IncrementalPullConfigProperty;
        /**
        * source_connector_properties block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#source_connector_properties TfFlow#source_connector_properties}
        */
        readonly sourceConnectorProperties: SourceConnectorPropertiesProperty;
    }
    class SourceFlowConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceFlowConfigProperty | undefined;
        set internalValue(value: SourceFlowConfigProperty | undefined);
        private _apiVersion?;
        get apiVersion(): string;
        set apiVersion(value: string);
        resetApiVersion(): void;
        get apiVersionInput(): string | undefined;
        private _connectorProfileName?;
        get connectorProfileName(): string;
        set connectorProfileName(value: string);
        resetConnectorProfileName(): void;
        get connectorProfileNameInput(): string | undefined;
        private _connectorType?;
        get connectorType(): string;
        set connectorType(value: string);
        get connectorTypeInput(): string | undefined;
        private _incrementalPullConfig;
        get incrementalPullConfig(): IncrementalPullConfigPropertyOutputReference;
        putIncrementalPullConfig(value: IncrementalPullConfigProperty): void;
        resetIncrementalPullConfig(): void;
        get incrementalPullConfigInput(): IncrementalPullConfigProperty | undefined;
        private _sourceConnectorProperties;
        get sourceConnectorProperties(): SourceConnectorPropertiesPropertyOutputReference;
        putSourceConnectorProperties(value: SourceConnectorPropertiesProperty): void;
        get sourceConnectorPropertiesInput(): SourceConnectorPropertiesProperty | undefined;
    }
    interface ConnectorOperatorProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#amplitude TfFlow#amplitude}
        */
        readonly amplitude?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#custom_connector TfFlow#custom_connector}
        */
        readonly customConnector?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#datadog TfFlow#datadog}
        */
        readonly datadog?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#dynatrace TfFlow#dynatrace}
        */
        readonly dynatrace?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#google_analytics TfFlow#google_analytics}
        */
        readonly googleAnalytics?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#infor_nexus TfFlow#infor_nexus}
        */
        readonly inforNexus?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#marketo TfFlow#marketo}
        */
        readonly marketo?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#s3 TfFlow#s3}
        */
        readonly s3?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#salesforce TfFlow#salesforce}
        */
        readonly salesforce?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#sapo_data TfFlow#sapo_data}
        */
        readonly sapoData?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#service_now TfFlow#service_now}
        */
        readonly serviceNow?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#singular TfFlow#singular}
        */
        readonly singular?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#slack TfFlow#slack}
        */
        readonly slack?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#trendmicro TfFlow#trendmicro}
        */
        readonly trendmicro?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#veeva TfFlow#veeva}
        */
        readonly veeva?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#zendesk TfFlow#zendesk}
        */
        readonly zendesk?: string;
    }
    class ConnectorOperatorPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConnectorOperatorProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConnectorOperatorProperty | cdktn.IResolvable | undefined);
        private _amplitude?;
        get amplitude(): string;
        set amplitude(value: string);
        resetAmplitude(): void;
        get amplitudeInput(): string | undefined;
        private _customConnector?;
        get customConnector(): string;
        set customConnector(value: string);
        resetCustomConnector(): void;
        get customConnectorInput(): string | undefined;
        private _datadog?;
        get datadog(): string;
        set datadog(value: string);
        resetDatadog(): void;
        get datadogInput(): string | undefined;
        private _dynatrace?;
        get dynatrace(): string;
        set dynatrace(value: string);
        resetDynatrace(): void;
        get dynatraceInput(): string | undefined;
        private _googleAnalytics?;
        get googleAnalytics(): string;
        set googleAnalytics(value: string);
        resetGoogleAnalytics(): void;
        get googleAnalyticsInput(): string | undefined;
        private _inforNexus?;
        get inforNexus(): string;
        set inforNexus(value: string);
        resetInforNexus(): void;
        get inforNexusInput(): string | undefined;
        private _marketo?;
        get marketo(): string;
        set marketo(value: string);
        resetMarketo(): void;
        get marketoInput(): string | undefined;
        private _s3?;
        get s3(): string;
        set s3(value: string);
        resetS3(): void;
        get s3Input(): string | undefined;
        private _salesforce?;
        get salesforce(): string;
        set salesforce(value: string);
        resetSalesforce(): void;
        get salesforceInput(): string | undefined;
        private _sapoData?;
        get sapoData(): string;
        set sapoData(value: string);
        resetSapoData(): void;
        get sapoDataInput(): string | undefined;
        private _serviceNow?;
        get serviceNow(): string;
        set serviceNow(value: string);
        resetServiceNow(): void;
        get serviceNowInput(): string | undefined;
        private _singular?;
        get singular(): string;
        set singular(value: string);
        resetSingular(): void;
        get singularInput(): string | undefined;
        private _slack?;
        get slack(): string;
        set slack(value: string);
        resetSlack(): void;
        get slackInput(): string | undefined;
        private _trendmicro?;
        get trendmicro(): string;
        set trendmicro(value: string);
        resetTrendmicro(): void;
        get trendmicroInput(): string | undefined;
        private _veeva?;
        get veeva(): string;
        set veeva(value: string);
        resetVeeva(): void;
        get veevaInput(): string | undefined;
        private _zendesk?;
        get zendesk(): string;
        set zendesk(value: string);
        resetZendesk(): void;
        get zendeskInput(): string | undefined;
    }
    class ConnectorOperatorPropertyList extends cdktn.ComplexList {
        internalValue?: ConnectorOperatorProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConnectorOperatorPropertyOutputReference;
    }
    interface TaskProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#destination_field TfFlow#destination_field}
        */
        readonly destinationField?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#source_fields TfFlow#source_fields}
        */
        readonly sourceFields?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#task_properties TfFlow#task_properties}
        */
        readonly taskProperties?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#task_type TfFlow#task_type}
        */
        readonly taskType: string;
        /**
        * connector_operator block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#connector_operator TfFlow#connector_operator}
        */
        readonly connectorOperator?: ConnectorOperatorProperty[] | cdktn.IResolvable;
    }
    class TaskPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TaskProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TaskProperty | cdktn.IResolvable | undefined);
        private _destinationField?;
        get destinationField(): string;
        set destinationField(value: string);
        resetDestinationField(): void;
        get destinationFieldInput(): string | undefined;
        private _sourceFields?;
        get sourceFields(): string[];
        set sourceFields(value: string[]);
        resetSourceFields(): void;
        get sourceFieldsInput(): string[] | undefined;
        private _taskProperties?;
        get taskProperties(): {
            [key: string]: string;
        };
        set taskProperties(value: {
            [key: string]: string;
        });
        resetTaskProperties(): void;
        get taskPropertiesInput(): {
            [key: string]: string;
        } | undefined;
        private _taskType?;
        get taskType(): string;
        set taskType(value: string);
        get taskTypeInput(): string | undefined;
        private _connectorOperator;
        get connectorOperator(): ConnectorOperatorPropertyList;
        putConnectorOperator(value: ConnectorOperatorProperty[] | cdktn.IResolvable): void;
        resetConnectorOperator(): void;
        get connectorOperatorInput(): cdktn.IResolvable | ConnectorOperatorProperty[] | undefined;
    }
    class TaskPropertyList extends cdktn.ComplexList {
        internalValue?: TaskProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TaskPropertyOutputReference;
    }
    interface ScheduledProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#data_pull_mode TfFlow#data_pull_mode}
        */
        readonly dataPullMode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#first_execution_from TfFlow#first_execution_from}
        */
        readonly firstExecutionFrom?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#schedule_end_time TfFlow#schedule_end_time}
        */
        readonly scheduleEndTime?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#schedule_expression TfFlow#schedule_expression}
        */
        readonly scheduleExpression: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#schedule_offset TfFlow#schedule_offset}
        */
        readonly scheduleOffset?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#schedule_start_time TfFlow#schedule_start_time}
        */
        readonly scheduleStartTime?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#timezone TfFlow#timezone}
        */
        readonly timezone?: string;
    }
    class ScheduledPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ScheduledProperty | undefined;
        set internalValue(value: ScheduledProperty | undefined);
        private _dataPullMode?;
        get dataPullMode(): string;
        set dataPullMode(value: string);
        resetDataPullMode(): void;
        get dataPullModeInput(): string | undefined;
        private _firstExecutionFrom?;
        get firstExecutionFrom(): string;
        set firstExecutionFrom(value: string);
        resetFirstExecutionFrom(): void;
        get firstExecutionFromInput(): string | undefined;
        private _scheduleEndTime?;
        get scheduleEndTime(): string;
        set scheduleEndTime(value: string);
        resetScheduleEndTime(): void;
        get scheduleEndTimeInput(): string | undefined;
        private _scheduleExpression?;
        get scheduleExpression(): string;
        set scheduleExpression(value: string);
        get scheduleExpressionInput(): string | undefined;
        private _scheduleOffset?;
        get scheduleOffset(): number;
        set scheduleOffset(value: number);
        resetScheduleOffset(): void;
        get scheduleOffsetInput(): number | undefined;
        private _scheduleStartTime?;
        get scheduleStartTime(): string;
        set scheduleStartTime(value: string);
        resetScheduleStartTime(): void;
        get scheduleStartTimeInput(): string | undefined;
        private _timezone?;
        get timezone(): string;
        set timezone(value: string);
        resetTimezone(): void;
        get timezoneInput(): string | undefined;
    }
    interface TriggerPropertiesProperty {
        /**
        * scheduled block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#scheduled TfFlow#scheduled}
        */
        readonly scheduled?: ScheduledProperty;
    }
    class TriggerPropertiesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TriggerPropertiesProperty | undefined;
        set internalValue(value: TriggerPropertiesProperty | undefined);
        private _scheduled;
        get scheduled(): ScheduledPropertyOutputReference;
        putScheduled(value: ScheduledProperty): void;
        resetScheduled(): void;
        get scheduledInput(): ScheduledProperty | undefined;
    }
    interface TriggerConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#trigger_type TfFlow#trigger_type}
        */
        readonly triggerType: string;
        /**
        * trigger_properties block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/appflow_flow#trigger_properties TfFlow#trigger_properties}
        */
        readonly triggerProperties?: TriggerPropertiesProperty;
    }
    class TriggerConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TriggerConfigProperty | undefined;
        set internalValue(value: TriggerConfigProperty | undefined);
        private _triggerType?;
        get triggerType(): string;
        set triggerType(value: string);
        get triggerTypeInput(): string | undefined;
        private _triggerProperties;
        get triggerProperties(): TriggerPropertiesPropertyOutputReference;
        putTriggerProperties(value: TriggerPropertiesProperty): void;
        resetTriggerProperties(): void;
        get triggerPropertiesInput(): TriggerPropertiesProperty | undefined;
    }
}
