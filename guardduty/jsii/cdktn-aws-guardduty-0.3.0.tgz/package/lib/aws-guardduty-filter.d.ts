import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsFilterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_filter#action AwsFilter#action}
    */
    readonly action: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_filter#description AwsFilter#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_filter#detector_id AwsFilter#detector_id}
    */
    readonly detectorId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_filter#id AwsFilter#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_filter#name AwsFilter#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_filter#rank AwsFilter#rank}
    */
    readonly rank: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_filter#region AwsFilter#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_filter#tags AwsFilter#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_filter#tags_all AwsFilter#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * finding_criteria block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_filter#finding_criteria AwsFilter#finding_criteria}
    */
    readonly findingCriteria: AwsFilter.FindingCriteriaProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_filter aws_guardduty_filter}
*/
export declare class AwsFilter extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_guardduty_filter";
    /**
    * Generates CDKTN code for importing a AwsFilter resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsFilter to import
    * @param importFromId The id of the existing AwsFilter that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_filter#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsFilter to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_filter aws_guardduty_filter} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsFilterConfig
    */
    constructor(scope: Construct, id: string, config: AwsFilterConfig);
    private _action?;
    get action(): string;
    set action(value: string);
    get actionInput(): string | undefined;
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _detectorId?;
    get detectorId(): string;
    set detectorId(value: string);
    get detectorIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _rank?;
    get rank(): number;
    set rank(value: number);
    get rankInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _findingCriteria;
    get findingCriteria(): AwsFilter.FindingCriteriaPropertyOutputReference;
    putFindingCriteria(value: AwsFilter.FindingCriteriaProperty): void;
    get findingCriteriaInput(): AwsFilter.FindingCriteriaProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsFilterCriterionPropertyToTerraform(struct?: AwsFilter.CriterionProperty | cdktn.IResolvable): any;
export declare function awsFilterCriterionPropertyToHclTerraform(struct?: AwsFilter.CriterionProperty | cdktn.IResolvable): any;
export declare function awsFilterFindingCriteriaPropertyToTerraform(struct?: AwsFilter.FindingCriteriaPropertyOutputReference | AwsFilter.FindingCriteriaProperty): any;
export declare function awsFilterFindingCriteriaPropertyToHclTerraform(struct?: AwsFilter.FindingCriteriaPropertyOutputReference | AwsFilter.FindingCriteriaProperty): any;
export declare namespace AwsFilter {
    interface CriterionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_filter#equals AwsFilter#equals}
        */
        readonly equalTo?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_filter#field AwsFilter#field}
        */
        readonly field: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_filter#greater_than AwsFilter#greater_than}
        */
        readonly greaterThan?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_filter#greater_than_or_equal AwsFilter#greater_than_or_equal}
        */
        readonly greaterThanOrEqual?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_filter#less_than AwsFilter#less_than}
        */
        readonly lessThan?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_filter#less_than_or_equal AwsFilter#less_than_or_equal}
        */
        readonly lessThanOrEqual?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_filter#matches AwsFilter#matches}
        */
        readonly matches?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_filter#not_equals AwsFilter#not_equals}
        */
        readonly notEquals?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_filter#not_matches AwsFilter#not_matches}
        */
        readonly notMatches?: string[];
    }
    class CriterionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CriterionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CriterionProperty | cdktn.IResolvable | undefined);
        private _equals?;
        get equalTo(): string[];
        set equalTo(value: string[]);
        resetEqualTo(): void;
        get equalToInput(): string[] | undefined;
        private _field?;
        get field(): string;
        set field(value: string);
        get fieldInput(): string | undefined;
        private _greaterThan?;
        get greaterThan(): string;
        set greaterThan(value: string);
        resetGreaterThan(): void;
        get greaterThanInput(): string | undefined;
        private _greaterThanOrEqual?;
        get greaterThanOrEqual(): string;
        set greaterThanOrEqual(value: string);
        resetGreaterThanOrEqual(): void;
        get greaterThanOrEqualInput(): string | undefined;
        private _lessThan?;
        get lessThan(): string;
        set lessThan(value: string);
        resetLessThan(): void;
        get lessThanInput(): string | undefined;
        private _lessThanOrEqual?;
        get lessThanOrEqual(): string;
        set lessThanOrEqual(value: string);
        resetLessThanOrEqual(): void;
        get lessThanOrEqualInput(): string | undefined;
        private _matches?;
        get matches(): string[];
        set matches(value: string[]);
        resetMatches(): void;
        get matchesInput(): string[] | undefined;
        private _notEquals?;
        get notEquals(): string[];
        set notEquals(value: string[]);
        resetNotEquals(): void;
        get notEqualsInput(): string[] | undefined;
        private _notMatches?;
        get notMatches(): string[];
        set notMatches(value: string[]);
        resetNotMatches(): void;
        get notMatchesInput(): string[] | undefined;
    }
    class CriterionPropertyList extends cdktn.ComplexList {
        internalValue?: CriterionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CriterionPropertyOutputReference;
    }
    interface FindingCriteriaProperty {
        /**
        * criterion block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_filter#criterion AwsFilter#criterion}
        */
        readonly criterion: CriterionProperty[] | cdktn.IResolvable;
    }
    class FindingCriteriaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): FindingCriteriaProperty | undefined;
        set internalValue(value: FindingCriteriaProperty | undefined);
        private _criterion;
        get criterion(): CriterionPropertyList;
        putCriterion(value: CriterionProperty[] | cdktn.IResolvable): void;
        get criterionInput(): cdktn.IResolvable | CriterionProperty[] | undefined;
    }
}
