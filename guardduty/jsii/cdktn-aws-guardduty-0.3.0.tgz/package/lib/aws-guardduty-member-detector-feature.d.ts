import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsMemberDetectorFeatureConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_member_detector_feature#account_id AwsMemberDetectorFeature#account_id}
    */
    readonly accountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_member_detector_feature#detector_id AwsMemberDetectorFeature#detector_id}
    */
    readonly detectorId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_member_detector_feature#name AwsMemberDetectorFeature#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_member_detector_feature#region AwsMemberDetectorFeature#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_member_detector_feature#status AwsMemberDetectorFeature#status}
    */
    readonly status: string;
    /**
    * additional_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_member_detector_feature#additional_configuration AwsMemberDetectorFeature#additional_configuration}
    */
    readonly additionalConfiguration?: AwsMemberDetectorFeature.AdditionalConfigurationProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_member_detector_feature aws_guardduty_member_detector_feature}
*/
export declare class AwsMemberDetectorFeature extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_guardduty_member_detector_feature";
    /**
    * Generates CDKTN code for importing a AwsMemberDetectorFeature resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsMemberDetectorFeature to import
    * @param importFromId The id of the existing AwsMemberDetectorFeature that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_member_detector_feature#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsMemberDetectorFeature to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_member_detector_feature aws_guardduty_member_detector_feature} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsMemberDetectorFeatureConfig
    */
    constructor(scope: Construct, id: string, config: AwsMemberDetectorFeatureConfig);
    private _accountId?;
    get accountId(): string;
    set accountId(value: string);
    get accountIdInput(): string | undefined;
    private _detectorId?;
    get detectorId(): string;
    set detectorId(value: string);
    get detectorIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    get statusInput(): string | undefined;
    private _additionalConfiguration;
    get additionalConfiguration(): AwsMemberDetectorFeature.AdditionalConfigurationPropertyList;
    putAdditionalConfiguration(value: AwsMemberDetectorFeature.AdditionalConfigurationProperty[] | cdktn.IResolvable): void;
    resetAdditionalConfiguration(): void;
    get additionalConfigurationInput(): cdktn.IResolvable | AwsMemberDetectorFeature.AdditionalConfigurationProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsMemberDetectorFeatureAdditionalConfigurationPropertyToTerraform(struct?: AwsMemberDetectorFeature.AdditionalConfigurationProperty | cdktn.IResolvable): any;
export declare function awsMemberDetectorFeatureAdditionalConfigurationPropertyToHclTerraform(struct?: AwsMemberDetectorFeature.AdditionalConfigurationProperty | cdktn.IResolvable): any;
export declare namespace AwsMemberDetectorFeature {
    interface AdditionalConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_member_detector_feature#name AwsMemberDetectorFeature#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/guardduty_member_detector_feature#status AwsMemberDetectorFeature#status}
        */
        readonly status: string;
    }
    class AdditionalConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AdditionalConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AdditionalConfigurationProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _status?;
        get status(): string;
        set status(value: string);
        get statusInput(): string | undefined;
    }
    class AdditionalConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: AdditionalConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AdditionalConfigurationPropertyOutputReference;
    }
}
