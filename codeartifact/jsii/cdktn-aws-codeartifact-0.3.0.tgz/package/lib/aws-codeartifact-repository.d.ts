import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsRepositoryConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeartifact_repository#description AwsRepository#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeartifact_repository#domain AwsRepository#domain}
    */
    readonly domain: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeartifact_repository#domain_owner AwsRepository#domain_owner}
    */
    readonly domainOwner?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeartifact_repository#id AwsRepository#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeartifact_repository#region AwsRepository#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeartifact_repository#repository AwsRepository#repository}
    */
    readonly repository: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeartifact_repository#tags AwsRepository#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeartifact_repository#tags_all AwsRepository#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * external_connections block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeartifact_repository#external_connections AwsRepository#external_connections}
    */
    readonly externalConnections?: AwsRepository.ExternalConnectionsProperty;
    /**
    * upstream block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeartifact_repository#upstream AwsRepository#upstream}
    */
    readonly upstream?: AwsRepository.UpstreamProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeartifact_repository aws_codeartifact_repository}
*/
export declare class AwsRepository extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_codeartifact_repository";
    /**
    * Generates CDKTN code for importing a AwsRepository resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsRepository to import
    * @param importFromId The id of the existing AwsRepository that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeartifact_repository#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsRepository to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeartifact_repository aws_codeartifact_repository} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsRepositoryConfig
    */
    constructor(scope: Construct, id: string, config: AwsRepositoryConfig);
    get administratorAccount(): string;
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _domain?;
    get domain(): string;
    set domain(value: string);
    get domainInput(): string | undefined;
    private _domainOwner?;
    get domainOwner(): string;
    set domainOwner(value: string);
    resetDomainOwner(): void;
    get domainOwnerInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _repository?;
    get repository(): string;
    set repository(value: string);
    get repositoryInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _externalConnections;
    get externalConnections(): AwsRepository.ExternalConnectionsPropertyOutputReference;
    putExternalConnections(value: AwsRepository.ExternalConnectionsProperty): void;
    resetExternalConnections(): void;
    get externalConnectionsInput(): AwsRepository.ExternalConnectionsProperty | undefined;
    private _upstream;
    get upstream(): AwsRepository.UpstreamPropertyList;
    putUpstream(value: AwsRepository.UpstreamProperty[] | cdktn.IResolvable): void;
    resetUpstream(): void;
    get upstreamInput(): cdktn.IResolvable | AwsRepository.UpstreamProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsRepositoryExternalConnectionsPropertyToTerraform(struct?: AwsRepository.ExternalConnectionsPropertyOutputReference | AwsRepository.ExternalConnectionsProperty): any;
export declare function awsRepositoryExternalConnectionsPropertyToHclTerraform(struct?: AwsRepository.ExternalConnectionsPropertyOutputReference | AwsRepository.ExternalConnectionsProperty): any;
export declare function awsRepositoryUpstreamPropertyToTerraform(struct?: AwsRepository.UpstreamProperty | cdktn.IResolvable): any;
export declare function awsRepositoryUpstreamPropertyToHclTerraform(struct?: AwsRepository.UpstreamProperty | cdktn.IResolvable): any;
export declare namespace AwsRepository {
    interface ExternalConnectionsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeartifact_repository#external_connection_name AwsRepository#external_connection_name}
        */
        readonly externalConnectionName: string;
    }
    class ExternalConnectionsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ExternalConnectionsProperty | undefined;
        set internalValue(value: ExternalConnectionsProperty | undefined);
        private _externalConnectionName?;
        get externalConnectionName(): string;
        set externalConnectionName(value: string);
        get externalConnectionNameInput(): string | undefined;
        get packageFormat(): string;
        get status(): string;
    }
    interface UpstreamProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/codeartifact_repository#repository_name AwsRepository#repository_name}
        */
        readonly repositoryName: string;
    }
    class UpstreamPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UpstreamProperty | cdktn.IResolvable | undefined;
        set internalValue(value: UpstreamProperty | cdktn.IResolvable | undefined);
        private _repositoryName?;
        get repositoryName(): string;
        set repositoryName(value: string);
        get repositoryNameInput(): string | undefined;
    }
    class UpstreamPropertyList extends cdktn.ComplexList {
        internalValue?: UpstreamProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UpstreamPropertyOutputReference;
    }
}
