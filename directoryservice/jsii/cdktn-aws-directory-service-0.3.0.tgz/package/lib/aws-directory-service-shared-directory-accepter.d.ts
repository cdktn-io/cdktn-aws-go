import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsSharedDirectoryAccepterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_shared_directory_accepter#id AwsSharedDirectoryAccepter#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_shared_directory_accepter#region AwsSharedDirectoryAccepter#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_shared_directory_accepter#shared_directory_id AwsSharedDirectoryAccepter#shared_directory_id}
    */
    readonly sharedDirectoryId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_shared_directory_accepter#timeouts AwsSharedDirectoryAccepter#timeouts}
    */
    readonly timeouts?: AwsSharedDirectoryAccepter.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_shared_directory_accepter aws_directory_service_shared_directory_accepter}
*/
export declare class AwsSharedDirectoryAccepter extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_directory_service_shared_directory_accepter";
    /**
    * Generates CDKTN code for importing a AwsSharedDirectoryAccepter resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsSharedDirectoryAccepter to import
    * @param importFromId The id of the existing AwsSharedDirectoryAccepter that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_shared_directory_accepter#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsSharedDirectoryAccepter to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_shared_directory_accepter aws_directory_service_shared_directory_accepter} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsSharedDirectoryAccepterConfig
    */
    constructor(scope: Construct, id: string, config: AwsSharedDirectoryAccepterConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get method(): string;
    get notes(): string;
    get ownerAccountId(): string;
    get ownerDirectoryId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _sharedDirectoryId?;
    get sharedDirectoryId(): string;
    set sharedDirectoryId(value: string);
    get sharedDirectoryIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): AwsSharedDirectoryAccepter.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsSharedDirectoryAccepter.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsSharedDirectoryAccepter.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsSharedDirectoryAccepterTimeoutsPropertyToTerraform(struct?: AwsSharedDirectoryAccepter.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsSharedDirectoryAccepterTimeoutsPropertyToHclTerraform(struct?: AwsSharedDirectoryAccepter.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsSharedDirectoryAccepter {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_shared_directory_accepter#create AwsSharedDirectoryAccepter#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_shared_directory_accepter#delete AwsSharedDirectoryAccepter#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
