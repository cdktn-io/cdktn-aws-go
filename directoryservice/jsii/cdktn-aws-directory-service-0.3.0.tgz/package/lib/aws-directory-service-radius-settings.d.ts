import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsRadiusSettingsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_radius_settings#authentication_protocol AwsRadiusSettings#authentication_protocol}
    */
    readonly authenticationProtocol: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_radius_settings#directory_id AwsRadiusSettings#directory_id}
    */
    readonly directoryId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_radius_settings#display_label AwsRadiusSettings#display_label}
    */
    readonly displayLabel: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_radius_settings#id AwsRadiusSettings#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_radius_settings#radius_port AwsRadiusSettings#radius_port}
    */
    readonly radiusPort: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_radius_settings#radius_retries AwsRadiusSettings#radius_retries}
    */
    readonly radiusRetries: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_radius_settings#radius_servers AwsRadiusSettings#radius_servers}
    */
    readonly radiusServers: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_radius_settings#radius_timeout AwsRadiusSettings#radius_timeout}
    */
    readonly radiusTimeout: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_radius_settings#region AwsRadiusSettings#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_radius_settings#shared_secret AwsRadiusSettings#shared_secret}
    */
    readonly sharedSecret: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_radius_settings#use_same_username AwsRadiusSettings#use_same_username}
    */
    readonly useSameUsername?: boolean | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_radius_settings#timeouts AwsRadiusSettings#timeouts}
    */
    readonly timeouts?: AwsRadiusSettings.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_radius_settings aws_directory_service_radius_settings}
*/
export declare class AwsRadiusSettings extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_directory_service_radius_settings";
    /**
    * Generates CDKTN code for importing a AwsRadiusSettings resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsRadiusSettings to import
    * @param importFromId The id of the existing AwsRadiusSettings that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_radius_settings#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsRadiusSettings to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_radius_settings aws_directory_service_radius_settings} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsRadiusSettingsConfig
    */
    constructor(scope: Construct, id: string, config: AwsRadiusSettingsConfig);
    private _authenticationProtocol?;
    get authenticationProtocol(): string;
    set authenticationProtocol(value: string);
    get authenticationProtocolInput(): string | undefined;
    private _directoryId?;
    get directoryId(): string;
    set directoryId(value: string);
    get directoryIdInput(): string | undefined;
    private _displayLabel?;
    get displayLabel(): string;
    set displayLabel(value: string);
    get displayLabelInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _radiusPort?;
    get radiusPort(): number;
    set radiusPort(value: number);
    get radiusPortInput(): number | undefined;
    private _radiusRetries?;
    get radiusRetries(): number;
    set radiusRetries(value: number);
    get radiusRetriesInput(): number | undefined;
    private _radiusServers?;
    get radiusServers(): string[];
    set radiusServers(value: string[]);
    get radiusServersInput(): string[] | undefined;
    private _radiusTimeout?;
    get radiusTimeout(): number;
    set radiusTimeout(value: number);
    get radiusTimeoutInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _sharedSecret?;
    get sharedSecret(): string;
    set sharedSecret(value: string);
    get sharedSecretInput(): string | undefined;
    private _useSameUsername?;
    get useSameUsername(): boolean | cdktn.IResolvable;
    set useSameUsername(value: boolean | cdktn.IResolvable);
    resetUseSameUsername(): void;
    get useSameUsernameInput(): boolean | cdktn.IResolvable | undefined;
    private _timeouts;
    get timeouts(): AwsRadiusSettings.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsRadiusSettings.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsRadiusSettings.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsRadiusSettingsTimeoutsPropertyToTerraform(struct?: AwsRadiusSettings.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsRadiusSettingsTimeoutsPropertyToHclTerraform(struct?: AwsRadiusSettings.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsRadiusSettings {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_radius_settings#create AwsRadiusSettings#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_radius_settings#update AwsRadiusSettings#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
