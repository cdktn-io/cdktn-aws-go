import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsTrustConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_trust#conditional_forwarder_ip_addrs AwsTrust#conditional_forwarder_ip_addrs}
    */
    readonly conditionalForwarderIpAddrs?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_trust#delete_associated_conditional_forwarder AwsTrust#delete_associated_conditional_forwarder}
    */
    readonly deleteAssociatedConditionalForwarder?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_trust#directory_id AwsTrust#directory_id}
    */
    readonly directoryId: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_trust#region AwsTrust#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_trust#remote_domain_name AwsTrust#remote_domain_name}
    */
    readonly remoteDomainName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_trust#selective_auth AwsTrust#selective_auth}
    */
    readonly selectiveAuth?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_trust#trust_direction AwsTrust#trust_direction}
    */
    readonly trustDirection: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_trust#trust_password AwsTrust#trust_password}
    */
    readonly trustPassword: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_trust#trust_type AwsTrust#trust_type}
    */
    readonly trustType?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_trust aws_directory_service_trust}
*/
export declare class AwsTrust extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_directory_service_trust";
    /**
    * Generates CDKTN code for importing a AwsTrust resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsTrust to import
    * @param importFromId The id of the existing AwsTrust that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_trust#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsTrust to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/directory_service_trust aws_directory_service_trust} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsTrustConfig
    */
    constructor(scope: Construct, id: string, config: AwsTrustConfig);
    private _conditionalForwarderIpAddrs?;
    get conditionalForwarderIpAddrs(): string[];
    set conditionalForwarderIpAddrs(value: string[]);
    resetConditionalForwarderIpAddrs(): void;
    get conditionalForwarderIpAddrsInput(): string[] | undefined;
    get createdDateTime(): string;
    private _deleteAssociatedConditionalForwarder?;
    get deleteAssociatedConditionalForwarder(): boolean | cdktn.IResolvable;
    set deleteAssociatedConditionalForwarder(value: boolean | cdktn.IResolvable);
    resetDeleteAssociatedConditionalForwarder(): void;
    get deleteAssociatedConditionalForwarderInput(): boolean | cdktn.IResolvable | undefined;
    private _directoryId?;
    get directoryId(): string;
    set directoryId(value: string);
    get directoryIdInput(): string | undefined;
    get id(): string;
    get lastUpdatedDateTime(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _remoteDomainName?;
    get remoteDomainName(): string;
    set remoteDomainName(value: string);
    get remoteDomainNameInput(): string | undefined;
    private _selectiveAuth?;
    get selectiveAuth(): string;
    set selectiveAuth(value: string);
    resetSelectiveAuth(): void;
    get selectiveAuthInput(): string | undefined;
    get stateLastUpdatedDateTime(): string;
    private _trustDirection?;
    get trustDirection(): string;
    set trustDirection(value: string);
    get trustDirectionInput(): string | undefined;
    private _trustPassword?;
    get trustPassword(): string;
    set trustPassword(value: string);
    get trustPasswordInput(): string | undefined;
    get trustState(): string;
    get trustStateReason(): string;
    private _trustType?;
    get trustType(): string;
    set trustType(value: string);
    resetTrustType(): void;
    get trustTypeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
