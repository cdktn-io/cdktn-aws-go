import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfReplicationConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_replication_configuration#id TfReplicationConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_replication_configuration#region TfReplicationConfiguration#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_replication_configuration#source_file_system_id TfReplicationConfiguration#source_file_system_id}
    */
    readonly sourceFileSystemId: string;
    /**
    * destination block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_replication_configuration#destination TfReplicationConfiguration#destination}
    */
    readonly destination: TfReplicationConfiguration.DestinationProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_replication_configuration#timeouts TfReplicationConfiguration#timeouts}
    */
    readonly timeouts?: TfReplicationConfiguration.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_replication_configuration aws_efs_replication_configuration}
*/
export declare class TfReplicationConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_efs_replication_configuration";
    /**
    * Generates CDKTN code for importing a TfReplicationConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfReplicationConfiguration to import
    * @param importFromId The id of the existing TfReplicationConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_replication_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfReplicationConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_replication_configuration aws_efs_replication_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfReplicationConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: TfReplicationConfigurationConfig);
    get creationTime(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get originalSourceFileSystemArn(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get sourceFileSystemArn(): string;
    private _sourceFileSystemId?;
    get sourceFileSystemId(): string;
    set sourceFileSystemId(value: string);
    get sourceFileSystemIdInput(): string | undefined;
    get sourceFileSystemRegion(): string;
    private _destination;
    get destination(): TfReplicationConfiguration.DestinationPropertyOutputReference;
    putDestination(value: TfReplicationConfiguration.DestinationProperty): void;
    get destinationInput(): TfReplicationConfiguration.DestinationProperty | undefined;
    private _timeouts;
    get timeouts(): TfReplicationConfiguration.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfReplicationConfiguration.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfReplicationConfiguration.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfReplicationConfigurationDestinationPropertyToTerraform(struct?: TfReplicationConfiguration.DestinationPropertyOutputReference | TfReplicationConfiguration.DestinationProperty): any;
export declare function tfReplicationConfigurationDestinationPropertyToHclTerraform(struct?: TfReplicationConfiguration.DestinationPropertyOutputReference | TfReplicationConfiguration.DestinationProperty): any;
export declare function tfReplicationConfigurationTimeoutsPropertyToTerraform(struct?: TfReplicationConfiguration.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfReplicationConfigurationTimeoutsPropertyToHclTerraform(struct?: TfReplicationConfiguration.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfReplicationConfiguration {
    interface DestinationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_replication_configuration#availability_zone_name TfReplicationConfiguration#availability_zone_name}
        */
        readonly availabilityZoneName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_replication_configuration#file_system_id TfReplicationConfiguration#file_system_id}
        */
        readonly fileSystemId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_replication_configuration#kms_key_id TfReplicationConfiguration#kms_key_id}
        */
        readonly kmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_replication_configuration#region TfReplicationConfiguration#region}
        */
        readonly region?: string;
    }
    class DestinationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DestinationProperty | undefined;
        set internalValue(value: DestinationProperty | undefined);
        private _availabilityZoneName?;
        get availabilityZoneName(): string;
        set availabilityZoneName(value: string);
        resetAvailabilityZoneName(): void;
        get availabilityZoneNameInput(): string | undefined;
        private _fileSystemId?;
        get fileSystemId(): string;
        set fileSystemId(value: string);
        resetFileSystemId(): void;
        get fileSystemIdInput(): string | undefined;
        private _kmsKeyId?;
        get kmsKeyId(): string;
        set kmsKeyId(value: string);
        resetKmsKeyId(): void;
        get kmsKeyIdInput(): string | undefined;
        private _region?;
        get region(): string;
        set region(value: string);
        resetRegion(): void;
        get regionInput(): string | undefined;
        get status(): string;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_replication_configuration#create TfReplicationConfiguration#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_replication_configuration#delete TfReplicationConfiguration#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
