import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfAccessPointConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_access_point#file_system_id TfAccessPoint#file_system_id}
    */
    readonly fileSystemId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_access_point#id TfAccessPoint#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_access_point#region TfAccessPoint#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_access_point#tags TfAccessPoint#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_access_point#tags_all TfAccessPoint#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * posix_user block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_access_point#posix_user TfAccessPoint#posix_user}
    */
    readonly posixUser?: TfAccessPoint.PosixUserProperty;
    /**
    * root_directory block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_access_point#root_directory TfAccessPoint#root_directory}
    */
    readonly rootDirectory?: TfAccessPoint.RootDirectoryProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_access_point aws_efs_access_point}
*/
export declare class TfAccessPoint extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_efs_access_point";
    /**
    * Generates CDKTN code for importing a TfAccessPoint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfAccessPoint to import
    * @param importFromId The id of the existing TfAccessPoint that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_access_point#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfAccessPoint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_access_point aws_efs_access_point} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfAccessPointConfig
    */
    constructor(scope: Construct, id: string, config: TfAccessPointConfig);
    get arn(): string;
    get fileSystemArn(): string;
    private _fileSystemId?;
    get fileSystemId(): string;
    set fileSystemId(value: string);
    get fileSystemIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ownerId(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _posixUser;
    get posixUser(): TfAccessPoint.PosixUserPropertyOutputReference;
    putPosixUser(value: TfAccessPoint.PosixUserProperty): void;
    resetPosixUser(): void;
    get posixUserInput(): TfAccessPoint.PosixUserProperty | undefined;
    private _rootDirectory;
    get rootDirectory(): TfAccessPoint.RootDirectoryPropertyOutputReference;
    putRootDirectory(value: TfAccessPoint.RootDirectoryProperty): void;
    resetRootDirectory(): void;
    get rootDirectoryInput(): TfAccessPoint.RootDirectoryProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfAccessPointPosixUserPropertyToTerraform(struct?: TfAccessPoint.PosixUserPropertyOutputReference | TfAccessPoint.PosixUserProperty): any;
export declare function tfAccessPointPosixUserPropertyToHclTerraform(struct?: TfAccessPoint.PosixUserPropertyOutputReference | TfAccessPoint.PosixUserProperty): any;
export declare function tfAccessPointCreationInfoPropertyToTerraform(struct?: TfAccessPoint.CreationInfoPropertyOutputReference | TfAccessPoint.CreationInfoProperty): any;
export declare function tfAccessPointCreationInfoPropertyToHclTerraform(struct?: TfAccessPoint.CreationInfoPropertyOutputReference | TfAccessPoint.CreationInfoProperty): any;
export declare function tfAccessPointRootDirectoryPropertyToTerraform(struct?: TfAccessPoint.RootDirectoryPropertyOutputReference | TfAccessPoint.RootDirectoryProperty): any;
export declare function tfAccessPointRootDirectoryPropertyToHclTerraform(struct?: TfAccessPoint.RootDirectoryPropertyOutputReference | TfAccessPoint.RootDirectoryProperty): any;
export declare namespace TfAccessPoint {
    interface PosixUserProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_access_point#gid TfAccessPoint#gid}
        */
        readonly gid: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_access_point#secondary_gids TfAccessPoint#secondary_gids}
        */
        readonly secondaryGids?: number[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_access_point#uid TfAccessPoint#uid}
        */
        readonly uid: number;
    }
    class PosixUserPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PosixUserProperty | undefined;
        set internalValue(value: PosixUserProperty | undefined);
        private _gid?;
        get gid(): number;
        set gid(value: number);
        get gidInput(): number | undefined;
        private _secondaryGids?;
        get secondaryGids(): number[];
        set secondaryGids(value: number[]);
        resetSecondaryGids(): void;
        get secondaryGidsInput(): number[] | undefined;
        private _uid?;
        get uid(): number;
        set uid(value: number);
        get uidInput(): number | undefined;
    }
    interface CreationInfoProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_access_point#owner_gid TfAccessPoint#owner_gid}
        */
        readonly ownerGid: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_access_point#owner_uid TfAccessPoint#owner_uid}
        */
        readonly ownerUid: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_access_point#permissions TfAccessPoint#permissions}
        */
        readonly permissions: string;
    }
    class CreationInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CreationInfoProperty | undefined;
        set internalValue(value: CreationInfoProperty | undefined);
        private _ownerGid?;
        get ownerGid(): number;
        set ownerGid(value: number);
        get ownerGidInput(): number | undefined;
        private _ownerUid?;
        get ownerUid(): number;
        set ownerUid(value: number);
        get ownerUidInput(): number | undefined;
        private _permissions?;
        get permissions(): string;
        set permissions(value: string);
        get permissionsInput(): string | undefined;
    }
    interface RootDirectoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_access_point#path TfAccessPoint#path}
        */
        readonly path?: string;
        /**
        * creation_info block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_access_point#creation_info TfAccessPoint#creation_info}
        */
        readonly creationInfo?: CreationInfoProperty;
    }
    class RootDirectoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RootDirectoryProperty | undefined;
        set internalValue(value: RootDirectoryProperty | undefined);
        private _path?;
        get path(): string;
        set path(value: string);
        resetPath(): void;
        get pathInput(): string | undefined;
        private _creationInfo;
        get creationInfo(): CreationInfoPropertyOutputReference;
        putCreationInfo(value: CreationInfoProperty): void;
        resetCreationInfo(): void;
        get creationInfoInput(): CreationInfoProperty | undefined;
    }
}
