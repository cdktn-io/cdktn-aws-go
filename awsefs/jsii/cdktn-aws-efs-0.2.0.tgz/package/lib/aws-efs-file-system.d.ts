import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfFileSystemConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_file_system#availability_zone_name TfFileSystem#availability_zone_name}
    */
    readonly availabilityZoneName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_file_system#creation_token TfFileSystem#creation_token}
    */
    readonly creationToken?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_file_system#encrypted TfFileSystem#encrypted}
    */
    readonly encrypted?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_file_system#id TfFileSystem#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_file_system#kms_key_id TfFileSystem#kms_key_id}
    */
    readonly kmsKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_file_system#performance_mode TfFileSystem#performance_mode}
    */
    readonly performanceMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_file_system#provisioned_throughput_in_mibps TfFileSystem#provisioned_throughput_in_mibps}
    */
    readonly provisionedThroughputInMibps?: number;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_file_system#region TfFileSystem#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_file_system#tags TfFileSystem#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_file_system#tags_all TfFileSystem#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_file_system#throughput_mode TfFileSystem#throughput_mode}
    */
    readonly throughputMode?: string;
    /**
    * lifecycle_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_file_system#lifecycle_policy TfFileSystem#lifecycle_policy}
    */
    readonly lifecyclePolicy?: TfFileSystem.LifecyclePolicyProperty[] | cdktn.IResolvable;
    /**
    * protection block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_file_system#protection TfFileSystem#protection}
    */
    readonly protection?: TfFileSystem.ProtectionProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_file_system aws_efs_file_system}
*/
export declare class TfFileSystem extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_efs_file_system";
    /**
    * Generates CDKTN code for importing a TfFileSystem resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfFileSystem to import
    * @param importFromId The id of the existing TfFileSystem that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_file_system#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfFileSystem to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_file_system aws_efs_file_system} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfFileSystemConfig = {}
    */
    constructor(scope: Construct, id: string, config?: TfFileSystemConfig);
    get arn(): string;
    get availabilityZoneId(): string;
    private _availabilityZoneName?;
    get availabilityZoneName(): string;
    set availabilityZoneName(value: string);
    resetAvailabilityZoneName(): void;
    get availabilityZoneNameInput(): string | undefined;
    private _creationToken?;
    get creationToken(): string;
    set creationToken(value: string);
    resetCreationToken(): void;
    get creationTokenInput(): string | undefined;
    get dnsName(): string;
    private _encrypted?;
    get encrypted(): boolean | cdktn.IResolvable;
    set encrypted(value: boolean | cdktn.IResolvable);
    resetEncrypted(): void;
    get encryptedInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _kmsKeyId?;
    get kmsKeyId(): string;
    set kmsKeyId(value: string);
    resetKmsKeyId(): void;
    get kmsKeyIdInput(): string | undefined;
    get name(): string;
    get numberOfMountTargets(): number;
    get ownerId(): string;
    private _performanceMode?;
    get performanceMode(): string;
    set performanceMode(value: string);
    resetPerformanceMode(): void;
    get performanceModeInput(): string | undefined;
    private _provisionedThroughputInMibps?;
    get provisionedThroughputInMibps(): number;
    set provisionedThroughputInMibps(value: number);
    resetProvisionedThroughputInMibps(): void;
    get provisionedThroughputInMibpsInput(): number | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _sizeInBytes;
    get sizeInBytes(): TfFileSystem.SizeInBytesPropertyList;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _throughputMode?;
    get throughputMode(): string;
    set throughputMode(value: string);
    resetThroughputMode(): void;
    get throughputModeInput(): string | undefined;
    private _lifecyclePolicy;
    get lifecyclePolicy(): TfFileSystem.LifecyclePolicyPropertyList;
    putLifecyclePolicy(value: TfFileSystem.LifecyclePolicyProperty[] | cdktn.IResolvable): void;
    resetLifecyclePolicy(): void;
    get lifecyclePolicyInput(): cdktn.IResolvable | TfFileSystem.LifecyclePolicyProperty[] | undefined;
    private _protection;
    get protection(): TfFileSystem.ProtectionPropertyOutputReference;
    putProtection(value: TfFileSystem.ProtectionProperty): void;
    resetProtection(): void;
    get protectionInput(): TfFileSystem.ProtectionProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfFileSystemSizeInBytesPropertyToTerraform(struct?: TfFileSystem.SizeInBytesProperty): any;
export declare function tfFileSystemSizeInBytesPropertyToHclTerraform(struct?: TfFileSystem.SizeInBytesProperty): any;
export declare function tfFileSystemLifecyclePolicyPropertyToTerraform(struct?: TfFileSystem.LifecyclePolicyProperty | cdktn.IResolvable): any;
export declare function tfFileSystemLifecyclePolicyPropertyToHclTerraform(struct?: TfFileSystem.LifecyclePolicyProperty | cdktn.IResolvable): any;
export declare function tfFileSystemProtectionPropertyToTerraform(struct?: TfFileSystem.ProtectionPropertyOutputReference | TfFileSystem.ProtectionProperty): any;
export declare function tfFileSystemProtectionPropertyToHclTerraform(struct?: TfFileSystem.ProtectionPropertyOutputReference | TfFileSystem.ProtectionProperty): any;
export declare namespace TfFileSystem {
    interface SizeInBytesProperty {
    }
    class SizeInBytesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SizeInBytesProperty | undefined;
        set internalValue(value: SizeInBytesProperty | undefined);
        get value(): number;
        get valueInIa(): number;
        get valueInStandard(): number;
    }
    class SizeInBytesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SizeInBytesPropertyOutputReference;
    }
    interface LifecyclePolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_file_system#transition_to_archive TfFileSystem#transition_to_archive}
        */
        readonly transitionToArchive?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_file_system#transition_to_ia TfFileSystem#transition_to_ia}
        */
        readonly transitionToIa?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_file_system#transition_to_primary_storage_class TfFileSystem#transition_to_primary_storage_class}
        */
        readonly transitionToPrimaryStorageClass?: string;
    }
    class LifecyclePolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LifecyclePolicyProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LifecyclePolicyProperty | cdktn.IResolvable | undefined);
        private _transitionToArchive?;
        get transitionToArchive(): string;
        set transitionToArchive(value: string);
        resetTransitionToArchive(): void;
        get transitionToArchiveInput(): string | undefined;
        private _transitionToIa?;
        get transitionToIa(): string;
        set transitionToIa(value: string);
        resetTransitionToIa(): void;
        get transitionToIaInput(): string | undefined;
        private _transitionToPrimaryStorageClass?;
        get transitionToPrimaryStorageClass(): string;
        set transitionToPrimaryStorageClass(value: string);
        resetTransitionToPrimaryStorageClass(): void;
        get transitionToPrimaryStorageClassInput(): string | undefined;
    }
    class LifecyclePolicyPropertyList extends cdktn.ComplexList {
        internalValue?: LifecyclePolicyProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LifecyclePolicyPropertyOutputReference;
    }
    interface ProtectionProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/efs_file_system#replication_overwrite TfFileSystem#replication_overwrite}
        */
        readonly replicationOverwrite?: string;
    }
    class ProtectionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ProtectionProperty | undefined;
        set internalValue(value: ProtectionProperty | undefined);
        private _replicationOverwrite?;
        get replicationOverwrite(): string;
        set replicationOverwrite(value: string);
        resetReplicationOverwrite(): void;
        get replicationOverwriteInput(): string | undefined;
    }
}
