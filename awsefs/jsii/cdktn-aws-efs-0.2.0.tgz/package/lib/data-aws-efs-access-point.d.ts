import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfAccessPointConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/efs_access_point#access_point_id DataTfAccessPoint#access_point_id}
    */
    readonly accessPointId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/efs_access_point#id DataTfAccessPoint#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/efs_access_point#region DataTfAccessPoint#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/efs_access_point#tags DataTfAccessPoint#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/efs_access_point aws_efs_access_point}
*/
export declare class DataTfAccessPoint extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_efs_access_point";
    /**
    * Generates CDKTN code for importing a DataTfAccessPoint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfAccessPoint to import
    * @param importFromId The id of the existing DataTfAccessPoint that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/efs_access_point#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfAccessPoint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/efs_access_point aws_efs_access_point} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfAccessPointConfig
    */
    constructor(scope: Construct, id: string, config: DataTfAccessPointConfig);
    private _accessPointId?;
    get accessPointId(): string;
    set accessPointId(value: string);
    get accessPointIdInput(): string | undefined;
    get arn(): string;
    get fileSystemArn(): string;
    get fileSystemId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ownerId(): string;
    private _posixUser;
    get posixUser(): DataTfAccessPoint.PosixUserPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _rootDirectory;
    get rootDirectory(): DataTfAccessPoint.RootDirectoryPropertyList;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfAccessPointPosixUserPropertyToTerraform(struct?: DataTfAccessPoint.PosixUserProperty): any;
export declare function dataTfAccessPointPosixUserPropertyToHclTerraform(struct?: DataTfAccessPoint.PosixUserProperty): any;
export declare function dataTfAccessPointCreationInfoPropertyToTerraform(struct?: DataTfAccessPoint.CreationInfoProperty): any;
export declare function dataTfAccessPointCreationInfoPropertyToHclTerraform(struct?: DataTfAccessPoint.CreationInfoProperty): any;
export declare function dataTfAccessPointRootDirectoryPropertyToTerraform(struct?: DataTfAccessPoint.RootDirectoryProperty): any;
export declare function dataTfAccessPointRootDirectoryPropertyToHclTerraform(struct?: DataTfAccessPoint.RootDirectoryProperty): any;
export declare namespace DataTfAccessPoint {
    interface PosixUserProperty {
    }
    class PosixUserPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PosixUserProperty | undefined;
        set internalValue(value: PosixUserProperty | undefined);
        get gid(): number;
        get secondaryGids(): number[];
        get uid(): number;
    }
    class PosixUserPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PosixUserPropertyOutputReference;
    }
    interface CreationInfoProperty {
    }
    class CreationInfoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CreationInfoProperty | undefined;
        set internalValue(value: CreationInfoProperty | undefined);
        get ownerGid(): number;
        get ownerUid(): number;
        get permissions(): string;
    }
    class CreationInfoPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CreationInfoPropertyOutputReference;
    }
    interface RootDirectoryProperty {
    }
    class RootDirectoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RootDirectoryProperty | undefined;
        set internalValue(value: RootDirectoryProperty | undefined);
        private _creationInfo;
        get creationInfo(): CreationInfoPropertyList;
        get path(): string;
    }
    class RootDirectoryPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RootDirectoryPropertyOutputReference;
    }
}
