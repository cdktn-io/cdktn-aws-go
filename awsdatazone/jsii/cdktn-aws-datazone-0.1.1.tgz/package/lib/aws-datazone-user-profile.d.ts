import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDatazoneUserProfileConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_user_profile#domain_identifier AwsDatazoneUserProfile#domain_identifier}
    */
    readonly domainIdentifier: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_user_profile#region AwsDatazoneUserProfile#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_user_profile#status AwsDatazoneUserProfile#status}
    */
    readonly status?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_user_profile#user_identifier AwsDatazoneUserProfile#user_identifier}
    */
    readonly userIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_user_profile#user_type AwsDatazoneUserProfile#user_type}
    */
    readonly userType?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_user_profile#timeouts AwsDatazoneUserProfile#timeouts}
    */
    readonly timeouts?: AwsDatazoneUserProfile.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_user_profile aws_datazone_user_profile}
*/
export declare class AwsDatazoneUserProfile extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_datazone_user_profile";
    /**
    * Generates CDKTN code for importing a AwsDatazoneUserProfile resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDatazoneUserProfile to import
    * @param importFromId The id of the existing AwsDatazoneUserProfile that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_user_profile#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDatazoneUserProfile to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_user_profile aws_datazone_user_profile} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDatazoneUserProfileConfig
    */
    constructor(scope: Construct, id: string, config: AwsDatazoneUserProfileConfig);
    private _details;
    get details(): AwsDatazoneUserProfile.DetailsPropertyList;
    private _domainIdentifier?;
    get domainIdentifier(): string;
    set domainIdentifier(value: string);
    get domainIdentifierInput(): string | undefined;
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    get type(): string;
    private _userIdentifier?;
    get userIdentifier(): string;
    set userIdentifier(value: string);
    get userIdentifierInput(): string | undefined;
    private _userType?;
    get userType(): string;
    set userType(value: string);
    resetUserType(): void;
    get userTypeInput(): string | undefined;
    private _timeouts;
    get timeouts(): AwsDatazoneUserProfile.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsDatazoneUserProfile.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsDatazoneUserProfile.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDatazoneUserProfileIamPropertyToTerraform(struct?: AwsDatazoneUserProfile.IamProperty): any;
export declare function awsDatazoneUserProfileIamPropertyToHclTerraform(struct?: AwsDatazoneUserProfile.IamProperty): any;
export declare function awsDatazoneUserProfileSsoPropertyToTerraform(struct?: AwsDatazoneUserProfile.SsoProperty): any;
export declare function awsDatazoneUserProfileSsoPropertyToHclTerraform(struct?: AwsDatazoneUserProfile.SsoProperty): any;
export declare function awsDatazoneUserProfileDetailsPropertyToTerraform(struct?: AwsDatazoneUserProfile.DetailsProperty): any;
export declare function awsDatazoneUserProfileDetailsPropertyToHclTerraform(struct?: AwsDatazoneUserProfile.DetailsProperty): any;
export declare function awsDatazoneUserProfileTimeoutsPropertyToTerraform(struct?: AwsDatazoneUserProfile.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsDatazoneUserProfileTimeoutsPropertyToHclTerraform(struct?: AwsDatazoneUserProfile.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsDatazoneUserProfile {
    interface IamProperty {
    }
    class IamPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IamProperty | undefined;
        set internalValue(value: IamProperty | undefined);
        get arn(): string;
    }
    class IamPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IamPropertyOutputReference;
    }
    interface SsoProperty {
    }
    class SsoPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SsoProperty | undefined;
        set internalValue(value: SsoProperty | undefined);
        get firstName(): string;
        get lastName(): string;
        get userName(): string;
    }
    class SsoPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SsoPropertyOutputReference;
    }
    interface DetailsProperty {
    }
    class DetailsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DetailsProperty | undefined;
        set internalValue(value: DetailsProperty | undefined);
        private _iam;
        get iam(): IamPropertyList;
        private _sso;
        get sso(): SsoPropertyList;
    }
    class DetailsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DetailsPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_user_profile#create AwsDatazoneUserProfile#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_user_profile#update AwsDatazoneUserProfile#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
