import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsDatazoneDomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_domain#description AwsDatazoneDomain#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_domain#domain_execution_role AwsDatazoneDomain#domain_execution_role}
    */
    readonly domainExecutionRole: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_domain#domain_version AwsDatazoneDomain#domain_version}
    */
    readonly domainVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_domain#kms_key_identifier AwsDatazoneDomain#kms_key_identifier}
    */
    readonly kmsKeyIdentifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_domain#name AwsDatazoneDomain#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_domain#region AwsDatazoneDomain#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_domain#service_role AwsDatazoneDomain#service_role}
    */
    readonly serviceRole?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_domain#skip_deletion_check AwsDatazoneDomain#skip_deletion_check}
    */
    readonly skipDeletionCheck?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_domain#tags AwsDatazoneDomain#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * single_sign_on block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_domain#single_sign_on AwsDatazoneDomain#single_sign_on}
    */
    readonly singleSignOn?: AwsDatazoneDomain.SingleSignOnProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_domain#timeouts AwsDatazoneDomain#timeouts}
    */
    readonly timeouts?: AwsDatazoneDomain.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_domain aws_datazone_domain}
*/
export declare class AwsDatazoneDomain extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_datazone_domain";
    /**
    * Generates CDKTN code for importing a AwsDatazoneDomain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsDatazoneDomain to import
    * @param importFromId The id of the existing AwsDatazoneDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsDatazoneDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_domain aws_datazone_domain} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsDatazoneDomainConfig
    */
    constructor(scope: Construct, id: string, config: AwsDatazoneDomainConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _domainExecutionRole?;
    get domainExecutionRole(): string;
    set domainExecutionRole(value: string);
    get domainExecutionRoleInput(): string | undefined;
    private _domainVersion?;
    get domainVersion(): string;
    set domainVersion(value: string);
    resetDomainVersion(): void;
    get domainVersionInput(): string | undefined;
    get id(): string;
    private _kmsKeyIdentifier?;
    get kmsKeyIdentifier(): string;
    set kmsKeyIdentifier(value: string);
    resetKmsKeyIdentifier(): void;
    get kmsKeyIdentifierInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get portalUrl(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get rootDomainUnitId(): string;
    private _serviceRole?;
    get serviceRole(): string;
    set serviceRole(value: string);
    resetServiceRole(): void;
    get serviceRoleInput(): string | undefined;
    private _skipDeletionCheck?;
    get skipDeletionCheck(): boolean | cdktn.IResolvable;
    set skipDeletionCheck(value: boolean | cdktn.IResolvable);
    resetSkipDeletionCheck(): void;
    get skipDeletionCheckInput(): boolean | cdktn.IResolvable | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _singleSignOn;
    get singleSignOn(): AwsDatazoneDomain.SingleSignOnPropertyList;
    putSingleSignOn(value: AwsDatazoneDomain.SingleSignOnProperty[] | cdktn.IResolvable): void;
    resetSingleSignOn(): void;
    get singleSignOnInput(): cdktn.IResolvable | AwsDatazoneDomain.SingleSignOnProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsDatazoneDomain.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsDatazoneDomain.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsDatazoneDomain.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsDatazoneDomainSingleSignOnPropertyToTerraform(struct?: AwsDatazoneDomain.SingleSignOnProperty | cdktn.IResolvable): any;
export declare function awsDatazoneDomainSingleSignOnPropertyToHclTerraform(struct?: AwsDatazoneDomain.SingleSignOnProperty | cdktn.IResolvable): any;
export declare function awsDatazoneDomainTimeoutsPropertyToTerraform(struct?: AwsDatazoneDomain.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsDatazoneDomainTimeoutsPropertyToHclTerraform(struct?: AwsDatazoneDomain.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsDatazoneDomain {
    interface SingleSignOnProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_domain#type AwsDatazoneDomain#type}
        */
        readonly type?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_domain#user_assignment AwsDatazoneDomain#user_assignment}
        */
        readonly userAssignment?: string;
    }
    class SingleSignOnPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): SingleSignOnProperty | cdktn.IResolvable | undefined;
        set internalValue(value: SingleSignOnProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        resetType(): void;
        get typeInput(): string | undefined;
        private _userAssignment?;
        get userAssignment(): string;
        set userAssignment(value: string);
        resetUserAssignment(): void;
        get userAssignmentInput(): string | undefined;
    }
    class SingleSignOnPropertyList extends cdktn.ComplexList {
        internalValue?: SingleSignOnProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): SingleSignOnPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_domain#create AwsDatazoneDomain#create}
        */
        readonly create?: string;
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours). Setting a timeout for a Delete operation is only applicable if changes are saved into state before the destroy operation occurs.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_domain#delete AwsDatazoneDomain#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
