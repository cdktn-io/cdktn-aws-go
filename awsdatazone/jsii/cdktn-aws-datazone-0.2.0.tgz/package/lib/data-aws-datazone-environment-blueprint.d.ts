import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfEnvironmentBlueprintConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/datazone_environment_blueprint#domain_id DataTfEnvironmentBlueprint#domain_id}
    */
    readonly domainId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/datazone_environment_blueprint#managed DataTfEnvironmentBlueprint#managed}
    */
    readonly managed: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/datazone_environment_blueprint#name DataTfEnvironmentBlueprint#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/datazone_environment_blueprint#region DataTfEnvironmentBlueprint#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/datazone_environment_blueprint aws_datazone_environment_blueprint}
*/
export declare class DataTfEnvironmentBlueprint extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_datazone_environment_blueprint";
    /**
    * Generates CDKTN code for importing a DataTfEnvironmentBlueprint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfEnvironmentBlueprint to import
    * @param importFromId The id of the existing DataTfEnvironmentBlueprint that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/datazone_environment_blueprint#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfEnvironmentBlueprint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/datazone_environment_blueprint aws_datazone_environment_blueprint} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfEnvironmentBlueprintConfig
    */
    constructor(scope: Construct, id: string, config: DataTfEnvironmentBlueprintConfig);
    get blueprintProvider(): string;
    get description(): string;
    private _domainId?;
    get domainId(): string;
    set domainId(value: string);
    get domainIdInput(): string | undefined;
    get id(): string;
    private _managed?;
    get managed(): boolean | cdktn.IResolvable;
    set managed(value: boolean | cdktn.IResolvable);
    get managedInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
