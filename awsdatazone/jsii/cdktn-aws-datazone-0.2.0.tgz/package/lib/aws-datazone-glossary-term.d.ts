import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfGlossaryTermConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_glossary_term#domain_identifier TfGlossaryTerm#domain_identifier}
    */
    readonly domainIdentifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_glossary_term#glossary_identifier TfGlossaryTerm#glossary_identifier}
    */
    readonly glossaryIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_glossary_term#long_description TfGlossaryTerm#long_description}
    */
    readonly longDescription?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_glossary_term#name TfGlossaryTerm#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_glossary_term#region TfGlossaryTerm#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_glossary_term#short_description TfGlossaryTerm#short_description}
    */
    readonly shortDescription?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_glossary_term#status TfGlossaryTerm#status}
    */
    readonly status?: string;
    /**
    * term_relations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_glossary_term#term_relations TfGlossaryTerm#term_relations}
    */
    readonly termRelations?: TfGlossaryTerm.TermRelationsProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_glossary_term#timeouts TfGlossaryTerm#timeouts}
    */
    readonly timeouts?: TfGlossaryTerm.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_glossary_term aws_datazone_glossary_term}
*/
export declare class TfGlossaryTerm extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_datazone_glossary_term";
    /**
    * Generates CDKTN code for importing a TfGlossaryTerm resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfGlossaryTerm to import
    * @param importFromId The id of the existing TfGlossaryTerm that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_glossary_term#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfGlossaryTerm to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_glossary_term aws_datazone_glossary_term} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfGlossaryTermConfig
    */
    constructor(scope: Construct, id: string, config: TfGlossaryTermConfig);
    get createdAt(): string;
    get createdBy(): string;
    private _domainIdentifier?;
    get domainIdentifier(): string;
    set domainIdentifier(value: string);
    resetDomainIdentifier(): void;
    get domainIdentifierInput(): string | undefined;
    private _glossaryIdentifier?;
    get glossaryIdentifier(): string;
    set glossaryIdentifier(value: string);
    get glossaryIdentifierInput(): string | undefined;
    get id(): string;
    private _longDescription?;
    get longDescription(): string;
    set longDescription(value: string);
    resetLongDescription(): void;
    get longDescriptionInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _shortDescription?;
    get shortDescription(): string;
    set shortDescription(value: string);
    resetShortDescription(): void;
    get shortDescriptionInput(): string | undefined;
    private _status?;
    get status(): string;
    set status(value: string);
    resetStatus(): void;
    get statusInput(): string | undefined;
    private _termRelations;
    get termRelations(): TfGlossaryTerm.TermRelationsPropertyList;
    putTermRelations(value: TfGlossaryTerm.TermRelationsProperty[] | cdktn.IResolvable): void;
    resetTermRelations(): void;
    get termRelationsInput(): cdktn.IResolvable | TfGlossaryTerm.TermRelationsProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfGlossaryTerm.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfGlossaryTerm.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfGlossaryTerm.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfGlossaryTermTermRelationsPropertyToTerraform(struct?: TfGlossaryTerm.TermRelationsProperty | cdktn.IResolvable): any;
export declare function tfGlossaryTermTermRelationsPropertyToHclTerraform(struct?: TfGlossaryTerm.TermRelationsProperty | cdktn.IResolvable): any;
export declare function tfGlossaryTermTimeoutsPropertyToTerraform(struct?: TfGlossaryTerm.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfGlossaryTermTimeoutsPropertyToHclTerraform(struct?: TfGlossaryTerm.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfGlossaryTerm {
    interface TermRelationsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_glossary_term#classifies TfGlossaryTerm#classifies}
        */
        readonly classifies?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_glossary_term#is_a TfGlossaryTerm#is_a}
        */
        readonly isA?: string[];
    }
    class TermRelationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): TermRelationsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TermRelationsProperty | cdktn.IResolvable | undefined);
        private _classifies?;
        get classifies(): string[];
        set classifies(value: string[]);
        resetClassifies(): void;
        get classifiesInput(): string[] | undefined;
        private _isA?;
        get isA(): string[];
        set isA(value: string[]);
        resetIsA(): void;
        get isAInput(): string[] | undefined;
    }
    class TermRelationsPropertyList extends cdktn.ComplexList {
        internalValue?: TermRelationsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): TermRelationsPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * A string that can be [parsed as a duration](https://pkg.go.dev/time#ParseDuration) consisting of numbers and unit suffixes, such as "30s" or "2h45m". Valid time units are "s" (seconds), "m" (minutes), "h" (hours).
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_glossary_term#create TfGlossaryTerm#create}
        */
        readonly create?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
    }
}
