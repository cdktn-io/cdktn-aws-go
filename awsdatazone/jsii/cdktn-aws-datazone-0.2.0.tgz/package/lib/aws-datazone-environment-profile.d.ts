import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfEnvironmentProfileConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment_profile#aws_account_id TfEnvironmentProfile#aws_account_id}
    */
    readonly awsAccountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment_profile#aws_account_region TfEnvironmentProfile#aws_account_region}
    */
    readonly awsAccountRegion: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment_profile#description TfEnvironmentProfile#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment_profile#domain_identifier TfEnvironmentProfile#domain_identifier}
    */
    readonly domainIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment_profile#environment_blueprint_identifier TfEnvironmentProfile#environment_blueprint_identifier}
    */
    readonly environmentBlueprintIdentifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment_profile#name TfEnvironmentProfile#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment_profile#project_identifier TfEnvironmentProfile#project_identifier}
    */
    readonly projectIdentifier: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment_profile#region TfEnvironmentProfile#region}
    */
    readonly region?: string;
    /**
    * user_parameters block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment_profile#user_parameters TfEnvironmentProfile#user_parameters}
    */
    readonly userParameters?: TfEnvironmentProfile.UserParametersProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment_profile aws_datazone_environment_profile}
*/
export declare class TfEnvironmentProfile extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_datazone_environment_profile";
    /**
    * Generates CDKTN code for importing a TfEnvironmentProfile resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfEnvironmentProfile to import
    * @param importFromId The id of the existing TfEnvironmentProfile that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment_profile#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfEnvironmentProfile to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment_profile aws_datazone_environment_profile} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfEnvironmentProfileConfig
    */
    constructor(scope: Construct, id: string, config: TfEnvironmentProfileConfig);
    private _awsAccountId?;
    get awsAccountId(): string;
    set awsAccountId(value: string);
    resetAwsAccountId(): void;
    get awsAccountIdInput(): string | undefined;
    private _awsAccountRegion?;
    get awsAccountRegion(): string;
    set awsAccountRegion(value: string);
    get awsAccountRegionInput(): string | undefined;
    get createdAt(): string;
    get createdBy(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _domainIdentifier?;
    get domainIdentifier(): string;
    set domainIdentifier(value: string);
    get domainIdentifierInput(): string | undefined;
    private _environmentBlueprintIdentifier?;
    get environmentBlueprintIdentifier(): string;
    set environmentBlueprintIdentifier(value: string);
    get environmentBlueprintIdentifierInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _projectIdentifier?;
    get projectIdentifier(): string;
    set projectIdentifier(value: string);
    get projectIdentifierInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get updatedAt(): string;
    private _userParameters;
    get userParameters(): TfEnvironmentProfile.UserParametersPropertyList;
    putUserParameters(value: TfEnvironmentProfile.UserParametersProperty[] | cdktn.IResolvable): void;
    resetUserParameters(): void;
    get userParametersInput(): cdktn.IResolvable | TfEnvironmentProfile.UserParametersProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfEnvironmentProfileUserParametersPropertyToTerraform(struct?: TfEnvironmentProfile.UserParametersProperty | cdktn.IResolvable): any;
export declare function tfEnvironmentProfileUserParametersPropertyToHclTerraform(struct?: TfEnvironmentProfile.UserParametersProperty | cdktn.IResolvable): any;
export declare namespace TfEnvironmentProfile {
    interface UserParametersProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment_profile#name TfEnvironmentProfile#name}
        */
        readonly name?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/datazone_environment_profile#value TfEnvironmentProfile#value}
        */
        readonly value?: string;
    }
    class UserParametersPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UserParametersProperty | cdktn.IResolvable | undefined;
        set internalValue(value: UserParametersProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        resetName(): void;
        get nameInput(): string | undefined;
        private _value?;
        get value(): string;
        set value(value: string);
        resetValue(): void;
        get valueInput(): string | undefined;
    }
    class UserParametersPropertyList extends cdktn.ComplexList {
        internalValue?: UserParametersProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UserParametersPropertyOutputReference;
    }
}
