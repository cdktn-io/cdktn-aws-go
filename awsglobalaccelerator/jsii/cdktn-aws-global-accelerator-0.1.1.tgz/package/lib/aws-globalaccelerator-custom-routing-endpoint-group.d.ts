import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsGlobalacceleratorCustomRoutingEndpointGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_endpoint_group#endpoint_group_region AwsGlobalacceleratorCustomRoutingEndpointGroup#endpoint_group_region}
    */
    readonly endpointGroupRegion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_endpoint_group#id AwsGlobalacceleratorCustomRoutingEndpointGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_endpoint_group#listener_arn AwsGlobalacceleratorCustomRoutingEndpointGroup#listener_arn}
    */
    readonly listenerArn: string;
    /**
    * destination_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_endpoint_group#destination_configuration AwsGlobalacceleratorCustomRoutingEndpointGroup#destination_configuration}
    */
    readonly destinationConfiguration: AwsGlobalacceleratorCustomRoutingEndpointGroup.DestinationConfigurationProperty[] | cdktn.IResolvable;
    /**
    * endpoint_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_endpoint_group#endpoint_configuration AwsGlobalacceleratorCustomRoutingEndpointGroup#endpoint_configuration}
    */
    readonly endpointConfiguration?: AwsGlobalacceleratorCustomRoutingEndpointGroup.EndpointConfigurationProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_endpoint_group#timeouts AwsGlobalacceleratorCustomRoutingEndpointGroup#timeouts}
    */
    readonly timeouts?: AwsGlobalacceleratorCustomRoutingEndpointGroup.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_endpoint_group aws_globalaccelerator_custom_routing_endpoint_group}
*/
export declare class AwsGlobalacceleratorCustomRoutingEndpointGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_globalaccelerator_custom_routing_endpoint_group";
    /**
    * Generates CDKTN code for importing a AwsGlobalacceleratorCustomRoutingEndpointGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsGlobalacceleratorCustomRoutingEndpointGroup to import
    * @param importFromId The id of the existing AwsGlobalacceleratorCustomRoutingEndpointGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_endpoint_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsGlobalacceleratorCustomRoutingEndpointGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_endpoint_group aws_globalaccelerator_custom_routing_endpoint_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsGlobalacceleratorCustomRoutingEndpointGroupConfig
    */
    constructor(scope: Construct, id: string, config: AwsGlobalacceleratorCustomRoutingEndpointGroupConfig);
    get arn(): string;
    private _endpointGroupRegion?;
    get endpointGroupRegion(): string;
    set endpointGroupRegion(value: string);
    resetEndpointGroupRegion(): void;
    get endpointGroupRegionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _listenerArn?;
    get listenerArn(): string;
    set listenerArn(value: string);
    get listenerArnInput(): string | undefined;
    private _destinationConfiguration;
    get destinationConfiguration(): AwsGlobalacceleratorCustomRoutingEndpointGroup.DestinationConfigurationPropertyList;
    putDestinationConfiguration(value: AwsGlobalacceleratorCustomRoutingEndpointGroup.DestinationConfigurationProperty[] | cdktn.IResolvable): void;
    get destinationConfigurationInput(): cdktn.IResolvable | AwsGlobalacceleratorCustomRoutingEndpointGroup.DestinationConfigurationProperty[] | undefined;
    private _endpointConfiguration;
    get endpointConfiguration(): AwsGlobalacceleratorCustomRoutingEndpointGroup.EndpointConfigurationPropertyList;
    putEndpointConfiguration(value: AwsGlobalacceleratorCustomRoutingEndpointGroup.EndpointConfigurationProperty[] | cdktn.IResolvable): void;
    resetEndpointConfiguration(): void;
    get endpointConfigurationInput(): cdktn.IResolvable | AwsGlobalacceleratorCustomRoutingEndpointGroup.EndpointConfigurationProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsGlobalacceleratorCustomRoutingEndpointGroup.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsGlobalacceleratorCustomRoutingEndpointGroup.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsGlobalacceleratorCustomRoutingEndpointGroup.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsGlobalacceleratorCustomRoutingEndpointGroupDestinationConfigurationPropertyToTerraform(struct?: AwsGlobalacceleratorCustomRoutingEndpointGroup.DestinationConfigurationProperty | cdktn.IResolvable): any;
export declare function awsGlobalacceleratorCustomRoutingEndpointGroupDestinationConfigurationPropertyToHclTerraform(struct?: AwsGlobalacceleratorCustomRoutingEndpointGroup.DestinationConfigurationProperty | cdktn.IResolvable): any;
export declare function awsGlobalacceleratorCustomRoutingEndpointGroupEndpointConfigurationPropertyToTerraform(struct?: AwsGlobalacceleratorCustomRoutingEndpointGroup.EndpointConfigurationProperty | cdktn.IResolvable): any;
export declare function awsGlobalacceleratorCustomRoutingEndpointGroupEndpointConfigurationPropertyToHclTerraform(struct?: AwsGlobalacceleratorCustomRoutingEndpointGroup.EndpointConfigurationProperty | cdktn.IResolvable): any;
export declare function awsGlobalacceleratorCustomRoutingEndpointGroupTimeoutsPropertyToTerraform(struct?: AwsGlobalacceleratorCustomRoutingEndpointGroup.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsGlobalacceleratorCustomRoutingEndpointGroupTimeoutsPropertyToHclTerraform(struct?: AwsGlobalacceleratorCustomRoutingEndpointGroup.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsGlobalacceleratorCustomRoutingEndpointGroup {
    interface DestinationConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_endpoint_group#from_port AwsGlobalacceleratorCustomRoutingEndpointGroup#from_port}
        */
        readonly fromPort: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_endpoint_group#protocols AwsGlobalacceleratorCustomRoutingEndpointGroup#protocols}
        */
        readonly protocols: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_endpoint_group#to_port AwsGlobalacceleratorCustomRoutingEndpointGroup#to_port}
        */
        readonly toPort: number;
    }
    class DestinationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DestinationConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DestinationConfigurationProperty | cdktn.IResolvable | undefined);
        private _fromPort?;
        get fromPort(): number;
        set fromPort(value: number);
        get fromPortInput(): number | undefined;
        private _protocols?;
        get protocols(): string[];
        set protocols(value: string[]);
        get protocolsInput(): string[] | undefined;
        private _toPort?;
        get toPort(): number;
        set toPort(value: number);
        get toPortInput(): number | undefined;
    }
    class DestinationConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: DestinationConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DestinationConfigurationPropertyOutputReference;
    }
    interface EndpointConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_endpoint_group#endpoint_id AwsGlobalacceleratorCustomRoutingEndpointGroup#endpoint_id}
        */
        readonly endpointId?: string;
    }
    class EndpointConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EndpointConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EndpointConfigurationProperty | cdktn.IResolvable | undefined);
        private _endpointId?;
        get endpointId(): string;
        set endpointId(value: string);
        resetEndpointId(): void;
        get endpointIdInput(): string | undefined;
    }
    class EndpointConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: EndpointConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EndpointConfigurationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_endpoint_group#create AwsGlobalacceleratorCustomRoutingEndpointGroup#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_endpoint_group#delete AwsGlobalacceleratorCustomRoutingEndpointGroup#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
