import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsGlobalacceleratorCustomRoutingListenerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_listener#accelerator_arn AwsGlobalacceleratorCustomRoutingListener#accelerator_arn}
    */
    readonly acceleratorArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_listener#id AwsGlobalacceleratorCustomRoutingListener#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * port_range block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_listener#port_range AwsGlobalacceleratorCustomRoutingListener#port_range}
    */
    readonly portRange: AwsGlobalacceleratorCustomRoutingListener.PortRangeProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_listener#timeouts AwsGlobalacceleratorCustomRoutingListener#timeouts}
    */
    readonly timeouts?: AwsGlobalacceleratorCustomRoutingListener.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_listener aws_globalaccelerator_custom_routing_listener}
*/
export declare class AwsGlobalacceleratorCustomRoutingListener extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_globalaccelerator_custom_routing_listener";
    /**
    * Generates CDKTN code for importing a AwsGlobalacceleratorCustomRoutingListener resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsGlobalacceleratorCustomRoutingListener to import
    * @param importFromId The id of the existing AwsGlobalacceleratorCustomRoutingListener that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_listener#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsGlobalacceleratorCustomRoutingListener to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_listener aws_globalaccelerator_custom_routing_listener} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsGlobalacceleratorCustomRoutingListenerConfig
    */
    constructor(scope: Construct, id: string, config: AwsGlobalacceleratorCustomRoutingListenerConfig);
    private _acceleratorArn?;
    get acceleratorArn(): string;
    set acceleratorArn(value: string);
    get acceleratorArnInput(): string | undefined;
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _portRange;
    get portRange(): AwsGlobalacceleratorCustomRoutingListener.PortRangePropertyList;
    putPortRange(value: AwsGlobalacceleratorCustomRoutingListener.PortRangeProperty[] | cdktn.IResolvable): void;
    get portRangeInput(): cdktn.IResolvable | AwsGlobalacceleratorCustomRoutingListener.PortRangeProperty[] | undefined;
    private _timeouts;
    get timeouts(): AwsGlobalacceleratorCustomRoutingListener.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsGlobalacceleratorCustomRoutingListener.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsGlobalacceleratorCustomRoutingListener.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsGlobalacceleratorCustomRoutingListenerPortRangePropertyToTerraform(struct?: AwsGlobalacceleratorCustomRoutingListener.PortRangeProperty | cdktn.IResolvable): any;
export declare function awsGlobalacceleratorCustomRoutingListenerPortRangePropertyToHclTerraform(struct?: AwsGlobalacceleratorCustomRoutingListener.PortRangeProperty | cdktn.IResolvable): any;
export declare function awsGlobalacceleratorCustomRoutingListenerTimeoutsPropertyToTerraform(struct?: AwsGlobalacceleratorCustomRoutingListener.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsGlobalacceleratorCustomRoutingListenerTimeoutsPropertyToHclTerraform(struct?: AwsGlobalacceleratorCustomRoutingListener.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsGlobalacceleratorCustomRoutingListener {
    interface PortRangeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_listener#from_port AwsGlobalacceleratorCustomRoutingListener#from_port}
        */
        readonly fromPort?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_listener#to_port AwsGlobalacceleratorCustomRoutingListener#to_port}
        */
        readonly toPort?: number;
    }
    class PortRangePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PortRangeProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PortRangeProperty | cdktn.IResolvable | undefined);
        private _fromPort?;
        get fromPort(): number;
        set fromPort(value: number);
        resetFromPort(): void;
        get fromPortInput(): number | undefined;
        private _toPort?;
        get toPort(): number;
        set toPort(value: number);
        resetToPort(): void;
        get toPortInput(): number | undefined;
    }
    class PortRangePropertyList extends cdktn.ComplexList {
        internalValue?: PortRangeProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PortRangePropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_listener#create AwsGlobalacceleratorCustomRoutingListener#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_listener#delete AwsGlobalacceleratorCustomRoutingListener#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_listener#update AwsGlobalacceleratorCustomRoutingListener#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
