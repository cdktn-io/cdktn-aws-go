import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsGlobalacceleratorCustomRoutingAcceleratorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/globalaccelerator_custom_routing_accelerator#arn DataAwsGlobalacceleratorCustomRoutingAccelerator#arn}
    */
    readonly arn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/globalaccelerator_custom_routing_accelerator#id DataAwsGlobalacceleratorCustomRoutingAccelerator#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/globalaccelerator_custom_routing_accelerator#name DataAwsGlobalacceleratorCustomRoutingAccelerator#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/globalaccelerator_custom_routing_accelerator#tags DataAwsGlobalacceleratorCustomRoutingAccelerator#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/globalaccelerator_custom_routing_accelerator aws_globalaccelerator_custom_routing_accelerator}
*/
export declare class DataAwsGlobalacceleratorCustomRoutingAccelerator extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_globalaccelerator_custom_routing_accelerator";
    /**
    * Generates CDKTN code for importing a DataAwsGlobalacceleratorCustomRoutingAccelerator resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsGlobalacceleratorCustomRoutingAccelerator to import
    * @param importFromId The id of the existing DataAwsGlobalacceleratorCustomRoutingAccelerator that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/globalaccelerator_custom_routing_accelerator#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsGlobalacceleratorCustomRoutingAccelerator to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/globalaccelerator_custom_routing_accelerator aws_globalaccelerator_custom_routing_accelerator} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsGlobalacceleratorCustomRoutingAcceleratorConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAwsGlobalacceleratorCustomRoutingAcceleratorConfig);
    private _arn?;
    get arn(): string;
    set arn(value: string);
    resetArn(): void;
    get arnInput(): string | undefined;
    private _attributes;
    get attributes(): DataAwsGlobalacceleratorCustomRoutingAccelerator.AttributesPropertyList;
    get dnsName(): string;
    get enabled(): cdktn.IResolvable;
    get hostedZoneId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ipAddressType(): string;
    private _ipSets;
    get ipSets(): DataAwsGlobalacceleratorCustomRoutingAccelerator.IpSetsPropertyList;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsGlobalacceleratorCustomRoutingAcceleratorAttributesPropertyToTerraform(struct?: DataAwsGlobalacceleratorCustomRoutingAccelerator.AttributesProperty): any;
export declare function dataAwsGlobalacceleratorCustomRoutingAcceleratorAttributesPropertyToHclTerraform(struct?: DataAwsGlobalacceleratorCustomRoutingAccelerator.AttributesProperty): any;
export declare function dataAwsGlobalacceleratorCustomRoutingAcceleratorIpSetsPropertyToTerraform(struct?: DataAwsGlobalacceleratorCustomRoutingAccelerator.IpSetsProperty): any;
export declare function dataAwsGlobalacceleratorCustomRoutingAcceleratorIpSetsPropertyToHclTerraform(struct?: DataAwsGlobalacceleratorCustomRoutingAccelerator.IpSetsProperty): any;
export declare namespace DataAwsGlobalacceleratorCustomRoutingAccelerator {
    interface AttributesProperty {
    }
    class AttributesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AttributesProperty | undefined;
        set internalValue(value: AttributesProperty | undefined);
        get flowLogsEnabled(): cdktn.IResolvable;
        get flowLogsS3Bucket(): string;
        get flowLogsS3Prefix(): string;
    }
    class AttributesPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AttributesPropertyOutputReference;
    }
    interface IpSetsProperty {
    }
    class IpSetsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IpSetsProperty | undefined;
        set internalValue(value: IpSetsProperty | undefined);
        get ipAddresses(): string[];
        get ipFamily(): string;
    }
    class IpSetsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IpSetsPropertyOutputReference;
    }
}
