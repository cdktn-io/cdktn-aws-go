import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsGlobalacceleratorCustomRoutingAcceleratorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_accelerator#enabled AwsGlobalacceleratorCustomRoutingAccelerator#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_accelerator#id AwsGlobalacceleratorCustomRoutingAccelerator#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_accelerator#ip_address_type AwsGlobalacceleratorCustomRoutingAccelerator#ip_address_type}
    */
    readonly ipAddressType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_accelerator#ip_addresses AwsGlobalacceleratorCustomRoutingAccelerator#ip_addresses}
    */
    readonly ipAddresses?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_accelerator#name AwsGlobalacceleratorCustomRoutingAccelerator#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_accelerator#tags AwsGlobalacceleratorCustomRoutingAccelerator#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_accelerator#tags_all AwsGlobalacceleratorCustomRoutingAccelerator#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * attributes block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_accelerator#attributes AwsGlobalacceleratorCustomRoutingAccelerator#attributes}
    */
    readonly attributes?: AwsGlobalacceleratorCustomRoutingAccelerator.AttributesProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_accelerator#timeouts AwsGlobalacceleratorCustomRoutingAccelerator#timeouts}
    */
    readonly timeouts?: AwsGlobalacceleratorCustomRoutingAccelerator.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_accelerator aws_globalaccelerator_custom_routing_accelerator}
*/
export declare class AwsGlobalacceleratorCustomRoutingAccelerator extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_globalaccelerator_custom_routing_accelerator";
    /**
    * Generates CDKTN code for importing a AwsGlobalacceleratorCustomRoutingAccelerator resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsGlobalacceleratorCustomRoutingAccelerator to import
    * @param importFromId The id of the existing AwsGlobalacceleratorCustomRoutingAccelerator that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_accelerator#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsGlobalacceleratorCustomRoutingAccelerator to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_accelerator aws_globalaccelerator_custom_routing_accelerator} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsGlobalacceleratorCustomRoutingAcceleratorConfig
    */
    constructor(scope: Construct, id: string, config: AwsGlobalacceleratorCustomRoutingAcceleratorConfig);
    get arn(): string;
    get dnsName(): string;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    get hostedZoneId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipAddressType?;
    get ipAddressType(): string;
    set ipAddressType(value: string);
    resetIpAddressType(): void;
    get ipAddressTypeInput(): string | undefined;
    private _ipAddresses?;
    get ipAddresses(): string[];
    set ipAddresses(value: string[]);
    resetIpAddresses(): void;
    get ipAddressesInput(): string[] | undefined;
    private _ipSets;
    get ipSets(): AwsGlobalacceleratorCustomRoutingAccelerator.IpSetsPropertyList;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _attributes;
    get attributes(): AwsGlobalacceleratorCustomRoutingAccelerator.AttributesPropertyOutputReference;
    putAttributes(value: AwsGlobalacceleratorCustomRoutingAccelerator.AttributesProperty): void;
    resetAttributes(): void;
    get attributesInput(): AwsGlobalacceleratorCustomRoutingAccelerator.AttributesProperty | undefined;
    private _timeouts;
    get timeouts(): AwsGlobalacceleratorCustomRoutingAccelerator.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsGlobalacceleratorCustomRoutingAccelerator.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsGlobalacceleratorCustomRoutingAccelerator.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsGlobalacceleratorCustomRoutingAcceleratorIpSetsPropertyToTerraform(struct?: AwsGlobalacceleratorCustomRoutingAccelerator.IpSetsProperty): any;
export declare function awsGlobalacceleratorCustomRoutingAcceleratorIpSetsPropertyToHclTerraform(struct?: AwsGlobalacceleratorCustomRoutingAccelerator.IpSetsProperty): any;
export declare function awsGlobalacceleratorCustomRoutingAcceleratorAttributesPropertyToTerraform(struct?: AwsGlobalacceleratorCustomRoutingAccelerator.AttributesPropertyOutputReference | AwsGlobalacceleratorCustomRoutingAccelerator.AttributesProperty): any;
export declare function awsGlobalacceleratorCustomRoutingAcceleratorAttributesPropertyToHclTerraform(struct?: AwsGlobalacceleratorCustomRoutingAccelerator.AttributesPropertyOutputReference | AwsGlobalacceleratorCustomRoutingAccelerator.AttributesProperty): any;
export declare function awsGlobalacceleratorCustomRoutingAcceleratorTimeoutsPropertyToTerraform(struct?: AwsGlobalacceleratorCustomRoutingAccelerator.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsGlobalacceleratorCustomRoutingAcceleratorTimeoutsPropertyToHclTerraform(struct?: AwsGlobalacceleratorCustomRoutingAccelerator.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsGlobalacceleratorCustomRoutingAccelerator {
    interface IpSetsProperty {
    }
    class IpSetsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IpSetsProperty | undefined;
        set internalValue(value: IpSetsProperty | undefined);
        get ipAddresses(): string[];
        get ipFamily(): string;
    }
    class IpSetsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IpSetsPropertyOutputReference;
    }
    interface AttributesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_accelerator#flow_logs_enabled AwsGlobalacceleratorCustomRoutingAccelerator#flow_logs_enabled}
        */
        readonly flowLogsEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_accelerator#flow_logs_s3_bucket AwsGlobalacceleratorCustomRoutingAccelerator#flow_logs_s3_bucket}
        */
        readonly flowLogsS3Bucket?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_accelerator#flow_logs_s3_prefix AwsGlobalacceleratorCustomRoutingAccelerator#flow_logs_s3_prefix}
        */
        readonly flowLogsS3Prefix?: string;
    }
    class AttributesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AttributesProperty | undefined;
        set internalValue(value: AttributesProperty | undefined);
        private _flowLogsEnabled?;
        get flowLogsEnabled(): boolean | cdktn.IResolvable;
        set flowLogsEnabled(value: boolean | cdktn.IResolvable);
        resetFlowLogsEnabled(): void;
        get flowLogsEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _flowLogsS3Bucket?;
        get flowLogsS3Bucket(): string;
        set flowLogsS3Bucket(value: string);
        resetFlowLogsS3Bucket(): void;
        get flowLogsS3BucketInput(): string | undefined;
        private _flowLogsS3Prefix?;
        get flowLogsS3Prefix(): string;
        set flowLogsS3Prefix(value: string);
        resetFlowLogsS3Prefix(): void;
        get flowLogsS3PrefixInput(): string | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_accelerator#create AwsGlobalacceleratorCustomRoutingAccelerator#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_accelerator#update AwsGlobalacceleratorCustomRoutingAccelerator#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
