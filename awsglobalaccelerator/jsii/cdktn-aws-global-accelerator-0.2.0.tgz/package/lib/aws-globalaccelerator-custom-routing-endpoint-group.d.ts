import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfCustomRoutingEndpointGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_endpoint_group#endpoint_group_region TfCustomRoutingEndpointGroup#endpoint_group_region}
    */
    readonly endpointGroupRegion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_endpoint_group#id TfCustomRoutingEndpointGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_endpoint_group#listener_arn TfCustomRoutingEndpointGroup#listener_arn}
    */
    readonly listenerArn: string;
    /**
    * destination_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_endpoint_group#destination_configuration TfCustomRoutingEndpointGroup#destination_configuration}
    */
    readonly destinationConfiguration: TfCustomRoutingEndpointGroup.DestinationConfigurationProperty[] | cdktn.IResolvable;
    /**
    * endpoint_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_endpoint_group#endpoint_configuration TfCustomRoutingEndpointGroup#endpoint_configuration}
    */
    readonly endpointConfiguration?: TfCustomRoutingEndpointGroup.EndpointConfigurationProperty[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_endpoint_group#timeouts TfCustomRoutingEndpointGroup#timeouts}
    */
    readonly timeouts?: TfCustomRoutingEndpointGroup.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_endpoint_group aws_globalaccelerator_custom_routing_endpoint_group}
*/
export declare class TfCustomRoutingEndpointGroup extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_globalaccelerator_custom_routing_endpoint_group";
    /**
    * Generates CDKTN code for importing a TfCustomRoutingEndpointGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfCustomRoutingEndpointGroup to import
    * @param importFromId The id of the existing TfCustomRoutingEndpointGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_endpoint_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfCustomRoutingEndpointGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_endpoint_group aws_globalaccelerator_custom_routing_endpoint_group} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfCustomRoutingEndpointGroupConfig
    */
    constructor(scope: Construct, id: string, config: TfCustomRoutingEndpointGroupConfig);
    get arn(): string;
    private _endpointGroupRegion?;
    get endpointGroupRegion(): string;
    set endpointGroupRegion(value: string);
    resetEndpointGroupRegion(): void;
    get endpointGroupRegionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _listenerArn?;
    get listenerArn(): string;
    set listenerArn(value: string);
    get listenerArnInput(): string | undefined;
    private _destinationConfiguration;
    get destinationConfiguration(): TfCustomRoutingEndpointGroup.DestinationConfigurationPropertyList;
    putDestinationConfiguration(value: TfCustomRoutingEndpointGroup.DestinationConfigurationProperty[] | cdktn.IResolvable): void;
    get destinationConfigurationInput(): cdktn.IResolvable | TfCustomRoutingEndpointGroup.DestinationConfigurationProperty[] | undefined;
    private _endpointConfiguration;
    get endpointConfiguration(): TfCustomRoutingEndpointGroup.EndpointConfigurationPropertyList;
    putEndpointConfiguration(value: TfCustomRoutingEndpointGroup.EndpointConfigurationProperty[] | cdktn.IResolvable): void;
    resetEndpointConfiguration(): void;
    get endpointConfigurationInput(): cdktn.IResolvable | TfCustomRoutingEndpointGroup.EndpointConfigurationProperty[] | undefined;
    private _timeouts;
    get timeouts(): TfCustomRoutingEndpointGroup.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfCustomRoutingEndpointGroup.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | TfCustomRoutingEndpointGroup.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfCustomRoutingEndpointGroupDestinationConfigurationPropertyToTerraform(struct?: TfCustomRoutingEndpointGroup.DestinationConfigurationProperty | cdktn.IResolvable): any;
export declare function tfCustomRoutingEndpointGroupDestinationConfigurationPropertyToHclTerraform(struct?: TfCustomRoutingEndpointGroup.DestinationConfigurationProperty | cdktn.IResolvable): any;
export declare function tfCustomRoutingEndpointGroupEndpointConfigurationPropertyToTerraform(struct?: TfCustomRoutingEndpointGroup.EndpointConfigurationProperty | cdktn.IResolvable): any;
export declare function tfCustomRoutingEndpointGroupEndpointConfigurationPropertyToHclTerraform(struct?: TfCustomRoutingEndpointGroup.EndpointConfigurationProperty | cdktn.IResolvable): any;
export declare function tfCustomRoutingEndpointGroupTimeoutsPropertyToTerraform(struct?: TfCustomRoutingEndpointGroup.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfCustomRoutingEndpointGroupTimeoutsPropertyToHclTerraform(struct?: TfCustomRoutingEndpointGroup.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfCustomRoutingEndpointGroup {
    interface DestinationConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_endpoint_group#from_port TfCustomRoutingEndpointGroup#from_port}
        */
        readonly fromPort: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_endpoint_group#protocols TfCustomRoutingEndpointGroup#protocols}
        */
        readonly protocols: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_endpoint_group#to_port TfCustomRoutingEndpointGroup#to_port}
        */
        readonly toPort: number;
    }
    class DestinationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): DestinationConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: DestinationConfigurationProperty | cdktn.IResolvable | undefined);
        private _fromPort?;
        get fromPort(): number;
        set fromPort(value: number);
        get fromPortInput(): number | undefined;
        private _protocols?;
        get protocols(): string[];
        set protocols(value: string[]);
        get protocolsInput(): string[] | undefined;
        private _toPort?;
        get toPort(): number;
        set toPort(value: number);
        get toPortInput(): number | undefined;
    }
    class DestinationConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: DestinationConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): DestinationConfigurationPropertyOutputReference;
    }
    interface EndpointConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_endpoint_group#endpoint_id TfCustomRoutingEndpointGroup#endpoint_id}
        */
        readonly endpointId?: string;
    }
    class EndpointConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EndpointConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EndpointConfigurationProperty | cdktn.IResolvable | undefined);
        private _endpointId?;
        get endpointId(): string;
        set endpointId(value: string);
        resetEndpointId(): void;
        get endpointIdInput(): string | undefined;
    }
    class EndpointConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: EndpointConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EndpointConfigurationPropertyOutputReference;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_endpoint_group#create TfCustomRoutingEndpointGroup#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/globalaccelerator_custom_routing_endpoint_group#delete TfCustomRoutingEndpointGroup#delete}
        */
        readonly delete?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
    }
}
