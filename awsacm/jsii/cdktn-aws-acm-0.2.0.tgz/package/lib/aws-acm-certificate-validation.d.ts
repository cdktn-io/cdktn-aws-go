import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfCertificateValidationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acm_certificate_validation#certificate_arn TfCertificateValidation#certificate_arn}
    */
    readonly certificateArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acm_certificate_validation#id TfCertificateValidation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acm_certificate_validation#region TfCertificateValidation#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acm_certificate_validation#validation_record_fqdns TfCertificateValidation#validation_record_fqdns}
    */
    readonly validationRecordFqdns?: string[];
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acm_certificate_validation#timeouts TfCertificateValidation#timeouts}
    */
    readonly timeouts?: TfCertificateValidation.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acm_certificate_validation aws_acm_certificate_validation}
*/
export declare class TfCertificateValidation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_acm_certificate_validation";
    /**
    * Generates CDKTN code for importing a TfCertificateValidation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfCertificateValidation to import
    * @param importFromId The id of the existing TfCertificateValidation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acm_certificate_validation#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfCertificateValidation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acm_certificate_validation aws_acm_certificate_validation} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfCertificateValidationConfig
    */
    constructor(scope: Construct, id: string, config: TfCertificateValidationConfig);
    private _certificateArn?;
    get certificateArn(): string;
    set certificateArn(value: string);
    get certificateArnInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _validationRecordFqdns?;
    get validationRecordFqdns(): string[];
    set validationRecordFqdns(value: string[]);
    resetValidationRecordFqdns(): void;
    get validationRecordFqdnsInput(): string[] | undefined;
    private _timeouts;
    get timeouts(): TfCertificateValidation.TimeoutsPropertyOutputReference;
    putTimeouts(value: TfCertificateValidation.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): TfCertificateValidation.TimeoutsProperty | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfCertificateValidationTimeoutsPropertyToTerraform(struct?: TfCertificateValidation.TimeoutsProperty | cdktn.IResolvable): any;
export declare function tfCertificateValidationTimeoutsPropertyToHclTerraform(struct?: TfCertificateValidation.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace TfCertificateValidation {
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/acm_certificate_validation#create TfCertificateValidation#create}
        */
        readonly create?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
    }
}
