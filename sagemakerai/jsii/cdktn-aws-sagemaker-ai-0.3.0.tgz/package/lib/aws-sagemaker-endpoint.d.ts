import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsEndpointConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#endpoint_config_name AwsEndpoint#endpoint_config_name}
    */
    readonly endpointConfigName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#id AwsEndpoint#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#name AwsEndpoint#name}
    */
    readonly name?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#region AwsEndpoint#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#tags AwsEndpoint#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#tags_all AwsEndpoint#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * deployment_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#deployment_config AwsEndpoint#deployment_config}
    */
    readonly deploymentConfig?: AwsEndpoint.DeploymentConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint aws_sagemaker_endpoint}
*/
export declare class AwsEndpoint extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sagemaker_endpoint";
    /**
    * Generates CDKTN code for importing a AwsEndpoint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsEndpoint to import
    * @param importFromId The id of the existing AwsEndpoint that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsEndpoint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint aws_sagemaker_endpoint} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsEndpointConfig
    */
    constructor(scope: Construct, id: string, config: AwsEndpointConfig);
    get arn(): string;
    private _endpointConfigName?;
    get endpointConfigName(): string;
    set endpointConfigName(value: string);
    get endpointConfigNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _deploymentConfig;
    get deploymentConfig(): AwsEndpoint.DeploymentConfigPropertyOutputReference;
    putDeploymentConfig(value: AwsEndpoint.DeploymentConfigProperty): void;
    resetDeploymentConfig(): void;
    get deploymentConfigInput(): AwsEndpoint.DeploymentConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsEndpointAlarmsPropertyToTerraform(struct?: AwsEndpoint.AlarmsProperty | cdktn.IResolvable): any;
export declare function awsEndpointAlarmsPropertyToHclTerraform(struct?: AwsEndpoint.AlarmsProperty | cdktn.IResolvable): any;
export declare function awsEndpointAutoRollbackConfigurationPropertyToTerraform(struct?: AwsEndpoint.AutoRollbackConfigurationPropertyOutputReference | AwsEndpoint.AutoRollbackConfigurationProperty): any;
export declare function awsEndpointAutoRollbackConfigurationPropertyToHclTerraform(struct?: AwsEndpoint.AutoRollbackConfigurationPropertyOutputReference | AwsEndpoint.AutoRollbackConfigurationProperty): any;
export declare function awsEndpointCanarySizePropertyToTerraform(struct?: AwsEndpoint.CanarySizePropertyOutputReference | AwsEndpoint.CanarySizeProperty): any;
export declare function awsEndpointCanarySizePropertyToHclTerraform(struct?: AwsEndpoint.CanarySizePropertyOutputReference | AwsEndpoint.CanarySizeProperty): any;
export declare function awsEndpointLinearStepSizePropertyToTerraform(struct?: AwsEndpoint.LinearStepSizePropertyOutputReference | AwsEndpoint.LinearStepSizeProperty): any;
export declare function awsEndpointLinearStepSizePropertyToHclTerraform(struct?: AwsEndpoint.LinearStepSizePropertyOutputReference | AwsEndpoint.LinearStepSizeProperty): any;
export declare function awsEndpointTrafficRoutingConfigurationPropertyToTerraform(struct?: AwsEndpoint.TrafficRoutingConfigurationPropertyOutputReference | AwsEndpoint.TrafficRoutingConfigurationProperty): any;
export declare function awsEndpointTrafficRoutingConfigurationPropertyToHclTerraform(struct?: AwsEndpoint.TrafficRoutingConfigurationPropertyOutputReference | AwsEndpoint.TrafficRoutingConfigurationProperty): any;
export declare function awsEndpointBlueGreenUpdatePolicyPropertyToTerraform(struct?: AwsEndpoint.BlueGreenUpdatePolicyPropertyOutputReference | AwsEndpoint.BlueGreenUpdatePolicyProperty): any;
export declare function awsEndpointBlueGreenUpdatePolicyPropertyToHclTerraform(struct?: AwsEndpoint.BlueGreenUpdatePolicyPropertyOutputReference | AwsEndpoint.BlueGreenUpdatePolicyProperty): any;
export declare function awsEndpointMaximumBatchSizePropertyToTerraform(struct?: AwsEndpoint.MaximumBatchSizePropertyOutputReference | AwsEndpoint.MaximumBatchSizeProperty): any;
export declare function awsEndpointMaximumBatchSizePropertyToHclTerraform(struct?: AwsEndpoint.MaximumBatchSizePropertyOutputReference | AwsEndpoint.MaximumBatchSizeProperty): any;
export declare function awsEndpointRollbackMaximumBatchSizePropertyToTerraform(struct?: AwsEndpoint.RollbackMaximumBatchSizePropertyOutputReference | AwsEndpoint.RollbackMaximumBatchSizeProperty): any;
export declare function awsEndpointRollbackMaximumBatchSizePropertyToHclTerraform(struct?: AwsEndpoint.RollbackMaximumBatchSizePropertyOutputReference | AwsEndpoint.RollbackMaximumBatchSizeProperty): any;
export declare function awsEndpointRollingUpdatePolicyPropertyToTerraform(struct?: AwsEndpoint.RollingUpdatePolicyPropertyOutputReference | AwsEndpoint.RollingUpdatePolicyProperty): any;
export declare function awsEndpointRollingUpdatePolicyPropertyToHclTerraform(struct?: AwsEndpoint.RollingUpdatePolicyPropertyOutputReference | AwsEndpoint.RollingUpdatePolicyProperty): any;
export declare function awsEndpointDeploymentConfigPropertyToTerraform(struct?: AwsEndpoint.DeploymentConfigPropertyOutputReference | AwsEndpoint.DeploymentConfigProperty): any;
export declare function awsEndpointDeploymentConfigPropertyToHclTerraform(struct?: AwsEndpoint.DeploymentConfigPropertyOutputReference | AwsEndpoint.DeploymentConfigProperty): any;
export declare namespace AwsEndpoint {
    interface AlarmsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#alarm_name AwsEndpoint#alarm_name}
        */
        readonly alarmName: string;
    }
    class AlarmsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): AlarmsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: AlarmsProperty | cdktn.IResolvable | undefined);
        private _alarmName?;
        get alarmName(): string;
        set alarmName(value: string);
        get alarmNameInput(): string | undefined;
    }
    class AlarmsPropertyList extends cdktn.ComplexList {
        internalValue?: AlarmsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): AlarmsPropertyOutputReference;
    }
    interface AutoRollbackConfigurationProperty {
        /**
        * alarms block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#alarms AwsEndpoint#alarms}
        */
        readonly alarms?: AlarmsProperty[] | cdktn.IResolvable;
    }
    class AutoRollbackConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AutoRollbackConfigurationProperty | undefined;
        set internalValue(value: AutoRollbackConfigurationProperty | undefined);
        private _alarms;
        get alarms(): AlarmsPropertyList;
        putAlarms(value: AlarmsProperty[] | cdktn.IResolvable): void;
        resetAlarms(): void;
        get alarmsInput(): cdktn.IResolvable | AlarmsProperty[] | undefined;
    }
    interface CanarySizeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#type AwsEndpoint#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#value AwsEndpoint#value}
        */
        readonly value: number;
    }
    class CanarySizePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CanarySizeProperty | undefined;
        set internalValue(value: CanarySizeProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface LinearStepSizeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#type AwsEndpoint#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#value AwsEndpoint#value}
        */
        readonly value: number;
    }
    class LinearStepSizePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): LinearStepSizeProperty | undefined;
        set internalValue(value: LinearStepSizeProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface TrafficRoutingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#type AwsEndpoint#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#wait_interval_in_seconds AwsEndpoint#wait_interval_in_seconds}
        */
        readonly waitIntervalInSeconds: number;
        /**
        * canary_size block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#canary_size AwsEndpoint#canary_size}
        */
        readonly canarySize?: CanarySizeProperty;
        /**
        * linear_step_size block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#linear_step_size AwsEndpoint#linear_step_size}
        */
        readonly linearStepSize?: LinearStepSizeProperty;
    }
    class TrafficRoutingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TrafficRoutingConfigurationProperty | undefined;
        set internalValue(value: TrafficRoutingConfigurationProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _waitIntervalInSeconds?;
        get waitIntervalInSeconds(): number;
        set waitIntervalInSeconds(value: number);
        get waitIntervalInSecondsInput(): number | undefined;
        private _canarySize;
        get canarySize(): CanarySizePropertyOutputReference;
        putCanarySize(value: CanarySizeProperty): void;
        resetCanarySize(): void;
        get canarySizeInput(): CanarySizeProperty | undefined;
        private _linearStepSize;
        get linearStepSize(): LinearStepSizePropertyOutputReference;
        putLinearStepSize(value: LinearStepSizeProperty): void;
        resetLinearStepSize(): void;
        get linearStepSizeInput(): LinearStepSizeProperty | undefined;
    }
    interface BlueGreenUpdatePolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#maximum_execution_timeout_in_seconds AwsEndpoint#maximum_execution_timeout_in_seconds}
        */
        readonly maximumExecutionTimeoutInSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#termination_wait_in_seconds AwsEndpoint#termination_wait_in_seconds}
        */
        readonly terminationWaitInSeconds?: number;
        /**
        * traffic_routing_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#traffic_routing_configuration AwsEndpoint#traffic_routing_configuration}
        */
        readonly trafficRoutingConfiguration: TrafficRoutingConfigurationProperty;
    }
    class BlueGreenUpdatePolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): BlueGreenUpdatePolicyProperty | undefined;
        set internalValue(value: BlueGreenUpdatePolicyProperty | undefined);
        private _maximumExecutionTimeoutInSeconds?;
        get maximumExecutionTimeoutInSeconds(): number;
        set maximumExecutionTimeoutInSeconds(value: number);
        resetMaximumExecutionTimeoutInSeconds(): void;
        get maximumExecutionTimeoutInSecondsInput(): number | undefined;
        private _terminationWaitInSeconds?;
        get terminationWaitInSeconds(): number;
        set terminationWaitInSeconds(value: number);
        resetTerminationWaitInSeconds(): void;
        get terminationWaitInSecondsInput(): number | undefined;
        private _trafficRoutingConfiguration;
        get trafficRoutingConfiguration(): TrafficRoutingConfigurationPropertyOutputReference;
        putTrafficRoutingConfiguration(value: TrafficRoutingConfigurationProperty): void;
        get trafficRoutingConfigurationInput(): TrafficRoutingConfigurationProperty | undefined;
    }
    interface MaximumBatchSizeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#type AwsEndpoint#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#value AwsEndpoint#value}
        */
        readonly value: number;
    }
    class MaximumBatchSizePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MaximumBatchSizeProperty | undefined;
        set internalValue(value: MaximumBatchSizeProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface RollbackMaximumBatchSizeProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#type AwsEndpoint#type}
        */
        readonly type: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#value AwsEndpoint#value}
        */
        readonly value: number;
    }
    class RollbackMaximumBatchSizePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RollbackMaximumBatchSizeProperty | undefined;
        set internalValue(value: RollbackMaximumBatchSizeProperty | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _value?;
        get value(): number;
        set value(value: number);
        get valueInput(): number | undefined;
    }
    interface RollingUpdatePolicyProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#maximum_execution_timeout_in_seconds AwsEndpoint#maximum_execution_timeout_in_seconds}
        */
        readonly maximumExecutionTimeoutInSeconds?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#wait_interval_in_seconds AwsEndpoint#wait_interval_in_seconds}
        */
        readonly waitIntervalInSeconds: number;
        /**
        * maximum_batch_size block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#maximum_batch_size AwsEndpoint#maximum_batch_size}
        */
        readonly maximumBatchSize: MaximumBatchSizeProperty;
        /**
        * rollback_maximum_batch_size block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#rollback_maximum_batch_size AwsEndpoint#rollback_maximum_batch_size}
        */
        readonly rollbackMaximumBatchSize?: RollbackMaximumBatchSizeProperty;
    }
    class RollingUpdatePolicyPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RollingUpdatePolicyProperty | undefined;
        set internalValue(value: RollingUpdatePolicyProperty | undefined);
        private _maximumExecutionTimeoutInSeconds?;
        get maximumExecutionTimeoutInSeconds(): number;
        set maximumExecutionTimeoutInSeconds(value: number);
        resetMaximumExecutionTimeoutInSeconds(): void;
        get maximumExecutionTimeoutInSecondsInput(): number | undefined;
        private _waitIntervalInSeconds?;
        get waitIntervalInSeconds(): number;
        set waitIntervalInSeconds(value: number);
        get waitIntervalInSecondsInput(): number | undefined;
        private _maximumBatchSize;
        get maximumBatchSize(): MaximumBatchSizePropertyOutputReference;
        putMaximumBatchSize(value: MaximumBatchSizeProperty): void;
        get maximumBatchSizeInput(): MaximumBatchSizeProperty | undefined;
        private _rollbackMaximumBatchSize;
        get rollbackMaximumBatchSize(): RollbackMaximumBatchSizePropertyOutputReference;
        putRollbackMaximumBatchSize(value: RollbackMaximumBatchSizeProperty): void;
        resetRollbackMaximumBatchSize(): void;
        get rollbackMaximumBatchSizeInput(): RollbackMaximumBatchSizeProperty | undefined;
    }
    interface DeploymentConfigProperty {
        /**
        * auto_rollback_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#auto_rollback_configuration AwsEndpoint#auto_rollback_configuration}
        */
        readonly autoRollbackConfiguration?: AutoRollbackConfigurationProperty;
        /**
        * blue_green_update_policy block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#blue_green_update_policy AwsEndpoint#blue_green_update_policy}
        */
        readonly blueGreenUpdatePolicy?: BlueGreenUpdatePolicyProperty;
        /**
        * rolling_update_policy block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_endpoint#rolling_update_policy AwsEndpoint#rolling_update_policy}
        */
        readonly rollingUpdatePolicy?: RollingUpdatePolicyProperty;
    }
    class DeploymentConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DeploymentConfigProperty | undefined;
        set internalValue(value: DeploymentConfigProperty | undefined);
        private _autoRollbackConfiguration;
        get autoRollbackConfiguration(): AutoRollbackConfigurationPropertyOutputReference;
        putAutoRollbackConfiguration(value: AutoRollbackConfigurationProperty): void;
        resetAutoRollbackConfiguration(): void;
        get autoRollbackConfigurationInput(): AutoRollbackConfigurationProperty | undefined;
        private _blueGreenUpdatePolicy;
        get blueGreenUpdatePolicy(): BlueGreenUpdatePolicyPropertyOutputReference;
        putBlueGreenUpdatePolicy(value: BlueGreenUpdatePolicyProperty): void;
        resetBlueGreenUpdatePolicy(): void;
        get blueGreenUpdatePolicyInput(): BlueGreenUpdatePolicyProperty | undefined;
        private _rollingUpdatePolicy;
        get rollingUpdatePolicy(): RollingUpdatePolicyPropertyOutputReference;
        putRollingUpdatePolicy(value: RollingUpdatePolicyProperty): void;
        resetRollingUpdatePolicy(): void;
        get rollingUpdatePolicyInput(): RollingUpdatePolicyProperty | undefined;
    }
}
