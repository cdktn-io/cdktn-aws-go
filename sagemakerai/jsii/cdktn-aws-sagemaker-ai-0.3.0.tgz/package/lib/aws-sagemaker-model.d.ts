import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsModelConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#enable_network_isolation AwsModel#enable_network_isolation}
    */
    readonly enableNetworkIsolation?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#execution_role_arn AwsModel#execution_role_arn}
    */
    readonly executionRoleArn: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#id AwsModel#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#name AwsModel#name}
    */
    readonly name?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#region AwsModel#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#tags AwsModel#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#tags_all AwsModel#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * container block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#container AwsModel#container}
    */
    readonly container?: AwsModel.ContainerProperty[] | cdktn.IResolvable;
    /**
    * inference_execution_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#inference_execution_config AwsModel#inference_execution_config}
    */
    readonly inferenceExecutionConfig?: AwsModel.InferenceExecutionConfigProperty;
    /**
    * primary_container block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#primary_container AwsModel#primary_container}
    */
    readonly primaryContainer?: AwsModel.PrimaryContainerProperty;
    /**
    * vpc_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#vpc_config AwsModel#vpc_config}
    */
    readonly vpcConfig?: AwsModel.VpcConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model aws_sagemaker_model}
*/
export declare class AwsModel extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sagemaker_model";
    /**
    * Generates CDKTN code for importing a AwsModel resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsModel to import
    * @param importFromId The id of the existing AwsModel that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsModel to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model aws_sagemaker_model} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsModelConfig
    */
    constructor(scope: Construct, id: string, config: AwsModelConfig);
    get arn(): string;
    private _enableNetworkIsolation?;
    get enableNetworkIsolation(): boolean | cdktn.IResolvable;
    set enableNetworkIsolation(value: boolean | cdktn.IResolvable);
    resetEnableNetworkIsolation(): void;
    get enableNetworkIsolationInput(): boolean | cdktn.IResolvable | undefined;
    private _executionRoleArn?;
    get executionRoleArn(): string;
    set executionRoleArn(value: string);
    get executionRoleArnInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _container;
    get container(): AwsModel.ContainerPropertyList;
    putContainer(value: AwsModel.ContainerProperty[] | cdktn.IResolvable): void;
    resetContainer(): void;
    get containerInput(): cdktn.IResolvable | AwsModel.ContainerProperty[] | undefined;
    private _inferenceExecutionConfig;
    get inferenceExecutionConfig(): AwsModel.InferenceExecutionConfigPropertyOutputReference;
    putInferenceExecutionConfig(value: AwsModel.InferenceExecutionConfigProperty): void;
    resetInferenceExecutionConfig(): void;
    get inferenceExecutionConfigInput(): AwsModel.InferenceExecutionConfigProperty | undefined;
    private _primaryContainer;
    get primaryContainer(): AwsModel.PrimaryContainerPropertyOutputReference;
    putPrimaryContainer(value: AwsModel.PrimaryContainerProperty): void;
    resetPrimaryContainer(): void;
    get primaryContainerInput(): AwsModel.PrimaryContainerProperty | undefined;
    private _vpcConfig;
    get vpcConfig(): AwsModel.VpcConfigPropertyOutputReference;
    putVpcConfig(value: AwsModel.VpcConfigProperty): void;
    resetVpcConfig(): void;
    get vpcConfigInput(): AwsModel.VpcConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsModelContainerAdditionalModelDataSourceS3DataSourceModelAccessConfigPropertyToTerraform(struct?: AwsModel.ContainerAdditionalModelDataSourceS3DataSourceModelAccessConfigPropertyOutputReference | AwsModel.ContainerAdditionalModelDataSourceS3DataSourceModelAccessConfigProperty): any;
export declare function awsModelContainerAdditionalModelDataSourceS3DataSourceModelAccessConfigPropertyToHclTerraform(struct?: AwsModel.ContainerAdditionalModelDataSourceS3DataSourceModelAccessConfigPropertyOutputReference | AwsModel.ContainerAdditionalModelDataSourceS3DataSourceModelAccessConfigProperty): any;
export declare function awsModelContainerAdditionalModelDataSourceS3DataSourcePropertyToTerraform(struct?: AwsModel.ContainerAdditionalModelDataSourceS3DataSourceProperty | cdktn.IResolvable): any;
export declare function awsModelContainerAdditionalModelDataSourceS3DataSourcePropertyToHclTerraform(struct?: AwsModel.ContainerAdditionalModelDataSourceS3DataSourceProperty | cdktn.IResolvable): any;
export declare function awsModelContainerAdditionalModelDataSourcePropertyToTerraform(struct?: AwsModel.ContainerAdditionalModelDataSourceProperty | cdktn.IResolvable): any;
export declare function awsModelContainerAdditionalModelDataSourcePropertyToHclTerraform(struct?: AwsModel.ContainerAdditionalModelDataSourceProperty | cdktn.IResolvable): any;
export declare function awsModelContainerImageConfigRepositoryAuthConfigPropertyToTerraform(struct?: AwsModel.ContainerImageConfigRepositoryAuthConfigPropertyOutputReference | AwsModel.ContainerImageConfigRepositoryAuthConfigProperty): any;
export declare function awsModelContainerImageConfigRepositoryAuthConfigPropertyToHclTerraform(struct?: AwsModel.ContainerImageConfigRepositoryAuthConfigPropertyOutputReference | AwsModel.ContainerImageConfigRepositoryAuthConfigProperty): any;
export declare function awsModelContainerImageConfigPropertyToTerraform(struct?: AwsModel.ContainerImageConfigPropertyOutputReference | AwsModel.ContainerImageConfigProperty): any;
export declare function awsModelContainerImageConfigPropertyToHclTerraform(struct?: AwsModel.ContainerImageConfigPropertyOutputReference | AwsModel.ContainerImageConfigProperty): any;
export declare function awsModelContainerModelDataSourceS3DataSourceModelAccessConfigPropertyToTerraform(struct?: AwsModel.ContainerModelDataSourceS3DataSourceModelAccessConfigPropertyOutputReference | AwsModel.ContainerModelDataSourceS3DataSourceModelAccessConfigProperty): any;
export declare function awsModelContainerModelDataSourceS3DataSourceModelAccessConfigPropertyToHclTerraform(struct?: AwsModel.ContainerModelDataSourceS3DataSourceModelAccessConfigPropertyOutputReference | AwsModel.ContainerModelDataSourceS3DataSourceModelAccessConfigProperty): any;
export declare function awsModelContainerModelDataSourceS3DataSourcePropertyToTerraform(struct?: AwsModel.ContainerModelDataSourceS3DataSourceProperty | cdktn.IResolvable): any;
export declare function awsModelContainerModelDataSourceS3DataSourcePropertyToHclTerraform(struct?: AwsModel.ContainerModelDataSourceS3DataSourceProperty | cdktn.IResolvable): any;
export declare function awsModelContainerModelDataSourcePropertyToTerraform(struct?: AwsModel.ContainerModelDataSourcePropertyOutputReference | AwsModel.ContainerModelDataSourceProperty): any;
export declare function awsModelContainerModelDataSourcePropertyToHclTerraform(struct?: AwsModel.ContainerModelDataSourcePropertyOutputReference | AwsModel.ContainerModelDataSourceProperty): any;
export declare function awsModelContainerMultiModelConfigPropertyToTerraform(struct?: AwsModel.ContainerMultiModelConfigPropertyOutputReference | AwsModel.ContainerMultiModelConfigProperty): any;
export declare function awsModelContainerMultiModelConfigPropertyToHclTerraform(struct?: AwsModel.ContainerMultiModelConfigPropertyOutputReference | AwsModel.ContainerMultiModelConfigProperty): any;
export declare function awsModelContainerPropertyToTerraform(struct?: AwsModel.ContainerProperty | cdktn.IResolvable): any;
export declare function awsModelContainerPropertyToHclTerraform(struct?: AwsModel.ContainerProperty | cdktn.IResolvable): any;
export declare function awsModelInferenceExecutionConfigPropertyToTerraform(struct?: AwsModel.InferenceExecutionConfigPropertyOutputReference | AwsModel.InferenceExecutionConfigProperty): any;
export declare function awsModelInferenceExecutionConfigPropertyToHclTerraform(struct?: AwsModel.InferenceExecutionConfigPropertyOutputReference | AwsModel.InferenceExecutionConfigProperty): any;
export declare function awsModelPrimaryContainerAdditionalModelDataSourceS3DataSourceModelAccessConfigPropertyToTerraform(struct?: AwsModel.PrimaryContainerAdditionalModelDataSourceS3DataSourceModelAccessConfigPropertyOutputReference | AwsModel.PrimaryContainerAdditionalModelDataSourceS3DataSourceModelAccessConfigProperty): any;
export declare function awsModelPrimaryContainerAdditionalModelDataSourceS3DataSourceModelAccessConfigPropertyToHclTerraform(struct?: AwsModel.PrimaryContainerAdditionalModelDataSourceS3DataSourceModelAccessConfigPropertyOutputReference | AwsModel.PrimaryContainerAdditionalModelDataSourceS3DataSourceModelAccessConfigProperty): any;
export declare function awsModelPrimaryContainerAdditionalModelDataSourceS3DataSourcePropertyToTerraform(struct?: AwsModel.PrimaryContainerAdditionalModelDataSourceS3DataSourceProperty | cdktn.IResolvable): any;
export declare function awsModelPrimaryContainerAdditionalModelDataSourceS3DataSourcePropertyToHclTerraform(struct?: AwsModel.PrimaryContainerAdditionalModelDataSourceS3DataSourceProperty | cdktn.IResolvable): any;
export declare function awsModelPrimaryContainerAdditionalModelDataSourcePropertyToTerraform(struct?: AwsModel.PrimaryContainerAdditionalModelDataSourceProperty | cdktn.IResolvable): any;
export declare function awsModelPrimaryContainerAdditionalModelDataSourcePropertyToHclTerraform(struct?: AwsModel.PrimaryContainerAdditionalModelDataSourceProperty | cdktn.IResolvable): any;
export declare function awsModelPrimaryContainerImageConfigRepositoryAuthConfigPropertyToTerraform(struct?: AwsModel.PrimaryContainerImageConfigRepositoryAuthConfigPropertyOutputReference | AwsModel.PrimaryContainerImageConfigRepositoryAuthConfigProperty): any;
export declare function awsModelPrimaryContainerImageConfigRepositoryAuthConfigPropertyToHclTerraform(struct?: AwsModel.PrimaryContainerImageConfigRepositoryAuthConfigPropertyOutputReference | AwsModel.PrimaryContainerImageConfigRepositoryAuthConfigProperty): any;
export declare function awsModelPrimaryContainerImageConfigPropertyToTerraform(struct?: AwsModel.PrimaryContainerImageConfigPropertyOutputReference | AwsModel.PrimaryContainerImageConfigProperty): any;
export declare function awsModelPrimaryContainerImageConfigPropertyToHclTerraform(struct?: AwsModel.PrimaryContainerImageConfigPropertyOutputReference | AwsModel.PrimaryContainerImageConfigProperty): any;
export declare function awsModelPrimaryContainerModelDataSourceS3DataSourceModelAccessConfigPropertyToTerraform(struct?: AwsModel.PrimaryContainerModelDataSourceS3DataSourceModelAccessConfigPropertyOutputReference | AwsModel.PrimaryContainerModelDataSourceS3DataSourceModelAccessConfigProperty): any;
export declare function awsModelPrimaryContainerModelDataSourceS3DataSourceModelAccessConfigPropertyToHclTerraform(struct?: AwsModel.PrimaryContainerModelDataSourceS3DataSourceModelAccessConfigPropertyOutputReference | AwsModel.PrimaryContainerModelDataSourceS3DataSourceModelAccessConfigProperty): any;
export declare function awsModelPrimaryContainerModelDataSourceS3DataSourcePropertyToTerraform(struct?: AwsModel.PrimaryContainerModelDataSourceS3DataSourceProperty | cdktn.IResolvable): any;
export declare function awsModelPrimaryContainerModelDataSourceS3DataSourcePropertyToHclTerraform(struct?: AwsModel.PrimaryContainerModelDataSourceS3DataSourceProperty | cdktn.IResolvable): any;
export declare function awsModelPrimaryContainerModelDataSourcePropertyToTerraform(struct?: AwsModel.PrimaryContainerModelDataSourcePropertyOutputReference | AwsModel.PrimaryContainerModelDataSourceProperty): any;
export declare function awsModelPrimaryContainerModelDataSourcePropertyToHclTerraform(struct?: AwsModel.PrimaryContainerModelDataSourcePropertyOutputReference | AwsModel.PrimaryContainerModelDataSourceProperty): any;
export declare function awsModelPrimaryContainerMultiModelConfigPropertyToTerraform(struct?: AwsModel.PrimaryContainerMultiModelConfigPropertyOutputReference | AwsModel.PrimaryContainerMultiModelConfigProperty): any;
export declare function awsModelPrimaryContainerMultiModelConfigPropertyToHclTerraform(struct?: AwsModel.PrimaryContainerMultiModelConfigPropertyOutputReference | AwsModel.PrimaryContainerMultiModelConfigProperty): any;
export declare function awsModelPrimaryContainerPropertyToTerraform(struct?: AwsModel.PrimaryContainerPropertyOutputReference | AwsModel.PrimaryContainerProperty): any;
export declare function awsModelPrimaryContainerPropertyToHclTerraform(struct?: AwsModel.PrimaryContainerPropertyOutputReference | AwsModel.PrimaryContainerProperty): any;
export declare function awsModelVpcConfigPropertyToTerraform(struct?: AwsModel.VpcConfigPropertyOutputReference | AwsModel.VpcConfigProperty): any;
export declare function awsModelVpcConfigPropertyToHclTerraform(struct?: AwsModel.VpcConfigPropertyOutputReference | AwsModel.VpcConfigProperty): any;
export declare namespace AwsModel {
    interface ContainerAdditionalModelDataSourceS3DataSourceModelAccessConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#accept_eula AwsModel#accept_eula}
        */
        readonly acceptEula: boolean | cdktn.IResolvable;
    }
    class ContainerAdditionalModelDataSourceS3DataSourceModelAccessConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ContainerAdditionalModelDataSourceS3DataSourceModelAccessConfigProperty | undefined;
        set internalValue(value: ContainerAdditionalModelDataSourceS3DataSourceModelAccessConfigProperty | undefined);
        private _acceptEula?;
        get acceptEula(): boolean | cdktn.IResolvable;
        set acceptEula(value: boolean | cdktn.IResolvable);
        get acceptEulaInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface ContainerAdditionalModelDataSourceS3DataSourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#compression_type AwsModel#compression_type}
        */
        readonly compressionType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#s3_data_type AwsModel#s3_data_type}
        */
        readonly s3DataType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#s3_uri AwsModel#s3_uri}
        */
        readonly s3Uri: string;
        /**
        * model_access_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#model_access_config AwsModel#model_access_config}
        */
        readonly modelAccessConfig?: ContainerAdditionalModelDataSourceS3DataSourceModelAccessConfigProperty;
    }
    class ContainerAdditionalModelDataSourceS3DataSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ContainerAdditionalModelDataSourceS3DataSourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ContainerAdditionalModelDataSourceS3DataSourceProperty | cdktn.IResolvable | undefined);
        private _compressionType?;
        get compressionType(): string;
        set compressionType(value: string);
        get compressionTypeInput(): string | undefined;
        private _s3DataType?;
        get s3DataType(): string;
        set s3DataType(value: string);
        get s3DataTypeInput(): string | undefined;
        private _s3Uri?;
        get s3Uri(): string;
        set s3Uri(value: string);
        get s3UriInput(): string | undefined;
        private _modelAccessConfig;
        get modelAccessConfig(): ContainerAdditionalModelDataSourceS3DataSourceModelAccessConfigPropertyOutputReference;
        putModelAccessConfig(value: ContainerAdditionalModelDataSourceS3DataSourceModelAccessConfigProperty): void;
        resetModelAccessConfig(): void;
        get modelAccessConfigInput(): ContainerAdditionalModelDataSourceS3DataSourceModelAccessConfigProperty | undefined;
    }
    class ContainerAdditionalModelDataSourceS3DataSourcePropertyList extends cdktn.ComplexList {
        internalValue?: ContainerAdditionalModelDataSourceS3DataSourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ContainerAdditionalModelDataSourceS3DataSourcePropertyOutputReference;
    }
    interface ContainerAdditionalModelDataSourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#channel_name AwsModel#channel_name}
        */
        readonly channelName: string;
        /**
        * s3_data_source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#s3_data_source AwsModel#s3_data_source}
        */
        readonly s3DataSource: ContainerAdditionalModelDataSourceS3DataSourceProperty[] | cdktn.IResolvable;
    }
    class ContainerAdditionalModelDataSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ContainerAdditionalModelDataSourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ContainerAdditionalModelDataSourceProperty | cdktn.IResolvable | undefined);
        private _channelName?;
        get channelName(): string;
        set channelName(value: string);
        get channelNameInput(): string | undefined;
        private _s3DataSource;
        get s3DataSource(): ContainerAdditionalModelDataSourceS3DataSourcePropertyList;
        putS3DataSource(value: ContainerAdditionalModelDataSourceS3DataSourceProperty[] | cdktn.IResolvable): void;
        get s3DataSourceInput(): cdktn.IResolvable | ContainerAdditionalModelDataSourceS3DataSourceProperty[] | undefined;
    }
    class ContainerAdditionalModelDataSourcePropertyList extends cdktn.ComplexList {
        internalValue?: ContainerAdditionalModelDataSourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ContainerAdditionalModelDataSourcePropertyOutputReference;
    }
    interface ContainerImageConfigRepositoryAuthConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#repository_credentials_provider_arn AwsModel#repository_credentials_provider_arn}
        */
        readonly repositoryCredentialsProviderArn: string;
    }
    class ContainerImageConfigRepositoryAuthConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ContainerImageConfigRepositoryAuthConfigProperty | undefined;
        set internalValue(value: ContainerImageConfigRepositoryAuthConfigProperty | undefined);
        private _repositoryCredentialsProviderArn?;
        get repositoryCredentialsProviderArn(): string;
        set repositoryCredentialsProviderArn(value: string);
        get repositoryCredentialsProviderArnInput(): string | undefined;
    }
    interface ContainerImageConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#repository_access_mode AwsModel#repository_access_mode}
        */
        readonly repositoryAccessMode: string;
        /**
        * repository_auth_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#repository_auth_config AwsModel#repository_auth_config}
        */
        readonly repositoryAuthConfig?: ContainerImageConfigRepositoryAuthConfigProperty;
    }
    class ContainerImageConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ContainerImageConfigProperty | undefined;
        set internalValue(value: ContainerImageConfigProperty | undefined);
        private _repositoryAccessMode?;
        get repositoryAccessMode(): string;
        set repositoryAccessMode(value: string);
        get repositoryAccessModeInput(): string | undefined;
        private _repositoryAuthConfig;
        get repositoryAuthConfig(): ContainerImageConfigRepositoryAuthConfigPropertyOutputReference;
        putRepositoryAuthConfig(value: ContainerImageConfigRepositoryAuthConfigProperty): void;
        resetRepositoryAuthConfig(): void;
        get repositoryAuthConfigInput(): ContainerImageConfigRepositoryAuthConfigProperty | undefined;
    }
    interface ContainerModelDataSourceS3DataSourceModelAccessConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#accept_eula AwsModel#accept_eula}
        */
        readonly acceptEula: boolean | cdktn.IResolvable;
    }
    class ContainerModelDataSourceS3DataSourceModelAccessConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ContainerModelDataSourceS3DataSourceModelAccessConfigProperty | undefined;
        set internalValue(value: ContainerModelDataSourceS3DataSourceModelAccessConfigProperty | undefined);
        private _acceptEula?;
        get acceptEula(): boolean | cdktn.IResolvable;
        set acceptEula(value: boolean | cdktn.IResolvable);
        get acceptEulaInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface ContainerModelDataSourceS3DataSourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#compression_type AwsModel#compression_type}
        */
        readonly compressionType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#s3_data_type AwsModel#s3_data_type}
        */
        readonly s3DataType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#s3_uri AwsModel#s3_uri}
        */
        readonly s3Uri: string;
        /**
        * model_access_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#model_access_config AwsModel#model_access_config}
        */
        readonly modelAccessConfig?: ContainerModelDataSourceS3DataSourceModelAccessConfigProperty;
    }
    class ContainerModelDataSourceS3DataSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ContainerModelDataSourceS3DataSourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ContainerModelDataSourceS3DataSourceProperty | cdktn.IResolvable | undefined);
        private _compressionType?;
        get compressionType(): string;
        set compressionType(value: string);
        get compressionTypeInput(): string | undefined;
        private _s3DataType?;
        get s3DataType(): string;
        set s3DataType(value: string);
        get s3DataTypeInput(): string | undefined;
        private _s3Uri?;
        get s3Uri(): string;
        set s3Uri(value: string);
        get s3UriInput(): string | undefined;
        private _modelAccessConfig;
        get modelAccessConfig(): ContainerModelDataSourceS3DataSourceModelAccessConfigPropertyOutputReference;
        putModelAccessConfig(value: ContainerModelDataSourceS3DataSourceModelAccessConfigProperty): void;
        resetModelAccessConfig(): void;
        get modelAccessConfigInput(): ContainerModelDataSourceS3DataSourceModelAccessConfigProperty | undefined;
    }
    class ContainerModelDataSourceS3DataSourcePropertyList extends cdktn.ComplexList {
        internalValue?: ContainerModelDataSourceS3DataSourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ContainerModelDataSourceS3DataSourcePropertyOutputReference;
    }
    interface ContainerModelDataSourceProperty {
        /**
        * s3_data_source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#s3_data_source AwsModel#s3_data_source}
        */
        readonly s3DataSource: ContainerModelDataSourceS3DataSourceProperty[] | cdktn.IResolvable;
    }
    class ContainerModelDataSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ContainerModelDataSourceProperty | undefined;
        set internalValue(value: ContainerModelDataSourceProperty | undefined);
        private _s3DataSource;
        get s3DataSource(): ContainerModelDataSourceS3DataSourcePropertyList;
        putS3DataSource(value: ContainerModelDataSourceS3DataSourceProperty[] | cdktn.IResolvable): void;
        get s3DataSourceInput(): cdktn.IResolvable | ContainerModelDataSourceS3DataSourceProperty[] | undefined;
    }
    interface ContainerMultiModelConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#model_cache_setting AwsModel#model_cache_setting}
        */
        readonly modelCacheSetting?: string;
    }
    class ContainerMultiModelConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ContainerMultiModelConfigProperty | undefined;
        set internalValue(value: ContainerMultiModelConfigProperty | undefined);
        private _modelCacheSetting?;
        get modelCacheSetting(): string;
        set modelCacheSetting(value: string);
        resetModelCacheSetting(): void;
        get modelCacheSettingInput(): string | undefined;
    }
    interface ContainerProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#container_hostname AwsModel#container_hostname}
        */
        readonly containerHostname?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#environment AwsModel#environment}
        */
        readonly environment?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#image AwsModel#image}
        */
        readonly image?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#inference_specification_name AwsModel#inference_specification_name}
        */
        readonly inferenceSpecificationName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#mode AwsModel#mode}
        */
        readonly mode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#model_data_url AwsModel#model_data_url}
        */
        readonly modelDataUrl?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#model_package_name AwsModel#model_package_name}
        */
        readonly modelPackageName?: string;
        /**
        * additional_model_data_source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#additional_model_data_source AwsModel#additional_model_data_source}
        */
        readonly additionalModelDataSource?: ContainerAdditionalModelDataSourceProperty[] | cdktn.IResolvable;
        /**
        * image_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#image_config AwsModel#image_config}
        */
        readonly imageConfig?: ContainerImageConfigProperty;
        /**
        * model_data_source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#model_data_source AwsModel#model_data_source}
        */
        readonly modelDataSource?: ContainerModelDataSourceProperty;
        /**
        * multi_model_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#multi_model_config AwsModel#multi_model_config}
        */
        readonly multiModelConfig?: ContainerMultiModelConfigProperty;
    }
    class ContainerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ContainerProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ContainerProperty | cdktn.IResolvable | undefined);
        private _containerHostname?;
        get containerHostname(): string;
        set containerHostname(value: string);
        resetContainerHostname(): void;
        get containerHostnameInput(): string | undefined;
        private _environment?;
        get environment(): {
            [key: string]: string;
        };
        set environment(value: {
            [key: string]: string;
        });
        resetEnvironment(): void;
        get environmentInput(): {
            [key: string]: string;
        } | undefined;
        private _image?;
        get image(): string;
        set image(value: string);
        resetImage(): void;
        get imageInput(): string | undefined;
        private _inferenceSpecificationName?;
        get inferenceSpecificationName(): string;
        set inferenceSpecificationName(value: string);
        resetInferenceSpecificationName(): void;
        get inferenceSpecificationNameInput(): string | undefined;
        private _mode?;
        get mode(): string;
        set mode(value: string);
        resetMode(): void;
        get modeInput(): string | undefined;
        private _modelDataUrl?;
        get modelDataUrl(): string;
        set modelDataUrl(value: string);
        resetModelDataUrl(): void;
        get modelDataUrlInput(): string | undefined;
        private _modelPackageName?;
        get modelPackageName(): string;
        set modelPackageName(value: string);
        resetModelPackageName(): void;
        get modelPackageNameInput(): string | undefined;
        private _additionalModelDataSource;
        get additionalModelDataSource(): ContainerAdditionalModelDataSourcePropertyList;
        putAdditionalModelDataSource(value: ContainerAdditionalModelDataSourceProperty[] | cdktn.IResolvable): void;
        resetAdditionalModelDataSource(): void;
        get additionalModelDataSourceInput(): cdktn.IResolvable | ContainerAdditionalModelDataSourceProperty[] | undefined;
        private _imageConfig;
        get imageConfig(): ContainerImageConfigPropertyOutputReference;
        putImageConfig(value: ContainerImageConfigProperty): void;
        resetImageConfig(): void;
        get imageConfigInput(): ContainerImageConfigProperty | undefined;
        private _modelDataSource;
        get modelDataSource(): ContainerModelDataSourcePropertyOutputReference;
        putModelDataSource(value: ContainerModelDataSourceProperty): void;
        resetModelDataSource(): void;
        get modelDataSourceInput(): ContainerModelDataSourceProperty | undefined;
        private _multiModelConfig;
        get multiModelConfig(): ContainerMultiModelConfigPropertyOutputReference;
        putMultiModelConfig(value: ContainerMultiModelConfigProperty): void;
        resetMultiModelConfig(): void;
        get multiModelConfigInput(): ContainerMultiModelConfigProperty | undefined;
    }
    class ContainerPropertyList extends cdktn.ComplexList {
        internalValue?: ContainerProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ContainerPropertyOutputReference;
    }
    interface InferenceExecutionConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#mode AwsModel#mode}
        */
        readonly mode: string;
    }
    class InferenceExecutionConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InferenceExecutionConfigProperty | undefined;
        set internalValue(value: InferenceExecutionConfigProperty | undefined);
        private _mode?;
        get mode(): string;
        set mode(value: string);
        get modeInput(): string | undefined;
    }
    interface PrimaryContainerAdditionalModelDataSourceS3DataSourceModelAccessConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#accept_eula AwsModel#accept_eula}
        */
        readonly acceptEula: boolean | cdktn.IResolvable;
    }
    class PrimaryContainerAdditionalModelDataSourceS3DataSourceModelAccessConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PrimaryContainerAdditionalModelDataSourceS3DataSourceModelAccessConfigProperty | undefined;
        set internalValue(value: PrimaryContainerAdditionalModelDataSourceS3DataSourceModelAccessConfigProperty | undefined);
        private _acceptEula?;
        get acceptEula(): boolean | cdktn.IResolvable;
        set acceptEula(value: boolean | cdktn.IResolvable);
        get acceptEulaInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface PrimaryContainerAdditionalModelDataSourceS3DataSourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#compression_type AwsModel#compression_type}
        */
        readonly compressionType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#s3_data_type AwsModel#s3_data_type}
        */
        readonly s3DataType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#s3_uri AwsModel#s3_uri}
        */
        readonly s3Uri: string;
        /**
        * model_access_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#model_access_config AwsModel#model_access_config}
        */
        readonly modelAccessConfig?: PrimaryContainerAdditionalModelDataSourceS3DataSourceModelAccessConfigProperty;
    }
    class PrimaryContainerAdditionalModelDataSourceS3DataSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PrimaryContainerAdditionalModelDataSourceS3DataSourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PrimaryContainerAdditionalModelDataSourceS3DataSourceProperty | cdktn.IResolvable | undefined);
        private _compressionType?;
        get compressionType(): string;
        set compressionType(value: string);
        get compressionTypeInput(): string | undefined;
        private _s3DataType?;
        get s3DataType(): string;
        set s3DataType(value: string);
        get s3DataTypeInput(): string | undefined;
        private _s3Uri?;
        get s3Uri(): string;
        set s3Uri(value: string);
        get s3UriInput(): string | undefined;
        private _modelAccessConfig;
        get modelAccessConfig(): PrimaryContainerAdditionalModelDataSourceS3DataSourceModelAccessConfigPropertyOutputReference;
        putModelAccessConfig(value: PrimaryContainerAdditionalModelDataSourceS3DataSourceModelAccessConfigProperty): void;
        resetModelAccessConfig(): void;
        get modelAccessConfigInput(): PrimaryContainerAdditionalModelDataSourceS3DataSourceModelAccessConfigProperty | undefined;
    }
    class PrimaryContainerAdditionalModelDataSourceS3DataSourcePropertyList extends cdktn.ComplexList {
        internalValue?: PrimaryContainerAdditionalModelDataSourceS3DataSourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PrimaryContainerAdditionalModelDataSourceS3DataSourcePropertyOutputReference;
    }
    interface PrimaryContainerAdditionalModelDataSourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#channel_name AwsModel#channel_name}
        */
        readonly channelName: string;
        /**
        * s3_data_source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#s3_data_source AwsModel#s3_data_source}
        */
        readonly s3DataSource: PrimaryContainerAdditionalModelDataSourceS3DataSourceProperty[] | cdktn.IResolvable;
    }
    class PrimaryContainerAdditionalModelDataSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PrimaryContainerAdditionalModelDataSourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PrimaryContainerAdditionalModelDataSourceProperty | cdktn.IResolvable | undefined);
        private _channelName?;
        get channelName(): string;
        set channelName(value: string);
        get channelNameInput(): string | undefined;
        private _s3DataSource;
        get s3DataSource(): PrimaryContainerAdditionalModelDataSourceS3DataSourcePropertyList;
        putS3DataSource(value: PrimaryContainerAdditionalModelDataSourceS3DataSourceProperty[] | cdktn.IResolvable): void;
        get s3DataSourceInput(): cdktn.IResolvable | PrimaryContainerAdditionalModelDataSourceS3DataSourceProperty[] | undefined;
    }
    class PrimaryContainerAdditionalModelDataSourcePropertyList extends cdktn.ComplexList {
        internalValue?: PrimaryContainerAdditionalModelDataSourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PrimaryContainerAdditionalModelDataSourcePropertyOutputReference;
    }
    interface PrimaryContainerImageConfigRepositoryAuthConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#repository_credentials_provider_arn AwsModel#repository_credentials_provider_arn}
        */
        readonly repositoryCredentialsProviderArn: string;
    }
    class PrimaryContainerImageConfigRepositoryAuthConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PrimaryContainerImageConfigRepositoryAuthConfigProperty | undefined;
        set internalValue(value: PrimaryContainerImageConfigRepositoryAuthConfigProperty | undefined);
        private _repositoryCredentialsProviderArn?;
        get repositoryCredentialsProviderArn(): string;
        set repositoryCredentialsProviderArn(value: string);
        get repositoryCredentialsProviderArnInput(): string | undefined;
    }
    interface PrimaryContainerImageConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#repository_access_mode AwsModel#repository_access_mode}
        */
        readonly repositoryAccessMode: string;
        /**
        * repository_auth_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#repository_auth_config AwsModel#repository_auth_config}
        */
        readonly repositoryAuthConfig?: PrimaryContainerImageConfigRepositoryAuthConfigProperty;
    }
    class PrimaryContainerImageConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PrimaryContainerImageConfigProperty | undefined;
        set internalValue(value: PrimaryContainerImageConfigProperty | undefined);
        private _repositoryAccessMode?;
        get repositoryAccessMode(): string;
        set repositoryAccessMode(value: string);
        get repositoryAccessModeInput(): string | undefined;
        private _repositoryAuthConfig;
        get repositoryAuthConfig(): PrimaryContainerImageConfigRepositoryAuthConfigPropertyOutputReference;
        putRepositoryAuthConfig(value: PrimaryContainerImageConfigRepositoryAuthConfigProperty): void;
        resetRepositoryAuthConfig(): void;
        get repositoryAuthConfigInput(): PrimaryContainerImageConfigRepositoryAuthConfigProperty | undefined;
    }
    interface PrimaryContainerModelDataSourceS3DataSourceModelAccessConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#accept_eula AwsModel#accept_eula}
        */
        readonly acceptEula: boolean | cdktn.IResolvable;
    }
    class PrimaryContainerModelDataSourceS3DataSourceModelAccessConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PrimaryContainerModelDataSourceS3DataSourceModelAccessConfigProperty | undefined;
        set internalValue(value: PrimaryContainerModelDataSourceS3DataSourceModelAccessConfigProperty | undefined);
        private _acceptEula?;
        get acceptEula(): boolean | cdktn.IResolvable;
        set acceptEula(value: boolean | cdktn.IResolvable);
        get acceptEulaInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface PrimaryContainerModelDataSourceS3DataSourceProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#compression_type AwsModel#compression_type}
        */
        readonly compressionType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#s3_data_type AwsModel#s3_data_type}
        */
        readonly s3DataType: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#s3_uri AwsModel#s3_uri}
        */
        readonly s3Uri: string;
        /**
        * model_access_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#model_access_config AwsModel#model_access_config}
        */
        readonly modelAccessConfig?: PrimaryContainerModelDataSourceS3DataSourceModelAccessConfigProperty;
    }
    class PrimaryContainerModelDataSourceS3DataSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): PrimaryContainerModelDataSourceS3DataSourceProperty | cdktn.IResolvable | undefined;
        set internalValue(value: PrimaryContainerModelDataSourceS3DataSourceProperty | cdktn.IResolvable | undefined);
        private _compressionType?;
        get compressionType(): string;
        set compressionType(value: string);
        get compressionTypeInput(): string | undefined;
        private _s3DataType?;
        get s3DataType(): string;
        set s3DataType(value: string);
        get s3DataTypeInput(): string | undefined;
        private _s3Uri?;
        get s3Uri(): string;
        set s3Uri(value: string);
        get s3UriInput(): string | undefined;
        private _modelAccessConfig;
        get modelAccessConfig(): PrimaryContainerModelDataSourceS3DataSourceModelAccessConfigPropertyOutputReference;
        putModelAccessConfig(value: PrimaryContainerModelDataSourceS3DataSourceModelAccessConfigProperty): void;
        resetModelAccessConfig(): void;
        get modelAccessConfigInput(): PrimaryContainerModelDataSourceS3DataSourceModelAccessConfigProperty | undefined;
    }
    class PrimaryContainerModelDataSourceS3DataSourcePropertyList extends cdktn.ComplexList {
        internalValue?: PrimaryContainerModelDataSourceS3DataSourceProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): PrimaryContainerModelDataSourceS3DataSourcePropertyOutputReference;
    }
    interface PrimaryContainerModelDataSourceProperty {
        /**
        * s3_data_source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#s3_data_source AwsModel#s3_data_source}
        */
        readonly s3DataSource: PrimaryContainerModelDataSourceS3DataSourceProperty[] | cdktn.IResolvable;
    }
    class PrimaryContainerModelDataSourcePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PrimaryContainerModelDataSourceProperty | undefined;
        set internalValue(value: PrimaryContainerModelDataSourceProperty | undefined);
        private _s3DataSource;
        get s3DataSource(): PrimaryContainerModelDataSourceS3DataSourcePropertyList;
        putS3DataSource(value: PrimaryContainerModelDataSourceS3DataSourceProperty[] | cdktn.IResolvable): void;
        get s3DataSourceInput(): cdktn.IResolvable | PrimaryContainerModelDataSourceS3DataSourceProperty[] | undefined;
    }
    interface PrimaryContainerMultiModelConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#model_cache_setting AwsModel#model_cache_setting}
        */
        readonly modelCacheSetting?: string;
    }
    class PrimaryContainerMultiModelConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PrimaryContainerMultiModelConfigProperty | undefined;
        set internalValue(value: PrimaryContainerMultiModelConfigProperty | undefined);
        private _modelCacheSetting?;
        get modelCacheSetting(): string;
        set modelCacheSetting(value: string);
        resetModelCacheSetting(): void;
        get modelCacheSettingInput(): string | undefined;
    }
    interface PrimaryContainerProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#container_hostname AwsModel#container_hostname}
        */
        readonly containerHostname?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#environment AwsModel#environment}
        */
        readonly environment?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#image AwsModel#image}
        */
        readonly image?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#inference_specification_name AwsModel#inference_specification_name}
        */
        readonly inferenceSpecificationName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#mode AwsModel#mode}
        */
        readonly mode?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#model_data_url AwsModel#model_data_url}
        */
        readonly modelDataUrl?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#model_package_name AwsModel#model_package_name}
        */
        readonly modelPackageName?: string;
        /**
        * additional_model_data_source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#additional_model_data_source AwsModel#additional_model_data_source}
        */
        readonly additionalModelDataSource?: PrimaryContainerAdditionalModelDataSourceProperty[] | cdktn.IResolvable;
        /**
        * image_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#image_config AwsModel#image_config}
        */
        readonly imageConfig?: PrimaryContainerImageConfigProperty;
        /**
        * model_data_source block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#model_data_source AwsModel#model_data_source}
        */
        readonly modelDataSource?: PrimaryContainerModelDataSourceProperty;
        /**
        * multi_model_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#multi_model_config AwsModel#multi_model_config}
        */
        readonly multiModelConfig?: PrimaryContainerMultiModelConfigProperty;
    }
    class PrimaryContainerPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PrimaryContainerProperty | undefined;
        set internalValue(value: PrimaryContainerProperty | undefined);
        private _containerHostname?;
        get containerHostname(): string;
        set containerHostname(value: string);
        resetContainerHostname(): void;
        get containerHostnameInput(): string | undefined;
        private _environment?;
        get environment(): {
            [key: string]: string;
        };
        set environment(value: {
            [key: string]: string;
        });
        resetEnvironment(): void;
        get environmentInput(): {
            [key: string]: string;
        } | undefined;
        private _image?;
        get image(): string;
        set image(value: string);
        resetImage(): void;
        get imageInput(): string | undefined;
        private _inferenceSpecificationName?;
        get inferenceSpecificationName(): string;
        set inferenceSpecificationName(value: string);
        resetInferenceSpecificationName(): void;
        get inferenceSpecificationNameInput(): string | undefined;
        private _mode?;
        get mode(): string;
        set mode(value: string);
        resetMode(): void;
        get modeInput(): string | undefined;
        private _modelDataUrl?;
        get modelDataUrl(): string;
        set modelDataUrl(value: string);
        resetModelDataUrl(): void;
        get modelDataUrlInput(): string | undefined;
        private _modelPackageName?;
        get modelPackageName(): string;
        set modelPackageName(value: string);
        resetModelPackageName(): void;
        get modelPackageNameInput(): string | undefined;
        private _additionalModelDataSource;
        get additionalModelDataSource(): PrimaryContainerAdditionalModelDataSourcePropertyList;
        putAdditionalModelDataSource(value: PrimaryContainerAdditionalModelDataSourceProperty[] | cdktn.IResolvable): void;
        resetAdditionalModelDataSource(): void;
        get additionalModelDataSourceInput(): cdktn.IResolvable | PrimaryContainerAdditionalModelDataSourceProperty[] | undefined;
        private _imageConfig;
        get imageConfig(): PrimaryContainerImageConfigPropertyOutputReference;
        putImageConfig(value: PrimaryContainerImageConfigProperty): void;
        resetImageConfig(): void;
        get imageConfigInput(): PrimaryContainerImageConfigProperty | undefined;
        private _modelDataSource;
        get modelDataSource(): PrimaryContainerModelDataSourcePropertyOutputReference;
        putModelDataSource(value: PrimaryContainerModelDataSourceProperty): void;
        resetModelDataSource(): void;
        get modelDataSourceInput(): PrimaryContainerModelDataSourceProperty | undefined;
        private _multiModelConfig;
        get multiModelConfig(): PrimaryContainerMultiModelConfigPropertyOutputReference;
        putMultiModelConfig(value: PrimaryContainerMultiModelConfigProperty): void;
        resetMultiModelConfig(): void;
        get multiModelConfigInput(): PrimaryContainerMultiModelConfigProperty | undefined;
    }
    interface VpcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#security_group_ids AwsModel#security_group_ids}
        */
        readonly securityGroupIds: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_model#subnets AwsModel#subnets}
        */
        readonly subnets: string[];
    }
    class VpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): VpcConfigProperty | undefined;
        set internalValue(value: VpcConfigProperty | undefined);
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        get securityGroupIdsInput(): string[] | undefined;
        private _subnets?;
        get subnets(): string[];
        set subnets(value: string[]);
        get subnetsInput(): string[] | undefined;
    }
}
