import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsHubConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hub#hub_description AwsHub#hub_description}
    */
    readonly hubDescription: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hub#hub_display_name AwsHub#hub_display_name}
    */
    readonly hubDisplayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hub#hub_name AwsHub#hub_name}
    */
    readonly hubName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hub#hub_search_keywords AwsHub#hub_search_keywords}
    */
    readonly hubSearchKeywords?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hub#id AwsHub#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hub#region AwsHub#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hub#tags AwsHub#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hub#tags_all AwsHub#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * s3_storage_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hub#s3_storage_config AwsHub#s3_storage_config}
    */
    readonly s3StorageConfig?: AwsHub.S3StorageConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hub aws_sagemaker_hub}
*/
export declare class AwsHub extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sagemaker_hub";
    /**
    * Generates CDKTN code for importing a AwsHub resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsHub to import
    * @param importFromId The id of the existing AwsHub that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hub#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsHub to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hub aws_sagemaker_hub} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsHubConfig
    */
    constructor(scope: Construct, id: string, config: AwsHubConfig);
    get arn(): string;
    private _hubDescription?;
    get hubDescription(): string;
    set hubDescription(value: string);
    get hubDescriptionInput(): string | undefined;
    private _hubDisplayName?;
    get hubDisplayName(): string;
    set hubDisplayName(value: string);
    resetHubDisplayName(): void;
    get hubDisplayNameInput(): string | undefined;
    private _hubName?;
    get hubName(): string;
    set hubName(value: string);
    get hubNameInput(): string | undefined;
    private _hubSearchKeywords?;
    get hubSearchKeywords(): string[];
    set hubSearchKeywords(value: string[]);
    resetHubSearchKeywords(): void;
    get hubSearchKeywordsInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _s3StorageConfig;
    get s3StorageConfig(): AwsHub.S3StorageConfigPropertyOutputReference;
    putS3StorageConfig(value: AwsHub.S3StorageConfigProperty): void;
    resetS3StorageConfig(): void;
    get s3StorageConfigInput(): AwsHub.S3StorageConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsHubS3StorageConfigPropertyToTerraform(struct?: AwsHub.S3StorageConfigPropertyOutputReference | AwsHub.S3StorageConfigProperty): any;
export declare function awsHubS3StorageConfigPropertyToHclTerraform(struct?: AwsHub.S3StorageConfigPropertyOutputReference | AwsHub.S3StorageConfigProperty): any;
export declare namespace AwsHub {
    interface S3StorageConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_hub#s3_output_path AwsHub#s3_output_path}
        */
        readonly s3OutputPath?: string;
    }
    class S3StorageConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3StorageConfigProperty | undefined;
        set internalValue(value: S3StorageConfigProperty | undefined);
        private _s3OutputPath?;
        get s3OutputPath(): string;
        set s3OutputPath(value: string);
        resetS3OutputPath(): void;
        get s3OutputPathInput(): string | undefined;
    }
}
