import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsUserProfileConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#domain_id AwsUserProfile#domain_id}
    */
    readonly domainId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#id AwsUserProfile#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#region AwsUserProfile#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#single_sign_on_user_identifier AwsUserProfile#single_sign_on_user_identifier}
    */
    readonly singleSignOnUserIdentifier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#single_sign_on_user_value AwsUserProfile#single_sign_on_user_value}
    */
    readonly singleSignOnUserValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#tags AwsUserProfile#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#tags_all AwsUserProfile#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#user_profile_name AwsUserProfile#user_profile_name}
    */
    readonly userProfileName: string;
    /**
    * user_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#user_settings AwsUserProfile#user_settings}
    */
    readonly userSettings?: AwsUserProfile.UserSettingsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile aws_sagemaker_user_profile}
*/
export declare class AwsUserProfile extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sagemaker_user_profile";
    /**
    * Generates CDKTN code for importing a AwsUserProfile resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsUserProfile to import
    * @param importFromId The id of the existing AwsUserProfile that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsUserProfile to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile aws_sagemaker_user_profile} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsUserProfileConfig
    */
    constructor(scope: Construct, id: string, config: AwsUserProfileConfig);
    get arn(): string;
    private _domainId?;
    get domainId(): string;
    set domainId(value: string);
    get domainIdInput(): string | undefined;
    get homeEfsFileSystemUid(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _singleSignOnUserIdentifier?;
    get singleSignOnUserIdentifier(): string;
    set singleSignOnUserIdentifier(value: string);
    resetSingleSignOnUserIdentifier(): void;
    get singleSignOnUserIdentifierInput(): string | undefined;
    private _singleSignOnUserValue?;
    get singleSignOnUserValue(): string;
    set singleSignOnUserValue(value: string);
    resetSingleSignOnUserValue(): void;
    get singleSignOnUserValueInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _userProfileName?;
    get userProfileName(): string;
    set userProfileName(value: string);
    get userProfileNameInput(): string | undefined;
    private _userSettings;
    get userSettings(): AwsUserProfile.UserSettingsPropertyOutputReference;
    putUserSettings(value: AwsUserProfile.UserSettingsProperty): void;
    resetUserSettings(): void;
    get userSettingsInput(): AwsUserProfile.UserSettingsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsUserProfileDirectDeploySettingsPropertyToTerraform(struct?: AwsUserProfile.DirectDeploySettingsPropertyOutputReference | AwsUserProfile.DirectDeploySettingsProperty): any;
export declare function awsUserProfileDirectDeploySettingsPropertyToHclTerraform(struct?: AwsUserProfile.DirectDeploySettingsPropertyOutputReference | AwsUserProfile.DirectDeploySettingsProperty): any;
export declare function awsUserProfileEmrServerlessSettingsPropertyToTerraform(struct?: AwsUserProfile.EmrServerlessSettingsPropertyOutputReference | AwsUserProfile.EmrServerlessSettingsProperty): any;
export declare function awsUserProfileEmrServerlessSettingsPropertyToHclTerraform(struct?: AwsUserProfile.EmrServerlessSettingsPropertyOutputReference | AwsUserProfile.EmrServerlessSettingsProperty): any;
export declare function awsUserProfileGenerativeAiSettingsPropertyToTerraform(struct?: AwsUserProfile.GenerativeAiSettingsPropertyOutputReference | AwsUserProfile.GenerativeAiSettingsProperty): any;
export declare function awsUserProfileGenerativeAiSettingsPropertyToHclTerraform(struct?: AwsUserProfile.GenerativeAiSettingsPropertyOutputReference | AwsUserProfile.GenerativeAiSettingsProperty): any;
export declare function awsUserProfileIdentityProviderOauthSettingsPropertyToTerraform(struct?: AwsUserProfile.IdentityProviderOauthSettingsProperty | cdktn.IResolvable): any;
export declare function awsUserProfileIdentityProviderOauthSettingsPropertyToHclTerraform(struct?: AwsUserProfile.IdentityProviderOauthSettingsProperty | cdktn.IResolvable): any;
export declare function awsUserProfileKendraSettingsPropertyToTerraform(struct?: AwsUserProfile.KendraSettingsPropertyOutputReference | AwsUserProfile.KendraSettingsProperty): any;
export declare function awsUserProfileKendraSettingsPropertyToHclTerraform(struct?: AwsUserProfile.KendraSettingsPropertyOutputReference | AwsUserProfile.KendraSettingsProperty): any;
export declare function awsUserProfileModelRegisterSettingsPropertyToTerraform(struct?: AwsUserProfile.ModelRegisterSettingsPropertyOutputReference | AwsUserProfile.ModelRegisterSettingsProperty): any;
export declare function awsUserProfileModelRegisterSettingsPropertyToHclTerraform(struct?: AwsUserProfile.ModelRegisterSettingsPropertyOutputReference | AwsUserProfile.ModelRegisterSettingsProperty): any;
export declare function awsUserProfileTimeSeriesForecastingSettingsPropertyToTerraform(struct?: AwsUserProfile.TimeSeriesForecastingSettingsPropertyOutputReference | AwsUserProfile.TimeSeriesForecastingSettingsProperty): any;
export declare function awsUserProfileTimeSeriesForecastingSettingsPropertyToHclTerraform(struct?: AwsUserProfile.TimeSeriesForecastingSettingsPropertyOutputReference | AwsUserProfile.TimeSeriesForecastingSettingsProperty): any;
export declare function awsUserProfileWorkspaceSettingsPropertyToTerraform(struct?: AwsUserProfile.WorkspaceSettingsPropertyOutputReference | AwsUserProfile.WorkspaceSettingsProperty): any;
export declare function awsUserProfileWorkspaceSettingsPropertyToHclTerraform(struct?: AwsUserProfile.WorkspaceSettingsPropertyOutputReference | AwsUserProfile.WorkspaceSettingsProperty): any;
export declare function awsUserProfileCanvasAppSettingsPropertyToTerraform(struct?: AwsUserProfile.CanvasAppSettingsPropertyOutputReference | AwsUserProfile.CanvasAppSettingsProperty): any;
export declare function awsUserProfileCanvasAppSettingsPropertyToHclTerraform(struct?: AwsUserProfile.CanvasAppSettingsPropertyOutputReference | AwsUserProfile.CanvasAppSettingsProperty): any;
export declare function awsUserProfileUserSettingsCodeEditorAppSettingsAppLifecycleManagementIdleSettingsPropertyToTerraform(struct?: AwsUserProfile.UserSettingsCodeEditorAppSettingsAppLifecycleManagementIdleSettingsPropertyOutputReference | AwsUserProfile.UserSettingsCodeEditorAppSettingsAppLifecycleManagementIdleSettingsProperty): any;
export declare function awsUserProfileUserSettingsCodeEditorAppSettingsAppLifecycleManagementIdleSettingsPropertyToHclTerraform(struct?: AwsUserProfile.UserSettingsCodeEditorAppSettingsAppLifecycleManagementIdleSettingsPropertyOutputReference | AwsUserProfile.UserSettingsCodeEditorAppSettingsAppLifecycleManagementIdleSettingsProperty): any;
export declare function awsUserProfileUserSettingsCodeEditorAppSettingsAppLifecycleManagementPropertyToTerraform(struct?: AwsUserProfile.UserSettingsCodeEditorAppSettingsAppLifecycleManagementPropertyOutputReference | AwsUserProfile.UserSettingsCodeEditorAppSettingsAppLifecycleManagementProperty): any;
export declare function awsUserProfileUserSettingsCodeEditorAppSettingsAppLifecycleManagementPropertyToHclTerraform(struct?: AwsUserProfile.UserSettingsCodeEditorAppSettingsAppLifecycleManagementPropertyOutputReference | AwsUserProfile.UserSettingsCodeEditorAppSettingsAppLifecycleManagementProperty): any;
export declare function awsUserProfileUserSettingsCodeEditorAppSettingsCustomImagePropertyToTerraform(struct?: AwsUserProfile.UserSettingsCodeEditorAppSettingsCustomImageProperty | cdktn.IResolvable): any;
export declare function awsUserProfileUserSettingsCodeEditorAppSettingsCustomImagePropertyToHclTerraform(struct?: AwsUserProfile.UserSettingsCodeEditorAppSettingsCustomImageProperty | cdktn.IResolvable): any;
export declare function awsUserProfileUserSettingsCodeEditorAppSettingsDefaultResourceSpecPropertyToTerraform(struct?: AwsUserProfile.UserSettingsCodeEditorAppSettingsDefaultResourceSpecPropertyOutputReference | AwsUserProfile.UserSettingsCodeEditorAppSettingsDefaultResourceSpecProperty): any;
export declare function awsUserProfileUserSettingsCodeEditorAppSettingsDefaultResourceSpecPropertyToHclTerraform(struct?: AwsUserProfile.UserSettingsCodeEditorAppSettingsDefaultResourceSpecPropertyOutputReference | AwsUserProfile.UserSettingsCodeEditorAppSettingsDefaultResourceSpecProperty): any;
export declare function awsUserProfileCodeEditorAppSettingsPropertyToTerraform(struct?: AwsUserProfile.CodeEditorAppSettingsPropertyOutputReference | AwsUserProfile.CodeEditorAppSettingsProperty): any;
export declare function awsUserProfileCodeEditorAppSettingsPropertyToHclTerraform(struct?: AwsUserProfile.CodeEditorAppSettingsPropertyOutputReference | AwsUserProfile.CodeEditorAppSettingsProperty): any;
export declare function awsUserProfileEfsFileSystemConfigPropertyToTerraform(struct?: AwsUserProfile.EfsFileSystemConfigProperty | cdktn.IResolvable): any;
export declare function awsUserProfileEfsFileSystemConfigPropertyToHclTerraform(struct?: AwsUserProfile.EfsFileSystemConfigProperty | cdktn.IResolvable): any;
export declare function awsUserProfileCustomFileSystemConfigPropertyToTerraform(struct?: AwsUserProfile.CustomFileSystemConfigProperty | cdktn.IResolvable): any;
export declare function awsUserProfileCustomFileSystemConfigPropertyToHclTerraform(struct?: AwsUserProfile.CustomFileSystemConfigProperty | cdktn.IResolvable): any;
export declare function awsUserProfileCustomPosixUserConfigPropertyToTerraform(struct?: AwsUserProfile.CustomPosixUserConfigPropertyOutputReference | AwsUserProfile.CustomPosixUserConfigProperty): any;
export declare function awsUserProfileCustomPosixUserConfigPropertyToHclTerraform(struct?: AwsUserProfile.CustomPosixUserConfigPropertyOutputReference | AwsUserProfile.CustomPosixUserConfigProperty): any;
export declare function awsUserProfileUserSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsPropertyToTerraform(struct?: AwsUserProfile.UserSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsPropertyOutputReference | AwsUserProfile.UserSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsProperty): any;
export declare function awsUserProfileUserSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsPropertyToHclTerraform(struct?: AwsUserProfile.UserSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsPropertyOutputReference | AwsUserProfile.UserSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsProperty): any;
export declare function awsUserProfileUserSettingsJupyterLabAppSettingsAppLifecycleManagementPropertyToTerraform(struct?: AwsUserProfile.UserSettingsJupyterLabAppSettingsAppLifecycleManagementPropertyOutputReference | AwsUserProfile.UserSettingsJupyterLabAppSettingsAppLifecycleManagementProperty): any;
export declare function awsUserProfileUserSettingsJupyterLabAppSettingsAppLifecycleManagementPropertyToHclTerraform(struct?: AwsUserProfile.UserSettingsJupyterLabAppSettingsAppLifecycleManagementPropertyOutputReference | AwsUserProfile.UserSettingsJupyterLabAppSettingsAppLifecycleManagementProperty): any;
export declare function awsUserProfileUserSettingsJupyterLabAppSettingsCodeRepositoryPropertyToTerraform(struct?: AwsUserProfile.UserSettingsJupyterLabAppSettingsCodeRepositoryProperty | cdktn.IResolvable): any;
export declare function awsUserProfileUserSettingsJupyterLabAppSettingsCodeRepositoryPropertyToHclTerraform(struct?: AwsUserProfile.UserSettingsJupyterLabAppSettingsCodeRepositoryProperty | cdktn.IResolvable): any;
export declare function awsUserProfileUserSettingsJupyterLabAppSettingsCustomImagePropertyToTerraform(struct?: AwsUserProfile.UserSettingsJupyterLabAppSettingsCustomImageProperty | cdktn.IResolvable): any;
export declare function awsUserProfileUserSettingsJupyterLabAppSettingsCustomImagePropertyToHclTerraform(struct?: AwsUserProfile.UserSettingsJupyterLabAppSettingsCustomImageProperty | cdktn.IResolvable): any;
export declare function awsUserProfileUserSettingsJupyterLabAppSettingsDefaultResourceSpecPropertyToTerraform(struct?: AwsUserProfile.UserSettingsJupyterLabAppSettingsDefaultResourceSpecPropertyOutputReference | AwsUserProfile.UserSettingsJupyterLabAppSettingsDefaultResourceSpecProperty): any;
export declare function awsUserProfileUserSettingsJupyterLabAppSettingsDefaultResourceSpecPropertyToHclTerraform(struct?: AwsUserProfile.UserSettingsJupyterLabAppSettingsDefaultResourceSpecPropertyOutputReference | AwsUserProfile.UserSettingsJupyterLabAppSettingsDefaultResourceSpecProperty): any;
export declare function awsUserProfileEmrSettingsPropertyToTerraform(struct?: AwsUserProfile.EmrSettingsPropertyOutputReference | AwsUserProfile.EmrSettingsProperty): any;
export declare function awsUserProfileEmrSettingsPropertyToHclTerraform(struct?: AwsUserProfile.EmrSettingsPropertyOutputReference | AwsUserProfile.EmrSettingsProperty): any;
export declare function awsUserProfileJupyterLabAppSettingsPropertyToTerraform(struct?: AwsUserProfile.JupyterLabAppSettingsPropertyOutputReference | AwsUserProfile.JupyterLabAppSettingsProperty): any;
export declare function awsUserProfileJupyterLabAppSettingsPropertyToHclTerraform(struct?: AwsUserProfile.JupyterLabAppSettingsPropertyOutputReference | AwsUserProfile.JupyterLabAppSettingsProperty): any;
export declare function awsUserProfileUserSettingsJupyterServerAppSettingsCodeRepositoryPropertyToTerraform(struct?: AwsUserProfile.UserSettingsJupyterServerAppSettingsCodeRepositoryProperty | cdktn.IResolvable): any;
export declare function awsUserProfileUserSettingsJupyterServerAppSettingsCodeRepositoryPropertyToHclTerraform(struct?: AwsUserProfile.UserSettingsJupyterServerAppSettingsCodeRepositoryProperty | cdktn.IResolvable): any;
export declare function awsUserProfileUserSettingsJupyterServerAppSettingsDefaultResourceSpecPropertyToTerraform(struct?: AwsUserProfile.UserSettingsJupyterServerAppSettingsDefaultResourceSpecPropertyOutputReference | AwsUserProfile.UserSettingsJupyterServerAppSettingsDefaultResourceSpecProperty): any;
export declare function awsUserProfileUserSettingsJupyterServerAppSettingsDefaultResourceSpecPropertyToHclTerraform(struct?: AwsUserProfile.UserSettingsJupyterServerAppSettingsDefaultResourceSpecPropertyOutputReference | AwsUserProfile.UserSettingsJupyterServerAppSettingsDefaultResourceSpecProperty): any;
export declare function awsUserProfileJupyterServerAppSettingsPropertyToTerraform(struct?: AwsUserProfile.JupyterServerAppSettingsPropertyOutputReference | AwsUserProfile.JupyterServerAppSettingsProperty): any;
export declare function awsUserProfileJupyterServerAppSettingsPropertyToHclTerraform(struct?: AwsUserProfile.JupyterServerAppSettingsPropertyOutputReference | AwsUserProfile.JupyterServerAppSettingsProperty): any;
export declare function awsUserProfileUserSettingsKernelGatewayAppSettingsCustomImagePropertyToTerraform(struct?: AwsUserProfile.UserSettingsKernelGatewayAppSettingsCustomImageProperty | cdktn.IResolvable): any;
export declare function awsUserProfileUserSettingsKernelGatewayAppSettingsCustomImagePropertyToHclTerraform(struct?: AwsUserProfile.UserSettingsKernelGatewayAppSettingsCustomImageProperty | cdktn.IResolvable): any;
export declare function awsUserProfileUserSettingsKernelGatewayAppSettingsDefaultResourceSpecPropertyToTerraform(struct?: AwsUserProfile.UserSettingsKernelGatewayAppSettingsDefaultResourceSpecPropertyOutputReference | AwsUserProfile.UserSettingsKernelGatewayAppSettingsDefaultResourceSpecProperty): any;
export declare function awsUserProfileUserSettingsKernelGatewayAppSettingsDefaultResourceSpecPropertyToHclTerraform(struct?: AwsUserProfile.UserSettingsKernelGatewayAppSettingsDefaultResourceSpecPropertyOutputReference | AwsUserProfile.UserSettingsKernelGatewayAppSettingsDefaultResourceSpecProperty): any;
export declare function awsUserProfileKernelGatewayAppSettingsPropertyToTerraform(struct?: AwsUserProfile.KernelGatewayAppSettingsPropertyOutputReference | AwsUserProfile.KernelGatewayAppSettingsProperty): any;
export declare function awsUserProfileKernelGatewayAppSettingsPropertyToHclTerraform(struct?: AwsUserProfile.KernelGatewayAppSettingsPropertyOutputReference | AwsUserProfile.KernelGatewayAppSettingsProperty): any;
export declare function awsUserProfileUserSettingsRSessionAppSettingsCustomImagePropertyToTerraform(struct?: AwsUserProfile.UserSettingsRSessionAppSettingsCustomImageProperty | cdktn.IResolvable): any;
export declare function awsUserProfileUserSettingsRSessionAppSettingsCustomImagePropertyToHclTerraform(struct?: AwsUserProfile.UserSettingsRSessionAppSettingsCustomImageProperty | cdktn.IResolvable): any;
export declare function awsUserProfileUserSettingsRSessionAppSettingsDefaultResourceSpecPropertyToTerraform(struct?: AwsUserProfile.UserSettingsRSessionAppSettingsDefaultResourceSpecPropertyOutputReference | AwsUserProfile.UserSettingsRSessionAppSettingsDefaultResourceSpecProperty): any;
export declare function awsUserProfileUserSettingsRSessionAppSettingsDefaultResourceSpecPropertyToHclTerraform(struct?: AwsUserProfile.UserSettingsRSessionAppSettingsDefaultResourceSpecPropertyOutputReference | AwsUserProfile.UserSettingsRSessionAppSettingsDefaultResourceSpecProperty): any;
export declare function awsUserProfileRSessionAppSettingsPropertyToTerraform(struct?: AwsUserProfile.RSessionAppSettingsPropertyOutputReference | AwsUserProfile.RSessionAppSettingsProperty): any;
export declare function awsUserProfileRSessionAppSettingsPropertyToHclTerraform(struct?: AwsUserProfile.RSessionAppSettingsPropertyOutputReference | AwsUserProfile.RSessionAppSettingsProperty): any;
export declare function awsUserProfileRStudioServerProAppSettingsPropertyToTerraform(struct?: AwsUserProfile.RStudioServerProAppSettingsPropertyOutputReference | AwsUserProfile.RStudioServerProAppSettingsProperty): any;
export declare function awsUserProfileRStudioServerProAppSettingsPropertyToHclTerraform(struct?: AwsUserProfile.RStudioServerProAppSettingsPropertyOutputReference | AwsUserProfile.RStudioServerProAppSettingsProperty): any;
export declare function awsUserProfileSharingSettingsPropertyToTerraform(struct?: AwsUserProfile.SharingSettingsPropertyOutputReference | AwsUserProfile.SharingSettingsProperty): any;
export declare function awsUserProfileSharingSettingsPropertyToHclTerraform(struct?: AwsUserProfile.SharingSettingsPropertyOutputReference | AwsUserProfile.SharingSettingsProperty): any;
export declare function awsUserProfileDefaultEbsStorageSettingsPropertyToTerraform(struct?: AwsUserProfile.DefaultEbsStorageSettingsPropertyOutputReference | AwsUserProfile.DefaultEbsStorageSettingsProperty): any;
export declare function awsUserProfileDefaultEbsStorageSettingsPropertyToHclTerraform(struct?: AwsUserProfile.DefaultEbsStorageSettingsPropertyOutputReference | AwsUserProfile.DefaultEbsStorageSettingsProperty): any;
export declare function awsUserProfileSpaceStorageSettingsPropertyToTerraform(struct?: AwsUserProfile.SpaceStorageSettingsPropertyOutputReference | AwsUserProfile.SpaceStorageSettingsProperty): any;
export declare function awsUserProfileSpaceStorageSettingsPropertyToHclTerraform(struct?: AwsUserProfile.SpaceStorageSettingsPropertyOutputReference | AwsUserProfile.SpaceStorageSettingsProperty): any;
export declare function awsUserProfileStudioWebPortalSettingsPropertyToTerraform(struct?: AwsUserProfile.StudioWebPortalSettingsPropertyOutputReference | AwsUserProfile.StudioWebPortalSettingsProperty): any;
export declare function awsUserProfileStudioWebPortalSettingsPropertyToHclTerraform(struct?: AwsUserProfile.StudioWebPortalSettingsPropertyOutputReference | AwsUserProfile.StudioWebPortalSettingsProperty): any;
export declare function awsUserProfileUserSettingsTensorBoardAppSettingsDefaultResourceSpecPropertyToTerraform(struct?: AwsUserProfile.UserSettingsTensorBoardAppSettingsDefaultResourceSpecPropertyOutputReference | AwsUserProfile.UserSettingsTensorBoardAppSettingsDefaultResourceSpecProperty): any;
export declare function awsUserProfileUserSettingsTensorBoardAppSettingsDefaultResourceSpecPropertyToHclTerraform(struct?: AwsUserProfile.UserSettingsTensorBoardAppSettingsDefaultResourceSpecPropertyOutputReference | AwsUserProfile.UserSettingsTensorBoardAppSettingsDefaultResourceSpecProperty): any;
export declare function awsUserProfileTensorBoardAppSettingsPropertyToTerraform(struct?: AwsUserProfile.TensorBoardAppSettingsPropertyOutputReference | AwsUserProfile.TensorBoardAppSettingsProperty): any;
export declare function awsUserProfileTensorBoardAppSettingsPropertyToHclTerraform(struct?: AwsUserProfile.TensorBoardAppSettingsPropertyOutputReference | AwsUserProfile.TensorBoardAppSettingsProperty): any;
export declare function awsUserProfileUserSettingsPropertyToTerraform(struct?: AwsUserProfile.UserSettingsPropertyOutputReference | AwsUserProfile.UserSettingsProperty): any;
export declare function awsUserProfileUserSettingsPropertyToHclTerraform(struct?: AwsUserProfile.UserSettingsPropertyOutputReference | AwsUserProfile.UserSettingsProperty): any;
export declare namespace AwsUserProfile {
    interface DirectDeploySettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#status AwsUserProfile#status}
        */
        readonly status?: string;
    }
    class DirectDeploySettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DirectDeploySettingsProperty | undefined;
        set internalValue(value: DirectDeploySettingsProperty | undefined);
        private _status?;
        get status(): string;
        set status(value: string);
        resetStatus(): void;
        get statusInput(): string | undefined;
    }
    interface EmrServerlessSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#execution_role_arn AwsUserProfile#execution_role_arn}
        */
        readonly executionRoleArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#status AwsUserProfile#status}
        */
        readonly status?: string;
    }
    class EmrServerlessSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EmrServerlessSettingsProperty | undefined;
        set internalValue(value: EmrServerlessSettingsProperty | undefined);
        private _executionRoleArn?;
        get executionRoleArn(): string;
        set executionRoleArn(value: string);
        resetExecutionRoleArn(): void;
        get executionRoleArnInput(): string | undefined;
        private _status?;
        get status(): string;
        set status(value: string);
        resetStatus(): void;
        get statusInput(): string | undefined;
    }
    interface GenerativeAiSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#amazon_bedrock_role_arn AwsUserProfile#amazon_bedrock_role_arn}
        */
        readonly amazonBedrockRoleArn?: string;
    }
    class GenerativeAiSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): GenerativeAiSettingsProperty | undefined;
        set internalValue(value: GenerativeAiSettingsProperty | undefined);
        private _amazonBedrockRoleArn?;
        get amazonBedrockRoleArn(): string;
        set amazonBedrockRoleArn(value: string);
        resetAmazonBedrockRoleArn(): void;
        get amazonBedrockRoleArnInput(): string | undefined;
    }
    interface IdentityProviderOauthSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#data_source_name AwsUserProfile#data_source_name}
        */
        readonly dataSourceName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#secret_arn AwsUserProfile#secret_arn}
        */
        readonly secretArn: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#status AwsUserProfile#status}
        */
        readonly status?: string;
    }
    class IdentityProviderOauthSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): IdentityProviderOauthSettingsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: IdentityProviderOauthSettingsProperty | cdktn.IResolvable | undefined);
        private _dataSourceName?;
        get dataSourceName(): string;
        set dataSourceName(value: string);
        resetDataSourceName(): void;
        get dataSourceNameInput(): string | undefined;
        private _secretArn?;
        get secretArn(): string;
        set secretArn(value: string);
        get secretArnInput(): string | undefined;
        private _status?;
        get status(): string;
        set status(value: string);
        resetStatus(): void;
        get statusInput(): string | undefined;
    }
    class IdentityProviderOauthSettingsPropertyList extends cdktn.ComplexList {
        internalValue?: IdentityProviderOauthSettingsProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): IdentityProviderOauthSettingsPropertyOutputReference;
    }
    interface KendraSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#status AwsUserProfile#status}
        */
        readonly status?: string;
    }
    class KendraSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KendraSettingsProperty | undefined;
        set internalValue(value: KendraSettingsProperty | undefined);
        private _status?;
        get status(): string;
        set status(value: string);
        resetStatus(): void;
        get statusInput(): string | undefined;
    }
    interface ModelRegisterSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#cross_account_model_register_role_arn AwsUserProfile#cross_account_model_register_role_arn}
        */
        readonly crossAccountModelRegisterRoleArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#status AwsUserProfile#status}
        */
        readonly status?: string;
    }
    class ModelRegisterSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ModelRegisterSettingsProperty | undefined;
        set internalValue(value: ModelRegisterSettingsProperty | undefined);
        private _crossAccountModelRegisterRoleArn?;
        get crossAccountModelRegisterRoleArn(): string;
        set crossAccountModelRegisterRoleArn(value: string);
        resetCrossAccountModelRegisterRoleArn(): void;
        get crossAccountModelRegisterRoleArnInput(): string | undefined;
        private _status?;
        get status(): string;
        set status(value: string);
        resetStatus(): void;
        get statusInput(): string | undefined;
    }
    interface TimeSeriesForecastingSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#amazon_forecast_role_arn AwsUserProfile#amazon_forecast_role_arn}
        */
        readonly amazonForecastRoleArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#status AwsUserProfile#status}
        */
        readonly status?: string;
    }
    class TimeSeriesForecastingSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeSeriesForecastingSettingsProperty | undefined;
        set internalValue(value: TimeSeriesForecastingSettingsProperty | undefined);
        private _amazonForecastRoleArn?;
        get amazonForecastRoleArn(): string;
        set amazonForecastRoleArn(value: string);
        resetAmazonForecastRoleArn(): void;
        get amazonForecastRoleArnInput(): string | undefined;
        private _status?;
        get status(): string;
        set status(value: string);
        resetStatus(): void;
        get statusInput(): string | undefined;
    }
    interface WorkspaceSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#s3_artifact_path AwsUserProfile#s3_artifact_path}
        */
        readonly s3ArtifactPath?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#s3_kms_key_id AwsUserProfile#s3_kms_key_id}
        */
        readonly s3KmsKeyId?: string;
    }
    class WorkspaceSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): WorkspaceSettingsProperty | undefined;
        set internalValue(value: WorkspaceSettingsProperty | undefined);
        private _s3ArtifactPath?;
        get s3ArtifactPath(): string;
        set s3ArtifactPath(value: string);
        resetS3ArtifactPath(): void;
        get s3ArtifactPathInput(): string | undefined;
        private _s3KmsKeyId?;
        get s3KmsKeyId(): string;
        set s3KmsKeyId(value: string);
        resetS3KmsKeyId(): void;
        get s3KmsKeyIdInput(): string | undefined;
    }
    interface CanvasAppSettingsProperty {
        /**
        * direct_deploy_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#direct_deploy_settings AwsUserProfile#direct_deploy_settings}
        */
        readonly directDeploySettings?: DirectDeploySettingsProperty;
        /**
        * emr_serverless_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#emr_serverless_settings AwsUserProfile#emr_serverless_settings}
        */
        readonly emrServerlessSettings?: EmrServerlessSettingsProperty;
        /**
        * generative_ai_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#generative_ai_settings AwsUserProfile#generative_ai_settings}
        */
        readonly generativeAiSettings?: GenerativeAiSettingsProperty;
        /**
        * identity_provider_oauth_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#identity_provider_oauth_settings AwsUserProfile#identity_provider_oauth_settings}
        */
        readonly identityProviderOauthSettings?: IdentityProviderOauthSettingsProperty[] | cdktn.IResolvable;
        /**
        * kendra_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#kendra_settings AwsUserProfile#kendra_settings}
        */
        readonly kendraSettings?: KendraSettingsProperty;
        /**
        * model_register_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#model_register_settings AwsUserProfile#model_register_settings}
        */
        readonly modelRegisterSettings?: ModelRegisterSettingsProperty;
        /**
        * time_series_forecasting_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#time_series_forecasting_settings AwsUserProfile#time_series_forecasting_settings}
        */
        readonly timeSeriesForecastingSettings?: TimeSeriesForecastingSettingsProperty;
        /**
        * workspace_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#workspace_settings AwsUserProfile#workspace_settings}
        */
        readonly workspaceSettings?: WorkspaceSettingsProperty;
    }
    class CanvasAppSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CanvasAppSettingsProperty | undefined;
        set internalValue(value: CanvasAppSettingsProperty | undefined);
        private _directDeploySettings;
        get directDeploySettings(): DirectDeploySettingsPropertyOutputReference;
        putDirectDeploySettings(value: DirectDeploySettingsProperty): void;
        resetDirectDeploySettings(): void;
        get directDeploySettingsInput(): DirectDeploySettingsProperty | undefined;
        private _emrServerlessSettings;
        get emrServerlessSettings(): EmrServerlessSettingsPropertyOutputReference;
        putEmrServerlessSettings(value: EmrServerlessSettingsProperty): void;
        resetEmrServerlessSettings(): void;
        get emrServerlessSettingsInput(): EmrServerlessSettingsProperty | undefined;
        private _generativeAiSettings;
        get generativeAiSettings(): GenerativeAiSettingsPropertyOutputReference;
        putGenerativeAiSettings(value: GenerativeAiSettingsProperty): void;
        resetGenerativeAiSettings(): void;
        get generativeAiSettingsInput(): GenerativeAiSettingsProperty | undefined;
        private _identityProviderOauthSettings;
        get identityProviderOauthSettings(): IdentityProviderOauthSettingsPropertyList;
        putIdentityProviderOauthSettings(value: IdentityProviderOauthSettingsProperty[] | cdktn.IResolvable): void;
        resetIdentityProviderOauthSettings(): void;
        get identityProviderOauthSettingsInput(): cdktn.IResolvable | IdentityProviderOauthSettingsProperty[] | undefined;
        private _kendraSettings;
        get kendraSettings(): KendraSettingsPropertyOutputReference;
        putKendraSettings(value: KendraSettingsProperty): void;
        resetKendraSettings(): void;
        get kendraSettingsInput(): KendraSettingsProperty | undefined;
        private _modelRegisterSettings;
        get modelRegisterSettings(): ModelRegisterSettingsPropertyOutputReference;
        putModelRegisterSettings(value: ModelRegisterSettingsProperty): void;
        resetModelRegisterSettings(): void;
        get modelRegisterSettingsInput(): ModelRegisterSettingsProperty | undefined;
        private _timeSeriesForecastingSettings;
        get timeSeriesForecastingSettings(): TimeSeriesForecastingSettingsPropertyOutputReference;
        putTimeSeriesForecastingSettings(value: TimeSeriesForecastingSettingsProperty): void;
        resetTimeSeriesForecastingSettings(): void;
        get timeSeriesForecastingSettingsInput(): TimeSeriesForecastingSettingsProperty | undefined;
        private _workspaceSettings;
        get workspaceSettings(): WorkspaceSettingsPropertyOutputReference;
        putWorkspaceSettings(value: WorkspaceSettingsProperty): void;
        resetWorkspaceSettings(): void;
        get workspaceSettingsInput(): WorkspaceSettingsProperty | undefined;
    }
    interface UserSettingsCodeEditorAppSettingsAppLifecycleManagementIdleSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#idle_timeout_in_minutes AwsUserProfile#idle_timeout_in_minutes}
        */
        readonly idleTimeoutInMinutes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#lifecycle_management AwsUserProfile#lifecycle_management}
        */
        readonly lifecycleManagement?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#max_idle_timeout_in_minutes AwsUserProfile#max_idle_timeout_in_minutes}
        */
        readonly maxIdleTimeoutInMinutes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#min_idle_timeout_in_minutes AwsUserProfile#min_idle_timeout_in_minutes}
        */
        readonly minIdleTimeoutInMinutes?: number;
    }
    class UserSettingsCodeEditorAppSettingsAppLifecycleManagementIdleSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UserSettingsCodeEditorAppSettingsAppLifecycleManagementIdleSettingsProperty | undefined;
        set internalValue(value: UserSettingsCodeEditorAppSettingsAppLifecycleManagementIdleSettingsProperty | undefined);
        private _idleTimeoutInMinutes?;
        get idleTimeoutInMinutes(): number;
        set idleTimeoutInMinutes(value: number);
        resetIdleTimeoutInMinutes(): void;
        get idleTimeoutInMinutesInput(): number | undefined;
        private _lifecycleManagement?;
        get lifecycleManagement(): string;
        set lifecycleManagement(value: string);
        resetLifecycleManagement(): void;
        get lifecycleManagementInput(): string | undefined;
        private _maxIdleTimeoutInMinutes?;
        get maxIdleTimeoutInMinutes(): number;
        set maxIdleTimeoutInMinutes(value: number);
        resetMaxIdleTimeoutInMinutes(): void;
        get maxIdleTimeoutInMinutesInput(): number | undefined;
        private _minIdleTimeoutInMinutes?;
        get minIdleTimeoutInMinutes(): number;
        set minIdleTimeoutInMinutes(value: number);
        resetMinIdleTimeoutInMinutes(): void;
        get minIdleTimeoutInMinutesInput(): number | undefined;
    }
    interface UserSettingsCodeEditorAppSettingsAppLifecycleManagementProperty {
        /**
        * idle_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#idle_settings AwsUserProfile#idle_settings}
        */
        readonly idleSettings?: UserSettingsCodeEditorAppSettingsAppLifecycleManagementIdleSettingsProperty;
    }
    class UserSettingsCodeEditorAppSettingsAppLifecycleManagementPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UserSettingsCodeEditorAppSettingsAppLifecycleManagementProperty | undefined;
        set internalValue(value: UserSettingsCodeEditorAppSettingsAppLifecycleManagementProperty | undefined);
        private _idleSettings;
        get idleSettings(): UserSettingsCodeEditorAppSettingsAppLifecycleManagementIdleSettingsPropertyOutputReference;
        putIdleSettings(value: UserSettingsCodeEditorAppSettingsAppLifecycleManagementIdleSettingsProperty): void;
        resetIdleSettings(): void;
        get idleSettingsInput(): UserSettingsCodeEditorAppSettingsAppLifecycleManagementIdleSettingsProperty | undefined;
    }
    interface UserSettingsCodeEditorAppSettingsCustomImageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#app_image_config_name AwsUserProfile#app_image_config_name}
        */
        readonly appImageConfigName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#image_name AwsUserProfile#image_name}
        */
        readonly imageName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#image_version_number AwsUserProfile#image_version_number}
        */
        readonly imageVersionNumber?: number;
    }
    class UserSettingsCodeEditorAppSettingsCustomImagePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UserSettingsCodeEditorAppSettingsCustomImageProperty | cdktn.IResolvable | undefined;
        set internalValue(value: UserSettingsCodeEditorAppSettingsCustomImageProperty | cdktn.IResolvable | undefined);
        private _appImageConfigName?;
        get appImageConfigName(): string;
        set appImageConfigName(value: string);
        get appImageConfigNameInput(): string | undefined;
        private _imageName?;
        get imageName(): string;
        set imageName(value: string);
        get imageNameInput(): string | undefined;
        private _imageVersionNumber?;
        get imageVersionNumber(): number;
        set imageVersionNumber(value: number);
        resetImageVersionNumber(): void;
        get imageVersionNumberInput(): number | undefined;
    }
    class UserSettingsCodeEditorAppSettingsCustomImagePropertyList extends cdktn.ComplexList {
        internalValue?: UserSettingsCodeEditorAppSettingsCustomImageProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UserSettingsCodeEditorAppSettingsCustomImagePropertyOutputReference;
    }
    interface UserSettingsCodeEditorAppSettingsDefaultResourceSpecProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#instance_type AwsUserProfile#instance_type}
        */
        readonly instanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#lifecycle_config_arn AwsUserProfile#lifecycle_config_arn}
        */
        readonly lifecycleConfigArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#sagemaker_image_arn AwsUserProfile#sagemaker_image_arn}
        */
        readonly sagemakerImageArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#sagemaker_image_version_alias AwsUserProfile#sagemaker_image_version_alias}
        */
        readonly sagemakerImageVersionAlias?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#sagemaker_image_version_arn AwsUserProfile#sagemaker_image_version_arn}
        */
        readonly sagemakerImageVersionArn?: string;
    }
    class UserSettingsCodeEditorAppSettingsDefaultResourceSpecPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UserSettingsCodeEditorAppSettingsDefaultResourceSpecProperty | undefined;
        set internalValue(value: UserSettingsCodeEditorAppSettingsDefaultResourceSpecProperty | undefined);
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _lifecycleConfigArn?;
        get lifecycleConfigArn(): string;
        set lifecycleConfigArn(value: string);
        resetLifecycleConfigArn(): void;
        get lifecycleConfigArnInput(): string | undefined;
        private _sagemakerImageArn?;
        get sagemakerImageArn(): string;
        set sagemakerImageArn(value: string);
        resetSagemakerImageArn(): void;
        get sagemakerImageArnInput(): string | undefined;
        private _sagemakerImageVersionAlias?;
        get sagemakerImageVersionAlias(): string;
        set sagemakerImageVersionAlias(value: string);
        resetSagemakerImageVersionAlias(): void;
        get sagemakerImageVersionAliasInput(): string | undefined;
        private _sagemakerImageVersionArn?;
        get sagemakerImageVersionArn(): string;
        set sagemakerImageVersionArn(value: string);
        resetSagemakerImageVersionArn(): void;
        get sagemakerImageVersionArnInput(): string | undefined;
    }
    interface CodeEditorAppSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#built_in_lifecycle_config_arn AwsUserProfile#built_in_lifecycle_config_arn}
        */
        readonly builtInLifecycleConfigArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#lifecycle_config_arns AwsUserProfile#lifecycle_config_arns}
        */
        readonly lifecycleConfigArns?: string[];
        /**
        * app_lifecycle_management block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#app_lifecycle_management AwsUserProfile#app_lifecycle_management}
        */
        readonly appLifecycleManagement?: UserSettingsCodeEditorAppSettingsAppLifecycleManagementProperty;
        /**
        * custom_image block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#custom_image AwsUserProfile#custom_image}
        */
        readonly customImage?: UserSettingsCodeEditorAppSettingsCustomImageProperty[] | cdktn.IResolvable;
        /**
        * default_resource_spec block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#default_resource_spec AwsUserProfile#default_resource_spec}
        */
        readonly defaultResourceSpec?: UserSettingsCodeEditorAppSettingsDefaultResourceSpecProperty;
    }
    class CodeEditorAppSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CodeEditorAppSettingsProperty | undefined;
        set internalValue(value: CodeEditorAppSettingsProperty | undefined);
        private _builtInLifecycleConfigArn?;
        get builtInLifecycleConfigArn(): string;
        set builtInLifecycleConfigArn(value: string);
        resetBuiltInLifecycleConfigArn(): void;
        get builtInLifecycleConfigArnInput(): string | undefined;
        private _lifecycleConfigArns?;
        get lifecycleConfigArns(): string[];
        set lifecycleConfigArns(value: string[]);
        resetLifecycleConfigArns(): void;
        get lifecycleConfigArnsInput(): string[] | undefined;
        private _appLifecycleManagement;
        get appLifecycleManagement(): UserSettingsCodeEditorAppSettingsAppLifecycleManagementPropertyOutputReference;
        putAppLifecycleManagement(value: UserSettingsCodeEditorAppSettingsAppLifecycleManagementProperty): void;
        resetAppLifecycleManagement(): void;
        get appLifecycleManagementInput(): UserSettingsCodeEditorAppSettingsAppLifecycleManagementProperty | undefined;
        private _customImage;
        get customImage(): UserSettingsCodeEditorAppSettingsCustomImagePropertyList;
        putCustomImage(value: UserSettingsCodeEditorAppSettingsCustomImageProperty[] | cdktn.IResolvable): void;
        resetCustomImage(): void;
        get customImageInput(): cdktn.IResolvable | UserSettingsCodeEditorAppSettingsCustomImageProperty[] | undefined;
        private _defaultResourceSpec;
        get defaultResourceSpec(): UserSettingsCodeEditorAppSettingsDefaultResourceSpecPropertyOutputReference;
        putDefaultResourceSpec(value: UserSettingsCodeEditorAppSettingsDefaultResourceSpecProperty): void;
        resetDefaultResourceSpec(): void;
        get defaultResourceSpecInput(): UserSettingsCodeEditorAppSettingsDefaultResourceSpecProperty | undefined;
    }
    interface EfsFileSystemConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#file_system_id AwsUserProfile#file_system_id}
        */
        readonly fileSystemId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#file_system_path AwsUserProfile#file_system_path}
        */
        readonly fileSystemPath?: string;
    }
    class EfsFileSystemConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): EfsFileSystemConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: EfsFileSystemConfigProperty | cdktn.IResolvable | undefined);
        private _fileSystemId?;
        get fileSystemId(): string;
        set fileSystemId(value: string);
        get fileSystemIdInput(): string | undefined;
        private _fileSystemPath?;
        get fileSystemPath(): string;
        set fileSystemPath(value: string);
        resetFileSystemPath(): void;
        get fileSystemPathInput(): string | undefined;
    }
    class EfsFileSystemConfigPropertyList extends cdktn.ComplexList {
        internalValue?: EfsFileSystemConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): EfsFileSystemConfigPropertyOutputReference;
    }
    interface CustomFileSystemConfigProperty {
        /**
        * efs_file_system_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#efs_file_system_config AwsUserProfile#efs_file_system_config}
        */
        readonly efsFileSystemConfig?: EfsFileSystemConfigProperty[] | cdktn.IResolvable;
    }
    class CustomFileSystemConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CustomFileSystemConfigProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CustomFileSystemConfigProperty | cdktn.IResolvable | undefined);
        private _efsFileSystemConfig;
        get efsFileSystemConfig(): EfsFileSystemConfigPropertyList;
        putEfsFileSystemConfig(value: EfsFileSystemConfigProperty[] | cdktn.IResolvable): void;
        resetEfsFileSystemConfig(): void;
        get efsFileSystemConfigInput(): cdktn.IResolvable | EfsFileSystemConfigProperty[] | undefined;
    }
    class CustomFileSystemConfigPropertyList extends cdktn.ComplexList {
        internalValue?: CustomFileSystemConfigProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CustomFileSystemConfigPropertyOutputReference;
    }
    interface CustomPosixUserConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#gid AwsUserProfile#gid}
        */
        readonly gid: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#uid AwsUserProfile#uid}
        */
        readonly uid: number;
    }
    class CustomPosixUserConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CustomPosixUserConfigProperty | undefined;
        set internalValue(value: CustomPosixUserConfigProperty | undefined);
        private _gid?;
        get gid(): number;
        set gid(value: number);
        get gidInput(): number | undefined;
        private _uid?;
        get uid(): number;
        set uid(value: number);
        get uidInput(): number | undefined;
    }
    interface UserSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#idle_timeout_in_minutes AwsUserProfile#idle_timeout_in_minutes}
        */
        readonly idleTimeoutInMinutes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#lifecycle_management AwsUserProfile#lifecycle_management}
        */
        readonly lifecycleManagement?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#max_idle_timeout_in_minutes AwsUserProfile#max_idle_timeout_in_minutes}
        */
        readonly maxIdleTimeoutInMinutes?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#min_idle_timeout_in_minutes AwsUserProfile#min_idle_timeout_in_minutes}
        */
        readonly minIdleTimeoutInMinutes?: number;
    }
    class UserSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UserSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsProperty | undefined;
        set internalValue(value: UserSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsProperty | undefined);
        private _idleTimeoutInMinutes?;
        get idleTimeoutInMinutes(): number;
        set idleTimeoutInMinutes(value: number);
        resetIdleTimeoutInMinutes(): void;
        get idleTimeoutInMinutesInput(): number | undefined;
        private _lifecycleManagement?;
        get lifecycleManagement(): string;
        set lifecycleManagement(value: string);
        resetLifecycleManagement(): void;
        get lifecycleManagementInput(): string | undefined;
        private _maxIdleTimeoutInMinutes?;
        get maxIdleTimeoutInMinutes(): number;
        set maxIdleTimeoutInMinutes(value: number);
        resetMaxIdleTimeoutInMinutes(): void;
        get maxIdleTimeoutInMinutesInput(): number | undefined;
        private _minIdleTimeoutInMinutes?;
        get minIdleTimeoutInMinutes(): number;
        set minIdleTimeoutInMinutes(value: number);
        resetMinIdleTimeoutInMinutes(): void;
        get minIdleTimeoutInMinutesInput(): number | undefined;
    }
    interface UserSettingsJupyterLabAppSettingsAppLifecycleManagementProperty {
        /**
        * idle_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#idle_settings AwsUserProfile#idle_settings}
        */
        readonly idleSettings?: UserSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsProperty;
    }
    class UserSettingsJupyterLabAppSettingsAppLifecycleManagementPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UserSettingsJupyterLabAppSettingsAppLifecycleManagementProperty | undefined;
        set internalValue(value: UserSettingsJupyterLabAppSettingsAppLifecycleManagementProperty | undefined);
        private _idleSettings;
        get idleSettings(): UserSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsPropertyOutputReference;
        putIdleSettings(value: UserSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsProperty): void;
        resetIdleSettings(): void;
        get idleSettingsInput(): UserSettingsJupyterLabAppSettingsAppLifecycleManagementIdleSettingsProperty | undefined;
    }
    interface UserSettingsJupyterLabAppSettingsCodeRepositoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#repository_url AwsUserProfile#repository_url}
        */
        readonly repositoryUrl: string;
    }
    class UserSettingsJupyterLabAppSettingsCodeRepositoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UserSettingsJupyterLabAppSettingsCodeRepositoryProperty | cdktn.IResolvable | undefined;
        set internalValue(value: UserSettingsJupyterLabAppSettingsCodeRepositoryProperty | cdktn.IResolvable | undefined);
        private _repositoryUrl?;
        get repositoryUrl(): string;
        set repositoryUrl(value: string);
        get repositoryUrlInput(): string | undefined;
    }
    class UserSettingsJupyterLabAppSettingsCodeRepositoryPropertyList extends cdktn.ComplexList {
        internalValue?: UserSettingsJupyterLabAppSettingsCodeRepositoryProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UserSettingsJupyterLabAppSettingsCodeRepositoryPropertyOutputReference;
    }
    interface UserSettingsJupyterLabAppSettingsCustomImageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#app_image_config_name AwsUserProfile#app_image_config_name}
        */
        readonly appImageConfigName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#image_name AwsUserProfile#image_name}
        */
        readonly imageName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#image_version_number AwsUserProfile#image_version_number}
        */
        readonly imageVersionNumber?: number;
    }
    class UserSettingsJupyterLabAppSettingsCustomImagePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UserSettingsJupyterLabAppSettingsCustomImageProperty | cdktn.IResolvable | undefined;
        set internalValue(value: UserSettingsJupyterLabAppSettingsCustomImageProperty | cdktn.IResolvable | undefined);
        private _appImageConfigName?;
        get appImageConfigName(): string;
        set appImageConfigName(value: string);
        get appImageConfigNameInput(): string | undefined;
        private _imageName?;
        get imageName(): string;
        set imageName(value: string);
        get imageNameInput(): string | undefined;
        private _imageVersionNumber?;
        get imageVersionNumber(): number;
        set imageVersionNumber(value: number);
        resetImageVersionNumber(): void;
        get imageVersionNumberInput(): number | undefined;
    }
    class UserSettingsJupyterLabAppSettingsCustomImagePropertyList extends cdktn.ComplexList {
        internalValue?: UserSettingsJupyterLabAppSettingsCustomImageProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UserSettingsJupyterLabAppSettingsCustomImagePropertyOutputReference;
    }
    interface UserSettingsJupyterLabAppSettingsDefaultResourceSpecProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#instance_type AwsUserProfile#instance_type}
        */
        readonly instanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#lifecycle_config_arn AwsUserProfile#lifecycle_config_arn}
        */
        readonly lifecycleConfigArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#sagemaker_image_arn AwsUserProfile#sagemaker_image_arn}
        */
        readonly sagemakerImageArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#sagemaker_image_version_alias AwsUserProfile#sagemaker_image_version_alias}
        */
        readonly sagemakerImageVersionAlias?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#sagemaker_image_version_arn AwsUserProfile#sagemaker_image_version_arn}
        */
        readonly sagemakerImageVersionArn?: string;
    }
    class UserSettingsJupyterLabAppSettingsDefaultResourceSpecPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UserSettingsJupyterLabAppSettingsDefaultResourceSpecProperty | undefined;
        set internalValue(value: UserSettingsJupyterLabAppSettingsDefaultResourceSpecProperty | undefined);
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _lifecycleConfigArn?;
        get lifecycleConfigArn(): string;
        set lifecycleConfigArn(value: string);
        resetLifecycleConfigArn(): void;
        get lifecycleConfigArnInput(): string | undefined;
        private _sagemakerImageArn?;
        get sagemakerImageArn(): string;
        set sagemakerImageArn(value: string);
        resetSagemakerImageArn(): void;
        get sagemakerImageArnInput(): string | undefined;
        private _sagemakerImageVersionAlias?;
        get sagemakerImageVersionAlias(): string;
        set sagemakerImageVersionAlias(value: string);
        resetSagemakerImageVersionAlias(): void;
        get sagemakerImageVersionAliasInput(): string | undefined;
        private _sagemakerImageVersionArn?;
        get sagemakerImageVersionArn(): string;
        set sagemakerImageVersionArn(value: string);
        resetSagemakerImageVersionArn(): void;
        get sagemakerImageVersionArnInput(): string | undefined;
    }
    interface EmrSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#assumable_role_arns AwsUserProfile#assumable_role_arns}
        */
        readonly assumableRoleArns?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#execution_role_arns AwsUserProfile#execution_role_arns}
        */
        readonly executionRoleArns?: string[];
    }
    class EmrSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EmrSettingsProperty | undefined;
        set internalValue(value: EmrSettingsProperty | undefined);
        private _assumableRoleArns?;
        get assumableRoleArns(): string[];
        set assumableRoleArns(value: string[]);
        resetAssumableRoleArns(): void;
        get assumableRoleArnsInput(): string[] | undefined;
        private _executionRoleArns?;
        get executionRoleArns(): string[];
        set executionRoleArns(value: string[]);
        resetExecutionRoleArns(): void;
        get executionRoleArnsInput(): string[] | undefined;
    }
    interface JupyterLabAppSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#built_in_lifecycle_config_arn AwsUserProfile#built_in_lifecycle_config_arn}
        */
        readonly builtInLifecycleConfigArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#lifecycle_config_arns AwsUserProfile#lifecycle_config_arns}
        */
        readonly lifecycleConfigArns?: string[];
        /**
        * app_lifecycle_management block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#app_lifecycle_management AwsUserProfile#app_lifecycle_management}
        */
        readonly appLifecycleManagement?: UserSettingsJupyterLabAppSettingsAppLifecycleManagementProperty;
        /**
        * code_repository block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#code_repository AwsUserProfile#code_repository}
        */
        readonly codeRepository?: UserSettingsJupyterLabAppSettingsCodeRepositoryProperty[] | cdktn.IResolvable;
        /**
        * custom_image block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#custom_image AwsUserProfile#custom_image}
        */
        readonly customImage?: UserSettingsJupyterLabAppSettingsCustomImageProperty[] | cdktn.IResolvable;
        /**
        * default_resource_spec block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#default_resource_spec AwsUserProfile#default_resource_spec}
        */
        readonly defaultResourceSpec?: UserSettingsJupyterLabAppSettingsDefaultResourceSpecProperty;
        /**
        * emr_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#emr_settings AwsUserProfile#emr_settings}
        */
        readonly emrSettings?: EmrSettingsProperty;
    }
    class JupyterLabAppSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): JupyterLabAppSettingsProperty | undefined;
        set internalValue(value: JupyterLabAppSettingsProperty | undefined);
        private _builtInLifecycleConfigArn?;
        get builtInLifecycleConfigArn(): string;
        set builtInLifecycleConfigArn(value: string);
        resetBuiltInLifecycleConfigArn(): void;
        get builtInLifecycleConfigArnInput(): string | undefined;
        private _lifecycleConfigArns?;
        get lifecycleConfigArns(): string[];
        set lifecycleConfigArns(value: string[]);
        resetLifecycleConfigArns(): void;
        get lifecycleConfigArnsInput(): string[] | undefined;
        private _appLifecycleManagement;
        get appLifecycleManagement(): UserSettingsJupyterLabAppSettingsAppLifecycleManagementPropertyOutputReference;
        putAppLifecycleManagement(value: UserSettingsJupyterLabAppSettingsAppLifecycleManagementProperty): void;
        resetAppLifecycleManagement(): void;
        get appLifecycleManagementInput(): UserSettingsJupyterLabAppSettingsAppLifecycleManagementProperty | undefined;
        private _codeRepository;
        get codeRepository(): UserSettingsJupyterLabAppSettingsCodeRepositoryPropertyList;
        putCodeRepository(value: UserSettingsJupyterLabAppSettingsCodeRepositoryProperty[] | cdktn.IResolvable): void;
        resetCodeRepository(): void;
        get codeRepositoryInput(): cdktn.IResolvable | UserSettingsJupyterLabAppSettingsCodeRepositoryProperty[] | undefined;
        private _customImage;
        get customImage(): UserSettingsJupyterLabAppSettingsCustomImagePropertyList;
        putCustomImage(value: UserSettingsJupyterLabAppSettingsCustomImageProperty[] | cdktn.IResolvable): void;
        resetCustomImage(): void;
        get customImageInput(): cdktn.IResolvable | UserSettingsJupyterLabAppSettingsCustomImageProperty[] | undefined;
        private _defaultResourceSpec;
        get defaultResourceSpec(): UserSettingsJupyterLabAppSettingsDefaultResourceSpecPropertyOutputReference;
        putDefaultResourceSpec(value: UserSettingsJupyterLabAppSettingsDefaultResourceSpecProperty): void;
        resetDefaultResourceSpec(): void;
        get defaultResourceSpecInput(): UserSettingsJupyterLabAppSettingsDefaultResourceSpecProperty | undefined;
        private _emrSettings;
        get emrSettings(): EmrSettingsPropertyOutputReference;
        putEmrSettings(value: EmrSettingsProperty): void;
        resetEmrSettings(): void;
        get emrSettingsInput(): EmrSettingsProperty | undefined;
    }
    interface UserSettingsJupyterServerAppSettingsCodeRepositoryProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#repository_url AwsUserProfile#repository_url}
        */
        readonly repositoryUrl: string;
    }
    class UserSettingsJupyterServerAppSettingsCodeRepositoryPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UserSettingsJupyterServerAppSettingsCodeRepositoryProperty | cdktn.IResolvable | undefined;
        set internalValue(value: UserSettingsJupyterServerAppSettingsCodeRepositoryProperty | cdktn.IResolvable | undefined);
        private _repositoryUrl?;
        get repositoryUrl(): string;
        set repositoryUrl(value: string);
        get repositoryUrlInput(): string | undefined;
    }
    class UserSettingsJupyterServerAppSettingsCodeRepositoryPropertyList extends cdktn.ComplexList {
        internalValue?: UserSettingsJupyterServerAppSettingsCodeRepositoryProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UserSettingsJupyterServerAppSettingsCodeRepositoryPropertyOutputReference;
    }
    interface UserSettingsJupyterServerAppSettingsDefaultResourceSpecProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#instance_type AwsUserProfile#instance_type}
        */
        readonly instanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#lifecycle_config_arn AwsUserProfile#lifecycle_config_arn}
        */
        readonly lifecycleConfigArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#sagemaker_image_arn AwsUserProfile#sagemaker_image_arn}
        */
        readonly sagemakerImageArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#sagemaker_image_version_alias AwsUserProfile#sagemaker_image_version_alias}
        */
        readonly sagemakerImageVersionAlias?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#sagemaker_image_version_arn AwsUserProfile#sagemaker_image_version_arn}
        */
        readonly sagemakerImageVersionArn?: string;
    }
    class UserSettingsJupyterServerAppSettingsDefaultResourceSpecPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UserSettingsJupyterServerAppSettingsDefaultResourceSpecProperty | undefined;
        set internalValue(value: UserSettingsJupyterServerAppSettingsDefaultResourceSpecProperty | undefined);
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _lifecycleConfigArn?;
        get lifecycleConfigArn(): string;
        set lifecycleConfigArn(value: string);
        resetLifecycleConfigArn(): void;
        get lifecycleConfigArnInput(): string | undefined;
        private _sagemakerImageArn?;
        get sagemakerImageArn(): string;
        set sagemakerImageArn(value: string);
        resetSagemakerImageArn(): void;
        get sagemakerImageArnInput(): string | undefined;
        private _sagemakerImageVersionAlias?;
        get sagemakerImageVersionAlias(): string;
        set sagemakerImageVersionAlias(value: string);
        resetSagemakerImageVersionAlias(): void;
        get sagemakerImageVersionAliasInput(): string | undefined;
        private _sagemakerImageVersionArn?;
        get sagemakerImageVersionArn(): string;
        set sagemakerImageVersionArn(value: string);
        resetSagemakerImageVersionArn(): void;
        get sagemakerImageVersionArnInput(): string | undefined;
    }
    interface JupyterServerAppSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#lifecycle_config_arns AwsUserProfile#lifecycle_config_arns}
        */
        readonly lifecycleConfigArns?: string[];
        /**
        * code_repository block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#code_repository AwsUserProfile#code_repository}
        */
        readonly codeRepository?: UserSettingsJupyterServerAppSettingsCodeRepositoryProperty[] | cdktn.IResolvable;
        /**
        * default_resource_spec block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#default_resource_spec AwsUserProfile#default_resource_spec}
        */
        readonly defaultResourceSpec?: UserSettingsJupyterServerAppSettingsDefaultResourceSpecProperty;
    }
    class JupyterServerAppSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): JupyterServerAppSettingsProperty | undefined;
        set internalValue(value: JupyterServerAppSettingsProperty | undefined);
        private _lifecycleConfigArns?;
        get lifecycleConfigArns(): string[];
        set lifecycleConfigArns(value: string[]);
        resetLifecycleConfigArns(): void;
        get lifecycleConfigArnsInput(): string[] | undefined;
        private _codeRepository;
        get codeRepository(): UserSettingsJupyterServerAppSettingsCodeRepositoryPropertyList;
        putCodeRepository(value: UserSettingsJupyterServerAppSettingsCodeRepositoryProperty[] | cdktn.IResolvable): void;
        resetCodeRepository(): void;
        get codeRepositoryInput(): cdktn.IResolvable | UserSettingsJupyterServerAppSettingsCodeRepositoryProperty[] | undefined;
        private _defaultResourceSpec;
        get defaultResourceSpec(): UserSettingsJupyterServerAppSettingsDefaultResourceSpecPropertyOutputReference;
        putDefaultResourceSpec(value: UserSettingsJupyterServerAppSettingsDefaultResourceSpecProperty): void;
        resetDefaultResourceSpec(): void;
        get defaultResourceSpecInput(): UserSettingsJupyterServerAppSettingsDefaultResourceSpecProperty | undefined;
    }
    interface UserSettingsKernelGatewayAppSettingsCustomImageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#app_image_config_name AwsUserProfile#app_image_config_name}
        */
        readonly appImageConfigName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#image_name AwsUserProfile#image_name}
        */
        readonly imageName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#image_version_number AwsUserProfile#image_version_number}
        */
        readonly imageVersionNumber?: number;
    }
    class UserSettingsKernelGatewayAppSettingsCustomImagePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UserSettingsKernelGatewayAppSettingsCustomImageProperty | cdktn.IResolvable | undefined;
        set internalValue(value: UserSettingsKernelGatewayAppSettingsCustomImageProperty | cdktn.IResolvable | undefined);
        private _appImageConfigName?;
        get appImageConfigName(): string;
        set appImageConfigName(value: string);
        get appImageConfigNameInput(): string | undefined;
        private _imageName?;
        get imageName(): string;
        set imageName(value: string);
        get imageNameInput(): string | undefined;
        private _imageVersionNumber?;
        get imageVersionNumber(): number;
        set imageVersionNumber(value: number);
        resetImageVersionNumber(): void;
        get imageVersionNumberInput(): number | undefined;
    }
    class UserSettingsKernelGatewayAppSettingsCustomImagePropertyList extends cdktn.ComplexList {
        internalValue?: UserSettingsKernelGatewayAppSettingsCustomImageProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UserSettingsKernelGatewayAppSettingsCustomImagePropertyOutputReference;
    }
    interface UserSettingsKernelGatewayAppSettingsDefaultResourceSpecProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#instance_type AwsUserProfile#instance_type}
        */
        readonly instanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#lifecycle_config_arn AwsUserProfile#lifecycle_config_arn}
        */
        readonly lifecycleConfigArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#sagemaker_image_arn AwsUserProfile#sagemaker_image_arn}
        */
        readonly sagemakerImageArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#sagemaker_image_version_alias AwsUserProfile#sagemaker_image_version_alias}
        */
        readonly sagemakerImageVersionAlias?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#sagemaker_image_version_arn AwsUserProfile#sagemaker_image_version_arn}
        */
        readonly sagemakerImageVersionArn?: string;
    }
    class UserSettingsKernelGatewayAppSettingsDefaultResourceSpecPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UserSettingsKernelGatewayAppSettingsDefaultResourceSpecProperty | undefined;
        set internalValue(value: UserSettingsKernelGatewayAppSettingsDefaultResourceSpecProperty | undefined);
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _lifecycleConfigArn?;
        get lifecycleConfigArn(): string;
        set lifecycleConfigArn(value: string);
        resetLifecycleConfigArn(): void;
        get lifecycleConfigArnInput(): string | undefined;
        private _sagemakerImageArn?;
        get sagemakerImageArn(): string;
        set sagemakerImageArn(value: string);
        resetSagemakerImageArn(): void;
        get sagemakerImageArnInput(): string | undefined;
        private _sagemakerImageVersionAlias?;
        get sagemakerImageVersionAlias(): string;
        set sagemakerImageVersionAlias(value: string);
        resetSagemakerImageVersionAlias(): void;
        get sagemakerImageVersionAliasInput(): string | undefined;
        private _sagemakerImageVersionArn?;
        get sagemakerImageVersionArn(): string;
        set sagemakerImageVersionArn(value: string);
        resetSagemakerImageVersionArn(): void;
        get sagemakerImageVersionArnInput(): string | undefined;
    }
    interface KernelGatewayAppSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#lifecycle_config_arns AwsUserProfile#lifecycle_config_arns}
        */
        readonly lifecycleConfigArns?: string[];
        /**
        * custom_image block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#custom_image AwsUserProfile#custom_image}
        */
        readonly customImage?: UserSettingsKernelGatewayAppSettingsCustomImageProperty[] | cdktn.IResolvable;
        /**
        * default_resource_spec block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#default_resource_spec AwsUserProfile#default_resource_spec}
        */
        readonly defaultResourceSpec?: UserSettingsKernelGatewayAppSettingsDefaultResourceSpecProperty;
    }
    class KernelGatewayAppSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KernelGatewayAppSettingsProperty | undefined;
        set internalValue(value: KernelGatewayAppSettingsProperty | undefined);
        private _lifecycleConfigArns?;
        get lifecycleConfigArns(): string[];
        set lifecycleConfigArns(value: string[]);
        resetLifecycleConfigArns(): void;
        get lifecycleConfigArnsInput(): string[] | undefined;
        private _customImage;
        get customImage(): UserSettingsKernelGatewayAppSettingsCustomImagePropertyList;
        putCustomImage(value: UserSettingsKernelGatewayAppSettingsCustomImageProperty[] | cdktn.IResolvable): void;
        resetCustomImage(): void;
        get customImageInput(): cdktn.IResolvable | UserSettingsKernelGatewayAppSettingsCustomImageProperty[] | undefined;
        private _defaultResourceSpec;
        get defaultResourceSpec(): UserSettingsKernelGatewayAppSettingsDefaultResourceSpecPropertyOutputReference;
        putDefaultResourceSpec(value: UserSettingsKernelGatewayAppSettingsDefaultResourceSpecProperty): void;
        resetDefaultResourceSpec(): void;
        get defaultResourceSpecInput(): UserSettingsKernelGatewayAppSettingsDefaultResourceSpecProperty | undefined;
    }
    interface UserSettingsRSessionAppSettingsCustomImageProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#app_image_config_name AwsUserProfile#app_image_config_name}
        */
        readonly appImageConfigName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#image_name AwsUserProfile#image_name}
        */
        readonly imageName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#image_version_number AwsUserProfile#image_version_number}
        */
        readonly imageVersionNumber?: number;
    }
    class UserSettingsRSessionAppSettingsCustomImagePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): UserSettingsRSessionAppSettingsCustomImageProperty | cdktn.IResolvable | undefined;
        set internalValue(value: UserSettingsRSessionAppSettingsCustomImageProperty | cdktn.IResolvable | undefined);
        private _appImageConfigName?;
        get appImageConfigName(): string;
        set appImageConfigName(value: string);
        get appImageConfigNameInput(): string | undefined;
        private _imageName?;
        get imageName(): string;
        set imageName(value: string);
        get imageNameInput(): string | undefined;
        private _imageVersionNumber?;
        get imageVersionNumber(): number;
        set imageVersionNumber(value: number);
        resetImageVersionNumber(): void;
        get imageVersionNumberInput(): number | undefined;
    }
    class UserSettingsRSessionAppSettingsCustomImagePropertyList extends cdktn.ComplexList {
        internalValue?: UserSettingsRSessionAppSettingsCustomImageProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): UserSettingsRSessionAppSettingsCustomImagePropertyOutputReference;
    }
    interface UserSettingsRSessionAppSettingsDefaultResourceSpecProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#instance_type AwsUserProfile#instance_type}
        */
        readonly instanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#lifecycle_config_arn AwsUserProfile#lifecycle_config_arn}
        */
        readonly lifecycleConfigArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#sagemaker_image_arn AwsUserProfile#sagemaker_image_arn}
        */
        readonly sagemakerImageArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#sagemaker_image_version_alias AwsUserProfile#sagemaker_image_version_alias}
        */
        readonly sagemakerImageVersionAlias?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#sagemaker_image_version_arn AwsUserProfile#sagemaker_image_version_arn}
        */
        readonly sagemakerImageVersionArn?: string;
    }
    class UserSettingsRSessionAppSettingsDefaultResourceSpecPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UserSettingsRSessionAppSettingsDefaultResourceSpecProperty | undefined;
        set internalValue(value: UserSettingsRSessionAppSettingsDefaultResourceSpecProperty | undefined);
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _lifecycleConfigArn?;
        get lifecycleConfigArn(): string;
        set lifecycleConfigArn(value: string);
        resetLifecycleConfigArn(): void;
        get lifecycleConfigArnInput(): string | undefined;
        private _sagemakerImageArn?;
        get sagemakerImageArn(): string;
        set sagemakerImageArn(value: string);
        resetSagemakerImageArn(): void;
        get sagemakerImageArnInput(): string | undefined;
        private _sagemakerImageVersionAlias?;
        get sagemakerImageVersionAlias(): string;
        set sagemakerImageVersionAlias(value: string);
        resetSagemakerImageVersionAlias(): void;
        get sagemakerImageVersionAliasInput(): string | undefined;
        private _sagemakerImageVersionArn?;
        get sagemakerImageVersionArn(): string;
        set sagemakerImageVersionArn(value: string);
        resetSagemakerImageVersionArn(): void;
        get sagemakerImageVersionArnInput(): string | undefined;
    }
    interface RSessionAppSettingsProperty {
        /**
        * custom_image block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#custom_image AwsUserProfile#custom_image}
        */
        readonly customImage?: UserSettingsRSessionAppSettingsCustomImageProperty[] | cdktn.IResolvable;
        /**
        * default_resource_spec block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#default_resource_spec AwsUserProfile#default_resource_spec}
        */
        readonly defaultResourceSpec?: UserSettingsRSessionAppSettingsDefaultResourceSpecProperty;
    }
    class RSessionAppSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RSessionAppSettingsProperty | undefined;
        set internalValue(value: RSessionAppSettingsProperty | undefined);
        private _customImage;
        get customImage(): UserSettingsRSessionAppSettingsCustomImagePropertyList;
        putCustomImage(value: UserSettingsRSessionAppSettingsCustomImageProperty[] | cdktn.IResolvable): void;
        resetCustomImage(): void;
        get customImageInput(): cdktn.IResolvable | UserSettingsRSessionAppSettingsCustomImageProperty[] | undefined;
        private _defaultResourceSpec;
        get defaultResourceSpec(): UserSettingsRSessionAppSettingsDefaultResourceSpecPropertyOutputReference;
        putDefaultResourceSpec(value: UserSettingsRSessionAppSettingsDefaultResourceSpecProperty): void;
        resetDefaultResourceSpec(): void;
        get defaultResourceSpecInput(): UserSettingsRSessionAppSettingsDefaultResourceSpecProperty | undefined;
    }
    interface RStudioServerProAppSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#access_status AwsUserProfile#access_status}
        */
        readonly accessStatus?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#user_group AwsUserProfile#user_group}
        */
        readonly userGroup?: string;
    }
    class RStudioServerProAppSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): RStudioServerProAppSettingsProperty | undefined;
        set internalValue(value: RStudioServerProAppSettingsProperty | undefined);
        private _accessStatus?;
        get accessStatus(): string;
        set accessStatus(value: string);
        resetAccessStatus(): void;
        get accessStatusInput(): string | undefined;
        private _userGroup?;
        get userGroup(): string;
        set userGroup(value: string);
        resetUserGroup(): void;
        get userGroupInput(): string | undefined;
    }
    interface SharingSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#notebook_output_option AwsUserProfile#notebook_output_option}
        */
        readonly notebookOutputOption?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#s3_kms_key_id AwsUserProfile#s3_kms_key_id}
        */
        readonly s3KmsKeyId?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#s3_output_path AwsUserProfile#s3_output_path}
        */
        readonly s3OutputPath?: string;
    }
    class SharingSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SharingSettingsProperty | undefined;
        set internalValue(value: SharingSettingsProperty | undefined);
        private _notebookOutputOption?;
        get notebookOutputOption(): string;
        set notebookOutputOption(value: string);
        resetNotebookOutputOption(): void;
        get notebookOutputOptionInput(): string | undefined;
        private _s3KmsKeyId?;
        get s3KmsKeyId(): string;
        set s3KmsKeyId(value: string);
        resetS3KmsKeyId(): void;
        get s3KmsKeyIdInput(): string | undefined;
        private _s3OutputPath?;
        get s3OutputPath(): string;
        set s3OutputPath(value: string);
        resetS3OutputPath(): void;
        get s3OutputPathInput(): string | undefined;
    }
    interface DefaultEbsStorageSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#default_ebs_volume_size_in_gb AwsUserProfile#default_ebs_volume_size_in_gb}
        */
        readonly defaultEbsVolumeSizeInGb: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#maximum_ebs_volume_size_in_gb AwsUserProfile#maximum_ebs_volume_size_in_gb}
        */
        readonly maximumEbsVolumeSizeInGb: number;
    }
    class DefaultEbsStorageSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): DefaultEbsStorageSettingsProperty | undefined;
        set internalValue(value: DefaultEbsStorageSettingsProperty | undefined);
        private _defaultEbsVolumeSizeInGb?;
        get defaultEbsVolumeSizeInGb(): number;
        set defaultEbsVolumeSizeInGb(value: number);
        get defaultEbsVolumeSizeInGbInput(): number | undefined;
        private _maximumEbsVolumeSizeInGb?;
        get maximumEbsVolumeSizeInGb(): number;
        set maximumEbsVolumeSizeInGb(value: number);
        get maximumEbsVolumeSizeInGbInput(): number | undefined;
    }
    interface SpaceStorageSettingsProperty {
        /**
        * default_ebs_storage_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#default_ebs_storage_settings AwsUserProfile#default_ebs_storage_settings}
        */
        readonly defaultEbsStorageSettings?: DefaultEbsStorageSettingsProperty;
    }
    class SpaceStorageSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SpaceStorageSettingsProperty | undefined;
        set internalValue(value: SpaceStorageSettingsProperty | undefined);
        private _defaultEbsStorageSettings;
        get defaultEbsStorageSettings(): DefaultEbsStorageSettingsPropertyOutputReference;
        putDefaultEbsStorageSettings(value: DefaultEbsStorageSettingsProperty): void;
        resetDefaultEbsStorageSettings(): void;
        get defaultEbsStorageSettingsInput(): DefaultEbsStorageSettingsProperty | undefined;
    }
    interface StudioWebPortalSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#hidden_app_types AwsUserProfile#hidden_app_types}
        */
        readonly hiddenAppTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#hidden_instance_types AwsUserProfile#hidden_instance_types}
        */
        readonly hiddenInstanceTypes?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#hidden_ml_tools AwsUserProfile#hidden_ml_tools}
        */
        readonly hiddenMlTools?: string[];
    }
    class StudioWebPortalSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): StudioWebPortalSettingsProperty | undefined;
        set internalValue(value: StudioWebPortalSettingsProperty | undefined);
        private _hiddenAppTypes?;
        get hiddenAppTypes(): string[];
        set hiddenAppTypes(value: string[]);
        resetHiddenAppTypes(): void;
        get hiddenAppTypesInput(): string[] | undefined;
        private _hiddenInstanceTypes?;
        get hiddenInstanceTypes(): string[];
        set hiddenInstanceTypes(value: string[]);
        resetHiddenInstanceTypes(): void;
        get hiddenInstanceTypesInput(): string[] | undefined;
        private _hiddenMlTools?;
        get hiddenMlTools(): string[];
        set hiddenMlTools(value: string[]);
        resetHiddenMlTools(): void;
        get hiddenMlToolsInput(): string[] | undefined;
    }
    interface UserSettingsTensorBoardAppSettingsDefaultResourceSpecProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#instance_type AwsUserProfile#instance_type}
        */
        readonly instanceType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#lifecycle_config_arn AwsUserProfile#lifecycle_config_arn}
        */
        readonly lifecycleConfigArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#sagemaker_image_arn AwsUserProfile#sagemaker_image_arn}
        */
        readonly sagemakerImageArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#sagemaker_image_version_alias AwsUserProfile#sagemaker_image_version_alias}
        */
        readonly sagemakerImageVersionAlias?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#sagemaker_image_version_arn AwsUserProfile#sagemaker_image_version_arn}
        */
        readonly sagemakerImageVersionArn?: string;
    }
    class UserSettingsTensorBoardAppSettingsDefaultResourceSpecPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UserSettingsTensorBoardAppSettingsDefaultResourceSpecProperty | undefined;
        set internalValue(value: UserSettingsTensorBoardAppSettingsDefaultResourceSpecProperty | undefined);
        private _instanceType?;
        get instanceType(): string;
        set instanceType(value: string);
        resetInstanceType(): void;
        get instanceTypeInput(): string | undefined;
        private _lifecycleConfigArn?;
        get lifecycleConfigArn(): string;
        set lifecycleConfigArn(value: string);
        resetLifecycleConfigArn(): void;
        get lifecycleConfigArnInput(): string | undefined;
        private _sagemakerImageArn?;
        get sagemakerImageArn(): string;
        set sagemakerImageArn(value: string);
        resetSagemakerImageArn(): void;
        get sagemakerImageArnInput(): string | undefined;
        private _sagemakerImageVersionAlias?;
        get sagemakerImageVersionAlias(): string;
        set sagemakerImageVersionAlias(value: string);
        resetSagemakerImageVersionAlias(): void;
        get sagemakerImageVersionAliasInput(): string | undefined;
        private _sagemakerImageVersionArn?;
        get sagemakerImageVersionArn(): string;
        set sagemakerImageVersionArn(value: string);
        resetSagemakerImageVersionArn(): void;
        get sagemakerImageVersionArnInput(): string | undefined;
    }
    interface TensorBoardAppSettingsProperty {
        /**
        * default_resource_spec block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#default_resource_spec AwsUserProfile#default_resource_spec}
        */
        readonly defaultResourceSpec?: UserSettingsTensorBoardAppSettingsDefaultResourceSpecProperty;
    }
    class TensorBoardAppSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TensorBoardAppSettingsProperty | undefined;
        set internalValue(value: TensorBoardAppSettingsProperty | undefined);
        private _defaultResourceSpec;
        get defaultResourceSpec(): UserSettingsTensorBoardAppSettingsDefaultResourceSpecPropertyOutputReference;
        putDefaultResourceSpec(value: UserSettingsTensorBoardAppSettingsDefaultResourceSpecProperty): void;
        resetDefaultResourceSpec(): void;
        get defaultResourceSpecInput(): UserSettingsTensorBoardAppSettingsDefaultResourceSpecProperty | undefined;
    }
    interface UserSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#auto_mount_home_efs AwsUserProfile#auto_mount_home_efs}
        */
        readonly autoMountHomeEfs?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#default_landing_uri AwsUserProfile#default_landing_uri}
        */
        readonly defaultLandingUri?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#execution_role AwsUserProfile#execution_role}
        */
        readonly executionRole: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#security_groups AwsUserProfile#security_groups}
        */
        readonly securityGroups?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#studio_web_portal AwsUserProfile#studio_web_portal}
        */
        readonly studioWebPortal?: string;
        /**
        * canvas_app_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#canvas_app_settings AwsUserProfile#canvas_app_settings}
        */
        readonly canvasAppSettings?: CanvasAppSettingsProperty;
        /**
        * code_editor_app_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#code_editor_app_settings AwsUserProfile#code_editor_app_settings}
        */
        readonly codeEditorAppSettings?: CodeEditorAppSettingsProperty;
        /**
        * custom_file_system_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#custom_file_system_config AwsUserProfile#custom_file_system_config}
        */
        readonly customFileSystemConfig?: CustomFileSystemConfigProperty[] | cdktn.IResolvable;
        /**
        * custom_posix_user_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#custom_posix_user_config AwsUserProfile#custom_posix_user_config}
        */
        readonly customPosixUserConfig?: CustomPosixUserConfigProperty;
        /**
        * jupyter_lab_app_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#jupyter_lab_app_settings AwsUserProfile#jupyter_lab_app_settings}
        */
        readonly jupyterLabAppSettings?: JupyterLabAppSettingsProperty;
        /**
        * jupyter_server_app_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#jupyter_server_app_settings AwsUserProfile#jupyter_server_app_settings}
        */
        readonly jupyterServerAppSettings?: JupyterServerAppSettingsProperty;
        /**
        * kernel_gateway_app_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#kernel_gateway_app_settings AwsUserProfile#kernel_gateway_app_settings}
        */
        readonly kernelGatewayAppSettings?: KernelGatewayAppSettingsProperty;
        /**
        * r_session_app_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#r_session_app_settings AwsUserProfile#r_session_app_settings}
        */
        readonly rSessionAppSettings?: RSessionAppSettingsProperty;
        /**
        * r_studio_server_pro_app_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#r_studio_server_pro_app_settings AwsUserProfile#r_studio_server_pro_app_settings}
        */
        readonly rStudioServerProAppSettings?: RStudioServerProAppSettingsProperty;
        /**
        * sharing_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#sharing_settings AwsUserProfile#sharing_settings}
        */
        readonly sharingSettings?: SharingSettingsProperty;
        /**
        * space_storage_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#space_storage_settings AwsUserProfile#space_storage_settings}
        */
        readonly spaceStorageSettings?: SpaceStorageSettingsProperty;
        /**
        * studio_web_portal_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#studio_web_portal_settings AwsUserProfile#studio_web_portal_settings}
        */
        readonly studioWebPortalSettings?: StudioWebPortalSettingsProperty;
        /**
        * tensor_board_app_settings block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_user_profile#tensor_board_app_settings AwsUserProfile#tensor_board_app_settings}
        */
        readonly tensorBoardAppSettings?: TensorBoardAppSettingsProperty;
    }
    class UserSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): UserSettingsProperty | undefined;
        set internalValue(value: UserSettingsProperty | undefined);
        private _autoMountHomeEfs?;
        get autoMountHomeEfs(): string;
        set autoMountHomeEfs(value: string);
        resetAutoMountHomeEfs(): void;
        get autoMountHomeEfsInput(): string | undefined;
        private _defaultLandingUri?;
        get defaultLandingUri(): string;
        set defaultLandingUri(value: string);
        resetDefaultLandingUri(): void;
        get defaultLandingUriInput(): string | undefined;
        private _executionRole?;
        get executionRole(): string;
        set executionRole(value: string);
        get executionRoleInput(): string | undefined;
        private _securityGroups?;
        get securityGroups(): string[];
        set securityGroups(value: string[]);
        resetSecurityGroups(): void;
        get securityGroupsInput(): string[] | undefined;
        private _studioWebPortal?;
        get studioWebPortal(): string;
        set studioWebPortal(value: string);
        resetStudioWebPortal(): void;
        get studioWebPortalInput(): string | undefined;
        private _canvasAppSettings;
        get canvasAppSettings(): CanvasAppSettingsPropertyOutputReference;
        putCanvasAppSettings(value: CanvasAppSettingsProperty): void;
        resetCanvasAppSettings(): void;
        get canvasAppSettingsInput(): CanvasAppSettingsProperty | undefined;
        private _codeEditorAppSettings;
        get codeEditorAppSettings(): CodeEditorAppSettingsPropertyOutputReference;
        putCodeEditorAppSettings(value: CodeEditorAppSettingsProperty): void;
        resetCodeEditorAppSettings(): void;
        get codeEditorAppSettingsInput(): CodeEditorAppSettingsProperty | undefined;
        private _customFileSystemConfig;
        get customFileSystemConfig(): CustomFileSystemConfigPropertyList;
        putCustomFileSystemConfig(value: CustomFileSystemConfigProperty[] | cdktn.IResolvable): void;
        resetCustomFileSystemConfig(): void;
        get customFileSystemConfigInput(): cdktn.IResolvable | CustomFileSystemConfigProperty[] | undefined;
        private _customPosixUserConfig;
        get customPosixUserConfig(): CustomPosixUserConfigPropertyOutputReference;
        putCustomPosixUserConfig(value: CustomPosixUserConfigProperty): void;
        resetCustomPosixUserConfig(): void;
        get customPosixUserConfigInput(): CustomPosixUserConfigProperty | undefined;
        private _jupyterLabAppSettings;
        get jupyterLabAppSettings(): JupyterLabAppSettingsPropertyOutputReference;
        putJupyterLabAppSettings(value: JupyterLabAppSettingsProperty): void;
        resetJupyterLabAppSettings(): void;
        get jupyterLabAppSettingsInput(): JupyterLabAppSettingsProperty | undefined;
        private _jupyterServerAppSettings;
        get jupyterServerAppSettings(): JupyterServerAppSettingsPropertyOutputReference;
        putJupyterServerAppSettings(value: JupyterServerAppSettingsProperty): void;
        resetJupyterServerAppSettings(): void;
        get jupyterServerAppSettingsInput(): JupyterServerAppSettingsProperty | undefined;
        private _kernelGatewayAppSettings;
        get kernelGatewayAppSettings(): KernelGatewayAppSettingsPropertyOutputReference;
        putKernelGatewayAppSettings(value: KernelGatewayAppSettingsProperty): void;
        resetKernelGatewayAppSettings(): void;
        get kernelGatewayAppSettingsInput(): KernelGatewayAppSettingsProperty | undefined;
        private _rSessionAppSettings;
        get rSessionAppSettings(): RSessionAppSettingsPropertyOutputReference;
        putRSessionAppSettings(value: RSessionAppSettingsProperty): void;
        resetRSessionAppSettings(): void;
        get rSessionAppSettingsInput(): RSessionAppSettingsProperty | undefined;
        private _rStudioServerProAppSettings;
        get rStudioServerProAppSettings(): RStudioServerProAppSettingsPropertyOutputReference;
        putRStudioServerProAppSettings(value: RStudioServerProAppSettingsProperty): void;
        resetRStudioServerProAppSettings(): void;
        get rStudioServerProAppSettingsInput(): RStudioServerProAppSettingsProperty | undefined;
        private _sharingSettings;
        get sharingSettings(): SharingSettingsPropertyOutputReference;
        putSharingSettings(value: SharingSettingsProperty): void;
        resetSharingSettings(): void;
        get sharingSettingsInput(): SharingSettingsProperty | undefined;
        private _spaceStorageSettings;
        get spaceStorageSettings(): SpaceStorageSettingsPropertyOutputReference;
        putSpaceStorageSettings(value: SpaceStorageSettingsProperty): void;
        resetSpaceStorageSettings(): void;
        get spaceStorageSettingsInput(): SpaceStorageSettingsProperty | undefined;
        private _studioWebPortalSettings;
        get studioWebPortalSettings(): StudioWebPortalSettingsPropertyOutputReference;
        putStudioWebPortalSettings(value: StudioWebPortalSettingsProperty): void;
        resetStudioWebPortalSettings(): void;
        get studioWebPortalSettingsInput(): StudioWebPortalSettingsProperty | undefined;
        private _tensorBoardAppSettings;
        get tensorBoardAppSettings(): TensorBoardAppSettingsPropertyOutputReference;
        putTensorBoardAppSettings(value: TensorBoardAppSettingsProperty): void;
        resetTensorBoardAppSettings(): void;
        get tensorBoardAppSettingsInput(): TensorBoardAppSettingsProperty | undefined;
    }
}
