import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsPipelineConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_pipeline#id AwsPipeline#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_pipeline#pipeline_definition AwsPipeline#pipeline_definition}
    */
    readonly pipelineDefinition?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_pipeline#pipeline_description AwsPipeline#pipeline_description}
    */
    readonly pipelineDescription?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_pipeline#pipeline_display_name AwsPipeline#pipeline_display_name}
    */
    readonly pipelineDisplayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_pipeline#pipeline_name AwsPipeline#pipeline_name}
    */
    readonly pipelineName: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_pipeline#region AwsPipeline#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_pipeline#role_arn AwsPipeline#role_arn}
    */
    readonly roleArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_pipeline#tags AwsPipeline#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_pipeline#tags_all AwsPipeline#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * parallelism_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_pipeline#parallelism_configuration AwsPipeline#parallelism_configuration}
    */
    readonly parallelismConfiguration?: AwsPipeline.ParallelismConfigurationProperty;
    /**
    * pipeline_definition_s3_location block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_pipeline#pipeline_definition_s3_location AwsPipeline#pipeline_definition_s3_location}
    */
    readonly pipelineDefinitionS3Location?: AwsPipeline.PipelineDefinitionS3LocationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_pipeline aws_sagemaker_pipeline}
*/
export declare class AwsPipeline extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sagemaker_pipeline";
    /**
    * Generates CDKTN code for importing a AwsPipeline resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsPipeline to import
    * @param importFromId The id of the existing AwsPipeline that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_pipeline#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsPipeline to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_pipeline aws_sagemaker_pipeline} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsPipelineConfig
    */
    constructor(scope: Construct, id: string, config: AwsPipelineConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _pipelineDefinition?;
    get pipelineDefinition(): string;
    set pipelineDefinition(value: string);
    resetPipelineDefinition(): void;
    get pipelineDefinitionInput(): string | undefined;
    private _pipelineDescription?;
    get pipelineDescription(): string;
    set pipelineDescription(value: string);
    resetPipelineDescription(): void;
    get pipelineDescriptionInput(): string | undefined;
    private _pipelineDisplayName?;
    get pipelineDisplayName(): string;
    set pipelineDisplayName(value: string);
    get pipelineDisplayNameInput(): string | undefined;
    private _pipelineName?;
    get pipelineName(): string;
    set pipelineName(value: string);
    get pipelineNameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _roleArn?;
    get roleArn(): string;
    set roleArn(value: string);
    resetRoleArn(): void;
    get roleArnInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _parallelismConfiguration;
    get parallelismConfiguration(): AwsPipeline.ParallelismConfigurationPropertyOutputReference;
    putParallelismConfiguration(value: AwsPipeline.ParallelismConfigurationProperty): void;
    resetParallelismConfiguration(): void;
    get parallelismConfigurationInput(): AwsPipeline.ParallelismConfigurationProperty | undefined;
    private _pipelineDefinitionS3Location;
    get pipelineDefinitionS3Location(): AwsPipeline.PipelineDefinitionS3LocationPropertyOutputReference;
    putPipelineDefinitionS3Location(value: AwsPipeline.PipelineDefinitionS3LocationProperty): void;
    resetPipelineDefinitionS3Location(): void;
    get pipelineDefinitionS3LocationInput(): AwsPipeline.PipelineDefinitionS3LocationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsPipelineParallelismConfigurationPropertyToTerraform(struct?: AwsPipeline.ParallelismConfigurationPropertyOutputReference | AwsPipeline.ParallelismConfigurationProperty): any;
export declare function awsPipelineParallelismConfigurationPropertyToHclTerraform(struct?: AwsPipeline.ParallelismConfigurationPropertyOutputReference | AwsPipeline.ParallelismConfigurationProperty): any;
export declare function awsPipelinePipelineDefinitionS3LocationPropertyToTerraform(struct?: AwsPipeline.PipelineDefinitionS3LocationPropertyOutputReference | AwsPipeline.PipelineDefinitionS3LocationProperty): any;
export declare function awsPipelinePipelineDefinitionS3LocationPropertyToHclTerraform(struct?: AwsPipeline.PipelineDefinitionS3LocationPropertyOutputReference | AwsPipeline.PipelineDefinitionS3LocationProperty): any;
export declare namespace AwsPipeline {
    interface ParallelismConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_pipeline#max_parallel_execution_steps AwsPipeline#max_parallel_execution_steps}
        */
        readonly maxParallelExecutionSteps: number;
    }
    class ParallelismConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ParallelismConfigurationProperty | undefined;
        set internalValue(value: ParallelismConfigurationProperty | undefined);
        private _maxParallelExecutionSteps?;
        get maxParallelExecutionSteps(): number;
        set maxParallelExecutionSteps(value: number);
        get maxParallelExecutionStepsInput(): number | undefined;
    }
    interface PipelineDefinitionS3LocationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_pipeline#bucket AwsPipeline#bucket}
        */
        readonly bucket: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_pipeline#object_key AwsPipeline#object_key}
        */
        readonly objectKey: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_pipeline#version_id AwsPipeline#version_id}
        */
        readonly versionId?: string;
    }
    class PipelineDefinitionS3LocationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PipelineDefinitionS3LocationProperty | undefined;
        set internalValue(value: PipelineDefinitionS3LocationProperty | undefined);
        private _bucket?;
        get bucket(): string;
        set bucket(value: string);
        get bucketInput(): string | undefined;
        private _objectKey?;
        get objectKey(): string;
        set objectKey(value: string);
        get objectKeyInput(): string | undefined;
        private _versionId?;
        get versionId(): string;
        set versionId(value: string);
        resetVersionId(): void;
        get versionIdInput(): string | undefined;
    }
}
