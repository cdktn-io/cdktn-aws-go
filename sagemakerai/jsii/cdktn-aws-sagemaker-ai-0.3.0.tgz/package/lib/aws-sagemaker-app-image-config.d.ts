import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsAppImageConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#app_image_config_name AwsAppImageConfig#app_image_config_name}
    */
    readonly appImageConfigName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#id AwsAppImageConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#region AwsAppImageConfig#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#tags AwsAppImageConfig#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#tags_all AwsAppImageConfig#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * code_editor_app_image_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#code_editor_app_image_config AwsAppImageConfig#code_editor_app_image_config}
    */
    readonly codeEditorAppImageConfig?: AwsAppImageConfig.CodeEditorAppImageConfigProperty;
    /**
    * jupyter_lab_image_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#jupyter_lab_image_config AwsAppImageConfig#jupyter_lab_image_config}
    */
    readonly jupyterLabImageConfig?: AwsAppImageConfig.JupyterLabImageConfigProperty;
    /**
    * kernel_gateway_image_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#kernel_gateway_image_config AwsAppImageConfig#kernel_gateway_image_config}
    */
    readonly kernelGatewayImageConfig?: AwsAppImageConfig.KernelGatewayImageConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config aws_sagemaker_app_image_config}
*/
export declare class AwsAppImageConfig extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sagemaker_app_image_config";
    /**
    * Generates CDKTN code for importing a AwsAppImageConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsAppImageConfig to import
    * @param importFromId The id of the existing AwsAppImageConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsAppImageConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config aws_sagemaker_app_image_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsAppImageConfigConfig
    */
    constructor(scope: Construct, id: string, config: AwsAppImageConfigConfig);
    private _appImageConfigName?;
    get appImageConfigName(): string;
    set appImageConfigName(value: string);
    get appImageConfigNameInput(): string | undefined;
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _codeEditorAppImageConfig;
    get codeEditorAppImageConfig(): AwsAppImageConfig.CodeEditorAppImageConfigPropertyOutputReference;
    putCodeEditorAppImageConfig(value: AwsAppImageConfig.CodeEditorAppImageConfigProperty): void;
    resetCodeEditorAppImageConfig(): void;
    get codeEditorAppImageConfigInput(): AwsAppImageConfig.CodeEditorAppImageConfigProperty | undefined;
    private _jupyterLabImageConfig;
    get jupyterLabImageConfig(): AwsAppImageConfig.JupyterLabImageConfigPropertyOutputReference;
    putJupyterLabImageConfig(value: AwsAppImageConfig.JupyterLabImageConfigProperty): void;
    resetJupyterLabImageConfig(): void;
    get jupyterLabImageConfigInput(): AwsAppImageConfig.JupyterLabImageConfigProperty | undefined;
    private _kernelGatewayImageConfig;
    get kernelGatewayImageConfig(): AwsAppImageConfig.KernelGatewayImageConfigPropertyOutputReference;
    putKernelGatewayImageConfig(value: AwsAppImageConfig.KernelGatewayImageConfigProperty): void;
    resetKernelGatewayImageConfig(): void;
    get kernelGatewayImageConfigInput(): AwsAppImageConfig.KernelGatewayImageConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsAppImageConfigCodeEditorAppImageConfigContainerConfigPropertyToTerraform(struct?: AwsAppImageConfig.CodeEditorAppImageConfigContainerConfigPropertyOutputReference | AwsAppImageConfig.CodeEditorAppImageConfigContainerConfigProperty): any;
export declare function awsAppImageConfigCodeEditorAppImageConfigContainerConfigPropertyToHclTerraform(struct?: AwsAppImageConfig.CodeEditorAppImageConfigContainerConfigPropertyOutputReference | AwsAppImageConfig.CodeEditorAppImageConfigContainerConfigProperty): any;
export declare function awsAppImageConfigCodeEditorAppImageConfigFileSystemConfigPropertyToTerraform(struct?: AwsAppImageConfig.CodeEditorAppImageConfigFileSystemConfigPropertyOutputReference | AwsAppImageConfig.CodeEditorAppImageConfigFileSystemConfigProperty): any;
export declare function awsAppImageConfigCodeEditorAppImageConfigFileSystemConfigPropertyToHclTerraform(struct?: AwsAppImageConfig.CodeEditorAppImageConfigFileSystemConfigPropertyOutputReference | AwsAppImageConfig.CodeEditorAppImageConfigFileSystemConfigProperty): any;
export declare function awsAppImageConfigCodeEditorAppImageConfigPropertyToTerraform(struct?: AwsAppImageConfig.CodeEditorAppImageConfigPropertyOutputReference | AwsAppImageConfig.CodeEditorAppImageConfigProperty): any;
export declare function awsAppImageConfigCodeEditorAppImageConfigPropertyToHclTerraform(struct?: AwsAppImageConfig.CodeEditorAppImageConfigPropertyOutputReference | AwsAppImageConfig.CodeEditorAppImageConfigProperty): any;
export declare function awsAppImageConfigJupyterLabImageConfigContainerConfigPropertyToTerraform(struct?: AwsAppImageConfig.JupyterLabImageConfigContainerConfigPropertyOutputReference | AwsAppImageConfig.JupyterLabImageConfigContainerConfigProperty): any;
export declare function awsAppImageConfigJupyterLabImageConfigContainerConfigPropertyToHclTerraform(struct?: AwsAppImageConfig.JupyterLabImageConfigContainerConfigPropertyOutputReference | AwsAppImageConfig.JupyterLabImageConfigContainerConfigProperty): any;
export declare function awsAppImageConfigJupyterLabImageConfigFileSystemConfigPropertyToTerraform(struct?: AwsAppImageConfig.JupyterLabImageConfigFileSystemConfigPropertyOutputReference | AwsAppImageConfig.JupyterLabImageConfigFileSystemConfigProperty): any;
export declare function awsAppImageConfigJupyterLabImageConfigFileSystemConfigPropertyToHclTerraform(struct?: AwsAppImageConfig.JupyterLabImageConfigFileSystemConfigPropertyOutputReference | AwsAppImageConfig.JupyterLabImageConfigFileSystemConfigProperty): any;
export declare function awsAppImageConfigJupyterLabImageConfigPropertyToTerraform(struct?: AwsAppImageConfig.JupyterLabImageConfigPropertyOutputReference | AwsAppImageConfig.JupyterLabImageConfigProperty): any;
export declare function awsAppImageConfigJupyterLabImageConfigPropertyToHclTerraform(struct?: AwsAppImageConfig.JupyterLabImageConfigPropertyOutputReference | AwsAppImageConfig.JupyterLabImageConfigProperty): any;
export declare function awsAppImageConfigKernelGatewayImageConfigFileSystemConfigPropertyToTerraform(struct?: AwsAppImageConfig.KernelGatewayImageConfigFileSystemConfigPropertyOutputReference | AwsAppImageConfig.KernelGatewayImageConfigFileSystemConfigProperty): any;
export declare function awsAppImageConfigKernelGatewayImageConfigFileSystemConfigPropertyToHclTerraform(struct?: AwsAppImageConfig.KernelGatewayImageConfigFileSystemConfigPropertyOutputReference | AwsAppImageConfig.KernelGatewayImageConfigFileSystemConfigProperty): any;
export declare function awsAppImageConfigKernelSpecPropertyToTerraform(struct?: AwsAppImageConfig.KernelSpecProperty | cdktn.IResolvable): any;
export declare function awsAppImageConfigKernelSpecPropertyToHclTerraform(struct?: AwsAppImageConfig.KernelSpecProperty | cdktn.IResolvable): any;
export declare function awsAppImageConfigKernelGatewayImageConfigPropertyToTerraform(struct?: AwsAppImageConfig.KernelGatewayImageConfigPropertyOutputReference | AwsAppImageConfig.KernelGatewayImageConfigProperty): any;
export declare function awsAppImageConfigKernelGatewayImageConfigPropertyToHclTerraform(struct?: AwsAppImageConfig.KernelGatewayImageConfigPropertyOutputReference | AwsAppImageConfig.KernelGatewayImageConfigProperty): any;
export declare namespace AwsAppImageConfig {
    interface CodeEditorAppImageConfigContainerConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#container_arguments AwsAppImageConfig#container_arguments}
        */
        readonly containerArguments?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#container_entrypoint AwsAppImageConfig#container_entrypoint}
        */
        readonly containerEntrypoint?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#container_environment_variables AwsAppImageConfig#container_environment_variables}
        */
        readonly containerEnvironmentVariables?: {
            [key: string]: string;
        };
    }
    class CodeEditorAppImageConfigContainerConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CodeEditorAppImageConfigContainerConfigProperty | undefined;
        set internalValue(value: CodeEditorAppImageConfigContainerConfigProperty | undefined);
        private _containerArguments?;
        get containerArguments(): string[];
        set containerArguments(value: string[]);
        resetContainerArguments(): void;
        get containerArgumentsInput(): string[] | undefined;
        private _containerEntrypoint?;
        get containerEntrypoint(): string[];
        set containerEntrypoint(value: string[]);
        resetContainerEntrypoint(): void;
        get containerEntrypointInput(): string[] | undefined;
        private _containerEnvironmentVariables?;
        get containerEnvironmentVariables(): {
            [key: string]: string;
        };
        set containerEnvironmentVariables(value: {
            [key: string]: string;
        });
        resetContainerEnvironmentVariables(): void;
        get containerEnvironmentVariablesInput(): {
            [key: string]: string;
        } | undefined;
    }
    interface CodeEditorAppImageConfigFileSystemConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#default_gid AwsAppImageConfig#default_gid}
        */
        readonly defaultGid?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#default_uid AwsAppImageConfig#default_uid}
        */
        readonly defaultUid?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#mount_path AwsAppImageConfig#mount_path}
        */
        readonly mountPath?: string;
    }
    class CodeEditorAppImageConfigFileSystemConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CodeEditorAppImageConfigFileSystemConfigProperty | undefined;
        set internalValue(value: CodeEditorAppImageConfigFileSystemConfigProperty | undefined);
        private _defaultGid?;
        get defaultGid(): number;
        set defaultGid(value: number);
        resetDefaultGid(): void;
        get defaultGidInput(): number | undefined;
        private _defaultUid?;
        get defaultUid(): number;
        set defaultUid(value: number);
        resetDefaultUid(): void;
        get defaultUidInput(): number | undefined;
        private _mountPath?;
        get mountPath(): string;
        set mountPath(value: string);
        resetMountPath(): void;
        get mountPathInput(): string | undefined;
    }
    interface CodeEditorAppImageConfigProperty {
        /**
        * container_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#container_config AwsAppImageConfig#container_config}
        */
        readonly containerConfig?: CodeEditorAppImageConfigContainerConfigProperty;
        /**
        * file_system_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#file_system_config AwsAppImageConfig#file_system_config}
        */
        readonly fileSystemConfig?: CodeEditorAppImageConfigFileSystemConfigProperty;
    }
    class CodeEditorAppImageConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CodeEditorAppImageConfigProperty | undefined;
        set internalValue(value: CodeEditorAppImageConfigProperty | undefined);
        private _containerConfig;
        get containerConfig(): CodeEditorAppImageConfigContainerConfigPropertyOutputReference;
        putContainerConfig(value: CodeEditorAppImageConfigContainerConfigProperty): void;
        resetContainerConfig(): void;
        get containerConfigInput(): CodeEditorAppImageConfigContainerConfigProperty | undefined;
        private _fileSystemConfig;
        get fileSystemConfig(): CodeEditorAppImageConfigFileSystemConfigPropertyOutputReference;
        putFileSystemConfig(value: CodeEditorAppImageConfigFileSystemConfigProperty): void;
        resetFileSystemConfig(): void;
        get fileSystemConfigInput(): CodeEditorAppImageConfigFileSystemConfigProperty | undefined;
    }
    interface JupyterLabImageConfigContainerConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#container_arguments AwsAppImageConfig#container_arguments}
        */
        readonly containerArguments?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#container_entrypoint AwsAppImageConfig#container_entrypoint}
        */
        readonly containerEntrypoint?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#container_environment_variables AwsAppImageConfig#container_environment_variables}
        */
        readonly containerEnvironmentVariables?: {
            [key: string]: string;
        };
    }
    class JupyterLabImageConfigContainerConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): JupyterLabImageConfigContainerConfigProperty | undefined;
        set internalValue(value: JupyterLabImageConfigContainerConfigProperty | undefined);
        private _containerArguments?;
        get containerArguments(): string[];
        set containerArguments(value: string[]);
        resetContainerArguments(): void;
        get containerArgumentsInput(): string[] | undefined;
        private _containerEntrypoint?;
        get containerEntrypoint(): string[];
        set containerEntrypoint(value: string[]);
        resetContainerEntrypoint(): void;
        get containerEntrypointInput(): string[] | undefined;
        private _containerEnvironmentVariables?;
        get containerEnvironmentVariables(): {
            [key: string]: string;
        };
        set containerEnvironmentVariables(value: {
            [key: string]: string;
        });
        resetContainerEnvironmentVariables(): void;
        get containerEnvironmentVariablesInput(): {
            [key: string]: string;
        } | undefined;
    }
    interface JupyterLabImageConfigFileSystemConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#default_gid AwsAppImageConfig#default_gid}
        */
        readonly defaultGid?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#default_uid AwsAppImageConfig#default_uid}
        */
        readonly defaultUid?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#mount_path AwsAppImageConfig#mount_path}
        */
        readonly mountPath?: string;
    }
    class JupyterLabImageConfigFileSystemConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): JupyterLabImageConfigFileSystemConfigProperty | undefined;
        set internalValue(value: JupyterLabImageConfigFileSystemConfigProperty | undefined);
        private _defaultGid?;
        get defaultGid(): number;
        set defaultGid(value: number);
        resetDefaultGid(): void;
        get defaultGidInput(): number | undefined;
        private _defaultUid?;
        get defaultUid(): number;
        set defaultUid(value: number);
        resetDefaultUid(): void;
        get defaultUidInput(): number | undefined;
        private _mountPath?;
        get mountPath(): string;
        set mountPath(value: string);
        resetMountPath(): void;
        get mountPathInput(): string | undefined;
    }
    interface JupyterLabImageConfigProperty {
        /**
        * container_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#container_config AwsAppImageConfig#container_config}
        */
        readonly containerConfig?: JupyterLabImageConfigContainerConfigProperty;
        /**
        * file_system_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#file_system_config AwsAppImageConfig#file_system_config}
        */
        readonly fileSystemConfig?: JupyterLabImageConfigFileSystemConfigProperty;
    }
    class JupyterLabImageConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): JupyterLabImageConfigProperty | undefined;
        set internalValue(value: JupyterLabImageConfigProperty | undefined);
        private _containerConfig;
        get containerConfig(): JupyterLabImageConfigContainerConfigPropertyOutputReference;
        putContainerConfig(value: JupyterLabImageConfigContainerConfigProperty): void;
        resetContainerConfig(): void;
        get containerConfigInput(): JupyterLabImageConfigContainerConfigProperty | undefined;
        private _fileSystemConfig;
        get fileSystemConfig(): JupyterLabImageConfigFileSystemConfigPropertyOutputReference;
        putFileSystemConfig(value: JupyterLabImageConfigFileSystemConfigProperty): void;
        resetFileSystemConfig(): void;
        get fileSystemConfigInput(): JupyterLabImageConfigFileSystemConfigProperty | undefined;
    }
    interface KernelGatewayImageConfigFileSystemConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#default_gid AwsAppImageConfig#default_gid}
        */
        readonly defaultGid?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#default_uid AwsAppImageConfig#default_uid}
        */
        readonly defaultUid?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#mount_path AwsAppImageConfig#mount_path}
        */
        readonly mountPath?: string;
    }
    class KernelGatewayImageConfigFileSystemConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KernelGatewayImageConfigFileSystemConfigProperty | undefined;
        set internalValue(value: KernelGatewayImageConfigFileSystemConfigProperty | undefined);
        private _defaultGid?;
        get defaultGid(): number;
        set defaultGid(value: number);
        resetDefaultGid(): void;
        get defaultGidInput(): number | undefined;
        private _defaultUid?;
        get defaultUid(): number;
        set defaultUid(value: number);
        resetDefaultUid(): void;
        get defaultUidInput(): number | undefined;
        private _mountPath?;
        get mountPath(): string;
        set mountPath(value: string);
        resetMountPath(): void;
        get mountPathInput(): string | undefined;
    }
    interface KernelSpecProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#display_name AwsAppImageConfig#display_name}
        */
        readonly displayName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#name AwsAppImageConfig#name}
        */
        readonly name: string;
    }
    class KernelSpecPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): KernelSpecProperty | cdktn.IResolvable | undefined;
        set internalValue(value: KernelSpecProperty | cdktn.IResolvable | undefined);
        private _displayName?;
        get displayName(): string;
        set displayName(value: string);
        resetDisplayName(): void;
        get displayNameInput(): string | undefined;
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
    }
    class KernelSpecPropertyList extends cdktn.ComplexList {
        internalValue?: KernelSpecProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): KernelSpecPropertyOutputReference;
    }
    interface KernelGatewayImageConfigProperty {
        /**
        * file_system_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#file_system_config AwsAppImageConfig#file_system_config}
        */
        readonly fileSystemConfig?: KernelGatewayImageConfigFileSystemConfigProperty;
        /**
        * kernel_spec block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_app_image_config#kernel_spec AwsAppImageConfig#kernel_spec}
        */
        readonly kernelSpec: KernelSpecProperty[] | cdktn.IResolvable;
    }
    class KernelGatewayImageConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): KernelGatewayImageConfigProperty | undefined;
        set internalValue(value: KernelGatewayImageConfigProperty | undefined);
        private _fileSystemConfig;
        get fileSystemConfig(): KernelGatewayImageConfigFileSystemConfigPropertyOutputReference;
        putFileSystemConfig(value: KernelGatewayImageConfigFileSystemConfigProperty): void;
        resetFileSystemConfig(): void;
        get fileSystemConfigInput(): KernelGatewayImageConfigFileSystemConfigProperty | undefined;
        private _kernelSpec;
        get kernelSpec(): KernelSpecPropertyList;
        putKernelSpec(value: KernelSpecProperty[] | cdktn.IResolvable): void;
        get kernelSpecInput(): cdktn.IResolvable | KernelSpecProperty[] | undefined;
    }
}
