import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsWorkforceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#id AwsWorkforce#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#region AwsWorkforce#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#workforce_name AwsWorkforce#workforce_name}
    */
    readonly workforceName: string;
    /**
    * cognito_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#cognito_config AwsWorkforce#cognito_config}
    */
    readonly cognitoConfig?: AwsWorkforce.CognitoConfigProperty;
    /**
    * oidc_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#oidc_config AwsWorkforce#oidc_config}
    */
    readonly oidcConfig?: AwsWorkforce.OidcConfigProperty;
    /**
    * source_ip_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#source_ip_config AwsWorkforce#source_ip_config}
    */
    readonly sourceIpConfig?: AwsWorkforce.SourceIpConfigProperty;
    /**
    * workforce_vpc_config block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#workforce_vpc_config AwsWorkforce#workforce_vpc_config}
    */
    readonly workforceVpcConfig?: AwsWorkforce.WorkforceVpcConfigProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce aws_sagemaker_workforce}
*/
export declare class AwsWorkforce extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_sagemaker_workforce";
    /**
    * Generates CDKTN code for importing a AwsWorkforce resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsWorkforce to import
    * @param importFromId The id of the existing AwsWorkforce that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsWorkforce to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce aws_sagemaker_workforce} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsWorkforceConfig
    */
    constructor(scope: Construct, id: string, config: AwsWorkforceConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get subdomain(): string;
    private _workforceName?;
    get workforceName(): string;
    set workforceName(value: string);
    get workforceNameInput(): string | undefined;
    private _cognitoConfig;
    get cognitoConfig(): AwsWorkforce.CognitoConfigPropertyOutputReference;
    putCognitoConfig(value: AwsWorkforce.CognitoConfigProperty): void;
    resetCognitoConfig(): void;
    get cognitoConfigInput(): AwsWorkforce.CognitoConfigProperty | undefined;
    private _oidcConfig;
    get oidcConfig(): AwsWorkforce.OidcConfigPropertyOutputReference;
    putOidcConfig(value: AwsWorkforce.OidcConfigProperty): void;
    resetOidcConfig(): void;
    get oidcConfigInput(): AwsWorkforce.OidcConfigProperty | undefined;
    private _sourceIpConfig;
    get sourceIpConfig(): AwsWorkforce.SourceIpConfigPropertyOutputReference;
    putSourceIpConfig(value: AwsWorkforce.SourceIpConfigProperty): void;
    resetSourceIpConfig(): void;
    get sourceIpConfigInput(): AwsWorkforce.SourceIpConfigProperty | undefined;
    private _workforceVpcConfig;
    get workforceVpcConfig(): AwsWorkforce.WorkforceVpcConfigPropertyOutputReference;
    putWorkforceVpcConfig(value: AwsWorkforce.WorkforceVpcConfigProperty): void;
    resetWorkforceVpcConfig(): void;
    get workforceVpcConfigInput(): AwsWorkforce.WorkforceVpcConfigProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsWorkforceCognitoConfigPropertyToTerraform(struct?: AwsWorkforce.CognitoConfigPropertyOutputReference | AwsWorkforce.CognitoConfigProperty): any;
export declare function awsWorkforceCognitoConfigPropertyToHclTerraform(struct?: AwsWorkforce.CognitoConfigPropertyOutputReference | AwsWorkforce.CognitoConfigProperty): any;
export declare function awsWorkforceOidcConfigPropertyToTerraform(struct?: AwsWorkforce.OidcConfigPropertyOutputReference | AwsWorkforce.OidcConfigProperty): any;
export declare function awsWorkforceOidcConfigPropertyToHclTerraform(struct?: AwsWorkforce.OidcConfigPropertyOutputReference | AwsWorkforce.OidcConfigProperty): any;
export declare function awsWorkforceSourceIpConfigPropertyToTerraform(struct?: AwsWorkforce.SourceIpConfigPropertyOutputReference | AwsWorkforce.SourceIpConfigProperty): any;
export declare function awsWorkforceSourceIpConfigPropertyToHclTerraform(struct?: AwsWorkforce.SourceIpConfigPropertyOutputReference | AwsWorkforce.SourceIpConfigProperty): any;
export declare function awsWorkforceWorkforceVpcConfigPropertyToTerraform(struct?: AwsWorkforce.WorkforceVpcConfigPropertyOutputReference | AwsWorkforce.WorkforceVpcConfigProperty): any;
export declare function awsWorkforceWorkforceVpcConfigPropertyToHclTerraform(struct?: AwsWorkforce.WorkforceVpcConfigPropertyOutputReference | AwsWorkforce.WorkforceVpcConfigProperty): any;
export declare namespace AwsWorkforce {
    interface CognitoConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#client_id AwsWorkforce#client_id}
        */
        readonly clientId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#user_pool AwsWorkforce#user_pool}
        */
        readonly userPool: string;
    }
    class CognitoConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CognitoConfigProperty | undefined;
        set internalValue(value: CognitoConfigProperty | undefined);
        private _clientId?;
        get clientId(): string;
        set clientId(value: string);
        get clientIdInput(): string | undefined;
        private _userPool?;
        get userPool(): string;
        set userPool(value: string);
        get userPoolInput(): string | undefined;
    }
    interface OidcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#authentication_request_extra_params AwsWorkforce#authentication_request_extra_params}
        */
        readonly authenticationRequestExtraParams?: {
            [key: string]: string;
        };
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#authorization_endpoint AwsWorkforce#authorization_endpoint}
        */
        readonly authorizationEndpoint: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#client_id AwsWorkforce#client_id}
        */
        readonly clientId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#client_secret AwsWorkforce#client_secret}
        */
        readonly clientSecret: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#issuer AwsWorkforce#issuer}
        */
        readonly issuer: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#jwks_uri AwsWorkforce#jwks_uri}
        */
        readonly jwksUri: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#logout_endpoint AwsWorkforce#logout_endpoint}
        */
        readonly logoutEndpoint: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#scope AwsWorkforce#scope}
        */
        readonly scope?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#token_endpoint AwsWorkforce#token_endpoint}
        */
        readonly tokenEndpoint: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#user_info_endpoint AwsWorkforce#user_info_endpoint}
        */
        readonly userInfoEndpoint: string;
    }
    class OidcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): OidcConfigProperty | undefined;
        set internalValue(value: OidcConfigProperty | undefined);
        private _authenticationRequestExtraParams?;
        get authenticationRequestExtraParams(): {
            [key: string]: string;
        };
        set authenticationRequestExtraParams(value: {
            [key: string]: string;
        });
        resetAuthenticationRequestExtraParams(): void;
        get authenticationRequestExtraParamsInput(): {
            [key: string]: string;
        } | undefined;
        private _authorizationEndpoint?;
        get authorizationEndpoint(): string;
        set authorizationEndpoint(value: string);
        get authorizationEndpointInput(): string | undefined;
        private _clientId?;
        get clientId(): string;
        set clientId(value: string);
        get clientIdInput(): string | undefined;
        private _clientSecret?;
        get clientSecret(): string;
        set clientSecret(value: string);
        get clientSecretInput(): string | undefined;
        private _issuer?;
        get issuer(): string;
        set issuer(value: string);
        get issuerInput(): string | undefined;
        private _jwksUri?;
        get jwksUri(): string;
        set jwksUri(value: string);
        get jwksUriInput(): string | undefined;
        private _logoutEndpoint?;
        get logoutEndpoint(): string;
        set logoutEndpoint(value: string);
        get logoutEndpointInput(): string | undefined;
        private _scope?;
        get scope(): string;
        set scope(value: string);
        resetScope(): void;
        get scopeInput(): string | undefined;
        private _tokenEndpoint?;
        get tokenEndpoint(): string;
        set tokenEndpoint(value: string);
        get tokenEndpointInput(): string | undefined;
        private _userInfoEndpoint?;
        get userInfoEndpoint(): string;
        set userInfoEndpoint(value: string);
        get userInfoEndpointInput(): string | undefined;
    }
    interface SourceIpConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#cidrs AwsWorkforce#cidrs}
        */
        readonly cidrs: string[];
    }
    class SourceIpConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SourceIpConfigProperty | undefined;
        set internalValue(value: SourceIpConfigProperty | undefined);
        private _cidrs?;
        get cidrs(): string[];
        set cidrs(value: string[]);
        get cidrsInput(): string[] | undefined;
    }
    interface WorkforceVpcConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#security_group_ids AwsWorkforce#security_group_ids}
        */
        readonly securityGroupIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#subnets AwsWorkforce#subnets}
        */
        readonly subnets?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/sagemaker_workforce#vpc_id AwsWorkforce#vpc_id}
        */
        readonly vpcId?: string;
    }
    class WorkforceVpcConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): WorkforceVpcConfigProperty | undefined;
        set internalValue(value: WorkforceVpcConfigProperty | undefined);
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        resetSecurityGroupIds(): void;
        get securityGroupIdsInput(): string[] | undefined;
        private _subnets?;
        get subnets(): string[];
        set subnets(value: string[]);
        resetSubnets(): void;
        get subnetsInput(): string[] | undefined;
        get vpcEndpointId(): string;
        private _vpcId?;
        get vpcId(): string;
        set vpcId(value: string);
        resetVpcId(): void;
        get vpcIdInput(): string | undefined;
    }
}
