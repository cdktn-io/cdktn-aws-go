import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfApplicationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#architecture TfApplication#architecture}
    */
    readonly architecture?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#id TfApplication#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#name TfApplication#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#region TfApplication#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#release_label TfApplication#release_label}
    */
    readonly releaseLabel: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#tags TfApplication#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#tags_all TfApplication#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#type TfApplication#type}
    */
    readonly type: string;
    /**
    * auto_start_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#auto_start_configuration TfApplication#auto_start_configuration}
    */
    readonly autoStartConfiguration?: TfApplication.AutoStartConfigurationProperty;
    /**
    * auto_stop_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#auto_stop_configuration TfApplication#auto_stop_configuration}
    */
    readonly autoStopConfiguration?: TfApplication.AutoStopConfigurationProperty;
    /**
    * image_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#image_configuration TfApplication#image_configuration}
    */
    readonly imageConfiguration?: TfApplication.ImageConfigurationProperty;
    /**
    * initial_capacity block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#initial_capacity TfApplication#initial_capacity}
    */
    readonly initialCapacity?: TfApplication.InitialCapacityProperty[] | cdktn.IResolvable;
    /**
    * interactive_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#interactive_configuration TfApplication#interactive_configuration}
    */
    readonly interactiveConfiguration?: TfApplication.InteractiveConfigurationProperty;
    /**
    * job_level_cost_allocation_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#job_level_cost_allocation_configuration TfApplication#job_level_cost_allocation_configuration}
    */
    readonly jobLevelCostAllocationConfiguration?: TfApplication.JobLevelCostAllocationConfigurationProperty;
    /**
    * maximum_capacity block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#maximum_capacity TfApplication#maximum_capacity}
    */
    readonly maximumCapacity?: TfApplication.MaximumCapacityProperty;
    /**
    * monitoring_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#monitoring_configuration TfApplication#monitoring_configuration}
    */
    readonly monitoringConfiguration?: TfApplication.MonitoringConfigurationProperty;
    /**
    * network_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#network_configuration TfApplication#network_configuration}
    */
    readonly networkConfiguration?: TfApplication.NetworkConfigurationProperty;
    /**
    * runtime_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#runtime_configuration TfApplication#runtime_configuration}
    */
    readonly runtimeConfiguration?: TfApplication.RuntimeConfigurationProperty[] | cdktn.IResolvable;
    /**
    * scheduler_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#scheduler_configuration TfApplication#scheduler_configuration}
    */
    readonly schedulerConfiguration?: TfApplication.SchedulerConfigurationProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application aws_emrserverless_application}
*/
export declare class TfApplication extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_emrserverless_application";
    /**
    * Generates CDKTN code for importing a TfApplication resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfApplication to import
    * @param importFromId The id of the existing TfApplication that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfApplication to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application aws_emrserverless_application} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfApplicationConfig
    */
    constructor(scope: Construct, id: string, config: TfApplicationConfig);
    private _architecture?;
    get architecture(): string;
    set architecture(value: string);
    resetArchitecture(): void;
    get architectureInput(): string | undefined;
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _releaseLabel?;
    get releaseLabel(): string;
    set releaseLabel(value: string);
    get releaseLabelInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _autoStartConfiguration;
    get autoStartConfiguration(): TfApplication.AutoStartConfigurationPropertyOutputReference;
    putAutoStartConfiguration(value: TfApplication.AutoStartConfigurationProperty): void;
    resetAutoStartConfiguration(): void;
    get autoStartConfigurationInput(): TfApplication.AutoStartConfigurationProperty | undefined;
    private _autoStopConfiguration;
    get autoStopConfiguration(): TfApplication.AutoStopConfigurationPropertyOutputReference;
    putAutoStopConfiguration(value: TfApplication.AutoStopConfigurationProperty): void;
    resetAutoStopConfiguration(): void;
    get autoStopConfigurationInput(): TfApplication.AutoStopConfigurationProperty | undefined;
    private _imageConfiguration;
    get imageConfiguration(): TfApplication.ImageConfigurationPropertyOutputReference;
    putImageConfiguration(value: TfApplication.ImageConfigurationProperty): void;
    resetImageConfiguration(): void;
    get imageConfigurationInput(): TfApplication.ImageConfigurationProperty | undefined;
    private _initialCapacity;
    get initialCapacity(): TfApplication.InitialCapacityPropertyList;
    putInitialCapacity(value: TfApplication.InitialCapacityProperty[] | cdktn.IResolvable): void;
    resetInitialCapacity(): void;
    get initialCapacityInput(): cdktn.IResolvable | TfApplication.InitialCapacityProperty[] | undefined;
    private _interactiveConfiguration;
    get interactiveConfiguration(): TfApplication.InteractiveConfigurationPropertyOutputReference;
    putInteractiveConfiguration(value: TfApplication.InteractiveConfigurationProperty): void;
    resetInteractiveConfiguration(): void;
    get interactiveConfigurationInput(): TfApplication.InteractiveConfigurationProperty | undefined;
    private _jobLevelCostAllocationConfiguration;
    get jobLevelCostAllocationConfiguration(): TfApplication.JobLevelCostAllocationConfigurationPropertyOutputReference;
    putJobLevelCostAllocationConfiguration(value: TfApplication.JobLevelCostAllocationConfigurationProperty): void;
    resetJobLevelCostAllocationConfiguration(): void;
    get jobLevelCostAllocationConfigurationInput(): TfApplication.JobLevelCostAllocationConfigurationProperty | undefined;
    private _maximumCapacity;
    get maximumCapacity(): TfApplication.MaximumCapacityPropertyOutputReference;
    putMaximumCapacity(value: TfApplication.MaximumCapacityProperty): void;
    resetMaximumCapacity(): void;
    get maximumCapacityInput(): TfApplication.MaximumCapacityProperty | undefined;
    private _monitoringConfiguration;
    get monitoringConfiguration(): TfApplication.MonitoringConfigurationPropertyOutputReference;
    putMonitoringConfiguration(value: TfApplication.MonitoringConfigurationProperty): void;
    resetMonitoringConfiguration(): void;
    get monitoringConfigurationInput(): TfApplication.MonitoringConfigurationProperty | undefined;
    private _networkConfiguration;
    get networkConfiguration(): TfApplication.NetworkConfigurationPropertyOutputReference;
    putNetworkConfiguration(value: TfApplication.NetworkConfigurationProperty): void;
    resetNetworkConfiguration(): void;
    get networkConfigurationInput(): TfApplication.NetworkConfigurationProperty | undefined;
    private _runtimeConfiguration;
    get runtimeConfiguration(): TfApplication.RuntimeConfigurationPropertyList;
    putRuntimeConfiguration(value: TfApplication.RuntimeConfigurationProperty[] | cdktn.IResolvable): void;
    resetRuntimeConfiguration(): void;
    get runtimeConfigurationInput(): cdktn.IResolvable | TfApplication.RuntimeConfigurationProperty[] | undefined;
    private _schedulerConfiguration;
    get schedulerConfiguration(): TfApplication.SchedulerConfigurationPropertyOutputReference;
    putSchedulerConfiguration(value: TfApplication.SchedulerConfigurationProperty): void;
    resetSchedulerConfiguration(): void;
    get schedulerConfigurationInput(): TfApplication.SchedulerConfigurationProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfApplicationAutoStartConfigurationPropertyToTerraform(struct?: TfApplication.AutoStartConfigurationPropertyOutputReference | TfApplication.AutoStartConfigurationProperty): any;
export declare function tfApplicationAutoStartConfigurationPropertyToHclTerraform(struct?: TfApplication.AutoStartConfigurationPropertyOutputReference | TfApplication.AutoStartConfigurationProperty): any;
export declare function tfApplicationAutoStopConfigurationPropertyToTerraform(struct?: TfApplication.AutoStopConfigurationPropertyOutputReference | TfApplication.AutoStopConfigurationProperty): any;
export declare function tfApplicationAutoStopConfigurationPropertyToHclTerraform(struct?: TfApplication.AutoStopConfigurationPropertyOutputReference | TfApplication.AutoStopConfigurationProperty): any;
export declare function tfApplicationImageConfigurationPropertyToTerraform(struct?: TfApplication.ImageConfigurationPropertyOutputReference | TfApplication.ImageConfigurationProperty): any;
export declare function tfApplicationImageConfigurationPropertyToHclTerraform(struct?: TfApplication.ImageConfigurationPropertyOutputReference | TfApplication.ImageConfigurationProperty): any;
export declare function tfApplicationWorkerConfigurationPropertyToTerraform(struct?: TfApplication.WorkerConfigurationPropertyOutputReference | TfApplication.WorkerConfigurationProperty): any;
export declare function tfApplicationWorkerConfigurationPropertyToHclTerraform(struct?: TfApplication.WorkerConfigurationPropertyOutputReference | TfApplication.WorkerConfigurationProperty): any;
export declare function tfApplicationInitialCapacityConfigPropertyToTerraform(struct?: TfApplication.InitialCapacityConfigPropertyOutputReference | TfApplication.InitialCapacityConfigProperty): any;
export declare function tfApplicationInitialCapacityConfigPropertyToHclTerraform(struct?: TfApplication.InitialCapacityConfigPropertyOutputReference | TfApplication.InitialCapacityConfigProperty): any;
export declare function tfApplicationInitialCapacityPropertyToTerraform(struct?: TfApplication.InitialCapacityProperty | cdktn.IResolvable): any;
export declare function tfApplicationInitialCapacityPropertyToHclTerraform(struct?: TfApplication.InitialCapacityProperty | cdktn.IResolvable): any;
export declare function tfApplicationInteractiveConfigurationPropertyToTerraform(struct?: TfApplication.InteractiveConfigurationPropertyOutputReference | TfApplication.InteractiveConfigurationProperty): any;
export declare function tfApplicationInteractiveConfigurationPropertyToHclTerraform(struct?: TfApplication.InteractiveConfigurationPropertyOutputReference | TfApplication.InteractiveConfigurationProperty): any;
export declare function tfApplicationJobLevelCostAllocationConfigurationPropertyToTerraform(struct?: TfApplication.JobLevelCostAllocationConfigurationPropertyOutputReference | TfApplication.JobLevelCostAllocationConfigurationProperty): any;
export declare function tfApplicationJobLevelCostAllocationConfigurationPropertyToHclTerraform(struct?: TfApplication.JobLevelCostAllocationConfigurationPropertyOutputReference | TfApplication.JobLevelCostAllocationConfigurationProperty): any;
export declare function tfApplicationMaximumCapacityPropertyToTerraform(struct?: TfApplication.MaximumCapacityPropertyOutputReference | TfApplication.MaximumCapacityProperty): any;
export declare function tfApplicationMaximumCapacityPropertyToHclTerraform(struct?: TfApplication.MaximumCapacityPropertyOutputReference | TfApplication.MaximumCapacityProperty): any;
export declare function tfApplicationLogTypesPropertyToTerraform(struct?: TfApplication.LogTypesProperty | cdktn.IResolvable): any;
export declare function tfApplicationLogTypesPropertyToHclTerraform(struct?: TfApplication.LogTypesProperty | cdktn.IResolvable): any;
export declare function tfApplicationCloudwatchLoggingConfigurationPropertyToTerraform(struct?: TfApplication.CloudwatchLoggingConfigurationPropertyOutputReference | TfApplication.CloudwatchLoggingConfigurationProperty): any;
export declare function tfApplicationCloudwatchLoggingConfigurationPropertyToHclTerraform(struct?: TfApplication.CloudwatchLoggingConfigurationPropertyOutputReference | TfApplication.CloudwatchLoggingConfigurationProperty): any;
export declare function tfApplicationManagedPersistenceMonitoringConfigurationPropertyToTerraform(struct?: TfApplication.ManagedPersistenceMonitoringConfigurationPropertyOutputReference | TfApplication.ManagedPersistenceMonitoringConfigurationProperty): any;
export declare function tfApplicationManagedPersistenceMonitoringConfigurationPropertyToHclTerraform(struct?: TfApplication.ManagedPersistenceMonitoringConfigurationPropertyOutputReference | TfApplication.ManagedPersistenceMonitoringConfigurationProperty): any;
export declare function tfApplicationPrometheusMonitoringConfigurationPropertyToTerraform(struct?: TfApplication.PrometheusMonitoringConfigurationPropertyOutputReference | TfApplication.PrometheusMonitoringConfigurationProperty): any;
export declare function tfApplicationPrometheusMonitoringConfigurationPropertyToHclTerraform(struct?: TfApplication.PrometheusMonitoringConfigurationPropertyOutputReference | TfApplication.PrometheusMonitoringConfigurationProperty): any;
export declare function tfApplicationS3MonitoringConfigurationPropertyToTerraform(struct?: TfApplication.S3MonitoringConfigurationPropertyOutputReference | TfApplication.S3MonitoringConfigurationProperty): any;
export declare function tfApplicationS3MonitoringConfigurationPropertyToHclTerraform(struct?: TfApplication.S3MonitoringConfigurationPropertyOutputReference | TfApplication.S3MonitoringConfigurationProperty): any;
export declare function tfApplicationMonitoringConfigurationPropertyToTerraform(struct?: TfApplication.MonitoringConfigurationPropertyOutputReference | TfApplication.MonitoringConfigurationProperty): any;
export declare function tfApplicationMonitoringConfigurationPropertyToHclTerraform(struct?: TfApplication.MonitoringConfigurationPropertyOutputReference | TfApplication.MonitoringConfigurationProperty): any;
export declare function tfApplicationNetworkConfigurationPropertyToTerraform(struct?: TfApplication.NetworkConfigurationPropertyOutputReference | TfApplication.NetworkConfigurationProperty): any;
export declare function tfApplicationNetworkConfigurationPropertyToHclTerraform(struct?: TfApplication.NetworkConfigurationPropertyOutputReference | TfApplication.NetworkConfigurationProperty): any;
export declare function tfApplicationRuntimeConfigurationPropertyToTerraform(struct?: TfApplication.RuntimeConfigurationProperty | cdktn.IResolvable): any;
export declare function tfApplicationRuntimeConfigurationPropertyToHclTerraform(struct?: TfApplication.RuntimeConfigurationProperty | cdktn.IResolvable): any;
export declare function tfApplicationSchedulerConfigurationPropertyToTerraform(struct?: TfApplication.SchedulerConfigurationPropertyOutputReference | TfApplication.SchedulerConfigurationProperty): any;
export declare function tfApplicationSchedulerConfigurationPropertyToHclTerraform(struct?: TfApplication.SchedulerConfigurationPropertyOutputReference | TfApplication.SchedulerConfigurationProperty): any;
export declare namespace TfApplication {
    interface AutoStartConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#enabled TfApplication#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class AutoStartConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AutoStartConfigurationProperty | undefined;
        set internalValue(value: AutoStartConfigurationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface AutoStopConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#enabled TfApplication#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#idle_timeout_minutes TfApplication#idle_timeout_minutes}
        */
        readonly idleTimeoutMinutes?: number;
    }
    class AutoStopConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): AutoStopConfigurationProperty | undefined;
        set internalValue(value: AutoStopConfigurationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _idleTimeoutMinutes?;
        get idleTimeoutMinutes(): number;
        set idleTimeoutMinutes(value: number);
        resetIdleTimeoutMinutes(): void;
        get idleTimeoutMinutesInput(): number | undefined;
    }
    interface ImageConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#image_uri TfApplication#image_uri}
        */
        readonly imageUri: string;
    }
    class ImageConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ImageConfigurationProperty | undefined;
        set internalValue(value: ImageConfigurationProperty | undefined);
        private _imageUri?;
        get imageUri(): string;
        set imageUri(value: string);
        get imageUriInput(): string | undefined;
    }
    interface WorkerConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#cpu TfApplication#cpu}
        */
        readonly cpu: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#disk TfApplication#disk}
        */
        readonly disk?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#memory TfApplication#memory}
        */
        readonly memory: string;
    }
    class WorkerConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): WorkerConfigurationProperty | undefined;
        set internalValue(value: WorkerConfigurationProperty | undefined);
        private _cpu?;
        get cpu(): string;
        set cpu(value: string);
        get cpuInput(): string | undefined;
        private _disk?;
        get disk(): string;
        set disk(value: string);
        resetDisk(): void;
        get diskInput(): string | undefined;
        private _memory?;
        get memory(): string;
        set memory(value: string);
        get memoryInput(): string | undefined;
    }
    interface InitialCapacityConfigProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#worker_count TfApplication#worker_count}
        */
        readonly workerCount: number;
        /**
        * worker_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#worker_configuration TfApplication#worker_configuration}
        */
        readonly workerConfiguration?: WorkerConfigurationProperty;
    }
    class InitialCapacityConfigPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InitialCapacityConfigProperty | undefined;
        set internalValue(value: InitialCapacityConfigProperty | undefined);
        private _workerCount?;
        get workerCount(): number;
        set workerCount(value: number);
        get workerCountInput(): number | undefined;
        private _workerConfiguration;
        get workerConfiguration(): WorkerConfigurationPropertyOutputReference;
        putWorkerConfiguration(value: WorkerConfigurationProperty): void;
        resetWorkerConfiguration(): void;
        get workerConfigurationInput(): WorkerConfigurationProperty | undefined;
    }
    interface InitialCapacityProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#initial_capacity_type TfApplication#initial_capacity_type}
        */
        readonly initialCapacityType: string;
        /**
        * initial_capacity_config block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#initial_capacity_config TfApplication#initial_capacity_config}
        */
        readonly initialCapacityConfig?: InitialCapacityConfigProperty;
    }
    class InitialCapacityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): InitialCapacityProperty | cdktn.IResolvable | undefined;
        set internalValue(value: InitialCapacityProperty | cdktn.IResolvable | undefined);
        private _initialCapacityType?;
        get initialCapacityType(): string;
        set initialCapacityType(value: string);
        get initialCapacityTypeInput(): string | undefined;
        private _initialCapacityConfig;
        get initialCapacityConfig(): InitialCapacityConfigPropertyOutputReference;
        putInitialCapacityConfig(value: InitialCapacityConfigProperty): void;
        resetInitialCapacityConfig(): void;
        get initialCapacityConfigInput(): InitialCapacityConfigProperty | undefined;
    }
    class InitialCapacityPropertyList extends cdktn.ComplexList {
        internalValue?: InitialCapacityProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): InitialCapacityPropertyOutputReference;
    }
    interface InteractiveConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#livy_endpoint_enabled TfApplication#livy_endpoint_enabled}
        */
        readonly livyEndpointEnabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#studio_enabled TfApplication#studio_enabled}
        */
        readonly studioEnabled?: boolean | cdktn.IResolvable;
    }
    class InteractiveConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): InteractiveConfigurationProperty | undefined;
        set internalValue(value: InteractiveConfigurationProperty | undefined);
        private _livyEndpointEnabled?;
        get livyEndpointEnabled(): boolean | cdktn.IResolvable;
        set livyEndpointEnabled(value: boolean | cdktn.IResolvable);
        resetLivyEndpointEnabled(): void;
        get livyEndpointEnabledInput(): boolean | cdktn.IResolvable | undefined;
        private _studioEnabled?;
        get studioEnabled(): boolean | cdktn.IResolvable;
        set studioEnabled(value: boolean | cdktn.IResolvable);
        resetStudioEnabled(): void;
        get studioEnabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface JobLevelCostAllocationConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#enabled TfApplication#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
    }
    class JobLevelCostAllocationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): JobLevelCostAllocationConfigurationProperty | undefined;
        set internalValue(value: JobLevelCostAllocationConfigurationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
    }
    interface MaximumCapacityProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#cpu TfApplication#cpu}
        */
        readonly cpu: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#disk TfApplication#disk}
        */
        readonly disk?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#memory TfApplication#memory}
        */
        readonly memory: string;
    }
    class MaximumCapacityPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MaximumCapacityProperty | undefined;
        set internalValue(value: MaximumCapacityProperty | undefined);
        private _cpu?;
        get cpu(): string;
        set cpu(value: string);
        get cpuInput(): string | undefined;
        private _disk?;
        get disk(): string;
        set disk(value: string);
        resetDisk(): void;
        get diskInput(): string | undefined;
        private _memory?;
        get memory(): string;
        set memory(value: string);
        get memoryInput(): string | undefined;
    }
    interface LogTypesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#name TfApplication#name}
        */
        readonly name: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#values TfApplication#values}
        */
        readonly values: string[];
    }
    class LogTypesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LogTypesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: LogTypesProperty | cdktn.IResolvable | undefined);
        private _name?;
        get name(): string;
        set name(value: string);
        get nameInput(): string | undefined;
        private _values?;
        get values(): string[];
        set values(value: string[]);
        get valuesInput(): string[] | undefined;
    }
    class LogTypesPropertyList extends cdktn.ComplexList {
        internalValue?: LogTypesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LogTypesPropertyOutputReference;
    }
    interface CloudwatchLoggingConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#enabled TfApplication#enabled}
        */
        readonly enabled: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#encryption_key_arn TfApplication#encryption_key_arn}
        */
        readonly encryptionKeyArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#log_group_name TfApplication#log_group_name}
        */
        readonly logGroupName?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#log_stream_name_prefix TfApplication#log_stream_name_prefix}
        */
        readonly logStreamNamePrefix?: string;
        /**
        * log_types block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#log_types TfApplication#log_types}
        */
        readonly logTypes?: LogTypesProperty[] | cdktn.IResolvable;
    }
    class CloudwatchLoggingConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): CloudwatchLoggingConfigurationProperty | undefined;
        set internalValue(value: CloudwatchLoggingConfigurationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _encryptionKeyArn?;
        get encryptionKeyArn(): string;
        set encryptionKeyArn(value: string);
        resetEncryptionKeyArn(): void;
        get encryptionKeyArnInput(): string | undefined;
        private _logGroupName?;
        get logGroupName(): string;
        set logGroupName(value: string);
        resetLogGroupName(): void;
        get logGroupNameInput(): string | undefined;
        private _logStreamNamePrefix?;
        get logStreamNamePrefix(): string;
        set logStreamNamePrefix(value: string);
        resetLogStreamNamePrefix(): void;
        get logStreamNamePrefixInput(): string | undefined;
        private _logTypes;
        get logTypes(): LogTypesPropertyList;
        putLogTypes(value: LogTypesProperty[] | cdktn.IResolvable): void;
        resetLogTypes(): void;
        get logTypesInput(): cdktn.IResolvable | LogTypesProperty[] | undefined;
    }
    interface ManagedPersistenceMonitoringConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#enabled TfApplication#enabled}
        */
        readonly enabled?: boolean | cdktn.IResolvable;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#encryption_key_arn TfApplication#encryption_key_arn}
        */
        readonly encryptionKeyArn?: string;
    }
    class ManagedPersistenceMonitoringConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ManagedPersistenceMonitoringConfigurationProperty | undefined;
        set internalValue(value: ManagedPersistenceMonitoringConfigurationProperty | undefined);
        private _enabled?;
        get enabled(): boolean | cdktn.IResolvable;
        set enabled(value: boolean | cdktn.IResolvable);
        resetEnabled(): void;
        get enabledInput(): boolean | cdktn.IResolvable | undefined;
        private _encryptionKeyArn?;
        get encryptionKeyArn(): string;
        set encryptionKeyArn(value: string);
        resetEncryptionKeyArn(): void;
        get encryptionKeyArnInput(): string | undefined;
    }
    interface PrometheusMonitoringConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#remote_write_url TfApplication#remote_write_url}
        */
        readonly remoteWriteUrl?: string;
    }
    class PrometheusMonitoringConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): PrometheusMonitoringConfigurationProperty | undefined;
        set internalValue(value: PrometheusMonitoringConfigurationProperty | undefined);
        private _remoteWriteUrl?;
        get remoteWriteUrl(): string;
        set remoteWriteUrl(value: string);
        resetRemoteWriteUrl(): void;
        get remoteWriteUrlInput(): string | undefined;
    }
    interface S3MonitoringConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#encryption_key_arn TfApplication#encryption_key_arn}
        */
        readonly encryptionKeyArn?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#log_uri TfApplication#log_uri}
        */
        readonly logUri?: string;
    }
    class S3MonitoringConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): S3MonitoringConfigurationProperty | undefined;
        set internalValue(value: S3MonitoringConfigurationProperty | undefined);
        private _encryptionKeyArn?;
        get encryptionKeyArn(): string;
        set encryptionKeyArn(value: string);
        resetEncryptionKeyArn(): void;
        get encryptionKeyArnInput(): string | undefined;
        private _logUri?;
        get logUri(): string;
        set logUri(value: string);
        resetLogUri(): void;
        get logUriInput(): string | undefined;
    }
    interface MonitoringConfigurationProperty {
        /**
        * cloudwatch_logging_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#cloudwatch_logging_configuration TfApplication#cloudwatch_logging_configuration}
        */
        readonly cloudwatchLoggingConfiguration?: CloudwatchLoggingConfigurationProperty;
        /**
        * managed_persistence_monitoring_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#managed_persistence_monitoring_configuration TfApplication#managed_persistence_monitoring_configuration}
        */
        readonly managedPersistenceMonitoringConfiguration?: ManagedPersistenceMonitoringConfigurationProperty;
        /**
        * prometheus_monitoring_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#prometheus_monitoring_configuration TfApplication#prometheus_monitoring_configuration}
        */
        readonly prometheusMonitoringConfiguration?: PrometheusMonitoringConfigurationProperty;
        /**
        * s3_monitoring_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#s3_monitoring_configuration TfApplication#s3_monitoring_configuration}
        */
        readonly s3MonitoringConfiguration?: S3MonitoringConfigurationProperty;
    }
    class MonitoringConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): MonitoringConfigurationProperty | undefined;
        set internalValue(value: MonitoringConfigurationProperty | undefined);
        private _cloudwatchLoggingConfiguration;
        get cloudwatchLoggingConfiguration(): CloudwatchLoggingConfigurationPropertyOutputReference;
        putCloudwatchLoggingConfiguration(value: CloudwatchLoggingConfigurationProperty): void;
        resetCloudwatchLoggingConfiguration(): void;
        get cloudwatchLoggingConfigurationInput(): CloudwatchLoggingConfigurationProperty | undefined;
        private _managedPersistenceMonitoringConfiguration;
        get managedPersistenceMonitoringConfiguration(): ManagedPersistenceMonitoringConfigurationPropertyOutputReference;
        putManagedPersistenceMonitoringConfiguration(value: ManagedPersistenceMonitoringConfigurationProperty): void;
        resetManagedPersistenceMonitoringConfiguration(): void;
        get managedPersistenceMonitoringConfigurationInput(): ManagedPersistenceMonitoringConfigurationProperty | undefined;
        private _prometheusMonitoringConfiguration;
        get prometheusMonitoringConfiguration(): PrometheusMonitoringConfigurationPropertyOutputReference;
        putPrometheusMonitoringConfiguration(value: PrometheusMonitoringConfigurationProperty): void;
        resetPrometheusMonitoringConfiguration(): void;
        get prometheusMonitoringConfigurationInput(): PrometheusMonitoringConfigurationProperty | undefined;
        private _s3MonitoringConfiguration;
        get s3MonitoringConfiguration(): S3MonitoringConfigurationPropertyOutputReference;
        putS3MonitoringConfiguration(value: S3MonitoringConfigurationProperty): void;
        resetS3MonitoringConfiguration(): void;
        get s3MonitoringConfigurationInput(): S3MonitoringConfigurationProperty | undefined;
    }
    interface NetworkConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#security_group_ids TfApplication#security_group_ids}
        */
        readonly securityGroupIds?: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#subnet_ids TfApplication#subnet_ids}
        */
        readonly subnetIds?: string[];
    }
    class NetworkConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): NetworkConfigurationProperty | undefined;
        set internalValue(value: NetworkConfigurationProperty | undefined);
        private _securityGroupIds?;
        get securityGroupIds(): string[];
        set securityGroupIds(value: string[]);
        resetSecurityGroupIds(): void;
        get securityGroupIdsInput(): string[] | undefined;
        private _subnetIds?;
        get subnetIds(): string[];
        set subnetIds(value: string[]);
        resetSubnetIds(): void;
        get subnetIdsInput(): string[] | undefined;
    }
    interface RuntimeConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#classification TfApplication#classification}
        */
        readonly classification: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#properties TfApplication#properties}
        */
        readonly properties?: {
            [key: string]: string;
        };
    }
    class RuntimeConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): RuntimeConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: RuntimeConfigurationProperty | cdktn.IResolvable | undefined);
        private _classification?;
        get classification(): string;
        set classification(value: string);
        get classificationInput(): string | undefined;
        private _properties?;
        get properties(): {
            [key: string]: string;
        };
        set properties(value: {
            [key: string]: string;
        });
        resetProperties(): void;
        get propertiesInput(): {
            [key: string]: string;
        } | undefined;
    }
    class RuntimeConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: RuntimeConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): RuntimeConfigurationPropertyOutputReference;
    }
    interface SchedulerConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#max_concurrent_runs TfApplication#max_concurrent_runs}
        */
        readonly maxConcurrentRuns?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/emrserverless_application#queue_timeout_minutes TfApplication#queue_timeout_minutes}
        */
        readonly queueTimeoutMinutes?: number;
    }
    class SchedulerConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): SchedulerConfigurationProperty | undefined;
        set internalValue(value: SchedulerConfigurationProperty | undefined);
        private _maxConcurrentRuns?;
        get maxConcurrentRuns(): number;
        set maxConcurrentRuns(value: number);
        resetMaxConcurrentRuns(): void;
        get maxConcurrentRunsInput(): number | undefined;
        private _queueTimeoutMinutes?;
        get queueTimeoutMinutes(): number;
        set queueTimeoutMinutes(value: number);
        resetQueueTimeoutMinutes(): void;
        get queueTimeoutMinutesInput(): number | undefined;
    }
}
