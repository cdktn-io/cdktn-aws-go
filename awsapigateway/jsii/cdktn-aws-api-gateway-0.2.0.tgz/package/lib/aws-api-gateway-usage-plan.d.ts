import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfUsagePlanConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_usage_plan#description TfUsagePlan#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_usage_plan#id TfUsagePlan#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_usage_plan#name TfUsagePlan#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_usage_plan#product_code TfUsagePlan#product_code}
    */
    readonly productCode?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_usage_plan#region TfUsagePlan#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_usage_plan#tags TfUsagePlan#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_usage_plan#tags_all TfUsagePlan#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * api_stages block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_usage_plan#api_stages TfUsagePlan#api_stages}
    */
    readonly apiStages?: TfUsagePlan.ApiStagesProperty[] | cdktn.IResolvable;
    /**
    * quota_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_usage_plan#quota_settings TfUsagePlan#quota_settings}
    */
    readonly quotaSettings?: TfUsagePlan.QuotaSettingsProperty;
    /**
    * throttle_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_usage_plan#throttle_settings TfUsagePlan#throttle_settings}
    */
    readonly throttleSettings?: TfUsagePlan.ThrottleSettingsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_usage_plan aws_api_gateway_usage_plan}
*/
export declare class TfUsagePlan extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_api_gateway_usage_plan";
    /**
    * Generates CDKTN code for importing a TfUsagePlan resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfUsagePlan to import
    * @param importFromId The id of the existing TfUsagePlan that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_usage_plan#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfUsagePlan to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_usage_plan aws_api_gateway_usage_plan} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfUsagePlanConfig
    */
    constructor(scope: Construct, id: string, config: TfUsagePlanConfig);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _productCode?;
    get productCode(): string;
    set productCode(value: string);
    resetProductCode(): void;
    get productCodeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _apiStages;
    get apiStages(): TfUsagePlan.ApiStagesPropertyList;
    putApiStages(value: TfUsagePlan.ApiStagesProperty[] | cdktn.IResolvable): void;
    resetApiStages(): void;
    get apiStagesInput(): cdktn.IResolvable | TfUsagePlan.ApiStagesProperty[] | undefined;
    private _quotaSettings;
    get quotaSettings(): TfUsagePlan.QuotaSettingsPropertyOutputReference;
    putQuotaSettings(value: TfUsagePlan.QuotaSettingsProperty): void;
    resetQuotaSettings(): void;
    get quotaSettingsInput(): TfUsagePlan.QuotaSettingsProperty | undefined;
    private _throttleSettings;
    get throttleSettings(): TfUsagePlan.ThrottleSettingsPropertyOutputReference;
    putThrottleSettings(value: TfUsagePlan.ThrottleSettingsProperty): void;
    resetThrottleSettings(): void;
    get throttleSettingsInput(): TfUsagePlan.ThrottleSettingsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfUsagePlanThrottlePropertyToTerraform(struct?: TfUsagePlan.ThrottleProperty | cdktn.IResolvable): any;
export declare function tfUsagePlanThrottlePropertyToHclTerraform(struct?: TfUsagePlan.ThrottleProperty | cdktn.IResolvable): any;
export declare function tfUsagePlanApiStagesPropertyToTerraform(struct?: TfUsagePlan.ApiStagesProperty | cdktn.IResolvable): any;
export declare function tfUsagePlanApiStagesPropertyToHclTerraform(struct?: TfUsagePlan.ApiStagesProperty | cdktn.IResolvable): any;
export declare function tfUsagePlanQuotaSettingsPropertyToTerraform(struct?: TfUsagePlan.QuotaSettingsPropertyOutputReference | TfUsagePlan.QuotaSettingsProperty): any;
export declare function tfUsagePlanQuotaSettingsPropertyToHclTerraform(struct?: TfUsagePlan.QuotaSettingsPropertyOutputReference | TfUsagePlan.QuotaSettingsProperty): any;
export declare function tfUsagePlanThrottleSettingsPropertyToTerraform(struct?: TfUsagePlan.ThrottleSettingsPropertyOutputReference | TfUsagePlan.ThrottleSettingsProperty): any;
export declare function tfUsagePlanThrottleSettingsPropertyToHclTerraform(struct?: TfUsagePlan.ThrottleSettingsPropertyOutputReference | TfUsagePlan.ThrottleSettingsProperty): any;
export declare namespace TfUsagePlan {
    interface ThrottleProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_usage_plan#burst_limit TfUsagePlan#burst_limit}
        */
        readonly burstLimit?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_usage_plan#path TfUsagePlan#path}
        */
        readonly path: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_usage_plan#rate_limit TfUsagePlan#rate_limit}
        */
        readonly rateLimit?: number;
    }
    class ThrottlePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ThrottleProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ThrottleProperty | cdktn.IResolvable | undefined);
        private _burstLimit?;
        get burstLimit(): number;
        set burstLimit(value: number);
        resetBurstLimit(): void;
        get burstLimitInput(): number | undefined;
        private _path?;
        get path(): string;
        set path(value: string);
        get pathInput(): string | undefined;
        private _rateLimit?;
        get rateLimit(): number;
        set rateLimit(value: number);
        resetRateLimit(): void;
        get rateLimitInput(): number | undefined;
    }
    class ThrottlePropertyList extends cdktn.ComplexList {
        internalValue?: ThrottleProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ThrottlePropertyOutputReference;
    }
    interface ApiStagesProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_usage_plan#api_id TfUsagePlan#api_id}
        */
        readonly apiId: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_usage_plan#stage TfUsagePlan#stage}
        */
        readonly stage: string;
        /**
        * throttle block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_usage_plan#throttle TfUsagePlan#throttle}
        */
        readonly throttle?: ThrottleProperty[] | cdktn.IResolvable;
    }
    class ApiStagesPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ApiStagesProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ApiStagesProperty | cdktn.IResolvable | undefined);
        private _apiId?;
        get apiId(): string;
        set apiId(value: string);
        get apiIdInput(): string | undefined;
        private _stage?;
        get stage(): string;
        set stage(value: string);
        get stageInput(): string | undefined;
        private _throttle;
        get throttle(): ThrottlePropertyList;
        putThrottle(value: ThrottleProperty[] | cdktn.IResolvable): void;
        resetThrottle(): void;
        get throttleInput(): cdktn.IResolvable | ThrottleProperty[] | undefined;
    }
    class ApiStagesPropertyList extends cdktn.ComplexList {
        internalValue?: ApiStagesProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ApiStagesPropertyOutputReference;
    }
    interface QuotaSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_usage_plan#limit TfUsagePlan#limit}
        */
        readonly limit: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_usage_plan#offset TfUsagePlan#offset}
        */
        readonly offset?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_usage_plan#period TfUsagePlan#period}
        */
        readonly period: string;
    }
    class QuotaSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): QuotaSettingsProperty | undefined;
        set internalValue(value: QuotaSettingsProperty | undefined);
        private _limit?;
        get limit(): number;
        set limit(value: number);
        get limitInput(): number | undefined;
        private _offset?;
        get offset(): number;
        set offset(value: number);
        resetOffset(): void;
        get offsetInput(): number | undefined;
        private _period?;
        get period(): string;
        set period(value: string);
        get periodInput(): string | undefined;
    }
    interface ThrottleSettingsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_usage_plan#burst_limit TfUsagePlan#burst_limit}
        */
        readonly burstLimit?: number;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_usage_plan#rate_limit TfUsagePlan#rate_limit}
        */
        readonly rateLimit?: number;
    }
    class ThrottleSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): ThrottleSettingsProperty | undefined;
        set internalValue(value: ThrottleSettingsProperty | undefined);
        private _burstLimit?;
        get burstLimit(): number;
        set burstLimit(value: number);
        resetBurstLimit(): void;
        get burstLimitInput(): number | undefined;
        private _rateLimit?;
        get rateLimit(): number;
        set rateLimit(value: number);
        resetRateLimit(): void;
        get rateLimitInput(): number | undefined;
    }
}
