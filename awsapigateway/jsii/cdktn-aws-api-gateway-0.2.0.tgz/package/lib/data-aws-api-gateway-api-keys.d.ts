import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfApiKeysConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/api_gateway_api_keys#customer_id DataTfApiKeys#customer_id}
    */
    readonly customerId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/api_gateway_api_keys#include_values DataTfApiKeys#include_values}
    */
    readonly includeValues?: boolean | cdktn.IResolvable;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/api_gateway_api_keys#region DataTfApiKeys#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/api_gateway_api_keys aws_api_gateway_api_keys}
*/
export declare class DataTfApiKeys extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_api_gateway_api_keys";
    /**
    * Generates CDKTN code for importing a DataTfApiKeys resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfApiKeys to import
    * @param importFromId The id of the existing DataTfApiKeys that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/api_gateway_api_keys#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfApiKeys to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/api_gateway_api_keys aws_api_gateway_api_keys} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfApiKeysConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataTfApiKeysConfig);
    private _customerId?;
    get customerId(): string;
    set customerId(value: string);
    resetCustomerId(): void;
    get customerIdInput(): string | undefined;
    get id(): string;
    private _includeValues?;
    get includeValues(): boolean | cdktn.IResolvable;
    set includeValues(value: boolean | cdktn.IResolvable);
    resetIncludeValues(): void;
    get includeValuesInput(): boolean | cdktn.IResolvable | undefined;
    private _items;
    get items(): DataTfApiKeys.ItemsPropertyList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfApiKeysItemsPropertyToTerraform(struct?: DataTfApiKeys.ItemsProperty): any;
export declare function dataTfApiKeysItemsPropertyToHclTerraform(struct?: DataTfApiKeys.ItemsProperty): any;
export declare namespace DataTfApiKeys {
    interface ItemsProperty {
    }
    class ItemsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ItemsProperty | undefined;
        set internalValue(value: ItemsProperty | undefined);
        get createdDate(): string;
        get customerId(): string;
        get description(): string;
        get enabled(): cdktn.IResolvable;
        get id(): string;
        get lastUpdatedDate(): string;
        get name(): string;
        get stageKeys(): string[];
        private _tags;
        get tags(): cdktn.StringMap;
        get value(): string;
    }
    class ItemsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ItemsPropertyOutputReference;
    }
}
