import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsApiGatewayDomainNameAccessAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_domain_name_access_association#access_association_source AwsApiGatewayDomainNameAccessAssociation#access_association_source}
    */
    readonly accessAssociationSource: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_domain_name_access_association#access_association_source_type AwsApiGatewayDomainNameAccessAssociation#access_association_source_type}
    */
    readonly accessAssociationSourceType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_domain_name_access_association#domain_name_arn AwsApiGatewayDomainNameAccessAssociation#domain_name_arn}
    */
    readonly domainNameArn: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_domain_name_access_association#region AwsApiGatewayDomainNameAccessAssociation#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_domain_name_access_association#tags AwsApiGatewayDomainNameAccessAssociation#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_domain_name_access_association aws_api_gateway_domain_name_access_association}
*/
export declare class AwsApiGatewayDomainNameAccessAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_api_gateway_domain_name_access_association";
    /**
    * Generates CDKTN code for importing a AwsApiGatewayDomainNameAccessAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsApiGatewayDomainNameAccessAssociation to import
    * @param importFromId The id of the existing AwsApiGatewayDomainNameAccessAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_domain_name_access_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsApiGatewayDomainNameAccessAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_domain_name_access_association aws_api_gateway_domain_name_access_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsApiGatewayDomainNameAccessAssociationConfig
    */
    constructor(scope: Construct, id: string, config: AwsApiGatewayDomainNameAccessAssociationConfig);
    private _accessAssociationSource?;
    get accessAssociationSource(): string;
    set accessAssociationSource(value: string);
    get accessAssociationSourceInput(): string | undefined;
    private _accessAssociationSourceType?;
    get accessAssociationSourceType(): string;
    set accessAssociationSourceType(value: string);
    get accessAssociationSourceTypeInput(): string | undefined;
    get arn(): string;
    private _domainNameArn?;
    get domainNameArn(): string;
    set domainNameArn(value: string);
    get domainNameArnInput(): string | undefined;
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
