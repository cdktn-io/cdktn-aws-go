import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsApiGatewayAccountConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_account#cloudwatch_role_arn AwsApiGatewayAccount#cloudwatch_role_arn}
    */
    readonly cloudwatchRoleArn?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_account#region AwsApiGatewayAccount#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_account aws_api_gateway_account}
*/
export declare class AwsApiGatewayAccount extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_api_gateway_account";
    /**
    * Generates CDKTN code for importing a AwsApiGatewayAccount resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsApiGatewayAccount to import
    * @param importFromId The id of the existing AwsApiGatewayAccount that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_account#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsApiGatewayAccount to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_account aws_api_gateway_account} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsApiGatewayAccountConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsApiGatewayAccountConfig);
    get apiKeyVersion(): string;
    private _cloudwatchRoleArn?;
    get cloudwatchRoleArn(): string;
    set cloudwatchRoleArn(value: string);
    resetCloudwatchRoleArn(): void;
    get cloudwatchRoleArnInput(): string | undefined;
    get features(): string[];
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _throttleSettings;
    get throttleSettings(): AwsApiGatewayAccount.ThrottleSettingsPropertyList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsApiGatewayAccountThrottleSettingsPropertyToTerraform(struct?: AwsApiGatewayAccount.ThrottleSettingsProperty): any;
export declare function awsApiGatewayAccountThrottleSettingsPropertyToHclTerraform(struct?: AwsApiGatewayAccount.ThrottleSettingsProperty): any;
export declare namespace AwsApiGatewayAccount {
    interface ThrottleSettingsProperty {
    }
    class ThrottleSettingsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ThrottleSettingsProperty | undefined;
        set internalValue(value: ThrottleSettingsProperty | undefined);
        get burstLimit(): number;
        get rateLimit(): number;
    }
    class ThrottleSettingsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ThrottleSettingsPropertyOutputReference;
    }
}
