import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsApiGatewayRestApiConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_rest_api#api_key_source AwsApiGatewayRestApi#api_key_source}
    */
    readonly apiKeySource?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_rest_api#binary_media_types AwsApiGatewayRestApi#binary_media_types}
    */
    readonly binaryMediaTypes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_rest_api#body AwsApiGatewayRestApi#body}
    */
    readonly body?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_rest_api#description AwsApiGatewayRestApi#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_rest_api#disable_execute_api_endpoint AwsApiGatewayRestApi#disable_execute_api_endpoint}
    */
    readonly disableExecuteApiEndpoint?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_rest_api#endpoint_access_mode AwsApiGatewayRestApi#endpoint_access_mode}
    */
    readonly endpointAccessMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_rest_api#fail_on_warnings AwsApiGatewayRestApi#fail_on_warnings}
    */
    readonly failOnWarnings?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_rest_api#id AwsApiGatewayRestApi#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_rest_api#minimum_compression_size AwsApiGatewayRestApi#minimum_compression_size}
    */
    readonly minimumCompressionSize?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_rest_api#name AwsApiGatewayRestApi#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_rest_api#parameters AwsApiGatewayRestApi#parameters}
    */
    readonly parameters?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_rest_api#policy AwsApiGatewayRestApi#policy}
    */
    readonly policy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_rest_api#put_rest_api_mode AwsApiGatewayRestApi#put_rest_api_mode}
    */
    readonly putRestApiMode?: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_rest_api#region AwsApiGatewayRestApi#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_rest_api#security_policy AwsApiGatewayRestApi#security_policy}
    */
    readonly securityPolicy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_rest_api#tags AwsApiGatewayRestApi#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_rest_api#tags_all AwsApiGatewayRestApi#tags_all}
    */
    readonly tagsAll?: {
        [key: string]: string;
    };
    /**
    * endpoint_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_rest_api#endpoint_configuration AwsApiGatewayRestApi#endpoint_configuration}
    */
    readonly endpointConfiguration?: AwsApiGatewayRestApi.EndpointConfigurationProperty;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_rest_api#timeouts AwsApiGatewayRestApi#timeouts}
    */
    readonly timeouts?: AwsApiGatewayRestApi.TimeoutsProperty;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_rest_api aws_api_gateway_rest_api}
*/
export declare class AwsApiGatewayRestApi extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_api_gateway_rest_api";
    /**
    * Generates CDKTN code for importing a AwsApiGatewayRestApi resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsApiGatewayRestApi to import
    * @param importFromId The id of the existing AwsApiGatewayRestApi that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_rest_api#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsApiGatewayRestApi to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_rest_api aws_api_gateway_rest_api} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsApiGatewayRestApiConfig
    */
    constructor(scope: Construct, id: string, config: AwsApiGatewayRestApiConfig);
    private _apiKeySource?;
    get apiKeySource(): string;
    set apiKeySource(value: string);
    resetApiKeySource(): void;
    get apiKeySourceInput(): string | undefined;
    get arn(): string;
    private _binaryMediaTypes?;
    get binaryMediaTypes(): string[];
    set binaryMediaTypes(value: string[]);
    resetBinaryMediaTypes(): void;
    get binaryMediaTypesInput(): string[] | undefined;
    private _body?;
    get body(): string;
    set body(value: string);
    resetBody(): void;
    get bodyInput(): string | undefined;
    get createdDate(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _disableExecuteApiEndpoint?;
    get disableExecuteApiEndpoint(): boolean | cdktn.IResolvable;
    set disableExecuteApiEndpoint(value: boolean | cdktn.IResolvable);
    resetDisableExecuteApiEndpoint(): void;
    get disableExecuteApiEndpointInput(): boolean | cdktn.IResolvable | undefined;
    private _endpointAccessMode?;
    get endpointAccessMode(): string;
    set endpointAccessMode(value: string);
    resetEndpointAccessMode(): void;
    get endpointAccessModeInput(): string | undefined;
    get executionArn(): string;
    private _failOnWarnings?;
    get failOnWarnings(): boolean | cdktn.IResolvable;
    set failOnWarnings(value: boolean | cdktn.IResolvable);
    resetFailOnWarnings(): void;
    get failOnWarningsInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _minimumCompressionSize?;
    get minimumCompressionSize(): string;
    set minimumCompressionSize(value: string);
    resetMinimumCompressionSize(): void;
    get minimumCompressionSizeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parameters?;
    get parameters(): {
        [key: string]: string;
    };
    set parameters(value: {
        [key: string]: string;
    });
    resetParameters(): void;
    get parametersInput(): {
        [key: string]: string;
    } | undefined;
    private _policy?;
    get policy(): string;
    set policy(value: string);
    resetPolicy(): void;
    get policyInput(): string | undefined;
    private _putRestApiMode?;
    get putRestApiMode(): string;
    set putRestApiMode(value: string);
    resetPutRestApiMode(): void;
    get putRestApiModeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get rootResourceId(): string;
    private _securityPolicy?;
    get securityPolicy(): string;
    set securityPolicy(value: string);
    resetSecurityPolicy(): void;
    get securityPolicyInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll?;
    get tagsAll(): {
        [key: string]: string;
    };
    set tagsAll(value: {
        [key: string]: string;
    });
    resetTagsAll(): void;
    get tagsAllInput(): {
        [key: string]: string;
    } | undefined;
    private _endpointConfiguration;
    get endpointConfiguration(): AwsApiGatewayRestApi.EndpointConfigurationPropertyOutputReference;
    putEndpointConfiguration(value: AwsApiGatewayRestApi.EndpointConfigurationProperty): void;
    resetEndpointConfiguration(): void;
    get endpointConfigurationInput(): AwsApiGatewayRestApi.EndpointConfigurationProperty | undefined;
    private _timeouts;
    get timeouts(): AwsApiGatewayRestApi.TimeoutsPropertyOutputReference;
    putTimeouts(value: AwsApiGatewayRestApi.TimeoutsProperty): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AwsApiGatewayRestApi.TimeoutsProperty | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function awsApiGatewayRestApiEndpointConfigurationPropertyToTerraform(struct?: AwsApiGatewayRestApi.EndpointConfigurationPropertyOutputReference | AwsApiGatewayRestApi.EndpointConfigurationProperty): any;
export declare function awsApiGatewayRestApiEndpointConfigurationPropertyToHclTerraform(struct?: AwsApiGatewayRestApi.EndpointConfigurationPropertyOutputReference | AwsApiGatewayRestApi.EndpointConfigurationProperty): any;
export declare function awsApiGatewayRestApiTimeoutsPropertyToTerraform(struct?: AwsApiGatewayRestApi.TimeoutsProperty | cdktn.IResolvable): any;
export declare function awsApiGatewayRestApiTimeoutsPropertyToHclTerraform(struct?: AwsApiGatewayRestApi.TimeoutsProperty | cdktn.IResolvable): any;
export declare namespace AwsApiGatewayRestApi {
    interface EndpointConfigurationProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_rest_api#ip_address_type AwsApiGatewayRestApi#ip_address_type}
        */
        readonly ipAddressType?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_rest_api#types AwsApiGatewayRestApi#types}
        */
        readonly types: string[];
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_rest_api#vpc_endpoint_ids AwsApiGatewayRestApi#vpc_endpoint_ids}
        */
        readonly vpcEndpointIds?: string[];
    }
    class EndpointConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): EndpointConfigurationProperty | undefined;
        set internalValue(value: EndpointConfigurationProperty | undefined);
        private _ipAddressType?;
        get ipAddressType(): string;
        set ipAddressType(value: string);
        resetIpAddressType(): void;
        get ipAddressTypeInput(): string | undefined;
        private _types?;
        get types(): string[];
        set types(value: string[]);
        get typesInput(): string[] | undefined;
        private _vpcEndpointIds?;
        get vpcEndpointIds(): string[];
        set vpcEndpointIds(value: string[]);
        resetVpcEndpointIds(): void;
        get vpcEndpointIdsInput(): string[] | undefined;
    }
    interface TimeoutsProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_rest_api#create AwsApiGatewayRestApi#create}
        */
        readonly create?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_rest_api#delete AwsApiGatewayRestApi#delete}
        */
        readonly delete?: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/api_gateway_rest_api#update AwsApiGatewayRestApi#update}
        */
        readonly update?: string;
    }
    class TimeoutsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
        get internalValue(): TimeoutsProperty | cdktn.IResolvable | undefined;
        set internalValue(value: TimeoutsProperty | cdktn.IResolvable | undefined);
        private _create?;
        get create(): string;
        set create(value: string);
        resetCreate(): void;
        get createInput(): string | undefined;
        private _delete?;
        get delete(): string;
        set delete(value: string);
        resetDelete(): void;
        get deleteInput(): string | undefined;
        private _update?;
        get update(): string;
        set update(value: string);
        resetUpdate(): void;
        get updateInput(): string | undefined;
    }
}
