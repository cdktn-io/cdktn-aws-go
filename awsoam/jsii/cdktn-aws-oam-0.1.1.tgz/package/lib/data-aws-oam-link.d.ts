import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAwsOamLinkConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/oam_link#id DataAwsOamLink#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/oam_link#link_identifier DataAwsOamLink#link_identifier}
    */
    readonly linkIdentifier: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/oam_link#region DataAwsOamLink#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/oam_link#tags DataAwsOamLink#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/oam_link aws_oam_link}
*/
export declare class DataAwsOamLink extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_oam_link";
    /**
    * Generates CDKTN code for importing a DataAwsOamLink resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAwsOamLink to import
    * @param importFromId The id of the existing DataAwsOamLink that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/oam_link#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAwsOamLink to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/oam_link aws_oam_link} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAwsOamLinkConfig
    */
    constructor(scope: Construct, id: string, config: DataAwsOamLinkConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get label(): string;
    get labelTemplate(): string;
    private _linkConfiguration;
    get linkConfiguration(): DataAwsOamLink.LinkConfigurationPropertyList;
    get linkId(): string;
    private _linkIdentifier?;
    get linkIdentifier(): string;
    set linkIdentifier(value: string);
    get linkIdentifierInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get resourceTypes(): string[];
    get sinkArn(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataAwsOamLinkLogGroupConfigurationPropertyToTerraform(struct?: DataAwsOamLink.LogGroupConfigurationProperty): any;
export declare function dataAwsOamLinkLogGroupConfigurationPropertyToHclTerraform(struct?: DataAwsOamLink.LogGroupConfigurationProperty): any;
export declare function dataAwsOamLinkMetricConfigurationPropertyToTerraform(struct?: DataAwsOamLink.MetricConfigurationProperty): any;
export declare function dataAwsOamLinkMetricConfigurationPropertyToHclTerraform(struct?: DataAwsOamLink.MetricConfigurationProperty): any;
export declare function dataAwsOamLinkLinkConfigurationPropertyToTerraform(struct?: DataAwsOamLink.LinkConfigurationProperty): any;
export declare function dataAwsOamLinkLinkConfigurationPropertyToHclTerraform(struct?: DataAwsOamLink.LinkConfigurationProperty): any;
export declare namespace DataAwsOamLink {
    interface LogGroupConfigurationProperty {
    }
    class LogGroupConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LogGroupConfigurationProperty | undefined;
        set internalValue(value: LogGroupConfigurationProperty | undefined);
        get filter(): string;
    }
    class LogGroupConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LogGroupConfigurationPropertyOutputReference;
    }
    interface MetricConfigurationProperty {
    }
    class MetricConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): MetricConfigurationProperty | undefined;
        set internalValue(value: MetricConfigurationProperty | undefined);
        get filter(): string;
    }
    class MetricConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): MetricConfigurationPropertyOutputReference;
    }
    interface LinkConfigurationProperty {
    }
    class LinkConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): LinkConfigurationProperty | undefined;
        set internalValue(value: LinkConfigurationProperty | undefined);
        private _logGroupConfiguration;
        get logGroupConfiguration(): LogGroupConfigurationPropertyList;
        private _metricConfiguration;
        get metricConfiguration(): MetricConfigurationPropertyList;
    }
    class LinkConfigurationPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): LinkConfigurationPropertyOutputReference;
    }
}
