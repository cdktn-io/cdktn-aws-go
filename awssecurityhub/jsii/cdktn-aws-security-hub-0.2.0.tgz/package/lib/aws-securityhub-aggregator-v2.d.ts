import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfAggregatorV2Config extends cdktn.TerraformMetaArguments {
    /**
    * The list of Regions linked to the aggregation Region.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_aggregator_v2#linked_regions TfAggregatorV2#linked_regions}
    */
    readonly linkedRegions?: string[];
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_aggregator_v2#region TfAggregatorV2#region}
    */
    readonly region?: string;
    /**
    * Determines how Regions are linked: ALL_REGIONS, ALL_REGIONS_EXCEPT_SPECIFIED, or SPECIFIED_REGIONS.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_aggregator_v2#region_linking_mode TfAggregatorV2#region_linking_mode}
    */
    readonly regionLinkingMode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_aggregator_v2#tags TfAggregatorV2#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_aggregator_v2 aws_securityhub_aggregator_v2}
*/
export declare class TfAggregatorV2 extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_securityhub_aggregator_v2";
    /**
    * Generates CDKTN code for importing a TfAggregatorV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfAggregatorV2 to import
    * @param importFromId The id of the existing TfAggregatorV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_aggregator_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfAggregatorV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_aggregator_v2 aws_securityhub_aggregator_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfAggregatorV2Config
    */
    constructor(scope: Construct, id: string, config: TfAggregatorV2Config);
    get aggregationRegion(): string;
    get arn(): string;
    private _linkedRegions?;
    get linkedRegions(): string[];
    set linkedRegions(value: string[]);
    resetLinkedRegions(): void;
    get linkedRegionsInput(): string[] | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _regionLinkingMode?;
    get regionLinkingMode(): string;
    set regionLinkingMode(value: string);
    get regionLinkingModeInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
