import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfConnectorV2Config extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_connector_v2#description TfConnectorV2#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_connector_v2#kms_key_arn TfConnectorV2#kms_key_arn}
    */
    readonly kmsKeyArn?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_connector_v2#name TfConnectorV2#name}
    */
    readonly name: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_connector_v2#region TfConnectorV2#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_connector_v2#tags TfConnectorV2#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * connector_provider block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_connector_v2#connector_provider TfConnectorV2#connector_provider}
    */
    readonly connectorProvider?: TfConnectorV2.ConnectorProviderProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_connector_v2 aws_securityhub_connector_v2}
*/
export declare class TfConnectorV2 extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_securityhub_connector_v2";
    /**
    * Generates CDKTN code for importing a TfConnectorV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfConnectorV2 to import
    * @param importFromId The id of the existing TfConnectorV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_connector_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfConnectorV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_connector_v2 aws_securityhub_connector_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfConnectorV2Config
    */
    constructor(scope: Construct, id: string, config: TfConnectorV2Config);
    get arn(): string;
    get connectorId(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _health;
    get health(): TfConnectorV2.HealthPropertyList;
    private _kmsKeyArn?;
    get kmsKeyArn(): string;
    set kmsKeyArn(value: string);
    resetKmsKeyArn(): void;
    get kmsKeyArnInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _connectorProvider;
    get connectorProvider(): TfConnectorV2.ConnectorProviderPropertyList;
    putConnectorProvider(value: TfConnectorV2.ConnectorProviderProperty[] | cdktn.IResolvable): void;
    resetConnectorProvider(): void;
    get connectorProviderInput(): cdktn.IResolvable | TfConnectorV2.ConnectorProviderProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfConnectorV2HealthPropertyToTerraform(struct?: TfConnectorV2.HealthProperty): any;
export declare function tfConnectorV2HealthPropertyToHclTerraform(struct?: TfConnectorV2.HealthProperty): any;
export declare function tfConnectorV2JiraCloudPropertyToTerraform(struct?: TfConnectorV2.JiraCloudProperty | cdktn.IResolvable): any;
export declare function tfConnectorV2JiraCloudPropertyToHclTerraform(struct?: TfConnectorV2.JiraCloudProperty | cdktn.IResolvable): any;
export declare function tfConnectorV2ServiceNowPropertyToTerraform(struct?: TfConnectorV2.ServiceNowProperty | cdktn.IResolvable): any;
export declare function tfConnectorV2ServiceNowPropertyToHclTerraform(struct?: TfConnectorV2.ServiceNowProperty | cdktn.IResolvable): any;
export declare function tfConnectorV2ConnectorProviderPropertyToTerraform(struct?: TfConnectorV2.ConnectorProviderProperty | cdktn.IResolvable): any;
export declare function tfConnectorV2ConnectorProviderPropertyToHclTerraform(struct?: TfConnectorV2.ConnectorProviderProperty | cdktn.IResolvable): any;
export declare namespace TfConnectorV2 {
    interface HealthProperty {
    }
    class HealthPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): HealthProperty | undefined;
        set internalValue(value: HealthProperty | undefined);
        get connectorStatus(): string;
        get lastCheckedAt(): string;
        get message(): string;
    }
    class HealthPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): HealthPropertyOutputReference;
    }
    interface JiraCloudProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_connector_v2#project_key TfConnectorV2#project_key}
        */
        readonly projectKey: string;
    }
    class JiraCloudPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): JiraCloudProperty | cdktn.IResolvable | undefined;
        set internalValue(value: JiraCloudProperty | cdktn.IResolvable | undefined);
        get authStatus(): string;
        get authUrl(): string;
        get cloudId(): string;
        get domain(): string;
        private _projectKey?;
        get projectKey(): string;
        set projectKey(value: string);
        get projectKeyInput(): string | undefined;
    }
    class JiraCloudPropertyList extends cdktn.ComplexList {
        internalValue?: JiraCloudProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): JiraCloudPropertyOutputReference;
    }
    interface ServiceNowProperty {
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_connector_v2#instance_name TfConnectorV2#instance_name}
        */
        readonly instanceName: string;
        /**
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_connector_v2#secret_arn TfConnectorV2#secret_arn}
        */
        readonly secretArn: string;
    }
    class ServiceNowPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ServiceNowProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ServiceNowProperty | cdktn.IResolvable | undefined);
        get authStatus(): string;
        private _instanceName?;
        get instanceName(): string;
        set instanceName(value: string);
        get instanceNameInput(): string | undefined;
        private _secretArn?;
        get secretArn(): string;
        set secretArn(value: string);
        get secretArnInput(): string | undefined;
    }
    class ServiceNowPropertyList extends cdktn.ComplexList {
        internalValue?: ServiceNowProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ServiceNowPropertyOutputReference;
    }
    interface ConnectorProviderProperty {
        /**
        * jira_cloud block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_connector_v2#jira_cloud TfConnectorV2#jira_cloud}
        */
        readonly jiraCloud?: JiraCloudProperty[] | cdktn.IResolvable;
        /**
        * service_now block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_connector_v2#service_now TfConnectorV2#service_now}
        */
        readonly serviceNow?: ServiceNowProperty[] | cdktn.IResolvable;
    }
    class ConnectorProviderPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ConnectorProviderProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ConnectorProviderProperty | cdktn.IResolvable | undefined);
        private _jiraCloud;
        get jiraCloud(): JiraCloudPropertyList;
        putJiraCloud(value: JiraCloudProperty[] | cdktn.IResolvable): void;
        resetJiraCloud(): void;
        get jiraCloudInput(): cdktn.IResolvable | JiraCloudProperty[] | undefined;
        private _serviceNow;
        get serviceNow(): ServiceNowPropertyList;
        putServiceNow(value: ServiceNowProperty[] | cdktn.IResolvable): void;
        resetServiceNow(): void;
        get serviceNowInput(): cdktn.IResolvable | ServiceNowProperty[] | undefined;
    }
    class ConnectorProviderPropertyList extends cdktn.ComplexList {
        internalValue?: ConnectorProviderProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ConnectorProviderPropertyOutputReference;
    }
}
