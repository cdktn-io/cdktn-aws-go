import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTfStandardsControlAssociationsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/securityhub_standards_control_associations#region DataTfStandardsControlAssociations#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/securityhub_standards_control_associations#security_control_id DataTfStandardsControlAssociations#security_control_id}
    */
    readonly securityControlId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/securityhub_standards_control_associations aws_securityhub_standards_control_associations}
*/
export declare class DataTfStandardsControlAssociations extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "aws_securityhub_standards_control_associations";
    /**
    * Generates CDKTN code for importing a DataTfStandardsControlAssociations resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTfStandardsControlAssociations to import
    * @param importFromId The id of the existing DataTfStandardsControlAssociations that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/securityhub_standards_control_associations#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTfStandardsControlAssociations to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/data-sources/securityhub_standards_control_associations aws_securityhub_standards_control_associations} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTfStandardsControlAssociationsConfig
    */
    constructor(scope: Construct, id: string, config: DataTfStandardsControlAssociationsConfig);
    get id(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _securityControlId?;
    get securityControlId(): string;
    set securityControlId(value: string);
    get securityControlIdInput(): string | undefined;
    private _standardsControlAssociations;
    get standardsControlAssociations(): DataTfStandardsControlAssociations.StandardsControlAssociationsPropertyList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function dataTfStandardsControlAssociationsStandardsControlAssociationsPropertyToTerraform(struct?: DataTfStandardsControlAssociations.StandardsControlAssociationsProperty): any;
export declare function dataTfStandardsControlAssociationsStandardsControlAssociationsPropertyToHclTerraform(struct?: DataTfStandardsControlAssociations.StandardsControlAssociationsProperty): any;
export declare namespace DataTfStandardsControlAssociations {
    interface StandardsControlAssociationsProperty {
    }
    class StandardsControlAssociationsPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): StandardsControlAssociationsProperty | undefined;
        set internalValue(value: StandardsControlAssociationsProperty | undefined);
        get associationStatus(): string;
        get relatedRequirements(): string[];
        get securityControlArn(): string;
        get securityControlId(): string;
        get standardsArn(): string;
        get standardsControlDescription(): string;
        get standardsControlTitle(): string;
        get updatedAt(): string;
        get updatedReason(): string;
    }
    class StandardsControlAssociationsPropertyList extends cdktn.ComplexList {
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): StandardsControlAssociationsPropertyOutputReference;
    }
}
