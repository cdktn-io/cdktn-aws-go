import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfFindingAggregatorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_finding_aggregator#id TfFindingAggregator#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_finding_aggregator#linking_mode TfFindingAggregator#linking_mode}
    */
    readonly linkingMode: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_finding_aggregator#region TfFindingAggregator#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_finding_aggregator#specified_regions TfFindingAggregator#specified_regions}
    */
    readonly specifiedRegions?: string[];
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_finding_aggregator aws_securityhub_finding_aggregator}
*/
export declare class TfFindingAggregator extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_securityhub_finding_aggregator";
    /**
    * Generates CDKTN code for importing a TfFindingAggregator resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfFindingAggregator to import
    * @param importFromId The id of the existing TfFindingAggregator that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_finding_aggregator#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfFindingAggregator to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_finding_aggregator aws_securityhub_finding_aggregator} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfFindingAggregatorConfig
    */
    constructor(scope: Construct, id: string, config: TfFindingAggregatorConfig);
    get arn(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _linkingMode?;
    get linkingMode(): string;
    set linkingMode(value: string);
    get linkingModeInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _specifiedRegions?;
    get specifiedRegions(): string[];
    set specifiedRegions(value: string[]);
    resetSpecifiedRegions(): void;
    get specifiedRegionsInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
