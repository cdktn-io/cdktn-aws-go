import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TfAutomationRuleV2Config extends cdktn.TerraformMetaArguments {
    /**
    * A description of the automation rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule_v2#description TfAutomationRuleV2#description}
    */
    readonly description: string;
    /**
    * Region where this resource will be [managed](https://docs.aws.amazon.com/general/latest/gr/rande.html#regional-endpoints). Defaults to the Region set in the [provider configuration](https://registry.terraform.io/providers/hashicorp/aws/latest/docs#aws-configuration-reference).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule_v2#region TfAutomationRuleV2#region}
    */
    readonly region?: string;
    /**
    * The name of the automation rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule_v2#rule_name TfAutomationRuleV2#rule_name}
    */
    readonly ruleName: string;
    /**
    * The priority of the rule (lower values = higher priority).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule_v2#rule_order TfAutomationRuleV2#rule_order}
    */
    readonly ruleOrder: number;
    /**
    * The status of the rule: ENABLED or DISABLED.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule_v2#rule_status TfAutomationRuleV2#rule_status}
    */
    readonly ruleStatus?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule_v2#tags TfAutomationRuleV2#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule_v2#action TfAutomationRuleV2#action}
    */
    readonly action?: TfAutomationRuleV2.ActionProperty[] | cdktn.IResolvable;
    /**
    * criteria block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule_v2#criteria TfAutomationRuleV2#criteria}
    */
    readonly criteria?: TfAutomationRuleV2.CriteriaProperty[] | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule_v2 aws_securityhub_automation_rule_v2}
*/
export declare class TfAutomationRuleV2 extends cdktn.TerraformResource {
    static readonly tfResourceType = "aws_securityhub_automation_rule_v2";
    /**
    * Generates CDKTN code for importing a TfAutomationRuleV2 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TfAutomationRuleV2 to import
    * @param importFromId The id of the existing TfAutomationRuleV2 that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule_v2#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TfAutomationRuleV2 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule_v2 aws_securityhub_automation_rule_v2} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TfAutomationRuleV2Config
    */
    constructor(scope: Construct, id: string, config: TfAutomationRuleV2Config);
    get arn(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get ruleId(): string;
    private _ruleName?;
    get ruleName(): string;
    set ruleName(value: string);
    get ruleNameInput(): string | undefined;
    private _ruleOrder?;
    get ruleOrder(): number;
    set ruleOrder(value: number);
    get ruleOrderInput(): number | undefined;
    private _ruleStatus?;
    get ruleStatus(): string;
    set ruleStatus(value: string);
    resetRuleStatus(): void;
    get ruleStatusInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _tagsAll;
    get tagsAll(): cdktn.StringMap;
    private _action;
    get action(): TfAutomationRuleV2.ActionPropertyList;
    putAction(value: TfAutomationRuleV2.ActionProperty[] | cdktn.IResolvable): void;
    resetAction(): void;
    get actionInput(): cdktn.IResolvable | TfAutomationRuleV2.ActionProperty[] | undefined;
    private _criteria;
    get criteria(): TfAutomationRuleV2.CriteriaPropertyList;
    putCriteria(value: TfAutomationRuleV2.CriteriaProperty[] | cdktn.IResolvable): void;
    resetCriteria(): void;
    get criteriaInput(): cdktn.IResolvable | TfAutomationRuleV2.CriteriaProperty[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
export declare function tfAutomationRuleV2ExternalIntegrationConfigurationPropertyToTerraform(struct?: TfAutomationRuleV2.ExternalIntegrationConfigurationProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleV2ExternalIntegrationConfigurationPropertyToHclTerraform(struct?: TfAutomationRuleV2.ExternalIntegrationConfigurationProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleV2FindingFieldsUpdatePropertyToTerraform(struct?: TfAutomationRuleV2.FindingFieldsUpdateProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleV2FindingFieldsUpdatePropertyToHclTerraform(struct?: TfAutomationRuleV2.FindingFieldsUpdateProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleV2ActionPropertyToTerraform(struct?: TfAutomationRuleV2.ActionProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleV2ActionPropertyToHclTerraform(struct?: TfAutomationRuleV2.ActionProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleV2CriteriaPropertyToTerraform(struct?: TfAutomationRuleV2.CriteriaProperty | cdktn.IResolvable): any;
export declare function tfAutomationRuleV2CriteriaPropertyToHclTerraform(struct?: TfAutomationRuleV2.CriteriaProperty | cdktn.IResolvable): any;
export declare namespace TfAutomationRuleV2 {
    interface ExternalIntegrationConfigurationProperty {
        /**
        * The ARN of the connector.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule_v2#connector_arn TfAutomationRuleV2#connector_arn}
        */
        readonly connectorArn: string;
    }
    class ExternalIntegrationConfigurationPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ExternalIntegrationConfigurationProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ExternalIntegrationConfigurationProperty | cdktn.IResolvable | undefined);
        private _connectorArn?;
        get connectorArn(): string;
        set connectorArn(value: string);
        get connectorArnInput(): string | undefined;
    }
    class ExternalIntegrationConfigurationPropertyList extends cdktn.ComplexList {
        internalValue?: ExternalIntegrationConfigurationProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ExternalIntegrationConfigurationPropertyOutputReference;
    }
    interface FindingFieldsUpdateProperty {
        /**
        * A comment for the finding.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule_v2#comment TfAutomationRuleV2#comment}
        */
        readonly comment?: string;
        /**
        * The severity ID to assign.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule_v2#severity_id TfAutomationRuleV2#severity_id}
        */
        readonly severityId?: number;
        /**
        * The status ID to assign.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule_v2#status_id TfAutomationRuleV2#status_id}
        */
        readonly statusId?: number;
    }
    class FindingFieldsUpdatePropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): FindingFieldsUpdateProperty | cdktn.IResolvable | undefined;
        set internalValue(value: FindingFieldsUpdateProperty | cdktn.IResolvable | undefined);
        private _comment?;
        get comment(): string;
        set comment(value: string);
        resetComment(): void;
        get commentInput(): string | undefined;
        private _severityId?;
        get severityId(): number;
        set severityId(value: number);
        resetSeverityId(): void;
        get severityIdInput(): number | undefined;
        private _statusId?;
        get statusId(): number;
        set statusId(value: number);
        resetStatusId(): void;
        get statusIdInput(): number | undefined;
    }
    class FindingFieldsUpdatePropertyList extends cdktn.ComplexList {
        internalValue?: FindingFieldsUpdateProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): FindingFieldsUpdatePropertyOutputReference;
    }
    interface ActionProperty {
        /**
        * The action type: FINDING_FIELDS_UPDATE or EXTERNAL_INTEGRATION.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule_v2#type TfAutomationRuleV2#type}
        */
        readonly type: string;
        /**
        * external_integration_configuration block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule_v2#external_integration_configuration TfAutomationRuleV2#external_integration_configuration}
        */
        readonly externalIntegrationConfiguration?: ExternalIntegrationConfigurationProperty[] | cdktn.IResolvable;
        /**
        * finding_fields_update block
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule_v2#finding_fields_update TfAutomationRuleV2#finding_fields_update}
        */
        readonly findingFieldsUpdate?: FindingFieldsUpdateProperty[] | cdktn.IResolvable;
    }
    class ActionPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): ActionProperty | cdktn.IResolvable | undefined;
        set internalValue(value: ActionProperty | cdktn.IResolvable | undefined);
        private _type?;
        get type(): string;
        set type(value: string);
        get typeInput(): string | undefined;
        private _externalIntegrationConfiguration;
        get externalIntegrationConfiguration(): ExternalIntegrationConfigurationPropertyList;
        putExternalIntegrationConfiguration(value: ExternalIntegrationConfigurationProperty[] | cdktn.IResolvable): void;
        resetExternalIntegrationConfiguration(): void;
        get externalIntegrationConfigurationInput(): cdktn.IResolvable | ExternalIntegrationConfigurationProperty[] | undefined;
        private _findingFieldsUpdate;
        get findingFieldsUpdate(): FindingFieldsUpdatePropertyList;
        putFindingFieldsUpdate(value: FindingFieldsUpdateProperty[] | cdktn.IResolvable): void;
        resetFindingFieldsUpdate(): void;
        get findingFieldsUpdateInput(): cdktn.IResolvable | FindingFieldsUpdateProperty[] | undefined;
    }
    class ActionPropertyList extends cdktn.ComplexList {
        internalValue?: ActionProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): ActionPropertyOutputReference;
    }
    interface CriteriaProperty {
        /**
        * JSON-encoded OCSF finding criteria for the rule.
        *
        * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/aws/6.62.0/docs/resources/securityhub_automation_rule_v2#ocsf_finding_criteria_json TfAutomationRuleV2#ocsf_finding_criteria_json}
        */
        readonly ocsfFindingCriteriaJson: string;
    }
    class CriteriaPropertyOutputReference extends cdktn.ComplexObject {
        private isEmptyObject;
        private resolvableValue?;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param complexObjectIndex the index of this item in the list
        * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
        get internalValue(): CriteriaProperty | cdktn.IResolvable | undefined;
        set internalValue(value: CriteriaProperty | cdktn.IResolvable | undefined);
        private _ocsfFindingCriteriaJson?;
        get ocsfFindingCriteriaJson(): string;
        set ocsfFindingCriteriaJson(value: string);
        get ocsfFindingCriteriaJsonInput(): string | undefined;
    }
    class CriteriaPropertyList extends cdktn.ComplexList {
        internalValue?: CriteriaProperty[] | cdktn.IResolvable;
        /**
        * @param terraformResource The parent resource
        * @param terraformAttribute The attribute on the parent resource this class is referencing
        * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
        */
        constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
        /**
        * @param index the index of the item to return
        */
        get(index: number): CriteriaPropertyOutputReference;
    }
}
